# 参考链接
- application/README.md: application项目如何使用
- 其他的都还没有


代码地图

A. 应用层入口 — ma-mgt/application/src/main/java/com/convertlab/macore/mamgt/filter/
controller/bff/BffFilterController.java   ← UI 元数据接口 + preview/previewCount/timeline
controller/FilterController.java          ← /filterv4/* 老接口：V2→V4 转换、convertV2ToSql 等
service/FilterV4Service.java              ← 服务接口
service/impl/FilterV4ServiceImpl.java     ← 编排层，委托给 FilterV4Parser

B. DSL 模型 — ma-mgt/library/filter-api/src/main/java/com/convertlab/macore/mamgt/filter/
model/filterV4/Where.java                 ← ★ 核心：and/or 树 + 20 种比较算子（多态 JSON）
model/filterV4/request/FilterV4VO.java    ← UI 提交的 ViewModel
model/filterV4/{Select,Limit,OrderByItem,Identifier,TimelineFilterV4}.java
model/filterV4/date/                      ← CronDateTime / RangeDateTime / SpecificDateTime
enums/                                    ← OperatorNameEnum, ConvertTypeEnum, IdentifierTypeEnum…
visitor/Visitor.java                      ← 遍历 Where 树的访问者接口
loader/                                   ← 元数据加载的抽象骨架（AbstractMetaLoader、链式 Loader）

C. 转换引擎 — ma-mgt/library/filter-core/src/main/java/com/convertlab/macore/mamgt/filter/
FilterParser.java                         ← 能力总接口（parse/convert/count 全景，先看这个）
filters/FilterV4Parser.java               ← ★ FilterParser 的实现，全流程编排者
filters/service/FilterMetaService.java    ← UI 元数据树的服务接口
filters/misc/loader/meta/                 ← tree/ relation/ function/ 三类元数据 Loader 链
filters/convert/FilterV4Convert.java      ← 业务条件展开的调度器
filters/convert/handler/business/         ← Tag/EventGroup/List/Subscribe… 业务算子 → 标准条件
filters/convert/handler/date/             ← 三种日期类型的展开
filters/convert/builder/FilterV4Builder.java  ← 构造 Where 节点 / FilterV4Dto 的工具
filters/visitor/                          ← ConditionsConvertVisitor 等，遍历树应用 handler
filters/misc/client/QueryEngineFeignClient.java  ← 发给 foundation 的出口
filters/config/                           ← FilterV4ConvertHandlerContainer（handler 注册表）
filters/utils/FilterV4VOBuilder.java

D. 使用方（二阶段再看） — 不属于 filter 模块，但会调用它：cdp/common/utils/FilterV4Helper.java、cdp-data-core/.../CdpFilterV4Helper.java、分群/标签计算（SegmentMemberServiceImpl、TraitMemberServiceImpl）、数据权限 datapermission/service/RuleService.java。

▎ 顺带说明：目录里那些 test_jacoco/ 是构建产物，直接无视。

阅读顺序（5 步）

第 1 步：先学会"语言"——filter-api 模型（半天）
读 Where.java 从头到尾，重点是 @JsonSubTypes 那张算子表 —— 它定义了 DSL 的全部词汇；再读 FilterV4VO 和 date/ 下三个日期类。目标：拿到一段筛选 JSON 能看懂"and 嵌套 + eq/in/between + 动态日期"。

第 2 步：看入口和能力面（半天）
按调用链读：BffFilterController.metaTree / filterV4List → FilterV4ServiceImpl（只看方法名和委托关系，别陷进细节）→ FilterParser.java 接口。这个接口是整个模块的"目录页"，每个方法对应一个能力（V2 兼容转换、count、timeline、生成 SQL），看完你就知道这模块对外承诺了什么。

第 3 步：UI 元数据怎么生成（1 天）
FilterMetaServiceImpl → filters/misc/loader/meta/tree/RootMetaTreeLoader → 随便一两个子 Loader（如 IdentityMetaTreeLoader）→ 对照 filter-api/loader/ 的抽象骨架。目标：理解"筛选面板上能选哪些字段/算子/函数"是怎么从 GDM 元数据聚出来的。relation 和 function 的 Loader 链套路相同，扫一眼即可。

第 4 步：业务转换（1-2 天，重点）
FilterV4Convert（看调度逻辑）→ filters/visitor/ConditionsConvertVisitor（怎么遍历 Where 树）→ 精读一个 ConvertHandler，推荐 TagConvertHandler 或 EventGroupConvertHandler，配合 ConvertTypeEnum 看分发。目标：理解"标签命中人群 / 发生过某事件"这类业务条件如何被改写成标准 where。其余 handler 都是同套路，用到再查。

第 5 步：出口收尾（半天）
FilterV4Builder（怎么把转换结果组装成 FilterV4Dto）→ QueryEngineFeignClient 三个接口。到这里 ma-mgt 部分闭环，下一站就是 foundation 的 filter-json。

整个 ma-mgt 部分的主干其实很短：FilterV4ServiceImpl → FilterV4Parser → FilterV4Convert(+handlers) → FilterV4Builder → Feign，A/B/C 三块代码都是围着这条主干转的。建议每步都带着一个真实的筛选 JSON 去读（customer 的测试资源或者直接从页面抓一个 preview 请求体），比干读代码快得多。