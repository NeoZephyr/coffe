package com.convertlab.macore.mamgt.cdp.utils;

import com.convertlab.foundation.api.queryengine.GdmQuery;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.mamgt.cdp.OrderQuery;
import com.convertlab.macore.mamgt.cdp.profile.common.utils.OrderServiceUtils;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.associated.ProfileOrderBizMeta;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.associated.ProfileOrderPropBizMeta;
import com.convertlab.macore.mamgt.misc.client.QueryEngineFeignClient;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class OrderServiceUtilsTest {
    private final ProfileOrderBizMeta profileOrderBizMeta = profileOrderBizMetaInit();
    private final GdmEntity orderGdmEntity = orderGdmEntityInit();
    @Mock
    QueryEngineFeignClient queryEngineFeignClient;

    ProfileOrderBizMeta profileOrderBizMetaInit() {
        try {
            InputStream is = this.getClass().getResourceAsStream("/metas/profileOrderBizMeta.json");
            return JsonUtils.instanceOfDto().json2Obj(IOUtils.toString(is, StandardCharsets.UTF_8), ProfileOrderBizMeta.class);
        }catch (Exception e){
            return null;
        }
    }

    GdmEntity orderGdmEntityInit() {
        try {
            InputStream is = this.getClass().getResourceAsStream("/gdm/entities/udoOrderGdmEntity.json");
            return JsonUtils.instanceOfDto().json2Obj(IOUtils.toString(is, StandardCharsets.UTF_8), GdmEntity.class);
        }catch (Exception e){
            return null;
        }
    }

    @BeforeEach
    void generalInit() {
        GdmQuery.Response response = new GdmQuery.Response();
        response.setElapseTime(0);
        response.setRows(Collections.singletonList(Collections.singletonMap("order_no", "123")));
        Mockito.lenient()
                .when(queryEngineFeignClient.queryEngineQuery(any()))
                .thenReturn(response);
    }

    @Test
    void buildOrderMeta() {
        OrderQuery.OrderMeta orderMeta = OrderServiceUtils.buildOrderMeta(profileOrderBizMeta, orderGdmEntity);
        Assertions.assertNotNull(orderMeta);
        List<OrderQuery.OrderMeta.OrderBizAndGdmMeta> orderHeaderMeta = orderMeta.getOrderHeaderMeta();
        orderHeaderMeta.forEach(orderBizAndGdmMeta -> {
            GdmField gdmField = orderBizAndGdmMeta.getGdmField();
            ProfileOrderPropBizMeta profileOrderPropBizMeta = orderBizAndGdmMeta.getProfileOrderPropBizMeta();
            Assertions.assertEquals(orderBizAndGdmMeta.getProfileOrderPropBizMeta().getFieldId(), gdmField.getFieldName());
            Assertions.assertEquals(orderBizAndGdmMeta.getDbColumnName(), gdmField.getDbColumnName());
            Assertions.assertEquals(orderBizAndGdmMeta.getGdmFieldName(), gdmField.getFieldName());
            Assertions.assertEquals(orderBizAndGdmMeta.getBizFieldName(), profileOrderPropBizMeta.getName());
        });
        List<OrderQuery.OrderMeta.OrderBizAndGdmMeta> orderLineMeta = orderMeta.getOrderLineMeta();
        orderLineMeta.forEach(orderBizAndGdmMeta -> {
            GdmField gdmField = orderBizAndGdmMeta.getGdmField();
            ProfileOrderPropBizMeta profileOrderPropBizMeta = orderBizAndGdmMeta.getProfileOrderPropBizMeta();
            Assertions.assertEquals(orderBizAndGdmMeta.getProfileOrderPropBizMeta().getFieldId(), gdmField.getFieldName());
            Assertions.assertEquals(orderBizAndGdmMeta.getDbColumnName(), gdmField.getDbColumnName());
            Assertions.assertEquals(orderBizAndGdmMeta.getGdmFieldName(), gdmField.getFieldName());
            Assertions.assertEquals(orderBizAndGdmMeta.getBizFieldName(), profileOrderPropBizMeta.getName());
        });

    }

    @Test
    void orderExists() {
        boolean orderExists = OrderServiceUtils.orderExists("http://xxx/v1/query-engine/q", queryEngineFeignClient, "2017100500060082", "full_order", "customer");
        boolean orderExists1 = OrderServiceUtils.orderExists("http://xxx/v1/query-engine/q", queryEngineFeignClient, "20200929013", "cf_sys_sales_leads_order", "c_sys_sales_leads");
        assertTrue(orderExists);
        assertTrue(orderExists1);
    }

    @Test
    void processOrder() {
    }

    @Test
    void buildOrderMessage() throws Exception {
        InputStream is = this.getClass().getResourceAsStream("/cdp/order/orderDemo.json");
        OrderQuery.Order order = JsonUtils.instanceOfDto().json2Obj(IOUtils.toString(is, StandardCharsets.UTF_8), OrderQuery.Order.class);
        MDC.put("x_tenant_id", "1");
        MDC.put("x_request_id", "123");
        Map<String, Object> map = OrderServiceUtils.buildOrderMessage("c_xxn_test", order, OrderServiceUtils.INSERT_OPERATE);
        Assertions.assertNotNull(map);
        Assertions.assertNotNull(map.get("deal"));
        Assertions.assertNotNull(map.get("lines"));
    }

    @Test
    void replaceExtraField() {
        OrderQuery.OrderMeta orderMeta = OrderServiceUtils.buildOrderMeta(profileOrderBizMeta, orderGdmEntity);
        List<OrderQuery.OrderMeta.OrderBizAndGdmMeta> orderHeaderMeta = orderMeta.getOrderHeaderMeta();
        OrderQuery.OrderMeta.OrderBizAndGdmMeta orderBizAndGdmMeta = new OrderQuery.OrderMeta.OrderBizAndGdmMeta();
        orderBizAndGdmMeta.setBizFieldName("c_test");
        orderBizAndGdmMeta.setDbColumnName("c_test");
        orderBizAndGdmMeta.setDbColumnHumpName("cTest");
        ProfileOrderPropBizMeta profileOrderPropBizMeta = new ProfileOrderPropBizMeta();
        profileOrderPropBizMeta.setIsAttr(true);
        profileOrderPropBizMeta.setType("Boolean");
        orderBizAndGdmMeta.setProfileOrderPropBizMeta(profileOrderPropBizMeta);
        orderHeaderMeta.add(orderBizAndGdmMeta);
        Map<String, Object> extraField = new HashMap<>();
        extraField.put("c_test", true);
        int size = extraField.size();
        OrderServiceUtils.replaceExtraField(extraField, orderHeaderMeta);
        Assertions.assertEquals(extraField.get("cTest"), "是");
        Assertions.assertEquals(size, extraField.size());
    }
}