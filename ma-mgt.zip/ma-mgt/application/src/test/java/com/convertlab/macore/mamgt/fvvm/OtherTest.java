package com.convertlab.macore.mamgt.fvvm;

import com.convertlab.foundation.api.queryengine.FilterV4Dto;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Mr.黄
 * @description 其他测试
 * @since 2023/03/20 18:38
 **/
@Tag("UnitTest")
class OtherTest {
    @Test
    @DisplayName("测试json解析")
    void jsonParse() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Object> originalMessage = new HashMap<>(16);
        String message = "{\"deleteListMemberTopic\":\"delete_list_member\",\"featureInfo\":{},\"dataJobParam\":{\"jobId\":null,\"batchNo\":\"20230319022432eb2__gid_segment_recompute-1-1466622047315625984\",\"jobNo\":\"segment_recompute-1-1466622047315625984\",\"tenantId\":1,\"triggerParam\":\"{\\\"tenantId\\\":1,\\\"segmentId\\\":1466622047315625984}\"},\"addListMemberTopic\":\"add_list_member\",\"type\":\"list\",\"definitionType\":\"dynamic\",\"sql\":\"SELECT DISTINCT ce.customer_id FROM (select customer_id from customer_event ce where tenant_id = 1 and ce.event NOT IN ('join_list', 'create_customer', 'merge_customer', 'leave_list', 'session_stop_from', 'session_start_from', 'complete_task', 'reopen_task', 'downgrade_stage', 'create_task', 'email_invalid', 'default', 'web_hook', 'mobile_app_notification_received') AND ce.field_date >= 1677600000000  AND ce.field_date < 1677686400000  ) AS ce  where 1 = 1 \",\"joinListEventTopic\":\"join_list_event\",\"updateTopic\":\"list_or_tag_customer_count_update\",\"requestId\":\"831614810891498796b0571d40965792\",\"suKey\":\"su1\",\"name\":\"filterV4\",\"tenantId\":1,\"topic\":\"trait_segment_callback_message\",\"needRefresh\":true,\"taskId\":1308154,\"definitionId\":1466622047315625984,\"status\":\"success\"}";
        originalMessage = objectMapper.readValue(message, originalMessage.getClass());
        Assertions.assertNotNull(originalMessage);
//        System.out.println(objectMapper.writeValueAsString(originalMessage));
        for (Map.Entry<String, Object> entry : originalMessage.entrySet()) {
//            System.out.println(entry.getKey() + "\t" + entry.getValue());
        }
    }

    @Test
    @DisplayName("测试filters的json解析")
    void filtersTest() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        String filters = "{\"logicalOperator\":\"and\",\"subFilters\":[{\"logicalOperator\":\"and\",\"conditions\":[{\"parameter\":{\"value\":\"auto_member\",\"operator\":\"contains\"},\"property\":\"name\",\"property_type\":\"Text\",\"description\":{\"property\":\"客户属性-姓名\",\"constraint\":{\"descStr\":\"\",\"descArr\":[]},\"value\":\"包含auto_member\"},\"constraint\":{},\"category\":\"customer\",\"to_string\":\"客户属性-姓名 → 包含auto_member\"}]}],\"version\":2,\"v4\":{\"where\":{\"logicalOp\":{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"like\":{\"left\":{\"type\":\"COLUMN\",\"value\":\"name\"},\"extraParams\":{\"conditionPropertyType\":\"Text\",\"category\":\"customer\"},\"right\":{\"type\":\"VALUE\",\"value\":\"auto_member\"}}}]}}]}}]}}},\"version\":4,\"table\":\"customer\"}}";
        Map<String, Object> map = objectMapper.readValue(filters, Map.class);
//        System.out.println(map.get("v4"));
        FilterV4Dto v4 = objectMapper.convertValue(map.get("v4"), FilterV4Dto.class);
//        System.out.println(v4.toString());
    }
}
