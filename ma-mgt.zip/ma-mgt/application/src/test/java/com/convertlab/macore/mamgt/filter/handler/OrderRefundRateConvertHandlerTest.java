package com.convertlab.macore.mamgt.filter.handler;

import cn.hutool.core.io.resource.ResourceUtil;
import com.convertlab.foundation.api.queryengine.FilterV4Dto;
import com.convertlab.foundation.api.queryengine.SqlBuilder;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.mamgt.cdp.common.utils.FilterV4Helper;
import com.convertlab.macore.mamgt.filter.filters.convert.builder.FilterV4Builder;
import com.convertlab.macore.mamgt.filter.filters.convert.handler.business.OrderRefundRateConvertHandler;
import com.convertlab.macore.mamgt.filter.enums.IdentifierTypeEnum;
import com.convertlab.macore.mamgt.filter.filters.model.mapping.FilterConvertMappings;
import com.convertlab.macore.mamgt.filter.filters.service.FilterMetaService;
import com.convertlab.macore.mamgt.filter.filters.service.GroupService;
import com.convertlab.macore.mamgt.filter.utils.ConvertMappingTestingUtil;
import com.convertlab.macore.mamgt.misc.client.QueryEngineFeignClient;
import com.convertlab.macore.mamgt.filter.filters.model.dto.function.FunctionBody;
import com.convertlab.macore.mamgt.filter.model.filterV4.*;
import com.convertlab.macore.mamgt.filter.service.FilterV4Service;
import com.convertlab.macore.mamgt.utils.JsonConfigLoader;
import com.convertlab.test.BaseTest;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.joda.time.DateTimeUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class OrderRefundRateConvertHandlerTest extends BaseTest {

    @Mock
    private FilterMetaService metaService;

    @Mock
    private GroupService groupService;

    @Mock
    private static FilterV4Helper filterV4Helper;

    @Mock
    private static QueryEngineFeignClient mockQueryEngineClient;
    @Mock
    private static FilterV4Service mockFilterV4Service;

    private Where.CompareOperator compareOperator;

    private ListIterator conditionIterator;

    @BeforeEach
    public void setup() throws Exception {
        DateTime today = DateTime.parse("2023-04-07T02:20+08:00");
        DateTimeUtils.setCurrentMillisFixed(today.getMillis());

        // Mock compare operator
        compareOperator = JsonConfigLoader.config2Obj("handler/orderRefundRate/orderRefundRateOperator.json", Where.CompareOperator.class);
        Where.CompareOperator rangeDateOperator = JsonConfigLoader.config2Obj("handler/orderRefundRate/rangeDateOperator.json", Where.CompareOperator.class);
        Where.CompareOperator cronDateOperator = JsonConfigLoader.config2Obj("handler/orderRefundRate/cronDateOperator.json", Where.CompareOperator.class);
        List<Where.CompareOperator> list = new ArrayList<>();
        list.add(compareOperator);
        list.add(rangeDateOperator);
        list.add(cronDateOperator);
        conditionIterator = list.listIterator();

        filterV4Helper = new FilterV4Helper(mockQueryEngineClient, mockFilterV4Service);

        // Mock convert mapping
        FilterConvertMappings filterConvertMappings = new FilterConvertMappings();
        filterConvertMappings.setFieldMappings(ConvertMappingTestingUtil.getFieldMappings());
        filterConvertMappings.setEntityMappings(ConvertMappingTestingUtil.getEntityMappings());
        filterConvertMappings.setConvertMapping(ConvertMappingTestingUtil.getConvertMapping());
        Mockito.lenient().when(metaService.getFilterConvertMappings(eq("customer"))).thenReturn(filterConvertMappings);


        // Mock function meta
        List<FunctionBody> dummyFunctions = JsonUtils.instanceOfDto().json2List(ResourceUtil.readUtf8Str("meta/meta-function.json"), FunctionBody.class);
        Map<String, FunctionBody> dummyMetaFunctionMap = dummyFunctions.stream().collect(Collectors.toMap(FunctionBody::getName, metaFunction -> metaFunction));
        Mockito.lenient().when(metaService.getMetaFunction()).thenReturn(dummyFunctions);
        Mockito.lenient().when(metaService.getMetaFunctionMap()).thenReturn(dummyMetaFunctionMap);

        String sql = "select * from full_order where date_order < '2023-11-24' and date_order >= '2023-10-24'";
        SqlBuilder.Response response = mock(SqlBuilder.Response.class);
        response.setGdql(sql);
        Mockito.lenient().when(mockQueryEngineClient.queryEngineSql(any())).thenReturn(response);

        String tableName = "full_order";
        FilterV4 filterV4 = new FilterV4();
        filterV4.setVersion(4);
        filterV4.setTable(tableName);
        Select select = new Select(FilterV4Dto.IdentifierType.COLUMN.getType(), "customer_id");
        filterV4.setSelect(Arrays.asList(select));
        List<Where.Operator> conditions = new ArrayList<>();
        Where.LogicalOperator logicalOperator = FilterV4Builder.buildLogicalNode(Where.LogicalOperator.Constants.AND, conditions.stream().toArray(Where.Operator[]::new));
        TimelineFilterV4.TimelineWhere where = new TimelineFilterV4.TimelineWhere();
        where.setLogicalOp(logicalOperator);
        filterV4.setWhere(where);
        String filterV4Json = JsonUtils.instanceOfDto().obj2Json(filterV4);
        FilterV4Dto filterV4Dto = JsonUtils.instanceOfDto().json2Obj(filterV4Json, FilterV4Dto.class);

        Mockito.lenient().when(filterV4Helper.filterV4ToSql(filterV4Dto, SqlBuilder.OutputFormat.GDQL, SqlBuilder.SQLDialect.SPARK)).thenReturn(sql);
        Mockito.lenient().when(FilterV4Builder.getDateClause(conditions, tableName, Arrays.asList(select))).thenReturn(sql);
    }

    @Test
    public void testConvert() {
        Map<String, Object> compareOperatorMap = mock(Map.class);
        OrderRefundRateConvertHandler orderRefundRateConvertHandler = new OrderRefundRateConvertHandler(groupService, metaService);
        orderRefundRateConvertHandler.convert(compareOperator, compareOperatorMap, conditionIterator);
        // 判断 conditionIterator 对象中的参数是否符合预期
        assertTrue(conditionIterator.hasPrevious());
        Where.CompareOperator operator = (Where.CompareOperator) conditionIterator.previous();
        assertNotNull(operator);
        Identifier left = operator.getLeft();
        Identifier right = operator.getRight();
        String resultSql = String.format(orderRefundRateConvertHandler.BASIC_SQL, "refund_rate", " AND date_order < '2023-11-24' and date_order >= '2023-10-24'");

        assertEquals(IdentifierTypeEnum.TMP_VIEW.getType(), left.getType());
        assertEquals("customer_id", left.getPrimaryKey());
        assertEquals("refund_rate", left.getColumn());
        assertEquals(resultSql, left.getSql());
        assertEquals(IdentifierTypeEnum.VALUE.getType(), right.getType());
        assertEquals(compareOperator.getRight().getValue(), left.getValue());

    }

}
