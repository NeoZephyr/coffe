package com.convertlab.macore.mamgt.filter;

import javax.annotation.Nonnull;
import java.io.BufferedReader;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import cn.hutool.core.io.resource.ResourceUtil;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.api.queryengine.FilterV4Dto;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClientWrapper;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.mamgt.cdp.client.GdmModelClientWrapper;
import com.convertlab.macore.mamgt.cdp.dto.Profile;
import com.convertlab.macore.mamgt.cdp.dto.Segment;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.GeneralProfileBizMeta;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.PrimaryProfileBizMeta;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.associated.ProfileEventBizMeta;
import com.convertlab.macore.mamgt.cdp.profile.mapper.TenantRelatedMapper;
import com.convertlab.macore.mamgt.cdp.meta.model.dto.profile.ProfileMeta;
import com.convertlab.macore.mamgt.cdp.meta.service.CdpMetaService;
import com.convertlab.macore.mamgt.cdp.meta.service.impl.CdpMetaServiceImpl;
import com.convertlab.macore.mamgt.cdp.profile.service.impl.SegmentServiceImpl;
import com.convertlab.macore.mamgt.common.configure.ApplicationContextProvider;
import com.convertlab.macore.mamgt.common.service.ServiceUnitService;
import com.convertlab.macore.mamgt.filter.filters.FilterV4Parser;
import com.convertlab.macore.mamgt.filter.filters.config.FilterV4ConvertHandlerContainer;
import com.convertlab.macore.mamgt.filter.filters.convert.FilterV4Convert;
import com.convertlab.macore.mamgt.filter.filters.misc.client.QueryEngineFeignClient;
import com.convertlab.macore.mamgt.filter.filters.model.dto.GdmEntityBizMeta;
import com.convertlab.macore.mamgt.filter.filters.model.dto.function.FunctionBody;
import com.convertlab.macore.mamgt.filter.filters.model.mapping.FilterConvertMappings;
import com.convertlab.macore.mamgt.filter.filters.service.FilterMetaService;
import com.convertlab.macore.mamgt.filter.filters.service.GroupService;
import com.convertlab.macore.mamgt.filter.filters.visitor.*;
import com.convertlab.macore.mamgt.cdp.meta.service.ProfileEventMetaService;
import com.convertlab.macore.mamgt.cdp.profile.service.ProfileExtService;
import com.convertlab.macore.mamgt.cdp.meta.service.ProfileMetaService;
import com.convertlab.macore.mamgt.common.KafkaListenersTypeExcludeFilter;
import com.convertlab.macore.mamgt.filter.model.filterV4.request.FilterV4VO;
import com.convertlab.macore.mamgt.filter.model.filterv2.Preview;
import com.convertlab.macore.mamgt.filter.service.impl.FilterV4ServiceImpl;
import com.convertlab.macore.mamgt.filter.utils.ConvertMappingTestingUtil;
import com.convertlab.macore.mamgt.misc.testingutil.mapper.FiltersV4Mapper;
import com.convertlab.macore.mamgt.utils.JsonConfigLoader;
import com.convertlab.macore.mamgt.utils.ParserTestCase;
import com.convertlab.test.BaseTest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.joda.time.DateTimeUtils;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.filter.TypeExcludeFilters;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

@Slf4j
@ExtendWith(MockitoExtension.class)
@TypeExcludeFilters(KafkaListenersTypeExcludeFilter.class)
public class FilterTest extends BaseTest {
    /**
     * Real test case begins
     */
    @Nonnull
    static String caseRootDir = "filters";
    static String udoFiltersDir = "udofilters";

    @Mock
    private QueryEngineFeignClient queryEngineFeignClient;

    private FilterV4ConvertHandlerContainer filterV4ConvertHandlerContainer;
    private FilterV4Convert filterV4Convert;
    private ConditionsConvertVisitor conditionsConvertVisitor;

    private ConditionsRemoveVisitor conditionsRemoveVisitor;

    private ConditionsAddSinceIdVisitor conditionsAddSinceIdVisitor;

    private ConditionsAggFuncVisitor conditionsAggFuncVisitor;

    private ConditionsDefaultVisitor conditionsDefaultVisitor;

    private ConditionsAddAdditionalConditionVisitor conditionsAddAdditionalConditionVisitor;

    private ConditionsValueConvertVisitor conditionsValueConvertVisitor;

    private FilterV4Parser filterV4Parser;
    @Mock
    private FilterMetaService metaService;
    @Mock
    private ProfileMetaService profileMetaService;
    @Mock
    private ProfileEventMetaService profileEventMetaService;
    @Mock
    private ProfileExtService profileExtService;
    @Mock
    private GsMetaClientWrapper gsMetaClient;
    @Mock
    private GdmEntity customerEntity;
    @Mock
    private GdmEntity cUserOpencard;
    @Mock
    private GdmModelClientWrapper gdmModelClient;
    @Mock
    private ServiceUnitService serviceUnitService;

    @Mock
    private TenantRelatedMapper tenantRelatedMapper;
    @Mock
    private FiltersV4Mapper filtersV4Mapper;

    private FilterV4ServiceImpl filterV4Service = null;

    static MockedStatic<ApplicationContextProvider> applicationContextProvider = null;


    @BeforeAll
    static void beforeAll() {
        applicationContextProvider = Mockito.mockStatic(ApplicationContextProvider.class);
        SegmentServiceImpl mockSegmentServiceImpl = Mockito.mock(SegmentServiceImpl.class);
        List<Segment> segments = new ArrayList<>();
        segments.add(randomMockSegment(545553231103715328L));
        segments.add(randomMockSegment(545552553136416768L));
        Mockito.lenient().doReturn(segments).when(mockSegmentServiceImpl).findByIds(eq("customer"), any());
        applicationContextProvider.when(()-> ApplicationContextProvider.getBean(SegmentServiceImpl.class))
                .thenReturn(mockSegmentServiceImpl);

        CdpMetaServiceImpl mockCdpMetaServiceImpl = Mockito.mock(CdpMetaServiceImpl.class);
        Mockito.lenient().doReturn(getMockProfileMeta("customer")).when(mockCdpMetaServiceImpl).getProfileMeta(eq("customer"));
        applicationContextProvider.when(()-> ApplicationContextProvider.getBean(CdpMetaService.class))
                .thenReturn(mockCdpMetaServiceImpl);

        GdmModelClientWrapper mockGdmModelClientWrapper = Mockito.mock(GdmModelClientWrapper.class);
        applicationContextProvider.when(()-> ApplicationContextProvider.getBean(GdmModelClientWrapper.class))
                .thenReturn(mockGdmModelClientWrapper);
        GdmModelDto gdmModelDto = JsonConfigLoader.config2Obj("cdp/ProfileServiceImpl/customer_gdm_model_dto.json", GdmModelDto.class);
        Mockito.lenient().doReturn(gdmModelDto).when(mockGdmModelClientWrapper).findByName(eq("customer"));

        log.info("beforeAll, mock PrincipalContextHolder");
    }

    static Segment randomMockSegment(Long listId){
        Segment segment = new Segment();
        segment.setName(UUID.randomUUID().toString());
        segment.setIsStatic(true);
        segment.setId(listId);
        return segment;
    }
    @AfterAll
    static void afterAll() {
        applicationContextProvider.close();
    }

    static ProfileMeta getMockProfileMeta(String profileName) {
        if (profileName.equals("customer")) {
            ProfileMeta profileMeta = new ProfileMeta();
            profileMeta.setProfileName(profileName);
            profileMeta.setProfileEntityName("customer");
            profileMeta.setProfileEntityPK("id");
            profileMeta.setProfileEventRelEntityFK("customer_id");

            profileMeta.setIdentityDefEntityName("identity");
            profileMeta.setProfileIdentityRelEntityName("identity");
            profileMeta.setProfileIdentityRelEntityFK("customer_id");

            profileMeta.setSegmentDefEntityName("list");
            profileMeta.setStaticSegmentDefEntityName("list_member");
            profileMeta.setDynamicSegmentDefEntityName("dynamic_list_member");
            profileMeta.setProfileDynamicSegmentRelEntityName("dynamic_list");
            profileMeta.setProfileStaticSegmentRelEntityName("static_list");
            profileMeta.setProfileSegmentRelEntityFK("customer_id");

            profileMeta.setTraitDefEntityName("tag");
            profileMeta.setStaticTraitDefEntityName("customer_tag");
            profileMeta.setDynamicTraitDefEntityName("dynamic_customer_tag");
            profileMeta.setProfileStaticTraitRelEntityName("static_tag");
            profileMeta.setProfileDynamicTraitRelEntityName("dynamic_tag");
            profileMeta.setProfileTraitRelEntityFK("customer_id");
            return profileMeta;
        }else{
            return  null;
        }
    }
    @BeforeEach
    public void setup() throws Exception {
        DateTime today = DateTime.parse("2023-04-07T02:20+08:00");
        DateTimeUtils.setCurrentMillisFixed(today.getMillis());

        // Mock tagName -> tagId resolver
        GroupService groupService = Mockito.mock(GroupService.class);
        Mockito.lenient().doAnswer(invocation -> {
            Object[] args = invocation.getArguments();
            Map<String, String> result = new HashMap<>();
            int i = 10000;
            for(String tagName : (List<String>)args[1]){
                result.put(tagName, String.valueOf(i++));
            }
            return result;
        }).when(groupService).getIdsByNames(any(),any());

        filterV4ConvertHandlerContainer = new FilterV4ConvertHandlerContainer(groupService, metaService);
        filterV4Convert = new FilterV4Convert(filterV4ConvertHandlerContainer,profileEventMetaService, metaService);
        conditionsConvertVisitor = new ConditionsConvertVisitor(filterV4Convert);
        conditionsRemoveVisitor = new ConditionsRemoveVisitor(filterV4Convert);
        conditionsAddSinceIdVisitor = new ConditionsAddSinceIdVisitor(filterV4Convert);
        conditionsAggFuncVisitor = new ConditionsAggFuncVisitor(filterV4Convert);
        conditionsDefaultVisitor = new ConditionsDefaultVisitor(filterV4Convert);
        conditionsAddAdditionalConditionVisitor = new ConditionsAddAdditionalConditionVisitor(filterV4Convert);
        conditionsValueConvertVisitor = new ConditionsValueConvertVisitor(filterV4Convert);
        filterV4Parser = new FilterV4Parser(queryEngineFeignClient,
                conditionsConvertVisitor, conditionsRemoveVisitor, conditionsAddSinceIdVisitor,conditionsAggFuncVisitor,
                conditionsDefaultVisitor, conditionsAddAdditionalConditionVisitor,
                conditionsValueConvertVisitor,
                metaService, profileMetaService, profileEventMetaService,
                profileExtService, gsMetaClient,gdmModelClient,
                serviceUnitService, tenantRelatedMapper);

        filterV4Parser.setPersistV4Model(true);

        filterV4Service = new FilterV4ServiceImpl(filterV4Parser, gsMetaClient,gdmModelClient,
                serviceUnitService, tenantRelatedMapper, filtersV4Mapper );

        // Mock profile biz metas
        PrimaryProfileBizMeta mockProfileBizMeta = JsonConfigLoader.config2Obj("cdp/ProfileServiceImpl/primary_profile_biz_meta.json", PrimaryProfileBizMeta.class);
        Mockito.lenient().when(profileMetaService.getProfileBizMeta(eq("customer"),
                eq(true), eq(false), eq(false),
                eq(false), eq(false), eq(false),eq(false),
                any(List.class)))
                .thenReturn(mockProfileBizMeta);

        Mockito.lenient().when(profileMetaService.getProfileBizMeta(eq("customer"),
                        eq(true), eq(true), eq(false),
                        eq(false), eq(false), eq(false),eq(false),
                        any(List.class)))
                .thenReturn(mockProfileBizMeta);

        GeneralProfileBizMeta mockUdoBizMeta = JsonConfigLoader.config2Obj("cdp/ProfileServiceImpl/265981-profile.json", GeneralProfileBizMeta.class);
        Mockito.lenient().when(profileMetaService.getProfileBizMeta(eq("c_user_opencard"),
                        eq(true), eq(false), eq(false),
                        eq(false), eq(false), eq(false),eq(false),
                        any(List.class)))
                .thenReturn(mockUdoBizMeta);

        Mockito.lenient().when(profileMetaService.getProfileBizMeta(eq("c_user_opencard"),
                        eq(true), eq(true), eq(false),
                        eq(false), eq(false), eq(false),eq(false),
                        any(List.class)))
                .thenReturn(mockUdoBizMeta);

        // Mock profile event biz metas
        List<ProfileEventBizMeta> mockEventsBizMeta = JsonConfigLoader.config2Obj("cdp/ProfileServiceImpl/primary_profile_events_biz_meta.json", new TypeReference<List<ProfileEventBizMeta>>() {
        });
        Mockito.lenient().when(profileEventMetaService.getBizEventMetas(eq("customer"),
                        eq(false),
                eq(false), eq(false), eq(false),eq(false),eq(true)))
                .thenReturn(mockEventsBizMeta);

        List<ProfileEventBizMeta> mockUdoEventsBizMeta = JsonConfigLoader.config2Obj("cdp/ProfileServiceImpl/265981-profile-events.json", new TypeReference<List<ProfileEventBizMeta>>() {
        });
        Mockito.lenient().when(profileEventMetaService.getBizEventMetas(eq("c_user_opencard"),
                        eq(false),
                        eq(false), eq(false), eq(false),eq(false),eq(true)))
                .thenReturn(mockEventsBizMeta);


        // Mock convert mapping
        FilterConvertMappings filterConvertMappings = new FilterConvertMappings();
        filterConvertMappings.setFieldMappings(ConvertMappingTestingUtil.getFieldMappings());
        filterConvertMappings.setEntityMappings(ConvertMappingTestingUtil.getEntityMappings());
        filterConvertMappings.setConvertMapping(ConvertMappingTestingUtil.getConvertMapping());
        Mockito.lenient().when(metaService.getFilterConvertMappings(any(String.class))).thenReturn(filterConvertMappings);

        // Mock relation meta
        Map<String, Object> relationMeta = JsonConfigLoader.config2Obj("metas/primary_profile_relation_meta.json", Map.class);
        Mockito.lenient().when(metaService.getMetaRelation(eq("customer"))).thenReturn(relationMeta);

        Map<String, Object> udoRelationMeta = JsonConfigLoader.config2Obj("metas/265981-relation.json", Map.class);
        Mockito.lenient().when(metaService.getMetaRelation(eq("c_user_opencard"))).thenReturn(udoRelationMeta);

        // Mock function meta
        List<FunctionBody> dummyFunctions = JsonUtils.instanceOfDto().json2List(ResourceUtil.readUtf8Str("meta/meta-function.json"), FunctionBody.class);
        Map<String, FunctionBody> dummyMetaFunctionMap = dummyFunctions.stream().collect(Collectors.toMap(FunctionBody::getName, metaFunction -> metaFunction));
        Mockito.lenient().when(metaService.getMetaFunction()).thenReturn(dummyFunctions);
        Mockito.lenient().when(metaService.getMetaFunctionMap()).thenReturn(dummyMetaFunctionMap);

        // Mock gdmMeta
        Map<String, GdmEntityBizMeta> gdmMeta = JsonUtils.dtoMapper().readValue(ResourceUtil.readUtf8Str("metas/primary_profile_gdm_meta.json"), new TypeReference<Map<String, GdmEntityBizMeta>>() {
        });
        Mockito.lenient().when(metaService.batchGetGdmBizMeta(eq("customer"), any(List.class))).thenReturn(gdmMeta);

        Map<String, GdmEntityBizMeta> udoGdmMeta = JsonUtils.dtoMapper().readValue(ResourceUtil.readUtf8Str("metas/265981-gdm.json"), new TypeReference<Map<String, GdmEntityBizMeta>>() {
        });
        Mockito.lenient().when(metaService.batchGetGdmBizMeta(eq("c_user_opencard"), any(List.class))).thenReturn(udoGdmMeta);

        // 不处理codelist
        Mockito.lenient().when(profileExtService.addCodeListValueToProfile(any(String.class), any(Profile.class)))
                .thenAnswer(it -> {
                    return it.getArguments()[1];
                });
        Mockito.lenient().when(customerEntity.getPrimaryKeyField()).thenReturn("id");
        Mockito.lenient().when(gsMetaClient.getEntity(eq("customer"))).thenReturn(customerEntity);

        Mockito.lenient().when(cUserOpencard.getPrimaryKeyField()).thenReturn("bk");
        Mockito.lenient().when(gsMetaClient.getEntity(eq("c_user_opencard"))).thenReturn(cUserOpencard);
    }
    @AfterAll
    public static void tearDown() {
        DateTimeUtils.setCurrentMillisSystem();
    }

//    @ParameterizedTest
//    @DisplayName("A conversion test from FilterV2 to ViewModel")
//    @MethodSource("findAllFilterJson")
//    public void testFilterV2ToViewModel(String caseFile) throws Exception{
//        if(false == "filters/filter_since_id".equals(caseFile)){
//            try(TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(1L, "客户A")) {
//                ParserTestCase testCase = new ParserTestCase(caseFile);
//                // 将Filter V2转换为ViewModel
//                Preview<FilterV4VO> preview = convertFilterV2ToViewModel(caseFile);
//                FilterV4VO viewModel = preview.getFilters().getV4();
//                String viewModelString = JsonUtils.instance().obj2Json(viewModel, true);
//                String expectedViewModelString = testCase.getViewModelContent();
//                assertJSONEquals(expectedViewModelString, viewModelString, "convert filterV2 to view model failed");
//            }
//        }
//    }

    @ParameterizedTest
    @DisplayName("all in one conversion")
    @MethodSource("findAllFilterJson")
    public void testConvertFilterV2ToFilterV4(String caseFile) throws Exception{
        if(false == "filters/filter_since_id".equals(caseFile)){
            try(TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(1L, "客户A")) {
                ParserTestCase testCase = new ParserTestCase(caseFile);
                String json5 = JsonConfigLoader.readContent(caseFile + ".json5");
                Preview preview = JsonUtils.instanceOfDto().json2Obj(json5, Preview.class);

                FilterV4Dto result = filterV4Service.convertFilterV2ToFilterV4("customer",null, null, preview.getFilters());
                String filterV4String = JsonUtils.instance().obj2Json(result, true);
                String expected = testCase.getResultFilterV4();
                assertFilterV4WhereConditionEquals(expected, filterV4String, "convertFilterV2ToFilterV4 failed ");
            }
        }
    }


    @ParameterizedTest
    @DisplayName("all in one conversion")
    @MethodSource("findAllUdoFilterJson")
    public void testUdoConvertFilterV2ToFilterV4(String caseFile) throws Exception{
        try(TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(1L, "c_car")) {
            ParserTestCase testCase = new ParserTestCase(caseFile);
            String json5 = JsonConfigLoader.readContent(caseFile + ".json5");
            Preview preview = JsonUtils.instanceOfDto().json2Obj(json5, Preview.class);

            FilterV4Dto result = filterV4Service.convertFilterV2ToFilterV4("c_user_opencard",null, null, preview.getFilters());
            String filterV4String = JsonUtils.instance().obj2Json(result, true);
            String expected = testCase.getResultFilterV4();
            assertFilterV4WhereConditionEquals(expected, filterV4String, "convertFilterV2ToFilterV4 failed ");
        }
    }

    @ParameterizedTest
    @DisplayName("sinceid conversion")
    @MethodSource("findAllFilterJson")
    public void testConvertSinceIdInFilterV4(String caseFile) throws Exception{
        if("filters/filter_since_id".equals(caseFile)){
            try(TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(1L, "客户A")) {
                ParserTestCase testCase = new ParserTestCase(caseFile);
                String json5 = JsonConfigLoader.readContent(caseFile + ".json5");
                Preview preview = JsonUtils.instanceOfDto().json2Obj(json5, Preview.class);

                FilterV4Dto result = filterV4Service.convertFilterV2ToFilterV4("customer",null, null, preview.getFilters());
                String filterV4String = JsonUtils.instance().obj2Json(result, true);
                String expected = testCase.getResultFilterV4();
                assertFilterV4SinceId(expected, filterV4String, "convertFilterV2ToFilterV4 failed ");
            }
        }
    }

    private Preview<FilterV4VO> convertFilterV2ToViewModel(@Nonnull String caseFile) throws Exception{
        String json5 = JsonConfigLoader.readContent(caseFile + ".json5");
        Preview<FilterV4VO> preview = JsonUtils.dtoMapper().readValue(json5, new TypeReference<Preview<FilterV4VO>>() {});

        // 删除测试请求中的V4节点，保留filterV2
        Map<String, Object> previewJson = JsonConfigLoader.convertJson5ToJson(json5);
        Map filtersJson = (Map) previewJson.get("filters");
        filtersJson.remove("v4");
        String json = JsonUtils.instanceOfDto().obj2Json(filtersJson);
        log.info("convert filterV2 json: {}", json);

        // 使用JavaScript转换器，将filterV2转换为filterV4
        FilterV4VO viewModel = filterV4Service.convertFilterV2ToViewModel("customer", json);
        Assertions.assertNotNull(viewModel, "convert filterv2 to viewModel failed");
        // 替换测请求中的filterV4
        preview.getFilters().setV4(viewModel);
        return preview;
    }

    @SneakyThrows
    private void handleException(@Nonnull ParserTestCase testCase, @Nonnull Exception e, boolean recordOutput) {
        String exception = loadException(testCase);
        String actualException = e.getClass().getCanonicalName() + " : " + e.getMessage();
        if (recordOutput || exception == null || exception.trim().isEmpty()) {
            log.warn("exception result is missing, writing...");
            testCase.recordException(actualException);
            throw e;
        }
        assertEquals(exception, actualException, "Not expected exception");
    }

    protected String loadException(@Nonnull ParserTestCase testCase) {
        return testCase.getExceptionContent();
    }
    @Nonnull
    private static Stream<Arguments> findAllFilterJson() throws IOException {
        URL resourceURL = Thread.currentThread().getContextClassLoader().getResource(caseRootDir);
        if(resourceURL==null) {
            return Stream.empty();
        }
        Path resourcePath = Paths.get(resourceURL.getPath());
        // TODO: Ugly code, refine it if you can not bear it!
        return Files.walk(resourcePath)
                .filter(s -> s.toString().endsWith(".json5") && !s.toString().contains("timeline") && !s.toString().contains("skip"))
                .map(path -> path.subpath(resourcePath.getNameCount() - 1, path.getNameCount()))
                .map(Path::toString)
                .map(path -> {
                    try (BufferedReader br = Files.newBufferedReader(Paths.get("/"+resourcePath.subpath(0,resourcePath.getNameCount()-1)+"/"+path))) {
                        String line = br.readLine();
                        String filename = path.substring(0, path.length() - 6);
                        line = line.startsWith("//") ? line.substring(2) : filename;
                        return Named.of(line, filename);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                })
                .map(Arguments::of)
                ;
    }

    @Nonnull
    private static Stream<Arguments> findAllUdoFilterJson() throws IOException {
        URL resourceURL = Thread.currentThread().getContextClassLoader().getResource(udoFiltersDir);
        if(resourceURL==null) {
            return Stream.empty();
        }
        Path resourcePath = Paths.get(resourceURL.getPath());
        // TODO: Ugly code, refine it if you can not bear it!
        return Files.walk(resourcePath)
                .filter(s -> s.toString().endsWith(".json5") && !s.toString().contains("timeline") && !s.toString().contains("skip"))
                .map(path -> path.subpath(resourcePath.getNameCount() - 1, path.getNameCount()))
                .map(Path::toString)
                .map(path -> {
                    try (BufferedReader br = Files.newBufferedReader(Paths.get("/"+resourcePath.subpath(0,resourcePath.getNameCount()-1)+"/"+path))) {
                        String line = br.readLine();
                        String filename = path.substring(0, path.length() - 6);
                        line = line.startsWith("//") ? line.substring(2) : filename;
                        return Named.of(line, filename);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                })
                .map(Arguments::of)
                ;
    }

    static void assertJSONEquals(String expected, String actual, String message) throws JsonProcessingException, JsonMappingException {
        ObjectMapper mapper = com.convertlab.foundation.library.utils.JsonUtils.getDefaultObjectMapper();
        mapper.configure(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS, true);
        Map leftObj = mapper.readValue(expected, Map.class);
        Map rightObj = mapper.readValue(actual, Map.class);
        String leftStr = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(leftObj);
        String rightStr = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(rightObj);
        assertEquals(leftStr,rightStr, message);
    }

    /**
     * 仅判断where条件一致，忽略select等其他条件
     * @param expected
     * @param actual
     * @param message
     * @throws JsonProcessingException
     * @throws JsonMappingException
     */
    static void assertFilterV4WhereConditionEquals(String expected, String actual, String message) throws JsonProcessingException, JsonMappingException {
        ObjectMapper mapper = com.convertlab.foundation.library.utils.JsonUtils.getDefaultObjectMapper();
        mapper.configure(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS, true);
        Map leftObj = mapper.readValue(expected, Map.class);
        Map rightObj = mapper.readValue(actual, Map.class);
        leftObj.remove("select");
        leftObj.remove("limit");
        leftObj.remove("orderBy");
        rightObj.remove("select");
        rightObj.remove("limit");
        rightObj.remove("orderBy");
        String leftStr = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(leftObj);
        String rightStr = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(rightObj);
        assertEquals(leftStr,rightStr, message);
    }

    /**
     *
     */
    static void assertFilterV4SinceId(String expected, String actual, String message) throws JsonProcessingException, JsonMappingException {
        ObjectMapper mapper = com.convertlab.foundation.library.utils.JsonUtils.getDefaultObjectMapper();
        mapper.configure(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS, true);
        Map leftObj = mapper.readValue(expected, Map.class);
        Map rightObj = mapper.readValue(actual, Map.class);
        leftObj.remove("select");
        leftObj.remove("limit");
        leftObj.remove("orderBy");
        rightObj.remove("select");
        rightObj.remove("limit");
        rightObj.remove("orderBy");
        String leftStr = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(leftObj);
        String rightStr = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(rightObj);
        assertEquals(leftStr,rightStr, message);
    }
}
