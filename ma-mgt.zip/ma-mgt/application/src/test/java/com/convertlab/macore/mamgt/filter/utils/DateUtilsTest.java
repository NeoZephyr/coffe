package com.convertlab.macore.mamgt.filter.utils;

import com.convertlab.foundation.library.exception.business.BusinessException;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.convertlab.macore.mamgt.filter.constants.Constants.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * All rights Reserved, Designed By ConvertLab
 * Author: zhiping.cai
 * Date: 2023/5/25
 * Description:
 * Copyright (C) 2022 www.convertlab.com
 */
@Tag("DateUtilsUnitTest")
public class DateUtilsTest {

    @Test
    public void testGetStaticDate() {
        Map<String, String> filterMapping = new HashMap<>();
        filterMapping.put("open_site", "open_page");

        List<String> result = DateUtils.getStaticDate("2020-08-08", "date", "date", filterMapping,"eq");
        assertEquals(Arrays.asList("2020-08-08 00:00:00"), result);
        result = DateUtils.getStaticDate("birthday", "hour", "datetime", filterMapping,"eq");
        assertEquals(Arrays.asList("HOUR(birthday,'Asia/Shanghai')"), result);
        BusinessException exception = assertThrows(BusinessException.class, () -> DateUtils.getStaticDate("2020-08-08", "unknown", "date", filterMapping,"eq"));
        assertEquals("MSG_100_000011", exception.getMessageCode());
    }
    @Test
    public void testGetDateStrByFieldType() {
        List<String> result = DateUtils.getDateStrByFieldType("2020-08-08", "date","eq");
        assertEquals(Arrays.asList("2020-08-08 00:00:00"), result);
        result = DateUtils.getDateStrByFieldType("2020-08-08T00:00:00Z", "datetime","eq");
        assertEquals(Arrays.asList("2020-08-08 00:00:00"), result);
        result = DateUtils.getDateStrByFieldType("2020-08-08", "datetime","eq");
        assertEquals(Arrays.asList("2020-08-07 16:00:00","2020-08-08 16:00:00"), result);
        BusinessException exception = assertThrows(BusinessException.class, () -> DateUtils.getDateStrByFieldType("2020-08-08 10:00:00", "datetime","eq"));
        assertEquals("MSG_100_000009", exception.getMessageCode());
    }
    @Test
    public void testGetDynamicRangeDate() {
        List<String> result = DateUtils.getDynamicRangeDate("day", "datetime", "-7", null, true, null);
        assertNotNull(result);
        result = DateUtils.getDynamicRangeDate("day", "datetime", null, "-0", null, true);
        assertNotNull(result);
        result = DateUtils.getDynamicRangeDate("day", "datetime", "any", "any", null, null);
        assertEquals(Arrays.asList("1400-01-01 15:54:17", "2999-12-31 16:00:00"), result);
    }
    @Test
    public void testHandleDynamicDateValue() {
        DateTime now = new DateTime(DateTimeZone.forID("Asia/Shanghai"));
        DateTime result = DateUtils.handleDynamicDateValue("day", now, "1", "+", true, null);
        assertEquals(now.plusDays(1), result);
        result = DateUtils.handleDynamicDateValue("week", now, "1", "-", true, null);
        assertEquals(now.minusWeeks(1).withDayOfWeek(1), result);
    }
    @Test
    public void testConvertDateStrToUtc() {
        String result = DateUtils.convertDateStrToUtc("2020-08-08", DateTimeZone.forID("Asia/Shanghai"), "date", true);
        assertEquals("2020-08-07T16:00:00Z", result);
        result = DateUtils.convertDateStrToUtc("2020-08-08 16:00:00", DateTimeZone.forID("Asia/Shanghai"), "datetime", true);
        assertEquals("2020-08-08T08:00:00Z", result);
    }
    @Test
    public void testConvertDateTimeToUtc() {
        DateTime dateTime = new DateTime(DateTimeZone.forID("Asia/Shanghai"));
        String result = DateUtils.convertDateTimeToUtc(dateTime);
        assertEquals(dateTime.withZone(DateTimeZone.UTC).toString(DATE_PATTERN_DEFAULT), result);
    }
    @Test
    public void testRemoveTZ() {
        String result = DateUtils.removeTZ("2020-08-08T16:00:00Z", DATE_PATTERN_DATETIME);
        assertEquals("2020-08-08 16:00:00", result);
    }
    @Test
    public void testMatchDynamicDateValue() {
        Map<String, String> result = DateUtils.matchDynamicDateValue("+7");
        assertEquals("+", result.get("sign"));
        assertEquals("7", result.get("value"));
        result = DateUtils.matchDynamicDateValue("-3");
        assertEquals("-", result.get("sign"));
        assertEquals("3", result.get("value"));
    }
    @Test
    public void testValidateDate() {
        boolean result = DateUtils.validateDate("2020-08-08", DATE_PATTERN_DATE);
        assertTrue(result);
        result = DateUtils.validateDate("2020-08-08 16:00:00", DATE_PATTERN_DATETIME);
        assertTrue(result);
        result = DateUtils.validateDate("2020-08-08 25:00:00", DATE_PATTERN_DATETIME);
        assertFalse(result);
    }
}
