package com.convertlab.macore.mamgt.utils;


import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;

public class ParserTestCase {
    String testName;
    private final String absolutePath;

    public ParserTestCase(String testName) {
        if (testName.endsWith(".json5")) {
            testName = testName.substring(0, testName.length() - 6);
        }
        this.testName = testName;
        this.absolutePath = getResourceAbsolutePath(getFilterJsonFile());
    }

    private String getFilterJsonFile() {
        return testName + ".json5";
    }

    private String getResultFile() {
        return testName + ".result";
    }

    private String getViewModelFile() {
        return testName + ".viewmodel";
    }

    private String getExceptionFile() { return testName + ".exception"; }

    private String getResultFileAbsolutePath() {
        return concatPath(absolutePath, getResultFile());
    }

    private String getExceptionFileAbsolutePath() {
        return concatPath(absolutePath, getExceptionFile());
    }

    private String getResourceAbsolutePath(String resourceName) {
        if (Files.exists(Paths.get(concatPath(JsonConfigLoader.DEFAULT_CONFIG_DIR, resourceName)))) {
            return JsonConfigLoader.DEFAULT_CONFIG_DIR;
        }
        URL resource = Thread.currentThread().getContextClassLoader().getResource(resourceName);
        if (resource == null) {
            throw new IllegalArgumentException(resourceName + " does not exist");
        }
        String path = resource.getPath();
        return path.substring(0, path.length() - resourceName.length());
    }

    private static String concatPath(String... paths) {
        String joined = String.join("/", paths);
        return Paths.get(joined).normalize().toString();
    }

    public void recordResult(String result) {
        JsonConfigLoader.writeContent(getResultFileAbsolutePath(), result);
    }

    public void recordException(String exception) {
        // Write to .tmp file first, then rename to .exception if this is really a ignorable exception
        // otherwise, on dev's laptop the exception would just throw one time, unless he runs "gradlew clean"
        JsonConfigLoader.writeContent(getExceptionFileAbsolutePath()+".tmp", exception);
    }

    public String getJsonContent() {
        return JsonConfigLoader.readContent(getFilterJsonFile());
    }

    public String getViewModelContent() {
        return JsonConfigLoader.readContent(getViewModelFile());
    }
    public String getResultFilterV4() {
        return JsonConfigLoader.readContent(getResultFile());
    }

    public String getExceptionContent() {
        return JsonConfigLoader.readContent(getExceptionFile());
    }
}
