package com.convertlab.macore.mamgt.cdp.utils;

import com.convertlab.foundation.api.queryengine.FilterV4Dto;
import com.convertlab.macore.mamgt.cdp.profile.common.utils.CdpFilterV4Helper;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Arrays;

@Slf4j
@Tag("UnitTest")
class FilterV4HelperTest {

    @Test
    public void testAddCondition() {
        FilterV4Dto.And and = new FilterV4Dto.And();
        CdpFilterV4Helper.addCondition(and, new FilterV4Dto.Or());
        Assertions.assertNotNull(and.getConditions());
    }


    @Test
    void testNewColumnCondition() {
        FilterV4Dto.CompareOperator compareOperator = CdpFilterV4Helper.newColumnCondition(new FilterV4Dto.In(), "customer.id", null, "1111");
        Assertions.assertNotNull(compareOperator);
        FilterV4Dto.Identifier left = compareOperator.getLeft();
        Assertions.assertNotNull(left);
        FilterV4Dto.Identifier right = compareOperator.getRight();
        Assertions.assertNotNull(right);
    }

    @Test
    void testNewIdentifier() {
        String field = "customer.id";
        FilterV4Dto.Identifier identifier = CdpFilterV4Helper.newIdentifier(FilterV4Dto.IdentifierType.COLUMN, null, field);
        Assertions.assertNotNull(identifier);
        String type = identifier.getType();
        Assertions.assertEquals(FilterV4Dto.IdentifierType.COLUMN.getType(), type);
        String value = identifier.getValue();
        Assertions.assertEquals(value, field);

        FilterV4Dto.Identifier identifier1 = CdpFilterV4Helper.newIdentifier(FilterV4Dto.IdentifierType.VALUE, null, "1111");
        Assertions.assertNotNull(identifier1);
        String type1 = identifier1.getType();
        Assertions.assertEquals(FilterV4Dto.IdentifierType.VALUE.getType(), type1);
        String value1 = identifier1.getValue();
        Assertions.assertEquals(value1, "1111");

        FilterV4Dto.Identifier identifier2 = CdpFilterV4Helper.newIdentifier(FilterV4Dto.IdentifierType.VALUES, null, "1111");
        Assertions.assertNotNull(identifier2);
        String type2 = identifier2.getType();
        Assertions.assertEquals(FilterV4Dto.IdentifierType.VALUES.getType(), type2);
        Assertions.assertNull(identifier2.getValue());
        Assertions.assertEquals(false, CollectionUtils.isEmpty(identifier2.getValues()));
    }

    @Test
    void testCheckLogicalOperatorIsEmpty() {
        Assertions.assertTrue(CdpFilterV4Helper.checkLogicalOperatorIsEmpty(new FilterV4Dto.And()));

        Assertions.assertTrue(CdpFilterV4Helper.checkLogicalOperatorIsEmpty(null));

        FilterV4Dto.And and = new FilterV4Dto.And();
        and.setConditions(new ArrayList<>(Arrays.asList(new FilterV4Dto.In())));
        Assertions.assertFalse(CdpFilterV4Helper.checkLogicalOperatorIsEmpty(and));
    }
}