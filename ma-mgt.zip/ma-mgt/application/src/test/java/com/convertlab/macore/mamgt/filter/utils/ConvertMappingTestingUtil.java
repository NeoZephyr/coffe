package com.convertlab.macore.mamgt.filter.utils;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.io.resource.ResourceUtil;
import cn.hutool.json.JSONUtil;
import com.convertlab.macore.mamgt.filter.filters.model.mapping.ConvertMapping;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import static com.convertlab.macore.mamgt.filter.constants.Constants.FIELD_MAPPING_SPLIT;
import static com.convertlab.macore.mamgt.filter.constants.Constants.IDENTITY_TABLE;

public class ConvertMappingTestingUtil {
    private static ConvertMapping convertMapping = new ConvertMapping();

    private static Map<String, Map<String, String>> fieldMappings = new ConcurrentHashMap<>();

    private static Map<String, String> entityMappings = new ConcurrentHashMap<>();

    static {
        convertMapping = JSONUtil.toBean(ResourceUtil.readUtf8Str("filter/filter-convert-mapping.json"), ConvertMapping.class);
        initializeFieldMappingToMap();
        initializeOtherFieldMappingToMap();
        initializeEntityMappingToMap();
    }

    public static Map<String, Map<String, String>> getFieldMappings() {
        return fieldMappings;
    }

    public static Map<String, String> getEntityMappings() {
        return entityMappings;
    }

    public static List<Map<String,Object>> getAdditionalConditions() {
        return convertMapping.getAdditionalConditions();
    }

    public static ConvertMapping getConvertMapping() {
        return convertMapping;
    }

    private static void initializeEntityMappingToMap(){
        entityMappings =
                convertMapping.getEntity().getEntityMappings().stream()
                        .filter(mapping -> mapping.getToEntities() == null)
                        .map(mapping -> new AbstractMap.SimpleEntry<>(mapping.getFromEntity(), mapping.getToEntity()))
                        .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    private static void initializeFieldMappingToMap() {
        fieldMappings = convertMapping.getEntity().getEntityMappings().stream()
                .filter(entityMapping -> CollectionUtil.isNotEmpty(entityMapping.getToEntities()))
                .flatMap(mapping -> mapping.getToEntities().stream()
                        .flatMap(toEntity -> toEntity.getMappings().stream()
                                .filter(mapping1 -> !mapping1.getFromField().equals("*"))
                                .map(mapping1 -> {
                                    String fromEntityField = mapping.getFromEntity() + "." + mapping1.getFromField();
                                    Map<String, String> toFieldsMap = new HashMap<>();
                                    toFieldsMap.put("toType", mapping1.getToType());
                                    toFieldsMap.put("fieldType", mapping1.getFieldType());
                                    if (toEntity.getType().equals("entity")) {
                                        toFieldsMap.put("toField", toEntity.getEntity() + "." + mapping1.getToField());
                                    } else {
                                        toFieldsMap.put("toField", mapping1.getExpr());
                                    }
                                    return new AbstractMap.SimpleEntry<>(fromEntityField, toFieldsMap);
                                })
                        )
                )
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (oldValue, newValue) -> oldValue));
    }

    private static void initializeOtherFieldMappingToMap() {
        convertMapping.getEntity().getEntityMappings().stream()
                .filter(entityMapping -> CollectionUtil.isNotEmpty(entityMapping.getToEntities()))
                .flatMap(mapping -> mapping.getToEntities().stream()
                        .filter(toEntity -> toEntity.getType().equals("entity"))
                        .flatMap(toEntity -> toEntity.getMappings().stream()
                                .filter(mapping1 -> mapping1.getFromField().equals("*"))
                                .map(mapping1 -> {
                                    String fromEntityField = mapping.getFromEntity() + "." + mapping1.getFromField();
                                    String[] toFields = toEntity.getMappings().stream()
                                            .filter(mapping2 -> mapping2.getFromField().equals("*"))
                                            .map(mapping2 -> {
                                                String result = toEntity.getEntity() != null ? toEntity.getEntity() + "." + mapping2.getToField() : mapping2.getExpr();
                                                String toType = mapping2.getToType();
                                                if(Objects.nonNull(toType)
                                                        && !toType.isEmpty()){
                                                    result += "," + toType;
                                                }
                                                return result;
                                            })
                                            .toArray(String[]::new);
                                    return new AbstractMap.SimpleEntry<>(fromEntityField, toFields);
                                })
                        )
                )
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (oldValue, newValue) -> oldValue))
                .forEach((key, value) -> {
                    if (key.endsWith(".*")) {
                        String entity = "";
                        entity  = key.substring(0, key.length() - 2);
                        if(IDENTITY_TABLE.equals(entity)){
                            String toField = Arrays.stream(value).collect(Collectors.joining(FIELD_MAPPING_SPLIT));
                            Map<String, String> toResult = Collections.singletonMap("toField", toField);
                            fieldMappings.put(entity + ".*", toResult);
                        }else{
                            Map<String, String> toResult = new HashMap<>();
                            String toField = "", toType = "";

                            List<String> toFields = Arrays.stream(value).collect(Collectors.toList());
                            for (String ele :
                                    toFields) {
                                String[] split = ele.split(",");
                                if(toField.isEmpty()){
                                    toField = split[0];
                                }else{
                                    toField += FIELD_MAPPING_SPLIT + split[0];
                                }

                                if(split.length >= 2 && toType.isEmpty()){
                                    toType = split[1];
                                }
                            }
                            toResult.put("toField", toField);
                            toResult.put("toType",  toType);
                            fieldMappings.put(entity + ".*", toResult);
                        }
                    }
                });
    }
}
