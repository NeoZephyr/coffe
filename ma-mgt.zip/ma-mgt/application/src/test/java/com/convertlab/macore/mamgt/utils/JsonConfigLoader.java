package com.convertlab.macore.mamgt.utils;

import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.convertlab.foundation.library.utils.JsonUtils;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;

import static com.fasterxml.jackson.core.JsonParser.Feature.*;
import static com.fasterxml.jackson.core.json.JsonReadFeature.ALLOW_JAVA_COMMENTS;

@Slf4j
public class JsonConfigLoader {
    public static final String DEFAULT_CONFIG_DIR = "/tmp";
    private static final ObjectMapper json5Mapper = JsonMapper
            .builder().enable(JsonReadFeature.ALLOW_JAVA_COMMENTS)
            .enable(JsonReadFeature.ALLOW_UNQUOTED_FIELD_NAMES)
            .enable(JsonReadFeature.ALLOW_TRAILING_COMMA)
            .enable(JsonReadFeature.ALLOW_SINGLE_QUOTES)
            .enable(JsonReadFeature.ALLOW_BACKSLASH_ESCAPING_ANY_CHARACTER)
            .enable(JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS)
            .enable(JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS)
            .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
            .build()
            .registerModule(new ParameterNamesModule())
            .registerModule(new Jdk8Module())
            .registerModule(new JavaTimeModule());

    public static <T> T config2Obj(String configName, Class<T> clazz) {
        return config2Obj(DEFAULT_CONFIG_DIR, configName, clazz);
    }

    public static Map<String, Object> config2ObjWithFilter(String configName, List<String> fields){
        Map<String, Object> data = config2Obj(DEFAULT_CONFIG_DIR, configName, Map.class);
        data = data.entrySet().stream().filter(x -> fields.contains(x.getKey()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        return data;
    }

    public static <T> List<T> config2List(String configName, Class<T> clazz) {
        return config2List(DEFAULT_CONFIG_DIR, configName, clazz);
    }

    public static <T> List<T> config2List(String configFolder, String configName, Class<T> clazz) {
        try {
            String content = readContent(configFolder, configName);
            final List<T> ts = JsonUtils.instance().json2List(content, clazz);
            return ts;
        } catch (Exception e) {
            return Lists.newArrayList();
        }
    }

    public static <T> T config2Obj(String configFolder, String configName, Class<T> clazz) {
        try {
            String content = readContent(configFolder, configName);
            return JsonUtils.instanceOfDto().json2Obj(content, clazz);
        } catch (Exception e) {
            log.error("failed to load json " + configName, e);
            return null;
        }
    }

    public static <T> T config2Obj(String configName, TypeReference<T> valueTypeRef) {
        return config2Obj(DEFAULT_CONFIG_DIR, configName, valueTypeRef);
    }

    public static <T> T config2Obj(String configFolder, String configName, TypeReference<T> valueTypeRef) {
        try {
            String content = readContent(configFolder, configName);
            return json5Mapper.readValue(content, valueTypeRef);
        } catch (Exception e) {
            log.error("failed to load json " + configName, e);
            return null;
        }
    }


    public static Map convertJson5ToJson(String json5){
        try {
            Map jsonObject = json5Mapper.readValue(json5, Map.class);
            return jsonObject;
        }catch (Exception e){
            return null;
        }
    }


    public static String readContent(String configName) {
        return readContent(DEFAULT_CONFIG_DIR, configName);
    }

    public static String readContent(String configFolder, String configName) {
        String content = null;
        try (InputStream is = new FileInputStream(configFolder.concat(configName))) {
            content = IOUtils.toString(is, StandardCharsets.UTF_8);
        } catch (Exception e) {
            try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(configName)) {
                if (is != null) {
                    content = IOUtils.toString(is, StandardCharsets.UTF_8);
                }
            } catch (Exception e1) {
                log.warn("no config file found for " + configName);
                return "";
            }
        }
        if (StringUtils.isBlank(content)) {
            return content;
        }
        return content.replaceAll("\r\n", "");
    }

    public static void writeContent(String fileAbsolutePath, String content) {
        try {
            log.info("write file to " + fileAbsolutePath);
            Files.write(
                    Paths.get(fileAbsolutePath),
                    content.getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception e) {
            log.warn("failed to write file " + fileAbsolutePath);
        }
    }
}
