package com.convertlab.macore.mamgt.cdp.utils;

import com.convertlab.foundation.library.gdmmeta.client.GsMetaClientWrapper;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.macore.mamgt.cdp.profile.common.utils.ColumnMappingUtil;
import com.convertlab.macore.mamgt.cdp.dto.Trait;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.GeneralProfileBizMeta;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.PrimaryProfileBizMeta;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.ProfileBizMeta;
import com.convertlab.macore.mamgt.cdp.meta.service.ProfileMetaService;
import com.convertlab.macore.mamgt.cdp.profile.service.TraitService;
import com.convertlab.macore.mamgt.gdm.LazyGdmRegistry;
import com.convertlab.macore.mamgt.utils.JsonConfigLoader;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Collections;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class ColumnMappingUtilTest {
    private static LazyGdmRegistry lazyGdmRegistry;
    private static ProfileBizMeta cCarProfileBizMeta;
    private static ProfileBizMeta customerProfileBizMeta;

    @Mock(lenient = true)
    private GsMetaClientWrapper mockGsMetaClient;

    @Mock(lenient = true)
    private ProfileMetaService mockProfileMetaService;

    @Mock(lenient = true)
    private TraitService traitService;

    private GdmEntity customerEntity;

    private GdmEntity cCarEntity;
    private GdmEntity memberEntity;


    @BeforeAll
    static void beforeAll() throws IOException, URISyntaxException {
        lazyGdmRegistry = new LazyGdmRegistry("/gdm/entities/gdmEntities.json");
        cCarProfileBizMeta = JsonConfigLoader.config2Obj("cdp/ProfileServiceImpl/c_car_profile_biz_meta.json", GeneralProfileBizMeta.class);
        customerProfileBizMeta = JsonConfigLoader.config2Obj("cdp/ProfileServiceImpl/primary_profile_biz_meta.json", PrimaryProfileBizMeta.class);
    }

    @BeforeEach
    void setUp() {
        customerEntity = lazyGdmRegistry.getEntity("customer");
        cCarEntity = lazyGdmRegistry.getEntity("c_car");
        memberEntity = lazyGdmRegistry.getEntity("member");
        Mockito.lenient().when(mockGsMetaClient.getEntity("customer")).thenReturn(customerEntity);
        Mockito.lenient().when(mockGsMetaClient.getEntity("c_car")).thenReturn(cCarEntity);
        Mockito.lenient().when(mockGsMetaClient.getEntity("member")).thenReturn(memberEntity);
        Mockito.lenient().when(mockProfileMetaService.getProfileBizMeta(eq("customer"), any())).thenReturn(customerProfileBizMeta);
        Mockito.lenient().when(mockProfileMetaService.getProfileBizMeta(eq("c_car"), any())).thenReturn(cCarProfileBizMeta);
    }

    @Test
    void testMatchesOldCustomerAttribute() {
        String customerProp = ColumnMappingUtil.matchesOldCustomerAttribute("id", mockProfileMetaService, mockGsMetaClient);
        Assertions.assertEquals("customer.id", customerProp);

        // 测试系统属性带大小写的情况,GDM中转为下划线case
        String customerPropWithUpperCase = ColumnMappingUtil.matchesOldCustomerAttribute("homeAddress", mockProfileMetaService, mockGsMetaClient);
        Assertions.assertEquals("customer.home_address", customerPropWithUpperCase);

        String customerPropWithAttr = ColumnMappingUtil.matchesOldCustomerAttribute("attr.attr34", mockProfileMetaService, mockGsMetaClient);
        Assertions.assertEquals("customer.attr34", customerPropWithAttr);

        // 匹配不上新客户属性格式
        String newFormat1 =  ColumnMappingUtil.matchesOldCustomerAttribute("customer.attr34", mockProfileMetaService, mockGsMetaClient);
        Assertions.assertNull(newFormat1);

        // 匹配不上非客户属性
        String newFormat2 = ColumnMappingUtil.matchesOldCustomerAttribute("attr.attr1.R.udo.c_xinbailu.mobile", mockProfileMetaService, mockGsMetaClient);
        Assertions.assertNull(newFormat2);
    }

    @Test
    void testMatchesNewCustomerAttribute() {
        String customerProp = ColumnMappingUtil.matchesNewCustomerAttribute("customer.id", mockProfileMetaService, mockGsMetaClient);
        Assertions.assertEquals("customer.id", customerProp);

        // 测试系统属性带大小写的情况,GDM中转为下划线case
        String customerPropWithUpperCase = ColumnMappingUtil.matchesNewCustomerAttribute("customer.homeAddress", mockProfileMetaService, mockGsMetaClient);
        Assertions.assertEquals("customer.home_address", customerPropWithUpperCase);

        String customerPropWithAttr = ColumnMappingUtil.matchesNewCustomerAttribute("customer.attr34", mockProfileMetaService, mockGsMetaClient);
        Assertions.assertEquals("customer.attr34", customerPropWithAttr);

        // 匹配不上udo属性
        String newFormat1 = ColumnMappingUtil.matchesNewCustomerAttribute("c_book.c_publisher", mockProfileMetaService, mockGsMetaClient);
        Assertions.assertNull(newFormat1);

        // 匹配不上查找关系
        String newFormat2 = ColumnMappingUtil.matchesNewCustomerAttribute("customer.attr1.name", mockProfileMetaService, mockGsMetaClient);
        Assertions.assertNull(newFormat2);
    }

    @Test
    void testMatchesOldProfileRelationToProfile() {
        // 客户属性关联到UDO
        String relation1 = ColumnMappingUtil.matchesOldProfileRelationToProfile("attr.attr1.R.udo.c_xinbailu.mobile", mockGsMetaClient, "customer", Collections.emptyList());
        Assertions.assertEquals("customer.attr1.mobile", relation1);

        // 客户属性关联到UDO
        String relation5 = ColumnMappingUtil.matchesOldProfileRelationToProfile("attr.attr1.R.udo.c_car.t6", mockGsMetaClient, "customer", Collections.emptyList());
        Assertions.assertEquals("customer.attr1.c_fsdfsdf", relation5);

        // UDO 的属性关联到客户扩展属性
        String relation2 = ColumnMappingUtil.matchesOldProfileRelationToProfile("udo.c_xinbailu.c_sdf.R.attr.attr3", mockGsMetaClient, "customer", Collections.emptyList());
        Assertions.assertEquals("c_xinbailu.c_sdf.attr3", relation2);

        // UDO 的属性关联到客户系统属性
        String relation3 = ColumnMappingUtil.matchesOldProfileRelationToProfile("udo.c_xinbailu.c_sdf.R.source", mockGsMetaClient, "customer", Collections.emptyList());
        Assertions.assertEquals("c_xinbailu.c_sdf.source", relation3);

        // UDO 的属性关联到UDO
        String relation4 = ColumnMappingUtil.matchesOldProfileRelationToProfile("udo.c_xinbailu.c_leads.R.udo.c_sys_sales_leads.c_channel", mockGsMetaClient, "customer", Collections.emptyList());
        Assertions.assertEquals("c_xinbailu.c_leads.c_channel", relation4);
    }

    @Test
    void testMatchesOldIdentityType() {
        String identity = ColumnMappingUtil.matchesOldIdentityType("identity.mobile");
        Assertions.assertEquals("customer.identity[mobile]", identity);

        String newIdentity = ColumnMappingUtil.matchesOldIdentityType("customer.identity[mobile].value");
        Assertions.assertNull(newIdentity);
    }

    @Test
    void testMatchesOldCustomerValueTag() {
        String valueTag = ColumnMappingUtil.matchesOldCustomerValueTag("value_tag.vt1544797275849596928");
        Assertions.assertEquals("customer.tag[1544797275849596928].value", valueTag);
    }


    @Test
    void testMatchesOldUdoValueTag() {
        String valueTag = ColumnMappingUtil.matchesOldUdoValueTag("udo.c_book.value_tag.vt1544797275849596928");
        Assertions.assertEquals("c_book.tag[1544797275849596928].value", valueTag);
    }

    @Test
    void testMatchesOldMemberProp(){
        String memberProp = ColumnMappingUtil.matchesOldMemberProp("membership.campaignId");
        Assertions.assertEquals("customer.member.campaign_id", memberProp);

        String memberProp2 = ColumnMappingUtil.matchesOldMemberProp("membership.c_s2414");
        Assertions.assertEquals("customer.member.c_s2414", memberProp2);
    }

    @Test
    void testMatchesOldUdoProperty(){
        String udoProp = ColumnMappingUtil.matchesOldUdoProperty("udo.c_car.c_nameAndId", mockGsMetaClient);
        Assertions.assertEquals("c_car.c_nameandid", udoProp);

        String udoProp2 = ColumnMappingUtil.matchesOldUdoProperty("udo.c_car.t4", mockGsMetaClient);
        Assertions.assertEquals("c_car.c_nameandid", udoProp2);

    }

    @Test
    void testMatchesNewUdoProperty(){
        String udoProp = ColumnMappingUtil.matchesNewUdoProperty("c_car.c_nameAndId", mockGsMetaClient);
        Assertions.assertEquals("c_car.c_nameandid", udoProp);
    }

    @Test
    void testMatchesOldUdoAndCustomerValueTagRelation() {
        // setup
        Trait customerTrait = new Trait();
        customerTrait.setRefFieldId("bk");
        customerTrait.setRefObjId("c_car");
        customerTrait.setLabelId("c_test_find_rel");
        when(traitService.findById(eq("customer"), eq("1557339004976857088"), eq(false))).thenReturn(customerTrait);

        Trait cXXNTestTrait = new Trait();
        cXXNTestTrait.setRefFieldId("id");
        cXXNTestTrait.setRefObjId("customer");
        cXXNTestTrait.setLabelId("c_kehu");
        when(traitService.findById(eq("c_xxn_test"), eq("1557339004976857088"), eq(false))).thenReturn(cXXNTestTrait);

        String udoTagRelation = ColumnMappingUtil.matchesOldUdoAndCustomerValueTagRelation("udo.c_xxn_test.value_tag.vt1557339004976857088.R.name",
                mockGsMetaClient, traitService);
        Assertions.assertEquals("c_xxn_test.tag[1557339004976857088].customer.name", udoTagRelation);

        String customerTagRelation = ColumnMappingUtil.matchesOldUdoAndCustomerValueTagRelation("value_tag.vt1557339004976857088.R.t6",
                mockGsMetaClient, traitService);
        Assertions.assertEquals("customer.tag[1557339004976857088].c_car.c_fsdfsdf", customerTagRelation);

    }

    @Test
    void testMatchesOldMemberProp2(){
        String udoProp = ColumnMappingUtil.matchesOldMemberProp("customer.member.attr38", mockGsMetaClient);
        Assertions.assertEquals("customer.member.c_04197684", udoProp);
    }
}
