package com.convertlab.macore.mamgt.filter.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.stream.Collectors;

import cn.hutool.core.io.resource.ResourceUtil;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.mamgt.filter.filters.config.FilterV4ConvertHandlerContainer;
import com.convertlab.macore.mamgt.filter.filters.convert.handler.IConvertHandler;
import com.convertlab.macore.mamgt.filter.enums.ConvertTypeEnum;
import com.convertlab.macore.mamgt.filter.enums.IdentifierTypeEnum;
import com.convertlab.macore.mamgt.filter.filters.service.FilterMetaService;
import com.convertlab.macore.mamgt.filter.filters.service.GroupService;
import com.convertlab.macore.mamgt.filter.model.filterV4.Identifier;
import com.convertlab.macore.mamgt.filter.model.filterV4.Where;
import com.convertlab.macore.mamgt.filter.filters.model.dto.function.FunctionBody;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.mockito.Mockito.when;

@Slf4j
class FilterV4ConvertHandlerContainerTest {

    @Test
    @DisplayName("开发测试框架的测试")
    void dummyTest() {
        // mock uiMetaService
        GroupService groupService = Mockito.mock(GroupService.class);
        FilterMetaService metaService = Mockito.mock(FilterMetaService.class);
        List<FunctionBody> metaFunctions = JsonUtils.instanceOfDto().json2List(ResourceUtil.readUtf8Str("meta/meta-function.json"), FunctionBody.class);
        when(metaService.getMetaFunctionMap()).thenReturn(metaFunctions.stream().collect(Collectors.toMap(FunctionBody::getName, metaFunction -> metaFunction)));

        FilterV4ConvertHandlerContainer container = new FilterV4ConvertHandlerContainer(groupService, metaService);
        IConvertHandler convertHandler = container.getInstance(ConvertTypeEnum.EXPR);
        log.info(" {} ", convertHandler);
        Where.Equal e = new Where.Equal();
        e.setLeft(new Identifier(IdentifierTypeEnum.COLUMN.getType(),"a","a"));
        e.setRight(new Identifier("expr","a","a"));
        ListIterator<Where.CompareOperator> listIterator = (new ArrayList<Where.CompareOperator>()).listIterator();
        HashMap<String, Object> compareOperatorMap = new HashMap<>();
        convertHandler.convert(e, compareOperatorMap, listIterator);
        log.info(" {} ", JsonUtils.instance().obj2Json(e, true));
        log.info("{}",JsonUtils.instance().obj2Json(compareOperatorMap, true));
    }
}