package com.convertlab.macore.mamgt.filter.utils;

import com.convertlab.macore.mamgt.common.utils.NamingUtils;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * All rights Reserved, Designed By ConvertLab
 * Author: zhiping.cai
 * Date: 2023/5/25
 * Description:
 * Copyright (C) 2022 www.convertlab.com
 */
@Tag("NamingUtilsUnitTest")
public class NamingUtilsTest {

    @Test
    public void testToUnderScoreCaseWithValidInput() {
        String inputName = "someInputName";
        String expectedOutput = "some_input_name";
        String actualOutput = NamingUtils.toUnderScoreCase(inputName);
        assertEquals(expectedOutput, actualOutput);
    }

    @Test
    public void testToUnderScoreCaseWithValidInputStartingWithC_() {
        String inputName = "c_someInputName";
        String expectedOutput = "c_someInputName";
        String actualOutput = NamingUtils.toUnderScoreCase(inputName);
        assertEquals(expectedOutput, actualOutput);
    }

    @Test
    public void testToUnderScoreCaseWithValidInputStartingWithCp_() {
        String inputName = "cp_someInputName";
        String expectedOutput = "cp_someInputName";
        String actualOutput = NamingUtils.toUnderScoreCase(inputName);
        assertEquals(expectedOutput, actualOutput);
    }

    @Test
    public void testToUnderScoreCaseWithValidInputContainingPeriod() {
        String inputName = "some.input.name";
        String expectedOutput = "some.input.name";
        String actualOutput = NamingUtils.toUnderScoreCase(inputName);
        assertEquals(expectedOutput, actualOutput);
    }

    @Test
    public void testToUnderScoreCaseWithValidInputAlreadyInUnderScoreCase() {
        String inputName = "some_input_name";
        String expectedOutput = "some_input_name";
        String actualOutput = NamingUtils.toUnderScoreCase(inputName);
        assertEquals(expectedOutput, actualOutput);
    }

    @Test
    public void testTBD() {
        assertEquals("c_car", NamingUtils.convertInvalidBOToValidEntity("c_car"));
        assertEquals("C_CAR", NamingUtils.convertInvalidBOToValidEntity("C_CAR"));
        assertEquals("cCar", NamingUtils.convertInvalidBOToValidEntity("cCar"));
        assertEquals("c_car", NamingUtils.convertInvalidBOToValidEntity("c__car"));
        assertEquals("c_car", NamingUtils.convertInvalidBOToValidEntity("c_______car"));
        assertEquals("c_car", NamingUtils.convertInvalidBOToValidEntity("c car"));
        assertEquals("c_car", NamingUtils.convertInvalidBOToValidEntity("c       car"));
        assertEquals("c_car", NamingUtils.convertInvalidBOToValidEntity("c-car"));
        assertEquals("c_car", NamingUtils.convertInvalidBOToValidEntity("c- _ -car"));
    }
}
