package com.convertlab.macore.mamgt.filter.convert;

import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.mamgt.filter.model.filterV4.Identifier;
import com.convertlab.macore.mamgt.filter.model.filterV4.Where;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@Slf4j
@Tag("UnitTest")
class FilterV4ConvertTest {

    @Test
    public void testBuildNewV4Condition() {
        // Create a Where.Equal object and serialize it to a json file.
        Where.CompareOperator equal = new Where.Equal();
        equal.setLeft(new Identifier("a", "b"));
        equal.setRight(new Identifier("c", "d"));
        log.info("Equal: {}", equal);
        // serialize equal to json file
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            String json = objectMapper.writeValueAsString(equal);
            log.info("Equal json: {}", json);
            Where.Equal e = JsonUtils.instanceOfDto().json2Obj(json, Where.Equal.class);
            log.info("Equal: {}", e);
        } catch (Exception e) {
            log.error("Error: {}", e);
        }

    }


    @Test
    void removeOldCondition() {
    }

    @Test
    void addSinceIdCondition() {
    }
}