package com.convertlab.macore.mamgt.gdm;

import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.ImmutableGdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationship;
import com.convertlab.foundation.library.gdmmeta.model.relationship.ImmutableGdmOneToManyGdmRelationship;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.net.URISyntaxException;

@Slf4j
public class TestLazyGdmRegistry {
    LazyGdmRegistry lazyGdmRegistry;

    @BeforeEach
    void setup() throws IOException, URISyntaxException {
        lazyGdmRegistry = new LazyGdmRegistry("/gdm/entities/gdmEntities.json");
    }

    @Test
    void testOnDemandLoadEntityAndRelationship() {
        GdmEntity customer = lazyGdmRegistry.getEntity("customer");
        Assertions.assertEquals(ImmutableGdmEntity.class, customer.getClass());
        Assertions.assertEquals("customer", customer.getEntityName());
    }
}
