package com.convertlab.macore.mamgt.fvvm.service;

import com.convertlab.macore.mamgt.cdp.dto.Segment;
import com.convertlab.macore.mamgt.cdp.profile.service.SegmentService;
import com.convertlab.macore.mamgt.filter.filters.model.GdmSqlResponse;
import com.convertlab.macore.mamgt.filter.model.filterV4.FilterV4;
import com.convertlab.macore.mamgt.filter.model.filterV4.Select;
import com.convertlab.macore.mamgt.filter.model.filterv2.Filters;
import com.convertlab.macore.mamgt.filter.model.filterv2.Preview;
import com.convertlab.macore.mamgt.filter.service.FilterV4Service;
import com.convertlab.macore.mamgt.misc.testingutil.service.FilterV4ViewModelConsumerService;
import com.convertlab.test.BaseTest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.support.serializer.JsonSerializer;

import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;


@ExtendWith(MockitoExtension.class)
class FilterV4ViewModelConsumerServiceTest extends BaseTest {
    @Mock
    FilterV4ViewModelConsumerService filterV4ViewModelConsumerService;
    @Mock
    SegmentService segmentService;
    @Mock
    FilterV4Service filterV4ServiceImpl;
    @Value("${queryEngineServer.serverUrl}")
    String queryEngineServerUrl;

    ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() throws JsonProcessingException {
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        Segment segment = new Segment();
        segment.setFilters("{\"logicalOperator\":\"and\",\"subFilters\":[{\"conditions\":[{\"category\":\"customer\",\"constraint\":{},\"description\":{\"constraint\":{\"descArr\":[],\"descStr\":\"\"},\"property\":\"客户属性-姓名\",\"value\":\"等于其中之一Auto直饰陨,Auto锑漓苑\"},\"parameter\":{\"operator\":\"one_of\",\"values\":[\"Auto直饰陨\",\"Auto锑漓苑\"]},\"property\":\"name\",\"property_type\":\"Text\",\"to_string\":\"客户属性-姓名 → 等于其中之一Auto直饰陨,Auto锑漓苑\"}],\"logicalOperator\":\"and\"}],\"v4\":{\"table\":\"customer\",\"version\":4,\"where\":{\"logicalOp\":{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"in\":{\"category\":\"customer\",\"extraParams\":{\"category\":\"customer\",\"conditionPropertyType\":\"Text\"},\"left\":{\"type\":\"COLUMN\",\"value\":\"name\"},\"right\":{\"type\":\"VALUES\",\"values\":[\"Auto直饰陨\",\"Auto锑漓苑\"]}}}]}}]}}]}}}},\"version\":2}");
        segment.setId(123L);
        Mockito.lenient()
                .when(segmentService.findById("customer", "123"))
                .thenReturn(segment);
        GdmSqlResponse gdmSqlResponse = new GdmSqlResponse(null, null, null, null, "SELECT customer.id FROM ( SELECT CAST(id AS BIGINT) AS id, name AS name FROM v_customer WHERE v_customer.tenant_id = 1 ) customer WHERE customer.name IN ('Auto直饰陨', 'Auto锑漓苑') ORDER BY id DESC");
        filterV4ViewModelConsumerService = new FilterV4ViewModelConsumerService(any(), segmentService, any(), filterV4ServiceImpl);
        filterV4ViewModelConsumerService.setObjectMapper(objectMapper);
    }

    @Test
    @DisplayName("buildPreview test")
    void buildPreview() throws JsonProcessingException {
        String filtersJson = "{\"logicalOperator\":\"and\",\"subFilters\":[{\"conditions\":[{\"category\":\"customer\",\"constraint\":{},\"description\":{\"constraint\":{\"descArr\":[],\"descStr\":\"\"},\"property\":\"客户属性-姓名\",\"value\":\"等于其中之一Auto直饰陨,Auto锑漓苑\"},\"parameter\":{\"operator\":\"one_of\",\"values\":[\"Auto直饰陨\",\"Auto锑漓苑\"]},\"property\":\"name\",\"property_type\":\"Text\",\"to_string\":\"客户属性-姓名 → 等于其中之一Auto直饰陨,Auto锑漓苑\"}],\"logicalOperator\":\"and\"}],\"v4\":{\"table\":\"customer\",\"version\":4,\"where\":{\"logicalOp\":{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"in\":{\"category\":\"customer\",\"extraParams\":{\"category\":\"customer\",\"conditionPropertyType\":\"Text\"},\"left\":{\"type\":\"COLUMN\",\"value\":\"name\"},\"right\":{\"type\":\"VALUES\",\"values\":[\"Auto直饰陨\",\"Auto锑漓苑\"]}}}]}}]}}]}}}},\"version\":2}";
        Filters<FilterV4> filters = objectMapper.readValue(filtersJson, Filters.class);
        FilterV4 filterV4 = objectMapper.convertValue(filters.getV4(), FilterV4.class);
        List<Select> selectList = new ArrayList<>();
        selectList.add(new Select("COLUMN", "id", "customer_id"));
        Preview<FilterV4> preview = new Preview<>();
        filterV4.setSelect(selectList);
        filters.setV4(filterV4);
        preview.setFilters(filters);
        Preview<FilterV4> actualPreview = filterV4ViewModelConsumerService.buildPreview("123");
        FilterV4 previewFiltersV4 = preview.getFilters().getV4();
        FilterV4 actualPreviewFiltersV4 = actualPreview.getFilters().getV4();
        preview.setFilters(null);
        actualPreview.setFilters(null);
        Assertions.assertEquals(preview, actualPreview);
        List<Select> previewFiltersV4Select = previewFiltersV4.getSelect();
        List<Select> actualPreviewFiltersV4Select = actualPreviewFiltersV4.getSelect();
        List<Select> list = new ArrayList<>();
        previewFiltersV4.setSelect(list);
        actualPreviewFiltersV4.setSelect(list);
        Assertions.assertEquals(previewFiltersV4.toString(), actualPreviewFiltersV4.toString());
        Assertions.assertEquals(previewFiltersV4Select.size(), actualPreviewFiltersV4Select.size());
    }

    @DisplayName("整体性测试，模拟上游生产者")
    public static void main(String[] args) {
        Properties properties = new Properties();
        // 指定key和消息体value的编码方式
        properties.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        properties.put("value.serializer", JsonSerializer.class);
        properties.put("bootstrap.servers", "localhost:9092");
        KafkaProducer<String, Object> kafkaProducer = new KafkaProducer<>(properties);
//        String message = "{\"deleteListMemberTopic\":\"delete_list_member\",\"upstream\":\"spark_tagging_single\",\"featureInfo\":{},\"dataJobParam\":{\"jobId\":null,\"batchNo\":\"20230327021108dc9__gid_segment_recompute-1-1473776660343011328\",\"jobNo\":\"segment_recompute-1-1473776660343011328\",\"tenantId\":1,\"triggerParam\":\"{\\\"tenantId\\\":1,\\\"segmentId\\\":1473776660343011328}\"},\"addListMemberTopic\":\"add_list_member\",\"type\":\"list\",\"definitionType\":\"dynamic\",\"sql\":\"SELECT c.id AS customer_id FROM customer AS c WHERE c.tenant_id = 1 and  c.name = 'Auto岩籍石' \",\"joinListEventTopic\":\"join_list_event\",\"updateTopic\":\"list_or_tag_customer_count_update\",\"requestId\":\"5108a55a500e4aed8e818adab2be0756\",\"suKey\":\"su1\",\"name\":\"Auto智能群组唤尿菱\",\"tenantId\":1,\"topic\":\"trait_segment_callback_message\",\"needRefresh\":true,\"taskId\":1890686,\"definitionId\":1474537840527491072,\"status\":\"success\"}";
        Map<String, Object> message = new HashMap<>();
        List<String> ids = Arrays.asList("1", "test", "A100", "123", "456", "789");
        String tenantId = "1";
        String requestId = "1234567";
        message.put("tenantId", tenantId);
        message.put("segmentId", "1459512391128815616");
        message.put("timestamp", System.currentTimeMillis());
        message.put("profileName", "c_buyer");
        message.put("ids", ids);
        message.put("requestId", requestId);
        String messageKey = String.format("%s-%s-%s-maMgt", tenantId, "c_buyer", "1459512391128815616");
//        String topic = "udo_add_list_member";
        String topic = "udo_delete_list_member";
        kafkaProducer.send(new ProducerRecord<>(topic, messageKey, message));
        kafkaProducer.flush();
    }
}