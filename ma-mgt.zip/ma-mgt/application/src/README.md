# 简单入门指南
这是一个Spring Boot项目，支持本地运行测试。 主笔是Copilot，其他人可以补充。

这个服务是[部署结构图](https://confluence.xiaoshu.biz/pages/viewpage.action?pageId=139831832#id-%E6%9E%B6%E6%9E%84%E5%9B%BEMasterBranch-GDM%E9%87%8D%E6%9E%84)
中的Foundation Service，主要负责meta data管理，query engine，以及其他一些基础功能。

 
## 配置
1. 环境相关的配置项都放在`env.yml`中，这样可以方便的在不同环境中切换。具体怎么做，看`env-example.yml`。
2. 项目的主配置文件是`application.yml`, 但是环境参数等不应该放在这里，因为这个文件会被checkin到仓库。
3. test的配置文件是`application-test.yml`(暂时没有checkin到仓库，需要的话自己建)。
## 运行
在配置好了`env.yml`之后，在foundation根目录中运行`./gradlew :application:bootRun` 可以启动项目。

## 测试
在foundation根目录中运行`./gradlew :application:test` 可以运行单元测试。

在foundation根目录中运行`./gradlew :application:integrationTest` 可以运行集成测试，需要配置`env.yml`。

## 开发
1. 项目的主要代码在`application/src/main/java`中，测试代码在`application/src/test/java`中, 集成测试代码在`application/src/integration-test/java`中。
2. 项目的主要配置文件是`application/src/main/resources/application.yml` 
   1. 在checkin代码前确认:有没有需要暴露给QA/DevOps/etc等角色的配置项。
   2. 这些配置项都重构到`application/src/main/resources/env.yml`中。
   3. 将暴露的配置项添加到`application/src/main/resources/env-example.yml`。

## 工具
1. 如果你本地有Docker, `./build-for-dev.sh -g` 可以编译jar包和docker镜像。
## 你要的信息不在这里
你来补充这个README.md吧，让别人知道怎么用这个项目。
