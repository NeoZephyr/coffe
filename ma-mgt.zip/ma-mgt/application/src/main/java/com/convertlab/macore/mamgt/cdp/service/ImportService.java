package com.convertlab.macore.mamgt.cdp.service;

import com.convertlab.macore.mamgt.cdp.ImportQuery;

import java.util.List;
import java.util.Map;

/**
 * @author Mr.黄
 * @description 原/apiv2/triggerUdoImport接口和/apiv2/triggerUdoTagImport
 * @since 2023/11/10 18:55
 **/
public interface ImportService {
    /**
     * 原/apiv2/triggerUdoImport
     *
     * @param profileName        profileName
     * @param request            ProfileImportRequest
     * @param jarName            jarName
     * @author Mr.黄
     * @since 2023/11/13
     */
    void profileImport(String profileName, ImportQuery.ProfileImportRequest request, String jarName, boolean isEtl, boolean triggerJoinListEvent);

    /**
     * 原/apiv2/triggerUdoTagImport
     *
     * @param profileName profileName
     * @param request     TraitImportRequest
     * @param jarName     jarName
     * @author Mr.黄
     * @since 2023/11/13
     */
    Map<String, List<ImportQuery.TraitImportRequest.TraitDefinition>> traitImport(String profileName, ImportQuery.TraitImportRequest request, String jarName);

    /**
     * 原/apiv2/triggerUdoExternalListImport
     * @param profileName profileName
     * @param request  SegmentImportRequeset
     * @param jarName jarName
     * @return
     */
    Map<String, List<ImportQuery.SegmentImportRequest.SegmentDefinition>>  segmentImport(String profileName, ImportQuery.SegmentImportRequest request, String jarName);
}
