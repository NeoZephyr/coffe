package com.convertlab.macore.mamgt.misc.mongo;

import com.mongodb.client.MongoClients;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.core.SimpleMongoClientDatabaseFactory;

/**
 * @author Mr.黄
 * @description
 * @since 2023/09/11 20:06
 **/
@Configuration
public class MongoConfig {
    @Value("${convertlab.mongodb.etlMongo.uri}")
    private String uri;
    @Value("${convertlab.mongodb.etlMongo.db}")
    private String orderDb;

    @Bean("etlMongoDataBaseFactory")
    public MongoDatabaseFactory orderMongoDataBaseFactory() {
        return new SimpleMongoClientDatabaseFactory(MongoClients.create(uri), orderDb);
    }
}
