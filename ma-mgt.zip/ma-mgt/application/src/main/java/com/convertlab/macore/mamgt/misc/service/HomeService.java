package com.convertlab.macore.mamgt.misc.service;


public interface HomeService {
    String greeting();

    void sendEvent();
}
