package com.convertlab.macore.mamgt.misc.event;

import com.convertlab.foundation.library.business.eventbroker.EventOptions;
import com.convertlab.foundation.library.business.eventbroker.GenericDomainEventPublisher;
import com.convertlab.foundation.library.business.property.EventBrokerProperties;
import com.convertlab.foundation.library.constant.ComponentNames;
import com.convertlab.foundation.library.gdmmeta.constants.MetaEvent;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import javax.annotation.Nonnull;

@Service
public class MetaEventPublisher extends GenericDomainEventPublisher<MetaEvent, MetaEvent.Dto, MetaEvent.MetaEventType> {
//    private final ApplicationEventPublisher eventPublisher;

    public MetaEventPublisher(ApplicationEventPublisher eventPublisher, EventBrokerProperties eventBrokerProperties) {
        super(eventPublisher, eventBrokerProperties);
    }

    @Nonnull
    @Override
    protected String getPublisher() {
        return ComponentNames.ADVANCED_FILTER;
    }


    @Nonnull
    @Override
    protected MetaEvent createEvent(MetaEvent.Dto dto, @Nonnull EventOptions options) {
        return new MetaEvent(this, dto, options);
    }
}
