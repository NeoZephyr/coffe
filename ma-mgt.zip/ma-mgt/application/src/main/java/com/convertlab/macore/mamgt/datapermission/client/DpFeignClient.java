package com.convertlab.macore.mamgt.datapermission.client;

import com.convertlab.macore.mamgt.misc.configure.FeignConfig;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(
        name = "DpClient",
        url = "${dataPermissionService.serverUrl}",
        configuration = FeignConfig.class,
        decode404 = true
)
public interface DpFeignClient extends DpApi {
}
