package com.convertlab.macore.mamgt.customer.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.customer.entity.TagDimension;
import org.apache.commons.collections.CollectionUtils;
import org.apache.ibatis.annotations.*;

import java.util.ArrayList;
import java.util.List;

@Mapper
public interface TagDimensionMapper extends BaseMapper<TagDimension> {

        @Select("select tg.* from tag_dimension tg where tg.dimension_key = #{dimension_key}")
        TagDimension getByDimensionKey( @Param("dimension_key") String dimensionKey);

        default List<String> listTagIdsByIdList(@Param("idList") List<String> idList){
                //如果idList为空，则返回空列表
                if(CollectionUtils.isEmpty(idList)){
                        return new ArrayList<>();
                }
                return _listTagIdsByIdList(idList);
        }


        //根据id list找到tag list。
        @Select("<script> select id from tag where id in <foreach item='item' index='index' collection='idList' open='(' separator=',' close=')'>#{item}</foreach>  </script>")
        List<String> _listTagIdsByIdList(@Param("idList") List<String> idList);

        @Select(" select distinct dimension from tag where dimension is not null and dimension != 'all' ")
        List<String> listAllDimensionByTag();

        default  List<TagDimension> listByDimensionKeyList(@Param("dimensionKeyList") List<String> dimensionKeyList){
                //如果dimensionKeyList为空，则返回空列表
                if(CollectionUtils.isEmpty(dimensionKeyList)){
                        return new ArrayList<>();
                }
                return _listByDimensionKeyList(dimensionKeyList);
        }

        //根据dimensionKey list找到tag dimension list
        @Select("<script> select * from tag_dimension where dimension_key in <foreach item='item' index='index' collection='dimensionKeyList' open='(' separator=',' close=')'>#{item}</foreach>  </script>")
        List<TagDimension> _listByDimensionKeyList(@Param("dimensionKeyList") List<String> dimensionKeyList);

        @Select("<script> SELECT * FROM tag_dimension   " +
                "       <if test=\"deptCode != null and deptCode != ''\">" +
                "        WHERE dept_code = #{deptCode}" +
                "        </if> </script> ")
        List<TagDimension> listByDeptCode(@Param("deptCode") String deptCode);

}

