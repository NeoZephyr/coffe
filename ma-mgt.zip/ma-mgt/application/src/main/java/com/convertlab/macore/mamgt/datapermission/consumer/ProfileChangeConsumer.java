package com.convertlab.macore.mamgt.datapermission.consumer;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class ProfileChangeConsumer {

    //udo change consumer

    //customer change consumer

}
