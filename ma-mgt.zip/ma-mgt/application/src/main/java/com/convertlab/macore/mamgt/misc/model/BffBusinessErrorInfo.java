package com.convertlab.macore.mamgt.misc.model;

import com.convertlab.macore.mamgt.misc.advice.I18nAspect;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Map;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BffBusinessErrorInfo {

    /**
     * 错误码
     */
    private String code;

    /**
     * 错误消息码
     */
    @JsonProperty("message_code")
    private String messageCode;

    /**
     * 消息参数
     */
    @JsonProperty("message_arguments")
    private String[] messageArguments;

    /**
     * HTTP状态码
     */
    @JsonProperty("http_status_code")
    private Integer httpStatusCode;

    @JsonProperty("field_errors")
    private List<com.convertlab.foundation.library.model.GenericErrorInfo.FieldError> fieldErrors;

    private Map<String, String> additions;

    @JsonGetter(value = "message")
    public String getMessage() {
        String message = null;
        if (messageCode != null) {
            message = I18nAspect.loadErrorMessage(messageCode);
            if(StringUtils.isNotBlank(message) && message.startsWith("\"") && message.endsWith("\"")){
                message = message.substring(1, message.length()-1);
            }
            if(message !=null && messageArguments!=null && messageArguments.length>0){
                for(int i=0; i<messageArguments.length; i++){
                    if(messageArguments[i] !=null) {
                        message = message.replace("{" + i + "}", messageArguments[i]);
                    }else{
                        message = message.replace("{" + i + "}", "null");
                    }
                }
            }

        }
        return message;
    }

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class FieldError {

        private String field;

        @JsonProperty("message_code")
        private String messageCode;

        private String description;
    }
}
