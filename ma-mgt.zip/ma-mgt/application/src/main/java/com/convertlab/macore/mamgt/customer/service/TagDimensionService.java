package com.convertlab.macore.mamgt.customer.service;

import com.convertlab.foundation.library.datapermission.feign.ResourceAclClient;
import com.convertlab.foundation.library.datapermission.model.GetMetaAndSettingDto;
import com.convertlab.foundation.library.datapermission.model.GlobalAccessSetting;
import com.convertlab.foundation.library.principal.context.PrincipalContextHolder;
import com.convertlab.macore.mamgt.customer.entity.TagDimension;
import com.convertlab.macore.mamgt.customer.mapper.TagDimensionMapper;
import com.convertlab.macore.mamgt.customer.model.CheckTagDimensionDataPermissionDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class TagDimensionService {

    private final ResourceAclClient resourceAclClient;
    private final TagDimensionMapper tagDimensionMapper;

    public TagDimensionService(ResourceAclClient resourceAclClient, TagDimensionMapper tagDimensionMapper) {
        this.resourceAclClient = resourceAclClient;
        this.tagDimensionMapper = tagDimensionMapper;
    }

    public List<TagDimension> getAllPathDimensionByKeys(List<String> dimensionKeys) {

            if(CollectionUtils.isEmpty(dimensionKeys)){
                return new ArrayList<>();
            }

            int cycles = 3;
            boolean flag = true;

            List<String> initDimensionKeys = dimensionKeys.stream()
                    .distinct()
                    .collect(Collectors.toList());

            List<TagDimension> dimensionsList = new ArrayList<>();

            while (cycles-- != 0 && flag) {

                //获得初始folder list
                List<TagDimension> dimensions = tagDimensionMapper.listByDimensionKeyList(initDimensionKeys);
                dimensionsList.addAll(dimensions);

                //获得folders的parentId list, 轮询folders, 找到他的parentId, 并去重, 且排除parentId = 0的场景。
                List<String> parentDimensionKeys = dimensions.stream()
                        .map(TagDimension::getParentKey)
                        .filter(parent -> !"all".equals(parent))
                        .distinct()
                        .collect(Collectors.toList());

                //如果parentFolderIds为空，则说明已经到达顶层，不再继续循环。
                if (parentDimensionKeys.size() == 0) {
                    flag = false;
                } else {
                    //如果parentFolderIds不为空，则继续循环。
                    initDimensionKeys = parentDimensionKeys;
                }
            }

       return  dimensionsList;

    }

    private boolean isHeadquarter() {
        String deptCode = PrincipalContextHolder.getDeptCode();
        if ("A00001".equals(deptCode) || "A00000".equals(deptCode)) {
            return true;
        }
        return false;

    }

    public List<TagDimension> listTagDimension() {
        TagDimensionPermissionCheck permissionCheck = new TagDimensionPermissionCheck();
        if(permissionCheck.requirePermission()) {
            GetMetaAndSettingDto metaAndSetting = permissionCheck.metaAndSetting;
            //1. 查询数据权限可见的tag dimension。
            List<TagDimension> tagDimensions1 = tagDimensionMapper.selectList(null);

            //2. 如果tagdimension内的tag数据权限可见，则tag dimension也可见。
            List<String> dimensionKeys = tagDimensionMapper.listAllDimensionByTag();

            //3. 根据tagDimensions2，找到所有父目录的dimension。
            List<TagDimension> tagDimensions2 =getAllPathDimensionByKeys(dimensionKeys);

            //4.将1和2合并，并根据dimensionKey去重。
            Set<TagDimension> mergedTagDimensions = new HashSet<>(tagDimensions1);
            for (TagDimension tagDimension : tagDimensions2) {
                if (!mergedTagDimensions.contains(tagDimension.getDimensionKey())) {
                    mergedTagDimensions.add(tagDimension);
                }
            }

            List<TagDimension> mergedAndDeduplicatedTagDimensions = new ArrayList<>(mergedTagDimensions);

            return mergedAndDeduplicatedTagDimensions;
        }else{
            return tagDimensionMapper.selectList(null);
        }
    }


    public List<TagDimension> listTagDimensionInCurrentDept(boolean withSubDept){
        //获得当前的deptCode
        String deptCode = PrincipalContextHolder.getDeptCode();
        //创建空的folder list
        List<TagDimension> tagDimensions = new ArrayList<>();
        //如果withSubDept为true，则默认使用数据权限查询规则，不放入deptCode作为条件。
        if(withSubDept){
            tagDimensions = tagDimensionMapper.listByDeptCode(null);
        }else{
            tagDimensions = tagDimensionMapper.listByDeptCode( deptCode);
        }
        return tagDimensions;
    }


    public boolean checkTagDimensionPermission(TagDimensionPermissionCheck permissionCheck, String dimensionKey){

        if(permissionCheck.requirePermission()){
            TagDimension tagDimension = tagDimensionMapper.getByDimensionKey(dimensionKey);
            if(tagDimension == null) {
                return false;
            }
        }
        return true;
    }

    public boolean checkTagPermission(TagDimensionPermissionCheck permissionCheck, List<String> contents){
        if(permissionCheck.requirePermission()){
            List<String> queryIds =  tagDimensionMapper.listTagIdsByIdList(contents);

            if(queryIds.size() == contents.size()){
                return true;
            }
            else{
                return false;
            }
        }else{
            return true;
        }
    }

    @Data
    @AllArgsConstructor
    public class TagDimensionPermissionCheck {

        GetMetaAndSettingDto metaAndSetting;

        public TagDimensionPermissionCheck(){
            //如果需要数据权限，则调用resourceAclClient接口，获取meta和globalSetting。
            metaAndSetting = resourceAclClient.getMetaAndSetting("tag_dimension");
        }

        boolean requirePermission(){
            //总部用户不做数据权限控制。
            if ( !isHeadquarter()) {
                //如果meta和globalSetting都不为空，则继续判断是否需要数据权限。
                if (metaAndSetting.getResourceMeta() != null && metaAndSetting.getGlobalAccessSetting() != null) {
                    if (GlobalAccessSetting.PRIVATE_PERMISSION.equals(metaAndSetting.getGlobalAccessSetting().getAccessPermission())) {
                        return true;
                    }
                }
            }
            return false;
        }
    }


    public Boolean checkDataPermission(CheckTagDimensionDataPermissionDto dto) {
        TagDimensionService.TagDimensionPermissionCheck permissionCheck = new TagDimensionService.TagDimensionPermissionCheck();
        //检查文件夹权限
        if (!checkTagDimensionPermission(permissionCheck, dto.getDimensionKey())) {
            return false;
        }

        //检查内容权限
        if (!checkTagPermission(permissionCheck, dto.getTagIdList())) {
            return false;
        }

        return true;
    }

}
