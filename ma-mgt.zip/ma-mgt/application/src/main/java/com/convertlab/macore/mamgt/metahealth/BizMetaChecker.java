package com.convertlab.macore.mamgt.metahealth;

import com.convertlab.foundation.api.gdm.pattern.GdmModelClient;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.libaray.meta.health.Issue;
import com.convertlab.foundation.libaray.meta.health.MetaChecker;
import com.convertlab.foundation.libaray.meta.health.annotation.MetaCheckerAnnotation;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationship;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmSingularGdmRelationship;
import com.convertlab.foundation.library.utils.Try;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.ProfileBizMeta;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.associated.ProfilePropBizMeta;
import com.convertlab.macore.mamgt.cdp.meta.common.enums.FieldType;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.convertlab.foundation.libaray.meta.health.BasicMetaValidationRule.*;

@RequiredArgsConstructor
@MetaCheckerAnnotation
public class BizMetaChecker implements MetaChecker<ProfileBizMeta> {
    private final GdmModelClient gdmModelClient;
    private final GsMetaClient gsMetaClient;

    @Override
    public @NonNull List<@NonNull Issue> check(@NonNull ProfileBizMeta profileBizMeta) {
        List<Issue> issues = new ArrayList<>();
        String profileName = profileBizMeta.getObjectName();
        String modelName = profileBizMeta.getModel().getName();
        String entityName = profileBizMeta.getEntityName();
        GdmModelDto model = gdmModelClient.findByNameWithoutEvents(modelName);
        if (model == null) {
            issues.add(RULE_01_001.toIssue(profileName));
        }

        GdmEntity entity = gsMetaClient.getEntity(entityName);
        if (entity == null) {
            issues.add(RULE_01_002.toIssue(profileName));
        } else {
            String primaryKeyField = entity.getPrimaryKeyField();
            if (StringUtils.isBlank(primaryKeyField)) {
                issues.add(RULE_01_003.toIssue(profileName));
            }
        }

        List<ProfilePropBizMeta> props = profileBizMeta.getProps();
        if (!CollectionUtils.isEmpty(props)) {
            List<ProfilePropBizMeta> lookUpRefFields = props.stream()
                    .filter(x -> FieldType.LookupRef.id.equals(x.getType()))
                    .collect(Collectors.toList());
            for (ProfilePropBizMeta propBizMeta : lookUpRefFields) {
                String rightEntityName = propBizMeta.getRefObjId();
                String mappedBy = propBizMeta.getName();
                GdmRelationship relationship = getRelationship(entityName, rightEntityName, profileName, mappedBy);
                if (relationship == null) {
                    RULE_01_004.toIssue(profileName, propBizMeta.getName());
                }
            }
        }
        return issues;
    }

    @Nullable
    private GdmRelationship getRelationship(String leftEntityName, String rightEntityName, String fkOwningSide, String mappedBy) {
        return Try.ignoreException(() -> {
            List<GdmRelationship> relationships = gsMetaClient.getRelationships(leftEntityName, null);
            if (CollectionUtils.isEmpty(relationships)) {
                return null;
            }
            return relationships.stream()
                    .filter(x -> x.getRightEntityName().equals(rightEntityName))
                    .filter(r -> r instanceof GdmSingularGdmRelationship)
                    .map(relationship -> (GdmSingularGdmRelationship) relationship)
                    .filter(r -> r.getForeignKeyOwningSide().equalsIgnoreCase(fkOwningSide) && r.getMappedBy().equalsIgnoreCase(mappedBy))
                    .findAny()
                    .orElse(null);
        }, null);
    }
}
