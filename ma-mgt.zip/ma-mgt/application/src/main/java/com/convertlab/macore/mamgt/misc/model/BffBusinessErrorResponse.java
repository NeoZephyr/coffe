package com.convertlab.macore.mamgt.misc.model;

import com.convertlab.foundation.library.model.vo.BaseResponse;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class BffBusinessErrorResponse implements BaseResponse {

    /**
     * 异常类型记录
     */
    private BffBusinessErrorInfo error;
}