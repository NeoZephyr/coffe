package com.convertlab.macore.mamgt.misc.annotation;


import java.lang.annotation.*;

/**
 * Controller Display Order in Swagger API Docs
 * Author:
 * Johnny Chen
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Documented
public @interface DisplayOrder {
    int value() default 0;
}
