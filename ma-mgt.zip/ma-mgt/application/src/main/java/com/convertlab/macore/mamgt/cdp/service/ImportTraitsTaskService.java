package com.convertlab.macore.mamgt.cdp.service;

import com.convertlab.macore.mamgt.cdp.model.entity.ExternalTagImportTask;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

public interface ImportTraitsTaskService {

    ExternalTagImportTask findById(Long id);

    List<ExternalTagImportTask> queryHistoriesTask(String profileName, List<String> fileNames, Date date);

    ExternalTagImportTaskVO queryHistoriesTask(String profileName, Long startId, Integer rows);

    ExternalTagImportTask saveTask(String profileName, ExternalTagImportTask entity);

    @Setter
    @Getter
    public static class ExternalTagImportTaskVO {
        private Long total;
        private Integer size;
        private List<ExternalTagImportTask> records;

        public ExternalTagImportTaskVO() {
        }

        public ExternalTagImportTaskVO(Long total, Integer size, List<ExternalTagImportTask> records) {
            this.total = total;
            this.size = size;
            this.records = records;
        }
    }
}
