package com.convertlab.macore.mamgt.datapermission.model;

public enum TaskType {
    create_rule, update_rule, delete_rule, refresh_rule,recalculate_rule
}
