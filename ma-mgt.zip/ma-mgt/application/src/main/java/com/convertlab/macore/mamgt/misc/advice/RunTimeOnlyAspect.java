package com.convertlab.macore.mamgt.misc.advice;

import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.macore.mamgt.misc.annotation.RunTimeOnly;
import lombok.RequiredArgsConstructor;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Value;

import static com.convertlab.foundation.library.constant.CommonErrors.GENERAL_ERROR;

@Aspect
@RequiredArgsConstructor
public class RunTimeOnlyAspect {
    @Value("${convertlab.metaclient.design-time-mode}")
    private Boolean designTimeMode;

    @Before("@annotation(runTimeOnly)")
    public void beforeRunTimeOnly(JoinPoint joinPoint, RunTimeOnly runTimeOnly){
        String signature = joinPoint.getSignature().getName();
        if(designTimeMode !=null && designTimeMode){
            throw new BusinessException(GENERAL_ERROR, "MSG_104_000076", "can not call method " + signature + " in design time", new String[]{signature});
        }
    }
}
