package com.convertlab.macore.mamgt.customer.model;

import lombok.*;

@Data
@EqualsAndHashCode(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TagDimensionMeta {

    String resourceType;
    String folderType;
    boolean requireDataPermission;
    boolean isMainDB;
    MiddleTableRelation middleTableRelation;
    DataTableRelation dataTableRelation;

    @Data
    @EqualsAndHashCode(callSuper=false)
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class MiddleTableRelation{
        @Builder.Default
        String middleTable = "folder_content";
        @Builder.Default
        String contentIdColumnMapping = "id";
    }

    @Data
    @EqualsAndHashCode(callSuper=false)
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class DataTableRelation{
        @Builder.Default
        String folderIdColumnMapping = "folder_id";
    }

}
