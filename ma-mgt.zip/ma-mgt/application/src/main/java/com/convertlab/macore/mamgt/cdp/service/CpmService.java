package com.convertlab.macore.mamgt.cdp.service;

import com.convertlab.macore.mamgt.cdp.CpmQuery;
import java.util.List;

public interface CpmService {

    boolean isCpmFeatureEnabled();

    List<CpmQuery.CpmPurposeVo> getCpmPurposes();

    List<CpmQuery.CpmConsentVo> getDataConsentsByCustomerId();
}
