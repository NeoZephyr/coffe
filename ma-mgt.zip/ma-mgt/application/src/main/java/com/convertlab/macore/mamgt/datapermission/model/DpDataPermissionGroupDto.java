package com.convertlab.macore.mamgt.datapermission.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class DpDataPermissionGroupDto implements Serializable {

    public static final String GROUP_TYPE_BUILT_IN = "built-in";
    public static final String GROUP_TYPE_CHANNEL = "channel";
    public static final String GROUP_TYPE_PRIMARY_PROFILE = "primary-profile";
    public static final String GROUP_TYPE_GENERAL_PROFILE = "general-profile";

    private String groupName;
    private String groupCnName;
    private String groupType;

}
