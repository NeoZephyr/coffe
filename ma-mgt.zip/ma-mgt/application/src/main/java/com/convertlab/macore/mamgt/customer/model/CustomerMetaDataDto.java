package com.convertlab.macore.mamgt.customer.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * 这个类在customer服务中也有一份拷贝，记得同时改
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString
@NoArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class CustomerMetaDataDto implements Serializable {
    /**
     * customer_meta 的类型
     */
    private String type;

    /**
     * customer_meta 的内容
     */
    private String meta;
}
