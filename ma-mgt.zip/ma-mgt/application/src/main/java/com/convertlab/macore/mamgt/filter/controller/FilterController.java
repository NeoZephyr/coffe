package com.convertlab.macore.mamgt.filter.controller;


import com.convertlab.filter.common.FilterProperties;
import com.convertlab.filter.common.FiltersQueryGenerator;
import com.convertlab.filter.common.QueryGenerator;
import com.convertlab.filter.common.SingleQueryGenerator;
import com.convertlab.filter.constants.CategoryType;
import com.convertlab.filter.utils.JsonHelper;
import com.convertlab.foundation.api.queryengine.FilterV4Dto;
import com.convertlab.foundation.api.queryengine.SqlBuilder;
import com.convertlab.foundation.library.business.feature.FeatureClient;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.model.GenericPage;
import com.convertlab.foundation.library.model.vo.GenericPageResponse;
import com.convertlab.foundation.library.model.vo.GenericResponse;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.library.webmvc.annotation.RequirePermission;
import com.convertlab.foundation.library.webmvc.annotation.ResourceIdentifier;
import com.convertlab.macore.api.permissions.annotation.RequireAdminPermission;
import com.convertlab.macore.mamgt.cdp.meta.common.utils.BizMetaHelper;
import com.convertlab.macore.mamgt.cdp.dto.Profile;
import com.convertlab.macore.mamgt.cdp.profile.service.TraitService;
import com.convertlab.macore.mamgt.filter.filters.model.FilterResponse;
import com.convertlab.macore.mamgt.filter.filters.model.FilterTransformResponse;
import com.convertlab.macore.mamgt.filter.filters.model.dao.registration.FilterExtensionPoints;
import com.convertlab.macore.mamgt.filter.filters.model.dto.registration.FilterRegistrationRequest;
import com.convertlab.macore.mamgt.filter.filters.model.dto.registration.FilterRegistrationResponse;
import com.convertlab.macore.mamgt.filter.filters.service.FilterMetaService;
import com.convertlab.macore.mamgt.filter.model.dto.EncryptQueryParameterRequest;
import com.convertlab.macore.mamgt.filter.model.filterV4.request.FilterV4VO;
import com.convertlab.macore.mamgt.filter.model.filterv2.Filter;
import com.convertlab.macore.mamgt.filter.model.filterv2.FilterGroup;
import com.convertlab.macore.mamgt.filter.model.filterv2.Filters;
import com.convertlab.macore.mamgt.filter.model.filterv2.Preview;
import com.convertlab.macore.mamgt.filter.service.FilterV4Service;
import com.convertlab.macore.mamgt.misc.annotation.DisplayOrder;
import com.convertlab.macore.mamgt.misc.controller.BaseController;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Nullable;
import java.util.*;

import static com.convertlab.foundation.library.constant.CommonErrors.GENERAL_ERROR;
import static com.convertlab.foundation.library.constant.CommonErrors.VALIDATION_ERROR;
import static com.convertlab.macore.mamgt.cdp.common.constants.ProfileConstants.PROFILE_CUSTOMER;
import com.convertlab.filter.timeline.*;

/**
 * All rights Reserved, Designed By ConvertLab
 * Author: zhiping.cai
 * Date: 2023/2/23
 * Description:
 * Copyright (C) 2022 www.convertlab.com
 */
@DisplayOrder(11)
@RequestMapping("/filterv4/")
@Slf4j
@RequiredArgsConstructor
@RestController
@Tag(name = "高级筛选接口")
public class FilterController extends BaseController {
    private final FilterV4Service filterV4Service;
    private final TraitService traitService;
    private final FilterMetaService filterMetaService;

    @Operation(summary = "将filterV2转换为FilterV4 ViewModel", description = "将FilterV2条件（不含select，分页信息)，转换为FilterV4 的ViewModel")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            content = @Content(mediaType = "application/json",
                    examples = {@ExampleObject(name = "request", description = "注意请求体不包含select，filters等字段，直接传filters的json对象", value = "@examples/filter/convert_v2_to_v4_req.json")})
    )
    @ApiResponse(content = @Content(
            mediaType = "application/json",
            examples = {@ExampleObject(name = "response", summary = "ViewModel（注意这个不是最终的FilterV4）", value = "@examples/filter/convert_v2_to_v4_res.json")}
    ))
    @RequestMapping(value = "convertV2ToViewModel/{profileName}", method = RequestMethod.POST)
    public GenericResponse<FilterV4VO> convertFilterV2ToV4iewModel(@PathVariable @Parameter(name = "profileName", description = "档案名", example = "customer")
                                                                           String profileName,
                                                                   @RequestBody
                                                                           Filters filterV2) {
        try {
            Preview<Filters> preview = new Preview<>();
            preview.setFilters(filterV2);
            preview.setSelect("id");
            String request = JsonUtils.instanceOfDto().obj2Json(filterV2);
            log.info("convertFilterV2ToV4iewModel filterV2 request is {}", request);
            FilterV4VO viewModel = filterV4Service.convertFilterV2ToViewModel(profileName, request);
            log.info("convertFilterV2ToV4iewModel viewModel response is {}", JsonUtils.instance().obj2Json(viewModel));
            return GenericResponse.<FilterV4VO>builder().result(viewModel).build();
        } catch (Exception e) {
            log.error("failed convertFilterV2ToV4iewModel {}", filterV2.toString(), e);
            throw new BusinessException(GENERAL_ERROR, "MSG_100_000018", "Failed to convert filterV2 to viewModel",
                    new String[]{profileName, e.getMessage()});
        }
    }

    @Operation(summary = "将含FilterV2的Preview请求转换为FilterV4", description = "将FilterV2转换为FilterV4，是convertFilterV2ToViewModel 和 convertViewModelToFilterV4的组合")
    @RequestMapping(value = "convertFilterV2ToFilterV4/{profileName}", method = RequestMethod.POST)
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            content = @Content(mediaType = "application/json",
                    examples = {@ExampleObject(name = "request", summary = "request", value = "@examples/filter/convert_v2_to_v4_req.json")})
    )
    public GenericResponse<FilterV4Dto> convertFilterV2ToFilterV4(@PathVariable @Parameter(name = "profileName", description = "档案名", example = "customer")
                                                                          String profileName,
                                                                  @RequestParam(value = "sqlDialect", required = false)
                                                                  @Parameter(name = "sqlDialect",
                                                                          description = "因GDM中的customerId为 bigint类型，但是sparkjob中的customerid需要兼容string类型,可以设置useSparkDialect确保V4中的customerId为String类型", example = "SPARK")
                                                                          String sqlDialect,
                                                                  @RequestBody Filters filters) {
        try {
            FilterV4Dto result = filterV4Service.convertFilterV2ToFilterV4(profileName, sqlDialect, null, filters);
            return GenericResponse.<FilterV4Dto>builder().result(result).build();
        } catch (Exception e) {
            log.error("failed convertFilterV2ToFilterV4 {}", filters.toString(), e);
            throw new BusinessException(GENERAL_ERROR, "MSG_100_000018", "Failed to convert filterV2 to filterV4",
                    new String[]{profileName, e.getMessage()});
        }
    }


    @Operation(summary = "将filterV2转换为Sql", description = "将FilterV2条件（不含select，分页信息)，转换为Sql")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            content = @Content(mediaType = "application/json",
                    examples = {@ExampleObject(name = "request", description = "注意请求体不包含select，filters等字段，直接传filters的json对象", value = "@examples/filter/convert_v2_to_v4_req.json")})
    )
    @RequestMapping(value = "convertV2ToSql/{profileName}", method = RequestMethod.POST)
    public GenericResponse<String> convertFilterV2ToSql(@PathVariable @Parameter(name = "profileName", description = "档案名", example = "customer")
                                                                String profileName,
                                                        @Parameter(name = "sqlDialect", description = "sql方言选择,IMPALA/SPARK", example = "IMPALA") @RequestParam(value = "sqlDialect", required = false, defaultValue = "IMPALA") @Nullable
                                                                String sqlDialect,
                                                        @Parameter(name = "primaryKeyAlias", description = "主键的Alias", example = "id") @RequestParam(value = "primaryKeyAlias", required = false, defaultValue = "id") @Nullable
                                                                String primaryKeyAlias,
                                                        @RequestBody
                                                                Filters<FilterV4VO> filterV2) {
        try {
            Boolean hasOrderBy = false;
            if(Objects.nonNull(filterV2.getV4())
                    &&Objects.nonNull(filterV2.getV4().getOrderBy())){
                hasOrderBy = true;
            }
            FilterV4Dto filterV4 = null;

            if (Objects.isNull(filterV2.getV4())){
                filterV4 = filterV4Service.convertFilterV2ToFilterV4(profileName, sqlDialect, primaryKeyAlias, filterV2);
            }else{
                filterV4 = filterV4Service.convertFilterV2ToFilterV4(profileName, sqlDialect, primaryKeyAlias, filterV2.getV4());
            }

            if(!hasOrderBy){
                filterV4.setOrderBy(null);
            }
            log.info("convertFilterV2ToSql before transforming to sql, V4 is {}", JsonUtils.instance().obj2Json(filterV4).toString());
            String sql = filterV4Service.convertFilterV4ToSqlWithDialect(profileName, filterV4, SqlBuilder.SQLDialect.valueOf(sqlDialect),null);
            return GenericResponse.<String>builder().result(sql).build();
        } catch (Exception e) {
            log.error("failed convertFilterV2ToSql {}", filterV2.toString(), e);
            throw new BusinessException(GENERAL_ERROR, "MSG_100_000018", "Failed to convert filterV2 to sql",
                    new String[]{profileName, e.getMessage()});
        }
    }


    @Operation(summary = "将filterV2转换为ViewModel 和 Sql", description = "将FilterV2条件（不含select，分页信息)，转换为ViewMode 和 Sql")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            content = @Content(mediaType = "application/json",
                    examples = {@ExampleObject(name = "request", description = "注意请求体不包含select，filters等字段，直接传filters的json对象", value = "@examples/filter/convert_v2_to_v4_req.json")})
    )
    @RequestMapping(value = "convertV2ToViewModelAndSql/{profileName}", method = RequestMethod.POST)
    public GenericResponse<FilterTransformResponse> convertFilterV2ToViewModelAndSql(@PathVariable @Parameter(name = "profileName", description = "档案名", example = "customer")
                                                        String profileName,
                                                                                     @Parameter(name = "sqlDialect", description = "sql方言选择,IMPALA/SPARK", example = "IMPALA") @RequestParam(value = "sqlDialect", required = false, defaultValue = "IMPALA") @Nullable
                                                        String sqlDialect,
                                                                                     @Parameter(name = "primaryKeyAlias", description = "主键的Alias", example = "id") @RequestParam(value = "primaryKeyAlias", required = false, defaultValue = "id") @Nullable
                                                        String primaryKeyAlias,
                                                                                     @Parameter(name = "withGdql", description = "withGdql", example = "false") @RequestParam(value = "withGdql", required = false)
                                                        @Nullable Boolean withGdql,
                                                                                     @Parameter(name = "withV2Sql", description = "withV2Sql", example = "false") @RequestParam(value = "withV2Sql", required = false)
                                                        @Nullable Boolean withV2Sql,
                                                                                     @RequestBody
                                                        Filters<FilterV4VO> filterV2) {
        try {
            Boolean hasOrderBy = false;
            if(Objects.nonNull(filterV2.getV4())
                    &&Objects.nonNull(filterV2.getV4().getOrderBy())){
                hasOrderBy = true;
            }

            FilterV4VO filterV4VO = filterV4Service.convertFilterV2ToViewModel(profileName, filterV2);
            FilterV4Dto filterV4 = filterV4Service.convertFilterV2ToFilterV4(profileName, sqlDialect, primaryKeyAlias, filterV4VO);
            if(!hasOrderBy){
                filterV4.setOrderBy(null);
            }
            log.info("convertFilterV2ToSql before transforming to sql, V4 is {}", JsonUtils.instance().obj2Json(filterV4).toString());
            String sql = filterV4Service.convertFilterV4ToSqlWithDialect(profileName, filterV4, SqlBuilder.SQLDialect.valueOf(sqlDialect),null);
            FilterTransformResponse response = FilterTransformResponse.builder().sql(sql).viewModel(filterV4VO).v4(filterV4).build();
            if(withGdql != null && withGdql){
                String gdql = filterV4Service.convertFilterV4ToGdqlWithDialect(profileName, filterV4, SqlBuilder.SQLDialect.valueOf(sqlDialect),null);
                response.setGdql(gdql);
            }

            if(withV2Sql != null && withV2Sql){
                String v2Sql = null;
                String ruleJson = JsonUtils.instance().obj2Json(filterV2).toString();
                if ("EventTimeline".equals(filterV2.getType())) {
                    v2Sql = getEventTimeLineQuerySql((int) TenantContextHolder.getTenantId().longValue(), ruleJson, "default");
                } else {
                    v2Sql = generateDefaultQuerySql((int) TenantContextHolder.getTenantId().longValue(), ruleJson, "default");
                }
                if(StringUtils.isNotBlank(v2Sql)){
                    v2Sql =  "select distinct cus.id from (select id from customer where tenant_id = " + TenantContextHolder.getTenantId() + ") cus left semi join (" + v2Sql
                            + " ) tmp on tmp.customer_id = cus.id";
                }
                response.setV2Sql(v2Sql);
            }

            return GenericResponse.<FilterTransformResponse>builder().result(response).build();
        } catch (Exception e) {
            log.error("failed convertFilterV2ToViewModelAndSql {}", filterV2.toString(), e);
            throw new BusinessException(GENERAL_ERROR, "MSG_100_000018", "Failed to convert filterV2 to sql and viewModel",
                    new String[]{profileName, e.getMessage()});
        }
    }

    /**
     * 临时做生产校验的，后面去掉
     * @param tenantId
     * @param ruleJson
     * @param ruleType
     * @return
     */
    private String getEventTimeLineQuerySql(int tenantId, String ruleJson, String ruleType) {
        FilterProperties filterProperties = new FilterProperties();
        SingleQueryGenerator singleQueryGenerator = new SingleQueryGenerator(filterProperties);
        FiltersQueryGenerator filtersQueryGenerator = new FiltersQueryGenerator(singleQueryGenerator);
        QueryGenerator queryGenerator = new QueryGenerator(filtersQueryGenerator, null);
        EventTimeLineQuery eventTimeLineQuery = new EventTimeLineQuery(singleQueryGenerator, queryGenerator);
        // 避免在群组标签条件中出现标签名，导致计算时无法匹配到具体的标签分区。这里将标签名换成标签id
        Map<Boolean, Filters> convert = convertTagNameToTagIdInFilters(tenantId, ruleJson);
        if (convert != null && convert.containsKey(true)) {
            Filters filters = convert.get(true);
            if (filters == null) {
                log.error("{} convertTagNameToTagIdInFilters failed with no Filters Dto return. tenantId: {} ruleJson: {}",
                        "FilterController", tenantId, ruleJson);
                throw new RuntimeException("convertTagNameToTagIdInFilters failed with no Filters Dto return. ruleJson: " + ruleJson);
            }
            return eventTimeLineQuery.getQuery(tenantId, JsonUtils.instance().obj2Json(filters), ruleType);
        }
        // 不含标签名，走原有逻辑
        return eventTimeLineQuery.getQuery(tenantId, ruleJson, ruleType);
    }

    /**
     * 临时做生产校验的，后面去掉
     * @param tenantId
     * @param ruleJson
     * @param ruleType
     * @return
     */
    private String generateDefaultQuerySql(int tenantId, String ruleJson, String ruleType) {
        FilterProperties filterProperties = new FilterProperties();
        SingleQueryGenerator singleQueryGenerator = new SingleQueryGenerator(filterProperties);
        FiltersQueryGenerator filtersQueryGenerator = new FiltersQueryGenerator(singleQueryGenerator);
        QueryGenerator queryGenerator = new QueryGenerator(filtersQueryGenerator, null);
        // 避免在群组标签条件中出现标签名，导致计算时无法匹配到具体的标签分区。这里将标签名换成标签id
        Map<Boolean, Filters> tagNameReplaceResult = convertTagNameToTagIdInFilters(tenantId, ruleJson);
        if (tagNameReplaceResult != null && tagNameReplaceResult.containsKey(true)) {
            Filters filtersDto = tagNameReplaceResult.get(true);
            log.warn("generateDefaultQuerySql found got new filters {}", JsonUtils.instance().obj2Json(filtersDto));
            if (filtersDto == null) {
                log.error("{} convertTagNameToTagIdInFilters failed with no Filters Dto return. tenantId: {} ruleJson: {}",
                        "FilterController", tenantId, ruleJson);
                throw new RuntimeException("convertTagNameToTagIdInFilters failed with no Filters Dto return. ruleJson: " + ruleJson);
            }
            return filtersQueryGenerator.getQuery(tenantId, JsonUtils.instance().obj2Json(filtersDto));
        }
        // 不含标签名，走原有逻辑
        return queryGenerator.generateQuery(tenantId, ruleJson, ruleType);
    }

    public Map<Boolean, Filters> convertTagNameToTagIdInFilters(int tenantId, String ruleJson) {
        Map<Boolean, Filters> result = new HashMap<>();
        try {
            Filters filters = JsonHelper.json2Obj(ruleJson, Filters.class);
            if (filters == null || filters.getSubFilters() == null || filters.getSubFilters().length == 0) {
                result.put(false, null);
                return result;
            }
            FilterGroup[] groups = filters.getSubFilters();

            boolean hasTagName = false;
            String[] EMPTY_PLACEHOLDER = new String[1];
            EMPTY_PLACEHOLDER[0] = "null";

            if (groups.length > 0) {
                for (FilterGroup group : groups) {
                    Filter[] groupFilters = group.getConditions();
                    for (Filter filter : groupFilters) {
                        if (filter == null || !CategoryType.Tag.equals(filter.getCategory())) {
                            continue;
                        }
                        // 2020年之前的标签条件，将逗号隔开的标签名字符串放在value, value2中。拼接SQL时直接用 tag.name in (value) 。
                        // 2020年之后，新增了differentTag参数 和values, values2字段。 如果differentTag为true，会将多个标签放在values: ['标签1','标签2'] 中。
                        // 如果differentTag为true，value='标签1' 拼接SQL时会用tag.name = '标签1'； values: ['标签1','标签2'] 会用 tag.name in ('标签1','标签2')
                        boolean differentTag = filter.getParameter().isDifferentList();
                        // 处理标签名
                        if (CategoryType.Tag.equals(filter.getProperty())) {
                            if (!"Number".equals(filter.getProperty_type())) {
                                hasTagName = true;
                                log.warn("{} convertTagNameToTagIdInFilters find tag name in condition: {}", "FilterController", JsonHelper.obj2Json(filter));
                                // 将property_type 设置为Number，这样SingleQueryGenerator.generateTagQuery将依据tagId生成SQL
                                filter.setProperty_type("Number");
                                // 将含有标签名的字段，替换为标签id
                                String value = filter.getParameter().getValue();
                                // 如果value中包含英文逗号，需要将value拆分成多个标签名，然后分别转换为标签id，再拼接成用英文逗号隔开的标签id字符串，
                                // 并最终和values, values2合并； 合并前暂存在tempValues， tempValues2中
                                String[] tempValues = null;
                                String[] tempValues2 = null;
                                String[] values = filter.getParameter().getValues();
                                if (!StringUtils.isBlank(value) && (values ==null || values.length ==0)) {
                                    Map<String, String> tagIdMap = traitService.getIdsByNames("customer", Arrays.asList(value), null, null);
                                    String tagId = tagIdMap.get(value);
                                    if (tagId != null && !tagId.contains(",")) {
                                        filter.getParameter().setValue(tagId);
                                    } else if (tagId != null && tagId.contains(",")) {
                                        filter.getParameter().setValue(null);
                                        tempValues = tagId.split(",");
                                    } else if (value.contains(",") || !differentTag) {
                                        // 如果是老的标签条件，为了避免标签被删除之后，拼出 SQL含： t.id in ( ) 语法错，给一个空的tagId
                                        filter.getParameter().setValue(null);
                                        tempValues = EMPTY_PLACEHOLDER;
                                    } else {
                                        filter.getParameter().setValue(null);
                                    }
                                }
                                String value2 = filter.getParameter().getValue2();
                                String[] values2 = filter.getParameter().getValues2();
                                if (!StringUtils.isBlank(value2) && (values2 ==null || values2.length == 0)) {
                                    Map<String, String> tagIdMap = traitService.getIdsByNames("customer", Arrays.asList(value2), null, null);
                                    String tagId = tagIdMap.get(value2);
                                    if (tagId != null && !tagId.contains(",")) {
                                        filter.getParameter().setValue2(tagId);
                                    } else if (tagId != null && tagId.contains(",")) {
                                        filter.getParameter().setValue2(null);
                                        tempValues2 = tagId.split(",");
                                    } else if (value2.contains(",") || !differentTag) {
                                        // 如果是老的标签条件，为了避免标签被删除之后，拼出 SQL含： t.id in ( ) 语法错，给一个空的tagId
                                        filter.getParameter().setValue2(null);
                                        tempValues2 = EMPTY_PLACEHOLDER;
                                    } else {
                                        filter.getParameter().setValue2(null);
                                    }
                                }

                                if (tempValues == null && values != null && values.length > 0) {
                                    Map<String, String> tagIdMap = traitService.getIdsByNames("customer", Arrays.asList(values), null, null);
                                    String[] tagIds = tagIdMap.values().toArray(new String[values.length]);
                                    filter.getParameter().setValues(tagIds);
                                } else if (tempValues != null) {
                                    filter.getParameter().setValues(tempValues);
                                }

                                if (tempValues2 == null && values2 != null && values2.length > 0) {
                                    Map<String, String> tagIdMap = traitService.getIdsByNames("customer", Arrays.asList(values2), null, null);
                                    String[] tagIds = tagIdMap.values().toArray(new String[values.length]);
                                    filter.getParameter().setValues2(tagIds);
                                } else if (tempValues2 != null) {
                                    filter.getParameter().setValues2(tempValues2);
                                }

                                // 为避免SQL语法错,放一个空tagId，生成的SQL为 t.id IN (null) 而不是 t.id IN ()
                                if ((filter.getParameter().getValues() != null && filter.getParameter().getValues().length == 0)
                                        && filter.getParameter().getValues2() != null && filter.getParameter().getValues2().length == 0){
                                    filter.getParameter().setValues(EMPTY_PLACEHOLDER);
                                    filter.getParameter().setValues(new String[]{});
                                }
                            }
                        } else if ("tag_group".equals(filter.getProperty())) {
                            // 由于dynamic_customer_tag 表的分区是 (id, tenant_id), 需要将dimension字段替换为tagId以确保predicates 能匹配到具体的分区
                            // dimension仅出现在values中
                            String[] values = filter.getParameter().getValues();
                            if (values != null && values.length > 0) {
                                List<String> tagIdList = new ArrayList<String>();
                                for (String dimension : values) {
                                    List<String> tagIds = traitService.getTagIdsByDimension(dimension);
                                    if (tagIds != null && tagIds.size() > 0) {
                                        tagIdList.addAll(tagIds);
                                    }
                                }
                                hasTagName = true;
                                log.warn("{} convertTagNameToTagIdInFilters exchange tag dimension to tagIds in condition: {}", "FilterController", JsonHelper.obj2Json(filter));
                                // 将property_type 设置为Number，这样SingleQueryGenerator.generateTagQuery将依据tagId生成SQL
                                filter.setProperty_type("Number");
                                filter.setProperty(CategoryType.Tag);
                                if (tagIdList.isEmpty()) {
                                    // 为避免SQL语法错,放一个空tagId，生成的SQL为 t.id IN (null) 而不是 t.id IN ()
                                    filter.getParameter().setValues(EMPTY_PLACEHOLDER);
                                } else {
                                    filter.getParameter().setValues(tagIdList.toArray(new String[tagIdList.size()]));
                                }
                            }
                        }
                    }
                }
            }
            result.put(hasTagName, filters);
            return result;
        } catch (Exception e) {
            log.error("{} convertTagNameToTagIdInFilters failed. tenantId: {} listOrTag: {} listOrTagName: {} id: {} ruleJson: {}", "FilterController", tenantId, ruleJson, e);
            result.put(false, null);
            return result;
        }
    }

    @Operation(summary = "档案高级筛选列表查询", description = "支持客户和UDO的高级筛选数据查询")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            content = @Content(mediaType = "application/json",
                    examples = {@ExampleObject(name = "request", summary = "request", value = "@examples/filter/filter_v4_preview_req.json")})
    )
    @ApiResponse(content = @Content(
            mediaType = "application/json",
            examples = {@ExampleObject(name = "response", summary = "返回结果", value = "@examples/filter/filter_v4_preview_res.json"),
                    @ExampleObject(name = "response2", summary = "含有可选项的返回结果", value = "@examples/filter/filter_v4_preview_with_options_res.json")}
    ))
    @PostMapping(value = "{profileName}/preview")
    public GenericPageResponse<Profile> filterV4List(@PathVariable @Parameter(name = "profileName", description = "档案名", example = "customer")
                                                             String profileName,
                                                     @RequestBody Preview<FilterV4VO>
                                                             request) {
        try {
            FilterV4VO viewModel = Optional.ofNullable(request.getFilters().getV4())
                    .orElseGet(() -> {
                        Optional<String> selectOptional = Optional.ofNullable(request.getSelect());
                        if (profileName.equals(PROFILE_CUSTOMER)) {
                            request.setSelect(selectOptional.orElse("id"));
                        } else {
                            request.setSelect(selectOptional.orElse("bk"));
                        }
                        String reqStr = JsonUtils.instance().obj2Json(request);
                        try {
                            return filterV4Service.convertFilterV2ToViewModel(profileName, reqStr);
                        } catch (Exception e) {
                            log.error("failed convertFilterV2ToViewModel {}", reqStr, e);
                            return null;
                        }
                    });
            request.getFilters().setV4(viewModel);
            FilterResponse response = filterV4Service.filterV4List(profileName, request, false);
            //convert results to GenericPage
            GenericPage<Profile> profileGenericPage = GenericPage.<com.convertlab.macore.mamgt.cdp.dto.Profile>builder()
                    .current(-1)
                    .total(Optional.ofNullable(response.getTotal()).map(rs -> rs.intValue()).orElse(0))
                    .records(response.getRecords())
                    .build();
            return GenericPageResponse.<com.convertlab.macore.mamgt.cdp.dto.Profile>builder().pagination(profileGenericPage).build();
        } catch (BusinessException e) {
            log.error("Failed filterV4List ", e);
            throw e;
        } catch (Exception e) {
            log.error("failed filterV4List {}", request.toString(), e);
            throw new BusinessException(GENERAL_ERROR, "MSG_104_000002", "filterV4List failed to get profile data: " + profileName,
                    new String[]{profileName, e.getMessage()});
        }
    }

    @Operation(summary = "档案高级筛选数量查询", description = "支持档案高级筛选数量查询")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            content = @Content(mediaType = "application/json",
                    examples = {@ExampleObject(name = "request", summary = "request", value = "@examples/filter/convert_v2_to_v4_preview_req.json")})
    )
    @PostMapping(value = "{profileName}/previewCount")
    public GenericResponse<Long> filterV4Count(@PathVariable @Parameter(name = "profileName", description = "档案名", example = "customer")
                                                       String profileName,
                                               @RequestBody Preview<FilterV4VO> filterV4) {
        try {
            log.info("previewCount request is {}", JsonUtils.instance().obj2Json(filterV4));
            FilterV4VO viewModel = Optional.ofNullable(filterV4.getFilters().getV4())
                    .orElseGet(() -> {
                        Optional<String> selectOptional = Optional.ofNullable(filterV4.getSelect());
                        filterV4.setSelect(selectOptional.orElse("id"));
                        String request = JsonUtils.instance().obj2Json(filterV4);
                        try {
                            return filterV4Service.convertFilterV2ToViewModel(profileName, request);
                        } catch (Exception e) {
                            log.error("failed convertFilterV2ToViewModel {}", request, e);
                            return null;
                        }
                    });
            log.info("previewCount viewModel is {}", JsonUtils.instance().obj2Json(viewModel));
            filterV4.getFilters().setV4(viewModel);
            Long response = filterV4Service.filterV4Count(profileName, filterV4);
            log.info("previewCount response is {}", JsonUtils.instance().obj2Json(response));
            return GenericResponse.<Long>builder().result(response).build();
        } catch (BusinessException e) {
            log.error("Failed filterV4List ", e);
            throw e;
        } catch (Exception e) {
            log.error("failed filterV4Count {}", filterV4.toString(), e);
            throw new BusinessException(GENERAL_ERROR, "MSG_104_000002", "filterV4Count failed to get profile count: " + profileName,
                    new String[]{profileName, e.getMessage()});
        }
    }


    @Operation(summary = "UDO时间轴高级筛选列表查询", description = "支持UDO的时间轴高级筛选数据查询")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            content = @Content(mediaType = "application/json",
                    examples = {@ExampleObject(name = "request", summary = "request", value = "@examples/filter/filter_v4_preview_req.json")})
    )
    @ApiResponse(content = @Content(
            mediaType = "application/json",
            examples = {@ExampleObject(name = "response", summary = "返回结果", value = "@examples/filter/filter_v4_preview_res.json"),
                    @ExampleObject(name = "response2", summary = "含有可选项的返回结果", value = "@examples/filter/filter_v4_preview_with_options_res.json")}
    ))
    @PostMapping(value = "{profileName}/timeline")
    public GenericPageResponse<Profile> timeline(@PathVariable @Parameter(name = "profileName", description = "档案名称", example = "c_car")
                                                         String profileName,
                                                 @RequestBody Preview<FilterV4VO>
                                                         request) {
        try {
            FilterV4VO viewModel = Optional.ofNullable(request.getFilters().getV4())
                    .orElseGet(() -> {
                        Optional<String> selectOptional = Optional.ofNullable(request.getSelect());
                        if (profileName.equals(PROFILE_CUSTOMER)) {
                            request.setSelect(selectOptional.orElse("id"));
                        } else {
                            request.setSelect(selectOptional.orElse("bk"));
                        }
                        String reqStr = JsonUtils.instance().obj2Json(request);
                        try {
                            return filterV4Service.convertFilterV2ToViewModel(profileName, reqStr);
                        } catch (Exception e) {
                            log.error("failed convertFilterV2ToViewModel {}", reqStr, e);
                            return null;
                        }
                    });
            request.getFilters().setV4(viewModel);
            FilterResponse response = filterV4Service.filterV4List(profileName, request, true);
            filterV4Service.postHandlerForTimelineRsp(profileName, request, response);
            List<Profile> records = response.getRecords();
            List<Profile> dataList = new ArrayList<>();
            for (Profile record : records) {
                Object event = record.get("event");
                if (event == null) {
                    dataList.add(record);
                    continue;
                }
                Map<String, Object> map = BizMetaHelper.gdmFieldToBizField(record, profileName, event.toString(), BizMetaHelper.BizType.EVENT);
                dataList.add(new Profile(map));
            }
            //convert results to GenericPage
            GenericPage<Profile> profileGenericPage = GenericPage.<com.convertlab.macore.mamgt.cdp.dto.Profile>builder()
                    .current(-1)
                    .total(Optional.ofNullable(response.getTotal()).map(rs -> rs.intValue()).orElse(0))
                    .records(dataList)
                    .build();
            return GenericPageResponse.<com.convertlab.macore.mamgt.cdp.dto.Profile>builder().pagination(profileGenericPage).build();
        } catch (Exception e) {
            log.error("failed filterV4List {}", request.toString(), e.getMessage());
            throw new BusinessException(GENERAL_ERROR, "MSG_104_000002", "filterV4List failed to get profile data: " + profileName,
                    new String[]{profileName, e.getMessage()});
        }
    }

    @Operation(summary = "注册高级筛选插入点")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            content = @Content(mediaType = "application/json",
                    examples = {@ExampleObject(name = "request", description = "注册高级筛选插入点", value = "@examples/filter/register_meta.json")})
    )
    @RequestMapping(value = "meta/profiles/{profileName}/extension/register", method = RequestMethod.POST)
    public GenericResponse<FilterExtensionPoints> registerExtensionPoint(@PathVariable @Parameter(name = "profileName", description = "档案名", example = "customer")
                                                                                     String profileName,
                                                           @RequestBody FilterRegistrationRequest request) {
        try{
            if(StringUtils.isBlank(profileName)){
                throw new BusinessException(VALIDATION_ERROR, "MSG_104_000000", "Invalid profile name: " + profileName, new String[]{profileName});
            }
            FilterExtensionPoints response = filterMetaService.registerExtensionPoint(profileName, request);
            return GenericResponse.<FilterExtensionPoints>builder().result(response).build();
        } catch (BusinessException e) {
            log.error("Failed registerExtensionPoint ", e);
            throw e;
        } catch (Exception e) {
            log.error("failed registerExtensionPoint {}", request.toString(), e);
            throw new BusinessException(GENERAL_ERROR, "MSG_104_000100", "registerExtensionPoint failed: " + profileName,
                    new String[]{profileName, e.getMessage()});
        }
    }

    @DeleteMapping("/meta/{profileName}/extension/{groupName}")
    @Operation(summary = "删除高级筛选插入点")
    public GenericResponse<FilterExtensionPoints> deleteExtensionPoint(@PathVariable String profileName, @PathVariable String groupName) {
        try{
            FilterExtensionPoints response = filterMetaService.removeExtensionPoint(profileName, groupName);
            return GenericResponse.<FilterExtensionPoints>builder().result(response).build();
        } catch (BusinessException e) {
            log.error("Failed deleteExtensionPoint ", e);
            throw e;
        } catch (Exception e) {
            log.error("failed deleteExtensionPoint {} groupName: {}", profileName, groupName, e);
            throw new BusinessException(GENERAL_ERROR, "MSG_104_000101", "deleteExtensionPoint failed: " + profileName + " groupName: " + groupName,
                    new String[]{groupName, e.getMessage()});
        }
    }

    @Operation(summary = "加密筛选条件中的数据字段")
    @PostMapping("/{profileName}/encryptQueryParameter")
    public GenericResponse<String> encryptQueryParameter(@ResourceIdentifier @PathVariable("profileName") String profileName,
                                                         @RequestBody EncryptQueryParameterRequest request) {
        if(request == null || StringUtils.isBlank(request.getValue())) {
            throw new BusinessException(GENERAL_ERROR, "MSG_104_000102", "encryptQueryParameter failed: " + profileName + "due to invalid input :"
                    +JsonUtils.instanceOfDto().obj2Json(request),
                    new String[]{});
        }

        if(request.getValue().startsWith("enc:")){
            // 已经是密文无需重复加密
            return GenericResponse.<String>builder().result(request.getValue()).build();
        }
        try{
            String result = filterV4Service.encryptQueryParameter(profileName, request.getPropertyFieldName(), request.getCategory(),
                    request.getValue());
            return GenericResponse.<String>builder().result(result).build();
        } catch (BusinessException e) {
            log.error("Failed encryptQueryParameter ", e);
            throw e;
        } catch (Exception e) {
            log.error("failed encryptQueryParameter {} groupName: {}", profileName, e);
            throw new BusinessException(GENERAL_ERROR, "MSG_104_000102", "encryptQueryParameter failed: ",
                    new String[]{});
        }
    }
}
