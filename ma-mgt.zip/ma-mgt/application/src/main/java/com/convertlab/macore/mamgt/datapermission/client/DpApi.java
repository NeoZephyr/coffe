package com.convertlab.macore.mamgt.datapermission.client;

import com.convertlab.macore.mamgt.common.utils.NamingUtils;
import com.convertlab.macore.mamgt.datapermission.model.DpDatapermissionRuleDto;
import com.convertlab.macore.mamgt.datapermission.model.DpRuleSparkResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

public interface DpApi {

    @GetMapping("/dp/acl/setting/rules")
    List<DpDatapermissionRuleDto> listRule(@RequestParam(name = "profile", defaultValue = "") String profile,
                                           @RequestParam(name = "pageNum", defaultValue = "1") Integer pageNum,
                                           @RequestParam(name = "pageSize", defaultValue = "50") Integer pageSize);

    @PostMapping("/dp/acl/setting/rule")
    DpDatapermissionRuleDto saveRule(@RequestBody DpDatapermissionRuleDto data);

    @PutMapping("/dp/acl/setting/rule/{ruleId}")
    DpDatapermissionRuleDto updateRule(@RequestParam(name = "ruleId") Long ruleId, @RequestBody DpDatapermissionRuleDto data);

    @PutMapping("/dp/acl/setting/rule/{ruleId}/status")
    DpDatapermissionRuleDto updateRuleStatus(@RequestParam(name = "ruleId") Long ruleId, @RequestBody DpRuleSparkResult data);

    @DeleteMapping("/dp/acl/setting/rule/{ruleId}")
    DpDatapermissionRuleDto deleteRule(@RequestParam(name = "ruleId") Long ruleId);

    @GetMapping("/dp/aclmeta/")
    List<Map<String, Object>> _getAclMetaByGroup(@RequestParam(name = "group") String group);

    default List<Map<String, Object>> getAclMetaByGroup(@RequestParam(name = "group") String group) {
        return _getAclMetaByGroup(NamingUtils.toLowerUnderScoreCase(group));
    }

    @GetMapping("/dp/aclmeta/")
    List<Map<String, Object>> getAclMetaByObjectList(@RequestParam(name = "objectNames") String objectNames);

}
