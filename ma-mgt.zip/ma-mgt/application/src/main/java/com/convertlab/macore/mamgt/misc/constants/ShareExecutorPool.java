package com.convertlab.macore.mamgt.misc.constants;

import com.convertlab.foundation.library.support.ExecutorUtils;

import java.util.concurrent.Executor;

/**
 * @author Mr.黄
 * @description
 * @since 2024/04/08 19:36
 **/
public class ShareExecutorPool {
    private static volatile ShareExecutorPool shareExecutorPool = null;
    public final Executor shareExecutor = ExecutorUtils.createMdcTtlExecutor("preloadCacheHandlerTask", 3);

    private ShareExecutorPool() {
    }

    public static ShareExecutorPool getShareExecutor() {
        if (shareExecutorPool == null) {
            synchronized (ShareExecutorPool.class) {
                if (shareExecutorPool == null) {
                    shareExecutorPool = new ShareExecutorPool();
                }
            }
        }
        return shareExecutorPool;
    }
}
