package com.convertlab.macore.mamgt.datapermission.model;

import io.swagger.v3.oas.annotations.Hidden;
import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Data
public class DpDatapermissionRuleDto implements Serializable {

    @Hidden
    private Long id;
    private String name;
    private Map<String, Object> filter;
    private List<String> deptCodes;
    @Hidden
    private String status;
    private String profileName;

    @Hidden
    private Map<String, Object> ignoredBusinessInfo;

}
