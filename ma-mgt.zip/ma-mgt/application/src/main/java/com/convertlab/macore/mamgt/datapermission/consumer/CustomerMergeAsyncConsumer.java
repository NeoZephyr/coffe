package com.convertlab.macore.mamgt.datapermission.consumer;

import com.convertlab.foundation.library.business.feature.FeatureClient;
import com.convertlab.foundation.library.datapermission.ListByResourcesDto;
import com.convertlab.foundation.library.datapermission.ResourceAccessDto;
import com.convertlab.foundation.library.datapermission.feign.ResourceAclClient;
import com.convertlab.foundation.library.datapermission.model.BatchResourceAccessDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class CustomerMergeAsyncConsumer {

    final FeatureClient featureClient;

    final ResourceAclClient resourceAclClient;


    public CustomerMergeAsyncConsumer(FeatureClient featureClient, ResourceAclClient resourceAclClient) {
        this.featureClient = featureClient;
        this.resourceAclClient = resourceAclClient;
    }

    /**
     *     {
     *        {
     *     		"fromIds": [1367977741747582976],
     *     		"toId": 1375586624381057024,
     *     		"tenantId": 5233,
     *     		"upstream": "customer",
     *     		"requestId": "0210305bb5ea8a2cdbdaa506df59086e"
     *        }
     *     }
     */

    @KafkaListener(
            topics = "${kafka.profileEventGroup.customerMergeAsync.topic}",
            groupId = "${kafka.profileEventGroup.customerMergeAsync.groupId}",
            concurrency = "${kafka.profileEventGroup.customerEventMerged.concurrency}")
    public void receive(@Nullable Map<String, Object> message) {
        log.info("receive customer merged message: {}", message);

        if (message.isEmpty()) {
            log.error("receive CustomerMerged message is null");
            return;
        }

        try {
            boolean featureEnabled = featureClient.checkToggleStatus("datapermission");
            if (featureEnabled) {
                //轮询messages，将每个message的fromIds和toId传入到datapermission服务的接口中
                Object fromIds =  message.get("fromIds");
                if (fromIds == null) {
                    log.error("receive CustomerMerged message fromIds is null");
                    return;
                }

                Object toId =  message.get("toId");
                if (toId == null) {
                    log.error("receive CustomerMerged message toId is null");
                    return;
                }

                //获得fromIds和toId
                List<Long> fromIdsLong = (List<Long>) fromIds;
                Long toIdLong = Long.valueOf(toId.toString());

                //调用resourceAclClient.listByResources()接口获取分享信息。
                List<ResourceAccessDto> results = getResourceAccessDtos(fromIdsLong, toIdLong);


                //找出增量部分，并调用resourceAclClient.batchSave()接口保存
                List<ResourceAccessDto> deltaList = getDeltaResourceAccessDtos(fromIdsLong, toIdLong,results);

                if (deltaList.isEmpty()) {
                    log.info("receive CustomerMerged message deltaList is empty");
                    return;
                }

                BatchResourceAccessDto dto = new BatchResourceAccessDto();
                dto.setResourceAclList(deltaList);
                dto.setResourceType("customer");
                resourceAclClient.batchSave(dto);
            }

        } catch (Exception e) {
            log.error("receive CustomerEventMerged message failed.", e);
        }

    }

    private List<ResourceAccessDto> getDeltaResourceAccessDtos(List<Long> fromIdsLong, Long toIdLong, List<ResourceAccessDto> aclList) {

        List<ResourceAccessDto> deltaList = new ArrayList<>();
        List<ResourceAccessDto> fromIdResourceList = new ArrayList<>();
        List<ResourceAccessDto> toIdResourceList = new ArrayList<>();

        //将acllist分类
        aclList.forEach(result -> {
            if (result.getResourceCode().equals(toIdLong.toString())) {
                toIdResourceList.add(result);
            } else {
                fromIdResourceList.add(result);
            }
        });

        //对于fromIdResourceList，如果fromIdResourceList中的resourceCode在toIdResourceList中不存在，则将其加入到deltaList中
        for (ResourceAccessDto fromIdResource : fromIdResourceList) {
            boolean isExist = false;
            for (ResourceAccessDto toIdResource : toIdResourceList) {
                if (fromIdResource.getGrantedSubjectType().equals(toIdResource.getGrantedSubjectType())
                        && fromIdResource.getGrantedSubjectCode().equals(toIdResource.getGrantedSubjectCode())
                        && fromIdResource.getGrantedReason().equals(toIdResource.getGrantedReason())
                )
                {
                    isExist = true;
                    break;
                }
            }

            if (!isExist) {
                fromIdResource.setResourceCode(toIdLong.toString());
                deltaList.add(fromIdResource);
            }
        }

        return deltaList;
    }

    private List<ResourceAccessDto> getResourceAccessDtos(List<Long> fromIdsLong, Long toIdLong) {
        //将fromIdsLong和toIdLong传入到resourceAclClient.listByResources()中
        ListByResourcesDto dto = new ListByResourcesDto();
        dto.setResourceType("customer");
        dto.setResourceCodeList(new ArrayList<String>());

        //将fromIdsLong传入到dto.getResourceCodeList()中
        for (Long fromIdLong : fromIdsLong) {
            dto.getResourceCodeList().add(fromIdLong.toString());
        }

        //将toIdLong传入到dto.getResourceCodeList()中
        dto.getResourceCodeList().add(toIdLong.toString());

        //调用resourceAclClient.listByResources()接口
        List<ResourceAccessDto> results = resourceAclClient.listByResources(dto);
        return results;
    }
}
