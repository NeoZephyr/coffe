package com.convertlab.macore.mamgt.misc.annotation;

import java.lang.annotation.*;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface EnableL2RedisLocalCaching {
}
