package com.convertlab.macore.mamgt.cdp.service;

/**
 * @author Mr.黄
 * @description
 * @since 2023/07/19 15:58
 **/
public interface FeatureService {
    String getLimit(String featureName);
}
