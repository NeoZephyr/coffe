package com.convertlab.macore.mamgt.cdp.service;

import com.convertlab.macore.mamgt.cdp.ProfileQuery;
import com.convertlab.macore.mamgt.cdp.TraitQuery;

import java.util.List;

public interface TraitMemberService {
    List<TraitQuery.TraitListResponseVo> getTraitMemberCount(String profileName, String traitIds, Boolean isStatic);

    ProfileQuery.ProfileResponseVo getTraitMemberList(String profileName, String traitId, String select, String startId, int rows);
}
