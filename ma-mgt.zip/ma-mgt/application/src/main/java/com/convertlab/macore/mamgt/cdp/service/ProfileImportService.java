package com.convertlab.macore.mamgt.cdp.service;

import com.convertlab.macore.mamgt.cdp.model.entity.UdoDataImportTask;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.*;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;

public interface ProfileImportService {

    TaskListResponse listProfileImportHistory(String profileName, String startId, String sort, Integer limit);

    SaveTaskResponse saveTask(String profileName, Long listId, SaveTaskRequest.Attachments attachments) throws InvocationTargetException, IllegalAccessException;

    MatchResponse match(String profileName, int attachId);


    Map<String,Object> getProfileImportTask(Long id);

    Map<String, Object> startTask(long id, String profileName, StartTaskRequest request) throws JsonProcessingException;

    RowsLimitResponse getRowsLimit();

    void afterImportDataComplete(Map<String, Object> messageMap);

    void bulkSaveOrUpdateProfileData(String profileName, List<Map<String, Object>> rows, String dataType);

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class TaskListResponse {
        private Long total;
        private Integer size;
        private List<UdoDataImportTask> records;

    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class MatchResponse {
        private List<Map<String, Object>> match;
        private List<Map<String, Object>> notMatch;
        private Integer countNum;

    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class SaveTaskRequest {
        private Attachments attachments;

        private Map<String, Object> settings;

        @Data
        @NoArgsConstructor
        @AllArgsConstructor
        @Builder
        public static class Attachments{
            private Map<String, String> matchInfo;
            private int attachmentId;
            private String hdfsPath;
            private String fileName;
            private int allCount;
            private String uuid;
        }

    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @EqualsAndHashCode(callSuper=false)
    public static class SaveTaskResponse extends UdoDataImportTask {
        private String failedAttachmentPath;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @EqualsAndHashCode(callSuper=false)
    public static class StartTaskRequest extends UdoDataImportTask {
        private String failedAttachmentPath;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class RowsLimitResponse {
        private int rowsLimit;
    }

    enum DataCountType {
        SUCCESS("success", "successCount"),
        FAIL("failed", "failedCount"),
        HANDLE("handle", "handleCount"),
        ALL("all", "allCount"),
        RECV("recv", "recvCount"),
        SEND("send", "sendCount"),
        NOT_SEND("notSend", "notSendCount");

        private DataCountType(String name, String desp) {
            this.name = name;
            this.desp = desp;
        }

        public String name;
        public String desp;
    }

}
