package com.convertlab.macore.mamgt.misc.configure;

import com.convertlab.common.crypto.client.CryptoClient;
import com.convertlab.foundation.api.gdm.pattern.GdmModelClient;
import com.convertlab.foundation.api.gdm.pattern.facade.GdmProfileEventClient;
import com.convertlab.foundation.library.business.feature.FeatureClient;
import com.convertlab.foundation.library.business.feature.JdbcFeatureClient;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClientWrapper;
import com.convertlab.foundation.library.gdmmeta.client.GsncMetaClient;
import com.convertlab.foundation.library.webmvc.access.PermissionValidator;
import com.convertlab.foundation.library.webmvc.property.ExtraWebMvcMultiTenancyProperties;
import com.convertlab.macore.api.permissions.autoconfigure.BffSecurityConfig;
import com.convertlab.macore.mamgt.cdp.client.GdmModelClientWrapper;
import com.convertlab.macore.mamgt.cdp.mapper.CustomerSearchMapper;
import com.convertlab.macore.mamgt.cdp.mapper.DpDatapermissionRuleMapper;
import com.convertlab.macore.mamgt.cdp.mapper.LegacyUdoFieldMetaMapper;
import com.convertlab.macore.mamgt.cdp.mapper.ListRuleMapper;
import com.convertlab.macore.mamgt.cdp.mapper.TagRuleMapper;
import com.convertlab.macore.mamgt.cdp.misc.loader.legacy.LegacyMetaLoader;
import com.convertlab.macore.mamgt.cdp.service.validation.ProfileValidator;
import com.convertlab.macore.mamgt.misc.advice.I18nAspect;
import com.convertlab.macore.mamgt.misc.advice.*;
import com.convertlab.macore.mamgt.misc.interceptor.UserLanguageInterceptor;
import com.zaxxer.hikari.HikariDataSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.*;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.annotation.Nonnull;
import javax.sql.DataSource;
import javax.validation.constraints.NotNull;

@Configuration("macoreAutoConfiguration")
@EnableAspectJAutoProxy
@Slf4j
public class MacoreAutoConfiguration {

    @NotNull
    @Bean
    @ConditionalOnMissingBean
    public PermissionValidator permissionValidator() {
        return new BffSecurityConfig();
    }


    @Bean
    @ConditionalOnMissingBean
    public GdmProfileEventClient profileEventClient(@Qualifier("gsMetaClient") GsMetaClient gsMetaClient) {
        return new GdmProfileEventClient(gsMetaClient);

    }

    @Bean("gdmModelClientWrapper")
    @ConditionalOnMissingBean
    public GdmModelClientWrapper gdmModelClient(@Qualifier("gsMetaClient") GsMetaClient gdmModelMetaClient, GdmProfileEventClient profileEventClient) {
        // 用GdmModelClientWrapper包装foundation的GdmModelClient，是为了自动对findByName方法的参数进行转换，符合
        // GDM对象命名规则 https://confluence.xiaoshu.biz/pages/viewpage.action?pageId=154438460
        // e.g gsMetaClient.findByName("c_Auto")  将被自动转义为 gsMetaClient.findByName("c_auto")
        return new GdmModelClientWrapper(gdmModelMetaClient, profileEventClient);
    }

    @Bean("gsMetaClientWrapper")
    public GsMetaClientWrapper gsMetaClientWrapper(@Nonnull @Qualifier("gsMetaClient") GsMetaClient gsMetaClient) {
        // 用GdmModelClientWrapper包装foundation的GdmModelClient，是为了自动对findByName方法的参数进行转换，符合
        // GDM对象命名规则 https://confluence.xiaoshu.biz/pages/viewpage.action?pageId=154438460
        // e.g gsMetaClientWrapper.getEntity("c_Auto")  将被自动转义为 gsMetaClient.getEntity("c_auto")
        return new GsMetaClientWrapper(gsMetaClient);
    }

    @Nonnull
    @Bean
    @ConditionalOnMissingBean
    public CryptoClient cryptoClient(@Value("${keyAdapter.serverUrl}") String keyAdapterServerUrl) {
        CryptoClient client = CryptoClient.getInstance();
        client.setUrl(keyAdapterServerUrl);
        return client;
    }

    @Bean
    public ProfileValidator profileValidator(@Qualifier("gsncMetaClient") GsncMetaClient gsMetaClient, GdmModelClient gdmModelClient,
                                             LegacyUdoFieldMetaMapper legacyUdoFieldMetaMapper, TagRuleMapper tagRuleMapper, ListRuleMapper listRuleMapper,
                                             CustomerSearchMapper customerSearchMapper, DpDatapermissionRuleMapper dpDatapermissionRuleMapper,
                                             LegacyMetaLoader legacyMetaLoader) {
        return new ProfileValidator(gsMetaClient, gdmModelClient, legacyUdoFieldMetaMapper,
                tagRuleMapper, listRuleMapper, customerSearchMapper, dpDatapermissionRuleMapper, legacyMetaLoader );
    }

    @Bean(name = "mainDataSource")
    @ConfigurationProperties(prefix = "spring.datasource.main")
    public DataSource mainDataSource() {
        return DataSourceBuilder.create().type(HikariDataSource.class).build();
    }

    @Bean("jdbcFeatureClient")
    @Primary
    public FeatureClient jdbcFeatureClient(@Qualifier("mainDataSource") DataSource dataSource) {
        return new JdbcFeatureClient(new JdbcTemplate(dataSource));
    }

    @Bean
    @ConditionalOnMissingBean
    BffResponseBodyAdvice maViewResponseBodyAdvice() {
        return new BffResponseBodyAdvice();
    }

    @Bean
    @ConditionalOnMissingBean
    RunTimeOnlyAspect runTimeOnlyAspect() {
        return new RunTimeOnlyAspect();
    }

    @Bean
    @ConditionalOnMissingBean
    CdpApiRouteAspect cdpApiRouteAspect(FeatureClient featureClient) {
        return new CdpApiRouteAspect(featureClient);
    }

    @Bean
    @ConditionalOnMissingBean
    UserLanguageInterceptor userLanguageInterceptor(ExtraWebMvcMultiTenancyProperties properties,
                                                    @Value("${convertlab.language.default:zh-CN}") String defaultLanguage,
                                                    @Value("${convertlab.language.supported.languages:zh-CN,en-US}") String supportedLanguages) {
        return new UserLanguageInterceptor(properties, defaultLanguage, supportedLanguages);
    }

    @Bean
    @ConditionalOnMissingBean
    I18nAspect bizMetaI18nAspect(@Value("${convertlab.language.supported.languages:zh-CN,en-US}") String supportedLanguages,
                                 @Value("${convertlab.language.default:zh-CN}") String defaultLanguage)
            throws InstantiationException {
        return new I18nAspect(supportedLanguages, defaultLanguage);
    }
}
