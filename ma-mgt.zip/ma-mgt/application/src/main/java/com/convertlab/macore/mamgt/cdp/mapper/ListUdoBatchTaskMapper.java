package com.convertlab.macore.mamgt.cdp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.cdp.model.entity.ListUdoBatchTask;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import java.util.Date;
import java.util.List;

@Mapper
public interface ListUdoBatchTaskMapper extends BaseMapper<ListUdoBatchTask> {
    @Select({"<script>",
            "SELECT * ",
            " FROM list_udo_batch_task WHERE  user_id = #{userId} ",
            " <if test=\"profileName != null and profileName != ''\" > ",
            " AND obj_id = #{profileName} ",
            " </if>",
            " <if test=\"fromDate != null\" > ",
            " AND date_created >= #{fromDate} ",
            " </if>",
            " <if test=\"taskType != null and taskType != ''\" > ",
            " AND task_type = #{taskType} ",
            " </if>",
            " ORDER BY ${sidx} ${sort} ",
            " LIMIT #{offset},#{rows} ",
            "</script>"})
    @ResultType(ListUdoBatchTask.class)
    List<ListUdoBatchTask> getTaskList(@Param("profileName") String profileName,
                                            @Param("taskType") String taskType,
                                            @Param("userId") Long userId,
                                            @Param("fromDate") Date fromDate,
                                            @Param("sort") String sort,
                                            @Param("sidx") String sidx,
                                            @Param("rows") Integer rows,
                                            @Param("offset") Integer offset);

    @Select({"<script>",
            "SELECT count(1) ",
            " FROM list_udo_batch_task WHERE  user_id = #{userId} ",
            " <if test=\"profileName != null and profileName != ''\" > ",
            " AND obj_id = #{profileName} ",
            " </if>",
            " <if test=\"fromDate != null\" > ",
            " AND date_created >= #{fromDate} ",
            " </if>",
            " <if test=\"taskType != null and taskType != ''\" > ",
            " AND task_type = #{taskType} ",
            " </if>",
            "</script>"})
    @ResultType(java.lang.Integer.class)
    Integer getTaskCount(@Param("profileName") String profileName,
                                       @Param("taskType") String taskType,
                                       @Param("userId") Long userId,
                                       @Param("fromDate") Date fromDate);
}
