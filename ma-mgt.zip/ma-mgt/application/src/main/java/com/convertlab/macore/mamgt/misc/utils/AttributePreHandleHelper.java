package com.convertlab.macore.mamgt.misc.utils;

import com.convertlab.cache.util.SimpleJacksonUtils;
import com.convertlab.foundation.library.model.GenericPage;
import com.convertlab.foundation.library.model.vo.GenericListResponse;
import com.convertlab.foundation.library.model.vo.GenericPageResponse;
import com.convertlab.foundation.library.model.vo.GenericResponse;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.mamgt.cdp.meta.service.ProfileMetaService;
import com.convertlab.macore.mamgt.cdp.service.ProfileMaskService;
import com.convertlab.macore.mamgt.misc.service.AttributePreHandleService;
import com.convertlab.macore.mamgt.misc.service.impl.BkMaskPreHandleServiceImpl;
import com.convertlab.macore.mamgt.misc.service.impl.RepeatReadRequest;
import com.fasterxml.jackson.core.type.TypeReference;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import lombok.Getter;
import lombok.Setter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.CollectionUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Slf4j
public class AttributePreHandleHelper {
    private static final String LOG_PREFIX = "<ma-mgt> <AttributePreHandleHelper>";

    private static final ThreadLocal<AttributeContext> threadLocal = new ThreadLocal<>();

    private static final List<AttributePreHandleService> handleServiceList = new ArrayList<>();
    private static Map<String, AttributeHandleConfig> configMap;

    public static void init(ProfileMaskService profileMaskService, ProfileMetaService profileMetaService) {
        if (!CollectionUtils.isEmpty(handleServiceList)) {
            return;
        }
        handleServiceList.add(new BkMaskPreHandleServiceImpl(profileMaskService, profileMetaService));
    }

    /**
     * 根据请求获取配置
     *
     * @param request 请求对象
     * @return
     */
    public static AttributeHandleConfig getConfigByPath(HttpServletRequest request) {
        String requestURI = request.getRequestURI();
        String method = request.getMethod();
        return getConfig(method, requestURI);
    }

    /**
     * 处理请求参数
     *
     * @param request  请求对象
     * @param response 响应对象
     * @return 是否继续
     * @throws ServletException
     * @throws IOException
     */
    public static boolean requestBeforeHandle(RepeatReadRequest request, HttpServletResponse response) throws ServletException, IOException {
        threadLocal.set(null);
        String requestURI = request.getRequestURI();
        String method = request.getMethod();
        AttributeHandleConfig config = getConfig(method, requestURI);
        if (config == null) {
            return true;
        }
        AttributeContext attributeContext = new AttributeContext();
        attributeContext.setConfig(config);
        threadLocal.set(attributeContext);
        //处理参数属性
        for (AttributePreHandleService handleService : handleServiceList) {
            List<AttributeInfo> requestConfigs = getListByHandle(config.getRequest(), handleService.getHandleType());
            //使用前先清理对象
            attributeContext.setRequestVariable(null);
            //获取请求里的变量参数
            Map<String, Object> requestVariable = getRequestVariable(request, config);
            attributeContext.setRequestVariable(requestVariable);
            try {
                if (!handleService.handleRequest(request, response, attributeContext, requestConfigs)) {
                    return false;
                }
            } catch (Exception e) {
                log.error("{} handleRequest have a error . method:{} ,requestURI:{} ,responseConfigs:{} ,context:{} ", LOG_PREFIX, request.getMethod(), request.getRequestURI(), requestConfigs, attributeContext, e);
            }
        }
        return true;
    }

    /**
     * 处理响应数据
     *
     * @param responseBody 响应的数据对象
     * @param request      请求对象
     * @param response     响应对象
     * @return
     */
    public static Object requestAfterHandle(Object responseBody, HttpServletRequest request, HttpServletResponse response) {
        AttributeContext attributeContext = threadLocal.get();
        if (attributeContext == null || attributeContext.getConfig() == null) {
            return responseBody;
        }
        try {
            if (isBaseDataType(responseBody)) {
                return responseBody;
            } else if (responseBody instanceof GenericResponse) {
                Object body = ((GenericResponse) responseBody).getResult();
                Map<String, Object> dataMap = JsonUtils.instance().convertToMap(body);
                ((GenericResponse) responseBody).setResult(handleResponse(dataMap, request, response, attributeContext));
            } else if (responseBody instanceof GenericListResponse) {
                Object body = ((GenericListResponse) responseBody).getResults();
                List<Map> mapList = JsonUtils.instance().json2List(JsonUtils.instance().obj2Json(body), Map.class);
                handleResponse(mapList, request, response, attributeContext);
                ((GenericListResponse) responseBody).setResults(mapList);
            } else if (responseBody instanceof GenericPageResponse) {
                GenericPage pagination = ((GenericPageResponse) responseBody).getPagination();
                if (pagination == null) {
                    return responseBody;
                }
                Object body = pagination.getRecords();
                List<Map> mapList = JsonUtils.instance().json2List(JsonUtils.instance().obj2Json(body), Map.class);
                handleResponse(mapList, request, response, attributeContext);
                pagination.setRecords(mapList);
            } else if (responseBody instanceof Map || responseBody instanceof List) {
                handleResponse(responseBody, request, response, attributeContext);
            }
        } catch (ServletException | IOException e) {
            log.error("{} requestAfterHandle stop . have a error . responseBody:{}", LOG_PREFIX, JsonUtils.instance().obj2Json(responseBody), e);
        } finally {
            threadLocal.set(null);
        }
        return responseBody;
    }

    /**
     * 对象转指定编码的json字符串
     *
     * @param data 数据对象
     * @return 指定编码的json字符串
     */
    public static String objectToString(Object data) {
        try {
            return objectToString(data, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            log.error("{} objectToString error .", LOG_PREFIX, e);
        }
        return JsonUtils.instance().obj2Json(data);
    }

    /**
     * 对象转指定编码的json字符串
     *
     * @param data              数据对象
     * @param characterEncoding 编码类型
     * @return 指定编码的json字符串
     * @throws UnsupportedEncodingException
     */
    public static String objectToString(Object data, String characterEncoding) throws UnsupportedEncodingException {
        String str = JsonUtils.instance().obj2Json(data);
        if (StringUtils.isNotBlank(characterEncoding) && !characterEncoding.equalsIgnoreCase(StandardCharsets.UTF_8.name())) {
            return new String(str.getBytes(StandardCharsets.UTF_8), characterEncoding);
        }
        return str;
    }

    /**
     * 获取请求里的变量参数
     *
     * @param request 请求对象
     * @param config  变量参数配置
     * @return 变量参数
     */
    public static Map<String, Object> getRequestVariable(RepeatReadRequest request, AttributeHandleConfig config) {
        List<AttributeInfo> variables = config.getVariable();
        if (CollectionUtils.isEmpty(variables)) {
            return null;
        }
        String requestURI = request.getRequestURI();
        Map<String, Object> variableMap = new HashMap<>();
        for (AttributeInfo variable : variables) {
            List<String> names = variable.getNames();
            if (ParamType.REQUEST_PATH == variable.getType()) {
                Map<String, String> urlParamMap = getMatchUrlParamMap(config.getPath(), requestURI);
                for (Map.Entry<String, String> paramMap : urlParamMap.entrySet()) {
                    if (names.contains("*") || names.contains(paramMap.getKey())) {
                        variableMap.put(paramMap.getKey(), paramMap.getValue());
                    }
                }
            } else if (ParamType.REQUEST_HEADER == variable.getType()) {
                Enumeration<String> headerNames = request.getHeaderNames();
                while (headerNames.hasMoreElements()) {
                    String key = headerNames.nextElement();
                    AtomicReference<String> name = new AtomicReference<>();
                    if (names.contains("*")) {
                        variableMap.put(key, request.getHeader(key));
                    } else if (names.stream().anyMatch(s -> {
                        if (s.equalsIgnoreCase(key)) {
                            name.set(s);
                            return true;
                        } else {
                            return false;
                        }
                    })) {
                        variableMap.put(name.get(), request.getHeader(key));
                    }
                }
            } else if (ParamType.REQUEST_QUERY == variable.getType()) {
                Map<String, String[]> parameterMap = request.getParameterMap();
                if (parameterMap == null || parameterMap.isEmpty()) {
                    continue;
                }
                for (Map.Entry<String, String[]> map : parameterMap.entrySet()) {
                    if (names.contains("*") || names.contains(map.getKey())) {
                        variableMap.put(map.getKey(), map.getValue());
                    }
                }
            } else if (ParamType.REQUEST_BODY == variable.getType()) {
                try {
                    Object requestBodyObject = request.getRequestBodyObject();
                    if (requestBodyObject instanceof List || requestBodyObject instanceof Map) {
                        String jsonPath = variable.getJsonPath();
                        Function<Object, Object> filter = data -> data;
                        if (!StringUtils.isBlank(jsonPath)) {
                            filter = data -> getObjectByJsonPath(data, jsonPath);
                        }
                        handleDataAttribute(requestBodyObject, filter, (object, objType, key, val) -> {
                            variableMap.put(key, val);
                            return val;
                        }, names.toArray(new String[0]));
                    }
                } catch (IOException e) {
                    log.error("{} getRequestVariable have a error . config:{}", LOG_PREFIX, JsonUtils.instance().obj2Json(config));
                }
            }
        }
        return variableMap;
    }

    /**
     * 基础处理请求参数的方法
     *
     * @param request        请求对象
     * @param response       响应对象
     * @param config         处理配置
     * @param requestConfigs 处理详细配置
     * @param handle         处理函数
     * @return 是否继续进行接下来的流程
     * @throws ServletException
     * @throws IOException
     */
    public static Boolean baseHandleRequest(RepeatReadRequest request, HttpServletResponse response, AttributeHandleConfig config, List<AttributeInfo> requestConfigs, DataHandle handle) throws ServletException, IOException {
        boolean needForward = false;
        String forwardPath = request.getRequestURI();
        if (CollectionUtils.isEmpty(requestConfigs)) {
            return true;
        }
        for (AttributeInfo requestConfig : requestConfigs) {
            List<String> names = requestConfig.getNames();
            if (ParamType.REQUEST_PATH == requestConfig.getType()) {
                Map<String, String> urlParamMap = getMatchUrlParamMap(config.getPath(), forwardPath);
                Map<String, Object> urlParamMapCopy = new HashMap<>(urlParamMap);
                for (Map.Entry<String, String> paramMap : urlParamMap.entrySet()) {
                    if (names.contains("*") || names.contains(paramMap.getKey())) {
                        String value = paramMap.getValue();
                        Object apply = handle.handle(urlParamMapCopy, ObjType.MAP, paramMap.getKey(), value);
                        if (!(apply == null && value == null) || (value != null && !value.equals(apply.toString()))) {
                            urlParamMapCopy.put(paramMap.getKey(), apply == null ? null : apply.toString());
                        }
                    }
                }
                forwardPath = buildUrlByParam(config.getPath(), urlParamMapCopy);
                if (!request.getRequestURI().equals(forwardPath)) {
                    needForward = true;
                }
            } else if (ParamType.REQUEST_QUERY == requestConfig.getType()) {
                Map<String, String[]> parameterMap = request.getParameterMap();
                if (parameterMap == null || parameterMap.isEmpty()) {
                    continue;
                }
                Map<String, Object> parameterMapCopy = new HashMap<>(parameterMap);
                for (Map.Entry<String, String[]> map : parameterMap.entrySet()) {
                    String[] values = map.getValue();
                    if (names.contains("*") || names.contains(map.getKey())) {
                        Object apply = handle.handle(parameterMapCopy, ObjType.MAP, map.getKey(), values);
                        if (apply != null && apply.getClass().isArray() && Arrays.equals(values, (String[]) apply)) {
                            parameterMapCopy.put(map.getKey(), apply);
                        } else if (!(apply == null && values == null) || (apply != null && !apply.getClass().isArray())) {
                            parameterMapCopy.put(map.getKey(), apply);
                        }
                    }
                }
                for (Map.Entry<String, Object> mapCopy : parameterMapCopy.entrySet()) {
                    parameterMap.put(mapCopy.getKey(), (String[]) mapCopy.getValue());
                }
            } else if (ParamType.REQUEST_BODY == requestConfig.getType()) {
                Object requestBodyObject = request.getRequestBodyObject();
                if (requestBodyObject instanceof List || requestBodyObject instanceof Map) {
                    String jsonPath = requestConfig.getJsonPath();
                    Function<Object, Object> filter = data -> data;
                    if (!StringUtils.isBlank(jsonPath)) {
                        filter = data -> getObjectByJsonPath(data, jsonPath);
                    }
                    handleDataAttribute(requestBodyObject, filter, handle, names.toArray(new String[0]));
                    request.setRequestBody(JsonUtils.instance().obj2Json(requestBodyObject));
                } else {
                    continue;
                }
            }
        }
        if (needForward) {
            log.info("{} baseHandleRequest forward start . method:{} ,path:{} ,forwardPath:{} config:{}", LOG_PREFIX, request.getMethod(), request.getRequestURI(), forwardPath, JsonUtils.instance().obj2Json(config));
            request.getRequestDispatcher(forwardPath).forward(request, response);
            return false;
        }
        return true;
    }

    private static Object handleResponse(Object data, HttpServletRequest request, HttpServletResponse response, AttributeContext context) throws ServletException, IOException {
        for (AttributePreHandleService handleService : handleServiceList) {
            List<AttributeInfo> responseConfigs = getListByHandle(context.getConfig().getResponse(), handleService.getHandleType());
            try {
                handleService.handleResponse(data, request, response, context, responseConfigs);
            } catch (Exception e) {
                log.error("{} handleResponse have a error . method:{} ,requestURI:{} ,responseConfigs:{} ,context:{} ,data:{}", LOG_PREFIX, request.getMethod(), request.getRequestURI(), JsonUtils.instance().obj2Json(responseConfigs), JsonUtils.instance().obj2Json(context), JsonUtils.instance().obj2Json(data), e);
            }
        }
        return data;
    }

    /**
     * 基础处理响应结果的方法
     *
     * @param data            要处理的数据（Map或List<Map> ）
     * @param responseConfigs 处理详细配置
     * @param handle          处理函数
     * @param attributeNames  要处理的属性名称列表
     * @return 处理后的对象
     * @throws ServletException
     * @throws IOException
     */
    public static Object baseHandleResponse(Object data, List<AttributeInfo> responseConfigs, DataHandle handle, String... attributeNames) {
        if (CollectionUtils.isEmpty(responseConfigs)) {
            return data;
        }
        if (data instanceof List || data instanceof Map) {
            for (AttributeInfo responseConfig : responseConfigs) {
                String jsonPath = responseConfig.getJsonPath();
                Function<Object, Object> filter = val -> val;
                if (!StringUtils.isBlank(jsonPath)) {
                    filter = val -> getObjectByJsonPath(val, jsonPath);
                }
                Set<String> nameList = new HashSet<>(responseConfig.getNames());
                if (attributeNames != null) {
                    for (String name : attributeNames) {
                        nameList.add(name);
                    }
                }
                handleDataAttribute(data, filter, handle, nameList.toArray(new String[0]));
            }
        }
        return data;
    }


    /**
     * 处理数据属性的值
     *
     * @param data           数据对象
     * @param handle         处理数据的函数
     * @param attributeNames 要处理的属性名称列表
     * @return 处理后的数据对象
     */
    public static Object handleDataAttribute(Object data, DataHandle handle, String... attributeNames) {
        return handleDataAttribute(data, val -> val, handle, attributeNames);
    }

    /**
     * 处理数据属性的值
     *
     * @param data           数据对象
     * @param jsonPath       jsonPath表达式
     * @param handle         处理数据的函数
     * @param attributeNames 要处理的属性名称列表
     * @return 处理后的数据对象
     */
    public static Object handleDataAttribute(Object data, String jsonPath, DataHandle handle, String... attributeNames) {
        return handleDataAttribute(data, da -> getObjectByJsonPath(data, jsonPath), handle, attributeNames);
    }

    /**
     * 处理数据属性的值
     *
     * @param data           数据对象
     * @param dataFilter     数据对象过滤处理
     * @param handle         处理数据的函数
     * @param attributeNames 要处理的属性名称列表
     * @return 处理后的数据对象
     */
    public static Object handleDataAttribute(Object data, Function<Object, Object> dataFilter, DataHandle handle, String... attributeNames) {
        Object object = dataFilter.apply(data);
        if (object == null) {
            return data;
        }
        if (ArrayUtils.contains(attributeNames, "*")) {
            return handle.handle(data, ObjType.All, "*", object);
        }
        if (object instanceof Map) {
            return handleMapDataAttribute((Map<String, Object>) object, handle, attributeNames);
        } else if (object instanceof List) {
            return handleListDataAttribute((List<Object>) object, handle, attributeNames);
        }
        return data;
    }

    /**
     * 处理Map类型数据
     *
     * @param data           Map类型数据
     * @param handle         处理函数
     * @param attributeNames 要处理的属性名称
     * @return
     */
    private static Object handleMapDataAttribute(Map<String, Object> data, DataHandle handle, String... attributeNames) {
        if (data == null || data.isEmpty() || attributeNames == null || attributeNames.length == 0) {
            return data;
        }
        Map<String, Object> mapCopy = new HashMap<>(data);
        for (Map.Entry<String, Object> map : data.entrySet()) {
            String key = map.getKey();
            Object val = map.getValue();
            if (ArrayUtils.contains(attributeNames, key)) {
                mapCopy.put(key, handle.handle(mapCopy, ObjType.MAP, key, val));
                continue;
            }
            if (val instanceof Map) {
                handleMapDataAttribute((Map<String, Object>) val, handle, attributeNames);
            } else if (val instanceof List) {
                handleListDataAttribute((List<Object>) val, handle, attributeNames);
            } else if (ArrayUtils.contains(attributeNames, "*")) {
                mapCopy.put(key, handle.handle(mapCopy, ObjType.MAP, key, val));
            }
        }
        data.putAll(mapCopy);
        return data;
    }

    /**
     * 处理List<Map> 类型数据
     *
     * @param dataList       List<Map> 类型数据
     * @param handle         处理函数
     * @param attributeNames 要处理的属性名称
     * @return
     */
    private static Object handleListDataAttribute(List<Object> dataList, DataHandle handle, String... attributeNames) {
        if (CollectionUtils.isEmpty(dataList) || attributeNames == null || attributeNames.length == 0) {
            return dataList;
        }
        List<Object> dataListCopy = new ArrayList<>(dataList);
        for (int index = 0; index < dataList.size(); index++) {
            Object data = dataList.get(index);
            if (data instanceof Map) {
                handleMapDataAttribute((Map<String, Object>) data, handle, attributeNames);
            } else if (data instanceof List) {
                handleListDataAttribute((List<Object>) data, handle, attributeNames);
            } else {
                Object handleVal = handle.handle(dataListCopy, ObjType.LIST, String.valueOf(index), data);
                dataListCopy.set(index, handleVal);
                dataList.set(index, handleVal);
            }
        }
        List<Object> dataListCopy1 = new ArrayList<>(dataList);
        //获取已删除数据
        dataListCopy1.removeAll(dataListCopy);
        //获取新增的数据
        dataListCopy.removeAll(dataList);

        dataList.removeAll(dataListCopy1);
        dataList.addAll(dataListCopy);
        return dataList;
    }

    /**
     * 根据jsonPath获取json对象的数据
     *
     * @param jsonData json对象数据
     * @param jsonPath jsonPath表达式
     * @return path指定的对象
     */
    public static Object getObjectByJsonPath(Object jsonData, String jsonPath) {
        if (jsonData == null || isBaseDataType(jsonData)) {
            return null;
        }
        if (StringUtils.isBlank(jsonPath)) {
            return jsonData;
        }
        try {
            return JsonPath.read(jsonData, jsonPath);
        } catch (PathNotFoundException e) {
            log.warn("{} getByJsonPath stop . jsonPath not found .  jsonPath:{} ,jsonData:{} .", LOG_PREFIX, jsonPath, JsonUtils.instance().obj2Json(jsonData), e);
        } catch (Exception e) {
            log.warn("{} getByJsonPath have a error . jsonPath:{} ,jsonData:{} .", LOG_PREFIX, jsonPath, JsonUtils.instance().obj2Json(jsonData), e);
        }
        return null;
    }

    /**
     * 判断对象是不是基础数据类型
     *
     * @param object 对象
     * @return 是否是基础数据类型
     */
    public static boolean isBaseDataType(Object object) {
        if (object == null) {
            return false;
        }
        if (object instanceof Boolean
                || object instanceof Short
                || object instanceof Integer
                || object instanceof Long
                || object instanceof Float
                || object instanceof Double
                || object instanceof BigDecimal
                || object instanceof BigInteger
                || object instanceof Character
                || object instanceof String) {
            return true;
        }
        return false;
    }

    /**
     * 根据参数map构建url
     *
     * @param url      带参数占位符的url(占位符示例：{xxx})
     * @param paramMap 参数map
     * @return 构建后的url
     */
    public static String buildUrlByParam(String url, Map<String, Object> paramMap) {
        if (StringUtils.isBlank(url) || paramMap == null || paramMap.isEmpty()) {
            return url;
        }
        for (Map.Entry<String, Object> map : paramMap.entrySet()) {
            Object value = map.getValue();
            url = url.replace("{" + map.getKey() + "}", value == null ? "" : value.toString());
        }
        return url;
    }

    /**
     * @param urlRegex   url表达式（表达式代表参数示例：{xxx} eg: aaa/vvv/{param1}/eeee）
     * @param url        url字符串
     * @param paramNames 要处理的参数名称列表
     * @return
     */
    public static Map<String, String> getUrlParamByHandle(String urlRegex, String url, String... paramNames) {
        if (StringUtils.isBlank(url) || StringUtils.isBlank(urlRegex)) {
            return null;
        }
        if (paramNames == null || paramNames.length == 0) {
            return new HashMap<>(0);
        }
        Map<String, String> matchUrlParamMap = getMatchUrlParamMap(urlRegex, url);
        Map<String, String> paramMap = new HashMap<>();
        for (String paramName : paramNames) {
            if (matchUrlParamMap.containsKey(paramName)) {
                paramMap.put(paramName, matchUrlParamMap.get(paramName));
            }
        }
        return paramMap;
    }

    /**
     * 根据url表达式获取url内的参数
     *
     * @param urlRegex url表达式（表达式代表参数示例：{xxx} eg: aaa/vvv/{param1}/eeee）
     * @param urlStr   url字符串
     * @return url的参数map
     */
    public static Map<String, String> getMatchUrlParamMap(String urlRegex, String urlStr) {
        if (StringUtils.isBlank(urlRegex) || StringUtils.isBlank(urlStr)) {
            return new HashMap<>(0);
        }
        String paramRegex = "(?<=(\\{))(.+?)(?=(\\}))";
        List<String> paramKeys = new ArrayList<>();
        Matcher matcher = Pattern.compile(paramRegex).matcher(urlRegex);
        while (matcher.find()) {
            paramKeys.add(matcher.group());
        }
        String paramRegex1 = "(?:(\\{))(.+?)(?:(\\}))";
        String urlRegex2 = urlRegex.replaceAll(paramRegex1, "(.*)");
        Matcher matcher2 = Pattern.compile(urlRegex2).matcher(urlStr);
        Map<String, String> paramMap = new HashMap<>();
        if (matcher2.matches()) {
            for (int index = 0; index < paramKeys.size(); index++) {
                paramMap.put(paramKeys.get(index), matcher2.group(index + 1));
            }
        }
        return paramMap;
    }

    /**
     * 把json字符串转换为Map或List对象
     *
     * @param json json字符串
     * @return Map或List对象
     */
    public static Object jsonToObject(String json) {
        if (StringUtils.isBlank(json)) {
            return json;
        }
        Object bodyObj;
        if (json.trim().startsWith("{")) {
            bodyObj = JsonUtils.instance().json2Obj(json, Map.class);
        } else if (json.trim().startsWith("[")) {
            bodyObj = JsonUtils.instance().json2Obj(json, List.class);
//            bodyObj = SimpleJacksonUtils.jsonToObj(json, new TypeReference<List<Map<String, Object>>>() {})
        } else {
            bodyObj = json;
        }
        return bodyObj;
    }

    /**
     * 根据处理方式获取对应的处理配置
     *
     * @param configs 配置对象
     * @param handle  处理方式名称
     * @return
     */
    public static List<AttributeInfo> getListByHandle(List<AttributeInfo> configs, String handle) {
        if (CollectionUtils.isEmpty(configs)) {
            return null;
        }
        return configs.stream().filter(e -> e.getHandle().equals(handle)).collect(Collectors.toList());
    }

    /**
     * 获取请求对应的处理配置
     *
     * @param method     请求方式
     * @param requestURI 请求uri
     * @return 配置
     */
    public static AttributeHandleConfig getConfig(String method, String requestURI) {
        for (Map.Entry<String, AttributeHandleConfig> configMap : getConfigMap().entrySet()) {
            if (new AntPathMatcher().match(configMap.getKey(), method.toLowerCase() + "#" + requestURI)) {
                AttributeHandleConfig value = configMap.getValue();
                return value == null ? null : value.clone();
            }
        }
        return null;
    }

    /**
     * 获取配置的map
     *
     * @return
     */
    public static Map<String, AttributeHandleConfig> getConfigMap() {
        if (configMap != null) {
            return configMap;
        }
        configMap = getConfigList().stream().collect(Collectors.toMap(e -> e.getMethod().toLowerCase() + "#" + e.getPath().replaceAll("(?:(\\{))(.+?)(?:(\\}))", "*"), v -> v, (v1, v2) -> v1));
        return configMap;
    }

    /**
     * 获取所有配置列表
     *
     * @return
     */
    public static List<AttributeHandleConfig> getConfigList() {
        try {
            InputStream is = AttributePreHandleHelper.class.getClassLoader().getResourceAsStream("config/attribute_pre_handle_config.json");
            return JsonUtils.instanceOfDto().json2List(IOUtils.toString(is, StandardCharsets.UTF_8), AttributeHandleConfig.class);
        } catch (Exception e) {
            log.error("{} getConfigList stop . have a error .", LOG_PREFIX, e);
        }
        return null;
    }

    @Setter
    @Getter
    public static class AttributeContext implements Serializable {
        private AttributeHandleConfig config;
        private Map<String, Object> requestVariable;
        private Object custom;
    }

    @Setter
    @Getter
    public static class AttributeHandleConfig implements Serializable {
        private String path;
        private String method;
        private List<AttributeInfo> variable;
        private List<AttributeInfo> request;
        private List<AttributeInfo> response;

        @SneakyThrows
        @Override
        protected AttributeHandleConfig clone() {
            return deepClone(this);
        }
    }

    @Setter
    @Getter
    public static class AttributeInfo implements Serializable {
        /**
         * 参数类型
         */
        private ParamType type;
        /**
         * json path 表达式
         */
        private String jsonPath;
        /**
         * 要处理的属性名称，支持'*'
         */
        private List<String> names;
        /**
         * 处理的handle名称，AttributePreHandleService的实现类getHandleType获取的名称
         */
        private String handle;
    }

    @Getter
    public static enum ParamType {
        REQUEST_HEADER("header参数类型"),
        REQUEST_PATH("uri参数类型"),
        REQUEST_QUERY("url参数类型"),
        REQUEST_BODY("请求体参数类型"),
        JSON("返回的json类型");

        private String desc;

        ParamType(String desc) {
            this.desc = desc;
        }
    }

    @Getter
    public static enum ObjType {
        All(),
        MAP(),
        LIST();

        ObjType() {
        }
    }

    public static interface DataHandle {
        Object handle(Object object, ObjType objType, String key, Object val);
    }

    public static <T> T deepClone(T obj) throws IOException, ClassNotFoundException {
        //序列化
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream out = new ObjectOutputStream(bos);
        out.writeObject(obj);
        out.close();

        //反序列化
        ByteArrayInputStream bis = new ByteArrayInputStream(bos.toByteArray());
        ObjectInputStream input = new ObjectInputStream(bis);
        T clone = (T) input.readObject();
        input.close();
        return clone;
    }
}
