package com.convertlab.macore.mamgt.misc.advice;

import com.convertlab.foundation.library.business.feature.FeatureClient;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.mamgt.cdp.common.annotations.CdpApi;
import com.convertlab.macore.mamgt.common.utils.CommonHelper;
import com.convertlab.macore.mamgt.common.cache.MemCache;
import com.convertlab.macore.mamgt.common.cache.impl.CaffeineTenantIsolationMemCacheImpl;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.util.Assert;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.UriUtils;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.*;

@Slf4j
@Aspect
@RequiredArgsConstructor
public class CdpApiRouteAspect {
    private static final String LOG_PREFIX = "<ma-mgt> <CdpApiRouteAspect>";
    private static final String NON_COPY_FEATURE = "non_copy_bind_datahub";
    private final FeatureClient featureClient;

    @Value("${datahubInternalApiServer.serverUrl}")
    private String dataGdmServiceUrl;

    private final static MemCache<String> featureLimitCache = new CaffeineTenantIsolationMemCacheImpl<>(120L, 1000);

    @Around("@annotation(cdpApi)")
    public Object aroundCdpApiRoute(ProceedingJoinPoint joinPoint, CdpApi cdpApi) throws Throwable {
        try {
            MethodSignature signature = (MethodSignature) joinPoint.getSignature();
            String signatureName = signature.getName();
            log.debug("{} aroundCdpApiRoute start . methodName:{}", LOG_PREFIX, signatureName);
            Class<?> declaringType = signature.getDeclaringType();
            Method method = signature.getMethod();
            RouteRequestInfo routeRequestInfo = parseRequestMapping(declaringType, method);
            if (!checkNeedRoute(routeRequestInfo)) {
                log.debug("{} aroundCdpApiRoute end . route ignore . methodName:{} ,routeRequestInfo:{} .", LOG_PREFIX, signatureName, routeRequestInfo == null ? "" : routeRequestInfo);
                return joinPoint.proceed();
            }
            log.info("{} aroundCdpApiRoute ing . route start . methodName:{} ,routeRequestInfo:{}", LOG_PREFIX, signatureName, routeRequestInfo);
            Object forwardResult = httpForward(routeRequestInfo);
            log.info("{} aroundCdpApiRoute end . route end . methodName:{} ,routeRequestInfo:{}", LOG_PREFIX, signatureName, routeRequestInfo);
            return forwardResult;
        } catch (Exception e) {
            log.error("{} aroundCdpApiRoute error . methodName:{} ,error:{}", LOG_PREFIX, joinPoint.getSignature().getName(), e.getMessage(), e);
            throw e;
        }
    }

    /**
     * 校验是否需要路由请求
     *
     * @param requestMappingInfo 请求信息
     * @return 是否需要路由请求
     */
    private boolean checkNeedRoute(RouteRequestInfo requestMappingInfo) {
        if (requestMappingInfo == null) {
            return false;
        }
        // 忽略未绑定datahub工作区的租户
        String nonCopyDatahubWorkspaceId = featureLimitCache.get(NON_COPY_FEATURE, innerKey -> {
            String workspace = featureClient.getLimit(NON_COPY_FEATURE);
            if (workspace != null) {
                return workspace;
            } else {
                return "";
            }
        });

        if (StringUtils.isBlank(nonCopyDatahubWorkspaceId)) {
            return false;
        }

        String defineRequestUri = requestMappingInfo.getDefineRequestUri();
        String requestRealUri = requestMappingInfo.getRequestRealUri();
        Map<String, String> uriParam = getUriParam(defineRequestUri, requestRealUri);
        String profileName = uriParam.get("profileName");
        if (uriParam.isEmpty() || StringUtils.isBlank(profileName)) {
            return false;
        }
        if (profileName.startsWith("dw_")) {
            requestMappingInfo.setRouteServiceAddress(dataGdmServiceUrl);
            requestMappingInfo.addRouteUriReplaceRule("/litecdp/v1", "/inApi/v1/gdm");
            return true;
        }
        return false;
    }

    /**
     * 转发请求
     *
     * @param routeRequestInfo 转发请求对象
     * @return 转发返回的结果
     */
    private Object httpForward(RouteRequestInfo routeRequestInfo) {
        if (routeRequestInfo == null) {
            log.error("{} httpForward stop .have a error . routeRequestInfo must not null .", LOG_PREFIX);
            return new HashMap<>();
        }
        String method = routeRequestInfo.getMethod();
        Map<String, String> requestHeaders = routeRequestInfo.getRequestHeaders();
        String realUriWithQueryString = routeRequestInfo.getRequestRealUriWithQueryString();
        Map<String, String> routeUriReplaceRules = routeRequestInfo.getRouteUriReplaceRules();
        if (CommonHelper.checkMapIsNotEmpty(routeUriReplaceRules)) {
            //根据替换规则，处理uri
            for (Map.Entry<String, String> routeUriReplaceRuleMap : routeUriReplaceRules.entrySet()) {
                realUriWithQueryString = realUriWithQueryString.replaceAll(routeUriReplaceRuleMap.getKey(), routeUriReplaceRuleMap.getValue());
            }
        }
        String url = routeRequestInfo.getRouteServiceAddress() + realUriWithQueryString;
        HttpMethod httpMethod = HttpMethod.valueOf(method);
        ServletInputStream requestBody = routeRequestInfo.getRequestInputStream();

        RestTemplate restTemplate = new RestTemplate();
        String encodeUrl = UriUtils.encodePath(url, "UTF-8");
        log.info("{} httpForward start . method:{} ,requestUri:{} ,targetUrl:{} . routeRequestInfo:{}", LOG_PREFIX, method, routeRequestInfo.getRequestUriWithQueryString(), encodeUrl, routeRequestInfo);

        Object execute = restTemplate.execute(encodeUrl, httpMethod, clientHttpRequest -> {
            HttpHeaders httpHeaders = clientHttpRequest.getHeaders();
            if (requestHeaders != null) {
                for (Map.Entry<String, String> headerMap : requestHeaders.entrySet()) {
                    httpHeaders.add(headerMap.getKey(), headerMap.getValue());
                }
            }
            if (requestBody != null) {
                StreamUtils.copy(requestBody, clientHttpRequest.getBody());
            }
        }, null);
        return execute;
    }

    /**
     * 根据uri定义获取uri中的参数信息
     *
     * @param defineRequestUri 定义的uri信息
     * @param requestUri       请求uri信息
     * @return uri中的参数信息
     */
    private Map<String, String> getUriParam(String defineRequestUri, String requestUri) {
        Map<String, String> paramMap = new HashMap<>();
        if (StringUtils.isBlank(defineRequestUri) || StringUtils.isBlank(requestUri)) {
            return paramMap;
        }
        Map<String, Integer> paramIndexMap = new HashMap<>();
        String[] defineUriArray = defineRequestUri.split("/");
        for (int index = 0; index < defineUriArray.length; index++) {
            String uriE = defineUriArray[index];
            if (!uriE.startsWith("{")) {
                continue;
            }
            String paramName = uriE.replaceAll("\\{|\\}", "");
            paramIndexMap.put(paramName, index);
        }
        String[] requestUriArray = requestUri.split("/");
        for (Map.Entry<String, Integer> paramIndex : paramIndexMap.entrySet()) {
            String paramName = paramIndex.getKey();
            Integer index = paramIndex.getValue();
            if (index > requestUriArray.length - 1) {
                log.warn("{} getUriParam error . uri not match . defineRequestUri:{} ,requestUri:{}", LOG_PREFIX, defineRequestUri, requestUri);
                continue;
            }
            String paramValue = requestUriArray[index];
            paramMap.put(paramName, paramValue);
        }
        return paramMap;
    }

    /**
     * 解析出定义的uri信息和此次请求的信息
     *
     * @param clazz  类对象
     * @param method 方法对象
     * @return 解析到的对象
     * @throws IOException
     */
    private RouteRequestInfo parseRequestMapping(Class<?> clazz, Method method) throws IOException {
        String baseUrl = "";
        String patternUrl = "";
        String httpMethod = null;
        if (clazz.isAnnotationPresent(RequestMapping.class)) {
            RequestMapping requestMapping = clazz.getAnnotation(RequestMapping.class);
            if (requestMapping != null) {
                baseUrl = requestMapping.value()[0];
            }
        }
        if (method.isAnnotationPresent(GetMapping.class)) {
            GetMapping getMapping = method.getAnnotation(GetMapping.class);
            Assert.isTrue(getMapping.value().length == 1, "Only one url pattern is allowed in ma-mgt CdpApi");
            patternUrl = getMapping.value()[0];
            httpMethod = "GET";
        } else if (method.isAnnotationPresent(PostMapping.class)) {
            PostMapping postMapping = method.getAnnotation(PostMapping.class);
            Assert.isTrue(postMapping.value().length == 1, "Only one url pattern is allowed in ma-mgt CdpApi");
            patternUrl = postMapping.value()[0];
            httpMethod = "POST";
        } else if (method.isAnnotationPresent(PutMapping.class)) {
            PutMapping putMapping = method.getAnnotation(PutMapping.class);
            Assert.isTrue(putMapping.value().length == 1, "Only one url pattern is allowed in ma-mgt CdpApi");
            patternUrl = putMapping.value()[0];
            httpMethod = "PUT";
        } else if (method.isAnnotationPresent(DeleteMapping.class)) {
            DeleteMapping deleteMapping = method.getAnnotation(DeleteMapping.class);
            Assert.isTrue(deleteMapping.value().length == 1, "Only one url pattern is allowed in ma-mgt CdpApi");
            patternUrl = deleteMapping.value()[0];
            httpMethod = "DELETE";
        } else if (method.isAnnotationPresent(RequestMapping.class)) {
            RequestMapping requestMapping = method.getAnnotation(RequestMapping.class);
            Assert.isTrue(requestMapping.value().length == 1, "Only one url pattern is allowed in ma-mgt CdpApi");
            patternUrl = requestMapping.value()[0];
            Assert.isTrue(requestMapping.method().length == 1, "Only one http method is allowed in ma-mgt CdpApi");
            httpMethod = requestMapping.method()[0].name();
        }
        if (StringUtils.isBlank(httpMethod) || StringUtils.isBlank(baseUrl + patternUrl)) {
            return null;
        }
        String defineRequestUri = baseUrl + patternUrl;

        ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (servletRequestAttributes == null) {
            return null;
        }
        HttpServletRequest request = servletRequestAttributes.getRequest();
        String requestUri = request.getRequestURI();
        String protocol = request.getProtocol();
        String queryString = request.getQueryString();
        ServletInputStream inputStream = null;
        if (!"GET".equalsIgnoreCase(httpMethod)) {
            inputStream = request.getInputStream();
        }
        //获取请求头map
        Map<String, String> allHeader = getAllHeader(request);
        Map<String, String> mappingReplaceRules = getMappingReplaceRules();
        return new RouteRequestInfo(mappingReplaceRules, httpMethod, defineRequestUri, protocol, requestUri, queryString, request.getContentType(), allHeader, inputStream);
    }

    /**
     * 根据规则，获取真实的uri
     *
     * @param mappingReplaceRules 映射替换规则
     * @param requestUri          要处理的uri
     * @return 真实的uri
     */
    public static String getRealUri(Map<String, String> mappingReplaceRules, String requestUri) {
        if (CommonHelper.checkMapIsEmpty(mappingReplaceRules)) {
            return requestUri;
        }
        for (Map.Entry<String, String> replaceRuleMap : mappingReplaceRules.entrySet()) {
            String key = replaceRuleMap.getKey();
            if (requestUri.startsWith(key)) {
                return requestUri.replaceAll(key, replaceRuleMap.getValue());
            }
        }
        return requestUri;
    }

    /**
     * 获取映射替换规则
     *
     * @return 映射替换规则map
     */
    private Map<String, String> getMappingReplaceRules() {
        Map<String, String> mappingRules = new HashMap<>();
        mappingRules.put("/profiles/data", "/litecdp/v1/profiles");
        mappingRules.put("/profiles/meta", "/litecdp/v1/meta/profiles");
//        mappingRules.put("/cdp", "/litecdp");
        return mappingRules;
    }

    /**
     * 获取请求头map
     *
     * @param request 请求对象
     * @return 请求头map
     */
    private Map<String, String> getAllHeader(HttpServletRequest request) {
        Map<String, String> headerMap = new HashMap<>();
        if (request == null) {
            return headerMap;
        }
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            //读取请求消息头
            String name = headerNames.nextElement();
            headerMap.put(name, request.getHeader(name));
        }
        return headerMap;
    }

    @Setter
    @Getter
    static class RouteRequestInfo implements Serializable {
        /**
         * 请求类型（eg:GET ; POST ; DELETE ; PUT）
         */
        private String method;
        /**
         * 定义的uri信息
         */
        private String defineRequestUri;
        /**
         * 请求的协议
         */
        private String requestProtocol;
        /**
         * 请求的uri
         */
        private String requestUri;
        /**
         * 请求的uri的真实uri(根据替换规则处理后的uri)
         */
        private String requestRealUri;
        /**
         * 请求的参数字符串
         */
        private String requestQueryString;
        /**
         * 请求的uri带参数字符串
         */
        private String requestUriWithQueryString;
        /**
         * 请求的真实uri带参数字符串
         */
        private String requestRealUriWithQueryString;
        /**
         * 请求的header
         */
        private Map<String, String> requestHeaders;
        /**
         * 请求内容类型
         */
        private String requestContentType;
        /**
         * 请求体流
         */
        private ServletInputStream requestInputStream;
        /**
         * 要路由到的服务地址
         */
        private String routeServiceAddress;

        /**
         * 路由转发uri的替换规则
         */
        private Map<String, String> routeUriReplaceRules;
        /**
         * 请求uri替换规则
         */
        private Map<String, String> requestUriReplaceRules;


        public RouteRequestInfo() {
        }

        public RouteRequestInfo(String method, String defineRequestUri) {
            this.method = method;
            this.defineRequestUri = defineRequestUri;
        }

        public RouteRequestInfo(Map<String, String> requestUriReplaceRules, String method, String defineRequestUri, String requestProtocol, String requestUri, String requestQueryString, String requestContentType, Map<String, String> requestHeaders, ServletInputStream requestInputStream) {
            this.requestUriReplaceRules = requestUriReplaceRules;
            this.method = method;
            this.defineRequestUri = defineRequestUri;
            this.requestProtocol = requestProtocol;
            this.requestUri = requestUri;
            this.requestQueryString = requestQueryString;

            this.requestUriWithQueryString = requestUri;
            if (StringUtils.isNotBlank(requestQueryString)) {
                this.requestUriWithQueryString = this.requestUri + "?" + requestQueryString;
            }
            this.requestContentType = requestContentType;
            this.requestHeaders = requestHeaders;
            this.requestInputStream = requestInputStream;
            this.requestRealUri = getRealUri(this.requestUriReplaceRules, this.requestUri);

            this.requestRealUriWithQueryString = this.requestRealUri;
            if (StringUtils.isNotBlank(requestQueryString)) {
                this.requestRealUriWithQueryString = this.requestRealUri + "?" + requestQueryString;
            }
        }

        public void addRouteUriReplaceRule(String regex, String replacement) {
            if (this.routeUriReplaceRules == null) {
                this.routeUriReplaceRules = new HashMap<>();
            }
            this.routeUriReplaceRules.put(regex, replacement);
        }

        public String getRequestUriWithQueryString() {
            if (this.requestUriWithQueryString == null) {
                this.requestUriWithQueryString = this.requestUri;
                if (StringUtils.isNotBlank(this.requestQueryString)) {
                    this.requestUriWithQueryString = this.requestUri + "?" + requestQueryString;
                }
            }
            return this.requestUriWithQueryString;
        }

        public String getRequestRealUriWithQueryString() {
            if (this.requestRealUriWithQueryString == null) {
                this.requestRealUriWithQueryString = this.requestRealUri;
                if (StringUtils.isNotBlank(this.requestQueryString)) {
                    this.requestRealUriWithQueryString = this.requestRealUri + "?" + requestQueryString;
                }
            }
            return this.requestRealUriWithQueryString;
        }

        public String getRequestRealUri() {
            if (this.requestRealUri == null) {
                this.requestRealUri = getRealUri(this.requestUriReplaceRules, this.requestUri);
            }
            return this.requestRealUri;
        }

        @Override
        public String toString() {
            return JsonUtils.instance().obj2Json(this);
        }
    }
}
