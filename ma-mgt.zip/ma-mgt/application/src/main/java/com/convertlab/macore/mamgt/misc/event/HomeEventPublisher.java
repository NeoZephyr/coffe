package com.convertlab.macore.mamgt.misc.event;

import com.convertlab.foundation.library.business.eventbroker.EventOptions;
import com.convertlab.foundation.library.business.eventbroker.GenericDomainEventPublisher;
import com.convertlab.foundation.library.business.property.EventBrokerProperties;
import com.convertlab.foundation.library.constant.ComponentNames;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import javax.annotation.Nonnull;

@Service
public class HomeEventPublisher extends GenericDomainEventPublisher<HomeEvent,HomeEvent.Dto,HomeEvent.HomeEventType> {
//    private final ApplicationEventPublisher eventPublisher;

    public HomeEventPublisher(ApplicationEventPublisher eventPublisher, EventBrokerProperties eventBrokerProperties) {
        super(eventPublisher, eventBrokerProperties);
    }

    @Nonnull
    @Override
    protected String getPublisher() {
        return ComponentNames.DEMO_ONLY;
    }


    @Nonnull
    @Override
    protected HomeEvent createEvent(HomeEvent.Dto dto, @Nonnull EventOptions options) {
        return new HomeEvent(this, dto, options);
    }
}
