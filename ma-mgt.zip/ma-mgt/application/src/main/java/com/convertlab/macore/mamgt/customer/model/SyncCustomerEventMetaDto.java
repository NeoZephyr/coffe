package com.convertlab.macore.mamgt.customer.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class SyncCustomerEventMetaDto implements Serializable {

    /**
     * 改变类型，包括 update, insert, delete
     */
    String type;
    /**
     *
     */
    String metaType;
    /**
     * 改变的数据，内容被GZIP压缩过
     */
    String payload;
    /**
     * 事件列表
     */
    List<String> events;
}
