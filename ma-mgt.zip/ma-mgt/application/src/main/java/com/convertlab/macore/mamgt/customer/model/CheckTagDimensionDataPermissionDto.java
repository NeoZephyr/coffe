package com.convertlab.macore.mamgt.customer.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CheckTagDimensionDataPermissionDto {
    String dimensionKey;
    List<String> tagIdList;
}

