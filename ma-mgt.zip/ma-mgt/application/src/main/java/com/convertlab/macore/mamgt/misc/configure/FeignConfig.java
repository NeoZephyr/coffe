package com.convertlab.macore.mamgt.misc.configure;

import feign.Logger;
import org.springframework.context.annotation.Bean;

public class FeignConfig {
//    @Bean
//    Logger.Level feighLoggerLevel() {
//        return Logger.Level.BASIC;
//    }
}
