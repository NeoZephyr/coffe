package com.convertlab.macore.mamgt.filter.utils;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.convert.Convert;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.macore.mamgt.common.utils.NamingUtils;
import com.convertlab.macore.mamgt.filter.model.filterV4.Where;
import com.convertlab.macore.mamgt.filter.model.filterV4.date.RangeDateTime;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.convertlab.macore.mamgt.filter.constants.Constants.*;
import static com.convertlab.macore.mamgt.filter.enums.DateTypeEnum.getDateType;

/**
 * All rights Reserved, Designed By ConvertLab
 * Author: zhiping.cai
 * Date: 2023/4/24
 * Description:
 * Copyright (C) 2022 www.convertlab.com
 */
public class DateUtils {

    public static String OPERAND_ANY = "any";
    public static String OPERAND_SPECIAL_ANY = "specialAny";
    public static String OPERAND_SPECIAL_FROM_ANY = "specialFromAny";

    public static List<String> getStaticDate(final String inputDateValue,String timeDimension,String fieldType,Map<String, String> entityMappings,String operator) {
        String getMappingValue = BizUtils.getValueWithEntityMapping(inputDateValue,entityMappings);
        switch (getDateType(timeDimension)){
            case DATE:
                return getDateStrByFieldType(inputDateValue,fieldType,operator);
            case HOUR:
                return Arrays.asList(String.format("HOUR(%s,'%s')", NamingUtils.toUnderScoreCase(getMappingValue), TIME_ZONE_SHANGHAI));
            case DAY:
                return Arrays.asList(String.format("DAY(%s,'%s')", NamingUtils.toUnderScoreCase(getMappingValue), TIME_ZONE_SHANGHAI));
            case WEEK:
                return Arrays.asList(String.format("(DAYOFWEEK(%s,'%s') + 5) %% 7", NamingUtils.toUnderScoreCase(getMappingValue), TIME_ZONE_SHANGHAI));
            case MONTH:
                return Arrays.asList(String.format("MONTH(%s,'%s')", NamingUtils.toUnderScoreCase(getMappingValue), TIME_ZONE_SHANGHAI));
            case  YEAR:
                return Arrays.asList(String.format("YEAR(%s,'%s')", NamingUtils.toUnderScoreCase(getMappingValue), TIME_ZONE_SHANGHAI));
            default:
                throw new BusinessException(CommonErrors.WRONG_TYPE,"MSG_100_000008",new String[]{timeDimension},0);
        }
    }

    public static List<String> getDateStrByFieldType(String dateValue, String fieldType, String operator) {

        if(validateDate(dateValue, DATE_PATTERN_DATETIME)){
            throw new BusinessException(CommonErrors.VALIDATION_ERROR,"MSG_100_000009",new String[]{dateValue},0);
        }

        List<String> result = new ArrayList<>();
        DateTimeZone timezone = DateTimeZone.forID(TIME_ZONE_SHANGHAI);
        if (validateDate(dateValue, DATE_PATTERN_DATE)) {
            if(fieldType.equalsIgnoreCase(DATE_TYPE_DATETIME)){
                DateTime dateFromTime = new DateTime(dateValue, timezone);
                result.add(removeTZ(convertDateTimeToUtc(dateFromTime),DATE_PATTERN_DATETIME));
                if(Where.Operator.Constants.EQUAL.equalsIgnoreCase(operator)){
                    DateTime dateToTime = dateFromTime.plusDays(1);
                    result.add(removeTZ(convertDateTimeToUtc(dateToTime),DATE_PATTERN_DATETIME));
                }else if(Where.Operator.Constants.LESS_EQUAL.equalsIgnoreCase(operator)){
                    result.remove(0);
                    DateTime dateToTime = dateFromTime.plusDays(1);
                    result.add(removeTZ(convertDateTimeToUtc(dateToTime),DATE_PATTERN_DATETIME));
                }else if(Where.Operator.Constants.GREAT_THAN.equalsIgnoreCase(operator)){
                    result.remove(0);
                    DateTime dateToTime = dateFromTime.plusDays(1);
                    result.add(removeTZ(convertDateTimeToUtc(dateToTime.minusSeconds(1)),DATE_PATTERN_DATETIME));

                }
            }else if(fieldType.equalsIgnoreCase(DATE_TYPE_DATE)){
                if(Where.Operator.Constants.LESS_EQUAL.equalsIgnoreCase(operator)){
                    DateTime dateFromTime = new DateTime(dateValue, timezone);
                    result.add(removeTZ(convertDateTimeToUtc(dateFromTime),DATE_PATTERN_DATETIME));
                    result.remove(0);
                    DateTime dateToTime = dateFromTime.plusDays(1);
                    result.add(removeTZ(convertDateTimeToUtc(dateToTime),DATE_PATTERN_DATETIME));
                }else if(Where.Operator.Constants.GREAT_EQUAL.equalsIgnoreCase(operator)){
                    DateTime dateFromTime = new DateTime(dateValue, timezone);
                    result.add(removeTZ(convertDateTimeToUtc(dateFromTime),DATE_PATTERN_DATETIME));
                    result.remove(0);
                    DateTime dateToTime = dateFromTime;
                    result.add(removeTZ(convertDateTimeToUtc(dateToTime),DATE_PATTERN_DATETIME));
                }else if(Where.Operator.Constants.GREAT_THAN.equalsIgnoreCase(operator)) {
                    DateTime dateFromTime = new DateTime(dateValue, timezone);
                    result.add(removeTZ(convertDateTimeToUtc(dateFromTime),DATE_PATTERN_DATETIME));
                    result.remove(0);
                    DateTime dateToTime = dateFromTime.plusDays(1);
                    result.add(removeTZ(convertDateTimeToUtc(dateToTime.minusSeconds(1)),DATE_PATTERN_DATETIME));
                }else{
                    result.add(removeTZ(convertDateStrToUtc(dateValue, timezone, fieldType, false),DATE_PATTERN_DATETIME));
                }
            } else{
                result.add(removeTZ(convertDateStrToUtc(dateValue, timezone, fieldType, false),DATE_PATTERN_DATETIME));
            }
        } else {
            result.add(removeTZ(dateValue,DATE_PATTERN_DATETIME));
        }
        return result;
    }

    public static String getDynamicRangeFromDate(RangeDateTime rangeDateTime, String fieldType, Boolean includeFrom){
        String timeUnit = rangeDateTime.getDateFrom().getTimeUnit();
        String dateFromValue = rangeDateTime.getDateFrom().getValue();
        String dateFromAdditionalValue = rangeDateTime.getDateFrom().getAdditionalValue();

        String strFromDate = "";
        if ((StringUtils.isNotEmpty(dateFromValue) && OPERAND_ANY.equals(dateFromValue))
                && (StringUtils.isNotEmpty(dateFromAdditionalValue) && OPERAND_SPECIAL_FROM_ANY.equalsIgnoreCase(dateFromAdditionalValue))){
            DateTime nowDate = new DateTime(DateTimeZone.forID(TIME_ZONE_SHANGHAI)).withMillisOfDay(0);

            switch (getDateType(timeUnit)) {
                case WEEK:
                    strFromDate = removeTZ(convertDateTimeToUtc(nowDate.plusWeeks(1).withDayOfWeek(1)), DATE_PATTERN_DATETIME);
                    break;
                case MONTH:
                    strFromDate = removeTZ(convertDateTimeToUtc(nowDate.plusMonths(1).withDayOfMonth(1)), DATE_PATTERN_DATETIME);
                    break;
                case YEAR:
                    strFromDate = removeTZ(convertDateTimeToUtc(nowDate.plusYears(1).withDayOfYear(1)), DATE_PATTERN_DATETIME);
                    break;
                case DAY:
                    strFromDate = removeTZ(convertDateTimeToUtc(nowDate.plusDays(1)), DATE_PATTERN_DATETIME);
                    break;
                default:
                    strFromDate = "";
            }
        }else {
            strFromDate = DateUtils.getDynamicRangeDate(rangeDateTime.getDateFrom().getTimeUnit(), fieldType,
                            rangeDateTime.getDateFrom().getValue(), null, includeFrom, null).get(0);
        }
        return strFromDate;
    }

    public static String getDynamicRangeToDate(RangeDateTime rangeDateTime, String fieldType, Boolean includeTo){
        String timeUnit = rangeDateTime.getDateFrom().getTimeUnit();
        String dateToValue = rangeDateTime.getDateTo().getValue();
        String dateToAdditionalValue = rangeDateTime.getDateTo().getAdditionalValue();

        String strToDate = "";
        if ((StringUtils.isNotEmpty(dateToValue) && OPERAND_ANY.equals(dateToValue))
        && (StringUtils.isNotEmpty(dateToAdditionalValue) && OPERAND_SPECIAL_ANY.equalsIgnoreCase(dateToAdditionalValue))){
            DateTime nowDate = new DateTime(DateTimeZone.forID(TIME_ZONE_SHANGHAI)).withMillisOfDay(0);

            String dateFromValue = rangeDateTime.getDateFrom().getValue();
            if(StringUtils.isNotEmpty(dateFromValue) && OPERAND_ANY.equals(dateFromValue)){
                strToDate = removeTZ(convertDateTimeToUtc(nowDate.plusDays(1)), DATE_PATTERN_DATETIME);
            }else{
                switch (getDateType(timeUnit)) {
                    case WEEK:
                        strToDate = removeTZ(convertDateTimeToUtc(nowDate.plusWeeks(1).withDayOfWeek(1)), DATE_PATTERN_DATETIME);
                        break;
                    case MONTH:
                        strToDate = removeTZ(convertDateTimeToUtc(nowDate.plusMonths(1).withDayOfMonth(1)), DATE_PATTERN_DATETIME);
                        break;
                    case YEAR:
                        strToDate = removeTZ(convertDateTimeToUtc(nowDate.plusYears(1).withDayOfYear(1)), DATE_PATTERN_DATETIME);
                        break;
                    case DAY:
                        strToDate = removeTZ(convertDateTimeToUtc(nowDate.plusDays(1)), DATE_PATTERN_DATETIME);
                        break;
                    default:
                        strToDate = "";
                }
            }
        }else {
            strToDate = getDynamicRangeDate(timeUnit, fieldType,
                    null, rangeDateTime.getDateTo().getValue(), null,includeTo).get(1);
        }
        return strToDate;
    }

    public static List<String> getDynamicRangeDate(String dateType, String fieldType, String dateFrom, String dateTo, Boolean includeFrom, Boolean includeTo) {
        DateTime nowDate = new DateTime(DateTimeZone.forID(TIME_ZONE_SHANGHAI)).withMillisOfDay(0);
        DateTime dateFromTime = StringUtils.isNotEmpty(dateFrom) && !StringUtils.equals(dateFrom, OPERAND_ANY) ?
                handleDynamicDateValue(dateType, nowDate, matchDynamicDateValue(dateFrom).get("value"), matchDynamicDateValue(dateFrom).get("sign"), includeFrom, includeTo) :
                new DateTime(START_ANY, DateTimeZone.forID(TIME_ZONE_SHANGHAI));
        DateTime dateToTime = StringUtils.isNotEmpty(dateTo) && !StringUtils.equals(dateTo, OPERAND_ANY) ?
                handleDynamicDateValue(dateType, nowDate, matchDynamicDateValue(dateTo).get("value"), matchDynamicDateValue(dateTo).get("sign"), includeFrom, includeTo) :
                new DateTime(TO_ANY, DateTimeZone.forID(TIME_ZONE_SHANGHAI));
        String formattedDateFrom = Objects.nonNull(dateFromTime) ?
                removeTZ(convertDateTimeToUtc(dateFromTime), DATE_PATTERN_DATETIME) :
                null;
        String formattedDateTo = Objects.nonNull(dateToTime) ?
                removeTZ(convertDateTimeToUtc(dateToTime), DATE_PATTERN_DATETIME) :
                null;
        return CollectionUtil.list(false, formattedDateFrom, formattedDateTo);
    }

    public static DateTime handleDynamicDateValue(String dateType, DateTime dateTime, String value, String operator, Boolean includeFrom, Boolean includeTo) {
        switch (getDateType(dateType)) {
            case WEEK:
                if(operator.equalsIgnoreCase(DATE_ADD_OPERATOR)){
                    if(Objects.nonNull(includeFrom)){
                        return includeFrom == true ?
                                dateTime.plusWeeks(Convert.toInt(value)).withDayOfWeek(1) : dateTime.plusWeeks(Convert.toInt(value) + 1).withDayOfWeek(1);
                    }else {
                        return includeTo == true ?
                                dateTime.plusWeeks(Convert.toInt(value) + 1).withDayOfWeek(1) : dateTime.plusWeeks(Convert.toInt(value)).withDayOfWeek(1);
                    }
                }else if(operator.equalsIgnoreCase(DATE_SUB_OPERATOR)){
                    if(Objects.nonNull(includeFrom)){
                        return includeFrom == true ?
                                dateTime.minusWeeks(Convert.toInt(value)).withDayOfWeek(1) : dateTime.minusWeeks(Convert.toInt(value) - 1).withDayOfWeek(1);
                    }else {
                        return includeTo == true ?
                                dateTime.plusWeeks(Convert.toInt(value) + 1).withDayOfWeek(1) : dateTime.minusWeeks(Convert.toInt(value)).withDayOfWeek(1);
                    }
                }
            case MONTH:
                if(operator.equalsIgnoreCase(DATE_ADD_OPERATOR)){
                    if(Objects.nonNull(includeFrom)){
                        return includeFrom == true ?
                                dateTime.plusMonths(Convert.toInt(value)).withDayOfMonth(1) : dateTime.plusMonths(Convert.toInt(value) + 1).withDayOfMonth(1);
                    }else {
                        return includeTo == true ?
                                dateTime.plusMonths(Convert.toInt(value) + 1).withDayOfMonth(1) : dateTime.plusMonths(Convert.toInt(value)).withDayOfMonth(1);
                    }
                }else if(operator.equalsIgnoreCase(DATE_SUB_OPERATOR)){
                    if(Objects.nonNull(includeFrom)){
                        return includeFrom == true ?
                                dateTime.minusMonths(Convert.toInt(value)).withDayOfMonth(1) : dateTime.minusMonths(Convert.toInt(value) - 1).withDayOfMonth(1);
                    }else {
                        return includeTo == true ?
                                dateTime.plusMonths(Convert.toInt(value) + 1).withDayOfMonth(1) : dateTime.minusMonths(Convert.toInt(value)).withDayOfMonth(1);
                    }
                }
            case YEAR:
                if(operator.equalsIgnoreCase(DATE_ADD_OPERATOR)){
                    if(Objects.nonNull(includeFrom)){
                        return includeFrom == true ?
                                dateTime.plusYears(Convert.toInt(value)).withDayOfYear(1) : dateTime.plusYears(Convert.toInt(value) + 1).withDayOfYear(1);
                    }else {
                        return includeTo == true ?
                                dateTime.plusYears(Convert.toInt(value) + 1).withDayOfYear(1) : dateTime.plusYears(Convert.toInt(value)).withDayOfYear(1);
                    }
                }else if(operator.equalsIgnoreCase(DATE_SUB_OPERATOR)){
                    if(Objects.nonNull(includeFrom)){
                        return includeFrom == true ?
                                dateTime.minusYears(Convert.toInt(value)).withDayOfYear(1) : dateTime.minusYears(Convert.toInt(value) - 1).withDayOfYear(1);
                    }else {
                        return includeTo == true ?
                                dateTime.minusYears(Convert.toInt(value) - 1).withDayOfYear(1) : dateTime.minusYears(Convert.toInt(value)).withDayOfYear(1);
                    }
                }
            default:
                if(operator.equalsIgnoreCase(DATE_ADD_OPERATOR)){
                    if(Objects.nonNull(includeFrom)){
                        return includeFrom == true ? dateTime.plusDays(Convert.toInt(value)) : dateTime.plusDays(Convert.toInt(value) + 1);
                    }else {
                        return includeTo == true ? dateTime.plusDays(Convert.toInt(value) + 1) : dateTime.plusDays(Convert.toInt(value));
                    }
                }else if(operator.equalsIgnoreCase(DATE_SUB_OPERATOR)){
                    if(Objects.nonNull(includeFrom)){
                        return includeFrom == true ? dateTime.minusDays(Convert.toInt(value)) : dateTime.minusDays(Convert.toInt(value) - 1);
                    }else {
                        return includeTo == true ? dateTime.minusDays(Convert.toInt(value) - 1) : dateTime.minusDays(Convert.toInt(value));
                    }
                }
        }
        return null;
    }

    public static String convertDateStrToUtc(String dateString, DateTimeZone timeZone, String dateType, boolean isToUtc) {
        DateTime dateTime = null;
        if (DATE_TYPE_DATE.equalsIgnoreCase(dateType)) {
            dateTime = DateTimeFormat.forPattern(DATE_PATTERN_DATE).withZone(timeZone).parseDateTime(dateString);
        }else if(DATE_TYPE_DATETIME.equalsIgnoreCase(dateType)){
            dateTime = DateTimeFormat.forPattern(DATE_PATTERN_DATETIME).withZone(timeZone).parseDateTime(dateString);
        }
        return dateTime.withZone(isToUtc==true ? DateTimeZone.UTC : timeZone).toString(DATE_PATTERN_DEFAULT);
    }

    public static String convertDateTimeToUtc(DateTime dateTime) {
        return dateTime.withZone(DateTimeZone.UTC).toString(DATE_PATTERN_DEFAULT);
    }

    public static String removeTZ(String timeStr, String format) {
        DateTimeFormatter fmt = DateTimeFormat.forPattern(DATE_PATTERN_DEFAULT);
        DateTime dateTime = fmt.parseDateTime(timeStr);
        return dateTime.toString(format);
    }

    public static Map<String, String> matchDynamicDateValue(String input) {
        Pattern pattern = Pattern.compile("^([-+]?)(\\d+)$");
        Matcher matcher = pattern.matcher(input);
        Map<String, String> result = new HashMap<>();
        if (matcher.find()) {
            String sign = matcher.group(1);
            String value = matcher.group(2);
            result.put("sign", sign);
            result.put("value", value);
        }
        return result;
    }

    public static boolean validateDate(String date, String pattern) {
        DateTimeFormatter formatter = DateTimeFormat.forPattern(pattern);
        try {
            DateTime dt = formatter.parseDateTime(date);
            return true;
        } catch (IllegalArgumentException ex) {
            return false;
        }
    }

}