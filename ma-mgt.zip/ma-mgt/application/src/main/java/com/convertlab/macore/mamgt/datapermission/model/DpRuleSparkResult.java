package com.convertlab.macore.mamgt.datapermission.model;

import lombok.Data;

@Data
public class DpRuleSparkResult {

    Result result;
    Long tenantId;
    TaskDef taskDef;

    @Data
    public static class TaskDef{
        Long ruleId;
        String type;
    }

    @Data
    public static class Result{
        String status;
        String failReason;
    }
}
