package com.convertlab.macore.mamgt.datapermission.service;

import com.convertlab.macore.mamgt.cdp.dto.bizmeta.ProfileBizMeta;
import com.convertlab.macore.mamgt.cdp.meta.service.ProfileMetaService;
import com.convertlab.macore.mamgt.common.utils.NamingUtils;
import com.convertlab.macore.mamgt.datapermission.client.DpFeignClient;
import com.convertlab.macore.mamgt.datapermission.model.DpDataPermissionGroupDto;
import com.convertlab.macore.mamgt.datapermission.resource.DpResource;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class DpMetaService {

    private final DpFeignClient dpFeignClient;

    private final ProfileMetaService profileMetaService;

    public DpMetaService(DpFeignClient dpFeignClient, ProfileMetaService profileMetaService) {
        this.dpFeignClient = dpFeignClient;
        this.profileMetaService = profileMetaService;
    }

    public List<DpDataPermissionGroupDto> getGroup() {
        List<DpDataPermissionGroupDto> list = new ArrayList<>(convertProflieListToFeView(
                getProfileBizMetas(DpDataPermissionGroupDto.GROUP_TYPE_PRIMARY_PROFILE), DpDataPermissionGroupDto.GROUP_TYPE_PRIMARY_PROFILE));
        list.addAll(convertBuiltinToFeView(
                DpResource.getResourcesByGroup(DpResource.channel), DpDataPermissionGroupDto.GROUP_TYPE_CHANNEL));
        list.addAll(convertBuiltinToFeView(
                DpResource.getResourcesByGroup(DpResource.root), DpDataPermissionGroupDto.GROUP_TYPE_BUILT_IN));
        list.addAll(convertProflieListToFeView(
                getProfileBizMetas(DpDataPermissionGroupDto.GROUP_TYPE_GENERAL_PROFILE), DpDataPermissionGroupDto.GROUP_TYPE_GENERAL_PROFILE));
        return list.stream().distinct().collect(Collectors.toList());
    }

    public List<Map<String, Object>> getAclMeta(String group, String groupType) {
        List<Map<String, Object>> result = new ArrayList<>();
        switch (groupType) {
            case DpDataPermissionGroupDto.GROUP_TYPE_GENERAL_PROFILE:
            case DpDataPermissionGroupDto.GROUP_TYPE_PRIMARY_PROFILE:
                result = dpFeignClient.getAclMetaByGroup(group);
                result.forEach(map -> {
                    String resourceType = (String) map.get("resourceType");
                    Map<String, Object> labelInfo = (Map<String, Object>) map.get("labelInfo");
                    handleGeneralProfileLabelInfo(group, resourceType, labelInfo);
                });

                break;
            case DpDataPermissionGroupDto.GROUP_TYPE_CHANNEL:
                result = dpFeignClient.getAclMetaByGroup(group);
                break;
            case DpDataPermissionGroupDto.GROUP_TYPE_BUILT_IN:
                DpResource dpGroup = DpResource.getResourceByResourceName(group);
                if (dpGroup == null) {
                    log.error("group {} not found", group);
                    result = Collections.emptyList();
                    break;
                }
                result = dpFeignClient.getAclMetaByObjectList(
                        DpResource.toString(DpResource.getResourcesByGroup(dpGroup)));
                result.forEach(map -> {
                    String resourceType = (String) map.get("resourceType");
                    Map<String, Object> labelInfo = (Map<String, Object>) map.get("labelInfo");
                    labelInfo.put("cn", DpResource.getResourceByResourceName(resourceType).cn);
                });
                break;
        }

        return result;
    }

    private void handleGeneralProfileLabelInfo(String profileName, String resourceType, Map<String, Object> labelInfo){
        String profileCnName = getProfileCnName(profileName);
        if(StringUtils.isBlank(profileCnName)){
            return;
        }
        if (NamingUtils.toLowerUnderScoreCase(resourceType).equals(NamingUtils.toLowerUnderScoreCase(profileName))){
            labelInfo.put("cn", profileCnName);
        }else if (resourceType.endsWith("list_def")){
            labelInfo.put("cn", profileCnName+"群组");
        } else if (resourceType.endsWith("tag_def")) {
            labelInfo.put("cn", profileCnName+"标签");
        }else if (resourceType.endsWith("search")) {
            labelInfo.put("cn", profileCnName+"搜索");
        }
    }

    private String getProfileCnName(String profileName){
        ProfileBizMeta meta = profileMetaService.getProfileBizMeta(profileName);
        return meta.getName();
    }

    private List<DpDataPermissionGroupDto> convertBuiltinToFeView(List<DpResource> groupResources, String type){
        return groupResources.stream().map(dpResource ->
                new DpDataPermissionGroupDto(dpResource.resource, dpResource.cn, type)
        ).collect(Collectors.toList());
    }

    private List<ProfileBizMeta> getProfileBizMetas(String pattern){
        List<String> patternsArray = Collections.singletonList(pattern);
        return profileMetaService.
                queryAllProfileBizMetas(patternsArray, false, false, null, true).stream().filter(
                    profileBizMeta -> StringUtils.isNotBlank(profileBizMeta.getName())
                ).collect(Collectors.toList());
    }


    private List<DpDataPermissionGroupDto> convertProflieListToFeView(List<ProfileBizMeta> bizMetas, String type){
        return bizMetas.stream().map(profileBizMeta ->
                new DpDataPermissionGroupDto(profileBizMeta.getObjId(),
                        profileBizMeta.getName(),
                        type)
        ).collect(Collectors.toList());
    }

}
