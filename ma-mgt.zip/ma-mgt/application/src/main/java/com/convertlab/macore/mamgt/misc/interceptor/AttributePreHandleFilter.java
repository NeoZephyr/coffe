//package com.convertlab.macore.mamgt.misc.interceptor;
//
//import com.convertlab.macore.mamgt.cdp.meta.service.ProfileMetaService;
//import com.convertlab.macore.mamgt.cdp.service.ProfileMaskService;
//import com.convertlab.macore.mamgt.common.utils.CommonHelper;
//import com.convertlab.macore.mamgt.misc.service.impl.ResponseWrapper;
//import com.convertlab.macore.mamgt.misc.utils.AttributePreHandleHelper;
//import com.convertlab.macore.mamgt.misc.service.impl.RepeatReadRequest;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.core.annotation.Order;
//import org.springframework.stereotype.Component;
//import org.springframework.util.StopWatch;
//
//import javax.annotation.PostConstruct;
//import javax.annotation.Resource;
//import javax.servlet.*;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import java.io.*;
//import java.util.List;
//
///**
// * 请求响应的属性预处理拦截器 </br
// * 1.bk属性掩码处理
// */
//@Slf4j
//@Order(1)
//@Component
//public class AttributePreHandleFilter implements Filter {
//    private static final String LOG_PREFIX = "<ma-mgt> <RequestAttributePreHandle>";
//    @Resource
//    private ProfileMaskService profileMaskService;
//    @Resource
//    private ProfileMetaService profileMetaService;
//
//
//    @PostConstruct
//    private void init() {
//        AttributePreHandleHelper.init(profileMaskService, profileMetaService);
//    }
//
//
//    @Override
//    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
//            throws IOException, ServletException {
//        HttpServletRequest request = (HttpServletRequest) servletRequest;
//        HttpServletResponse response = (HttpServletResponse) servletResponse;
//        String method = request.getMethod();
//        String requestURI = request.getRequestURI();
//
//        AttributePreHandleHelper.AttributeHandleConfig conf = AttributePreHandleHelper.getConfigByPath(request);
//        if (conf == null) {
//            log.info("{} doFilter ing . handle ignore . method:{} ,path:{}", LOG_PREFIX, method, requestURI);
//            filterChain.doFilter(servletRequest, servletResponse);
//            return;
//        }
//
//
//        RepeatReadRequest repeatReadRequest = new RepeatReadRequest(request);
//        ResponseWrapper responseWrapper = new ResponseWrapper(response);
//
//        StopWatch stopWatch = new StopWatch();
//        stopWatch.start();
//        boolean isContinue = AttributePreHandleHelper.requestBeforeHandle(repeatReadRequest, responseWrapper);
//        stopWatch.stop();
//        log.info("{} doFilter ing . handle request end . cost:{} ms . method:{} ,path:{}", LOG_PREFIX, stopWatch.getLastTaskTimeMillis(), repeatReadRequest.getMethod(), repeatReadRequest.getRequestURI());
//
//        if (isContinue) {
//            filterChain.doFilter(repeatReadRequest, responseWrapper);
//        } else {
//            log.info("{} doFilter ing . requestBeforeHandle false . forward . method:{} ,path:{} ", LOG_PREFIX, repeatReadRequest.getMethod(), repeatReadRequest.getRequestURI());
//        }
//
//        String data = responseWrapper.getContent();
//        if (StringUtils.isBlank(data)) {
//            writerResponse(stopWatch, method, requestURI, response, data);
//            return;
//        }
//        if (data.contains("Not Found") && data.contains("path")) {
//            List<String> findStrList = CommonHelper.findAllFromStringByRegex(data, "(?<=(path\":\"))(.+?)(?=(\"))");
//            for (String str : findStrList) {
//                data = data.replaceAll(str, repeatReadRequest.getRequestURI());
//            }
//            writerResponse(stopWatch, method, requestURI, response, data);
//            return;
//        }
//
//        stopWatch.start();
//        Object dataObject = AttributePreHandleHelper.jsonToObject(data);
//        Object handleData = AttributePreHandleHelper.requestAfterHandle(dataObject, repeatReadRequest, response);
//        String dataJson = AttributePreHandleHelper.objectToString(handleData);
//        stopWatch.stop();
//        log.info("{} doFilter ing . handle response end . cost:{} ms . method:{} ,path:{}", LOG_PREFIX, stopWatch.getLastTaskTimeMillis(), repeatReadRequest.getMethod(), repeatReadRequest.getRequestURI());
//        writerResponse(stopWatch, method, requestURI, response, dataJson);
//    }
//
//    private static void writerResponse(StopWatch stopWatch, String method, String requestURI, HttpServletResponse response, String dataJson) throws IOException {
//        stopWatch.start();
//        response.setCharacterEncoding("UTF-8");
//        PrintWriter writer = response.getWriter();
//        writer.print(dataJson);
//        writer.flush();
//        writer.close();
//        stopWatch.stop();
//        log.info("{} doFilter end . write response end . cost:{} ms . method:{} ,path:{}", LOG_PREFIX, stopWatch.getLastTaskTimeMillis(), method, requestURI);
//    }
//}