package com.convertlab.macore.mamgt.datapermission.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.convertlab.foundation.library.mybatisplus.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;


@Data
@TableName(value = "dp_datapermission_rule")
@EqualsAndHashCode(callSuper=false)
public class DpDatapermissionRule extends BaseEntity {

    @TableId(value = "id", type = IdType.AUTO)
    Long id;
    public static final String STATUS_PROCESSING = "processing";
    public static final String STATUS_FINISHED = "finished";
    public static final String STATUS_FAILED = "failed";

    String name;
    String filter;
    String grantedSubjectCode;
    String status;
    String resourceType;
    String ignoredBusinessInfo;

}
