package com.convertlab.macore.mamgt.cdp.service;

import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.macore.mamgt.customer.model.SyncCustomerMetaDto;
import com.convertlab.macore.mamgt.customer.model.SyncCustomerEventMetaDto;

public interface PrimaryProfileBizMetaSyncService {
    void migratePrimaryProfileBizMeta(SyncCustomerMetaDto syncCustomerMetaDto) throws BusinessException;

    /**
     * 恢复系统设置
     */
    void resetCustomerPredefinedEventsToDefault();

    /**
     * 同步添加客户事件Meta
     *
     * @param syncCustomerMetaDto
     * @throws BusinessException
     */
    void syncAddCustomerEventMetaChange(SyncCustomerEventMetaDto syncCustomerMetaDto) throws BusinessException;

    /**
     * 同步删除客户事件Meta
     *
     * @param syncCustomerMetaDto
     * @throws BusinessException
     */
    void syncDeleteCustomerEventMetaChange(SyncCustomerEventMetaDto syncCustomerMetaDto) throws BusinessException;

}
