package com.convertlab.macore.mamgt.misc.configure;

import com.converlab.macore.filter.ViewModelConverter;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.redis.localcache.TenantAwareCache;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.mamgt.common.configure.ApplicationContextProvider;
import com.convertlab.macore.mamgt.filter.filters.model.FilterResponse;
import com.convertlab.macore.mamgt.filter.model.filterV4.request.FilterV4VO;
import com.convertlab.macore.mamgt.filter.model.filterv2.Preview;
import com.convertlab.macore.mamgt.filter.service.FilterV4Service;
import com.convertlab.macore.mamgt.misc.constants.ShareExecutorPool;
import com.convertlab.macore.mamgt.misc.globalsetting.service.GlobalSettingService;
import com.fasterxml.jackson.core.type.TypeReference;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.util.Asserts;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.info.BuildProperties;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.context.ApplicationContext;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import static com.convertlab.macore.mamgt.cdp.common.constants.ProfileConstants.PROFILE_CUSTOMER;
import static com.convertlab.macore.mamgt.misc.configure.CacheConfiguration.*;
import static com.convertlab.foundation.library.business.autoconfigure.SpringBeans.exitOnError;

@Slf4j
@Component
public class SystemWarmup implements CommandLineRunner {

    private final static String LOG_PREFIX = "<ma-mgt> <SystemWarmup> ";

    @Value("${convertlab.warmup.enabled:true}")
    private boolean warmupEnabled;

    @Value("${convertlab.warmup.tenants:1}")
    private String warmupTenants;
    private final ApplicationContext context;
    private final FilterV4Service filterV4Service;
    private final StringRedisTemplate stringRedisTemplate;
    private final GlobalSettingService globalSettingService;
    private final BuildProperties buildProperties;

    public SystemWarmup(ApplicationContext context, FilterV4Service filterV4Service,
                        BuildProperties buildProperties,
                        GlobalSettingService globalSettingService,
                        StringRedisTemplate stringRedisTemplate){
        this.context = context;
        this.filterV4Service = filterV4Service;
        this.buildProperties = buildProperties;
        this.globalSettingService = globalSettingService;
        this.stringRedisTemplate = stringRedisTemplate;
    }

    @Override
    public void run(String... args) throws Exception {
        try {
            log.info("BuildProperties( build version ): {}", JsonUtils.instanceOfDto().obj2Json(buildProperties));
            if(warmupEnabled){
                systemWarmup();
                for (String tenantStr : warmupTenants.split(",")) {
                    Long tenant = Long.parseLong(tenantStr);
                    if(tenant >0){
                        try (TemporaryTenantContext ignored = new TemporaryTenantContext(tenant)) {
                            log.info("Warming up tenant {}...", tenant);
                            tenantWarmup();
                        }
                    }
                }
                log.info("finished all warmup");
            }
            clearAllV4();
        } catch (Exception e) {
            log.error("System warmup failed.", e);
            exitOnError(-1, "System warmup failed.", e);
        }
    }

    public void clearAllV4() {
        // 获取分布式锁
        Boolean lock = stringRedisTemplate.opsForValue().setIfAbsent("system_clearV4_lock", "1", 5, TimeUnit.MINUTES);
        if (Boolean.TRUE.equals(lock)) {
            // 判断manifest.properties文件版本是否变更，变更了就做清理动作
            String convertV2ToV4Version = ViewModelConverter.getConvertV2ToV4Version();
            String globalValueByGlobalKey = globalSettingService.getGlobalValueByGlobalKey("convertV2ToV4");
            log.info("{} clearAllV4 start. convertV2ToV4Version: {} globalValueByGlobalKey: {}", LOG_PREFIX, convertV2ToV4Version, globalValueByGlobalKey);
            if (StringUtils.isNotBlank(convertV2ToV4Version) && !convertV2ToV4Version.equals(globalValueByGlobalKey)) {
                ShareExecutorPool
                        .getShareExecutor()
                        .shareExecutor
                        .execute(() -> {
                            log.info("{} start all clearV4.", LOG_PREFIX);
                            filterV4Service.clearFilterV4ByServiceUnit(null, null);
                            stringRedisTemplate.delete("system_clearV4_lock");
                            log.info("{} end all clearV4", LOG_PREFIX);
                        });
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                String now = simpleDateFormat.format(new Date());
                globalSettingService.upsertGlobalValue(1, "convertV2ToV4", convertV2ToV4Version,
                        "FilterV2转V4脚本版本", now, now,
                        true, "config", 1, "FilterV2转V4脚本版本");
            } else {
                log.warn("{} clearAllV4 do nothing. convertV2ToV4Version: {} globalValueByGlobalKey: {}", LOG_PREFIX, convertV2ToV4Version, globalValueByGlobalKey);
            }
        }
        log.info("{} clearAllV4 end.", LOG_PREFIX);
    }

    private void systemWarmup() throws Exception{
        log.info("Warming up system...");
        log.info("1. clean cache in redis...");
        cleanCacheInRedis();
        log.info("2. init javascript engine...");
        // try to init JavaScript engine for better performance
        filterV4Service.initJavaScriptEngine();
        log.info("Warming up system accomplished.");
    }

    /**
     * 清除所有redis中残留的GDM和Biz Meta缓存
     */
    public void cleanCacheInRedis() {
        if(ApplicationContextProvider.getApplicationContext() != null) {
            CacheManager cacheManager = ApplicationContextProvider.getApplicationContext().getBean(CacheManager.class);
            try {
                Cache cache = cacheManager.getCache(SYSTEM_LEVEL_BIZ_CACHE);
                if(cache !=null && cache instanceof TenantAwareCache){
                    ((TenantAwareCache)cache).clearAll();
                }
                cache = cacheManager.getCache(BIZ_META);
                if(cache !=null && cache instanceof TenantAwareCache){
                    ((TenantAwareCache)cache).clearAll();
                }
            } catch (Exception e) {
                log.error("failed to invalidate cache");
            }
        }
    }

    private void tenantWarmup() throws IOException {
        log.info("Warming up filterV4...");
        InputStream is = SystemWarmup.class.getClassLoader().getResourceAsStream("warmup/payload.json");
        Preview<FilterV4VO> preview = JsonUtils.dtoMapper().readValue(IOUtils.toString(is, StandardCharsets.UTF_8),
                new TypeReference<Preview<FilterV4VO>>() {
                });
        FilterResponse response = filterV4Service.filterV4List(PROFILE_CUSTOMER, preview, false);
        Asserts.check(response != null &&  response.getRecords().size() >= 0, "check tenant warmup data failed");
        log.info("Warming up succeed");
    }
}

