package com.convertlab.macore.mamgt.misc.controller;

import com.convertlab.foundation.library.constant.CustomHttpStatus;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.exception.business.DownstreamBusinessException;
import com.convertlab.macore.mamgt.misc.model.BffBusinessErrorInfo;
import com.convertlab.macore.mamgt.misc.model.BffBusinessErrorResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.annotation.Nonnull;

/**
 * ClassName: BaseBffController
 * Description: Bff Controller的基类, 处理报错信息
 * date: 2024/01/03 18:55 PM
 *
 * @author zihan.chen
 */
public class BaseController {
    @ExceptionHandler({BusinessException.class, DownstreamBusinessException.class})
    public ResponseEntity<BffBusinessErrorResponse> handleException(@Nonnull BusinessException exception) {
        BffBusinessErrorInfo errorInfo =
                BffBusinessErrorInfo.builder()
                        .code(exception.getCode())
                        .messageCode(exception.getMessageCode())
                        .messageArguments(exception.getMessageArguments())
                        .httpStatusCode(exception.getHttpStatusCode())
                        .additions(exception.getAdditions())
                        .build();
        BffBusinessErrorResponse response = BffBusinessErrorResponse.builder().error(errorInfo).build();
        return ResponseEntity.status(CustomHttpStatus.BUSINESS_ERROR.value())
                .body(response);
    }
}
