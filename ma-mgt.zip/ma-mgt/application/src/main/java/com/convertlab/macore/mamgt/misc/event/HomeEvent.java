package com.convertlab.macore.mamgt.misc.event;

import com.convertlab.foundation.library.business.eventbroker.EventOptions;
import com.convertlab.foundation.library.business.eventbroker.EventType;
import com.convertlab.foundation.library.business.eventbroker.NotificationEvent;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NonNull;
import org.checkerframework.checker.initialization.qual.Initialized;
import org.checkerframework.checker.nullness.qual.UnknownKeyFor;

import javax.annotation.Nonnull;

public class HomeEvent extends NotificationEvent<HomeEvent.Dto> {
    protected HomeEvent(@UnknownKeyFor @Initialized @NonNull Object source, Dto dto,
                        @Nonnull @UnknownKeyFor @org.checkerframework.checker.nullness.qual.NonNull @Initialized EventOptions options) {
        super(source, dto, options);
    }

    @Data
    @AllArgsConstructor
    public static class Dto {
        String message;
    }

    public enum HomeEventType implements EventType {
        // 事件
        DOOR_OPENED,

        // 指令
        CLEAN_HOUSE
        ;
        @Nonnull
        @Override
        public String getValue() {
            return toString();
        }
    }
}
