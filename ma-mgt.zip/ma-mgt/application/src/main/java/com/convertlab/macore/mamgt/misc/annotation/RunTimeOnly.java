package com.convertlab.macore.mamgt.misc.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * RunTimeOnly 标签会应用一下的场景：
 * 1. 实体类的方法上(for service implementation class)：标注在实体类的方法上，表示该方法只能在运行时调用；
 *   设计时调用不会抛出异常，但是会直接return
 * 2. @EventListener 的回调方法上
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface RunTimeOnly {
}
