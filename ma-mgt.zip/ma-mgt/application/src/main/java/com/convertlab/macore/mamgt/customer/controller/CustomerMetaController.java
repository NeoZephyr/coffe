package com.convertlab.macore.mamgt.customer.controller;

import com.convertlab.foundation.library.model.vo.GenericListResponse;
import com.convertlab.foundation.library.model.vo.GenericResponse;
import com.convertlab.macore.mamgt.cdp.meta.model.dto.bizmeta.EventProp;
import com.convertlab.macore.mamgt.cdp.meta.model.dto.bizmeta.EventTypeGroup;
import com.convertlab.macore.mamgt.cdp.meta.service.BizMetaStoreService;
import com.convertlab.macore.mamgt.cdp.service.PrimaryProfileBizMetaSyncService;
import com.convertlab.macore.mamgt.customer.model.SyncCustomerMetaDto;
import com.convertlab.macore.mamgt.customer.model.SyncCustomerEventMetaDto;
import com.convertlab.macore.mamgt.misc.annotation.DisplayOrder;
import com.convertlab.macore.mamgt.misc.annotation.I18nMeta;
import com.convertlab.macore.mamgt.misc.controller.BaseController;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.convertlab.macore.mamgt.cdp.common.constants.ProfileConstants.PROFILE_CUSTOMER;

@DisplayOrder(27)
@Slf4j
@RestController
@RequestMapping("/customer/meta/")
@RequiredArgsConstructor
@Tag(name = "历史客户Meta接口")
public class CustomerMetaController extends BaseController {

    private final PrimaryProfileBizMetaSyncService primaryProfileBizMetaSyncService;
    private final BizMetaStoreService bizMetaStoreService;

    @PostMapping("sync")
    @Operation(summary = "同步客户Meta变更", description = "同步客户Meta变更")
    public GenericResponse<Boolean> syncCustomerMetaChange(@RequestBody SyncCustomerMetaDto syncCustomerMetaDto) {
        primaryProfileBizMetaSyncService.migratePrimaryProfileBizMeta(syncCustomerMetaDto);
        return GenericResponse.<Boolean>builder().result(true).build();
    }

    @PostMapping("syncAddPluginEvent")
    @Operation(summary = "同步添加客户事件Meta", description = "同步添加客户事件Meta")
    public GenericResponse<Boolean> syncAddCustomerEventMetaChange(@RequestBody SyncCustomerEventMetaDto syncCustomerMetaDto) {
        primaryProfileBizMetaSyncService.syncAddCustomerEventMetaChange(syncCustomerMetaDto);
        return GenericResponse.<Boolean>builder().result(true).build();
    }

    @PostMapping("syncDeletePluginEvent")
    @Operation(summary = "同步删除客户事件Meta", description = "同步添加客户事件Meta")
    public GenericResponse<Boolean> syncDeleteCustomerEventMetaChange(@RequestBody SyncCustomerEventMetaDto syncCustomerMetaDto) {
        primaryProfileBizMetaSyncService.syncDeleteCustomerEventMetaChange(syncCustomerMetaDto);
        return GenericResponse.<Boolean>builder().result(true).build();
    }

    @GetMapping("reset")
    @Operation(summary = "恢复系统设置", description = "恢复客户系统事件设置")
    public GenericResponse<Boolean> reset() {
        primaryProfileBizMetaSyncService.resetCustomerPredefinedEventsToDefault();
        return GenericResponse.<Boolean>builder().result(true).build();
    }

    @GetMapping("/event/buildin/props")
    @Operation(summary = "事件的预置属性", description = "事件的预置属性")
    @I18nMeta
    public GenericListResponse<EventProp> getBuildInEventProps() {
        List<EventProp> result = bizMetaStoreService.loadBuildInEventProps(PROFILE_CUSTOMER);
        return GenericListResponse.<EventProp>builder().results(result).build();
    }

    @GetMapping("event-types")
    @Operation(summary = "系统预置事件", description = "系统预置事件，代替原customer-meta 项目的 MetaLoader.loadEventTypes()")
    @I18nMeta
    public GenericListResponse<EventTypeGroup> getSystemPredefineEventTypes() {
        List<EventTypeGroup> groupWithEvents = bizMetaStoreService.loadCustomerEventTypes();
        return GenericListResponse.<EventTypeGroup>builder().results(groupWithEvents).build();
    }

    @GetMapping("list-options")
    @Operation(summary = "补充到下拉选项的虚拟事件", description = "补充到下拉选项的虚拟事件，代替原customer-meta 项目的 MetaLoader.loadListOptions()")
    @I18nMeta
    public GenericListResponse<EventTypeGroup> getListOptions() {
        List<EventTypeGroup> groupWithEvents = bizMetaStoreService.loadListOptions();
        return GenericListResponse.<EventTypeGroup>builder().results(groupWithEvents).build();
    }
}
