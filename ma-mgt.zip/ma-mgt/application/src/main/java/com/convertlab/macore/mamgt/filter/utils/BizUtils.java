package com.convertlab.macore.mamgt.filter.utils;

import com.convertlab.macore.mamgt.filter.filters.model.Response;
import com.convertlab.macore.mamgt.filter.model.filterV4.Where;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.MDC;
import org.springframework.util.ObjectUtils;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class BizUtils {

    public static Response getSuccessResponse(Map data) {
        return getSuccessResponse(data, "", 200, 0);
    }

    public static Response getSuccessResponse(Map data, String message) {
        return getSuccessResponse(data, message, 200, 0);
    }

    public static Response getSuccessResponse(Map data, String message, int code, long records) {
        Response res = new Response();
        res.setData(data);
        res.setMessage(message);
        res.setStatus(code);
        res.setRecords(records);
        return res;
    }

    public static Response getSuccessResponse(Map data, String message, int code, long records, int total) {
        Response res = new Response();
        res.setData(data);
        res.setMessage(message);
        res.setStatus(code);
        res.setRecords(records);
        res.setTotal(total);
        return res;
    }

    public static Response getSuccessResponse(int code, long count, String message) {
        Response res = new Response();
        res.setMessage(message);
        res.setStatus(code);
        res.setCount(count);
        return res;
    }

    public static String writeObjectToString(Object query) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.writeValueAsString(query);
        } catch (Exception ex) {
            return "error";
        }
    }

    public static Response getExceptionResponse(String type, Exception e, String parameters, Logger log){
        Response res = new Response();
        log.error(type + " query error", e);
        if(!ObjectUtils.isEmpty(e.getMessage()) && e.getMessage().length() < 200){
            res.setMessage(e.getMessage());
        }else{
            res.setMessage("处理错误，请联系管理员");
        }
        res.setStatus(500);
        res.setTraceId(MDC.get("x_request_id"));
        log.error(type + " request parameter:" + parameters);
        return res;
    }

    public static String getSuccessResponseJson(int code, long count, String message) {
        Response res = new Response();
        res.setMessage(message);
        res.setStatus(code);
        res.setCount(count);
        return writeObjectToString(res);
    }

    public static String getCompareOperatorKey(Where.CompareOperator compareOperator){
        return ObjectUtils.isEmpty(compareOperator.getRight()) ? compareOperator.getLeft().getType() + "@" : compareOperator.getRight().getType() + "@";
    }

    public static String replaceMatchString(String str, List<String> matchList, List<String> replaceList) {
        for (int i = 0; i < matchList.size(); i++) {
            Pattern pattern = Pattern.compile(matchList.get(i));
            Matcher matcher = pattern.matcher(str);
            while (matcher.find()) {
                str = str.replaceAll(matchList.get(i), replaceList.get(i));
            }
        }
        return str;
    }

    public static String replaceMatchString(String str, String match, String replace){
        Pattern pattern = Pattern.compile(match);
        Matcher matcher = pattern.matcher(str);
        while (matcher.find()) {
            str = str.replaceAll(match, replace);
        }
        return str;
    }

    public static String getValueWithEntityMapping(String value, Map<String, String> entityMappings) {
        if (value != null && value.contains(".")) {
            String[] parts = value.split("\\.");
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < parts.length - 1; i++) {
                String mappedValue = entityMappings.get(parts[i]);
                if (mappedValue != null) {
                    stringBuilder.append(mappedValue).append(".");
                } else {
                    stringBuilder.append(parts[i]).append(".");
                }
            }
            return stringBuilder.append(parts[parts.length - 1]).toString();
        }
        return value;
    }
}

