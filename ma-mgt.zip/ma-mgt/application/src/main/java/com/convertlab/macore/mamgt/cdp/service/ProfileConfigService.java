package com.convertlab.macore.mamgt.cdp.service;


import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.macore.mamgt.cdp.common.utils.AES;
import com.convertlab.macore.mamgt.cdp.model.entity.ProfileConfig;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;

import static com.convertlab.foundation.library.constant.CommonErrors.GENERAL_ERROR;

public interface ProfileConfigService {
    /**
     * 根据type查询配置信息
     *
     * @param type 类型
     * @return
     */
    ProfileConfig findByType(String type);

    /**
     * 根据type查询配置信息
     *
     * @param type        类型
     * @param needDecrypt 是否需要解密，默认不需要
     * @return
     */
    Map<String, Object> findMetaByType(String type, Boolean needDecrypt);

    /**
     * 更新或插入配置
     *
     * @param profileConfig 配置信息
     * @return
     */
    ProfileConfig upsert(ProfileConfig profileConfig);

    /**
     * 校验字段是否存在
     *
     * @param name  字段名称
     * @param field 字段的值
     */
    default void checkMissField(String name, Object field) {
        if (checkObjectStringIsBlank(field)) {
            throw new BusinessException(GENERAL_ERROR, "MSG_104_000013", name + " must not empty", new String[]{name});
        }
    }

    /**
     * 校验object类型的字符串是否为空
     *
     * @param objStr object类型的字符串
     * @return 是否为空
     */
    default boolean checkObjectStringIsBlank(Object objStr) {
        return objStr == null || StringUtils.isBlank(objStr.toString());
    }

    /**
     * 加密字符
     *
     * @param aesPassword
     * @param oldStr
     * @param newStr
     * @return
     */
    default String encryptStr(String aesPassword, String oldStr, String newStr) {
        if (StringUtils.isBlank(oldStr) || !oldStr.equals(newStr)) {
            return AES.encrypt(newStr, aesPassword);
        }
        return newStr;
    }

    /**
     * 解密字符
     *
     * @param aesPassword 密钥
     * @param encryptStr  密文
     * @return
     */
    default String decryptStr(String aesPassword, String encryptStr) {
        if (StringUtils.isNotBlank(encryptStr)) {
            return AES.decrypt(encryptStr, aesPassword);
        }
        return encryptStr;
    }
}
