package com.convertlab.macore.mamgt.filter.utils;

import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.macore.mamgt.common.cache.MemCache;
import com.convertlab.macore.mamgt.common.cache.impl.CaffeineTenantIsolationMemCacheImpl;
import lombok.extern.slf4j.Slf4j;

import java.util.EnumMap;
import java.util.Map;

/**
 * 待调整为带租户ID
 * Meta Cache Helper
 */
@Slf4j
public class MetaCacheHelper {

    private static final Long CACHE_EXPIRATION_TIME = 60L;
    private static final long MAXIMUM_SIZE = 300L;
    private final static Map<MetaCacheType, MemCache<?>> CACHE_MAP = new EnumMap<>(MetaCacheType.class);

    static {
        for (MetaCacheType type : MetaCacheType.values()) {
            CACHE_MAP.put(type, new CaffeineTenantIsolationMemCacheImpl(CACHE_EXPIRATION_TIME, MAXIMUM_SIZE));
        }
    }

    public enum MetaCacheType {
        CUSTOMER_STAT("customer_stat"),
        EVENT_META("event_meta"),
        EVENT_TREE("event_tree"),
        IDENTITY("identity"),
        ORDER("order"),
        UDO_META("udo_meta"),
        CPM_PURPOSE_META("cpm_purpose_meta");
        private final String typeName;

        MetaCacheType(String typeName) {
            this.typeName = typeName;
        }

        public String typeName() {
            return typeName;
        }
    }

    public static <T> T getMetaCacheByMetaType(MetaCacheType metaCacheType, String metaIdentifier) {
        MemCache<?> cache = CACHE_MAP.get(metaCacheType);
        if (cache == null) {
            throw new BusinessException(CommonErrors.WRONG_TYPE,
                    "MSG_100_000011", new String[]{"缓存KEY类型", metaCacheType.typeName()}, 0);
        }
        return (T) cache.getIfPresent(metaCacheType.typeName() + metaIdentifier);
    }

    public static <T> void setMetaCacheByMetaType(MetaCacheType metaCacheType, T cache, String metaIdentifier) {
        MemCache<T> memCache = (MemCache<T>) CACHE_MAP.get(metaCacheType);
        if (memCache == null) {
            throw new BusinessException(CommonErrors.WRONG_TYPE,
                    "MSG_100_000011", new String[]{"缓存KEY类型", metaCacheType.typeName()}, 0);
        }
        memCache.put(metaCacheType.typeName() + metaIdentifier, cache);
    }
}
