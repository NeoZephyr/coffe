package com.convertlab.macore.mamgt.misc.localcache;

import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.redis.localcache.L2Cache;
import com.convertlab.macore.mamgt.cdp.service.clJob.handler.PreloadCacheJobHandler;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.Arrays;

@Slf4j
@Service("BizMetaCacheWarmup")
@AllArgsConstructor
public class CacheWarmUp implements L2Cache.CacheWarmupFunction {
    private static final String LOG_HEADER = "<CacheWarmUp>";

    private final StringRedisTemplate stringRedisTemplate;
    private final PreloadCacheJobHandler preloadCacheJobHandler;

    /**
     * 延迟重建meta
     */
    @Override
    public void doLazyCacheWarmup() {
        final Long tenantId = TenantContextHolder.getTenantId();
        if (tenantId == null) {
            log.error("{} doLazyCacheWarmUp failed since tenantId is empty", LOG_HEADER);
        }
        try (TemporaryTenantContext ignore = new TemporaryTenantContext(tenantId)) {
            log.info("{} throttle doLazyCacheWarmUp for tenantId: {}", LOG_HEADER, tenantId);
            preloadCacheJobHandler.executeMethodByTenantIds(Arrays.asList(tenantId), preloadCacheJobHandler.getExecuteMethodList(), null);
        }
    }
}
