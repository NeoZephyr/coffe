package com.convertlab.macore.mamgt.misc.advice;

import com.convertlab.foundation.library.model.vo.GenericListResponse;
import com.convertlab.foundation.library.model.vo.GenericPageResponse;
import com.convertlab.foundation.library.model.vo.GenericResponse;
import com.convertlab.foundation.library.webmvc.annotation.SkipRequestBodyAdvice;
import com.convertlab.foundation.library.webmvc.annotation.ViewController;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.base.BizObjectMeta;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.base.BizPropMeta;
import com.convertlab.macore.mamgt.cdp.misc.client.UserFeignClient;
import com.convertlab.macore.mamgt.common.cache.MemCache;
import com.convertlab.macore.mamgt.common.cache.impl.CaffeineTenantIsolationMemCacheImpl;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import javax.annotation.Nonnull;
import javax.validation.constraints.NotNull;

/**
 * Advice for Rendering ViewController Response and inject some common fields, like creatorName
 * Created by johnny.chen on 2023/10/15 11:25 AM
 */
@Slf4j
@RestControllerAdvice(annotations = {ViewController.class})
public class BffResponseBodyAdvice implements ResponseBodyAdvice<Object> {
    final static MemCache<String> userNameCache = new CaffeineTenantIsolationMemCacheImpl<String>(120L, 10000);

    @Value("${dataPermissionService.serverUrl}")
    protected String dataPermissionService;

    @Autowired
    private UserFeignClient dataPermissionFeignClient;

    /**
     * 兼容数据中两种格式的creator_id
     */
    private static final String CREATOR_ID = "creator_id";
    private static final String CAMEL_CREATOR_ID = "creatorId";
    private static final String CREATOR_NAME = "creator_name";
    private static final String CAMEL_CREATOR_NAME = "creatorName";
    private static final String LEGACY_CREATOR_NAME = "creator";


    @Override
    public boolean supports(
            @Nonnull MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
        if (returnType.getParameterType().isAssignableFrom(void.class)) {
            return false;
        }

        if (returnType.getContainingClass().isAnnotationPresent(SkipRequestBodyAdvice.class)
                || returnType.getMethod().isAnnotationPresent(SkipRequestBodyAdvice.class)) {
            return false;
        }

        return returnType.getContainingClass().isAnnotationPresent(ViewController.class)
                && returnType.getContainingClass().getPackage().getName()
                .matches("com\\.convertlab(\\.[a-zA-Z]+)+\\.bff(\\.[a-zA-Z]+)*");
    }

    @SneakyThrows
    @SuppressWarnings("unchecked")
    @Override
    public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType, Class<? extends HttpMessageConverter<?>> selectedConverterType, ServerHttpRequest request, ServerHttpResponse response) {
        log.debug("[BffResponseBodyAdvice] before inject");
        if (body != null) {
            if (body instanceof GenericResponse) {
                Object resultInResponse = ((GenericResponse<?>) body).getResult();
                if (resultInResponse !=null && resultInResponse instanceof BizObjectMeta) {
                    injectCreatorName((BizObjectMeta) resultInResponse);
                } else if (resultInResponse !=null && resultInResponse instanceof BizPropMeta) {
                    injectCreatorName((BizPropMeta) resultInResponse);
                } else if(resultInResponse !=null ){
                    tryInjectCreateNameToDataBean(resultInResponse);
                }
            } else if (body instanceof GenericListResponse) {
                if(((GenericListResponse<?>) body).getResults()!=null){
                    ((GenericListResponse<?>) body).getResults().forEach(it -> {
                        if (it instanceof BizObjectMeta) {
                            injectCreatorName((BizObjectMeta) it);
                        } else if (it instanceof BizPropMeta) {
                            injectCreatorName((BizPropMeta) it);
                        } else {
                            tryInjectCreateNameToDataBean(it);
                        }
                    });
                }
            } else if (body instanceof GenericPageResponse) {
                if(((GenericPageResponse<?>) body).getPagination() !=null && ((GenericPageResponse<?>) body).getPagination().getRecords() !=null){
                    for (Object record : ((GenericPageResponse<?>) body).getPagination().getRecords()) {
                        if (record instanceof BizObjectMeta) {
                            injectCreatorName((BizObjectMeta) record);
                        } else if (record instanceof BizPropMeta) {
                            injectCreatorName((BizPropMeta) record);
                        } else{
                            tryInjectCreateNameToDataBean(record);
                        }
                    }
                }
            }
        }
        log.debug("[BffResponseBodyAdvice] after inject");
        return body;
    }

    private void tryInjectCreateNameToDataBean(@NotNull Object data){
        try{
            String creatorId = BeanUtils.getProperty(data, CREATOR_ID);
            if( creatorId != null ) {
                String creatorName = getUserName(creatorId);
                if (StringUtils.isNotBlank(creatorName)) {
                    try {
                        BeanUtils.setProperty(data, CREATOR_NAME, creatorName);
                        BeanUtils.setProperty(data, LEGACY_CREATOR_NAME, creatorName);
                        BeanUtils.setProperty(data, CAMEL_CREATOR_NAME, creatorName);
                    }catch (Exception e){
                        // ignore
                    }
                }
                return;
            }

            String camelCaseCreatorId = BeanUtils.getProperty(data, CAMEL_CREATOR_ID);
            if( camelCaseCreatorId != null ) {
                String camelCaseCreatorName = getUserName(camelCaseCreatorId);
                if (StringUtils.isNotBlank(camelCaseCreatorName)) {
                    try {
                        BeanUtils.setProperty(data, CAMEL_CREATOR_NAME, camelCaseCreatorName);
                        BeanUtils.setProperty(data, LEGACY_CREATOR_NAME, camelCaseCreatorName);
                    }catch (Exception e){
                        // igonre
                    }
                }
                return;
            }
        }catch (Exception e){
        }
    }

    private void injectCreatorName(BizObjectMeta bizMeta) {
        // if creatorId is not null and not 0(anonymous), then inject creatorName by querying user
        if (bizMeta != null && bizMeta.getCreatorId() != null && StringUtils.isNotBlank(bizMeta.getCreatorId())
                && !bizMeta.getCreatorId().equals("0")) {
            String creatorName = getUserName(bizMeta.getCreatorId());
            if (StringUtils.isNotBlank(creatorName)) {
                bizMeta.setCreatorName(creatorName);
            }
        }
    }

    private void injectCreatorName(BizPropMeta bizMeta) {
        // if creatorId is not null and not 0(anonymous), then inject creatorName by querying user
        if (bizMeta != null && bizMeta.getCreatorId() != null && StringUtils.isNotBlank(bizMeta.getCreatorId())
                && !bizMeta.getCreatorId().equals("0")) {
            String creatorName = getUserName(bizMeta.getCreatorId());
            if (StringUtils.isNotBlank(creatorName)) {
                bizMeta.setCreatorName(creatorName);
            }
        }
    }

    public String getUserName(String userId) {
        return userNameCache.get(userId, (k) -> {
            try {
                UserFeignClient.UserInfo userInfo = dataPermissionFeignClient.getUserInfo(Long.valueOf(userId));
                if(userInfo !=null && userInfo.getName() !=null){
                    return userInfo.getName();
                }
                log.warn("failed to get user name for user id: " + userId + ", userMapper is null");
                return userId;
            } catch (Exception e) {
                log.warn("failed to get user name for user id: " + userId, e);
                return userId;
            }
        });
    }
}
