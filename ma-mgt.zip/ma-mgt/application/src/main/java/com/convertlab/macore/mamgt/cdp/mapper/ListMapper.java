package com.convertlab.macore.mamgt.cdp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.cdp.profile.model.entity.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ListMapper extends BaseMapper<List> {

}
