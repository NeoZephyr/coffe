package com.convertlab.macore.mamgt.misc.swagger;

import cn.hutool.core.io.resource.ResourceUtil;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.mamgt.cdp.common.annotations.CdpApi;
import com.convertlab.macore.mamgt.misc.annotation.DisplayOrder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.PathItem;
import io.swagger.v3.oas.models.Paths;
import io.swagger.v3.oas.models.examples.Example;
import io.swagger.v3.oas.models.media.MediaType;
import io.swagger.v3.oas.models.responses.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springdoc.core.OpenAPIService;
import org.springdoc.core.customizers.OpenApiBuilderCustomizer;
import org.springdoc.core.customizers.OpenApiCustomiser;
import org.springdoc.core.customizers.OperationCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.ClassUtils;

import java.util.*;

/**
 * Swagger 配置Beans
 * 1. 处理Swagger UI的请求，返回报文example文件
 * 2. 处理Swagger 中接口的排序
 * 3. 处理@CDP注解
 */
@Configuration
@Slf4j
public class SwaggerExampleConfiguration {
    // 一个Controller内最多有1000个api；api排序的时候，如果多个api属于同一个controller，
    // 其权重为${Controller的权重} * MAX_APIS_IN_ONE_CONTROLLER + api在Controller内的顺序
    private final long MAX_APIS_IN_ONE_CONTROLLER = 1000;

    // 不含@DisplayOrder注解的Controller，api排序时按出现顺序排序；其权重需要加上START_ORDER_BY_DEFAULT 基数，
    // 确保不含@DisplayOrder注解的Controller的api排在有@Order注解的Controller的api后面
    private final long START_ORDER_BY_DEFAULT = 3000 * 1000;

    // 存放controller的排序信息，如果有@DisplayOrder， 值为Order.value ; 如果没有@DisplayOrder，则值从3000 开始，顺序往后排
    private final Map<String, Long> controllerOrderMap = new HashMap<>();

    private final ObjectMapper objectMapper = JsonUtils.getDefaultObjectMapper();

    /**
     * 处理 带CdpApi注解的接口，目前是在summary上加上 [CDP API] 的字符串
     * @return
     */
    @Bean
    public OperationCustomizer handleCdpApiAnnotations() {
        return (operation, handlerMethod) -> {
            if(handlerMethod.getMethod() != null && handlerMethod.getMethod().isAnnotationPresent(CdpApi.class)){
                String summary = operation.getSummary();
                operation.setSummary("[CDP API] "+ ( (summary!=null)? summary: ""));
            }
            return operation;
        };
    }

    /**
     * 处理RequestBody 和Response中的 example ,如果example中指定了以"@example"开始的字符串，将从resource/example目录读取报文
     * 样例文件
     * @return
     */
    @Bean
    OpenApiCustomiser applyStandardOpenAPIModifications() {
        return openApi -> {
            Paths paths = new Paths();
            openApi.getPaths().entrySet().stream()
                    .forEach(stringPathItemEntry -> {
                        paths.addPathItem(stringPathItemEntry.getKey(),
                                addExamples(stringPathItemEntry.getValue()));
                    });
            openApi.setPaths(paths);
        };
    }

    // 根据@Order调整Controller的顺序, 记录到controllerOrderMap变量中
    @Bean
    OpenApiBuilderCustomizer applyOpenApiBuilderCustomizer(){
        return new OpenApiBuilderCustomizer(){
            @Override
            public void customise(OpenAPIService openApiService) {
                if(openApiService.getMappingsMap() != null){
                    final Map<String, Long> startIndexOfControllerWithoutOrder = new HashMap(){{
                       put("count", START_ORDER_BY_DEFAULT);
                    }};
                    openApiService.getMappingsMap().entrySet().forEach(it -> {
                        DisplayOrder order = ClassUtils.getUserClass((it.getValue().getClass())).getAnnotation(DisplayOrder.class);
                        io.swagger.v3.oas.annotations.tags.Tag tag = ClassUtils.getUserClass((it.getValue().getClass())).getAnnotation(io.swagger.v3.oas.annotations.tags.Tag.class);
                        if(order != null && tag !=null){
                            controllerOrderMap.put(tag.name(), (long) order.value());
                        }else if(tag !=null){
                            long appendAfter = startIndexOfControllerWithoutOrder.get("count");
                            startIndexOfControllerWithoutOrder.put("count", appendAfter+1);
                            controllerOrderMap.put(tag.name(), appendAfter);
                        }
                    });
                }
            }
        };
    }

    /**
     * 处理API的排序
     * @return
     */
    @Bean
    public OpenApiCustomiser sortPathsAndTags() {
        return openApi -> {
            Map<String, PathItem> paths = openApi.getPaths();
            Paths sortedPaths = new Paths();
            // 带权重的pathItem字典, 其中权重来自于在 applyOpenApiBuilderCustomizer中计算出的Controller的keyOrderMap
            Map<Long, Tuple2<String, PathItem>> weightedPathsMap = new HashMap<>();
            final Map<String, Long> startIndexOfControllerWithoutOrder = new HashMap(){{
                put("count", START_ORDER_BY_DEFAULT);
            }};

            paths.entrySet().forEach(entry -> {
                String pathPattern = entry.getKey();
                PathItem pathItem = entry.getValue();
                // 找到urlPattern 对应的第一个 operation的Tag
                Operation firstOperation = null;
                if(pathItem.getGet() !=null){
                    firstOperation = pathItem.getGet();
                }else if(pathItem.getPost() !=null){
                    firstOperation = pathItem.getPost();
                }else if(pathItem.getPut() !=null){
                    firstOperation = pathItem.getPut();
                }else if(pathItem.getDelete() !=null){
                    firstOperation = pathItem.getDelete();
                }

                String controllerTag = null;
                if(firstOperation != null && firstOperation.getTags() !=null && firstOperation.getTags().size() > 0){
                    controllerTag = firstOperation.getTags().get(0);
                }
                Tuple2 weightedPathTuple = new Tuple2(pathPattern, pathItem);
                if(controllerTag != null && controllerOrderMap.containsKey(controllerTag)){
                    long controllerWeight = controllerOrderMap.get(controllerTag);
                    // 如果该Controller下已有接口权重，则读取最大的已有
                    if(weightedPathsMap.containsKey(controllerWeight * MAX_APIS_IN_ONE_CONTROLLER)){
                        long pathItemWeight = getMaxWeightBetween(weightedPathsMap.keySet(),
                                controllerWeight * MAX_APIS_IN_ONE_CONTROLLER,
                                (controllerWeight+1) * MAX_APIS_IN_ONE_CONTROLLER);
                        weightedPathsMap.put(pathItemWeight+1, weightedPathTuple);
                    }else{
                        // 如果该Controller下没有接口权重，则*MAX_APIS_IN_ONE_CONTROLLER后放入
                        weightedPathsMap.put(controllerWeight * MAX_APIS_IN_ONE_CONTROLLER, weightedPathTuple);
                    }
                }else{
                    long appendAfter = startIndexOfControllerWithoutOrder.get("count");
                    startIndexOfControllerWithoutOrder.put("count", appendAfter+1);
                    weightedPathsMap.put(appendAfter, weightedPathTuple);
                }
            });

            // 将带有排序权重的weightedPathsMap中的PathItem，排序后依次写入sortedHashMap
            LinkedHashMap<String, PathItem> sortedHashMap = new LinkedHashMap<>();
            weightedPathsMap.keySet().stream().sorted().forEach(k -> {
                Tuple2<String, PathItem> weightedPathTuple = weightedPathsMap.get(k);
                sortedHashMap.put(weightedPathTuple.getFirst(), weightedPathTuple.getSecond());
            });

            sortedPaths.putAll(sortedHashMap);
            openApi.setPaths(sortedPaths);
        };
    }


    private static long getMaxWeightBetween(Set<Long> weights, long min, long max){
        return weights.stream().filter(it -> (it>=min && it<max)).sorted(Comparator.reverseOrder()).findFirst().orElse(min);
    }

    private void appendExampleToMedia(MediaType c) {
        if(c!=null && c.getExamples()!= null){
            c.getExamples().keySet().forEach(key -> {
                Example example = (Example)c.getExamples().get(key);
                if(example!= null && (example.getValue() instanceof String)
                        && StringUtils.isNotBlank((String) example.getValue())){
                    String fileName = (String) example.getValue();
                    // 判断从文件加载接口样例
                    if(fileName.startsWith("@") && fileName.lastIndexOf(".json") > 0){
                        try {
                            Object exampleData = objectMapper.readTree(ResourceUtil.readUtf8Str( fileName.replaceFirst("@","")));
                            if(exampleData instanceof ArrayNode){
                                example.setValue((ArrayNode) exampleData);
                            }else if(exampleData instanceof ObjectNode){
                                example.setValue((ObjectNode) exampleData);
                            }
                        } catch (JsonProcessingException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
            });
        }
    }

    /**
     * 根据资源文件，填充RequestBody的Example
     * @param pathItem 文件地址，以@开始, .json或者.json5 结束
     * @return
     */
    private PathItem addExamples(PathItem pathItem) {
        if(pathItem.getPost() != null && pathItem.getPost().getRequestBody() != null)  {
            pathItem.getPost().getRequestBody().getContent().values().stream()
                    .forEach(c -> appendExampleToMedia(c));
        }
        if(pathItem.getPut() != null && pathItem.getPut().getRequestBody() != null)  {
            pathItem.getPut().getRequestBody().getContent().values().stream()
                    .forEach(c -> appendExampleToMedia(c));
        }
        ApiResponses responses = null;

        if(pathItem.getPost() !=null){
            responses = pathItem.getPost().getResponses();
            associatedExampleToResponse(responses);
        }

        if(pathItem.getGet() != null){
            responses = pathItem.getGet().getResponses();
            associatedExampleToResponse(responses);
        }

        if(pathItem.getPut() != null){
            responses = pathItem.getPut().getResponses();
            associatedExampleToResponse(responses);
        }

        if(pathItem.getDelete() != null){
            responses = pathItem.getDelete().getResponses();
            associatedExampleToResponse(responses);
        }
        return pathItem;
    }

    private void associatedExampleToResponse (ApiResponses responses){
        if(responses != null){
            responses.values().stream().forEach(r -> {
                if(r != null && r.getContent() != null && r.getContent().values() != null) {
                    r.getContent().values().stream().forEach(c -> appendExampleToMedia(c));
                }
            });
        }
    }
    public static class Tuple2<A, B> {
        private final A first;
        private final B second;

        public Tuple2(A first, B second) {
            this.first = first;
            this.second = second;
        }

        public A getFirst() {
            return first;
        }

        public B getSecond() {
            return second;
        }

        @Override
        public String toString() {
            return "(" + first + ", " + second + ")";
        }
    }
}
