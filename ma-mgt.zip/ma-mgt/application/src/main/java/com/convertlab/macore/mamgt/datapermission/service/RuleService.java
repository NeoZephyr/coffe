package com.convertlab.macore.mamgt.datapermission.service;

import com.convertlab.foundation.api.queryengine.FilterV4Dto;
import com.convertlab.foundation.api.queryengine.SqlBuilder;
import com.convertlab.foundation.library.model.vo.GenericResponse;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.library.utils.LogUtils;
import com.convertlab.macore.mamgt.cdp.profile.common.utils.CdpFilterV4Helper;
import com.convertlab.macore.mamgt.cdp.profile.service.common.SparkJobHelper;
import com.convertlab.macore.mamgt.datapermission.client.DpFeignClient;
import com.convertlab.macore.mamgt.datapermission.model.DpDatapermissionRuleDto;
import com.convertlab.macore.mamgt.datapermission.model.DpRuleSparkResult;
import com.convertlab.macore.mamgt.datapermission.model.TaskType;
import com.convertlab.macore.mamgt.filter.model.filterv2.Filters;
import com.convertlab.macore.mamgt.filter.service.FilterV4Service;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.validation.constraints.NotNull;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class RuleService {
    private static final Boolean EVENT_JOB_TRIGGER = true;
    public static final String SPARK_JOB_DATA_PERMISSION = "spark-job-datapermission";
    public static final String SPARK_JOB_JAR_NAME = "spark-jobs";
    public static final String SPARK_JOB_DATA_PERMISSION_SUCCESS = "success";


    private final SparkJobHelper sparkJobHelper;
    private final DpFeignClient dpFeignClient;
    private final FilterV4Service filterV4Service;

    @Value("${kafka.datapermission.datapermissionTaskStatus.topic}")
    String statusTopic;

    public RuleService(SparkJobHelper sparkJobHelper, DpFeignClient dpFeignClient, FilterV4Service filterV4Service) {
        this.sparkJobHelper = sparkJobHelper;
        this.dpFeignClient = dpFeignClient;
        this.filterV4Service = filterV4Service;
    }

    public DpDatapermissionRuleDto saveDatapermissionRule(DpDatapermissionRuleDto dpDatapermissionRuleDto) {
        dpDatapermissionRuleDto = dpFeignClient.saveRule(dpDatapermissionRuleDto);
        startRuleCalTask(TaskType.create_rule, dpDatapermissionRuleDto.getId(),
            dpDatapermissionRuleDto.getProfileName(),
            dpDatapermissionRuleDto.getDeptCodes(),
            dpDatapermissionRuleDto.getFilter(), true);
        return dpDatapermissionRuleDto;
    }

    public DpDatapermissionRuleDto updateDatapermissionRule(Long id, DpDatapermissionRuleDto dpDatapermissionRuleDto) {
        dpDatapermissionRuleDto = dpFeignClient.updateRule(id, dpDatapermissionRuleDto);
        if (dpDatapermissionRuleDto.getFilter()!=null
            && !dpDatapermissionRuleDto.getFilter().isEmpty()) {
            startRuleCalTask(TaskType.update_rule, id,
                dpDatapermissionRuleDto.getProfileName(),
                dpDatapermissionRuleDto.getDeptCodes(),
                dpDatapermissionRuleDto.getFilter(), true);
        }
        return dpDatapermissionRuleDto;
    }

    public GenericResponse<Boolean> deleteDatapermissionRule(Long id) {
        DpDatapermissionRuleDto dpDatapermissionRuleDto = dpFeignClient.deleteRule(id);
        startRuleCalTask(TaskType.delete_rule, id,
            dpDatapermissionRuleDto.getProfileName(),
            dpDatapermissionRuleDto.getDeptCodes(),
            dpDatapermissionRuleDto.getFilter(), true);
        return GenericResponse.<Boolean>builder().result(true).build();
    }

    public List<DpDatapermissionRuleDto> listDatapermissionRule(String profileName, Integer pageNum, Integer pageSize) {
        return dpFeignClient.listRule(profileName, pageNum, pageSize);
    }

    public void updateDpStatus(Long ruleId, DpRuleSparkResult status){
        dpFeignClient.updateRuleStatus(ruleId, status);
    }

    public void startRuleRefreshTask() {
        log.info("start data permission refresh wrapper");
        Map<String, Object> message = new HashMap<>();
        message.put("tenantId", TenantContextHolder.getTenantId());
        message.put("useNewDPJob", true);
        message.put("flushImmediately", true);
        message.put("topic", statusTopic);

        Map<String, Object> taskDef = new HashMap<>();
        taskDef.put("type", TaskType.refresh_rule.name());
        message.put("taskDef", taskDef);
        startSparkJob(message);
    }

    public void startRuleCalTask(TaskType taskType, Long ruleId, String profileName, List<String> deptCodes,
                                 Map<String, Object> filter, Boolean flushImmediately) {
        try {
            log.info("start data permission task wrapper. Rule ID: " + ruleId);
            Map<String, Object> message = new HashMap<>();
            message.put("topic", statusTopic);
            message.put("tenantId", TenantContextHolder.getTenantId());
            message.put("useNewDPJob", true);
            message.put("subjectType", profileName);
            message.put("flushImmediately", flushImmediately);

            Map<String, Object> taskDef = new HashMap<>();
            taskDef.put("id", ruleId);
            taskDef.put("type", taskType);
            taskDef.put("grantedSubjectCodes", deptCodes);
            taskDef.put("subjectsSQL", convertFilterToSparkSql(profileName, filter));
            taskDef.put("ruleId", ruleId);
            message.put("taskDef", taskDef);
            startSparkJob(message);
        } catch (Exception e) {
            LogUtils.errorAndThrow(log, "Start data permission task wrapper failed.", e);
        }
    }

    private String convertFilterToSparkSql(String profileName, Map<String, Object> filter) {
        return CdpFilterV4Helper.filterV4ToSql(
            convertFilterToV4(profileName, filter),
            SqlBuilder.OutputFormat.SQL,
            SqlBuilder.SQLDialect.SPARK);
    }

    private boolean isFilterV4(Map<String, Object> filter) {
        return filter.containsKey("version") && filter.get("version").equals("4");
    }


    /**
     * 将 符合FilterV2格式的 filter条件（条件不含select字段） 转换为FilterV4Dto，生成的FilterV4Dto默认采用id，或者bk作为唯一的（人群包）select条件
     * 生成的FilterV4Dto将custoemr_id Cast为String类型，以方便SparkJob 执行时兼容物理表数据类型
     * 如果feFormatFilter中已有v4节点，将采用v4节点的ViewModel，无需JavaScript 将FilterV2转换为ViewModel，直接将v4代表的ViewModel转换为FilterV4
     * @param profileName 档案名称
     * @param feFormatFilter FilterV2条件（不含select，分页信息)
     * @return FilterV4 格式
     */
    private FilterV4Dto convertFilterToV4(@NotNull String profileName, Map<String, Object> feFormatFilter) {
        if (isFilterV4(feFormatFilter)) {
            return JsonUtils.instanceOfDto().json2Obj(JsonUtils.instanceOfDto().obj2Json(feFormatFilter), FilterV4Dto.class);
        }

        FilterV4Dto filterV4Dto = null;
        log.info("[RuleService] try to convert filterV2 of profile {} to filterV4", profileName);
        try{
            String filterV2Json = JsonUtils.instanceOfDto().obj2Json(feFormatFilter);
            Filters filterV2 = JsonUtils.instanceOfDto().json2Obj(filterV2Json, Filters.class);
            filterV4Dto = filterV4Service.convertFilterV2ToFilterV4(profileName, "SPARK", null, filterV2);
            String resultFilterV4String =  JsonUtils.instanceOfDto().obj2Json(filterV4Dto);
            log.info("[RuleService] response filterV4 is {}", resultFilterV4String);
        }catch (Exception e) {
            LogUtils.errorAndThrow(log, "convert filterV2 of profile " + profileName + " to filterV4 failed", e);
        }
        return filterV4Dto;
    }

    private void startSparkJob(Map<String, Object> message){
        log.info("start data permission task");
        if (Boolean.TRUE.equals(EVENT_JOB_TRIGGER)){
            Map<String, Object> result = sparkJobHelper.submitJob(SPARK_JOB_DATA_PERMISSION, SPARK_JOB_JAR_NAME, message, 1);
            Boolean isSuccess = (Boolean) result.getOrDefault(
                SPARK_JOB_DATA_PERMISSION_SUCCESS, null);
            log.info("Dp start result: {}!", isSuccess);
        }else{
            //todo: 2.12迁移到task Framework
//            JobData.JobDataBuilder jobDataBuilder = JobData.builder()
//                    .jobType(SPARK_JOB_DATA_PERMISSION)
//                    .bizUuid(UUID.randomUUID().toString())
//                    .appName("foundation")
//                    .jobHandler(SPARK_JOB_DATA_PERMISSION)
//                    .needNotification(true)
//                    .jobParameters(JsonUtils.instance().obj2Json(message, false));
//            bizJobClient.createAndStartBizJob(jobDataBuilder.build());
        }
    }
}
