package com.convertlab.macore.mamgt.misc.event;

import com.convertlab.foundation.library.business.eventbroker.NotificationEvent;
import com.convertlab.foundation.library.gdmmeta.constants.MetaEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import static com.convertlab.foundation.library.business.eventbroker.EventListenerHelper.NOTIFICATION_BROKER_EXECUTOR;

@Slf4j
@Component
public class MiscListenerExample {
    @Async(NOTIFICATION_BROKER_EXECUTOR)
    @EventListener
    public void onAllEvent(NotificationEvent<?> event){
        log.info("MiscListenerExample.onAllEvent: {}, {}", event.getLoggableContent(), event);
    }

    @Async(NOTIFICATION_BROKER_EXECUTOR)
    @EventListener
    public void onMetaEvent(MetaEvent event){
        log.info("MiscListenerExample.onMetaEvent: {}, {}", event.getLoggableContent(), event);
    }
}
