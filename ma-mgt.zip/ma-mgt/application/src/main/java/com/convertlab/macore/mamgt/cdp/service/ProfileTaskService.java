package com.convertlab.macore.mamgt.cdp.service;

import com.convertlab.macore.mamgt.cdp.ProfileTask;
import com.convertlab.macore.mamgt.cdp.dto.PageDataDto;
import com.convertlab.macore.mamgt.cdp.model.entity.ListUdoBatchTask;

import java.util.Map;

public interface ProfileTaskService {

    ListUdoBatchTask exportData(String profileName, ProfileTask.ExportDataRequest exportData) throws Exception;
    void afterExportDataComplete(Map<String, Object> message);
    PageDataDto<ListUdoBatchTask> getExportTasks(String profileName, String sort, String sidx, Integer rows, Integer page);
    ListUdoBatchTask findTaskByAttachmentUuid(String profileName, String uuid);
}
