package com.convertlab.macore.mamgt.cdp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.cdp.model.entity.GoodsUuid;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface GoodsMapper extends BaseMapper<GoodsUuid> {


    @Select({"<script>",
            "SELECT * FROM goods_uuid WHERE goods_uuid in ",
            " <foreach collection=\"uuids\" item=\"uuid\" open=\"(\" separator=\",\" close=\")\">",
            "          #{uuid}",
            "  </foreach>",
            "</script>"})
    @ResultType(GoodsUuid.class)
    List<GoodsUuid> getGoodsIdsByUuid(@Param("uuids") java.util.List<Object> uuids);





    @Insert({"<script>",
            "INSERT INTO goods_uuid ",
            " <foreach item=\"column\" collection=\"columns\"",
            "    open=\"(\" separator=\",\" close=\")\">",
            "          ${column}",
            "  </foreach>",
            " VALUES ",
            " <foreach item=\"value\" collection=\"values\"",
            "    open=\"(\" separator=\",\" close=\")\" nullable=\"true\">",
            "          #{value}",
            "  </foreach>",
            "</script>"})
    int insert(@Param("columns") List<String> columns, @Param("values") List<Object> values);


}
