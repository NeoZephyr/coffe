package com.convertlab.macore.mamgt.cdp.service;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public interface FileService {

    File downloadToFile(int attachId, String filePrefix) throws IOException;

    Map<String, Object> getTop2Rows(File file) throws IOException;

    List<String> readCsvLine(String row);

    Map deleteFile(Long failedAttachmentId);
}
