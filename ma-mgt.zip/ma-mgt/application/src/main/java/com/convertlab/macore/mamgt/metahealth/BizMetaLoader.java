package com.convertlab.macore.mamgt.metahealth;

import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.libaray.meta.health.MetaLoader;
import com.convertlab.foundation.libaray.meta.health.annotation.MetaLoaderAnnotation;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.ProfileBizMeta;
import com.convertlab.macore.mamgt.cdp.meta.service.ProfileMetaService;
import lombok.RequiredArgsConstructor;
import org.apache.hadoop.util.Lists;
import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.List;

@MetaLoaderAnnotation
@RequiredArgsConstructor
public class BizMetaLoader implements MetaLoader<ProfileBizMeta> {
    private final ProfileMetaService profileMetaService;

    @Override
    public @NonNull List<ProfileBizMeta> loadAll() {
        List<String> patterns = Lists.newArrayList("primary-profile", "general-profile");
        return profileMetaService.queryAllProfileBizMetas(patterns, true, false, GdmModelDto.ProvisionStatus.PROVISIONED, false);
    }
}
