package com.convertlab.macore.mamgt.cdp.service;

import com.convertlab.macore.mamgt.cdp.model.entity.GoodsUuid;

import java.util.List;

public interface GoodsService {

    /**
     * 查询在用商品对应的goods_id
     * @param uuids
     * @return
     */
    public List<GoodsUuid> getGoodsIdsByUuid(List<Object> uuids);



    /**
     * 维护在用商品唯一主键
     * @param uuid
     */
    public long insert(Object uuid);


}
