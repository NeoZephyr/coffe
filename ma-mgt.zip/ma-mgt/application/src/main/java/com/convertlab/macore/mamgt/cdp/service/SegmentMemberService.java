package com.convertlab.macore.mamgt.cdp.service;

import com.convertlab.macore.mamgt.cdp.ProfileQuery;
import com.convertlab.macore.mamgt.cdp.SegmentQuery;

import java.util.List;

public interface SegmentMemberService {

    ProfileQuery.ProfileResponseVo getSegmentMemberList(String profileName, String segmentId, String select, String startId, int rows, boolean needTotal);

    List<SegmentQuery.SegmentListResponseVo> getSegmentMemberCount(String profileName, String segmentIds, Boolean isStatic);

    boolean segmentMemberAsyncTask(String profileName, String segmentId, SegmentQuery.SegmentMemberTaskRequest segmentMemberTaskRequest);
}
