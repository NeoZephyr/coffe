package com.convertlab.macore.mamgt.datapermission.resource;


import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public enum DpResource {

    //    分类-根
    root("root", "根", null),
    empty("empty", "空", null),
    oneself("oneself", "自己", null),

    //    分类-渠道
    channel("channel", "渠道", empty),
    wechat("wechat", "微信生态", channel),
    sms("sms", "触达-短信", channel),
    email("email", "触达-电子邮件", channel),
    vms("vms", "触达-视频短信", channel),
    mms("mms", "触达-彩信", channel),
    gsms("gsms", "触达-国际短信", channel),
    appnotification("appnotification", "触达-App Push", channel),

    webhook("webhook", "Webhook", channel),

    //    分类-内容
    content("content", "内容", root),
    page("page", "微页面", content),
    form("form", "表单", content),
    file("file", "文件", content),
    media_resource("media_resource", "素材资源", content),

//      分类-内置插件
    built_in_plugin("built_in_plugin", "内置插件", root),
    promo_info("promo_info", "权益码", built_in_plugin),
    lucky_draw("lucky_draw", "抽奖活动", built_in_plugin),

//    分类-营销策略
    strategy("strategy", "营销策略", root),
    mktcmp("mktcmp", "营销活动", strategy),
    flow("workflow", "自动流程", strategy),

//    分类-数据看板
    insight("insight", "分析洞察", root),
    dashboard("dashboard", "数据看板", insight),
    url_tracker_url("url_tracker_url", "网页可跟踪URL", insight),
    url_tracker_wechat_app("url_tracker_wechat_app", "小程序可跟踪URL", insight),

    ;


    DpResource(String resource, String cn, DpResource parent) {
        this.resource = resource;
        this.parent = parent;
        this.cn = cn;
    }

    public static List<DpResource> getResourcesByGroup(DpResource parent) {
        return Arrays.stream(DpResource.values())
                .filter(r -> r.parent == parent)
                .collect(Collectors.toList());
    }

    public static DpResource getResourceByResourceName(String resource) {
        return Arrays.stream(DpResource.values())
                .filter(r -> r.resource.equals(resource))
                .findFirst()
                .orElse(null);
    }

    public static String toString(List<DpResource> resources) {
        return resources.stream().map(r -> r.resource).collect(Collectors.joining(","));
    }

    public String resource;

    public String cn;

    public DpResource parent;

}