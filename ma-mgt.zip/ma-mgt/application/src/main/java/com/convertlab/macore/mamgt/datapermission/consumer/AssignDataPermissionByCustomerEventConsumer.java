package com.convertlab.macore.mamgt.datapermission.consumer;

import com.convertlab.foundation.library.business.feature.FeatureClient;
import com.convertlab.foundation.library.datapermission.GrantedPermission;
import com.convertlab.foundation.library.datapermission.GrantedReason;
import com.convertlab.foundation.library.datapermission.GrantedSubjectType;
import com.convertlab.foundation.library.datapermission.ResourceAccessDto;
import com.convertlab.foundation.library.datapermission.entity.ResourceEntity;
import com.convertlab.foundation.library.datapermission.feign.ResourceAclClient;
import com.convertlab.foundation.library.datapermission.model.BatchResourceAccessDto;
import com.convertlab.foundation.library.datapermission.service.ResourceEntityService;
import com.convertlab.foundation.library.jdbc.datasource.lookup.DataSourceLookupHelper;
import com.convertlab.macore.mamgt.cdp.profile.service.ProfileService;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Nullable;
import java.util.*;

@Slf4j
@Service
public class AssignDataPermissionByCustomerEventConsumer {

    private ObjectMapper objectMapper;

    final FeatureClient featureClient;

    final ProfileService profileService;

    final ResourceAclClient resourceAclClient;

    final ResourceEntityService resourceEntityService;

    final KafkaTemplate<String, Map<String, Object>> kafkaTemplate;

    @Value("${kafka.reactflowRealtimeAction.topic}")
    private String updateCustomerTopic;

    public AssignDataPermissionByCustomerEventConsumer(ProfileService profileService, FeatureClient featureClient, ResourceAclClient resourceAclClient, ResourceEntityService resourceEntityService, KafkaTemplate<String, Map<String, Object>> kafkaTemplate){
        super();
        this.featureClient = featureClient;
        this.profileService = profileService;
        this.resourceAclClient = resourceAclClient;
        this.resourceEntityService = resourceEntityService;
        this.kafkaTemplate = kafkaTemplate;
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }
    @KafkaListener(
            topics = "${kafka.profileEventGroup.customerEventMerged.topic}",
            groupId = "${kafka.profileEventGroup.customerEventMerged.groupId}",
            concurrency = "${kafka.profileEventGroup.customerEventMerged.concurrency}",
            batch = "true")
    public void receive(@Nullable List<Map<String, Object>> messages) {
        log.info("receive CustomerEventMerged message: {}", messages);
        if(messages.isEmpty()){
            log.error("receive customerEventMerged message is null");
            return;
        }

        try{
            //TODO, 这里可能会有性能问题，目前的feature client是一个rest client。
            boolean featureEnabled = featureClient.checkToggleStatus("datapermission");
            if(featureEnabled){
                Map<String, String> cId2deptCode = new HashMap<>() ;
                //handle page event, 根据网页事件，来判断是否要给客户增加dept权限。
                handlePageEvent(messages, cId2deptCode);
                //handle wechat event, 根据微信扫码事件，来判断是否要给客户增加dept权限。
                handleWechatEvent(messages, cId2deptCode);
                //handle customer, 如果客户的dept_code为空，则更新dept_code， 如果客户的dept_code不为空，则在resource_access表中增加一个共享记录。
                handleCustomer(cId2deptCode);
            }
        }catch (Exception e){
            log.error("receive CustomerEventMerged message failed.", e);
        }
    }

    private void handleWechatEvent(List<Map<String, Object>> messages, Map<String, String> cId2deptCode) {

        Map<String,String> cid2uuid = new HashMap<>();
        for (Map<String, Object> message : messages) {
            if ("wechat_scan".equals(message.get("event"))) {
                String uuid = (String) message.get("targetId");
                Object cid = message.get("customerId");
                if (uuid != null && cid != null) {
                    cid2uuid.put(cid.toString(), uuid);
                }
            }
        }

        if (cid2uuid.isEmpty()) {
            return;
        }

        DataSourceLookupHelper.withLookupKey("main", () -> {
            //根据pageId,读取page的deptCode
            List<ResourceEntity> resourceEntities = resourceEntityService.getResourceEntityList("wechat_qrcode", new ArrayList<>(cid2uuid.values()));
            //轮询cId2uuid
            cid2uuid.forEach((customerId, uuid) -> {
                Optional<ResourceEntity> matchedEntity = resourceEntities.stream()
                        .filter(entity -> uuid.equals(entity.getResourceCode()))
                        .findFirst();

                if(matchedEntity.isPresent()){
                    // matchedEntity is not null
                    ResourceEntity entity = matchedEntity.get();
                    if(entity.getDeptCode() != null){
                        cId2deptCode.put(customerId,entity.getDeptCode());
                    }
                }
            });
        });

    }


    private void handlePageEvent(List<Map<String, Object>> messages, Map<String, String> cId2deptCode) {

        Map<String,String> cId2pageId = new HashMap<>();
        for (Map<String, Object> message : messages) {
            if ("open_page".equals(message.get("event")) || "submit_form".equals(message.get("event")) || "click_link_in_page".equals(message.get("event"))) {
                String pageId = (String) message.get("pageId");
                Object cid = message.get("customerId");
                if (pageId != null && cid != null) {
                    cId2pageId.put(cid.toString(), pageId);
                }
            }
        }

        if (cId2pageId.isEmpty()) {
            return;
        }

        DataSourceLookupHelper.withLookupKey("main", () -> {
            //根据pageId,读取page的deptCode
            List<ResourceEntity> resourceEntities = resourceEntityService.getResourceEntityList("page", new ArrayList<>(cId2pageId.values()));
            //轮询cId2pageId
            cId2pageId.forEach((customerId, pageId) -> {

                Optional<ResourceEntity> matchedEntity = resourceEntities.stream()
                        .filter(entity -> pageId.equals(entity.getResourceCode()))
                        .findFirst();

                if(matchedEntity.isPresent()){
                    // matchedEntity is not null
                    ResourceEntity entity = matchedEntity.get();
                    if(entity.getDeptCode() != null){
                        cId2deptCode.put(customerId,entity.getDeptCode());
                    }
                }
            });
        });
    }


    private void handleCustomer(Map<String, String> cId2deptCode) {

        if(cId2deptCode.isEmpty()){
            return;
        }

        //查找客户
        List<Map<String, Object>> customers =
                profileService.bulkGet("customer", Arrays.asList("id", "dept_code"), new ArrayList<>(cId2deptCode.keySet()));

        if(customers.isEmpty()){
            return;
        }

        // 从customers中过滤出dept_code为空的客户列表,调用ProfileService批量更新dept_code。
        List<Map<String, Object>> customersWithEmptyDeptCode = getCustomersNotAssignDept(cId2deptCode, customers);
        if(!customersWithEmptyDeptCode.isEmpty()){
            //TODO, 目前由于ProfileService还不支持更新客户，暂时先使用workaround方式，待ProfileService支持更新客户后，再将代码签回。
            customersWithEmptyDeptCode.forEach(map -> {
               String customerId = map.get("id").toString();
               String deptCode = map.get("deptCode").toString();
               kafkaTemplate.send(updateCustomerTopic, customerId, getUpdateCustoemrData(customerId, deptCode));
            });
        }

        // 从customers中过滤出dept_code不为空的客户列表，调用resource access service 批量保存。
        BatchResourceAccessDto batchResourceAccessDto = getCustomersAlreadyAssignDept(cId2deptCode, customers);
        if(!CollectionUtils.isEmpty(batchResourceAccessDto.getResourceAclList())){
            resourceAclClient.batchSave(batchResourceAccessDto);
        }
    }

    private Map<String, Object> getUpdateCustoemrData(String customerId, String deptCode){
        // 构造最内层actionBody结构
        Map<String, Object> actionBody = new HashMap<>();
        actionBody.put("inputValue", deptCode);
        actionBody.put("operator", "equal");
        actionBody.put("property", "deptCode");

        // 构造action结构
        Map<String, Object> action = new HashMap<>();
        action.put("actionBody", actionBody);
        action.put("actionType", "modify_property");

        // 构造最外层结构
        Map<String, Object> mainMap = new HashMap<>();
        mainMap.put("action", action);
        mainMap.put("customerId", customerId);
        mainMap.put("flowKey", "mamgt_temp");
        mainMap.put("realtime", true);

        return mainMap;
    }

    private static BatchResourceAccessDto getCustomersAlreadyAssignDept(Map<String, String> cId2deptCode, List<Map<String, Object>> customers) {
        BatchResourceAccessDto batchResourceAccessDto = new BatchResourceAccessDto();
        batchResourceAccessDto.setResourceType("customer");
        for(Map<String, Object> customer : customers){
            if(customer.get("dept_code") != null){
                // 如果客户的dept_code不为空，则创建一个dto对象。
                ResourceAccessDto dto = new ResourceAccessDto();
                dto.setResourceType("customer");
                dto.setResourceCode(customer.get("id").toString());
                dto.setGrantedSubjectType(GrantedSubjectType.SUBJECT_TYPE_DEPT);
                dto.setGrantedSubjectCode(cId2deptCode.get(customer.get("id")));
                dto.setGrantedPermission(GrantedPermission.ALL_ACCESS_LEVEL);
                dto.setGrantedReason(GrantedReason.GRANTED_REASON_CONTENT);
                batchResourceAccessDto.setResourceAclList(new ArrayList<>());
                batchResourceAccessDto.getResourceAclList().add(dto);
            }
        }
        return batchResourceAccessDto;
    }

    private static List<Map<String, Object>> getCustomersNotAssignDept(Map<String, String> cId2deptCode, List<Map<String, Object>> customers) {
        List<Map<String, Object>> customersWithEmptyDeptCode = new ArrayList<>();
        for(Map<String, Object> customer : customers){
            if(customer.get("dept_code") == null){
                customer.put("id", customer.get("id").toString());
                customer.put("deptCode", cId2deptCode.get(customer.get("id").toString()));
                customersWithEmptyDeptCode.add(customer);
            }
        }
        return customersWithEmptyDeptCode;
    }


}
