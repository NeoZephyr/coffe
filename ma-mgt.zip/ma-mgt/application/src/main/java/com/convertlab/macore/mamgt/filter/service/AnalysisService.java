package com.convertlab.macore.mamgt.filter.service;

import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;

public interface AnalysisService {
    GdmEntity getGdmMeta(String profileName);

    GdmModelDto getGdmModel(String profileName);
}
