package com.convertlab.macore.mamgt.datapermission.controller;


import com.convertlab.foundation.library.model.vo.GenericResponse;
import com.convertlab.macore.mamgt.datapermission.model.DpDatapermissionRuleDto;
import com.convertlab.macore.mamgt.datapermission.service.RuleService;
import com.convertlab.macore.mamgt.datapermission.service.job.DpRuleEvent;
import com.convertlab.macore.mamgt.datapermission.service.job.DpRuleHandler;
import com.convertlab.macore.mamgt.misc.controller.BaseController;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.Min;
import java.util.List;

@RestController
@RequestMapping("/dp/acl/setting")
@Tag(name = "数据权限接口")
public class ResourceAclSettingController extends BaseController {

    final RuleService ruleService;
    final DpRuleHandler dpRuleHandler;

    public ResourceAclSettingController(RuleService ruleService, DpRuleHandler dpRuleHandler) {
        this.ruleService = ruleService;
        this.dpRuleHandler = dpRuleHandler;
    }

    @PostMapping("/rule")
    public DpDatapermissionRuleDto saveRule(@RequestBody DpDatapermissionRuleDto dpDatapermissionRuleDto) {
        return ruleService.saveDatapermissionRule(dpDatapermissionRuleDto);
    }

    @PutMapping("/rule/{ruleId}")
    public DpDatapermissionRuleDto updateRule(@PathVariable Long ruleId, @RequestBody DpDatapermissionRuleDto dpDatapermissionRuleDto) {
        return ruleService.updateDatapermissionRule(ruleId, dpDatapermissionRuleDto);
    }

    @DeleteMapping("/rule/{ruleId}")
    public GenericResponse<Boolean> deleteRule(@PathVariable Long ruleId) {
        return ruleService.deleteDatapermissionRule(ruleId);
    }

    @GetMapping("/rules")
    public List<DpDatapermissionRuleDto> listRule(@RequestParam(name = "profile", defaultValue = "") String profile,
                                               @RequestParam(name = "pageNum", defaultValue = "1") @Min(1) Integer pageNum,
                                               @RequestParam(name = "pageSize", defaultValue = "50") @Min(1) Integer pageSize) {
        return ruleService.listDatapermissionRule(profile, pageNum, pageSize);
    }

    @PostMapping("/rules/reset")
    public GenericResponse<Boolean> reset() {
        dpRuleHandler.reset(DpRuleEvent.DpRuleEventType.DP_RULE_EVENT_TYPE_API_TRIGGER);
        return GenericResponse.<Boolean>builder().result(true).build();
    }

    @PostMapping("/rules/refresh")
    public GenericResponse<Boolean> refresh() {
        dpRuleHandler.refresh();
        return GenericResponse.<Boolean>builder().result(true).build();
    }

}
