package com.convertlab.macore.mamgt;


import com.convertlab.foundation.libaray.meta.health.config.EnableMetaHealthCheck;
import com.convertlab.foundation.library.redis.annotation.EnableRedisLocalCaching;
import com.convertlab.foundation.library.redis.annotation.EnableRedisLock;
import com.convertlab.macore.mamgt.misc.annotation.EnableL2RedisLocalCaching;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

import java.util.TimeZone;

@EnableFeignClients(basePackages = {
        "com.convertlab.foundation.library.datapermission.feign",
        "com.convertlab.foundation.library.queryengine.client",
        "com.convertlab.macore.mamgt.common.feign",
        "com.convertlab.macore.mamgt.cdp.misc.client",
        "com.convertlab.macore.mamgt.filter.filters.misc.client",
        "com.convertlab.macore.campaign.service.legacy.cms.client",
        "com.convertlab.macore.mamgt.*.client",
        "com.convertlab.macore.*.client",
        "com.convertlab.channel.client",
})
@SpringBootApplication
@EnableRedisLocalCaching
@EnableRedisLock
@EnableL2RedisLocalCaching
@MapperScan("com.convertlab.**.mapper")
@EnableMetaHealthCheck
public class MacoreApplication {
    public static void main(String[] args) {
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        SpringApplication.run(MacoreApplication.class, args);
    }
}
