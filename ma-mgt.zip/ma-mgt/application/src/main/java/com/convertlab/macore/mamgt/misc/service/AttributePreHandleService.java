package com.convertlab.macore.mamgt.misc.service;

import com.convertlab.macore.mamgt.misc.utils.AttributePreHandleHelper;
import com.convertlab.macore.mamgt.misc.service.impl.RepeatReadRequest;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public interface AttributePreHandleService {

    String getHandleType();

    Boolean handleRequest(RepeatReadRequest request, HttpServletResponse response, AttributePreHandleHelper.AttributeContext context, List<AttributePreHandleHelper.AttributeInfo> requestConfigs) throws ServletException, IOException;

    Object handleResponse(Object data, HttpServletRequest request, HttpServletResponse response, AttributePreHandleHelper.AttributeContext context, List<AttributePreHandleHelper.AttributeInfo> responseConfigs ) throws ServletException, IOException;
}
