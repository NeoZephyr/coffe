package com.convertlab.macore.mamgt.cdp.service;


import com.convertlab.macore.mamgt.cdp.common.enums.BussClassifyTypeEnum;
import lombok.Getter;
import lombok.Setter;

import java.util.Arrays;
import java.util.List;
import java.util.Map;


public interface ExternalImportService {
    public static final String TYPE_OSS = "oss";
    public static final String TYPE_COS = "cos";
    public static final String TYPE_FTP = "ftp";
    public static final String TYPE_SFTP = "sftp";


    public static final List<String> TAG_IMPORT_TYPE_List = Arrays.asList(TYPE_OSS, TYPE_COS, TYPE_FTP, TYPE_SFTP);

    public static final String TAG_TAG_FILE_TYPE_CSV = "csv";

    public static final String META_TYPE_TAG = "external_tag_setting";
    public static final String META_TYPE_SEGMENT = "external_list_setting";

    /**
     * 测试链接
     *
     * @param type    类型：trait ,segment
     * @param metaMap meta的map
     * @return
     */
    Boolean testConnect(BussClassifyTypeEnum type, Map<String, Object> metaMap);

    /**
     * 导入标签或群组
     *
     * @param type        类型：trait ,segment
     * @param profileName 档案名称（eg:customer,c_car ...）
     * @param dataList    标签或群组列表
     * @return
     */
    ImportResponse importData(BussClassifyTypeEnum type, String profileName, List<String> dataList);

    /**
     * 列出文件列表
     *
     * @param type        类型：trait ,segment
     * @param profileName 档案名称（eg:customer,c_car ...）
     * @return
     */
    List<ImportFileRecord> listFields(BussClassifyTypeEnum type, String profileName);

    /**
     * 查询导入列表
     *
     * @param type        类型：trait ,segment
     * @param profileName 档案名称（eg:customer,c_car ...）
     * @param startId     起始id
     * @param limit       长度限制
     * @return
     */
    ImportTraitsTaskService.ExternalTagImportTaskVO listImportHistory(BussClassifyTypeEnum type, String profileName, Long startId, Integer limit);

    /**
     * 根据业务type获取对象的meta类型
     *
     * @param bussType 业务type字符串
     * @return
     */
    default String getMetaTypeByBizType(String bussType) {
        return getMetaTypeByBizType(BussClassifyTypeEnum.getBussClassifyTypeEnumByName(bussType));
    }

    default String getMetaTypeByBizType(BussClassifyTypeEnum bussType) {
        if (bussType == BussClassifyTypeEnum.TRAIT) {
            return META_TYPE_TAG;
        }
        return META_TYPE_SEGMENT;
    }

    @Setter
    @Getter
    public static class ImportResponse {
        private Boolean isSuccess;
        private List<String> success;
        private List<String> failed;

        public ImportResponse() {
        }

        public ImportResponse(boolean isSuccess) {
            this.isSuccess = isSuccess;
        }

        public ImportResponse(List<String> success, List<String> failed) {
            this.isSuccess = true;
            this.success = success;
            this.failed = failed;
        }
    }

    @Setter
    @Getter
    public static class ImportFileRecord {
        private String name;
        private String filePath;
        private String status;
    }


    @Setter
    @Getter
    public static class ImportTaskMessage {
        private Long taskId;
        private String msgType;
        private Long tenantId;
        private String tagName;
        private String valueType;
        private Boolean multiValue = false;
        private String filePath;
        private Long tagId;
        private Map<String, Object> setting;
        private String tblName;
        private String profileName;
        private String group;
        private String refObjId;
        private Long ownerId;
        private Long creatorId;
        private String creatorName;
    }
}
