package com.convertlab.macore.mamgt.cdp.service;

import com.convertlab.macore.mamgt.cdp.ProfileQuery;

import java.util.List;

public interface ProfileBatchOperateService {

    Boolean support(String type);

    void dispatch(String profileName, ProfileQuery.BatchOperateRequest data);

    void modifyProps(String profileName, List<ProfileQuery.BatchOperateProperty> properties, List<String> bks);

}
