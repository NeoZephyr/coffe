package com.convertlab.macore.mamgt.misc.controller;

import com.convertlab.foundation.library.business.annotations.DesignTimeOnly;
import com.convertlab.foundation.library.business.annotations.RequiredApiFlag;
import com.convertlab.foundation.library.gdmmeta.client.GeneralMetaClient;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClientWrapper;
import com.convertlab.foundation.library.gdmmeta.client.SimpleMetaClient;
import com.convertlab.foundation.library.gdmmeta.model.general.BaseMetaSchema;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.BaseMetaDto;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.ObjectRequest;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.ObjectResponse;
import com.convertlab.foundation.library.gdmmeta.validation.Issue;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.library.webmvc.annotation.ViewController;
import com.convertlab.foundation.library.webmvc.swagger.DeptAuthentication;
import com.convertlab.foundation.library.webmvc.swagger.TenantAuthentication;
import com.convertlab.foundation.library.webmvc.swagger.UserAuthentication;
import com.convertlab.macore.ad.controller.bff.AdAccountController;
import com.convertlab.macore.ad.controller.bff.AdAudienceController;
import com.convertlab.macore.ad.controller.bff.AdCallbackController;
import com.convertlab.macore.ad.controller.bff.AdConfigController;
import com.convertlab.macore.mamgt.cdp.service.validation.ProfileValidator;
import com.convertlab.macore.mamgt.misc.service.HomeService;
import com.convertlab.macore.mamgt.misc.swagger.LanguageAuthentication;
import com.convertlab.macore.mamgt.misc.testingutil.dto.ApiForward;
import com.convertlab.macore.mamgt.misc.testingutil.dto.ApiForwardGroup;
import com.convertlab.macore.mamgt.misc.testingutil.dto.ApiForwardReplace;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.checkerframework.checker.initialization.qual.Initialized;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.UnknownKeyFor;
import org.springdoc.webmvc.api.OpenApiResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.MediaType;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

/**
 * HomePageController用来存放不属于业务Controller的杂项配置
 * 1. 开发时的api主页，提供工具链接，例如swagger-ui
 * 2. Swager-ui的配置, 通过@OpenAPIDefinition定义, 通过@SecurityRequirement引用;在HomePage上挂载TenantID和UserID的验证。
 */

// @OpenAPIDefinition是一个全局的swagger配置，可以在这里配置所有的swagger基本信息。
@RestController
@Slf4j
@OpenAPIDefinition(
        info = @io.swagger.v3.oas.annotations.info.Info(
                title = "MA Management API", version = "1.0", description = "A collection of APIs for MA CORE."
        ),
        security = {
                @SecurityRequirement(name = "tenantId"),
                @SecurityRequirement(name = "userDept"),
                @SecurityRequirement(name = "userId"),
                @SecurityRequirement(name = "userLang")
        }
)
// 虽然这里没有使用到TenantAuthentication和UserAuthentication，但是这里的@SecurityRequirement(name = "tenantId")
// 和@SecurityRequirement(name = "userId")会被swagger-ui读取到。 并且在swagger-ui的页面上会显示出来。
// 其他的API也会从此获益，因为这里的配置是全局的。
@RequiredArgsConstructor
public class HomePageController implements TenantAuthentication, UserAuthentication, DeptAuthentication, LanguageAuthentication {
    public static final String TEST = "test_";
    private final HomeService homeService;
    private final GsMetaClientWrapper metaClient;
    private final GeneralMetaClient generalMetaClient;
    private final ProfileValidator profileValidator;
    private final GsMetaClient gsMetaClient;
    private final OpenApiResource openApiResource;
    private AtomicBoolean hasRegisteredBff = new AtomicBoolean(false);
    @Autowired
    ApplicationContext context;

    private static final Map<String, Map<String, Object>> allowedApiGroup = new HashMap<>();

    static {
        allowedApiGroup.put("Bff 高级筛选接口", new HashMap() {{
            put("scopeId", "filter");
            put("serverAddress", "maMgtServer.serverUrl");
            put("forwardReplace", Arrays.asList(new ApiForwardReplace("/mamgt/filter/", "/filter/")));
        }});
        allowedApiGroup.put("Bff 档案接口", new HashMap() {{
            put("scopeId", "litecdp-meta");
            put("serverAddress", "maMgtServer.serverUrl");
            put("forwardReplace", Arrays.asList(new ApiForwardReplace("/mamgt/profiles/", "/profiles/")));
        }});
        allowedApiGroup.put("Bff 客户同意信息接口", new HashMap() {{
            put("scopeId", "cpm");
            put("serverAddress", "maMgtServer.serverUrl");
            put("forwardReplace", Arrays.asList(new ApiForwardReplace("/mamgt/cpm/", "/cpm/")));
        }});
        allowedApiGroup.put("Bff 资源接口", new HashMap() {{
            put("scopeId", "resource");
            put("serverAddress", "maMgtServer.serverUrl");
            put("forwardReplace", Arrays.asList(new ApiForwardReplace("/mamgt/", "")));
        }});

        allowedApiGroup.put("文件夹资源", new HashMap() {{
            put("scopeId", "folder");
            put("serverAddress", "maMgtServer.serverUrl");
            put("forwardReplace", Arrays.asList(new ApiForwardReplace("/mamgt/", "")));
        }});

        allowedApiGroup.put("Bff non copy 配置接口", new HashMap() {{
            put("scopeId", "non-copy");
            put("serverAddress", "maMgtServer.serverUrl");
            put("forwardReplace", Arrays.asList(new ApiForwardReplace("/mamgt/non-copy", "/non-copy")));
        }});

        allowedApiGroup.put(AdAccountController.TAG, new HashMap() {{
            put("scopeId", "ad_mkt-accounts");
            put("serverAddress", "maMgtServer.serverUrl");
            put("forwardReplace", Collections.singletonList(new ApiForwardReplace("/mamgt/ad_mkt/accounts", "/ad_mkt/accounts")));
        }});
        allowedApiGroup.put(AdAudienceController.TAG, new HashMap() {{
            put("scopeId", "ad_mkt-audience");
            put("serverAddress", "maMgtServer.serverUrl");
            put("forwardReplace", Collections.singletonList(new ApiForwardReplace("/mamgt/ad_mkt/audience", "/ad_mkt/audience")));
        }});
        allowedApiGroup.put(AdConfigController.TAG, new HashMap() {{
            put("scopeId", "ad_mkt-configs");
            put("serverAddress", "maMgtServer.serverUrl");
            put("forwardReplace", Collections.singletonList(new ApiForwardReplace("/mamgt/ad_mkt/configs", "/ad_mkt/configs")));
        }});
        allowedApiGroup.put(AdCallbackController.TAG, new HashMap() {{
            put("scopeId", "ad_mkt-callback");
            put("serverAddress", "maMgtServer.serverUrl");
            put("forwardReplace", Collections.singletonList(new ApiForwardReplace("/mamgt/ad_mkt/callback", "/ad_mkt/callback")));
        }});
    }

    /**
     * 扫描所有bff controller，将未登记到allowedApiGroup中的接口补充进去
     * @return
     */
    void registeredBff() {
        // can register only once
        if(hasRegisteredBff.compareAndSet(false, true)){
            log.info("=== automatically register Bff Controllers to Manifest === ");
            Map<String, Object> controllers = new HashMap<>();
            Map<String, Object> restControllers = context.getBeansWithAnnotation(RestController.class);
            Map<String, Object> viewControllers = context.getBeansWithAnnotation(ViewController.class);
            controllers.putAll(viewControllers);
            controllers.putAll(restControllers);

            controllers.entrySet().forEach(it -> {
                String key = it.getKey();
                Object controllerInstance = it.getValue();
                String pkg = controllerInstance.getClass().getPackage().getName();
                if(pkg.matches("com\\.convertlab(\\.[a-zA-Z]+)+\\.bff(\\.[a-zA-Z]+)*")){
                    Tag tag = controllerInstance.getClass().getAnnotation(Tag.class);
                    String name = tag.name();
                    RequestMapping requestMapping = org.springframework.util.ClassUtils.getUserClass(controllerInstance).getAnnotation(RequestMapping.class);
                    if(requestMapping==null || requestMapping.value().length != 1) {
                        return;
                    }
                    String mapping = requestMapping.value()[0];
                    if(StringUtils.isBlank(mapping)){
                        return;
                    }
                    if(mapping.startsWith("/")){
                        mapping = mapping.replaceFirst("/", "");
                    }
                    final String controllerPath = mapping;
                    if(StringUtils.isNotBlank(name) && !allowedApiGroup.containsKey(name)){
                        allowedApiGroup.put(name, new HashMap(){{
                            put("scopeId", key);
                            put("serverAddress", "maMgtServer.serverUrl");
                            put("forwardReplace", Arrays.asList(new ApiForwardReplace("/mamgt/"+ controllerPath, "/"+controllerPath)));
                        }});
                        log.info("=== register Bff: {} of path : {}", name, controllerPath);
                    }
                }
            });
        }
    }

    @GetMapping("/api/manifest")
    @Operation(summary = "生成app服务中的meta/api_forward.json", description = "生成app服务中的meta/api_forward.json")
    public List<ApiForwardGroup> generateApiForwardJson(HttpServletRequest request) throws Exception {
        registeredBff();

        String content = openApiResource.openapiJson(request, "/v3/api-docs", Locale.US);
        Map<String, Object> apiDocs = JsonUtils.instanceOfDto().json2Obj(content, HashMap.class);
        List<ApiForwardGroup> apiForwardGroups = new ArrayList<>();
        Map<String, Map<String, Object>> paths = (Map<String, Map<String, Object>>) apiDocs.get("paths");

        paths.entrySet().forEach(entry -> {
            String path = entry.getKey();
            Map<String, Object> methods = entry.getValue();
            methods.entrySet().forEach(methodEntry -> {
                String method = methodEntry.getKey();
                Map<String, Object> operation = (Map<String, Object>) methodEntry.getValue();
                List<String> tags = (List<String>) operation.get("tags");
                String summary = operation.getOrDefault("summary", "").toString();
                for (String tag : tags) {
                    if (allowedApiGroup.containsKey(tag)) {
                        String matchPath = path.replaceAll("\\{[A-z]+\\}", "*");
                        matchPath = matchPath.replace("/v1", "");
                        log.info("add {} {} to group {}", method, matchPath, tag);
                        String scopeId = allowedApiGroup.get(tag).get("scopeId").toString();
                        ApiForwardGroup apiForwardGroup = apiForwardGroups.stream().filter(it -> it.getScopeId().equals(scopeId)).findFirst().orElse(null);
                        if (apiForwardGroup == null) {
                            apiForwardGroup = new ApiForwardGroup();
                            apiForwardGroup.setDescription(tag);
                            apiForwardGroup.setServerAddress(allowedApiGroup.get(tag).get("serverAddress").toString());
                            apiForwardGroup.setForwardReplace((List) allowedApiGroup.get(tag).get("forwardReplace"));
                            apiForwardGroup.setScopeId(allowedApiGroup.get(tag).get("scopeId").toString());
                            apiForwardGroup.setApis(new ArrayList<ApiForward>());
                            apiForwardGroups.add(apiForwardGroup);
                        }
                        ApiForward apiForward = new ApiForward();
                        apiForward.setMethod(method.toUpperCase());
                        apiForward.setDescription(summary);
                        apiForward.setPath("/mamgt" + matchPath);
                        apiForwardGroup.getApis().add(apiForward);
                    }
                }
            });
        });
        return apiForwardGroups;
    }

    @GetMapping("/")
    @Hidden
    public String greeting() {
        return homeService.greeting();
    }

    @GetMapping("/sendEvent")
    @Hidden
    public void sendEvent() {
        homeService.sendEvent();
    }

    @GetMapping("/gsclientinfo")
    @Operation(summary = "获取gsclient信息", description = "获取gsclient信息")
    @Tag(name = "health-check-endpoint")
    public String getGsClientInfo() {
        return metaClient.getGsClientInfo();
    }

    @GetMapping("/checkDesignTime")
    @Operation(summary = "检查是否处于设计时模式", description = "检查是否处于设计时")
    @Tag(name = "health-check-endpoint")
    @DesignTimeOnly
    public boolean checkDesignTime() {
        return true;
    }

    @GetMapping("/_/test-meta-integrity")
    @Operation(summary = "检测foundation meta服务的一致性", description = "使用gsMetaClient.simpleClientOf(BaseMetaSchema.MetaType.EXT_MISC)通过高并发读写，检测foundation meta服务的一致性和缓存执行情况")
    @Tag(name = "health-check-endpoint")
    @RequiredApiFlag("test-meta-ops")
    public DummyDto testMetaHighPressureOps(@RequestParam(required = false, defaultValue = "10") int count,
                                            @RequestParam(required = false, defaultValue = "100") int sleep) throws InterruptedException {
        return runMetaPressureTest(count, sleep);
    }

    @Nonnull
    private DummyDto runMetaPressureTest(int count, int sleep) throws InterruptedException {
        @NonNull SimpleMetaClient miscClient = gsMetaClient.simpleClientOf(BaseMetaSchema.MetaType.EXT_MISC);
        Map<String, String> filter = new HashMap<>();
        filter.put("data.type", "DUMMY");
        List<DummyDto> dummies = miscClient.queryObjects2(filter, DummyDto.class);
        dummies.forEach(dummy -> miscClient.deleteObject(dummy.dummyName));
        ExecutorService executorService = new ThreadPoolExecutor(10, 10, 0L, java.util.concurrent.TimeUnit.MILLISECONDS, new java.util.concurrent.LinkedBlockingQueue<>());


        for (int i = 0; i < count; i++) {

            DummyDto dto = new DummyDto(TEST + i, TEST + i);
            miscClient.createObject2(dto.dummyName, dto);

            filter.clear();
            String names = "";
            for (int j = 0; j <= i; j++) {
                names += TEST + j + ",";
            }
            filter.put("objectName", names);

            Runnable task = getRunnable(i, miscClient, filter);
            executorService.submit(task);
            executorService.submit(task);
            executorService.submit(task);

            Thread.sleep(sleep);

            List<DummyDto> queryResult = miscClient.queryObjects2(filter, DummyDto.class);
            log.info("Meta pressure test, in round:" + i + ", expect:" + (i + 1) + ", actual:" + queryResult.size());
            if (queryResult.size() != i + 1) {
                throw new IllegalStateException("Meta pressure test failed, due to query result size mismatch, in round:" + i + ", expect:" + (i + 1) + ", actual:" + queryResult.size());
            }
        }
        DummyDto dummy;
        dummy = miscClient.getObject2(TEST + (count - 1), DummyDto.class);
        dummy.ext = "Summary:" + count + " rounds. OK";
        return dummy;
    }

    @Nonnull
    private static Runnable getRunnable(int i, @Nonnull SimpleMetaClient miscClient, Map<String, String> filter) {
        Runnable task = () -> {
            List<DummyDto> result = miscClient.queryObjects2(filter, DummyDto.class);
            log.info("Meta pressure test, in round:" + i + ", expect:" + (i + 1) + ", actual:" + result.size());
            if (result.size() != i + 1) {
                log.error("Meta pressure test failed, due to query result size mismatch, in round:" + i + ", expect:" + (i + 1) + ", actual:" + result.size());
                log.error("Filter: " + filter);
                log.error("Result: " + result);
                throw new IllegalStateException("Meta pressure test failed, due to query result size mismatch, in round:" + i + ", expect:" + (i + 1) + ", actual:" + result.size());
            }
        };
        return task;
    }

    @Nullable
    private static DummyDto touchDummy(@Nonnull SimpleMetaClient miscClient) {
        long start = System.currentTimeMillis();
        HomePageController.DummyDto result = miscClient.getObject2("test", DummyDto.class);
        log.info("Touch dummy took: {}ms", System.currentTimeMillis() - start);
        return result;
    }

    private static long stopWatch(Consumer<SimpleMetaClient> action) {
        long start = System.currentTimeMillis();
        action.accept(null);
        return System.currentTimeMillis() - start;
    }

    @Nullable
    @PostMapping(value = "/createDummyMeta", consumes = {MediaType.TEXT_PLAIN, MediaType.APPLICATION_JSON, "text/plain;charset=UTF-8"})
    @Operation(summary = "检查gsclient是否处于设计时模式", description = "检查gsclient是否处于设计时模式")
    @Tag(name = "health-check-endpoint")
    public DummyDto createDummyMeta(@RequestBody DummyDto dto) {
        @UnknownKeyFor @NonNull @Initialized SimpleMetaClient miscClient =
                metaClient.simpleClientOf(BaseMetaSchema.MetaType.EXT_MISC);
//        DummyDto dto = new DummyDto();
//        dto.dummyName = "dummy_" + UUID.randomUUID().toString().replace("-", "");
//        dto.dummyValue = "dummy_" + UUID.randomUUID().toString().replace("-", "");

        return miscClient.createObject2(dto.dummyName, dto);
    }

    @GetMapping("/checkMeta")
    @Tag(name = "health-check-endpoint")
    public List<Issue> checkMeta() {
        return profileValidator.validate();
    }

    @Nullable
    @PostMapping("/createDummyMeta2")
    @Operation(summary = "检查gsclient是否处于设计时模式", description = "检查gsclient是否处于设计时模式")
    @Tag(name = "health-check-endpoint")
    public DummyDto createDummyMeta2() {
        DummyDto dto = new DummyDto();
        dto.dummyName = "dummy_" + UUID.randomUUID().toString().replace("-", "");
        dto.dummyValue = "dummy_" + UUID.randomUUID().toString().replace("-", "");
        ObjectRequest request = new ObjectRequest(dto.dummyName, dto);
        @UnknownKeyFor @NonNull @Initialized ObjectResponse response =
                generalMetaClient.createObject(BaseMetaSchema.Namespace.EXT, BaseMetaSchema.MetaType.EXT_MISC,
                        request);
        return response.getObject(DummyDto.class);
    }

    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class DummyDto extends BaseMetaDto {
        String dummyName;
        String dummyValue;
        String ext;
        String type = "DUMMY";

        public DummyDto(String dummyName, String dummyValue) {
            this.dummyName = dummyName;
            this.dummyValue = dummyValue;
        }

        public DummyDto() {

        }
    }


}
