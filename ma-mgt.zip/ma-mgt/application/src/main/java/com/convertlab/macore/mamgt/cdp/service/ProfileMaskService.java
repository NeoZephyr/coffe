package com.convertlab.macore.mamgt.cdp.service;


import java.util.List;
import java.util.Map;

public interface ProfileMaskService {

    /**
     * 获取掩码白名单
     *
     * @param profileName 档案名称
     * @return
     */
    Map<String, Object> getMaskWhiteList(String profileName);

    /**
     * 保存掩码白名单
     *
     * @param profileName   档案名称
     * @param maskWhiteList 白名单列表
     * @return
     */
    Boolean saveMaskWhiteList(String profileName, Map<String, Object> maskWhiteList);

    /**
     * 检查是否在白名单中白名单
     *
     * @param profileName 档案名称
     * @return
     */
    Boolean checkInMaskWhiteList(String profileName);

    /**
     * 获取掩码规则配置
     *
     * @param profileName 档案名称
     * @return
     */
    List<Map<String, Object>> getMaskRuleSettings(String profileName);

    /**
     * 保存掩码规则配置
     *
     * @param profileName      档案名称
     * @param maskRuleSettings 掩码规则
     * @return
     */
    Boolean saveMaskRuleSettings(String profileName, List<Map<String, Object>> maskRuleSettings);

    /**
     * 检查租户是否存在掩码配置
     *
     * @return 是否存在掩码配置
     */
    Boolean checkTenantExistMaskRuleSettings();

    Boolean insertWithoutSu(String entityName, List<String> columns, List<Object> values);

    List<Map<String, Object>> selectByParamsInWithoutSu(String entityName, List<String> selectList, Map<String, List<String>> filterMap);

    Boolean deleteByIdWithoutSu(String entityName, String pkColumn, Object id);
}
