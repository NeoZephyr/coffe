package com.convertlab.macore.mamgt.customer.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.convertlab.foundation.library.mybatisplus.entity.BaseEntity;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;


@Getter
@Setter
@TableName(value = "tag_dimension",excludeProperty = {"version", "creatorName", "creatorId","updaterId", "updaterName"})
public class TagDimension extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @TableField("version")
    private Integer version;

    @TableField("dimension_key")
    private String dimensionKey;

    @TableField("name")
    private String name;

    @TableField("parent_key")
    private String parentKey;

    @TableField("is_single_choice")
    private Boolean isSingleChoice;

    @TableField("sequence")
    private Integer sequence = 0;

    @TableField("editable")
    private Boolean editable;

    @TableField("path")
    private String path;

    @TableField("dept_code")
    private String deptCode;

    @TableField("owner_id")
    private Long ownerId;

}

