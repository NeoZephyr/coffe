package com.convertlab.macore.mamgt.misc.interceptor;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.util.Enumeration;

/**
 * Filter to set Content-Type to application/json for all requests except for some specific ones.
 * 粗陋的实现，只是为了解决一个问题，不要以为它总能工作！XP-75027
 * 只有三个租户会触发这个问题：9321（98%）, 5633(1%)，1659(1%)
 * curl -X 'POST' \
 *   'http://localhost:9001/litecdp/v1/profiles/api/c_xxn_test/tags/bulkGet' \
 *   -H 'accept: application/json' \
 *   -H 'X-Tenant-Id: 1' \
 *   -H 'Content-Type: text/plain' \
 *   -d '{
 *   "objId": "c_xxn_test",
 *   "bks": [
 *     "test830002",
 *     "test825001",
 *     "test825005"
 *   ],
 *   "tagIds": [
 *     "1583266098432966656",
 *     "1586768416126277632"
 *   ],
 *   "labelIds": [
 *     "c_test825002"
 *   ]
 * }'
 */
@Component
@Order(1)
public class ContentTypePreFilter implements Filter {
    public static final String CONTENT_TYPE = "Content-Type";

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {
        filterChain.doFilter(new ContentTypeWrapper((HttpServletRequest) servletRequest), servletResponse);
    }

    private static class ContentTypeWrapper extends HttpServletRequestWrapper {
        public ContentTypeWrapper(HttpServletRequest request) {
            super(request);
        }

        private boolean keepContentType() {
            if (getRequestURI() == null || super.getHeader(CONTENT_TYPE) == null) return true;
            return !getRequestURI().contains("/litecdp/v1/profiles/api") // see also: com/convertlab/macore/mamgt/cdp/controller/openapi/OpenApiUDOController.java:68
                    && !getRequestURI().contains("createDummyMeta")
                    && !super.getHeader(CONTENT_TYPE).equalsIgnoreCase(MediaType.APPLICATION_JSON);
        }

        @Override
        public String getContentType() {
            if (keepContentType()) return super.getContentType();

            return MediaType.APPLICATION_JSON;
        }
        @Override
        public String getHeader(String name) {
            if (keepContentType() || name == null) return super.getHeader(name);

            if (name.equalsIgnoreCase(CONTENT_TYPE)) {
                return getContentType();
            }
            return super.getHeader(name);
        }

        @Override
        public Enumeration<String> getHeaderNames() {
            if (keepContentType()) return super.getHeaderNames();

            try {
                Enumeration<String> headerNames = super.getHeaderNames();
                return new Enumeration<String>() {
                    @Override
                    public boolean hasMoreElements() {
                        return headerNames.hasMoreElements();
                    }

                    @Override
                    public String nextElement() {
                        String headerName = headerNames.nextElement();
                        if (headerName.equalsIgnoreCase(CONTENT_TYPE)) {
                            return MediaType.APPLICATION_JSON;
                        }
                        return headerName;
                    }
                };
            } catch (Exception e) {
                return super.getHeaderNames();
            }
        }
    }
}