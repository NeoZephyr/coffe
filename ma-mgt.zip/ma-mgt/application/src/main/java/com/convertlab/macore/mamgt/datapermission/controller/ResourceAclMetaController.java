package com.convertlab.macore.mamgt.datapermission.controller;


import com.convertlab.macore.mamgt.datapermission.model.DpDataPermissionGroupDto;
import com.convertlab.macore.mamgt.datapermission.service.DpMetaService;
import com.convertlab.macore.mamgt.misc.annotation.I18nMeta;
import com.convertlab.macore.mamgt.misc.controller.BaseController;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/dp/acl/meta")
@Tag(name = "数据权限接口")
public class ResourceAclMetaController extends BaseController {

    final DpMetaService dpMetaService;

    public ResourceAclMetaController(DpMetaService dpMetaService) {
        this.dpMetaService = dpMetaService;
    }

    @GetMapping("")
    @I18nMeta
    public List<Map<String, Object>> getAclMeta(@RequestParam(name = "group") String group,
                                   @RequestParam(name = "groupType") String groupType) {
        return dpMetaService.getAclMeta(group, groupType);
    }

    @GetMapping("/group")
    @I18nMeta
    public List<DpDataPermissionGroupDto> getGroup() {
        return dpMetaService.getGroup();
    }

}
