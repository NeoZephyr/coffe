package com.convertlab.macore.mamgt.cdp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.cdp.model.entity.ProfileConfig;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

@Mapper
public interface ProfileConfigMapper extends BaseMapper<ProfileConfig> {

    @Select({"<script>",
            "SELECT ",
            " <foreach item=\"column\" collection=\"selectList\" separator=\",\">",
            "          ${column}",
            "  </foreach>",
            " FROM profile_config WHERE type in ",
            " <foreach collection=\"types\" item=\"type\" open=\"(\" separator=\",\" close=\")\">",
            "          #{type}",
            "  </foreach>",
            "</script>"})
    @ResultType(ProfileConfig.class)
    List<ProfileConfig> selectByType(@Param("selectList") List<String> selectList, @Param("types") List<String> types);

    @Insert({"<script>",
            "INSERT INTO profile_config ",
            " <foreach item=\"column\" collection=\"columns\"",
            "    open=\"(\" separator=\",\" close=\")\">",
            "          ${column}",
            "  </foreach>",
            " VALUES ",
            " <foreach item=\"value\" collection=\"values\"",
            "    open=\"(\" separator=\",\" close=\")\" nullable=\"true\">",
            "          #{value}",
            "  </foreach>",
            "</script>"})
    int insert(@Param("columns") List<String> columns, @Param("values") List<Object> values);

    @Update({"<script>",
            "UPDATE profile_config SET ",
            " <foreach collection=\"props\" index=\"key\" item=\"value\" separator=\",\">",
            "         ${key} = #{value}",
            "  </foreach>",
            " WHERE id = #{id}",
            "</script>"})
    int updateById(@Param("id") Long id, @Param("props") Map<String, Object> props);

}
