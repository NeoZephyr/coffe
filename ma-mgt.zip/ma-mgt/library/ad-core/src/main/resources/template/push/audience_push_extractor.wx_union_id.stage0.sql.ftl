<#if segmentProfile == 'customer'>
    <#if segmentType == 'dynamic'>
        <#assign list_customer_table = 'dynamic_list_member'>
    <#else>
        <#assign list_customer_table = 'list_member'>
    </#if>
</#if>


<#if segmentProfile == 'customer'>
    select wechat_fans.unionid as unionId

    from ${list_customer_table}

    inner join customer on ${list_customer_table}.customer_id = customer.id and ${list_customer_table}.tenant_id = customer.tenant_id

    left join wechat_fans on cast(${list_customer_table}.customer_id as string) = wechat_fans.customer_id and ${list_customer_table}.tenant_id = wechat_fans.tenant_id

    where
    ${list_customer_table}.tenant_id = ${tenantId?c}
    and ${list_customer_table}.list_id = ${segmentId?c}
    and wechat_fans.account_id = '${adPlatformInstanceAppId}'
    and wechat_fans.unionid is not null

<#else>
<#-- 目前只支持 customer -->
</#if>