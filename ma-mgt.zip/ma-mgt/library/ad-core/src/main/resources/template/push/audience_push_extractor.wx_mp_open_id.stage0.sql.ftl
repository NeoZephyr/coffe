<#if segmentProfile == 'customer'>
    <#if segmentType == 'dynamic'>
        <#assign list_customer_table = 'dynamic_list_member'>
    <#else>
        <#assign list_customer_table = 'list_member'>
    </#if>
</#if>


<#if segmentProfile == 'customer'>
    select customer.id as customerId

    from ${list_customer_table}

    inner join customer on ${list_customer_table}.customer_id = customer.id and ${list_customer_table}.tenant_id = customer.tenant_id

    where
    ${list_customer_table}.tenant_id = ${tenantId?c}
    and ${list_customer_table}.list_id = ${segmentId?c}

<#else>
<#-- 目前只支持 customer -->
</#if>