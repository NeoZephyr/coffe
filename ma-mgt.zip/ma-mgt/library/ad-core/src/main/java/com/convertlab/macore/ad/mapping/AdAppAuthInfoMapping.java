package com.convertlab.macore.ad.mapping;

import com.convertlab.macore.ad.model.dto.AdAppAuthInfoDTO;
import com.convertlab.macore.ad.model.entity.AdAppAuthInfo;
import com.convertlab.macore.ad.model.entity.AdAppAuthInfoExtField;
import org.mapstruct.*;

import java.util.List;

/**
 * @author luck
 * @since 2023/4/20 11:18
 */
@Mapper(componentModel = "spring",
        collectionMappingStrategy = CollectionMappingStrategy.ADDER_PREFERRED,
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        unmappedTargetPolicy = ReportingPolicy.WARN
)
public interface AdAppAuthInfoMapping {

    @Mapping(target = "uniqueExtFieldMap", ignore = true)
    @Mapping(target = "notUniqueExtFieldGroup", ignore = true)
    @Mapping(target = "extFieldMap", ignore = true)
    @Mapping(target = "extFieldGroup", ignore = true)
    @Mapping(target = "extFieldList", source = "adAppAuthInfoExtFieldList")
    AdAppAuthInfoDTO toDTO(AdAppAuthInfo adAppAuthInfo, List<AdAppAuthInfoExtField> adAppAuthInfoExtFieldList);

    AdAppAuthInfo toEntity(AdAppAuthInfoDTO adAppAuthInfoDTO);

    void updateByDTO(AdAppAuthInfoDTO adAppAuthInfoDTO, @MappingTarget AdAppAuthInfo adAppAuthInfo);

    AdAppAuthInfo genNew(AdAppAuthInfo existAdAppAuthInfo);
}
