package com.convertlab.macore.ad.job;

import cn.hutool.core.util.StrUtil;
import com.convertlab.data.job.core.handler.ClJobHandlerMark;
import com.convertlab.data.job.core.handler.annotation.ClJob;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.multitenancy.annotation.TenantIgnore;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.mybatisplus.entity.BaseEntity;
import com.convertlab.macore.ad.common.utils.JacksonUtils;
import com.convertlab.macore.ad.model.entity.AdAdvertiserAccount;
import com.convertlab.macore.ad.model.entity.AdAudiencePush;
import com.convertlab.macore.ad.model.entity.AdAudiencePushIdentityConfig;
import com.convertlab.macore.ad.service.dao.AdAdvertiserAccountService;
import com.convertlab.macore.ad.service.dao.AdAudiencePushIdentityConfigService;
import com.convertlab.macore.ad.service.dao.AdAudiencePushService;
import com.convertlab.macore.ad.service.muilt.impl.AdTencentServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;


/**
 * @author fucheng.ning
 * @version v1
 */
@Slf4j
@Component
@RestController
@DataSourceLookup("main")
@RequestMapping("/ad_mkt/job")
public class SyncPushFileStatusJobHandler implements ClJobHandlerMark {

    @Resource
    private AdAudiencePushIdentityConfigService adAudiencePushIdentityConfigService;
    @Resource
    private AdAdvertiserAccountService adAdvertiserAccountService;
    @Resource
    private AdAudiencePushService adAudiencePushService;
    @Resource
    private AdTencentServiceImpl adTencentService;

    /**
     * 同步 {@link AdAudiencePushIdentityConfig} 对应上传的文件解析状态
     * 3 分钟跑一次
     *
     * @author luck
     */
    @TenantIgnore
    @Transactional(rollbackFor = Exception.class)
    @PostMapping("/syncPushFileStatusJobHandler")
    @ClJob(value = "syncPushFileStatusJobHandler")
    public void run() {
        log.info("SyncPushFileStatusJobHandler_run start");

        Number lastIdOffsetId = null;

        List<AdAudiencePushIdentityConfig> adAudiencePushIdentityConfigList = new ArrayList<>();
        Instant now = Instant.now();
        Instant minusOneMonth = ZonedDateTime.ofInstant(now, ZoneId.systemDefault()).minusMonths(1).toInstant();

        while (true) {
            try {
                adAudiencePushIdentityConfigList = adAudiencePushIdentityConfigService.getBaseMapper().nativeListSyncPushFileStatusJobHandlerData(minusOneMonth, lastIdOffsetId, 20);
            } catch (Exception e) {
                log.error("SyncPushFileStatusJobHandler_run query exception, time: {}, lastIdOffsetId: {}, limit: {}, list: {}", now, lastIdOffsetId, 20, JacksonUtils.toJSONString(adAudiencePushIdentityConfigList));
            }
            if (CollectionUtils.isEmpty(adAudiencePushIdentityConfigList)) {
                log.warn("SyncPushFileStatusJobHandler_run break");
                break;
            }

            log.info("SyncPushFileStatusJobHandler_run while process, lastIdOffsetId: {}, adAudiencePushIdentityConfigList: {}", lastIdOffsetId, JacksonUtils.toJSONString(adAudiencePushIdentityConfigList));
            lastIdOffsetId = adAudiencePushIdentityConfigList.stream().mapToLong(AdAudiencePushIdentityConfig::getId).max().getAsLong();

            Map<Long, List<AdAudiencePushIdentityConfig>> tenantIdGroup = adAudiencePushIdentityConfigList.stream().collect(Collectors.groupingBy(AdAudiencePushIdentityConfig::getTenantId));

            for (Map.Entry<Long, List<AdAudiencePushIdentityConfig>> tenantEntry : tenantIdGroup.entrySet()) {
                Long tenantId = tenantEntry.getKey();

                // 跨租户查了出来，但是要单独租户处理
                try (TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(tenantId)) {
                    List<AdAudiencePushIdentityConfig> audiencePushIdentityConfigList = tenantEntry.getValue();

                    List<Long> audiencePushIdList = audiencePushIdentityConfigList.stream().map(AdAudiencePushIdentityConfig::getAudiencePushId).collect(Collectors.toList());
                    Map<Long, AdAudiencePush> adAudiencePushMap = CollectionUtils.isEmpty(audiencePushIdList) ? new HashMap<>() : adAudiencePushService.listByIds(audiencePushIdList).stream().collect(HashMap::new, (map, i) -> map.put(i.getId(), i), HashMap::putAll);

                    List<Long> advertiserAccountIdList = adAudiencePushMap.values().stream().map(AdAudiencePush::getAdvertiserAccountId).collect(Collectors.toList());
                    Map<Long, AdAdvertiserAccount> adAdvertiserAccountMap = CollectionUtils.isEmpty(advertiserAccountIdList) ? new HashMap<>() : adAdvertiserAccountService.listByIds(advertiserAccountIdList).stream().collect(HashMap::new, (map, i) -> map.put(i.getId(), i), HashMap::putAll);

                    for (AdAudiencePushIdentityConfig audiencePushIdentityConfig : audiencePushIdentityConfigList) {
                        run(audiencePushIdentityConfig, adAudiencePushMap, adAdvertiserAccountMap);
                    }
                }
            }
        }

        log.info("SyncPushFileStatusJobHandler_run end");

    }

    public void run(AdAudiencePushIdentityConfig audiencePushIdentityConfig, Map<Long, AdAudiencePush> adAudiencePushMap, Map<Long, AdAdvertiserAccount> adAdvertiserAccountMap) {
        String updateAudiencePushIdentityConfigPushStatus = null;
        String updateAudiencePushIdentityConfigOuterPushStatus = null;
        String updateAudiencePushIdentityConfigPushReason = null;
        Integer updateAudiencePushIdentityConfigPushCount = 0;
        Integer updateAudiencePushIdentityConfigPushSuccessCount = 0;

        try {
            log.info("SyncPushFileStatusJobHandler_run processing adAudiencePushIdentityConfig: {}", JacksonUtils.toJSONString(audiencePushIdentityConfig));
            AdAudiencePush adAudiencePush = adAudiencePushMap.get(audiencePushIdentityConfig.getAudiencePushId());

            if (Objects.isNull(adAudiencePush)) {
                String msg = StrUtil.format("SyncPushFileStatusJobHandler_run processing adAudiencePushIdentityConfig adAudiencePushId: {} is not found. ", audiencePushIdentityConfig.getAudiencePushId());
                updateAudiencePushIdentityConfigPushReason = msg;
                log.warn(msg);
                throw new RuntimeException(msg);
            }

            AdAdvertiserAccount advertiserAccount = adAdvertiserAccountMap.get(adAudiencePush.getAdvertiserAccountId());
            if (Objects.isNull(advertiserAccount)) {
                String msg = StrUtil.format("SyncPushFileStatusJobHandler_run processing adAudiencePushIdentityConfig advertiserAccountId: {} is not found. ", adAudiencePush.getAdvertiserAccountId());
                updateAudiencePushIdentityConfigPushReason = msg;
                log.warn(msg);
                throw new RuntimeException(msg);
            }

            AdAudiencePushIdentityConfig adAudiencePushIdentityConfigForCount = adTencentService.getAdAudiencePushIdentityConfigCount(advertiserAccount, adAudiencePush, audiencePushIdentityConfig);

            if (Objects.nonNull(adAudiencePushIdentityConfigForCount)) {
                updateAudiencePushIdentityConfigPushCount = adAudiencePushIdentityConfigForCount.getPushCount();
                updateAudiencePushIdentityConfigPushStatus = adAudiencePushIdentityConfigForCount.getPushStatus();
                updateAudiencePushIdentityConfigPushSuccessCount = adAudiencePushIdentityConfigForCount.getPushSuccessCount();
                updateAudiencePushIdentityConfigOuterPushStatus = adAudiencePushIdentityConfigForCount.getOuterPushStatus();
            }

        } catch (Exception e) {
            log.warn("SyncPushFileStatusJobHandler_run processing adAudiencePushIdentityConfig: {}, e: ", JacksonUtils.toJSONString(audiencePushIdentityConfig), e);
            updateAudiencePushIdentityConfigPushStatus = AdAudiencePush.PushStatus.FAILURE.getCode();
            updateAudiencePushIdentityConfigPushReason = e.getMessage();
        } finally {

            adAudiencePushIdentityConfigService.lambdaUpdate()
                    .eq(AdAudiencePushIdentityConfig::getId, audiencePushIdentityConfig.getId())
                    .eq(AdAudiencePushIdentityConfig::getPushStatus, AdAudiencePush.PushStatus.PROCESSING.getCode())
                    .set(AdAudiencePushIdentityConfig::getPushCount, updateAudiencePushIdentityConfigPushCount)
                    .set(AdAudiencePushIdentityConfig::getPushSuccessCount, updateAudiencePushIdentityConfigPushSuccessCount)
                    .set(StringUtils.hasLength(updateAudiencePushIdentityConfigOuterPushStatus),
                            AdAudiencePushIdentityConfig::getOuterPushStatus,
                            updateAudiencePushIdentityConfigOuterPushStatus
                    )
                    .set(Arrays.asList(AdAudiencePush.PushStatus.SUCCESS.getCode(), AdAudiencePush.PushStatus.FAILURE.getCode()).contains(updateAudiencePushIdentityConfigPushStatus),
                            AdAudiencePushIdentityConfig::getPushStatus,
                            updateAudiencePushIdentityConfigPushStatus
                    )
                    .set(StringUtils.hasLength(updateAudiencePushIdentityConfigPushReason),
                            AdAudiencePushIdentityConfig::getPushReason,
                            updateAudiencePushIdentityConfigPushReason
                    )
                    .set(AdAudiencePushIdentityConfig::getUpdaterId, audiencePushIdentityConfig.getUpdaterId())
                    .set(AdAudiencePushIdentityConfig::getUpdaterName, audiencePushIdentityConfig.getUpdaterName())
                    .set(AdAudiencePushIdentityConfig::getLastUpdated, Instant.now())
                    .update();

        }
    }
}