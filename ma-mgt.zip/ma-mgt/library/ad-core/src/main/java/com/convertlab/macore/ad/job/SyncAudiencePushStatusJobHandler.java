package com.convertlab.macore.ad.job;

import cn.hutool.core.util.StrUtil;
import com.convertlab.data.job.core.handler.ClJobHandlerMark;
import com.convertlab.data.job.core.handler.annotation.ClJob;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.jdbc.datasource.lookup.DataSourceLookupHelper;
import com.convertlab.foundation.library.multitenancy.annotation.TenantIgnore;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.macore.ad.common.utils.JacksonUtils;
import com.convertlab.macore.ad.model.entity.AdAdvertiserAccount;
import com.convertlab.macore.ad.model.entity.AdAudiencePush;
import com.convertlab.macore.ad.model.entity.AdAudiencePushIdentityConfig;
import com.convertlab.macore.ad.service.dao.AdAdvertiserAccountService;
import com.convertlab.macore.ad.service.dao.AdAudiencePushIdentityConfigService;
import com.convertlab.macore.ad.service.dao.AdAudiencePushService;
import com.convertlab.macore.ad.service.muilt.impl.AdTencentServiceImpl;
import com.convertlab.macore.mamgt.cdp.profile.service.RetrievalCommonService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.stream.Collectors;


/**
 * @author fucheng.ning
 * @version v1
 */
@Slf4j
@Component
@RestController
@DataSourceLookup("main")
@RequestMapping("/ad_mkt/job")
public class SyncAudiencePushStatusJobHandler implements ClJobHandlerMark {

    @Resource
    private AdAudiencePushIdentityConfigService adAudiencePushIdentityConfigService;
    @Resource
    private AdAdvertiserAccountService adAdvertiserAccountService;
    @Resource
    private RetrievalCommonService retrievalCommonService;
    @Resource
    private AdAudiencePushService adAudiencePushService;
    @Resource
    private AdTencentServiceImpl adTencentService;

    /**
     * 10 分钟跑一次
     * 同步 {@link AdAudiencePush} 对应的人群包状态
     *
     * @author luck
     */
    @TenantIgnore
    @PostMapping("/syncAudiencePushStatusJobHandler")
    @ClJob(value = "syncAudiencePushStatusJobHandler")
    public void run() {
        log.info("SyncAudiencePushStatusJobHandler_run start");

        Number lastIdOffsetId = null;

        List<AdAudiencePush> adAudiencePushList = new ArrayList<>();
        Instant now = Instant.now();
        Instant minusOneMonth = ZonedDateTime.ofInstant(now, ZoneId.systemDefault()).minusMonths(1).toInstant();
        while (true) {
            try {
                adAudiencePushList = adAudiencePushService.getBaseMapper().nativeListSyncAudiencePushStatusJobHandlerData(minusOneMonth, lastIdOffsetId, 20);
            } catch (Exception e) {
                log.error("SyncAudiencePushStatusJobHandler_run query time: {}, lastIdOffsetId: {}, exception: ", minusOneMonth, lastIdOffsetId, e);
            }
            if (CollectionUtils.isEmpty(adAudiencePushList)) {
                log.warn("SyncAudiencePushStatusJobHandler_run break");
                break;
            }

            log.info("SyncAudiencePushStatusJobHandler_run while process, lastIdOffsetId: {}, adAudiencePushList: {}", lastIdOffsetId, JacksonUtils.toJSONString(adAudiencePushList));
            lastIdOffsetId = adAudiencePushList.stream().mapToLong(AdAudiencePush::getId).max().getAsLong();

            Map<Long, List<AdAudiencePush>> tenantIdGroup = adAudiencePushList.stream().collect(Collectors.groupingBy(AdAudiencePush::getTenantId));

            for (Map.Entry<Long, List<AdAudiencePush>> tenantEntry : tenantIdGroup.entrySet()) {
                Long tenantId = tenantEntry.getKey();

                // 跨租户查了出来，但是要单独租户处理
                try (TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(tenantId)) {
                    List<AdAudiencePush> audiencePushList = tenantEntry.getValue();

                    Map<Long, List<AdAudiencePushIdentityConfig>> parentAllAdAudiencePushIdentityConfigGroup = getAllAdAudiencePushIdentityConfigGroup(audiencePushList);


                    List<Long> advertiserAccountIdList = audiencePushList.stream().map(AdAudiencePush::getAdvertiserAccountId).collect(Collectors.toList());
                    Map<Long, AdAdvertiserAccount> adAdvertiserAccountMap = adAdvertiserAccountService.batchGetMap(advertiserAccountIdList);

                    for (AdAudiencePush audiencePush : audiencePushList) {
                        run(audiencePush, parentAllAdAudiencePushIdentityConfigGroup, adAdvertiserAccountMap);
                    }
                }
            }
        }

        log.info("SyncAudiencePushStatusJobHandler_run end");

    }

    public Map<Long, List<AdAudiencePushIdentityConfig>> getAllAdAudiencePushIdentityConfigGroup(List<AdAudiencePush> audiencePushList) {
        Map<Long, List<AdAudiencePushIdentityConfig>> resultGroup = new HashMap<>();

        Map<Boolean, List<AdAudiencePush>> group = audiencePushList.stream().collect(Collectors.groupingBy(i -> Objects.isNull(i.getParentId())));

        for (Map.Entry<Boolean, List<AdAudiencePush>> groupEntry : group.entrySet()) {
            // 顶层数据和子数据分别处理
            if (groupEntry.getKey()) {
                // 如果是顶层数据，要处理子数据
                // 顶层数据
                List<AdAudiencePush> parentAudiencePushList = groupEntry.getValue();

                List<Long> parentAudiencePushIdList = CollectionUtils.isEmpty(parentAudiencePushList) ? new ArrayList<>() : parentAudiencePushList.stream().map(AdAudiencePush::getId).collect(Collectors.toList());

                // 子数据
                List<AdAudiencePush> childAdAudiencePushList = CollectionUtils.isEmpty(parentAudiencePushIdList) ? new ArrayList<>() : adAudiencePushService.lambdaQuery().in(AdAudiencePush::getParentId, parentAudiencePushIdList).list();
                Map<Long, List<AdAudiencePush>> parentWithChildGroup = childAdAudiencePushList.stream().collect(Collectors.groupingBy(AdAudiencePush::getParentId));

                List<Long> childAdAudiencePushIdList = childAdAudiencePushList.stream().map(AdAudiencePush::getId).collect(Collectors.toList());

                Map<Long, List<AdAudiencePushIdentityConfig>> childAdAudiencePushIdentityConfigGroup = adAudiencePushIdentityConfigService.getAudiencePushIdWithIdentityConfigGroup(childAdAudiencePushIdList, AdAudiencePushIdentityConfig.VersionTypeEnum.CURRENT);

                Map<Long, List<AdAudiencePushIdentityConfig>> parentAdAudiencePushIdentityConfigGroup = adAudiencePushIdentityConfigService.getAudiencePushIdWithIdentityConfigGroup(parentAudiencePushIdList, AdAudiencePushIdentityConfig.VersionTypeEnum.CURRENT);

                Map<Long, List<AdAudiencePushIdentityConfig>> parentAllAdAudiencePushIdentityConfigGroup = new HashMap<>(parentAdAudiencePushIdentityConfigGroup);

                for (Map.Entry<Long, List<AdAudiencePushIdentityConfig>> parentAllEntry : parentAllAdAudiencePushIdentityConfigGroup.entrySet()) {
                    Optional.ofNullable(parentWithChildGroup.get(parentAllEntry.getKey()))
                            .ifPresent(tmpChildAdAudiencePushList -> {
                                for (AdAudiencePush childAdAudiencePush : tmpChildAdAudiencePushList) {
                                    Optional.ofNullable(childAdAudiencePushIdentityConfigGroup.get(childAdAudiencePush.getId())).ifPresent(childEntry -> {
                                        parentAllEntry.getValue().addAll(childEntry);
                                    });
                                }
                            });
                }
                resultGroup.putAll(parentAllAdAudiencePushIdentityConfigGroup);
            } else {
                // 只是单纯的子数据
                List<AdAudiencePush> childAdAudiencePushList = groupEntry.getValue();
                List<Long> childAdAudiencePushIdList = CollectionUtils.isEmpty(childAdAudiencePushList) ? new ArrayList<>() : childAdAudiencePushList.stream().map(AdAudiencePush::getId).collect(Collectors.toList());
                resultGroup.putAll(adAudiencePushIdentityConfigService.getAudiencePushIdWithIdentityConfigGroup(childAdAudiencePushIdList, AdAudiencePushIdentityConfig.VersionTypeEnum.CURRENT));
            }

        }
        return resultGroup;
    }

    public void run(AdAudiencePush audiencePush, Map<Long, List<AdAudiencePushIdentityConfig>> parentAllAdAudiencePushIdentityConfigGroup, Map<Long, AdAdvertiserAccount> adAdvertiserAccountMap) {
        String updateAudiencePushPushStatus = null;
        String updateAudiencePushAudienceStatus = null;
        String updateAudiencePushOuterAudienceStatus = null;
        String updateAudiencePushPushReason = null;
        Integer updateAudiencePushSegmentSize = null;

        try {
            log.info("SyncAudiencePushStatusJobHandler_run processing audiencePush: {}", JacksonUtils.toJSONString(audiencePush));
            List<AdAudiencePushIdentityConfig> adAudiencePushIdentityConfigList = parentAllAdAudiencePushIdentityConfigGroup.get(audiencePush.getId());

            if (CollectionUtils.isEmpty(adAudiencePushIdentityConfigList)) {
                String msg = StrUtil.format("SyncAudiencePushStatusJobHandler_run processing adAudiencePushIdentityConfigList adAudiencePushId: {} is empty. ", audiencePush.getId());
                log.warn(msg);
                updateAudiencePushPushReason = msg;
                updateAudiencePushPushStatus = AdAudiencePush.PushStatus.FAILURE.getCode();
                return;
            }

            Map<String, Long> pushStatusCount = adAudiencePushIdentityConfigList.stream().collect(Collectors.groupingBy(AdAudiencePushIdentityConfig::getPushStatus, Collectors.counting()));
            log.info("SyncAudiencePushStatusJobHandler_run adAudiencePushIdentityConfigList pushStatusCount: {}, audiencePushId: {}", pushStatusCount, audiencePush.getId());

            if (pushStatusCount.containsKey(AdAudiencePush.PushStatus.FAILURE.getCode())) {
                updateAudiencePushPushStatus = AdAudiencePush.PushStatus.FAILURE.getCode();
            } else if (adAudiencePushIdentityConfigList.size() == Optional.ofNullable(pushStatusCount.get(AdAudiencePush.PushStatus.SUCCESS.getCode())).orElse(0L)) {
                updateAudiencePushPushStatus = AdAudiencePush.PushStatus.SUCCESS.getCode();
            }

            AdAdvertiserAccount adAdvertiserAccount = adAdvertiserAccountMap.get(audiencePush.getAdvertiserAccountId());
            if (Objects.isNull(adAdvertiserAccount)) {
                String msg = StrUtil.format("SyncAudiencePushStatusJobHandler_run processing adAdvertiserAccount adAudiencePushId: {} is null. ", audiencePush.getId());
                log.warn(msg);
                updateAudiencePushPushReason = msg;
                updateAudiencePushPushStatus = AdAudiencePush.PushStatus.FAILURE.getCode();
                return;
            }
            if (Objects.isNull(audiencePush.getSegmentSize())) {
                try {
                    updateAudiencePushSegmentSize = DataSourceLookupHelper.withLookupKey(
                            null,
                            () -> retrievalCommonService.querySegmentCountBySegment(audiencePush.getSegmentProfile(), Collections.singletonList(String.valueOf(audiencePush.getSegmentId())))
                    );
                } catch (Exception e) {
                    log.error("SyncAudiencePushStatusJobHandler_run querySegmentCountBySegment error, audiencePushId: {}", audiencePush.getId(), e);
                }
            }

            AdAudiencePush adAudiencePushAudienceStatus = adTencentService.getAdAudiencePushAudienceStatus(adAdvertiserAccount, audiencePush);
            if (Objects.nonNull(adAudiencePushAudienceStatus)) {
                updateAudiencePushAudienceStatus = adAudiencePushAudienceStatus.getAudienceStatus();
                updateAudiencePushOuterAudienceStatus = adAudiencePushAudienceStatus.getOuterAudienceStatus();
            } else {
                log.warn("SyncAudiencePushStatusJobHandler_run adAudiencePushAudienceStatus is null, maybe deleted. audiencePushId: {}", audiencePush.getId());
                updateAudiencePushAudienceStatus = AdAudiencePush.AudienceStatus.DELETED.getCode();
            }

        } catch (Exception e) {
            log.error("SyncAudiencePushStatusJobHandler_run processing adAudiencePushIdentityConfig: {}, e: ", JacksonUtils.toJSONString(audiencePush), e);
        } finally {
            adAudiencePushService.syncAudiencePushStatusJobHandlerFinallyUpdate(
                    audiencePush,
                    updateAudiencePushPushReason,
                    updateAudiencePushPushStatus,
                    updateAudiencePushAudienceStatus,
                    updateAudiencePushOuterAudienceStatus,
                    updateAudiencePushSegmentSize);
        }
    }

}