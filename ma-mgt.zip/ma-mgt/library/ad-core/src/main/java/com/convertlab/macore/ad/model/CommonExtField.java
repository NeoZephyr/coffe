package com.convertlab.macore.ad.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.convertlab.macore.ad.common.enums.ExtFieldTypeEnum;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Objects;
import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties({"tenantId", "id"})
public class CommonExtField implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 字段 id
     */
    protected Long id;
    /**
     * 租户 ID
     *
     * @see Long
     */
    protected Long tenantId;
    /**
     * 关联表外键
     */
    @TableField(value = "`fk`")
    protected Object fk;
    /**
     * 字段名称
     */
    protected String name;
    /**
     * 字段类型
     * {@link ExtFieldTypeEnum}
     *
     * @mock str
     */
    protected String type;
    /**
     * 值：long 类型
     *
     * @mock 5734
     */
    protected Long longValue;
    /**
     * 值：int 类型
     */
    protected Integer intValue;
    /**
     * 值：varchar(128) 类型
     */
    protected String strValue;
    /**
     * 值：text 类型
     */
    protected String textValue;
    /**
     * 值：datetime 类型
     */
    protected Instant datetimeValue;
    /**
     * 该字段是否是唯一，默认 true
     *
     * @see Boolean
     */
    protected Boolean uniqueEnable = true;
    /**
     * 是否加密：0 false，1 true
     * <p>
     * 之后接入加解密：加密后都放到 text_value 字段，解密后，放到对应类型的字段中
     */
    protected Boolean encrypted;

    /**
     * 逻辑值，哪个有值取哪个
     *
     * @see Object
     */
    @TableField(exist = false)
    protected Object value;

    public void setLongValue(Long longValue) {
        this.longValue = longValue;
        this.type = ExtFieldTypeEnum.LONG.getCode();
    }

    public void setIntValue(Integer intValue) {
        this.intValue = intValue;
        this.type = ExtFieldTypeEnum.INT.getCode();
    }

    public void setStrValue(String strValue) {
        this.strValue = strValue;
        this.type = ExtFieldTypeEnum.STR.getCode();
    }

    public void setTextValue(String textValue) {
        this.textValue = textValue;
        this.type = ExtFieldTypeEnum.TEXT.getCode();
    }

    public void setDatetimeValue(Instant datetimeValue) {
        this.datetimeValue = datetimeValue;
        this.type = ExtFieldTypeEnum.DATETIME.getCode();
    }

    /**
     * 设置值
     *
     * @param type  类型 {@link ExtFieldTypeEnum}
     * @param value 值
     * @author luck
     * @apiNote 设置值
     * @since 2023-04-25 14:37:31
     */
    public void setValue(String type, Object value) {
        if (Objects.equals(type, ExtFieldTypeEnum.LONG.getCode())) {
            this.longValue = (Long) value;
        } else if (Objects.equals(type, ExtFieldTypeEnum.INT.getCode())) {
            this.intValue = (Integer) value;
        } else if (Objects.equals(type, ExtFieldTypeEnum.STR.getCode())) {
            this.strValue = (String) value;
        } else if (Objects.equals(type, ExtFieldTypeEnum.TEXT.getCode())) {
            this.textValue = (String) value;
        } else if (Objects.equals(type, ExtFieldTypeEnum.DATETIME.getCode())) {
            this.datetimeValue = (Instant) value;
        }
    }

    public Object getValue() {
        if (Objects.equals(this.type, ExtFieldTypeEnum.LONG.getCode())) {
            value = this.longValue;
            return this.longValue;
        } else if (Objects.equals(this.type, ExtFieldTypeEnum.INT.getCode())) {
            value = this.intValue;
            return this.intValue;
        } else if (Objects.equals(this.type, ExtFieldTypeEnum.STR.getCode())) {
            value = this.strValue;
            return this.strValue;
        } else if (Objects.equals(this.type, ExtFieldTypeEnum.TEXT.getCode())) {
            value = this.textValue;
            return this.textValue;
        } else if (Objects.equals(this.type, ExtFieldTypeEnum.DATETIME.getCode())) {
            value = this.datetimeValue;
            return this.datetimeValue;
        } else if (Objects.nonNull(this.longValue)) {
            value = this.longValue;
            return this.longValue;
        } else if (Objects.nonNull(this.intValue)) {
            value = this.intValue;
            return this.intValue;
        } else if (Objects.nonNull(this.strValue)) {
            value = this.strValue;
            return this.strValue;
        } else if (Objects.nonNull(this.textValue)) {
            value = this.textValue;
            return this.textValue;
        } else if (Objects.nonNull(this.datetimeValue)) {
            value = this.datetimeValue;
            return this.datetimeValue;
        }
        return null;
    }

    public CommonExtField(Object fk,
                          String name,
                          String type,
                          Long longValue,
                          Integer intValue,
                          String strValue,
                          String textValue,
                          Instant datetimeValue,
                          Boolean uniqueEnable,
                          Boolean encrypted) {
        this.fk = fk;
        this.name = name;
        this.type = type;
        this.longValue = longValue;
        this.intValue = intValue;
        this.strValue = strValue;
        this.textValue = textValue;
        this.datetimeValue = datetimeValue;
        this.uniqueEnable = uniqueEnable;
        this.encrypted = encrypted;
    }

    public static CommonExtField genLong(Long fk, String name, Long longValue) {
        return new CommonExtField(fk, name, ExtFieldTypeEnum.LONG.getCode(), longValue, null, null, null, null, true, false);
    }

    public static CommonExtField genLong(Long fk, String name, Long longValue, Boolean uniqueEnable, Boolean encrypted) {
        return new CommonExtField(fk, name, ExtFieldTypeEnum.LONG.getCode(), longValue, null, null, null, null, uniqueEnable, encrypted);
    }

    public static CommonExtField genInt(Long fk, String name, Integer intValue) {
        return new CommonExtField(fk, name, ExtFieldTypeEnum.INT.getCode(), null, intValue, null, null, null, true, false);
    }

    public static CommonExtField genInt(Long fk, String name, Integer intValue, Boolean uniqueEnable, Boolean encrypted) {
        return new CommonExtField(fk, name, ExtFieldTypeEnum.INT.getCode(), null, intValue, null, null, null, uniqueEnable, encrypted);
    }

    public static CommonExtField genStr(Long fk, String name, String strValue) {
        return new CommonExtField(fk, name, ExtFieldTypeEnum.STR.getCode(), null, null, strValue, null, null, true, false);
    }

    public static CommonExtField genStr(Long fk, String name, String strValue, Boolean uniqueEnable, Boolean encrypted) {
        return new CommonExtField(fk, name, ExtFieldTypeEnum.STR.getCode(), null, null, strValue, null, null, uniqueEnable, encrypted);
    }

    public static CommonExtField genText(Long fk, String name, String textValue) {
        return new CommonExtField(fk, name, ExtFieldTypeEnum.TEXT.getCode(), null, null, null, textValue, null, true, false);
    }

    public static CommonExtField genText(Long fk, String name, String textValue, Boolean uniqueEnable, Boolean encrypted) {
        return new CommonExtField(fk, name, ExtFieldTypeEnum.TEXT.getCode(), null, null, null, textValue, null, uniqueEnable, encrypted);
    }

    public static CommonExtField genDatetime(Long fk, String name, Instant datetimeValue) {
        return new CommonExtField(fk, name, ExtFieldTypeEnum.DATETIME.getCode(), null, null, null, null, datetimeValue, true, false);
    }

    public static CommonExtField genDatetime(Long fk, String name, Instant datetimeValue, Boolean uniqueEnable, Boolean encrypted) {
        return new CommonExtField(fk, name, ExtFieldTypeEnum.DATETIME.getCode(), null, null, null, null, datetimeValue, uniqueEnable, encrypted);
    }

}