package com.convertlab.macore.ad.job;

import cn.hutool.core.util.StrUtil;
import cn.hutool.core.util.ZipUtil;
import com.convertlab.data.job.core.handler.ClJobHandlerMark;
import com.convertlab.data.job.core.handler.annotation.ClJob;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.multitenancy.annotation.TenantIgnore;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.macore.ad.common.utils.JacksonUtils;
import com.convertlab.macore.ad.kafka.consume.AdMktAudiencePushExtractCallbackConsume;
import com.convertlab.macore.ad.mapping.AdAudiencePushIdentityConfigMapping;
import com.convertlab.macore.ad.model.dto.AdAudiencePushIdentityConfigFileUrlPairDTO;
import com.convertlab.macore.ad.model.entity.AdAdvertiserAccount;
import com.convertlab.macore.ad.model.entity.AdAudiencePush;
import com.convertlab.macore.ad.model.entity.AdAudiencePushIdentityConfig;
import com.convertlab.macore.ad.service.biz.BizFileService;
import com.convertlab.macore.ad.service.dao.AdAdvertiserAccountService;
import com.convertlab.macore.ad.service.dao.AdAudiencePushIdentityConfigService;
import com.convertlab.macore.ad.service.dao.AdAudiencePushService;
import com.convertlab.macore.ad.service.muilt.impl.AdTencentServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;


/**
 * @author fucheng.ning
 * @version v1
 */
@Slf4j
@Component
@RestController
@DataSourceLookup("main")
@RequestMapping("/ad_mkt/job")
public class OperatePushJobHandler implements ClJobHandlerMark {

    @Resource
    private AdAudiencePushIdentityConfigService adAudiencePushIdentityConfigService;
    @Resource
    private AdAudiencePushIdentityConfigMapping adAudiencePushIdentityConfigMapping;
    @Resource
    private AdAdvertiserAccountService adAdvertiserAccountService;
    @Resource
    private AdAudiencePushService adAudiencePushService;
    @Resource
    private AdTencentServiceImpl adTencentService;
    @Resource
    private BizFileService bizFileService;

    /**
     * 10s 跑一次
     * 将对应 {@link AdAudiencePushIdentityConfig} 需要的文件上传到平台
     *
     * next step {@link SyncAudiencePushStatusJobHandler#run()} or {@link SyncPushFileStatusJobHandler#run()}
     *
     * @author luck
     */
    @TenantIgnore
    @PostMapping("/operatePushJobHandler")
    @ClJob(value = "operatePushJobHandler")
    public void run() {
        log.info("OperatePushJobHandler_run start");

        Number lastIdOffsetId = null;

        List<AdAudiencePushIdentityConfig> adAudiencePushIdentityConfigList = new ArrayList<>();

        while (true) {
            try {
                adAudiencePushIdentityConfigList = adAudiencePushIdentityConfigService.getBaseMapper().nativeListOperatePushJobHandlerData(lastIdOffsetId,20);
//                adAudiencePushIdentityConfigList = Collections.singletonList(adAudiencePushIdentityConfigService.getById(203L));
            } catch (Exception e) {
                log.error("OperatePushJobHandler_run query lastIdOffsetId: {}, exception: ", lastIdOffsetId, e);
            }
            if (CollectionUtils.isEmpty(adAudiencePushIdentityConfigList)) {
                log.warn("OperatePushJobHandler_run break");
                break;
            }

            log.info("OperatePushJobHandler_run while process, lastIdOffsetId: {}, adAudiencePushIdentityConfigList: {}", lastIdOffsetId, JacksonUtils.toJSONString(adAudiencePushIdentityConfigList));
            lastIdOffsetId = adAudiencePushIdentityConfigList.stream().mapToLong(AdAudiencePushIdentityConfig::getId).max().getAsLong();

            Map<Long, List<AdAudiencePushIdentityConfig>> tenantIdGroup = adAudiencePushIdentityConfigList.stream().collect(Collectors.groupingBy(AdAudiencePushIdentityConfig::getTenantId));

            for (Map.Entry<Long, List<AdAudiencePushIdentityConfig>> tenantEntry : tenantIdGroup.entrySet()) {
                Long tenantId = tenantEntry.getKey();

                // 跨租户查了出来，但是要单独租户处理
                try (TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(tenantId)) {
                    List<AdAudiencePushIdentityConfig> audiencePushIdentityConfigList = tenantEntry.getValue();

                    List<Long> audiencePushIdList = audiencePushIdentityConfigList.stream().map(AdAudiencePushIdentityConfig::getAudiencePushId).collect(Collectors.toList());
                    Map<Long, AdAudiencePush> adAudiencePushMap = CollectionUtils.isEmpty(audiencePushIdList) ? new HashMap<>() : adAudiencePushService.listByIds(audiencePushIdList).stream().collect(HashMap::new, (map, i) -> map.put(i.getId(), i), HashMap::putAll);

                    List<Long> advertiserAccountIdList = adAudiencePushMap.values().stream().map(AdAudiencePush::getAdvertiserAccountId).collect(Collectors.toList());
                    Map<Long, AdAdvertiserAccount> adAdvertiserAccountMap = CollectionUtils.isEmpty(advertiserAccountIdList) ? new HashMap<>() : adAdvertiserAccountService.listByIds(advertiserAccountIdList).stream().collect(HashMap::new, (map, i) -> map.put(i.getId(), i), HashMap::putAll);

                    for (AdAudiencePushIdentityConfig audiencePushIdentityConfig : audiencePushIdentityConfigList) {
                        Map<String, AdAudiencePushIdentityConfig> versionTypeMap = adAudiencePushIdentityConfigService.lambdaQuery()
                                .eq(AdAudiencePushIdentityConfig::getAudiencePushId, audiencePushIdentityConfig.getAudiencePushId())
                                .eq(AdAudiencePushIdentityConfig::getIdType, audiencePushIdentityConfig.getIdType())
                                .eq(Objects.nonNull(audiencePushIdentityConfig.getAdPlatformInstanceAppId()), AdAudiencePushIdentityConfig::getAdPlatformInstanceAppId, audiencePushIdentityConfig.getAdPlatformInstanceAppId())
                                .list()
                                .stream().collect(HashMap::new, (map, i) -> map.put(i.getVersionType(), i), HashMap::putAll);

                        AdAudiencePushIdentityConfig currentAdAudiencePushIdentityConfig = versionTypeMap.get(AdAudiencePushIdentityConfig.VersionTypeEnum.CURRENT.getCode());
//                        AdAudiencePushIdentityConfig currentAppendAdAudiencePushIdentityConfig = versionTypeMap.get(AdAudiencePushIdentityConfig.VersionTypeEnum.CURRENT_APPEND.getCode());
//                        AdAudiencePushIdentityConfig currentReduceAdAudiencePushIdentityConfig = versionTypeMap.get(AdAudiencePushIdentityConfig.VersionTypeEnum.CURRENT_REDUCE.getCode());
                        AdAudiencePushIdentityConfig lastAdAudiencePushIdentityConfig = versionTypeMap.get(AdAudiencePushIdentityConfig.VersionTypeEnum.LAST.getCode());
//                        AdAudiencePushIdentityConfig lastAppendAdAudiencePushIdentityConfig = versionTypeMap.get(AdAudiencePushIdentityConfig.VersionTypeEnum.LAST_APPEND.getCode());
//                        AdAudiencePushIdentityConfig lastReduceAdAudiencePushIdentityConfig = versionTypeMap.get(AdAudiencePushIdentityConfig.VersionTypeEnum.LAST_REDUCE.getCode());

                        List<AdAudiencePushIdentityConfig> childAdAudiencePushIdentityConfigList = new ArrayList<>();

                        Path file = null;
                        File zip = null;
                        /** 和更新有关 */
                        Path lastFile = null;
                        Path currentFile = null;
                        Path currentDiffAppendFile = null;
                        Path currentDiffReduceFile = null;
                        File currentDiffAppendZip = null;
                        File currentDiffReduceZip = null;

                        String updateAudiencePushIdentityConfigPushStatus = AdAudiencePush.PushStatus.PROCESSING.getCode();
                        String updateAudiencePushIdentityConfigPushReason = "";
                        Long updateAudiencePushIdentityConfigFileSize = 0L;
                        String updateAudiencePushIdentityConfigOuterFileId = null;

                        try {
                            log.info("OperatePushJobHandler_run processing adAudiencePushIdentityConfig: {}", JacksonUtils.toJSONString(audiencePushIdentityConfig));
                            AdAudiencePush adAudiencePush = adAudiencePushMap.get(audiencePushIdentityConfig.getAudiencePushId());

                            if (Objects.isNull(adAudiencePush)) {
                                String msg = StrUtil.format("OperatePushJobHandler_run processing adAudiencePushIdentityConfig adAudiencePushId: {} is not found. ", audiencePushIdentityConfig.getAudiencePushId());
                                updateAudiencePushIdentityConfigPushReason = msg;
                                log.warn(msg);
                                throw new RuntimeException(msg);
                            }

                            boolean isSync = Objects.nonNull(lastAdAudiencePushIdentityConfig);

                            AdAdvertiserAccount advertiserAccount = adAdvertiserAccountMap.get(adAudiencePush.getAdvertiserAccountId());
                            if (Objects.isNull(advertiserAccount)) {
                                String msg = StrUtil.format("OperatePushJobHandler_run processing adAudiencePushIdentityConfig advertiserAccountId: {} is not found. ", adAudiencePush.getAdvertiserAccountId());
                                updateAudiencePushIdentityConfigPushReason = msg;
                                log.warn(msg);
                                throw new RuntimeException(msg);
                            }

                            if (!isSync) {
                                file = bizFileService.downloadWrapBizToPath(audiencePushIdentityConfig.getAdPlatformInstanceAppId(), audiencePushIdentityConfig.getIdType(), audiencePushIdentityConfig.getFileUrl(), "ad_mkt-", ".txt");
                                zip = ZipUtil.zip(file.toFile(), StandardCharsets.UTF_8);
                                updateAudiencePushIdentityConfigFileSize = Files.size(file);
                                if(updateAudiencePushIdentityConfigFileSize == 0L){
                                    String msg = StrUtil.format("OperatePushJobHandler_run processing file is empty, adAudiencePushIdentityConfig: {}", JacksonUtils.toJSONString(audiencePushIdentityConfig));
                                    updateAudiencePushIdentityConfigPushReason = msg;
                                    log.warn(msg);
                                    throw new RuntimeException(msg);
                                }
                                log.info("OperatePushJobHandler_run processing adAudiencePushIdentityConfig file:{}, zip: {}", file.toAbsolutePath(), zip.getAbsolutePath());

                                String customAudienceFileId = adTencentService.genCustomAudienceFileId(adAudiencePush, audiencePushIdentityConfig, advertiserAccount, zip);

                                if (!StringUtils.hasLength(updateAudiencePushIdentityConfigOuterFileId = customAudienceFileId)) {
                                    String msg = StrUtil.format("OperatePushJobHandler_run processing customAudienceFileId is null, adAudiencePushIdentityConfig: {}", JacksonUtils.toJSONString(audiencePushIdentityConfig));
                                    updateAudiencePushIdentityConfigPushReason = msg;
                                    log.warn(msg);
                                    throw new RuntimeException(msg);
                                }
                            } else {
                                // 如果是更新策略跑的，两个文件做对比计算差集
                                lastFile = bizFileService.downloadWrapBizToPath(audiencePushIdentityConfig.getAdPlatformInstanceAppId(), audiencePushIdentityConfig.getIdType(), lastAdAudiencePushIdentityConfig.getFileUrl(), "ad_mkt-", ".last.txt");
                                currentFile = bizFileService.downloadWrapBizToPath(audiencePushIdentityConfig.getAdPlatformInstanceAppId(), audiencePushIdentityConfig.getIdType(), currentAdAudiencePushIdentityConfig.getFileUrl(), "ad_mkt-", ".current.txt");

                                String lastFileName = JacksonUtils.parseObject(lastAdAudiencePushIdentityConfig.getFileTraceInfo(), AdMktAudiencePushExtractCallbackConsume.SparkCallbackDTO.class).getFileName();
                                String currentFileName = JacksonUtils.parseObject(currentAdAudiencePushIdentityConfig.getFileTraceInfo(), AdMktAudiencePushExtractCallbackConsume.SparkCallbackDTO.class).getFileName();

                                AdAudiencePushIdentityConfigFileUrlPairDTO filePair = bizFileService.getDiff(
                                        lastFile.toString(),
                                        currentFile.toString(),
                                        currentFileName + ".current.txt",
                                        lastFileName + ".last.txt");
                                if (Objects.nonNull(filePair.getAppend())) {
                                    currentDiffAppendFile = Paths.get(filePair.getAppend());
                                    currentDiffAppendZip = ZipUtil.zip(currentDiffAppendFile.toFile());
                                    String customAudienceFileId = adTencentService.genCustomAudienceFileId(adAudiencePush, audiencePushIdentityConfig, advertiserAccount, currentDiffAppendZip);
                                    childAdAudiencePushIdentityConfigList.add(adAudiencePushIdentityConfigMapping.genNewChild(
                                            audiencePushIdentityConfig.getParentId(),
                                            AdAudiencePushIdentityConfig.VersionTypeEnum.CURRENT_APPEND.getCode(),
                                            customAudienceFileId,
                                            Files.size(currentDiffAppendFile),
                                            audiencePushIdentityConfig
                                    ));
                                }
                                if (Objects.nonNull(filePair.getReduce())) {
                                    currentDiffReduceFile = Paths.get(filePair.getReduce());
                                    currentDiffReduceZip = ZipUtil.zip(currentDiffReduceFile.toFile());
                                    String customAudienceFileId = adTencentService.genCustomAudienceFileId(adAudiencePush, audiencePushIdentityConfig, advertiserAccount, currentDiffReduceZip);
                                    childAdAudiencePushIdentityConfigList.add(adAudiencePushIdentityConfigMapping.genNewChild(
                                            audiencePushIdentityConfig.getParentId(),
                                            AdAudiencePushIdentityConfig.VersionTypeEnum.CURRENT_REDUCE.getCode(),
                                            customAudienceFileId,
                                            Files.size(currentDiffReduceFile),
                                            audiencePushIdentityConfig
                                    ));
                                }

                            }

                        } catch (Exception e) {
                            log.warn("OperatePushJobHandler_run processing adAudiencePushIdentityConfig: {}, e: ", JacksonUtils.toJSONString(audiencePushIdentityConfig), e);
                            updateAudiencePushIdentityConfigPushStatus = AdAudiencePush.PushStatus.FAILURE.getCode();
                            updateAudiencePushIdentityConfigPushReason = e.getMessage();
                        } finally {
                            if (Objects.nonNull(file)) {
                                try {
                                    Files.deleteIfExists(file);
                                } catch (IOException e) {
                                    log.error("OperatePushJobHandler_run processing adAudiencePushIdentityConfig file delete error: ", e);
                                    throw new RuntimeException(e);
                                }
                            }
                            if (Objects.nonNull(zip)) {
                                try {
                                    zip.delete();
                                } catch (Exception e) {
                                    log.error("OperatePushJobHandler_run processing adAudiencePushIdentityConfig zip delete error: ", e);
                                    throw new RuntimeException(e);
                                }
                            }
                            if (Objects.nonNull(currentDiffAppendFile)) {
                                try {
                                    Files.deleteIfExists(currentDiffAppendFile);
                                } catch (IOException e) {
                                    log.error("OperatePushJobHandler_run processing adAudiencePushIdentityConfig currentDiffAppendFile delete error: ", e);
                                    throw new RuntimeException(e);
                                }
                            }
                            if (Objects.nonNull(currentDiffAppendZip)) {
                                try {
                                    currentDiffAppendZip.delete();
                                } catch (Exception e) {
                                    log.error("OperatePushJobHandler_run processing adAudiencePushIdentityConfig currentDiffAppendZip delete error: ", e);
                                    throw new RuntimeException(e);
                                }
                            }
                            if (Objects.nonNull(currentDiffReduceFile)) {
                                try {
                                    Files.deleteIfExists(currentDiffReduceFile);
                                } catch (IOException e) {
                                    log.error("OperatePushJobHandler_run processing adAudiencePushIdentityConfig currentDiffReduceFile delete error: ", e);
                                    throw new RuntimeException(e);
                                }
                            }
                            if (Objects.nonNull(currentDiffReduceZip)) {
                                try {
                                    currentDiffReduceZip.delete();
                                } catch (Exception e) {
                                    log.error("OperatePushJobHandler_run processing adAudiencePushIdentityConfig currentDiffReduceZip delete error: ", e);
                                    throw new RuntimeException(e);
                                }
                            }

                            AdAudiencePushIdentityConfig updateAudiencePushIdentityConfig = new AdAudiencePushIdentityConfig();
                            updateAudiencePushIdentityConfig.setId(audiencePushIdentityConfig.getId());
                            updateAudiencePushIdentityConfig.setFileSize(updateAudiencePushIdentityConfigFileSize);
                            updateAudiencePushIdentityConfig.setPushStatus(updateAudiencePushIdentityConfigPushStatus);
                            updateAudiencePushIdentityConfig.setPushReason(updateAudiencePushIdentityConfigPushReason);
                            updateAudiencePushIdentityConfig.setOuterFileId(updateAudiencePushIdentityConfigOuterFileId);
                            updateAudiencePushIdentityConfig.setUpdaterId(audiencePushIdentityConfig.getUpdaterId());
                            updateAudiencePushIdentityConfig.setUpdaterName(audiencePushIdentityConfig.getUpdaterName());
                            updateAudiencePushIdentityConfig.setLastUpdated(Instant.now());
                            adAudiencePushIdentityConfigService.updateById(updateAudiencePushIdentityConfig);
                            if (!CollectionUtils.isEmpty(childAdAudiencePushIdentityConfigList)) {
                                adAudiencePushIdentityConfigService.saveBatch(childAdAudiencePushIdentityConfigList);
                            }

                            adAudiencePushService.lambdaUpdate()
                                    .eq(AdAudiencePush::getId, audiencePushIdentityConfig.getAudiencePushId())
                                    .in(AdAudiencePush::getPushStatus, AdAudiencePush.PushStatus.PENDING.getCode(), AdAudiencePush.PushStatus.PROCESSING.getCode())
                                    .set(AdAudiencePush::getPushStatus, updateAudiencePushIdentityConfigPushStatus)
                                    .update();
                        }
                    }
                }
            }
        }

        log.info("OperatePushJobHandler_run end");

    }
}