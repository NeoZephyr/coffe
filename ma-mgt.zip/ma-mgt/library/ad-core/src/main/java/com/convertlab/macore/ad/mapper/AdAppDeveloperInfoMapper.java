package com.convertlab.macore.ad.mapper;

import com.baomidou.mybatisplus.annotation.InterceptorIgnore;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.convertlab.macore.ad.model.dto.AdAppDeveloperInfoDTO;
import com.convertlab.macore.ad.model.entity.AdAppDeveloperInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @author luck
 */
@Mapper
public interface AdAppDeveloperInfoMapper extends BaseMapper<AdAppDeveloperInfo> {

    @InterceptorIgnore(tenantLine = "true")
    Page<AdAppDeveloperInfoDTO> nativePageDeveloperInfo(@Param("page") Page<AdAppDeveloperInfoDTO> page,
                                                        @Param("adPlatformCode") String adPlatformCode);

}
