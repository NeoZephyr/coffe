package com.convertlab.macore.ad.mapper;

import com.baomidou.mybatisplus.annotation.InterceptorIgnore;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.convertlab.macore.ad.model.dto.AdAudiencePushDetailIndexDTO;
import com.convertlab.macore.ad.model.entity.AdAudiencePushIdentityConfig;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.Instant;
import java.util.List;

/**
 * @author luck
 */
@Mapper
public interface AdAudiencePushIdentityConfigMapper extends BaseMapper<AdAudiencePushIdentityConfig> {

    Page<AdAudiencePushDetailIndexDTO> pagePushDetailIndex(@Param("page") Page<AdAudiencePushDetailIndexDTO> page,
                                                           @Param("audiencePushId") Long audiencePushId);

    @InterceptorIgnore(tenantLine = "true")
    List<AdAudiencePushIdentityConfig> nativeListOperatePushJobHandlerData(@Param("lastIdOffsetId") Number lastIdOffsetId,
                                                                           @Param("limit") Number limit);

    @InterceptorIgnore(tenantLine = "true")
    List<AdAudiencePushIdentityConfig> nativeListSyncPushFileStatusJobHandlerData(@Param("time") Instant time,
                                                                                  @Param("lastIdOffsetId") Number lastIdOffsetId,
                                                                                  @Param("limit") Number limit);

}
