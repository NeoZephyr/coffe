package com.convertlab.macore.ad.common;

import com.convertlab.macore.ad.model.CommonExtField;

import java.util.*;
import java.util.stream.Collectors;

public interface IExtFieldListHandle<CommonExtFieldType extends CommonExtField> {

    /**
     * 设置拓展字段
     *
     * @param extFieldList 延伸相关领域集合
     * @author luck
     * @apiNote 设置拓展字段
     * @since 2022-11-01 17:27:07
     */
    void setExtFieldList(List<CommonExtFieldType> extFieldList);

    /**
     * 获取拓展字段
     *
     * @return {@link List }<{@link CommonExtField }>
     * @author luck
     * @apiNote 获取拓展字段
     * @since 2022-11-01 17:27:22
     */
    List<CommonExtFieldType> getExtFieldList();

    /**
     * 【注意！！！】有非唯一的字段，map 可能被去除
     * 获取扩展相关字段映射
     *
     * @return {@link Map }<{@link String }, {@link CommonExtField }>
     * @author luck
     * @apiNote 获取扩展相关字段映射
     * @since 2022-12-12 18:23:35
     */
    default Map<String, CommonExtFieldType> getExtFieldMap() {
        return Optional.ofNullable(getExtFieldList()).orElse(new ArrayList<>())
                .stream()
                .collect(HashMap::new, (map, field) -> map.put(field.getName(), field), HashMap::putAll);
    }

    /**
     * 获取扩展相关字段映射
     *
     * @return {@link Map }<{@link String }, {@link CommonExtField }>
     * @author luck
     * @apiNote 获取扩展相关字段映射
     * @since 2022-12-12 18:23:35
     */
    default Map<String, CommonExtFieldType> getUniqueExtFieldMap() {
        return Optional.ofNullable(getExtFieldList()).orElse(new ArrayList<>())
                .stream()
                .filter(i -> Objects.equals(i.getUniqueEnable(), true) || Objects.isNull(i.getUniqueEnable()))
                .collect(HashMap::new, (map, field) -> map.put(field.getName(), field), HashMap::putAll);
    }

    /**
     * 获取扩展相关字段映射的 group
     *
     * @return {@link Map }<{@link String }, {@link List }<{@link CommonExtFieldType }>>
     * @author luck
     * @apiNote 获取扩展相关字段映射的 group
     * @see Map<String, List<CommonExtFieldType>>
     * @since 2023-12-20 18:24:06
     */
    default Map<String, List<CommonExtFieldType>> getExtFieldGroup() {
        return Optional.ofNullable(getExtFieldList()).orElse(new ArrayList<>())
                .stream()
                .collect(Collectors.groupingBy(CommonExtField::getName));
    }

    /**
     * 只获取非唯一扩展相关字段 group
     *
     * @return {@link Map }<{@link String }, {@link CommonExtField }>
     * @author luck
     * @apiNote 只获取非唯一扩展相关字段 group
     * @since 2022-12-12 18:23:35
     */
    default Map<String, List<CommonExtFieldType>> getNotUniqueExtFieldGroup() {
        return Optional.ofNullable(getExtFieldList()).orElse(new ArrayList<>())
                .stream()
                .filter(i -> Objects.nonNull(i.getUniqueEnable()) && Objects.equals(i.getUniqueEnable(), false))
                .collect(Collectors.groupingBy(CommonExtField::getName));
    }

}