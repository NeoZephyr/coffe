package com.convertlab.macore.ad.mapper;

import com.baomidou.mybatisplus.annotation.InterceptorIgnore;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.macore.ad.model.entity.AdAppAuthInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.Instant;
import java.util.List;

/**
 * @author luck
 */
@Mapper
@DataSourceLookup("main")
public interface AdAppAuthInfoMapper extends BaseMapper<AdAppAuthInfo> {

    AdAppAuthInfo nativeGet(@Param("adPlatformCode") String adPlatformCode,
                            @Param("clientId") String clientId,
                            @Param("appId") String appId);


    @InterceptorIgnore(tenantLine = "true")
    List<AdAppAuthInfo> nativeCursorExpiredAccessToken(@Param("paramAccessTokenExpiresTime") Instant paramAccessTokenExpiresTime,
                                                       @Param("lastIdOffsetId") Number lastIdOffsetId,
                                                       @Param("limit") Number limit);
}
