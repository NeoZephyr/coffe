package com.convertlab.macore.ad.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Component
@PropertySource(value = "classpath:ad_platform.config.yml", factory = YamlPropertiesSourceFactory.class)
@ConfigurationProperties(prefix = "ad-platform")
public class AdPlatformConfig {
    public static final String APP_ID = "appId";
    public static final String REDIRECT_URL = "redirectUrl";
    public static final String STATE = "state";

    private List<PlatformInfo> platformInfoList = new ArrayList<>();
    private Map<String, PlatformInfo> platformInfoMap = new HashMap<>();

    public Map<String, PlatformInfo> getPlatformInfoMap() {
        return this.platformInfoList.stream().collect(HashMap::new, (map, i) -> map.put(i.getCode(), i), HashMap::putAll);
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PlatformInfo implements Serializable {
        private static final long serialVersionUID = 1L;
        private String name;
        private String code;
        private String clientId;
        private String clientSecrete;
        private String authUrl;
        private String redirectUrl;
        private String redirectUIPath = "/ui/application/spa/index.html#/ad_mkt/account";
        private String trackUrl;
        private Boolean auth;
    }
}