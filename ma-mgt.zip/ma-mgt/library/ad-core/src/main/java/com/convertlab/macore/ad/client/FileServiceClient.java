package com.convertlab.macore.ad.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.net.URI;
import java.util.Map;

@FeignClient(name = "FileServiceClient", url = "${fileService.serverUrl}", decode404 = true)
public interface FileServiceClient {

    /**
     * 下载指定链接的文件
     *
     * @param uri uri
     * @return {@link Map }<{@link String }, {@link Object }>
     * @author luck
     * @apiNote 下载指定链接的文件
     * @see Map<String, Object>
     * @see Map<String, Object>
     * @since 2024-08-15 11:59:52
     */
    @GetMapping(headers = {"Accept-Charset=UTF-8"})
    feign.Response download(URI uri);

    @GetMapping(value = "/file/download2/{attachId}", headers = {"Accept-Charset=UTF-8"})
    feign.Response downloadByAttachId(@PathVariable("attachId") Number attachId, @RequestParam("x_tenant_id") String tenantId);

}