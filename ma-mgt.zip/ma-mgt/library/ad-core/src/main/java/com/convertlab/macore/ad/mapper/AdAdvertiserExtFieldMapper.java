package com.convertlab.macore.ad.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.ad.model.entity.AdAdvertiserAccountExtField;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author luck
 */
@Mapper
public interface AdAdvertiserExtFieldMapper extends BaseMapper<AdAdvertiserAccountExtField> {

}
