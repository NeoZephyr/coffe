package com.convertlab.macore.ad.client;

import com.convertlab.macore.ad.model.dto.ExportTaskDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

@FeignClient(
        name = "EventJobClient",
        url = "${eventJobServer.serverUrl}",
        decode404 = true
)
public interface EventJobClient {

    /**
     * 提交 spark job
     *
     * @param exportTask 任务数据
     * @return {@link Map }<{@link String }, {@link Object }>
     * @author luck
     * @apiNote 提交 spark job
     * @see Map<String, Object>
     * @see Map<String, Object>
     */
    @PostMapping("/dataExportTask")
    Map<String, Object> dataExportTask(@RequestBody ExportTaskDTO exportTask);

}