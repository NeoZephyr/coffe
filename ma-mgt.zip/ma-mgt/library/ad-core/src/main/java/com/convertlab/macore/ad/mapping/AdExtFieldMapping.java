package com.convertlab.macore.ad.mapping;

import com.convertlab.macore.ad.model.CommonExtField;
import com.convertlab.macore.ad.model.entity.AdAdvertiserAccountExtField;
import com.convertlab.macore.ad.model.entity.AdAppAuthInfoExtField;
import com.convertlab.macore.ad.model.entity.AdAudiencePushExtField;
import org.mapstruct.CollectionMappingStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(componentModel = "spring",
        collectionMappingStrategy = CollectionMappingStrategy.ADDER_PREFERRED,
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface AdExtFieldMapping {

    /**
     * {@link AdAdvertiserAccountExtField}
     * @param commonExtField {@link CommonExtField}
     */
    AdAdvertiserAccountExtField getAdAdvertiserExtField(CommonExtField commonExtField);
    List<AdAdvertiserAccountExtField> getAdAdvertiserExtFieldList(List<CommonExtField> commonExtFieldList);
    CommonExtField getByAdAdvertiserExtField(AdAdvertiserAccountExtField adAdvertiserExtField);
    List<CommonExtField> getByAdAdvertiserExtFieldList(List<AdAdvertiserAccountExtField> adAdvertiserExtFieldList);

    /**
     * {@link AdAppAuthInfoExtField}
     * @param commonExtField {@link CommonExtField}
     */
    AdAppAuthInfoExtField getAdAppAuthInfoExtField(CommonExtField commonExtField);
    List<AdAppAuthInfoExtField> getAdAppAuthInfoExtFieldList(List<CommonExtField> commonExtFieldList);
    CommonExtField getByAdAppAuthInfoExtField(AdAppAuthInfoExtField adAppAuthInfoExtField);
    List<CommonExtField> getByAdAppAuthInfoExtFieldList(List<AdAppAuthInfoExtField> adAppAuthInfoExtFieldList);

    /**
     * {@link AdAudiencePushExtField}
     * @param commonExtField {@link CommonExtField}
     */
    AdAudiencePushExtField getAdAudiencePushExtField(CommonExtField commonExtField);
    List<AdAudiencePushExtField> getAdAudiencePushExtFieldList(List<CommonExtField> commonExtFieldList);
    CommonExtField getByAdAudiencePushExtField(AdAudiencePushExtField adAudiencePushExtField);
    List<CommonExtField> getByAdAudiencePushExtFieldList(List<AdAudiencePushExtField> adAudiencePushExtFieldList);

}
