package com.convertlab.macore.ad.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.ad.model.entity.WechatAppFans;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author luck
 */
@Mapper
public interface WechatAppFansMapper extends BaseMapper<WechatAppFans> {

}
