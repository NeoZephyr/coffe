package com.convertlab.macore.ad.mapper;

import com.baomidou.mybatisplus.annotation.InterceptorIgnore;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.macore.ad.model.entity.AdAudiencePush;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.Instant;
import java.util.List;

/**
 * @author luck
 */
@Mapper
@DataSourceLookup("main")
public interface AdAudiencePushMapper extends BaseMapper<AdAudiencePush> {

    @InterceptorIgnore(tenantLine = "true")
    List<AdAudiencePush> nativeListSyncAudiencePushStatusJobHandlerData(@Param("time") Instant time,
                                                                        @Param("lastIdOffsetId") Number lastIdOffsetId,
                                                                        @Param("limit") Number limit);
}
