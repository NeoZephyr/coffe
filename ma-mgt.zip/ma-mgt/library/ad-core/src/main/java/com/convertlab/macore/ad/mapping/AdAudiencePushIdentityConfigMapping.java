package com.convertlab.macore.ad.mapping;

import com.convertlab.macore.ad.model.entity.AdAudiencePushIdentityConfig;
import org.mapstruct.*;

/**
 * @author luck
 * @since 2023/4/20 11:18
 */
@Mapper(componentModel = "spring",
        collectionMappingStrategy = CollectionMappingStrategy.ADDER_PREFERRED,
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface AdAudiencePushIdentityConfigMapping {

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "pushCount", expression = "java(0)")
    @Mapping(target = "pushSuccessCount", expression = "java(0)")
    @Mapping(target = "fileUrl", ignore = true)
    @Mapping(target = "fileTraceInfo", ignore = true)
    @Mapping(target = "fileSize", source = "fileSize")
    @Mapping(target = "outerFileId", source = "outerFileId")
    @Mapping(target = "pushStatus", ignore = true)
    @Mapping(target = "pushReason", ignore = true)
    @Mapping(target = "outerPushStatus", ignore = true)
    @Mapping(target = "parentId", source = "parentId")
    @Mapping(target = "versionType", source = "versionType")
    AdAudiencePushIdentityConfig genNewChild(Long parentId, String versionType, String outerFileId, long fileSize, AdAudiencePushIdentityConfig adAudiencePushIdentityConfig);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "pushCount", expression = "java(0)")
    @Mapping(target = "pushSuccessCount", expression = "java(0)")
    @Mapping(target = "fileUrl", source = "fileUrl")
    @Mapping(target = "fileTraceInfo", source = "fileTraceInfo")
    @Mapping(target = "fileSize", expression = "java(0L)")
    @Mapping(target = "outerFileId", ignore = true)
    @Mapping(target = "pushStatus", ignore = true)
    @Mapping(target = "pushReason", ignore = true)
    @Mapping(target = "outerPushStatus", ignore = true)
    @Mapping(target = "parentId", ignore = true)
    @Mapping(target = "versionType", expression = "java(AdAudiencePushIdentityConfig.VersionTypeEnum.CURRENT.getCode())")
    @Mapping(target = "version", ignore = true)
    @Mapping(target = "creatorId", source = "existAdAudiencePushIdentityConfig.creatorId")
    @Mapping(target = "creatorName", source = "existAdAudiencePushIdentityConfig.creatorName")
    @Mapping(target = "dateCreated", ignore = true)
    @Mapping(target = "updaterId", source = "existAdAudiencePushIdentityConfig.updaterId")
    @Mapping(target = "updaterName", source = "existAdAudiencePushIdentityConfig.updaterName")
    @Mapping(target = "lastUpdated", ignore = true)
    AdAudiencePushIdentityConfig newCurrent(AdAudiencePushIdentityConfig existAdAudiencePushIdentityConfig,
                                            String fileUrl,
                                            String fileTraceInfo);


}
