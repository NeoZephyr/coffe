package com.convertlab.macore.ad.mapping;

import com.convertlab.macore.ad.config.AdPlatformConfig;
import com.convertlab.macore.ad.model.dto.AdPlatformRuntimeConfigDTO;
import org.mapstruct.*;

import java.util.stream.Collectors;

/**
 * @author luck
 * @since 2023/4/20 11:18
 */
@Mapper(componentModel = "spring",
        collectionMappingStrategy = CollectionMappingStrategy.ADDER_PREFERRED,
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        unmappedTargetPolicy = ReportingPolicy.IGNORE,
        imports = {
                Collectors.class
        }
)
public interface AdConfigMapping {

    @Mapping(target = "platformRuntimeInfoList", source = "platformInfoList")
    @Mapping(target = "platformRuntimeInfoMap", ignore = true)
    AdPlatformRuntimeConfigDTO platformConfigToDTO(AdPlatformConfig adPlatformConfig);


    AdPlatformConfig.PlatformInfo copy(AdPlatformConfig.PlatformInfo platformInfo);
}
