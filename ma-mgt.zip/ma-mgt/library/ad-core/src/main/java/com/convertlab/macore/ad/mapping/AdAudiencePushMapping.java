package com.convertlab.macore.ad.mapping;

import com.convertlab.macore.ad.model.dto.AdAudiencePushDTO;
import com.convertlab.macore.ad.model.dto.AdAudiencePushIndexDTO;
import com.convertlab.macore.ad.model.dto.AdAudiencePushWithSegmentSyncConfigDTO;
import com.convertlab.macore.ad.model.entity.AdAudiencePush;
import com.convertlab.macore.ad.model.entity.AdAudiencePushExtField;
import com.convertlab.macore.ad.model.entity.AdAudiencePushIdentityConfig;
import com.convertlab.macore.ad.model.entity.AdAudiencePushSegmentSyncConfig;
import org.mapstruct.CollectionMappingStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.*;

import java.util.List;

/**
 * @author luck
 * @since 2023/4/20 11:18
 */
@Mapper(componentModel = "spring",
        collectionMappingStrategy = CollectionMappingStrategy.ADDER_PREFERRED,
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        unmappedTargetPolicy = ReportingPolicy.WARN
)
public interface AdAudiencePushMapping {

    AdAudiencePush dtoToEntity(AdAudiencePushDTO adAudiencePushDTO);


    @Mapping(target = "id", source = "adAudiencePush.id")
    @Mapping(target = "extFieldList", source = "extFieldList")
    @Mapping(target = "tenantId", source = "adAudiencePush.tenantId")
    @Mapping(target = "deleted", source = "adAudiencePush.deleted")
    @Mapping(target = "version", source = "adAudiencePush.version")
    @Mapping(target = "creatorId", source = "adAudiencePush.creatorId")
    @Mapping(target = "creatorName", source = "adAudiencePush.creatorName")
    @Mapping(target = "dateCreated", source = "adAudiencePush.dateCreated")
    @Mapping(target = "updaterId", source = "adAudiencePush.updaterId")
    @Mapping(target = "updaterName", source = "adAudiencePush.updaterName")
    @Mapping(target = "lastUpdated", source = "adAudiencePush.lastUpdated")
    @Mapping(target = "uniqueExtFieldMap", ignore = true)
    @Mapping(target = "notUniqueExtFieldGroup", ignore = true)
    @Mapping(target = "extFieldMap", ignore = true)
    @Mapping(target = "extFieldGroup", ignore = true)
    AdAudiencePushDTO entityToDTO(AdAudiencePush adAudiencePush,
                                  List<AdAudiencePushExtField> extFieldList,
                                  AdAudiencePushSegmentSyncConfig adAudiencePushSegmentSyncConfig,
                                  List<AdAudiencePushIdentityConfig> audiencePushIdentityConfigList);


    @Mapping(target = "uniqueExtFieldMap", ignore = true)
    @Mapping(target = "totalRecognitionRate", ignore = true)
    @Mapping(target = "totalPushSuccessCount", ignore = true)
    @Mapping(target = "totalPushCount", ignore = true)
    @Mapping(target = "notUniqueExtFieldGroup", ignore = true)
    @Mapping(target = "lastPushStatusCountMap", ignore = true)
    @Mapping(target = "extFieldMap", ignore = true)
    @Mapping(target = "extFieldGroup", ignore = true)
    @Mapping(target = "id", source = "adAudiencePush.id")
    @Mapping(target = "tenantId", source = "adAudiencePush.tenantId")
    @Mapping(target = "deleted", source = "adAudiencePush.deleted")
    @Mapping(target = "version", source = "adAudiencePush.version")
    @Mapping(target = "creatorId", source = "adAudiencePush.creatorId")
    @Mapping(target = "creatorName", source = "adAudiencePush.creatorName")
    @Mapping(target = "dateCreated", source = "adAudiencePush.dateCreated")
    @Mapping(target = "updaterId", source = "adAudiencePush.updaterId")
    @Mapping(target = "updaterName", source = "adAudiencePush.updaterName")
    @Mapping(target = "lastUpdated", source = "adAudiencePush.lastUpdated")
    @Mapping(target = "extFieldList", source = "extFieldList")
    @Mapping(target = "audiencePushIdentityConfigList", source = "audiencePushIdentityConfigList")
    AdAudiencePushIndexDTO entityToIndexDTO(AdAudiencePush adAudiencePush, AdAudiencePushSegmentSyncConfig adAudiencePushSegmentSyncConfig, List<AdAudiencePushIdentityConfig> audiencePushIdentityConfigList, List<AdAudiencePushExtField> extFieldList);

    @Mapping(target = "id", source = "audiencePushId")
    AdAudiencePush parseFromAdAudiencePushWithSegmentSyncConfigDTO(AdAudiencePushWithSegmentSyncConfigDTO adAudiencePushWithSegmentSyncConfigDTO);

}
