package com.convertlab.macore.ad.job;

import com.convertlab.data.job.core.handler.ClJobHandlerMark;
import com.convertlab.data.job.core.handler.annotation.ClJob;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.multitenancy.annotation.TenantIgnore;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.macore.ad.common.utils.JacksonUtils;
import com.convertlab.macore.ad.mapping.AdAudiencePushMapping;
import com.convertlab.macore.ad.model.dto.AdAudiencePushWithSegmentSyncConfigDTO;
import com.convertlab.macore.ad.model.entity.AdAudiencePush;
import com.convertlab.macore.ad.model.entity.AdAudiencePushIdentityConfig;
import com.convertlab.macore.ad.model.entity.AdAudiencePushSegmentSyncConfig;
import com.convertlab.macore.ad.service.biz.BizAdAudiencePushService;
import com.convertlab.macore.ad.service.biz.BizFileService;
import com.convertlab.macore.ad.service.dao.AdAdvertiserAccountService;
import com.convertlab.macore.ad.service.dao.AdAudiencePushIdentityConfigService;
import com.convertlab.macore.ad.service.dao.AdAudiencePushSegmentSyncConfigService;
import com.convertlab.macore.ad.service.dao.AdAudiencePushService;
import com.convertlab.macore.ad.service.muilt.impl.AdTencentServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;


/**
 * @author fucheng.ning
 * @version v1
 */
@Slf4j
@Component
@RestController
@DataSourceLookup("main")
@RequestMapping("/ad_mkt/job")
public class SyncSegmentOperatePushJobHandler implements ClJobHandlerMark {

    @Resource
    private AdAudiencePushSegmentSyncConfigService adAudiencePushSegmentSyncConfigService;
    @Resource
    private BizAdAudiencePushService bizAdAudiencePushService;
    @Resource
    private AdAudiencePushService adAudiencePushService;

    /**
     * 10min 跑一次更新策略的
     * 将对应 {@link AdAudiencePushIdentityConfig} 需要的文件上传到平台
     *
     * @author luck
     */
    @TenantIgnore
    @PostMapping("/syncSegmentOperatePushJobHandler")
    @ClJob(value = "syncSegmentOperatePushJobHandler")
    public void run() {
        log.info("SyncSegmentOperatePushJobHandler_run start");

        Number lastIdOffsetId = null;
        Instant now = Instant.now();

        List<AdAudiencePushSegmentSyncConfig> adAudiencePushWithSegmentSyncConfigDTOList = new ArrayList<>();

        // 需要进行更新动作的记录
        while (true) {
            try {
                adAudiencePushWithSegmentSyncConfigDTOList = adAudiencePushSegmentSyncConfigService.getBaseMapper().listNeedProcess(now, lastIdOffsetId, 20);
            } catch (Exception e) {
                log.error("SyncSegmentOperatePushJobHandler_run query exception, time: {}, lastIdOffsetId: {}, limit: {}, list: {}", now, lastIdOffsetId, 20, JacksonUtils.toJSONString(adAudiencePushWithSegmentSyncConfigDTOList));
            }
            if (CollectionUtils.isEmpty(adAudiencePushWithSegmentSyncConfigDTOList)) {
                log.warn("SyncSegmentOperatePushJobHandler_run break");
                break;
            }
            // 过滤出状态正常的
            log.info("SyncSegmentOperatePushJobHandler_run while process, lastIdOffsetId: {}, adAudiencePushWithSegmentSyncConfigDTOList: {}", lastIdOffsetId, JacksonUtils.toJSONString(adAudiencePushWithSegmentSyncConfigDTOList));
            lastIdOffsetId = adAudiencePushWithSegmentSyncConfigDTOList.stream().mapToLong(AdAudiencePushSegmentSyncConfig::getId).max().getAsLong();

            Map<Long, List<AdAudiencePushSegmentSyncConfig>> tenantIdGroup = adAudiencePushWithSegmentSyncConfigDTOList.stream().collect(Collectors.groupingBy(AdAudiencePushSegmentSyncConfig::getTenantId));

            for (Map.Entry<Long, List<AdAudiencePushSegmentSyncConfig>> tenantEntry : tenantIdGroup.entrySet()) {
                Long tenantId = tenantEntry.getKey();

                // 跨租户查了出来，但是要单独租户处理
                try (TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(tenantId)) {
                    List<AdAudiencePushSegmentSyncConfig> adAudiencePushSegmentSyncConfigList = tenantEntry.getValue();
                    for (AdAudiencePushSegmentSyncConfig adAudiencePushSegmentSyncConfig : adAudiencePushSegmentSyncConfigList) {
                        run(adAudiencePushSegmentSyncConfig, now);
                    }
                }
            }
        }

        log.info("SyncSegmentOperatePushJobHandler_run end");

    }

    public void run(AdAudiencePushSegmentSyncConfig adAudiencePushSegmentSyncConfig, Instant now) {
        String updateAdAudiencePushPushStatus = AdAudiencePush.PushStatus.PENDING.getCode();
        String updateAdAudiencePushPushReason = null;
        String updateAdAudiencePushAudienceStatus = AdAudiencePush.AudienceStatus.PENDING.getCode();
        try {
            bizAdAudiencePushService.extractOperatePushData(adAudiencePushSegmentSyncConfig.getAudiencePushId(), true, false);
        } catch (Exception e) {
            log.warn("SyncSegmentOperatePushJobHandler_run processing adAudiencePushSegmentSyncConfig: {}, ", JacksonUtils.toJSONString(adAudiencePushSegmentSyncConfig), e);
            updateAdAudiencePushPushStatus = AdAudiencePush.PushStatus.FAILURE.getCode();
            updateAdAudiencePushPushReason = e.getMessage();
        } finally {
            AdAudiencePush updateAdAudiencePush = new AdAudiencePush();
            updateAdAudiencePush.setId(adAudiencePushSegmentSyncConfig.getAudiencePushId());
            updateAdAudiencePush.setPushStatus(updateAdAudiencePushPushStatus);
            updateAdAudiencePush.setPushReason(updateAdAudiencePushPushReason);
            updateAdAudiencePush.setAudienceStatus(updateAdAudiencePushAudienceStatus);

            updateAdAudiencePush.setLastUpdated(now);
            updateAdAudiencePush.setUpdaterId(adAudiencePushSegmentSyncConfig.getUpdaterId());
            updateAdAudiencePush.setUpdaterName(adAudiencePushSegmentSyncConfig.getUpdaterName());

            adAudiencePushService.updateById(updateAdAudiencePush);
        }
    }
}