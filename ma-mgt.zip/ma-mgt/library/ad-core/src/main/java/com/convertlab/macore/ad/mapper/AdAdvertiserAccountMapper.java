package com.convertlab.macore.ad.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.convertlab.macore.ad.model.dto.AdAccountDTO;
import com.convertlab.macore.ad.model.entity.AdAdvertiserAccount;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Collection;
import java.util.List;

/**
 * @author luck
 */
@Mapper
public interface AdAdvertiserAccountMapper extends BaseMapper<AdAdvertiserAccount> {

    List<AdAdvertiserAccount> nativeBatchGetByOuterIds(@Param("adPlatformCode") String adPlatformCode,
                                                       @Param("outerIds") Collection<String> outerIds);

    Page<AdAccountDTO> nativePageAccounts(@Param("page") Page<AdAccountDTO> page,
                                          @Param("key") String key,
                                          @Param("statusList")List<String> statusList);

}
