package com.convertlab.macore.ad.mapper;

import com.baomidou.mybatisplus.annotation.InterceptorIgnore;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.ad.model.entity.AdAudiencePushSegmentSyncConfig;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.Instant;
import java.util.List;

/**
 * @author luck
 */
@Mapper
public interface AdAudiencePushSegmentSyncConfigMapper extends BaseMapper<AdAudiencePushSegmentSyncConfig> {

    @InterceptorIgnore(tenantLine = "true")
    List<AdAudiencePushSegmentSyncConfig> listNeedProcess(@Param("now") Instant now,
                                                          @Param("lastIdOffsetId") Number lastIdOffsetId,
                                                          @Param("limit") Number limit);
}
