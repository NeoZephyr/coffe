package com.convertlab.macore.ad.job;

import com.convertlab.data.job.core.handler.ClJobHandlerMark;
import com.convertlab.data.job.core.handler.annotation.ClJob;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.multitenancy.annotation.TenantIgnore;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.mybatisplus.entity.BaseTenantEntity;
import com.convertlab.macore.ad.client.AdTencentClient;
import com.convertlab.macore.ad.client.res.TencentAdOauthTokenRes;
import com.convertlab.macore.ad.common.consts.AdPlatformConfigConsts;
import com.convertlab.macore.ad.common.enums.AdPlatformCodeEnum;
import com.convertlab.macore.ad.common.helper.TryCatchHelper;
import com.convertlab.macore.ad.common.utils.JacksonUtils;
import com.convertlab.macore.ad.mapping.AdExtFieldMapping;
import com.convertlab.macore.ad.model.CommonExtField;
import com.convertlab.macore.ad.model.dto.AdAppAuthInfoDTO;
import com.convertlab.macore.ad.model.entity.AdAppAuthInfo;
import com.convertlab.macore.ad.model.entity.AdAppDeveloperInfo;
import com.convertlab.macore.ad.service.biz.BizAdAppAuthInfoService;
import com.convertlab.macore.ad.service.biz.BizAdAppDeveloperInfoService;
import com.convertlab.macore.ad.service.dao.AdAppAuthInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;


/**
 * @author fucheng.ning
 * @version v1
 */
@Slf4j
@Component
@RestController
@DataSourceLookup("main")
@RequestMapping("/ad_mkt/job")
public class RefreshTokenJobHandler implements ClJobHandlerMark {

    @Resource
    private BizAdAppDeveloperInfoService bizAdAppDeveloperInfoService;
    @Resource
    private BizAdAppAuthInfoService bizAdAppAuthInfoService;
    @Resource
    private AdAppAuthInfoService adAppAuthInfoService;
    @Resource
    private AdExtFieldMapping adExtFieldMapping;
    @Resource
    private AdTencentClient adTencentClient;


    /**
     * 刷新 token 并且要保证双写
     * 每十分钟
     *
     * @author luck
     * @apiNote 刷新 token 并且要保证双写
     * @since 2024-07-16 15:56:51
     */
    @TenantIgnore
    @PostMapping("/refreshTokenJobHandler")
    @ClJob(value = "refreshTokenJobHandler")
    public void doRefreshToken() {
        log.info("RefreshTokenJobHandler_doRefreshToken start");
        Instant now = Instant.now().minus(AdAppAuthInfoDTO.MAGIC_INTERVAL, ChronoUnit.MINUTES);

        Number lastIdOffsetId = null;
        Number limit = 20L;

        List<AdAppAuthInfo> authInfoList = new ArrayList<>();

        while (true) {
            try {
                authInfoList = adAppAuthInfoService.getBaseMapper().nativeCursorExpiredAccessToken(now, lastIdOffsetId, limit);
            } catch (Exception e) {
                log.error("RefreshTokenJobHandler_doRefreshToken query exception, time: {}, lastIdOffsetId: {}, limit: {}, authInfoList: {}", now, lastIdOffsetId, limit, JacksonUtils.toJSONString(authInfoList));
            }
            if (CollectionUtils.isEmpty(authInfoList)) {
                log.warn("RefreshTokenJobHandler_doRefreshToken break");
                break;
            }

            log.info("RefreshTokenJobHandler_doRefreshToken while process, time: {}, lastIdOffsetId: {}, limit: {}, authInfoList: {}", now, lastIdOffsetId, limit, JacksonUtils.toJSONString(authInfoList));

            lastIdOffsetId = authInfoList.stream().mapToLong(AdAppAuthInfo::getId).max().getAsLong();

            Map<Long, List<AdAppAuthInfo>> tenantIdGroup = authInfoList.stream().collect(Collectors.groupingBy(BaseTenantEntity::getTenantId));

            for (Map.Entry<Long, List<AdAppAuthInfo>> tenantEntry : tenantIdGroup.entrySet()) {
                Long tenantId = tenantEntry.getKey();
                // 跨租户查了出来，但是要单独租户处理
                try (TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(tenantId)) {
                    List<AdAppAuthInfoDTO> updateAdAppAuthInfoDTOByTenantList = new ArrayList<>();

                    List<AdAppAuthInfo> tenantAdAppAuthInfoList = tenantEntry.getValue();
                    Map<String, List<AdAppAuthInfo>> adPlatformCodeGroup = tenantAdAppAuthInfoList.stream().collect(Collectors.groupingBy(AdAppAuthInfo::getAdPlatformCode));

                    // todo:luck:2024/7/16 15:32:后面需要抽象策略模式处理
                    for (Map.Entry<String, List<AdAppAuthInfo>> adPlatformCodeEntry : adPlatformCodeGroup.entrySet()) {
                        String adPlatformCode = adPlatformCodeEntry.getKey();
                        // luck:2024/7/16 14:58:目前只处理腾讯
                        if (!Objects.equals(adPlatformCode, AdPlatformCodeEnum.TENCENT_AD.getCode())) {
                            log.warn("RefreshTokenJobHandler_doRefreshToken adPlatformCode is not support, skip. adPlatformCode: {}", adPlatformCode);
                            continue;
                        }
                        // refresh token
                        List<AdAppAuthInfo> tenantPlatformCodeAppAuthInfoList = adPlatformCodeEntry.getValue();
                        Map<String, List<AdAppAuthInfo>> clientIdGroup = tenantPlatformCodeAppAuthInfoList.stream().collect(Collectors.groupingBy(AdAppAuthInfo::getClientId));
                        // 相同 clientId 的一起处理
                        for (Map.Entry<String, List<AdAppAuthInfo>> clientEntry : clientIdGroup.entrySet()) {
                            String clientId = clientEntry.getKey();
                            AdAppDeveloperInfo adAppDeveloperInfo = bizAdAppDeveloperInfoService.cacheableGetValidAdAppDeveloperInfo(adPlatformCode, clientId);
                            if (Objects.isNull(adAppDeveloperInfo)) {
                                log.warn("RefreshTokenJobHandler_doRefreshToken adAppDeveloperInfo not found, skip. adPlatformCode: {}, clientId: {}", adPlatformCode, clientId);
                                continue;
                            }
                            log.info("RefreshTokenJobHandler_doRefreshToken adAppDeveloperInfo is: {}", JacksonUtils.toJSONString(adAppDeveloperInfo));

                            // 再通过 refreshToken group
                            Map<String, List<AdAppAuthInfo>> refreshTokenGroup = clientEntry.getValue().stream().collect(Collectors.groupingBy(AdAppAuthInfo::getRefreshToken));

                            for (Map.Entry<String, List<AdAppAuthInfo>> refreshTokenEntry : refreshTokenGroup.entrySet()) {
                                String refreshToken = refreshTokenEntry.getKey();

                                StringBuilder authReasonBuilder = new StringBuilder();
                                TencentAdOauthTokenRes tencentAdOauthTokenRes = Optional.ofNullable(
                                                TryCatchHelper.supplier(() -> adTencentClient.oauthToken(
                                                                adAppDeveloperInfo.getClientId(),
                                                                adAppDeveloperInfo.getClientSecret(),
                                                                AdPlatformConfigConsts.TencentAdConfig.REFRESH_TOKEN,
                                                                null,
                                                                null,
                                                                refreshToken),
                                                        e -> {
                                                            log.error("RefreshTokenJobHandler_doRefreshToken adTencentClient.oauthToken error, adPlatformCode: {}, clientId: {}, refreshToken: {} ",
                                                                    adPlatformCode,
                                                                    clientId,
                                                                    refreshToken,
                                                                    e);
                                                            authReasonBuilder.append(e.getMessage());
                                                            return null;
                                                        })
                                        ).map(tencentAdOauthTokenResTencentAdResult -> {
                                            log.warn("RefreshTokenJobHandler_doRefreshToken tencentAdOauthTokenResTencentAdResult: {}", JacksonUtils.toJSONString(tencentAdOauthTokenResTencentAdResult));
                                            return tencentAdOauthTokenResTencentAdResult.getData();
                                        })
                                        .orElse(null);

                                if (Objects.isNull(tencentAdOauthTokenRes)) {
                                    log.warn("RefreshTokenJobHandler_doRefreshToken tokenRes is null, skip. adPlatformCode: {}, clientId: {}", adPlatformCode, clientId);
                                }

                                // 这一批 AdAppAuthInfo 都是一样的 refreshToken update
                                Instant resNow = Instant.now();
                                // 因为涉及到双写 redis，没办法了
                                for (AdAppAuthInfo adAppAuthInfo : refreshTokenEntry.getValue()) {
                                    AdAppAuthInfoDTO adAppAuthInfoDTO = bizAdAppAuthInfoService.get(adPlatformCode, clientId, adAppAuthInfo.getAppId());
                                    log.info("RefreshTokenJobHandler_doRefreshToken getAdAppAuthInfoDTO: {}", JacksonUtils.toJSONString(adAppAuthInfoDTO));

                                    // 这里必须只能更新需要更新的字段，一定不能全字段更新！

                                    if (Objects.nonNull(tencentAdOauthTokenRes)) {
                                        adAppAuthInfoDTO.setAccessToken(tencentAdOauthTokenRes.getAccessToken());
                                        adAppAuthInfoDTO.setAccessTokenExpiresIn(tencentAdOauthTokenRes.getAccessTokenExpiresIn());
                                        adAppAuthInfoDTO.setAccessTokenExpiresTime(resNow.plusSeconds(tencentAdOauthTokenRes.getAccessTokenExpiresIn()));

                                        adAppAuthInfoDTO.setRefreshToken(tencentAdOauthTokenRes.getRefreshToken());
                                        adAppAuthInfoDTO.setRefreshTokenExpiresIn(adAppAuthInfoDTO.getRefreshTokenExpiresIn());
                                        adAppAuthInfoDTO.setRefreshTokenExpiresTime(resNow.plusSeconds(adAppAuthInfoDTO.getRefreshTokenExpiresIn()));

                                        adAppAuthInfoDTO.getExtFieldList().removeIf(i -> Objects.equals(i.getName(), "refreshTime"));
                                        adAppAuthInfoDTO.getExtFieldList().add(adExtFieldMapping.getAdAppAuthInfoExtField(CommonExtField.genDatetime(adAppAuthInfoDTO.getId(), "refreshTime", resNow)));
                                    } else {
                                        adAppAuthInfoDTO.setAuthStatus(AdAppAuthInfo.AuthStatusEnum.FAILURE.getCode());

                                        Long fk = adAppAuthInfoDTO.getId();
                                        // todo:luck:2024/7/16 15:59: 拓展字段统一管理
                                        adAppAuthInfoDTO.getExtFieldList().removeIf(i -> Objects.equals(i.getName(), "authReason"));
                                        adAppAuthInfoDTO.getExtFieldList().add(adExtFieldMapping.getAdAppAuthInfoExtField(CommonExtField.genStr(fk, "authReason", authReasonBuilder.toString())));
                                    }

                                    updateAdAppAuthInfoDTOByTenantList.add(adAppAuthInfoDTO);
                                }
                            }
                        }
                    }

                    for (AdAppAuthInfoDTO adAppAuthInfoDTO : updateAdAppAuthInfoDTOByTenantList) {
                        bizAdAppAuthInfoService.store(adAppAuthInfoDTO);
                    }
                }

            }


        }
        log.info("RefreshTokenJobHandler_doRefreshToken end");

    }
}