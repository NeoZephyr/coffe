package com.convertlab.macore.ad.mapping;

import com.convertlab.macore.ad.model.dto.AdAdvertiserAccountDTO;
import com.convertlab.macore.ad.model.entity.AdAdvertiserAccount;
import com.convertlab.macore.ad.model.entity.AdAdvertiserAccountExtField;
import org.mapstruct.*;

import java.util.List;

/**
 * @author luck
 * @since 2023/4/20 11:18
 */
@Mapper(componentModel = "spring",
        collectionMappingStrategy = CollectionMappingStrategy.ADDER_PREFERRED,
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        unmappedTargetPolicy = ReportingPolicy.WARN
)
public interface AdAdvertiserAccountMapping {

    @Mapping(target = "uniqueExtFieldMap", ignore = true)
    @Mapping(target = "notUniqueExtFieldGroup", ignore = true)
    @Mapping(target = "extFieldMap", ignore = true)
    @Mapping(target = "extFieldList",source = "adAdvertiserExtFieldList")
    @Mapping(target = "extFieldGroup", ignore = true)
    AdAdvertiserAccountDTO toDTO(AdAdvertiserAccount adAdvertiserAccount, List<AdAdvertiserAccountExtField> adAdvertiserExtFieldList);

    AdAdvertiserAccount toEntity(AdAdvertiserAccountDTO adAdvertiserAccountDTO);

    void updateByDTO(AdAdvertiserAccountDTO adAdvertiserAccountDTO, @MappingTarget AdAdvertiserAccount adAdvertiserAccount);

}
