package com.convertlab.macore.ad.client;

import com.convertlab.foundation.library.openfeign.configure.ProxyFeignConfiguration;
import com.convertlab.foundation.library.openfeign.interceptor.ContextPropagatingRequestInterceptor;
import com.convertlab.foundation.library.openfeign.interceptor.TenantPropagatingRequestInterceptor;
import com.convertlab.macore.ad.client.interceptor.TencentAdInterceptor;
import com.convertlab.macore.ad.client.req.AddCustomAudiencesReq;
import com.convertlab.macore.ad.client.req.DeleteCustomAudiencesReq;
import com.convertlab.macore.ad.client.res.*;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@FeignClient(
        name = "AdTencentClient",
        url = "${TENCENT_AD_DOMAIN:https://api.e.qq.com}",
        configuration = {TenantPropagatingRequestInterceptor.class, ContextPropagatingRequestInterceptor.class, TencentAdInterceptor.class, ProxyFeignConfiguration.class},
        decode404 = true
)
public interface AdTencentClient {

    /**
     * https://developers.e.qq.com/docs/api/authorize/oauth/oauth_token
     */
    @GetMapping("/oauth/token")
    TencentAdResult<TencentAdOauthTokenRes> oauthToken(@RequestParam("client_id") String clientId,
                                                       @RequestParam("client_secret") String clientSecret,
                                                       @RequestParam("grant_type") String grantType,
                                                       @RequestParam(value = "authorization_code", required = false) String authorizationCode,
                                                       @RequestParam(value = "redirect_uri", required = false) String redirectUri,
                                                       @RequestParam(value = "refresh_token", required = false) String refreshToken
    );

    /**
     * 查询腾讯广告广告主信息
     * https://developers.e.qq.com/docs/api/account/advertiser/advertiser_get
     */
    @GetMapping("/v3.0/advertiser/get")
    TencentAdResult<TencentAdAdvertiserRes> getAdvertisers(@RequestHeader(TencentAdInterceptor.AD_TOKEN_APP_ID) String adTokenAppId,
                                                           @RequestParam(value = "agency_id", required = false) Object agencyId,
                                                           @RequestParam(value = "account_id", required = false) Object accountId,
                                                           @RequestParam(value = "filtering", required = false) String filtering,
                                                           @RequestParam("fields") String fields,
                                                           @RequestParam(value = "pagination_mode") String paginationMode,
                                                           @RequestParam(value = "page", required = false) Object page,
                                                           @RequestParam(value = "page_size", required = false) Object pageSize,
                                                           @RequestParam(value = "cursor", required = false) Object cursor
    );

    /**
     * 查询组织下广告账号信息
     * https://developers.e.qq.com/v3.0/docs/api/organization_account_relation/get
     */
    @GetMapping("/v3.0/organization_account_relation/get")
    TencentAdResult<TencentAdOrganizationAccountRelationRes> getOrganizationAccountRelations(@RequestHeader(TencentAdInterceptor.AD_TOKEN_APP_ID) String adTokenAppId,
                                                                                             @RequestParam(value = "account_id", required = false) Object accountId,
                                                                                             @RequestParam(value = "pagination_mode") String paginationMode,
                                                                                             @RequestParam(value = "advertiser_type", required = false) String advertiserType,
                                                                                             @RequestParam(value = "page", required = false) Object page,
                                                                                             @RequestParam(value = "page_size", required = false) Object pageSize,
                                                                                             @RequestParam(value = "cursor", required = false) Object cursor
    );

    /**
     * 创建客户人群
     * <p>
     * <p>
     * https://developers.e.qq.com/v3.0/docs/api/custom_audiences/add
     *
     * @param adTokenAppId          token 绑定在哪个 appId 下
     * @param addCustomAudiencesReq 添加习俗观众请求体
     * @return {@link TencentAdResult }<{@link AddCustomAudiencesRes }>
     * @author luck
     * @apiNote 创建客户人群
     * https://developers.e.qq.com/v3.0/docs/api/custom_audiences/add
     * @see String
     * @see AddCustomAudiencesReq
     * @see TencentAdResult<AddCustomAudiencesRes>
     * @since 2024-07-26 14:16:16
     */
    @PostMapping("/v3.0/custom_audiences/add")
    TencentAdResult<AddCustomAudiencesRes> addCustomAudiences(@RequestHeader(TencentAdInterceptor.AD_TOKEN_APP_ID) String adTokenAppId,
                                                              @RequestBody AddCustomAudiencesReq addCustomAudiencesReq);

    /**
     * 删除客户人群
     * <p>
     * <p>
     * https://developers.e.qq.com/v3.0/docs/api/custom_audiences/delete
     *
     * @param adTokenAppId             token 绑定在哪个 appId 下
     * @param deleteCustomAudiencesReq {@link DeleteCustomAudiencesReq}
     * @return {@link TencentAdResult }<{@link AddCustomAudiencesRes }>
     * @author luck
     * @apiNote 删除客户人群
     * https://developers.e.qq.com/v3.0/docs/api/custom_audiences/delete
     * @see String
     * @see AddCustomAudiencesReq
     * @see TencentAdResult<AddCustomAudiencesRes>
     * @since 2024-07-26 14:16:16
     */
    @PostMapping("/v3.0/custom_audiences/delete")
    TencentAdResult<?> deleteCustomAudiences(@RequestHeader(TencentAdInterceptor.AD_TOKEN_APP_ID) String adTokenAppId,
                                             @RequestBody DeleteCustomAudiencesReq deleteCustomAudiencesReq);

    /**
     * 上传客户人群数据文件
     * https://github.com/spring-cloud/spring-cloud-openfeign/blob/5aa1b7a5298d985e9e103da3752c932b0ebc4200/spring-cloud-openfeign-core/src/test/java/org/springframework/cloud/openfeign/valid/ValidFeignClientTests.java#L352
     * https://developers.e.qq.com/v3.0/docs/api/custom_audience_files/add
     *
     * @param adTokenAppId token 绑定在哪个 appId 下
     *                     accountId     accountId
     *                     audienceId    人群 id，只能是 CUSTOMER_FILE 类人群
     *                     userIdType    号码包用户 id 类型，[枚举详情] 可选值：{ HASH_IDFA, HASH_IMEI, HASH_MOBILE_PHONE, IDFA, IMEI, WX_OPENID, WX_UNIONID, WECHAT_OPENID, SALTED_HASH_IMEI, SALTED_HASH_IDFA, OAID, HASH_OAID, SHA256_MOBILE_PHONE, MD5_SHA256_IMEI, MD5_SHA256_IDFA, MD5_SHA256_OAID, CAID }
     *                     file          上传人群文件，txt 或者 csv 文件每行一个号码，文件压缩后的 zip 包，压缩后的 zip 包不超过 100M
     *                     operationType 可选值：{ APPEND, REDUCE }
     *                     openAppId     打开应用程序 id
     * @return {@link TencentAdResult }<{@link AddCustomAudiencesRes }>
     * @author luck
     * @apiNote 上传客户人群数据文件
     * https://developers.e.qq.com/v3.0/docs/api/custom_audience_files/add
     * @since 2024-07-26 14:16:16
     */
    @PostMapping(value = "/v3.0/custom_audience_files/add", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    TencentAdResult<AddCustomAudienceFileRes> addCustomAudienceFiles(@RequestHeader(TencentAdInterceptor.AD_TOKEN_APP_ID) String adTokenAppId,
                                                                     @RequestBody Map<String, ?> form);

    /**
     * 获取客户人群数据文件
     * https://developers.e.qq.com/v3.0/docs/api/custom_audience_files/get
     */
    @GetMapping("/v3.0/custom_audience_files/get")
    TencentAdResult<TencentCustomAudienceFilesRes> getCustomAudienceFiles(@RequestHeader(TencentAdInterceptor.AD_TOKEN_APP_ID) String adTokenAppId,
                                                                          @RequestParam(value = "account_id") Object accountId,
                                                                          @RequestParam(value = "audience_id", required = false) Object audienceId,
                                                                          @RequestParam(value = "custom_audience_file_id", required = false) Object customAudienceFileId,
                                                                          @RequestParam(value = "page", required = false) Object page,
                                                                          @RequestParam(value = "page_size", required = false) Object pageSize
    );

    /**
     * https://developers.e.qq.com/v3.0/docs/api/custom_audiences/get
     * 获取客户人群
     */
    @GetMapping("/v3.0/custom_audiences/get")
    TencentAdResult<TencentCustomAudiencesRes> getCustomAudiences(@RequestHeader(TencentAdInterceptor.AD_TOKEN_APP_ID) String adTokenAppId,
                                                                  @RequestParam(value = "account_id") Object accountId,
                                                                  @RequestParam(value = "audience_id", required = false) Object audienceId,
                                                                  @RequestParam(value = "page", required = false) Object page,
                                                                  @RequestParam(value = "page_size", required = false) Object pageSize
    );
}