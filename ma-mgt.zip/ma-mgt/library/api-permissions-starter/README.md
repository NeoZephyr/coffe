## Requirements

* Java 8

<br>

## 功能列表

* 提供接口功能权限校验的配置 BffSecurityConfig。
* 继承AbstractApiPermissionValidator 实现功能权限校验逻辑。

## 使用方法

在项目中注入如下Bean

``` java
import com.convertlab.macore.api.permissions.configure.BffSecurityConfig;

@NotNull
@Bean
@ConditionalOnMissingBean
public PermissionValidator permissionValidator() {
    return new BffSecurityConfig();
}
```

程序将自动为所有加注了 @ViewController 的Controller进行接口功能权限校验。

### 使用 @RequirePermission 给Controller指定功能权限的permission key

在com.convertlab.**.controller.bff包下的Controller，会被自动识别为Bff Controller。Bff接口可以自动暴露到app服务，供前端访问(具体参考HomeController 的 /api/manifest接口),
为避免接口功能权限校验失败，请确保所有BffController中的接口通过 @RequirePermission() 注解配置功能权限。

> @RequirePermission() 允许指定多个功能权限，如果用户角色（或角色组）包含其中任意一个权限，则认为用户拥有该接口的访问权限。
>
```java
@GetMapping("/meta/{profileName}/identities")
@RequirePermission({"identity.read", "udoMeta.read"})
public GenericListResponse<ProfileIdentityBizMeta> getProfileIdentities(@ResourceIdentifier @NotNull @PathVariable("profileName") String profileName) {
        return profileMetaController.getProfileIdentities(profileName);
        }
```
如果登录用户是管理员，或者拥有identity.read， 或者拥有udoMeta.read功能权限，就能访问这个接口，否则访问会报**InsufficientPermissionException**异常

### 使用 @RequireAdminPermission 给Controller指定管理员访问权限
如果一个接口仅允许管理员访问，可以通过给Controller添加@RequireAdminPermission注解实现。

**e.g**

```java
@PostMapping("/meta/{profileName}/register")
@Operation(summary = "注册高级筛选插入点")
@RequireAdminPermission()
public GenericResponse<FilterExtensionPoints> register(@PathVariable String profileName,
                                                           @RequestBody FilterRegistrationRequest request) {
        return filterController.register(profileName, request);
}
```

### 使用 ResourceIdentifier 匹配合适资源的功能权限

接口中可以指定某一个path参数，或者请求参数，或者请求体参数为资源（resource）。在这种情况下，仅匹配
@RequirePermission 中对应资源的功能权限。

例如下面的接口，标识了path参数 profileName 为资源，接口的静态功能权限中有两个:

```java
@GetMapping("/meta/{profileName}/sources")
@Operation(summary = "返回档案的来源Meta[仅限主档案]")
@RequirePermission({"source.read", "udoMeta.read"})
public GenericListResponse<ProfileSourceBizMeta> getProfileSources(@ResourceIdentifier @NotNull @PathVariable("profileName") String profileName,
@Nullable @RequestParam("count") boolean count) {
        return profileMetaController.getProfileSources(profileName, count);
        }
```

* "source.read", // 客户来源的读权限，包含来源配置，以及来源数据的读取权限。

* "udoMeta.read" // udo的meta的读权限

> 当profileName 为customer时，仅有当前用户角色（或角色组）包含 source.read 权限时，才能访问该接口。
对应的，当profileName为某一个通用档案，e.g. c_car时，仅有当前用户角色（或角色组）包含 udoMeta.read 权限时，才能访问该接口。

## 实现自己的校验器

在 ```src/main/java/com/convertlab/macore/api/permissions/validators``` 目录下，目前已提供了主档案，通用档案及Ad-Hoc的校验器。如果需要其他的校验器，可以继承AbstractApiPermissionValidator
并实现```validateUserPermissionToRequest``` 方法。

```validateUserPermissionToRequest``` 方法返回一个```Set<RolePermission>```, 如果校验器返回一个非空的Set<RolePermission>；即当前用户含有该接口的访问权限。


