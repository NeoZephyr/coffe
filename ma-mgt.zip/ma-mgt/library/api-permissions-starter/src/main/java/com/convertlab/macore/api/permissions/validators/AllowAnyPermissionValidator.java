package com.convertlab.macore.api.permissions.validators;

import com.convertlab.macore.api.permissions.model.RolePermission;
import org.springframework.stereotype.Component;

import javax.annotation.Nullable;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 通配符接口权限校验器，ToDo:有部分接口暂时未定挂载到哪个功能权限上。临时放这里。后续要找到对应的功能挂载点
 */
@Component
public class AllowAnyPermissionValidator extends AbstractApiPermissionValidator{
    private static final String WILDCARD = "*";
    @Override
    protected Set<RolePermission> validateUserPermissionToRequest(@Nullable String resource, @Nullable String[] apiPermission, List<RolePermission> rolePermissions) {
        // Todo 有些接口暂时无法从功能权限树中找到合适的功能权限，临时用AllowAny 让通过
        if(Arrays.stream(apiPermission).filter(p -> p.equals(WILDCARD)).count() > 0){
            return new HashSet(){{
                add(new RolePermission());
            }};
        }else{
            return new HashSet<>();
        }
    }
}
