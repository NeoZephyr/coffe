package com.convertlab.macore.api.permissions.common;

public class ApiPermissionValidateException extends RuntimeException{
    public ApiPermissionValidateException(String message) {
        super(message);
    }
}
