package com.convertlab.macore.api.permissions.validators;

import com.convertlab.foundation.api.gdm.pattern.GdmModelClient;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto;
import com.convertlab.macore.api.permissions.common.ApiPermissionsUtil;
import com.convertlab.macore.api.permissions.model.RolePermission;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 通用档案及Ad-Hoc接口权限校验器
 */
@Component
@AllArgsConstructor
@Slf4j
public class GeneralProfileAndAdHocApiPermissionValidator extends AbstractApiPermissionValidator{
    private final GdmModelClient profileAssociationClient;
    private static final String PATTERN_GENERAL_PROFILE = "general-profile";
    private static final String PATTERN_AD_HOC = "ad-hoc";

    @Override
    protected Set<RolePermission> validateUserPermissionToRequest(String resource, String[] apiPermission, List<RolePermission> rolePermissions) {
        if(StringUtils.isNotBlank(resource)){
            GdmModelDto modeDef = profileAssociationClient.findByName(resource.toLowerCase());
            if(modeDef!=null && (modeDef.hasPattern(GdmPatternDto.PATTERN_GENERAL_PROFILE) || modeDef.hasPattern(GdmPatternDto.PATTERN_AD_HOC))){
                log.info("start validating general-profile api permission");
                List<ApiPermissionsUtil.ApiPermission> suitableApiPermissions = this.getSuitableApiPermissionsByResource("udo", resource, apiPermission);
                Set<RolePermission> result = evaluatePermissionByResource(Arrays.asList(modeDef.getPatterns()), resource, suitableApiPermissions, rolePermissions);
                log.info("start validating general-profile api permission");
                return result;
            }else if(apiPermission !=null && Arrays.stream(apiPermission).filter(it -> it.equals("udoMeta.create")).count()>0){
                // 创建UDO的时候，资源是profileName,但是profile还未创建，因此在GDMModel里面找不到； 这个时候，需要开特例为拥有udoMeta.create 权限的接口放行
                log.info("start validating profile {} api permission", resource.toLowerCase());
                List<ApiPermissionsUtil.ApiPermission> suitableApiPermissions = this.getSuitableApiPermissionsByResource("udo", resource, apiPermission);
                Set<RolePermission> result = evaluatePermissionByResource(Collections.singletonList(PATTERN_GENERAL_PROFILE), resource, suitableApiPermissions, rolePermissions);
                log.info("start validating profile {} general-profile api permission", resource.toLowerCase());
                return result;
            }
        }
        return new HashSet<>();
    }
}
