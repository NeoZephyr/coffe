package com.convertlab.macore.api.permissions.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.api.permissions.model.RolePermission;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface RolePermissionMapper extends BaseMapper<RolePermission> {
    @Select({"<script>",
            "select rp.* from role_permission rp where rp.role_key in ",
            " <foreach collection=\"roleKey\" item=\"roleKeys\" open=\"(\" separator=\",\" close=\")\">",
            "          #{roleKey}",
            "  </foreach>",
            "</script>"})
    @ResultType(RolePermission.class)
    List<RolePermission> getRolesPermissions(List<Long> roleKeys);


    @Select ({"<script>",
            "select rp.* from user_group_map ugm join user_group_role ugr " +
                    " on ugm.group_code = ugr.group_code join role_permission rp on ugr.role_key = rp.role_key where " +
                    " ugm.user_id = #{userId}",
            "</script>"})
    @ResultType(RolePermission.class)
    List<RolePermission> getUserGroupPermission(Long userId);
}

