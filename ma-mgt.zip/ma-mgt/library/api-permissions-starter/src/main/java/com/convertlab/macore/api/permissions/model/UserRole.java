package com.convertlab.macore.api.permissions.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

@Data
@EqualsAndHashCode(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TableName(value = "user_role",excludeProperty = {"version","creatorId", "creatorName", "updaterId", "updaterName"})
public class UserRole {
    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @TableId(value = "id")
    private Long id;

    @TableField("user_id")
    Long userId;

    @TableField("role_key")
    String roleKey;
}
