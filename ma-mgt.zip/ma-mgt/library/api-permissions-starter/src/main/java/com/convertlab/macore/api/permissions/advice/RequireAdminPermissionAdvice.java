package com.convertlab.macore.api.permissions.advice;

import com.convertlab.foundation.library.exception.InsufficientPermissionException;
import com.convertlab.foundation.library.principal.context.PrincipalContextHolder;
import com.convertlab.foundation.library.webmvc.access.PermissionValidator;
import com.convertlab.macore.api.permissions.annotation.RequireAdminPermission;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.aop.MethodBeforeAdvice;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.util.ClassUtils;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;

@Slf4j
@Aspect
public class RequireAdminPermissionAdvice implements MethodBeforeAdvice {
    private final PermissionValidator permissionValidator;
    public RequireAdminPermissionAdvice(PermissionValidator permissionValidator){
        this.permissionValidator = permissionValidator;
    }
    @Override
    public void before(Method method, Object[] args, Object target) throws Throwable {
        RequireAdminPermission requirePermission = AnnotationUtils.findAnnotation(method, RequireAdminPermission.class);
        if(requirePermission == null){
            return;
        }
        if(!permissionValidator.validate(null, PrincipalContextHolder.getRoles(), null)){
            String uri = null;
            String httpMethod = null;
            RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
            if (requestAttributes != null) {
                HttpServletRequest request = ((ServletRequestAttributes) requestAttributes).getRequest();
                uri = request.getRequestURI();
                httpMethod = request.getMethod();
            }

            String errorMessage = String.format(
                    "Current user [id:%d] has insufficient permissions to access the URI [%s %s] ",
                    PrincipalContextHolder.getUserId(),
                    httpMethod,
                    uri);

            log.warn("The Roles {} owned by User [id:{}] do not match the Permission Requirements {} declared by Method [{}].",
                    PrincipalContextHolder.getRoles(),
                    PrincipalContextHolder.getUserId(),
                    "admin",
                    String.format("%s#%s", ClassUtils.getQualifiedName(method.getDeclaringClass()), method.getName())
            );
            throw new InsufficientPermissionException(errorMessage);
        }
    }
}
