package com.convertlab.macore.api.permissions.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.api.permissions.model.User;

public interface UserMapper  extends BaseMapper<User> {
}
