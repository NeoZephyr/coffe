package com.convertlab.macore.api.permissions.validators;


import com.convertlab.macore.api.permissions.common.ApiPermissionValidateException;
import com.convertlab.macore.api.permissions.common.ApiPermissionsUtil;
import com.convertlab.macore.api.permissions.model.RolePermission;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.ListUtils;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 功能权限校验责任链抽象基类；如需要实现特定接口功能权限校验逻辑，请继承这个类，并实现validateUserPermissionToRequest方法
 */
@Slf4j
public abstract class AbstractApiPermissionValidator {
    protected AbstractApiPermissionValidator nextValidator;
    public static final String WILDCARD = "*";
    private static final String WILDCARD_RESOURCE_PATTERN = "\\{.*\\}";

    public void setNextValidator(AbstractApiPermissionValidator nextValidator) {
        this.nextValidator = nextValidator;
    }

    public Set<RolePermission> checkPermissions(@Nullable String resource, @Nullable String[] apiPermission, List<RolePermission> rolePermissions) throws ApiPermissionValidateException {
        Set<RolePermission> matchedApiPermissions = new HashSet<>();
        matchedApiPermissions = validateUserPermissionToRequest(resource, apiPermission, rolePermissions);
        if(nextValidator != null){
            Set<RolePermission> nextResult = nextValidator.checkPermissions(resource, apiPermission, rolePermissions);
            matchedApiPermissions.addAll(nextResult);
        }
        return matchedApiPermissions;
    }

    /**
     * 验证用户是否有权限访问当前接口
     * @param resource
     * @param apiPermission
     * @param rolePermissions
     */
    abstract protected Set<RolePermission> validateUserPermissionToRequest(@Nullable String resource, @Nullable String[] apiPermission, List<RolePermission> rolePermissions);

    /**
     * 根据资源类型和权限列表获取所有权限
     * @param resourceType  登记在permission.json中的 资源类型，如customer, udo
     * @param apiPermission controller注解中的功能权限
     * @return
     */
    public List<ApiPermissionsUtil.ApiPermission> getSuitableApiPermissionsByResource(String resourceType, String resource, String[] apiPermission){
        List<ApiPermissionsUtil.ApiPermission> result = new ArrayList<>();
        try {
            List<ApiPermissionsUtil.ApiPermission> allPermissions = ApiPermissionsUtil.getApiPermissions();
            if(StringUtils.isNotBlank(resourceType) && StringUtils.isNotBlank(resource)){
                for(String permissionWithWildcard: apiPermission){
                    ApiPermissionsUtil.ApiPermission permission = allPermissions.stream().filter(p-> p.getPermissionKey()
                            .equals(permissionWithWildcard.replaceAll(WILDCARD_RESOURCE_PATTERN, WILDCARD))).findFirst().orElse(null);
                    //  仅当资源类型相同时，才将权限加入接口的权限列表中
                    if(permission !=null && resourceType.equals(permission.getPermissionDocument())){
                        String realPermissionKey = permissionWithWildcard.replaceAll(WILDCARD_RESOURCE_PATTERN, resource);
                        permission.setPermissionKey(realPermissionKey);
                        result.add(permission);
                    }
                }
            }else{
                // 无需匹配资源类型的，例如homepage.read 之类的
                for(String permissionWithWildcard: apiPermission){
                    ApiPermissionsUtil.ApiPermission permission = allPermissions.stream()
                            .filter(p-> p.getPermissionDocument() == null && p.getPermissionKey().equals(permissionWithWildcard))
                            .findFirst().orElse(null);

                    if(permission !=null){
                        result.add(permission);
                    }
                }
            }
        } catch (Exception e) {
            log.error("Failed to get all api permissions", e);
        }
        return result;
    }

    /**
     * 根据资源类型和权限列表获取所有权限，如果没有权限则抛出异常
     * @param patterns e.g "primary-profile" , "general-profile"
     * @param resource e.g "c_car"
     * @param suitableApiPermissions
     * @param rolePermissions
     */
    protected Set<RolePermission> evaluatePermissionByResource(List<String> patterns, String resource, List<ApiPermissionsUtil.ApiPermission> suitableApiPermissions, List<RolePermission> rolePermissions) {
        Set<String> matchingPermissions = new HashSet<String>();
        Set<String> apiPermissionSet = suitableApiPermissions.stream().map(it->it.getPermissionKey()).collect(Collectors.toSet());
        Set<String> rolePermissionSet = rolePermissions.stream().map(it->it.getPermission()).collect(Collectors.toSet());
        matchingPermissions.addAll(apiPermissionSet);
        matchingPermissions.retainAll(rolePermissionSet);
        if(matchingPermissions.isEmpty()){
            return new HashSet<>();
        }else{
            log.info("user has permission to access to " + Arrays.toString(patterns.toArray()) + ": " + resource + ", permissions: " + matchingPermissions.stream().map(it->it).collect(Collectors.joining(",")));
            return rolePermissions.stream().filter(it->matchingPermissions.contains(it.getPermission())).collect(Collectors.toSet());
        }
    }
}
