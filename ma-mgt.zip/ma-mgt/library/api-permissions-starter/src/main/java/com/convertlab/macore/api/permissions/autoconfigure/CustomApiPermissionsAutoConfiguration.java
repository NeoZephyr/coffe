package com.convertlab.macore.api.permissions.autoconfigure;

import com.convertlab.foundation.library.business.feature.FeatureClient;
import com.convertlab.foundation.library.webmvc.access.PermissionValidator;
import com.convertlab.macore.api.permissions.advice.RequireAdminPermissionAdvice;
import com.convertlab.macore.api.permissions.mapper.RolePermissionMapper;
import com.convertlab.macore.api.permissions.mapper.UserRoleMapper;
import com.convertlab.macore.api.permissions.validators.AbstractApiPermissionValidator;
import org.springframework.aop.Advisor;
import org.springframework.aop.aspectj.AspectJExpressionPointcut;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

import javax.annotation.Nonnull;
import javax.validation.constraints.NotNull;
import java.util.Map;

@Configuration
@ComponentScan("com.convertlab.macore.api.permissions.validators")
public class CustomApiPermissionsAutoConfiguration {
    @Autowired
    ApplicationContext context;

    @ConditionalOnBean(PermissionValidator.class)
    @Bean
    @ConditionalOnMissingBean(name = "requireAdminPermissionAdvice")
    Advisor cdpApiRouteAspect(@Nonnull PermissionValidator permissionValidator) {
        RequireAdminPermissionAdvice advice = new RequireAdminPermissionAdvice(permissionValidator);
        AspectJExpressionPointcut pointcut = new AspectJExpressionPointcut();
        String expression = "execution(public * com.convertlab..controller..*(..)) && @annotation(com.convertlab.macore.api.permissions.annotation.RequireAdminPermission)";
        pointcut.setExpression(expression);

        return new DefaultPointcutAdvisor(pointcut, advice);
    }

    @Bean("apiPermissionValidatorChain")
    @Lazy(true)
    AbstractApiPermissionValidator apiPermissionValidatorChain(){
        AbstractApiPermissionValidator startValidator = null;
        Map<String, AbstractApiPermissionValidator> validators = context.getBeansOfType(AbstractApiPermissionValidator.class);
        if(validators != null && validators.size() > 0) {
            for(int i=0; i< validators.values().size(); i++) {
                AbstractApiPermissionValidator currentValidator = (AbstractApiPermissionValidator) validators.values().toArray()[i];
                if(i ==0){
                    startValidator = currentValidator;
                }
                if(i < (validators.values().size() -1)){
                    currentValidator.setNextValidator((AbstractApiPermissionValidator) validators.values().toArray()[i+1]);
                }
            }
        }
        return startValidator;
    }
}
