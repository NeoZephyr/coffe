package com.convertlab.macore.api.permissions.autoconfigure;

import com.convertlab.foundation.library.jdbc.datasource.lookup.DataSourceLookupHelper;
import com.convertlab.foundation.library.principal.context.PrincipalContextHolder;
import com.convertlab.foundation.library.webmvc.access.PermissionValidator;
import com.convertlab.macore.api.permissions.advice.RequireAdminPermissionAdvice;
import com.convertlab.macore.api.permissions.mapper.RolePermissionMapper;
import com.convertlab.macore.api.permissions.mapper.UserRoleMapper;
import com.convertlab.macore.api.permissions.model.RolePermission;
import com.convertlab.macore.api.permissions.validators.AbstractApiPermissionValidator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.aop.Advisor;
import org.springframework.aop.aspectj.AspectJExpressionPointcut;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
public class BffSecurityConfig implements PermissionValidator {
    private UserRoleMapper userRoleMapper;
    private RolePermissionMapper rolePermissionMapper;
    private AbstractApiPermissionValidator validatorChain;

    @Autowired
    ApplicationContext context;

    public BffSecurityConfig(){
        super();
    }


    @Override
    public boolean validate(@Nullable String resource, @Nullable String[] roles, @Nullable String[] permissions) {
        final Long userId = PrincipalContextHolder.getUserId();
        if(userId == null) {
            return false;
        }

        if(userRoleMapper == null){
            userRoleMapper = context.getBean(UserRoleMapper.class);
            if(userRoleMapper == null){
                throw new RuntimeException("Failed to initial BffSercurityConfig due to userRoleMapper is null");
            }
        }

        if(rolePermissionMapper == null){
            rolePermissionMapper = context.getBean(RolePermissionMapper.class);
            if(rolePermissionMapper == null){
                throw new RuntimeException("Failed to initial BffSercurityConfig due to rolePermissionMapper is null");
            }
        }

        if(validatorChain == null){
            validatorChain = context.getBean("apiPermissionValidatorChain", AbstractApiPermissionValidator.class);
            if(validatorChain == null){
                throw new RuntimeException("Failed to initial BffSercurityConfig due to validatorChain is null");
            }
        }

        // 以下逻辑来自app微服务的 PermissionService.hasPermission
        List<String> adminRoles = DataSourceLookupHelper.withLookupKey("main",() -> userRoleMapper.getAdminRoleKeyByUserId(userId));
        if(adminRoles != null && adminRoles.size() > 0) {
            return true;
        }
        List<String> adminGroups = DataSourceLookupHelper.withLookupKey("main",() -> userRoleMapper.getAdminRoleKeyByUserIdWithGroup(userId));
        if(adminGroups != null && adminGroups.size() > 0) {
            return true;
        }

        // 当permissions为空时，可能是RequireAdminPermissionAdvice，此时仅需要校验当前用户是否为admin
        if(permissions == null){
            return false;
        }

        // 查询当前用户角色的功能权限
        List<RolePermission> rolePermissions = DataSourceLookupHelper.withLookupKey("main",() -> userRoleMapper.getRolePermissionByUserId(userId));
        // 查询当前用户所在用户组的功能权限
        List<RolePermission> userGroupPermissions = DataSourceLookupHelper.withLookupKey("main",() -> rolePermissionMapper.getUserGroupPermission(userId));
        rolePermissions.addAll(userGroupPermissions);

        // 调用validators/*Validator 对api权限和rolePermission进行匹配
        Set<RolePermission> matchedPermission = validatorChain.checkPermissions(resource, permissions, rolePermissions);
        if(matchedPermission != null && matchedPermission.size() == 0){
            log.warn("No Api permission matched");
            return false;
        }else{
            log.info("Api permission matched: {}", matchedPermission.stream().map(it -> it.getPermission()).collect(Collectors.toSet()).toString());
            return true;
        }
    }


    public void setUserRoleMapper(UserRoleMapper userRoleMapper) {
        this.userRoleMapper = userRoleMapper;
    }

    public void setRolePermissionMapper(RolePermissionMapper rolePermissionMapper) {
        this.rolePermissionMapper = rolePermissionMapper;
    }

    public void setValidatorChain(AbstractApiPermissionValidator validatorChain) {
        this.validatorChain = validatorChain;
    }
}
