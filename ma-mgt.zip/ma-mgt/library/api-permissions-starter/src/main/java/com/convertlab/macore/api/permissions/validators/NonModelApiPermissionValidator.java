package com.convertlab.macore.api.permissions.validators;

import com.convertlab.macore.api.permissions.common.ApiPermissionsUtil;
import com.convertlab.macore.api.permissions.model.RolePermission;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 不涉及档案或者Ad-Hoc的接口，原封不动的比较api的permission和rolePermission
 */
@Component
@Slf4j
public class NonModelApiPermissionValidator extends AbstractApiPermissionValidator{

    @Override
    protected Set<RolePermission> validateUserPermissionToRequest(String resource, String[] apiPermission, List rolePermissions) {
        if(StringUtils.isEmpty(resource)){
            log.info("start validating non-model api permission");
            List<ApiPermissionsUtil.ApiPermission> suitableApiPermissions = this.getSuitableApiPermissionsByResource(null, null, apiPermission);
            Set<RolePermission> result = evaluatePermissionByResource(Collections.emptyList(), null, suitableApiPermissions, rolePermissions);
            log.info("end validating non-model api permission");
            return result;
        }
        return new HashSet<>();
    }
}
