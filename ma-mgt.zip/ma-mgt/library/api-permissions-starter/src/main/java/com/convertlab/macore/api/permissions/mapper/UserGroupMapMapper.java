package com.convertlab.macore.api.permissions.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.api.permissions.model.UserGroupMap;
import com.convertlab.macore.api.permissions.model.UserGroupRole;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserGroupMapMapper  extends BaseMapper<UserGroupMap> {
    @Select({"<script>",
            "select ugr.* from user_group_role ugr join user_group_map ugm on ugm.group_code = ugr.group_code where " +
                    " ugm.user_id = #{userId}",
            "</script>"})
    @ResultType(UserGroupRole.class)
    List<UserGroupRole> getUserGroupRole(Long userId);
}

