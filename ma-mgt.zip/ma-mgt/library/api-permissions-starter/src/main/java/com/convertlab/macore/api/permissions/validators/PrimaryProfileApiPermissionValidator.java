package com.convertlab.macore.api.permissions.validators;

import com.convertlab.foundation.api.gdm.pattern.GdmModelClient;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto;
import com.convertlab.macore.api.permissions.common.ApiPermissionsUtil;
import com.convertlab.macore.api.permissions.model.RolePermission;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


/**
 * 主档案接口权限校验器
 */
@Component
@AllArgsConstructor
@Slf4j
public class PrimaryProfileApiPermissionValidator extends AbstractApiPermissionValidator{
    private final GdmModelClient profileAssociationClient;
    private static final String PATTERN_PRIMARY_PROFILE = "primary-profile";
    @Override
    protected Set<RolePermission> validateUserPermissionToRequest(String resource, String[] apiPermission, List<RolePermission> rolePermissions) {
        if(StringUtils.isNotBlank(resource)){
            GdmModelDto modeDef = profileAssociationClient.findByName(resource.toLowerCase());
            if(modeDef!=null && modeDef.hasPattern(GdmPatternDto.PATTERN_PRIMARY_PROFILE)){
                log.info("start validating primary-profile api permission");
                List<ApiPermissionsUtil.ApiPermission> suitableApiPermissions = this.getSuitableApiPermissionsByResource("customer", resource, apiPermission);
                Set<RolePermission> result = evaluatePermissionByResource(Arrays.asList(modeDef.getPatterns()), resource, suitableApiPermissions, rolePermissions);
                log.info("end validating primary-profile api permission");
                return result;
            }
        }
        return new HashSet<>();
    }
}
