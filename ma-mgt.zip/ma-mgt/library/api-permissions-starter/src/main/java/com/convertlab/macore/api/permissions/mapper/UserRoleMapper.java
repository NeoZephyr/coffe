package com.convertlab.macore.api.permissions.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.api.permissions.model.RolePermission;
import com.convertlab.macore.api.permissions.model.UserRole;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserRoleMapper extends BaseMapper<UserRole> {

    @Select({"<script>",
            "SELECT rp.* from user_role ur inner join role_permission rp on rp.role_key = ur.role_key " +
                    "where ur.user_id = #{userId}",
            "</script>"})
    @ResultType(RolePermission.class)
    List<RolePermission> getRolePermissionByUserId(Long userId);

    @Select({"<script>" +
            "select role_key from user_role where user_id = #{userId} and (role_key = 'admin' || role_key = 'tenantAdmin')",
            "</script>"})
    List<String> getAdminRoleKeyByUserId(@Param("userId") Long userId);

    @Select({"<script>" +
            "select role_key from user_role where user_id = #{userId}",
            "</script>"})
    List<String> getRoleKeysByUserId(@Param("userId") Long userId);

    @Select({"<script>" +
            "select ur.role_key from user_role ur inner join role r on ur.role_key = r.role_key where ur.user_id = #{userId}",
            "</script>"})
    List<String> getExistRoleKeysByUserId(@Param("userId") Long userId);

    @Select({"<script>" +
            "select ugr.role_key from user_group_map ugm join user_group_role ugr " +
            "on ugm.group_code = ugr.group_code where " +
            "ugm.user_id = #{userId}  and (role_key = 'admin' || role_key = 'tenantAdmin')",
            "</script>"})
    List<String> getAdminRoleKeyByUserIdWithGroup(@Param("userId") Long userId);
}
