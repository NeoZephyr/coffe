package com.convertlab.macore.api.permissions.common;

import com.convertlab.api.permission.ApiPermissionLoader;
import com.convertlab.foundation.library.utils.JsonUtils;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.util.*;

public class ApiPermissionsUtil {
    private static String DOT_SEP = ".";
    private static String DOCUMENT_SEP ="/";

    // UDO数据的操作类型
    private static String [] udoDataOperations = new String[]{"create", "delete", "export", "import", "read", "write"};
    // UDO群组的操作类型
    private static String [] udoSegmentOperations = new String[]{"create", "delete", "read", "share", "write"};
    // UDO标签的操作类型
    private static String [] udoTraitOperations = new String[]{"create", "delete", "read", "share", "write"};

    // 因历史原因，这些路径不出现在permissionKey中
    private static Map EXCLUDE_PATH_IN_PERMISSION_KEY = new HashMap(){{
        put(".customer", "");
        put("dataMonitor", "");
        put("settingCenter.source", "source");
        put("settingCenter.property", "property");
        put("settingCenter.event", "event");
        put("settingCenter.order", "order");
        put("settingCenter.identity", "identity");
        put("settingCenter.contentTag", "contentTag");
        put("settingCenter.tag", "tag");
        put("settingCenter.customerLayer", "customerLayer");
        put("settingCenter.score", "score");
        put("settingCenter.measure", "measure");
        put("settingCenter.integration", "integration");
        put("settingCenter.webhook", "webhook");
        put("settingCenter.stage", "stage");
        put("customerLayer.lifecycle", "lifecycle");
        put("customerLayer.stage", "stage");
        put("marketingApp.socialSharing", "socialSharing");
    }};

    /**
     * 功能权限的格式，符合如下范式：
     *  {
     *      permissionKey: ${resource}.${method},
     *      permissionDocument: ${document}
     *  }
     *  其中permissionKey是原有功能权限树中的权限路径，跟api_permission.json 中的permissionKey 保持一致；描述的是对某个资源的CRUD，导出权限。
     *  permissionDocument 是当前功能权限作用的资源变量，可以是档案，udo或者
     *  创建客户 customer.create -> {permissionKey: '*.create', permissionDocument: 'customer'}
     *  批量操作 导出客户数据 customerOperation.export -> {permissionKey: 'customerOperation.export', permissionDocument: 'customer'}
     *  首页查看 homepage.read -> {permissionKey: 'homepage.read', permissionDocument: null}
     *  创建群组 list.create -> {permissionKey: 'customerOperation.export', permissionDocument: 'customer'}
     *  c_buyer群组权限共享 udoData.c_buyer.group.share -> {permissionKey: 'udoData.*.group.share', permissionDocument: 'c_buyer'}
     */
    @Data
    @AllArgsConstructor
    public static class ApiPermission {
        private String permissionKey;
        private String permissionDocument;
        @Override
        public String toString(){
            return  permissionDocument + DOCUMENT_SEP + permissionKey;
        }
    }

    /**
     * 遍历功能权限树，按
     * @return
     * @throws IOException
     */
    public static List<ApiPermission> getApiPermissions() throws IOException {
        List<ApiPermission> result = new ArrayList<>();
        List sections = JsonUtils.instance().json2Obj(ApiPermissionLoader.load(), List.class);
        sections.forEach(section -> {
            Map<String, Object> sectionMap = (Map<String, Object>) section;

            String sectionId = mapToLegacyPermissionKey(sectionMap.containsKey("id") ? (String) sectionMap.get("id") : null);
            String permissionResource = sectionMap.containsKey("resource") ?  (String) sectionMap.get("resource") : null;
            ApiPermission rootLevelPermission = new ApiPermission(sectionId, permissionResource);
            List<Map<String, Object>> children = sectionMap.containsKey("children") ?
                    (List<Map<String, Object>>) sectionMap.get("children") : Collections.emptyList();
            children.forEach(child -> {
                result.addAll(traverse(rootLevelPermission, child));
            });
        });
        result.addAll(composeWildcardUdoPermission());
        return result;
    }

    private static String mapToLegacyPermissionKey(String permissionKey){
        if(permissionKey == null){
            return null;
        }
        if(EXCLUDE_PATH_IN_PERMISSION_KEY.containsKey(permissionKey)){
            return EXCLUDE_PATH_IN_PERMISSION_KEY.get(permissionKey).toString();
        }else{
            return permissionKey;
        }
    }

    private static List<ApiPermission> traverse(ApiPermission ancestor, Map<String, Object> section) {
        String sectionId = "";
        if(section.containsKey("id")){
            if(StringUtils.isNotBlank(ancestor.getPermissionKey())) {
                if(StringUtils.isNotBlank(mapToLegacyPermissionKey((String) section.get("id")))){
                    sectionId = DOT_SEP + mapToLegacyPermissionKey((String) section.get("id"));
                }else{
                    sectionId = "";
                }
            }else{
                sectionId = mapToLegacyPermissionKey((String) section.get("id"));
            }
        }

        String permissionResource = (ancestor.getPermissionDocument() != null) ? ancestor.getPermissionDocument() :
                (section.containsKey("resource") ?  (String) section.get("resource") : null);
        final List<ApiPermission> result = new ArrayList<>();
        if(section.containsKey("children") && ((List)section.get("children")).size() > 0){
            for(Object child : (List)section.get("children")){
                String permissionKey = mapToLegacyPermissionKey((ancestor.getPermissionKey() !=null) ? (ancestor.getPermissionKey() + sectionId) : sectionId);
                result.addAll(traverse(new ApiPermission(permissionKey, permissionResource), (Map<String, Object>) child));
            }
            return result;
        }else{
            String permissionKey = mapToLegacyPermissionKey(ancestor.getPermissionKey() + sectionId);
            result.add(new ApiPermission(permissionKey, permissionResource));
        }
        return result;
    }

    /**
     * 生产通用UDO数据接口权限，包括UDO数据权限，UDO群组数据权限，UDO标签数据权限
     * 逻辑来自 1. app服务的PermissionService.composeUdoPermission
     *        2. dmhub-ui/apps/main/src/setting/permission/route.tsx loadPermissionTree
     *        Till DM2.10 UDO只有数据权限，以及群组的权限
     *
     * @return
     */
    private static List<ApiPermission> composeWildcardUdoPermission() {
        List<ApiPermission> result = new ArrayList<>();
        for(String operation : udoDataOperations){
            result.add(new ApiPermission("udoData.*." + operation, "udo"));
        }
        for(String operation : udoSegmentOperations){
            result.add(new ApiPermission("udoData.*.group." + operation, "udo"));
        }
        for(String operation : udoTraitOperations){
            result.add(new ApiPermission("udoData.*.trait." + operation, "udo"));
        }
        return result;
    }
}
