package com.convertlab.macore.api.permissions.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

@Data
@EqualsAndHashCode(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TableName(value = "role_permission",excludeProperty = {"version","creatorId", "creatorName", "updaterId", "updaterName"})
public class RolePermission {
    private static final long serialVersionUID = 1L;
    /**
     * 主键id
     */
    @TableId(value = "id")
    private Long id;

    @TableField("role_key")
    String roleKey;

    @TableField("permission")
    String permission;

    @TableField("black_white_list_id")
    Long blackWhiteListId;
}
