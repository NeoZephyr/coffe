package com.convertlab.macore.api.permissions;

import com.convertlab.foundation.api.gdm.pattern.GdmModelClient;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.principal.context.PrincipalContextHolder;
import com.convertlab.macore.api.permissions.autoconfigure.BffSecurityConfig;
import com.convertlab.macore.api.permissions.mapper.RolePermissionMapper;
import com.convertlab.macore.api.permissions.mapper.UserRoleMapper;
import com.convertlab.macore.api.permissions.model.RolePermission;
import com.convertlab.macore.api.permissions.validators.AbstractApiPermissionValidator;
import com.convertlab.macore.api.permissions.validators.GeneralProfileAndAdHocApiPermissionValidator;
import com.convertlab.macore.api.permissions.validators.PrimaryProfileApiPermissionValidator;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@Slf4j
class BffSercurityConfigTest {

    private BffSecurityConfig bffSercurityConfigUnderTest;
    static MockedStatic<PrincipalContextHolder> mockPrincipalContextHolder;

    @Mock(lenient = true)
    private UserRoleMapper mockUserRoleMapper;
    @Mock(lenient = true)
    private RolePermissionMapper mockRolePermissionMapper;
    @Mock
    private GdmModelClient mockGdmModelClient;


    @BeforeAll
    static void beforeAll() {
        mockPrincipalContextHolder = Mockito.mockStatic(PrincipalContextHolder.class);
        // 同步前后两次调用，模拟两个有不用权限的用户id
        mockPrincipalContextHolder.when(()-> PrincipalContextHolder.getUserId())
                .thenReturn(1L);
        log.info("beforeAll, mock PrincipalContextHolder");
    }

    @AfterAll
    static void afterAll() {
        mockPrincipalContextHolder.close();
        log.info("afterAll, mockPrincipalContextHolder.isClosed: {}", mockPrincipalContextHolder.isClosed());
    }

    @BeforeEach
    void setUp() {
        bffSercurityConfigUnderTest = new BffSecurityConfig();
        bffSercurityConfigUnderTest.setUserRoleMapper(mockUserRoleMapper);
        bffSercurityConfigUnderTest.setRolePermissionMapper(mockRolePermissionMapper);

        AbstractApiPermissionValidator validatorChain = new PrimaryProfileApiPermissionValidator(mockGdmModelClient);
        validatorChain.setNextValidator(new GeneralProfileAndAdHocApiPermissionValidator(mockGdmModelClient));
        bffSercurityConfigUnderTest.setValidatorChain(validatorChain);
    }

    @Test
    void testValidateWithAdmin() {
        try(TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(1L, "客户A")) {
            when(mockUserRoleMapper.getAdminRoleKeyByUserId(eq(1L))).thenReturn(Arrays.asList("admin"));
            boolean result = bffSercurityConfigUnderTest.validate("customer", new String[]{""},
                    new String[]{"customer.read"});
            Assertions.assertTrue(result);
        }
    }

    @Test
    void testValidateWithUserPermission() {
        try(TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(1L, "客户A")) {
            // Setup
            Mockito.lenient().when(mockGdmModelClient.findByName(any())).thenAnswer(arg -> {
                String profileName = arg.getArgument(0).toString();
                if(profileName.equals("customer")) {
                    return getGdmModelDto("customer", "primary-profile");
                }else {
                    return getGdmModelDto("c_car", "general-profile");
                }
            });

            //  非管理员用户
            when(mockUserRoleMapper.getAdminRoleKeyByUserId(eq(1L))).thenReturn(Collections.emptyList());
            when(mockUserRoleMapper.getAdminRoleKeyByUserIdWithGroup(eq(1L))).thenReturn(Collections.emptyList());

            RolePermission customerReadPermission = new RolePermission(1L, "9c210475b1704fd7bb204d6c2b127f47", "customer.read", 1L);
            RolePermission udoDataReadPermission = new RolePermission(2L, "9c210475b1704fd7bb204d6c2b127f48", "udoData.c_car.read", 1L);
            when(mockUserRoleMapper.getRolePermissionByUserId(eq(1L))).thenReturn(Arrays.asList(customerReadPermission, udoDataReadPermission));

            boolean result = bffSercurityConfigUnderTest.validate("customer", new String[]{""},
                    new String[]{"customer.read"});
            Assertions.assertTrue(result);

            boolean result2 = bffSercurityConfigUnderTest.validate("c_car", new String[]{""},
                    new String[]{"udoData.{proflieName}.read"});
            Assertions.assertTrue(result2);
        }
    }


    protected GdmModelDto getGdmModelDto(String profileName, String pattern) {
        GdmModelDto meta = new GdmModelDto();
        meta.setName(profileName);
        meta.setPatterns(new String[]{pattern});
        List<GdmPatternDto.Feature> features = new ArrayList<>();
        features.add(GdmPatternDto.Feature.StaticTraits);
        features.add(GdmPatternDto.Feature.DynamicTraits);
        features.add(GdmPatternDto.Feature.StaticSegment);
        features.add(GdmPatternDto.Feature.DynamicSegment);
        features.add(GdmPatternDto.Feature.OneId);
        features.add(GdmPatternDto.Feature.Order);
        features.add(GdmPatternDto.Feature.Event);
        features.add(GdmPatternDto.Feature.Indicator);
        features.add(GdmPatternDto.Feature.Cdc);
        features.add(GdmPatternDto.Feature.DataPermission);
        meta.setFeatures(features);
        GdmPatternDto.ProvisionProperties provisionProperties = new GdmPatternDto.ProvisionProperties();
        GdmPatternDto.ProfileEvent[] events = new GdmPatternDto.ProfileEvent[]{new GdmPatternDto.ProfileEvent("subscribe", "subscribe", false)};
        provisionProperties.setEvents(events);
        provisionProperties.setIdentityEntityName("identity");
        meta.setProps(provisionProperties);

        return meta;
    }
}
