package com.convertlab.macore.api.permissions;

import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.api.permissions.common.ApiPermissionsUtil;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ApiPermissionsUtilTest {

    @Test
    void testGetApiPermissions() throws Exception {
        // 样板数据来自： select distinct permission from role_permission where permission not like 'equity.%' and permission not like 'luckyDraw.%' and permission not like 'marketingApp.%' and permission not like 'udoData.%';
        Set samplePermissionKeySet = JsonUtils.loadJsonAs("/api_permissions_sample.json", HashSet.class);
        // Run the test
        final List<ApiPermissionsUtil.ApiPermission> result = ApiPermissionsUtil.getApiPermissions();

        //检查所有的role_permission 都包含在对permission树的解析结果中了
        Set<String> permissions = result.stream().map(ApiPermissionsUtil.ApiPermission::getPermissionKey).collect(Collectors.toSet());
        samplePermissionKeySet.removeAll(permissions);
        assertEquals(0, samplePermissionKeySet.size());
    }
}
