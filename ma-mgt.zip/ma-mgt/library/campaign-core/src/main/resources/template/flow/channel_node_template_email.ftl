{
  "nextSteps": [
    {
      "nextStep": "14"
    }
  ],
  "stepType": "action",
  "isTemplate": false,
  "subject": {
    "type": "customer"
  },
  "name": "邮件",
  "action": {
    "actionType": "me_action",
    "actionBody": {
      "payload": {
        "campaignUuid": "AMBQZ",
        "channelPluginInstanceInfo": {
          "accountInfo": {
            "channelTunnelInfo": {
              "tunnelId": "216583578555777536",
              "additional": {
                "quotaPoolId": "231797289021080577"
              }
            }
          },
          "messagingType": "email-sending_email",
          "pluginVersionId": "1636309033539133441",
          "channelType": "email"
        },
        "meta": {
          "text": "[{\"type\":\"text\",\"content\":\"元旦活动\"},{\"type\":\"text\",\"content\":\"<table role=\\\"presentation\\\" aria-hidden=\\\"true\\\" cellspacing=\\\"0\\\" cellpadding=\\\"0\\\" border=\\\"0\\\" align=\\\"center\\\" width=\\\"100%\\\" bgcolor=\\\"#ffffff\\\" style=\\\"background-color: rgb(255, 255, 255); width: 100%; border-width: 0px;\\\"><tbody><td align=\\\"center\\\" valign=\\\"top\\\" width=\\\"100%\\\" style=\\\"font-family: SimSun, 宋体, sans-serif; width: 100%; vertical-align: top;\\\"><span><table role=\\\"presentation\\\" aria-hidden=\\\"true\\\" cellspacing=\\\"0\\\" cellpadding=\\\"0\\\" border=\\\"0\\\" width=\\\"600\\\" bgcolor=\\\"#fff\\\" style=\\\"width: 600px; background-color: rgb(255, 255, 255); border-width: 0px;\\\"><tbody><tr><td bgcolor=\\\"#fff\\\" valign=\\\"top\\\" width=\\\"100%\\\" style=\\\"width: 100%; background-color: rgb(255, 255, 255); vertical-align: top; border: 0px solid rgb(255, 255, 255); padding: 0px;\\\"><table role=\\\"presentation\\\" aria-hidden=\\\"true\\\" cellspacing=\\\"0\\\" cellpadding=\\\"0\\\" border=\\\"0\\\" width=\\\"100%\\\" style=\\\"width: 100%; max-width: 100%; border-width: 0px;\\\"><tbody><tr><td align=\\\"center\\\" valign=\\\"top\\\" style=\\\"padding: 5px; vertical-align: top;\\\"><table role=\\\"presentation\\\" aria-hidden=\\\"true\\\" cellspacing=\\\"0\\\" cellpadding=\\\"0\\\" border=\\\"0\\\" width=\\\"600\\\" style=\\\"width: 600px; border-width: 0px;\\\"><tbody><tr><td align=\\\"center\\\" height=\\\"388\\\" valign=\\\"top\\\" style=\\\"height: 388px; vertical-align: top;\\\"><div><a style=\\\"display: inline-block;\\\" undefined=\\\"\\\">\\n              <img src=\\\"https://cdn.dmhub.cn/md/resource/get/e20cbc1ab4f14de489a21f68ab8b36e2\\\" alt=\\\"undefined\\\" aria-hidden=\\\"true\\\" width=\\\"600\\\" height=\\\"388\\\" style=\\\"vertical-align: top;\\\">\\n            <\/a><\/div><\/td><\/tr><\/tbody><\/table><\/td><\/tr><\/tbody><\/table><\/td><\/tr><\/tbody><\/table><\/span><\/td><\/tbody><\/table>\"}]",
          "extendText": "{\"links\":[],\"editorType\":\"module\"}"
        },
        "templateInfo": {
          "templateId": "1672547872404670464"
        },
        "tunnelId": "216583578555777536",
        "additionalInfo": {},
        "predicateInfo": {
          "pipl": [],
          "isMock": false,
          "skipDnd": false
        },
        "channelVersion": "20231116.1",
        "templateId": "1672547872404670464",
        "folderId": "",
        "audienceInfo": {
          "profileName": "customer",
          "sendIdentity": "customer",
          "objId": "customer",
          "audienceIdType": "email"
        },
        "vendorCode": "sendcloud-email"
      },
      "channelVersion": "20231116.1"
    }
  },
  "id": "13",
  "nodeType": "plugin_channel_system_email-sending_email",
  "config": {
    "identity": "attr"
  },
  "errors": {}
}