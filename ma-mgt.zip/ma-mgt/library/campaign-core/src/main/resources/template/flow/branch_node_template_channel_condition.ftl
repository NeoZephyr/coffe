{
  "nextSteps": [{
    "criteria": {
      "udo": {
        "objId": "customer"
      },
      "filters": ${branch.filters},
      "type": "complex"
    },
    "nextStep": "${branch.leftActionId}",
    "label": "是"
  },
    {
      "isDefault": true,
      "nextStep": "${branch.rightActionId}",
      "label": "否"
    }
  ],
  "stepType": "branch",
  "isTemplate": false,
  "subject": {
    "type": "customer"
  },
  "name": "属性判断",
  "description": "客户属性判断",
  "id": "${branch.nodeId}",
  "nodeType": "conditionNode",
  "config": {
    "identity": "attr"
  },
  "errors": {}
}