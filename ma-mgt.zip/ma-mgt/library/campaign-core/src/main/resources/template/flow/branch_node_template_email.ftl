{
  "nextSteps": [{
    "criteria": {
      "udo": {
        "objId": "customer"
      },
      "id": 0,
      "filters": {
        "logicalDisabled": false,
        "logicalOperator": "and",
        "subFilters": [{
          "logicalDisabled": false,
          "logicalOperator": "and",
          "conditions": [{
            "parameter": {
              "compareType": "value",
              "operator": "not_empty"
            },
            "property": "email",
            "property_type": "String",
            "description": {
              "property": "邮箱",
              "constraint": {
                "descStr": "",
                "descArr": []
              },
              "value": "不为空"
            },
            "constraint": {},
            "category": "customer",
            "to_string": "邮箱 → 不为空"
          }]
        }],
        "version": 2
      },
      "type": "complex"
    },
    "nextStep": "${branch.leftActionId}",
    "label": "是"
  },
    {
      "isDefault": true,
      "nextStep": "${branch.rightActionId}",
      "label": "否"
    }
  ],
  "stepType": "branch",
  "isTemplate": false,
  "subject": {
    "type": "customer"
  },
  "name": "属性判断",
  "description": "客户属性判断(邮箱 → 不为空)",
  "id": "${branch.nodeId}",
  "nodeType": "conditionNode",
  "config": {
    "identity": "attr"
  },
  "errors": {}
}