"filters": {
"logicalOperator": "and",
"subFilters": [{
"logicalOperator": "and",
"conditions": [{
"dateOperator": "any_time",
"parameter": {
"differentList": true,
"value2": "${flow.list}",
"operator": "in"
},
"property": "in",
"constraint": {},
"category": "list"
}]
}],
"version": 2
},
"type": "complex"