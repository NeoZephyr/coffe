{
"nextSteps": [
{
"nextStep": "12"
}
],
"stepType": "action",
"isTemplate": false,
"subject": {
"type": "customer"
},
"name": "短信",
"action": {
"actionType": "me_action",
"actionBody": {
"payload": {
"campaignUuid": "AMBQZ",
"channelPluginInstanceInfo": {
"accountInfo": {
"channelTunnelInfo": {
"tunnelId": "241750802715115520",
"additional": {
"quotaPoolId": "1593491202077102080"
}
}
},
"messagingType": "sms-sending_sms",
"pluginVersionId": "1595362469165973505",
"channelType": "sms"
},
"meta": {
"text": "[{\"type\":\"text\",\"content\":\"123123123123v 回TD退订\"}]",
"extendText": "{\"links\":[],\"linkAutoFill\":true}"
},
"templateInfo": {
"templateId": "1720327848910389248"
},
"tunnelId": "241750802715115520",
"additionalInfo": {},
"predicateInfo": {
"pipl": [],
"isMock": false,
"skipDnd": false
},
"channelVersion": "20231116.1",
"templateId": "1720327848910389248",
"folderId": "",
"audienceInfo": {
"profileName": "customer",
"sendIdentity": "customer",
"objId": "customer",
"audienceIdType": "mobile"
},
"vendorCode": "montnets-sms"
},
"channelVersion": "20231116.1"
}
},
"id": "11",
"nodeType": "plugin_channel_system_sms-sending_sms",
"config": {
"identity": "attr"
},
"errors": {}
}