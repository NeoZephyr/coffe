{
  "nextSteps": [
    {
      "nextStep": "${channel.endNodeId}"
    }
  ],
  "stepType": "action",
  "isTemplate": false,
  "subject": {
    "type": "customer"
  },
  "name": "${channel.messagingType}",
  "action": {
    "actionType": "me_action",
    "actionBody": ${channel.actionBody}
  },
  "id": "${channel.nodeId}",
  "nodeType": "${channel.nodeType}",
  "config": {
    "identity": "attr"
  },
  "errors": {}
}