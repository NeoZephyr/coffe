{
  "nextSteps": [{
    "criteria": {
      "udo": {
        "objId": "customer"
      },
      "filters": {
        "logicalDisabled": false,
        "logicalOperator": "and",
        "subFilters": [{
          "logicalDisabled": false,
          "logicalOperator": "and",
          "conditions": [{
            "parameter": {
              "parameter": {},
              "value": ${branch.wechatAccountId?c},
              "operator": "equal"
            },
            "property": "equal",
            "constraint": {
              "subscribe": true
            },
            "category": "channel.wechat",
            "to_string": "当前关注"
          }]
        }],
        "version": 2
      },
      "type": "complex"
    },
    "nextStep": "${branch.leftActionId}",
    "label": "是"
  },
    {
      "isDefault": true,
      "nextStep": "${branch.rightActionId}",
      "label": "否"
    }
  ],
  "stepType": "branch",
  "isTemplate": false,
  "subject": {
    "type": "customer"
  },
  "name": "属性判断",
  "description": "客户属性判断(当前关注公众号)",
  "id": "${branch.nodeId}",
  "nodeType": "conditionNode",
  "config": {
    "identity": "attr"
  },
  "errors": {}
}