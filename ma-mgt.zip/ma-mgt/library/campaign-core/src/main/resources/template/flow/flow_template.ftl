{
  "featureLevel": "Scala",
  "type": "campaignV4",
  "testStatus": "untested",
  "editorVersion": "2.0",
  "scheduledStop": false,
  "status": "draft",
  "killOnScheduleStop": false,
  "triggerType": "${flow.triggerType}",
  "name": "${flow.name}",
  "definition": {
    "globalSetting": {},
    "triggerType": "${flow.triggerType}",
    "startStep": "100",
    "startCriteria": {
      "udo": {
        "objId": "customer"
      },
      "isTemplate": false,
      "id": 0,
      ${flow.startFilters}
    },
    "subjectType": "customer",
    "steps": [
      {
        "nextSteps": [
          {
            "nextStep": "100"
          }
        ],
        "stepType": "delay",
        "name": "开始",
        "id": "1",
        "stepTimeout": 1,
        "nodeType": "start",
        "errors": {}
      }
      ${flow.channelNodes}
    ],
    "setting": {
      ${flow.strategy}
      "includeHistoricalMembers": true,
      "startOnJoinList": false,
      "useFlowstatServiceV2": true,
      "filterByPriorityGroup": "",
      "listThrottle": 400,
      "nonRestartableFromDb": true,
      "Restartable": ${flow.restartable}
    }
  }
}