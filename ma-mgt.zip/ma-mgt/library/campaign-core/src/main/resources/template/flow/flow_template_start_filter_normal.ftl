"filters": {
  "logicalOperator": "and",
  "subFilters": [],
  "watchList": "${flow.list}",
  "version": 2,
  "listType": "static"
}