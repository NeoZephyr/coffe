{
  "nextSteps": [{
    "criteria": {
      "udo": {
        "objId": "customer"
      },
      "filters": {
        "logicalDisabled": false,
        "logicalOperator": "and",
        "subFilters": [{
          "logicalDisabled": false,
          "logicalOperator": "and",
          "conditions": [{
            "parameter": {
              "parameter": {},
              "value": "${branch.appId}",
              "operator": "equal"
            },
            "property": "appKey",
            "description": {
                  "property": "推送应用",
                  "constraint": {
                  "descStr": "",
                  "descArr": []
              },
              "value": "jpush"
            },
            "constraint": {},
            "category": "app.push",
            "to_string": "推送应用 → jpush"
          }]
        }],
        "version": 2
      },
      "type": "complex"
    },
    "nextStep": "${branch.leftActionId}",
    "label": "是"
  },
    {
      "isDefault": true,
      "nextStep": "${branch.rightActionId}",
      "label": "否"
    }
  ],
  "stepType": "branch",
  "isTemplate": false,
  "subject": {
    "type": "customer"
  },
  "name": "属性判断",
  "description": "客户属性判断(推送应用 → jpush)",
  "id": "${branch.nodeId}",
  "nodeType": "conditionNode",
  "config": {
    "identity": "attr"
  },
  "errors": {}
}