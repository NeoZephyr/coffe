{
  "featureLevel": "Scala",
  "type": "standard",
  "testStatus": "untested",
  "editorVersion": "2.0",
  "scheduledStop": false,
  "status": "draft",
  "killOnScheduleStop": false,
  "triggerType": "EnrollFromList",
  "name": "${flow.name}",
  "definition": {
    "globalSetting": {},
    "triggerType": "EnrollFromList",
    "startStep": "3",
    "startCriteria": {
      "udo": {
        "objId": "customer"
      },
      "isTemplate": false,
      "id": 0,
      "filters": {
        "logicalOperator": "and",
        "subFilters": [],
        "watchList": "${flow.list}",
        "version": 2,
        "listType": "static"
      }
    },
    "subjectType": "customer",
    "steps": [
      {
        "nextSteps": [
          {
            "nextStep": "3"
          }
        ],
        "stepType": "delay",
        "name": "开始",
        "id": "1",
        "stepTimeout": 1,
        "nodeType": "start",
        "errors": {}
      },
      {
        "nextSteps": [
          {
            "nextStep": "6"
          },
          {
            "nextStep": "100"
          }
        ],
        "stepType": "abStartBranch",
        "isTemplate": false,
        "subject": {
          "type": "customer"
        },
        "name": "控制组分流",
        "id": "3",
        "nodeType": "compareNode",
        "config": {
          "identity": "attr",
          "typeName": "分流器",
          "abConfig": {
            "abId": "3",
            "probabilities": [
              {
                "p": ${flow.controlGroup},
                "branchId": "1",
                "isDefault": true,
                "stepId": "6",
                "name": "分支1"
              },
              {
                "p": ${flow.strategyGroup},
                "branchId": "2",
                "stepId": "100",
                "name": "分支2"
              }
            ]
          },
          "type": "distribute"
        },
        "errors": {}
      },
      {
        "nextSteps": [
          {
            "nextStep": "7"
          }
        ],
        "stepType": "action",
        "isTemplate": false,
        "subject": {
          "type": "customer"
        },
        "name": "记录进入控制组log",
        "action": {
          "actionType": "add_campaign_log",
          "actionBody": {
            "campaign": "活动"
          }
        },
        "id": "6",
        "nodeType": "addCampaignLog",
        "config": {
          "identity": "attr"
        },
        "errors": {}
      },
      {
        "nextSteps": [],
        "stepType": "done",
        "success": true,
        "name": "",
        "id": "7"
      }
      ${flow.channelNodes}
    ],
    "setting": {
      "includeHistoricalMembers": true,
      "startOnJoinList": false,
      "useFlowstatServiceV2": true,
      "filterByPriorityGroup": "",
      "listThrottle": 400,
      "nonRestartableFromDb": true,
      "Restartable": false
    }
  }
}