{
"nextSteps": [
{
"nextStep": "${channel.endNodeId}"
}
],
"stepType": "action",
"isTemplate": false,
"subject": {
"type": "customer"
},
"name": "${channel.messagingType}",
"action": {
"actionType": "me_action",
"actionBody": {
"payload": {
"campaignUuid": "${channel.campaignCode}",
"channelPluginInstanceInfo": {
"accountInfo": {
"channelTunnelInfo": {
"tunnelId": "${channel.tunnelId}",
"additional": {
"quotaPoolId": "${channel.quotaPoolId}"
}
}
},
"messagingType": "${channel.messagingType}",
"pluginVersionId": "${channel.pluginVersionId}",
"channelType": "${channel.channelType}"
},
"meta": {
},
"templateInfo": {
"templateId": "${channel.templateId}"
},
"tunnelId":  "${channel.tunnelId}",
"additionalInfo": {},
"predicateInfo": {
"pipl": [],
"isMock": false,
"skipDnd": false
},
"templateId": "${channel.templateId}",
"folderId": "",
"audienceInfo": {
"profileName": "customer",
"sendIdentity": "customer",
"objId": "customer",
"audienceIdType": "${channel.audienceIdType}"
},
"vendorCode": "${channel.vendorCode}"
},
"channelVersion": "${channel.channelVersion}"
}
},
"id": "${channel.nodeId}",
"nodeType": "${channel.nodeType}",
"config": {
"identity": "attr"
},
"errors": {}
}