{
  "nextSteps": [],
  "stepType": "done",
  "success": true,
  "name": "",
  "id": "${end.nodeId}"
}