package com.convertlab.macore.campaign.service;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.macore.campaign.common.utils.BeanCopyUtils;
import com.convertlab.macore.campaign.mapper.CampaignFilterMapper;
import com.convertlab.macore.campaign.model.dto.CampaignFilterDTO;
import com.convertlab.macore.campaign.model.entity.CampaignFilter;
import com.convertlab.macore.campaign.model.entity.CampaignTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
@Slf4j
@DataSourceLookup("main")
public class CampaignFilterService {

    private final CampaignFilterMapper campaignFilterMapper;

    private final CampaignStrategyService campaignStrategyService;

    public CampaignFilterService(CampaignFilterMapper campaignFilterMapper, CampaignStrategyService campaignStrategyService) {
        this.campaignFilterMapper = campaignFilterMapper;
        this.campaignStrategyService = campaignStrategyService;
    }

    /**
     * 查询过滤器列表
     *
     * @param name 过滤器名称
     */
    public List<CampaignFilterDTO> listCampaignFilter(String name) {
        LambdaQueryWrapper<CampaignFilter> queryWrapper = new LambdaQueryWrapper<>();
        if (StrUtil.isNotBlank(name)) {
            queryWrapper.like(CampaignFilter::getFilterName, name);
        }

        queryWrapper.orderByDesc(CampaignFilter::getLastUpdated);
        return BeanCopyUtils.copyList(campaignFilterMapper.selectList(queryWrapper), CampaignFilterDTO::new);
    }

    /**
     * 保存或更新过滤器信息
     *
     * @param dto 过滤器信息
     */
    public boolean saveOrUpdateCampaignFilter(CampaignFilterDTO dto) {
        Long count = campaignFilterMapper.selectCount(new LambdaQueryWrapper<CampaignFilter>()
                .eq(CampaignFilter::getFilterName, dto.getFilterName())
                .ne(Objects.nonNull(dto.getId()), CampaignFilter::getId, dto.getId()));
        if (count > 0) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000016", "campaign filter name is already exists. {}", new String[]{dto.getFilterName()});
        }

        if (Objects.isNull(dto.getId())) {
            return campaignFilterMapper.insert(BeanCopyUtils.copyBean(dto, CampaignFilter::new)) > 0;
        }

        CampaignFilter campaignFilter = campaignFilterMapper.selectById(dto.getId());
        if (Objects.isNull(campaignFilter)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000017", "campaign filter is not exists. {}", new String[]{dto.getId().toString()});
        }

        return campaignFilterMapper.updateById(BeanCopyUtils.copyBean(dto, CampaignFilter::new)) > 0;
    }

    /**
     * 过滤器详情
     *
     * @param id 过滤器ID
     */
    public CampaignFilterDTO findById(Long id) {
        CampaignFilter campaignFilter = campaignFilterMapper.selectById(id);
        if (Objects.isNull(campaignFilter)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000017", "campaign filter is not exists. {}", new String[]{id.toString()});
        }

        return BeanCopyUtils.copyBean(campaignFilter, CampaignFilterDTO::new);
    }

    /**
     * 复制过滤器信息
     *
     * @param id 过滤器ID
     */
    public boolean copyCampaignFilter(Long id) {
        CampaignFilter campaignFilter = campaignFilterMapper.selectById(id);
        if (Objects.isNull(campaignFilter)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000017", "campaign filter is not exists. {}", new String[]{id.toString()});
        }

        CampaignFilter filter = BeanCopyUtils.copyBean(campaignFilter, CampaignFilter::new, "id", "tenantId");
        filter.setFilterName(filter.getFilterName() + "_复制");
        return campaignFilterMapper.insert(filter) > 0;
    }

    /**
     * 过滤器删除
     *
     * @param id 过滤器ID
     */
    public boolean del(Long id) {
        return campaignFilterMapper.deleteById(id) > 0;
    }

    /**
     * 检查过滤器关联
     *
     * @param id 过滤器ID
     */
    public boolean checkFilterRelation(Long id) {
        return campaignStrategyService.countByFilterId(id) > 0;
    }
}
