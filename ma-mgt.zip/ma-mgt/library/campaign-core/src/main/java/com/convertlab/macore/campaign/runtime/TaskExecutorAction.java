package com.convertlab.macore.campaign.runtime;

import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.runtime.task.ITaskRuntimeService;

@FunctionalInterface
public interface TaskExecutorAction {
    void execute(ITaskRuntimeService taskService, CampaignExecutionTask task) throws Exception;
}