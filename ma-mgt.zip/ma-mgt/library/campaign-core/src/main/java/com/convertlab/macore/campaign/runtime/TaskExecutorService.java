package com.convertlab.macore.campaign.runtime;


import com.alibaba.ttl.threadpool.TtlExecutors;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.support.MdcTaskDecorator;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.runtime.task.ITaskRuntimeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.task.TaskDecorator;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

@Service
@Slf4j
@RequiredArgsConstructor
public class TaskExecutorService {

    Executor executor;
    ThreadPoolExecutor executorService;
    ThreadPoolTaskExecutor threadPoolTaskExecutor;

    final TaskServiceFactory taskServiceFactory;

    //////////////////////////
    //// 执行器部分 - 开始
    //////////////////////////

    @PostConstruct
    void init(){
        initExecutor("CampaignTaskExecutorService", 10);
    }

    public void initExecutor(String executorName, int poolSize) {
        final ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(poolSize);
        executor.setMaxPoolSize(poolSize);
        executor.setThreadNamePrefix(executorName + "-");
        executor.setThreadFactory(r -> {
            Thread thread = executor.newThread(r);
            thread.setUncaughtExceptionHandler((t, e) -> log.error("Uncaught exception in thread: " + t.getName(), e));
            return thread;
        });
        TaskDecorator mdcTaskDecorator = new MdcTaskDecorator(executorName);
        executor.setTaskDecorator(mdcTaskDecorator);
        executor.initialize();
        threadPoolTaskExecutor = executor;
        this.executor = TtlExecutors.getTtlExecutor(executor);
        executorService = executor.getThreadPoolExecutor();
    }

    private Executor getExecutor(){
        return executor;
    }

    //////////////////////////
    //// 执行器部分 - 结束
    //////////////////////////

    void runTaskAsync(CampaignExecutionTask task, TaskExecutorAction action, CampaignTaskExecutorService campaignTaskExecutorService){
        ITaskRuntimeService taskService = taskServiceFactory.getTaskService(task);
        getExecutor().execute(()->{
            try {
                if(Objects.equals(TenantContextHolder.getTenantId(), task.getTenantId())){
                    action.execute(taskService, task);
                }else{
                    try (TemporaryTenantContext ignored = new TemporaryTenantContext(task.getTenantId())) {
                        action.execute(taskService, task);
                    }
                }
            } catch (Exception e) {
                //任务失败，将任务的状态置为failed, 并保存error message，在execution info里。
                log.error("run task async failed", e);
                try (TemporaryTenantContext ignored = new TemporaryTenantContext(task.getTenantId())) {
                    campaignTaskExecutorService._failTask(task, e);
                }
            }
        });
    }

}
