package com.convertlab.macore.campaign.common.utils;

public class FolderNameUtils {

    public static final String CAMPAIGN_LIST_PREFIX = "campaign_list_";
    public static final String CAMPAIGN_FLOW_PREFIX = "campaign_flow_";

    /**
     * 获取群组的文件夹名称
     * @param campaignId
     * @return
     */
    public static String getCampaignListFolderName(long campaignId){
        if (campaignId < 0) {
            throw new IllegalArgumentException("Campaign ID must be positive.");
        }
        return String.format(CAMPAIGN_LIST_PREFIX + "%d", campaignId);
    }

    /**
     * 获取自动流的文件夹名称
     * @param campaignId
     * @return
     */
    public static String getCampaignFlowFolderName(long campaignId) {
        if (campaignId < 0) {
            throw new IllegalArgumentException("Campaign ID must be positive.");
        }
        return String.format(CAMPAIGN_FLOW_PREFIX + "%d", campaignId);
    }
}
