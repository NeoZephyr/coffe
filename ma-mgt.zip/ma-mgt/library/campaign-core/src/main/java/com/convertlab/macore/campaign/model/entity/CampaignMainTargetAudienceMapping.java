package com.convertlab.macore.campaign.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.convertlab.foundation.library.mybatisplus.entity.BaseTenantEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TableName(value = "campaign_main_target_audience_mapping", excludeProperty = {"version", "creatorId", "updaterId",
        "creatorName", "updaterName", "dateCreated", "lastUpdated"})
public class CampaignMainTargetAudienceMapping extends BaseTenantEntity implements Serializable {

    @TableId(value = "id", type = IdType.AUTO)
    Long id;

    @TableField("campaign_id")
    Long campaignId;

    @TableField("audience_strategy_id")
    Long audienceStrategyId;

    @TableField("list_id")
    Long listId;
}
