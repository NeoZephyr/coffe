package com.convertlab.macore.campaign.runtime;

import com.convertlab.data.job.core.biz.model.BizJob;
import com.convertlab.data.job.core.biz.model.ReturnCode;
import com.convertlab.data.job.core.biz.model.ReturnT;
import com.convertlab.data.job.core.constants.DataJobConstants;
import com.convertlab.data.job.core.context.ClJobHelper;
import com.convertlab.data.job.core.handler.annotation.ClJob;
import com.convertlab.data.job.core.util.data.BizJobClient;
import com.convertlab.data.job.core.util.data.JobData;
import com.convertlab.foundation.library.business.feature.FeatureClient;
import com.convertlab.foundation.library.business.feature.QueryToggleTenantsResponse;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.principal.context.PrincipalContextHolder;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.runtime.task.*;
import com.convertlab.macore.campaign.runtime.taskchain.TimeStrategyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.NotImplementedException;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.convertlab.macore.campaign.service.CampaignService;

@Service
@Slf4j
@RequiredArgsConstructor
public class CampaignTaskExecutorService implements ICampaignTaskExecutor{

    public final static String CAMPAIGN_TASK_SCHEDULER_HANDLER = "JOB_10_campaignTaskSchedulerHandler";
    public final static String CAMPAIGN_TASK_ASYNC_JOB_HANDLER = "campaignAsyncTaskHandler";

    final TaskExecutorService taskExecutorService;

    final BizJobClient bizJobClient;
    final FeatureClient featureClient;

    final CampaignTaskService campaignTaskService;
    final TimeStrategyService timeStrategyService;
    final TaskServiceFactory taskServiceFactory;
    final CampaignService campaignService;


    //////////////////////////
    //// 主函数部分 - 开始
    //////////////////////////

    @Override
    public void startTask(String taskId) {
        //load campaign task
        CampaignExecutionTask task = this.campaignTaskService.getTask(taskId);

        //根据任务的trigger date，判断是否需要schedule task, 如果trigger date不为空，且trigger date 在当前时间之后，则进行定时。
        if(task.getTaskTriggerDate() != null && task.getTaskTriggerDate().isAfter(Instant.now())){
            //schedule task if trigger date is not null
            _scheduleTask(task);
        }else{
            //push task to campaign task executor service.
            _startTaskDirectly(task);
        }
    }

    public void startDirectly(String taskId){
        CampaignExecutionTask task = campaignTaskService.getTask(taskId);
        if(task != null) {
            _startTaskDirectly(task);
        }
    }

    void _startTaskDirectly(CampaignExecutionTask task){
        log.info("start task :", task.getId() );

        if(CampaignExecutionTask.TASK_STATUS_STOPPED.equals(task.getTaskStatus())){
            //如果任务已经是停止状态，则不做任何处理。
            log.info("Task {} is already stopped.", task.getId());
            return;
        }

        //update task status to running.
        campaignTaskService.updateTaskStatus(task, CampaignExecutionTask.TASK_STATUS_RUNNING);

        //run task async
        taskExecutorService.runTaskAsync(task, this::executeTask, this);
    }

    @Override
    public void scheduleTask(String taskId) {
        //load campaign task
        CampaignExecutionTask task = this.campaignTaskService.getTask(taskId);
        this._scheduleTask(task);
    }


    @Override
    public void unscheduleTask(String taskId) {
        CampaignExecutionTask task = this.campaignTaskService.getTask(taskId);
        this._unscheduleTask(task);
    }

    private String genJobNo(CampaignExecutionTask task){
        return CAMPAIGN_TASK_SCHEDULER_HANDLER + "-" + task.getTenantId() + "-" + task.getId();
    }


    void executeTask(ITaskRuntimeService taskService, CampaignExecutionTask task){
        log.info("<CampaignTaskExecutorService> executeTask {} jobNo: {}", task.getId(), this.genJobNo(task));
        TaskResult result = taskService.start(task);
        if(result != null ) {
            if (result.isFinish()) {
                //如果任务执行结束
                log.info("<CampaignTaskExecutorService> Task {} is finished", task.getId());
                this._finishTask(task, taskService);
                // 更新任务执行的中间状态
                bizJobClient.updateLatestBizJobStatus(this.genJobNo(task), DataJobConstants.STATUS_FINISHED);
                return;
            }

            if(result.isFailed()){
                //如果任务执行失败
                this._failTask(task, new BusinessException("Task failed", result.getMessage()));
            }
        }
    }

    void _checkTaskProgress(ITaskRuntimeService taskService, CampaignExecutionTask task){
        TaskResult result = taskService.checkProgress(task);
        if(result!= null && result.isFinish()){
            this._finishTask(task, taskService);
        }
    }

    void _finishTask(CampaignExecutionTask task, ITaskRuntimeService service){
        service.finish(task);
        campaignTaskService.updateTaskStatus(task, CampaignExecutionTask.TASK_STATUS_FINISHED);
        //运行下一个任务。
        startNextTask(task);
    }


    void startNextTask(CampaignExecutionTask taskDef) {
        //找到下一个taskId，运行下一个任务，如果任务均已经运行，则不做其他处理。
        String nextTaskId = taskDef.getNextTaskId();
        if(nextTaskId != null){
            CampaignExecutionTask nextTask = campaignTaskService.getTask(nextTaskId);
            if(nextTask != null){
                this.startTask(nextTask.getId());
            }else{
                throw new BusinessException("Next task not found", "");
            }
        }
    }


    public void checkProgress(String taskId){
        CampaignExecutionTask task = campaignTaskService.getTask(taskId);
        if(task != null) {
            taskServiceFactory.getTaskService(task).checkProgress(task);
        }
    }

    void _failTask(CampaignExecutionTask task, Exception e) {
        //获取TaskDefinition。
        log.error("task failed {}", task.getId(), e);

        //更新当前task的状态。
        campaignTaskService.updateTaskStatus(task, CampaignExecutionTask.TASK_STATUS_FAILED, e.getMessage());

        //如果任务失败了，需要将engage或者campaign的状态更新为failed.
        if(task.getEngageId() > 0){
            campaignService.updateEngageStatus(task.getEngageId(), CampaignOutboundEngage.ENGAGE_STATUS_FAILED);
        }else{
            campaignService.updateCampaignStatus(task.getCampaignId(), MarketingCampaign.STATUS_FAILED);
        }
    }

    void unscheduleAndStopTasks(long campaignId) {
        List<CampaignExecutionTask> tasks = campaignTaskService.getCampaignExecutionTasks(campaignId);
        tasks.forEach(this::unscheduleAndStopTask);
    }

    private void unscheduleAndStopTask(CampaignExecutionTask task) {
        _unscheduleTask(task);
        campaignTaskService.updateTaskStatus(task, CampaignExecutionTask.TASK_STATUS_STOPPED);
    }


    @Override
    public void stopTask(String taskId) {
        //TODO
        throw new NotImplementedException("stopTask");
    }

    @Override
    public void finishTask(String taskId) {
        CampaignExecutionTask task = campaignTaskService.getTask(taskId);
        if(task != null) {
            this._finishTask(task, taskServiceFactory.getTaskService(task));
        }
    }

    @Override
    public void failTask(String taskId) {
        CampaignExecutionTask task = campaignTaskService.getTask(taskId);
        if(task != null) {
            this._failTask(task, new BusinessException("Task failed", ""));
        }
    }

    //////////////////////////
    //// 主函数部分 - 结束
    //////////////////////////





    //////////////////////////
    //// 调度处理部分 - 开始
    //////////////////////////


    void _scheduleTask(CampaignExecutionTask task) {
        if(CampaignExecutionTask.TASK_STATUS_STOPPED.equals(task.getTaskStatus())){
            //如果任务已经是停止状态，则不做任何处理。
            log.info("Task {} is already stopped.", task.getId());
            return;
        }

        log.info("Schedule task {} at time {}", task.getId(), task.getTaskTriggerDate());

        String cronString = timeStrategyService.convertUtcToCron(task.getTaskTriggerDate());

        log.info("Cron String is {}", cronString);

        Map<String, String> taskData = new HashMap<>();
        taskData.put("taskId", task.getId());
        taskData.put("campaignId", task.getCampaignId().toString());
        taskData.put("tenantId", task.getTenantId().toString());
        JobData.JobDataBuilder jobDataBuilder = JobData.builder()
                .bizUuid(task.getId())
                .jobType(CAMPAIGN_TASK_SCHEDULER_HANDLER)
                .cron(cronString)
                .scheduleConstrain("normal")
                .appName("ma-mgt")
                .retryCount(1)
                .retryWaitMinutes(5)
                .creatorId(PrincipalContextHolder.getUserId())
                .name(CAMPAIGN_TASK_SCHEDULER_HANDLER + "-" + task.getId())
                .needNotification(true)
                .jobNo(this.genJobNo(task))
                .jobHandler(CAMPAIGN_TASK_SCHEDULER_HANDLER)
                .jobParameters(JsonUtils.instanceOfDto().obj2Json(taskData));
        ReturnT<BizJob> createJobResult = bizJobClient.createBizJob(jobDataBuilder.build());
        if(createJobResult.getCode() == ReturnCode.SUCCESS){
            //update task status to running.
            campaignTaskService.updateTaskStatus(task, CampaignExecutionTask.TASK_STATUS_SCHEDULED);
        }else{
            String errorMessage= String.format("Failed to create campaign schedule task taskId: %s campaignId: %s, result code: %d  message: %s ",
                    task.getId(), task.getCampaignId().toString(), createJobResult.getCode(), createJobResult.getMsg());
            log.error(errorMessage);
            throw new BusinessException(CommonErrors.GENERAL_ERROR, "MSG_108_000026",
                    errorMessage,
                    new String[]{task.getId(), task.getCampaignId().toString()});
        }
    }


    void _unscheduleTask(CampaignExecutionTask task) {
        String jobNo = genJobNo(task);
        try {
            bizJobClient.deleteJobAndDefaultJobGroup(jobNo);
        }catch (Exception e){
            log.error("unscheduleTask failed", e);
        }
    }

    @ClJob(value = CAMPAIGN_TASK_SCHEDULER_HANDLER)
    public void campaignTaskSchedulerHandler(){
        //定时任务回调
        JsonUtils util = JsonUtils.instanceOfDto();
        String data  = ClJobHelper.getJobParam();

        _campaignTaskSchedulerHandler(util, data);
    }

    void _campaignTaskSchedulerHandler( JsonUtils util,  String data ){

        @SuppressWarnings("unchecked")
        Map<String, Object> jobData = util.json2Obj(data, Map.class);
        log.info("campaignTaskSchedulerHandler triggered {}", jobData);

        String tenantId = jobData.get("tenantId").toString();
        String taskId = jobData.get("taskId").toString();
        try (TemporaryTenantContext ignored1 = new TemporaryTenantContext(Long.valueOf(tenantId))) {
            CampaignExecutionTask task = this.campaignTaskService.getTask(taskId);
            //判断是否是定时任务，只有定时任务可以被触发。
            if(!CampaignExecutionTask.TASK_STATUS_SCHEDULED.equals(task.getTaskStatus())){
                log.error("Task {} is not scheduled, skip.", task.getId());
                return;
            }
            _startTaskDirectly(task);
        }
    }

    @ClJob(value = CAMPAIGN_TASK_ASYNC_JOB_HANDLER)
    public void campaignTaskAsyncJobHandler(){

        log.info("campaignTaskAsyncJobHandler is triggered");

        QueryToggleTenantsResponse response = featureClient.getToggleTenants(
                CampaignService.FEATURE_CAMPAIGN_V4,
                1000,
                0);
        if (CollectionUtils.isEmpty(response.getRows())) {
            log.info("No tenant found, skip campaignTaskAsyncJobHandler.");
            return;
        }

        response.getRows().forEach(feature -> {
                try (TemporaryTenantContext ignored = new TemporaryTenantContext(feature.getTenantId())) {
                    final List<CampaignExecutionTask> runningAsyncRemoteCallTaskList = campaignTaskService.getRunningAsyncCallTasks();

                    if (CollectionUtils.isEmpty(runningAsyncRemoteCallTaskList)) {
                        log.info("No running async remote call task found, skip campaignTaskAsyncJobHandler for tenant: {}.", feature.getTenantId());
                        return;
                    }

                    //轮询所有任务
                    runningAsyncRemoteCallTaskList.forEach(task -> {
                        //run task async
                        taskExecutorService.runTaskAsync(task, this::_checkTaskProgress, this);
                    });

                }  catch (Exception e) {
                     log.error("campaignTaskAsyncJobHandler for tenant: {} failed.", feature.getTenantId(), e);
                 }

        });

    }

    //////////////////////////
    //// 调度处理部分 - 结束
    //////////////////////////


}
