package com.convertlab.macore.campaign.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.campaign.model.entity.CampaignAudienceStrategy;
import com.convertlab.macore.campaign.model.entity.CampaignBatchInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface CampaignBatchInfoMapper extends BaseMapper<CampaignBatchInfo> {

    @Select("SELECT * FROM campaign_batch_info t WHERE t.campaign_id = #{campaignId} ")
    List<CampaignBatchInfo> selectByCampaignId(@Param("campaignId")Long campaignId);

    @Select("SELECT * FROM campaign_batch_info t WHERE t.campaign_id = #{campaignId} and t.engage_id = #{engageId}")
    List<CampaignBatchInfo> selectByCampaignIdAndEngageId(@Param("campaignId")Long campaignId, @Param("engageId")Long engageId);

    @Select({"<script>",
            "SELECT * FROM campaign_batch_info t",
            "WHERE t.campaign_id in ",
            "<foreach collection=\"campaignIds\" item=\"campaignId\" open=\"(\" separator=\",\" close=\")\">",
            "#{campaignId}",
            "</foreach>",
            "</script>"})
    List<CampaignBatchInfo> selectByBatchCampaignIds(@Param("campaignIds") List<Long> campaignIds);
}