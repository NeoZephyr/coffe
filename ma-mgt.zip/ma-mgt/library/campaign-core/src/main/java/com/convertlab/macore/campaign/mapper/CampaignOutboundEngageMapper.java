package com.convertlab.macore.campaign.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface CampaignOutboundEngageMapper extends BaseMapper<CampaignOutboundEngage> {
    //根据campaignId查询所有的engage
    @Select({"<script>",
            "SELECT * FROM campaign_outbound_engage t",
            "WHERE t.campaign_id = #{campaignId}",
            "</script>"})
    @ResultType(CampaignOutboundEngage.class)
    List<CampaignOutboundEngage> getEngageListByCampaignId(@Param("campaignId")long campaignId);

//    //根据EngageId找到对应的CampaignOutboundEngage
//    @Select({"<script>",
//            "SELECT * FROM campaign_outbound_engage t",
//            "WHERE t.id = #{engageId}",
//            "</script>"})
//    @ResultType(CampaignOutboundEngage.class)
//    CampaignOutboundEngage getEngageByEngageId(@Param("engageId")long engageId);
//
//
//    @Select({"<script>",
//            "SELECT * FROM campaign_outbound_engage t",
//            "WHERE t.campaign_id = #{campaignId}",
//            "</script>"})
//    List<CampaignOutboundEngage> selectByCampaignId(@Param("campaignId")Long campaignId);

    @Select({"<script>",
            "SELECT * FROM campaign_outbound_engage t",
            "WHERE t.campaign_id in ",
            "<foreach collection=\"campaignIds\" item=\"campaignId\" open=\"(\" separator=\",\" close=\")\">",
            "#{campaignId}",
            "</foreach>",
            "</script>"})
    List<CampaignOutboundEngage> getEngageListByBatchCampaignIds(@Param("campaignIds") List<Long> campaignIds);
}
