package com.convertlab.macore.campaign.runtime;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.LocalDateTimeUtil;
import cn.hutool.core.util.StrUtil;
import com.convertlab.data.job.core.handler.annotation.ClJob;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.macore.campaign.mapper.MarketingCampaignMapper;
import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.service.CampaignService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@DataSourceLookup("main")
@Slf4j
public class CampaignRuntimeService implements ICampaignRuntime {

    public static final String CAMPAIGN_STATUS_UPDATE_HANDLER = "campaignStatusUpdateHandler";

    final MarketingCampaignMapper marketingCampaignMapper;
    final CampaignTaskPlannerService campaignTaskPlannerService;
    final CampaignService campaignService;

    public CampaignRuntimeService(MarketingCampaignMapper marketingCampaignMapper, CampaignTaskPlannerService campaignTaskPlannerService, CampaignService campaignService) {
        this.marketingCampaignMapper = marketingCampaignMapper;
        this.campaignTaskPlannerService = campaignTaskPlannerService;
        this.campaignService = campaignService;
    }


    /**
     * 启动营销活动执行。
     *
     * @param campaignId 营销活动ID
     */
    @Transactional
    @Override
    public boolean startCampaign(Long campaignId) {
        //validate campaignId and return campaign
        CampaignFullDataDTO campaignFullData = campaignService.getCampaignFullData(campaignId);

        if (!MarketingCampaign.STATUS_DRAFT.equals(campaignFullData.getCampaign().getStatus())) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_108_000003", "Unable to start the campaign because its status is marked as {}", new String[]{campaignFullData.getCampaign().getStatus()});
        }

        //change campaign status to running.
        if (LocalDateTimeUtil.now().isBefore(campaignFullData.getCampaign().getDateStart())) {
            campaignFullData.getCampaign().setStatus(MarketingCampaign.STATUS_NOT_STARTED);
        } else {
            campaignFullData.getCampaign().setStatus(MarketingCampaign.STATUS_RUNNING);
            //invoke campaign task planner to plan tasks.
            campaignTaskPlannerService.planStartCampaign(campaignFullData);
        }

        return marketingCampaignMapper.updateById(campaignFullData.getCampaign()) > 0;
    }

    /**
     * 停止营销活动执行
     *
     * @param campaignId 营销活动ID
     */
    @Transactional
    @Override
    public boolean stopCampaign(Long campaignId, boolean isDelStrategy) {
        //validate campaignId and return campaign
        CampaignFullDataDTO campaignFullData = campaignService.getCampaignFullData(campaignId);

        //如果campaign status不等于Running、NotStarted
        if (!Arrays.asList(MarketingCampaign.STATUS_RUNNING, MarketingCampaign.STATUS_NOT_STARTED).contains(campaignFullData.getCampaign().getStatus())) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_108_000004", "Unable to stop the campaign because its status is marked as {}", new String[]{campaignFullData.getCampaign().getStatus()});
        }

        //change campaign status to stopping.
        campaignFullData.getCampaign().setStatus(MarketingCampaign.STATUS_STOPPED);
        boolean result = marketingCampaignMapper.updateById(campaignFullData.getCampaign()) > 0;

        //执行stop strategy, 执行完毕后，将status设置为stopped
        if (StrUtil.equals(MarketingCampaign.STATUS_RUNNING, campaignFullData.getCampaign().getStatus())) {
            campaignTaskPlannerService.planStopCampaign(campaignFullData, isDelStrategy);
        }
        return result;
    }

    @ClJob(value = CAMPAIGN_STATUS_UPDATE_HANDLER)
    public void scheduleUpdateStatus() {
        log.info("Start Campaign Status Update Job.");
        List<MarketingCampaign> notStartList = marketingCampaignMapper.getNotStartedCampaign();
        if (CollUtil.isNotEmpty(notStartList)) {
            // batch update campaign status to running.
            Set<Long> ids = notStartList.stream().map(MarketingCampaign::getId).collect(Collectors.toSet());
            marketingCampaignMapper.updateStatusInList(ids, MarketingCampaign.STATUS_RUNNING);

            // invoke campaign task
            notStartList.forEach(campaign -> {
                try (TemporaryTenantContext ignored = new TemporaryTenantContext(campaign.getTenantId())) {
                    campaignTaskPlannerService.planStartCampaign(campaignService.getCampaignFullData(campaign.getId()));
                }
            });
        }

        List<MarketingCampaign> runningList = marketingCampaignMapper.getRunningCampaign();
        if (CollUtil.isNotEmpty(runningList)) {
            // batch update campaign status to stopped.
            Set<Long> ids = runningList.stream().map(MarketingCampaign::getId).collect(Collectors.toSet());
            marketingCampaignMapper.updateStatusInList(ids, MarketingCampaign.STATUS_STOPPED);

            // invoke campaign task
            runningList.forEach(campaign -> {
                try (TemporaryTenantContext ignored = new TemporaryTenantContext(campaign.getTenantId())) {
                    campaignTaskPlannerService.planStopCampaign(campaignService.getCampaignFullData(campaign.getId()), false);
                }
            });
        }
        log.info("End Campaign Status Update Job.");
    }


    /**
     * 在营销活动过程中，可能会更新engage的时间和内容，或者disable某个engage。
     * 更新engage后，需要重新安排任务计划。
     *
     * @param engageList
     */
    @Override
    public boolean updateEngageList(Long campaignId, List<CampaignOutboundEngage> engageList) {
        CampaignFullDataDTO campaignFullData = campaignService.getCampaignFullData(campaignId);
        campaignTaskPlannerService.planUpdateEngage(campaignFullData, engageList);
        return true;
    }

    /**
     * 在营销活动过程中，针对已经执行的Engage，可以stop engage。
     *
     * @param engage
     */
    public void stopEngage(CampaignOutboundEngage engage) {

    }

    /**
     * 在营销活动过程中，针对已经停止的Enage, 可以resume engage。
     *
     * @param engage
     */
    public void resumeEngage(CampaignOutboundEngage engage) {

    }

}
