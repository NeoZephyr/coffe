package com.convertlab.macore.campaign.runtime.taskchain;

import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.runtime.task.CampaignTaskService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class EngageSegmentTaskChain extends AbstractTaskChainStrategy{

    public EngageSegmentTaskChain(CampaignTaskService campaignTaskService, TimeStrategyService timeStrategyService, ObjectMapper objectMapper) {
        super(campaignTaskService, timeStrategyService, objectMapper);
    }

    @Override
    public List<CampaignExecutionTask> createTaskChain(CampaignFullDataDTO campaignFullData) {

        List<CampaignExecutionTask> tasks = initializeTaskChain(campaignFullData);

        //iterate engageListByCampaignId and start engage task for each engage.
        for (CampaignOutboundEngage engage : campaignFullData.getOutboundEngageList()) {

            CampaignExecutionTask segmentationTask = campaignTaskService.createSegmentationTask(campaignFullData.getCampaign(), engage);
            CampaignExecutionTask startEngageTask = campaignTaskService.createStartEngageTask(campaignFullData, engage);
            if(engage.getTimeStrategy().equals("Scheduled")){
                Instant engageScheduleTime = timeStrategyService.getScheduledTime(engage);
                startEngageTask.setTaskTriggerDate(engageScheduleTime);

                Instant segmentScheduledTime = timeStrategyService.getSegmentScheduledTime(engageScheduleTime);
                segmentationTask.setTaskTriggerDate(segmentScheduledTime);
            }

            tasks.add(segmentationTask);
            tasks.add(startEngageTask);
        }
        return tasks;
    }

}
