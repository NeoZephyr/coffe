package com.convertlab.macore.campaign.common.utils;

public class TimingStrategyConstants {
    // 立即执行
    public static final String IMMEDIATE = "Immediate";

    // 计划执行
    public static final String SCHEDULED = "Scheduled";

    // 周期性执行
    public static final String PERIODIC = "Periodic";

    // 多波次执行
    public static final String MULTIPLE_WAVE = "MultipleWave";


}
