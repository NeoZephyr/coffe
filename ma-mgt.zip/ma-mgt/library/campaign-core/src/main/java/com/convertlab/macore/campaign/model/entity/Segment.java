package com.convertlab.macore.campaign.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

@Data
@EqualsAndHashCode(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TableName(value = "list")
public class Segment {
    @TableId(value = "id", type = IdType.AUTO)
    Long id;

    @TableField("is_static")
    Boolean isStatic;

    @TableField("is_external")
    Boolean isExternal;

}
