package com.convertlab.macore.campaign.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.convertlab.foundation.library.mybatisplus.entity.BaseTenantEntity;
import lombok.*;

import java.io.Serializable;

@Data
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TableName(value = "Limit", excludeProperty = {"version", "creatorId", "updaterId", "creatorName", "updaterName"})
public class Limit extends BaseTenantEntity implements Serializable {

    @TableId(value = "id", type = IdType.AUTO)
    Long id;

    @TableField("company_name")
    String companyName;

    @TableField("feature")
    String feature;

    @TableField("quantity")
    Integer quantity;

}
