package com.convertlab.macore.campaign.mapper;


import com.baomidou.mybatisplus.annotation.InterceptorIgnore;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;
import java.util.Set;

@Mapper
public interface MarketingCampaignMapper extends BaseMapper<MarketingCampaign> {

    @Select("SELECT id, status,tenant_id, execution_mode FROM marketing_campaign WHERE execution_mode='form_mode' AND  status = 'NotStarted' " +
            "AND date_start <= now() AND (date_finish is null OR date_finish > now())")
    @InterceptorIgnore(tenantLine = "true")
    List<MarketingCampaign> getNotStartedCampaign();

    @Select("SELECT id, status, tenant_id,execution_mode FROM marketing_campaign WHERE execution_mode='form_mode' AND  status = 'Running' " +
            "AND date_finish is not null AND date_finish <= now()")
    @InterceptorIgnore(tenantLine = "true")
    List<MarketingCampaign> getRunningCampaign();

    @Update({"<script>",
            "UPDATE marketing_campaign SET status = #{status} WHERE id in "
                    + "<foreach item='id' collection='ids' open='(' separator=',' close=')'>"
                    + "#{id}"
                    + "</foreach>",
            "</script>"})
    @InterceptorIgnore(tenantLine = "true")
    void updateStatusInList(@Param("ids") Set<Long> ids, @Param("status") String status);

    @Select("SELECT id, uuid, title FROM marketing_campaign WHERE status in ('Running','Stopping') or (status in ('Finished','Stopped') and last_updated > #{yesterday})")
    List<MarketingCampaign> getNotFinishCampaign(String yesterday);
}