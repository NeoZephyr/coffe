package com.convertlab.macore.campaign.model.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class ChannelInfo {
    String messagingType;
    String campaignCode;
    String channelInstanceId;
    String templateName;
    String tunnelId;
    String channelType;
    long wechatAccountId;
    String appId;
    long templateId;
    String audienceIdType;
    String flowStepId;
    String actionBody;
    boolean isThirdPartyChannel;
    String pluginId;
}
