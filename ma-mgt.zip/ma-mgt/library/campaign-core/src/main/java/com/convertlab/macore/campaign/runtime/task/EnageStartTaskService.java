package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.macore.campaign.common.utils.NameUtils;
import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.dto.DeployFlowResponse;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignListInfo;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.service.CampaignFactsDataSyncService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;

import static com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage.ENGAGE_STATUS_FAILED;
import static com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage.ENGAGE_STATUS_RUNNING;

@Service
@Slf4j
public class EnageStartTaskService extends AbstractTaskRuntimeService {

    @Autowired
    protected MaCoreService maCoreService;

    @Autowired
    protected CampaignListInfoService campaignListInfoService;

    @Autowired
    protected CampaignFactsDataSyncService campaignFactsDataSyncService;

    @Override
    public TaskResult onStart(CampaignExecutionTask task) {

        CampaignFullDataDTO campaignFullData = campaignService.getCampaignFullData(task.getCampaignId());
        CampaignOutboundEngage outboundEngage = campaignFullData.getEngageByEngageId(task.getEngageId());

        //发布flow
        final DeployFlowResponse deployFlowResponse = maCoreService.deployFlow(campaignFullData, outboundEngage);

        //如果response状态为success, 更新OutboundEngage状态为Running
        if(deployFlowResponse.isSuccess()) {
            //更新engage status running
            campaignService.updateEngageStatus(task.getEngageId(), ENGAGE_STATUS_RUNNING);

            //将campaign list info的值设置为
            CampaignListInfo listInfo = campaignListInfoService.updateExecutionTime(task.getCampaignId(), task.getEngageId(), NameUtils.TARGET_GROUP, Instant.now());

            //更新engage分群事实表groupDate
            campaignFactsDataSyncService.updateGroupFactsGroupDate(campaignFullData.getCampaign(), task, listInfo, outboundEngage);

            //结束
            return new TaskResult(true);
        }else{
            campaignService.updateEngageStatus(task.getEngageId(), ENGAGE_STATUS_FAILED);
            log.error("Failed to deploy flow for campaignId: {}, engageId: {}, flowId: {}", task.getCampaignId(), task.getEngageId(), outboundEngage.getFlowId());
            return new TaskResult(false);
        }

    }


    @Override
    public void onFinish(CampaignExecutionTask task) {

    }


    @Override
    public TaskResult checkProgress(CampaignExecutionTask task) {
        return new TaskResult(false);
    }
}
