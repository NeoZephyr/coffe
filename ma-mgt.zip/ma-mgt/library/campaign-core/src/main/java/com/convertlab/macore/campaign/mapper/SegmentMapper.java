package com.convertlab.macore.campaign.mapper;

import com.baomidou.mybatisplus.annotation.InterceptorIgnore;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.model.entity.Segment;
import com.convertlab.macore.campaign.service.legacy.cms.model.ListMemberBatchTask;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Set;

public interface SegmentMapper extends BaseMapper<Segment> {
    @Select({"<script>",
            "select id, is_static,is_external from list ",
            "WHERE id in <foreach item='item' index='index' collection='idList' open='(' separator=',' close=')'>#{item}</foreach></script>"})
    @InterceptorIgnore(tenantLine = "true")
    List<Segment> selectByIdList(@Param("idList") Set<Long> idList);

}
