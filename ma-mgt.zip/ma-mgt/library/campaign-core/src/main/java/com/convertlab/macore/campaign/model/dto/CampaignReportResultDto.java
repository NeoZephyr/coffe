package com.convertlab.macore.campaign.model.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Data
public class CampaignReportResultDto implements Serializable {

    public CampaignReportResultDto() {
        reportData = Collections.emptyList();
        violationCampaigns = Collections.emptyList();
    }

    private List<Map<String, Object>> reportData;

    private List<String> violationCampaigns;
}
