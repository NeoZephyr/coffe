package com.convertlab.macore.campaign.model.dto;

import lombok.Data;

@Data
public class CronDTO {
    String fromDate;
    int intervalDays = 0;
    String week = "?";
    String day= "*";
    String hour = "*";
    String min = "0";
    String month= "*";
}
