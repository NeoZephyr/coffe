package com.convertlab.macore.campaign.runtime;

import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;

import java.util.List;

public interface ICampaignTaskPlanner {
    void planStartCampaign(CampaignFullDataDTO campaignFullData);

    void planStopCampaign(CampaignFullDataDTO campaignFullData, boolean isDelStrategy);

    void planUpdateEngage(CampaignFullDataDTO campaignFullDataDTO, List<CampaignOutboundEngage> engageList);

}
