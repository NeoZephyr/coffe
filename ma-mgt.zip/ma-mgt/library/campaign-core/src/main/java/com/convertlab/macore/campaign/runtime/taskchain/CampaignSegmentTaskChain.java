package com.convertlab.macore.campaign.runtime.taskchain;

import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.runtime.task.CampaignTaskService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class CampaignSegmentTaskChain extends AbstractTaskChainStrategy {

    public CampaignSegmentTaskChain(CampaignTaskService campaignTaskService, TimeStrategyService timeStrategyService, ObjectMapper objectMapper) {
        super(campaignTaskService, timeStrategyService, objectMapper);
    }

    @Override
    public List<CampaignExecutionTask> createTaskChain(CampaignFullDataDTO campaignFullData) {
        List<CampaignExecutionTask> tasks = initializeTaskChain(campaignFullData);

        //create task for segmentation.
        CampaignExecutionTask segmentationTask = campaignTaskService.createSegmentationTask(campaignFullData.getCampaign(), null);
        tasks.add(segmentationTask);

        //iterate engageListByCampaignId and start engage task for each engage.
        List<Instant> scheduledTimeList = new ArrayList<>();
        for (CampaignOutboundEngage engage : campaignFullData.getOutboundEngageList()) {
            CampaignExecutionTask startEngageTask = campaignTaskService.createStartEngageTask(campaignFullData, engage);
            if(engage.getTimeStrategy().equals("Scheduled")){
                Instant engageScheduleTime = timeStrategyService.getScheduledTime(engage);
                startEngageTask.setTaskTriggerDate(engageScheduleTime);

                Instant segmentScheduledTime = timeStrategyService.getSegmentScheduledTime(engageScheduleTime);
                scheduledTimeList.add(segmentScheduledTime);
            }
            //create task for start engage
            tasks.add(startEngageTask);
        }

        if(scheduledTimeList.size() > 0){
            //获取最早的segment计算时间。
            scheduledTimeList.sort((task1, task2) -> {
                if(task1 == null && task2 == null){
                    return 0;
                }
                if(task1 == null){
                    return -1;
                }
                if(task2 == null){
                    return 1;
                }
                return task1.compareTo(task2);
            });

            //设置segmentTask的时间。
            segmentationTask.setTaskTriggerDate(scheduledTimeList.get(0));
        }

        return tasks;
    }

}
