package com.convertlab.macore.campaign.model.entity;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.convertlab.foundation.library.mybatisplus.entity.BaseTenantEntity;
import lombok.*;

import java.io.Serializable;

@Data
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TableName(value = "campaign_outbound_engage", excludeProperty = {"version", "creatorId", "updaterId",
        "creatorName", "updaterName", "ownerId", "deptCode", "dateCreated", "lastUpdated"})
public class CampaignOutboundEngage extends BaseTenantEntity implements Serializable {

    public static final String ENGAGE_STATUS_NOT_STARTED = "NotStarted";
    public static final String ENGAGE_STATUS_PREPARING = "Preparing";
    public static final String ENGAGE_STATUS_PREPARED = "Prepared";
    public static final String ENGAGE_STATUS_RUNNING = "Running";
    public static final String ENGAGE_STATUS_FINISHED = "Finished";
    public static final String ENGAGE_STATUS_FAILED = "Failed";
    public static final String ENGAGE_STATUS_STOPPED = "Stopped";
    public static final String ENGAGE_STATUS_STOPPING = "Stopping";

    @TableId(value = "id", type = IdType.AUTO)
    Long id;

    @TableField("seq")
    Integer seq;

    @TableField("code")
    String code;

    @TableField("campaign_id")
    Long campaignId;

    @TableField("status")
    String status;

    @TableField("audience_strategy")
    String audienceStrategy;

    @TableField("audience_data")
    String audienceData;

    @TableField("control_group_strategy")
    String controlGroupStrategy;

    @TableField("control_group_data")
    String controlGroupData;

    @TableField("channel_strategy")
    String channelStrategy;

    @TableField("channel_data")
    String channelData;

    @TableField("time_strategy")
    String timeStrategy;

    @TableField("time_data")
    String timeData;

    @TableField("profile_type")
    String profileType;

    @TableField("list_id")
    Long listId;

    @TableField("flow_id")
    Long flowId;

}
