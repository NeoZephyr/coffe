package com.convertlab.macore.campaign.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.convertlab.foundation.library.mybatisplus.entity.BaseTenantEntity;
import lombok.*;

import java.io.Serializable;
import java.time.Instant;

@Data
@EqualsAndHashCode(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TableName(value = "campaign_list_info",excludeProperty = {"version","creatorId", "creatorName", "dateCreated", "lastUpdated","updaterId", "updaterName"})
public class CampaignListInfo  extends BaseTenantEntity implements Serializable {


    public CampaignListInfo(Long campaignId, Long engageId, String listType, String listName, Long listId, String mapToListType, boolean isRoot) {
        this.campaignId = campaignId;
        this.engageId = engageId;
        this.listType = listType;
        this.listId = listId;
        this.listName = listName;
        this.mapToListType = mapToListType;
        this.isRoot = isRoot;
    }


    @TableId(value = "id", type = IdType.AUTO)
    Long id;

    @Builder.Default
    @TableField("profile_type")
    String profileType = "customer";

    @TableField("campaign_id")
    Long campaignId;

    @Builder.Default
    @TableField("engage_id")
    Long engageId = -1L;

    @TableField("list_type")
    String listType;

    @TableField("list_id")
    Long listId;

    @TableField("map_to_list_type")
    String mapToListType;

    @TableField("is_root")
    boolean isRoot;

    @TableField("list_name")
    String listName;

    @TableField("fail_reason")
    String failReason;

    @TableField("execution_time")
    Instant executionTime;

}


