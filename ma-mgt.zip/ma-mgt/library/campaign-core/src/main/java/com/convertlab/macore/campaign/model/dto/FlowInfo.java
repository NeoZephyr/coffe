package com.convertlab.macore.campaign.model.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class FlowInfo {

    String name;
    String list;
    String controlGroup;
    String strategyGroup;
    String strategy = "";
    //Periodicity
    //EnrollFromList
    //Standard
    String triggerType = "EnrollFromList";

    String restartable = "false";
}
