package com.convertlab.macore.campaign.model.dto;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.json.ObjectMapper;
import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;
import net.sf.cglib.beans.BeanMap;

import java.util.Map;

@Data
public class CampaignExcelData {
    public CampaignExcelData(){
        send = 0L;
        failedToSend = 0L;
        delivered = 0L;
        failedToDelivered = 0L;
        received = 0L;
        opened = 0L;
    }
    public static CampaignExcelData build(Map<String,Object> mapData){
        return BeanUtil.toBeanIgnoreError(mapData,CampaignExcelData.class);
    }
    @ExcelProperty(value = "营销活动名称", index = 0)
    private String campaignName;
    @ExcelProperty(value = "营销活动编码", index = 1)
    private String campaignCode;
    @ExcelProperty(value = "沟通策略编码", index = 2)
    private String strategyCode;
    @ExcelProperty(value = "时间/天", index = 3)
    private String executeTime;
    @ExcelProperty(value = "实验对照组", index = 4)
    private String groupType;
    @ExcelProperty(value = "渠道类型", index = 5)
    private String channelType;
    @ExcelProperty(value = "模版名称", index = 6)
    private String templateName;
    @ExcelProperty(value = "总人数", index = 7)
    private Long total;
    @ExcelProperty(value = "发送", index = 8)
    private Long send;
    @ExcelProperty(value = "发送失败", index = 9)
    private Long failedToSend;
    @ExcelProperty(value = "投递", index = 10)
    private Long delivered;
    @ExcelProperty(value = "投递失败", index = 11)
    private Long failedToDelivered;
    @ExcelProperty(value = "接收", index = 12)
    private Long received;
    @ExcelProperty(value = "打开", index = 13)
    private Long opened;
    @ExcelProperty(value = "点击", index = 14)
    private Long clicked;
    @ExcelProperty(value = "engageId", index = 15)
    private Long engageId;
    @ExcelProperty(value = "ListId", index = 16)
    private Long ListId;
}
