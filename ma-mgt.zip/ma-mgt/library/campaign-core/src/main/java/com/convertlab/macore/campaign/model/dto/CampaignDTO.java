package com.convertlab.macore.campaign.model.dto;

import com.convertlab.macore.campaign.common.constants.Constants;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CampaignDTO implements Serializable {
    private Long id;

    private String name;

    private String code;

    private String executionMode;

    private Integer folderId;

    @Builder.Default
    private String type = Constants.NEW_CAMPAIGN_KEY;

    private Long templateId;

    private Long approvalId;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime dateStart;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime dateEnd;

    // 自定义属性 KV
    private Map<String, Object> attrs;

    private Long strategyId;

    private AudienceStrategy audienceStrategy;

    private ChannelStrategy channelStrategy;

    private TimeStrategy timeStrategy;

    private ControlGroupStrategy controlGroupStrategy;

    @Builder.Default
    private Boolean isUptEngage = true;

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AudienceStrategy {
        private String segmentationType;

        private String targetSegmentation;

        private Long filterId;

        private String profileType;

        private Map<String, Object> data;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ChannelStrategy {
        private String strategy;

        private Map<String, Object> data;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TimeStrategy {
        private String strategy;

        private Map<String, Object> data;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ControlGroupStrategy {
        private String strategy;

        private Map<String, Object> data;
    }
}
