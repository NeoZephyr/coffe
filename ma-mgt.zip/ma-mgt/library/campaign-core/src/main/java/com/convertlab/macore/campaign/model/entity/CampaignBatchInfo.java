package com.convertlab.macore.campaign.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.convertlab.foundation.library.mybatisplus.entity.BaseTenantEntity;
import lombok.*;

import java.io.Serializable;

@Data
@EqualsAndHashCode(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TableName(value = "campaign_batch_info",excludeProperty = {"version","creatorId", "creatorName", "dateCreated", "lastUpdated","updaterId", "updaterName"})
public class CampaignBatchInfo  extends BaseTenantEntity implements Serializable {

    @TableId(value = "id", type = IdType.AUTO)
    Long id;

    @Builder.Default
    @TableField("profile_type")
    String profileType = "customer";

    @TableField("campaign_id")
    Long campaignId;

    @Builder.Default
    @TableField("engage_id")
    Long engageId = -1L;

    @TableField("engage_code")
    String engageCode;

    @TableField("flow_id")
    Long flowId;

    @TableField("batch_id")
    String batchId;

    @TableField("channel_type")
    String channelType;

    @TableField("messaging_type")
    String messagingType;

    @TableField("template_id")
    long templateId;

    @TableField("template_name")
    String templateName;

    @TableField("tunnel_id")
    String tunnelId;

    @TableField("channel_instance_id")
    String channelInstanceId;

}


