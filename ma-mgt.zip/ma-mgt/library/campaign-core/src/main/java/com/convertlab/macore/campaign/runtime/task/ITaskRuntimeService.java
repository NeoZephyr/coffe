package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;

public interface ITaskRuntimeService {
    public TaskResult start(CampaignExecutionTask task);

    public void stop(CampaignExecutionTask task);

    public void finish(CampaignExecutionTask task);

    public TaskResult checkProgress(CampaignExecutionTask task);
}
