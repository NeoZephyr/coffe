package com.convertlab.macore.campaign.model.dto;


import lombok.Builder;
import lombok.Data;
import org.springframework.util.Assert;

import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.temporal.WeekFields;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * campaign 报表的查询条件
 *
 */
@Builder
@Data
public class CampaignReportQuery {

    public static final String CAMPAIGN_NAME_DIM = "campaignName";
    public static final String CAMPAIGN_CODE_DIM = "campaignCode";
    public static final String CAMPAIGN_MODE_DIM = "executionMode";
    public static final String ENGAGE_CODE_DIM = "engageCode";
    public static final String ENGAGE_DATEUNIT_DIM = "dateUnit";
    public static final String CONTROL_GROUP_DIM = "groupType";
    public static final String FILTER_NAME_DIM = "filterName";

    //人数还是人次
    Boolean isDistinct;

    /**
     * 报表统计的所有 campaign id
     */
    List<Long> campaignIds;

    /**
     * 报表维度定义
     */
    ReportQueryDimension dimension;

    /**
     * 报表指标
     */
    ReportQueryMetric metric;

    public List<String> getFlatFields() {
        List<String> result = new ArrayList<>();
        if (!dimension.getCampaignDims().isEmpty()){
            Assert.isTrue(!dimension.getCampaignDims().contains(FILTER_NAME_DIM), "not support query dimension contains filterName.");
            result.addAll(dimension.getCampaignDims());
        }
        if (!dimension.getEngageDims().isEmpty()) {
            result.addAll(dimension.getEngageDims());
        }
        if (!dimension.getChannelDims().isEmpty()) {
            result.addAll(dimension.getChannelDims());
        }
        if (dimension.getDateUnit() != EngageDateUnit.NOT_SET) {
            result.add(ENGAGE_DATEUNIT_DIM);
        }
        return result;
    }

    @Data
    public static class ReportQueryDimension {


        public ReportQueryDimension() {
            this.campaignDims = new ArrayList<>();
            this.engageDims = new ArrayList<>();
            this.channelDims = new ArrayList<>();
            this.dateUnit = EngageDateUnit.NOT_SET;
            this.controlGroupDim = ControlGroupType.NOT_SET;
        }

        /**
         * 活动级别的维度: 活动名称, 活动编码, 执行模式，过滤器名称，以及自定义属性
         */
        List<String> campaignDims;

        /**
         * 沟通策略级别的维度:  沟通策略编码，沟通策略自定义属性
         */
        List<String> engageDims;

        /**
         * 渠道级别的维度: 渠道类型(channelType),  模板名称
         */
        List<String> channelDims;


        /**
         *  时间维度
         */
        EngageDateUnit dateUnit;

        /**
         * 对照组: 当前只有 groupName(对照组/实验组)
         */
        ControlGroupType controlGroupDim;
    }


    public CampaignReportQueryOptions createQueryOptions() {
        CampaignReportQueryOptions opt = new CampaignReportQueryOptions();
        opt.controlGroupType = getDimension().controlGroupDim;

        List<String> campaignDims = getDimension().campaignDims;
        List<String> engageDims = getDimension().engageDims;
        List<String> channelDims = getDimension().channelDims;

        opt.needCampaignId = !campaignDims.isEmpty()
                && (campaignDims.contains(CAMPAIGN_CODE_DIM) || campaignDims.contains(CAMPAIGN_NAME_DIM));

        //只有选了campaignCode/campaignName，因为 engageCode 在 campaign中不会重复，所以两个维度共同决定了需要 engageId 维度
        opt.needEngageId = opt.needCampaignId && !engageDims.isEmpty() && engageDims.contains(ENGAGE_CODE_DIM);

        opt.needBatchId = !channelDims.isEmpty();
        opt.needFilterId = !campaignDims.isEmpty() && campaignDims.contains(FILTER_NAME_DIM);
        opt.engageDateUnit = getDimension().getDateUnit();

        opt.eventBased = !channelDims.isEmpty() && !getMetric().getChannelMetrics().isEmpty();
        return opt;
    }

    /**
     * 报表查询选项
     * <p>
     * 因为查询的维度包含的维度可能是分属于多个维度层级的，实际查询中，只需要维度层级信息。
     * 这些维度层级，就是这里的查询选项。
     */
    @Data
    public static class CampaignReportQueryOptions {

        Boolean needCampaignId = false;

        Boolean needEngageId = false;

        Boolean needFilterId = false;

        /**
         * 沟通策略的时间窗口最好是按需查询，只有存在跨天的营销活动时，才需要
         * <p>
         * 沟通策略的时间窗口聚合维度和沟通策略维度哪一个在前面可能是视情况而定的;
         * 目前看，二者在聚合查询中的顺序，只会影响后面的计算逻辑，并不会影响最终的计算结果。所以先按照时间窗口在 Engage level之下处理
         * <p>
         * 时间窗口的聚合维度是在 batchId level 之上的：
         * - 对于多波段和周期性营销来说，为了事件的track，每个营销波次/周期，都会产生一个 batchId
         * - 时间窗口最小的粒度是天，时间窗口是会跨多个 batchId 的
         */
        EngageDateUnit engageDateUnit = EngageDateUnit.NOT_SET;

        /**
         * 模板Id的聚合可以在后面的阶段中关联维度表获取, 查询阶段不需要
         */
        Boolean needBatchId = false;

        /**
         * controlGroup 可以纳入 campaign 或者 engage 的查询条件中
         * 所以这里不再设立独立的 control group 的查询选项
         */
         ControlGroupType controlGroupType = ControlGroupType.NOT_SET;

         Boolean eventBased = false;

         //验证失败的 campaign
         List<Long> violationCampaignIds = Collections.emptyList();

         //进入报表逻辑的 campaign
         List<Long> reportCampaignIds = new ArrayList<>();
    }

    public enum FilterGroupType {
       FILTER_NAME, NOT_SET
    }

    public enum ControlGroupType {
        SET_IN_CAMPAIGN_LEVEL, SET_IN_ENGAGE_LEVEL, NOT_SET;
    }

    public enum EngageDateUnit {

        YEAR_DAY("DD") {
            @Override
            public String formatUnit(String unitTz) {
                LocalDateTime dateTime = LocalDateTime.parse(unitTz, DateTimeFormatter.ISO_DATE_TIME);
                return dateTime.toLocalDate().format(DateTimeFormatter.BASIC_ISO_DATE);
            }
        }, YEAR_WEEK("WW") {
            @Override
            public String formatUnit(String unitTz) {
                LocalDateTime dateTime = LocalDateTime.parse(unitTz, DateTimeFormatter.ISO_DATE_TIME);
                // 获取ISO标准周数和年份
                int weekOfYear = dateTime.get(WeekFields.ISO.weekOfWeekBasedYear());
                int year = dateTime.get(WeekFields.ISO.weekBasedYear());
                return String.format(Locale.US, "%dW%02d", year, weekOfYear);
            }
        }, YEAR_MONTH("MM") {
            @Override
            public String formatUnit(String unitTz) {
                LocalDateTime dateTime = LocalDateTime.parse(unitTz, DateTimeFormatter.ISO_DATE_TIME);
                YearMonth yearMonth = YearMonth.of(dateTime.getYear(), dateTime.getMonthValue());
                return yearMonth.format(DateTimeFormatter.ofPattern("yyyyMM"));
            }
        }, YEAR_QUARTER("Q") {
            @Override
            public String formatUnit(String unitTz) {
                LocalDateTime dateTime = LocalDateTime.parse(unitTz, DateTimeFormatter.ISO_DATE_TIME);
                int quarter = ((dateTime.getMonthValue() - 1) / 3) + 1;
                return String.format(Locale.US, "%dQ%d", dateTime.getYear(), quarter);
            }
        }, YEAR("YY") {
            @Override
            public String formatUnit(String unitTz) {
                LocalDateTime dateTime = LocalDateTime.parse(unitTz, DateTimeFormatter.ISO_DATE_TIME);
                return Integer.toString(dateTime.getYear());
            }
        }, NOT_SET("NA", false) {
            @Override
            public String formatUnit(String unitTz) {
                throw new UnsupportedOperationException("Not support");
            }
        };

        private final String impalaUnit;
        private final Boolean isSet;

        EngageDateUnit(String impalaUnit) {
            this.impalaUnit = impalaUnit;
            this.isSet = true;
        }

        EngageDateUnit(String impalaUnit, boolean isSet) {
            this.impalaUnit = impalaUnit;
            this.isSet = isSet;
        }

        public abstract String formatUnit(String unitTz);

        public String getImpalaUnit() {
            return impalaUnit;
        }

        public boolean isSet() {
            return isSet;
        }
    }

    @Data
    public static class ReportQueryMetric {

        public ReportQueryMetric() {
           this.campaignMetrics = new ArrayList<>();
           this.channelMetrics = new ArrayList<>();
        }
        List<String> campaignMetrics;
        List<String> channelMetrics;
    }
}