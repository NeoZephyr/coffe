package com.convertlab.macore.campaign.model.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CampaignTemplateSaveDTO extends CampaignDTO {

    private Long id;

    private String templateName;

    private String description;
}
