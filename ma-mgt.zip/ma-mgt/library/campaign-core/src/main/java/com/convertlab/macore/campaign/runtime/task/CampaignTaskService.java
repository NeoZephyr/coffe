package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.jdbc.datasource.lookup.DataSourceLookupHelper;
import com.convertlab.macore.campaign.mapper.CampaignExecutionTaskDataMapper;
import com.convertlab.macore.campaign.mapper.CampaignExecutionTaskMapper;
import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTaskData;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

@Service
@Slf4j
@RequiredArgsConstructor
public class CampaignTaskService {

    final CampaignExecutionTaskMapper campaignExecutionTaskMapper;
    final CampaignExecutionTaskDataMapper campaignExecutionTaskDataMapper;

    public CampaignExecutionTask createStopTask(MarketingCampaign campaign) {
        CampaignExecutionTask task = createBaseCampaignTask(campaign);
        task.setTaskType(CampaignExecutionTask.TASK_TYPE_STOP_CAMPAIGN);
        return task;
    }


    public void saveAndUpdateTaskChain(List<CampaignExecutionTask> tasks) {
        this.saveAndUpdateTaskChain(tasks, null);
    }

    private void saveAndUpdateTaskChain(List<CampaignExecutionTask> tasks, List<CampaignExecutionTaskData> datas) {
        DataSourceLookupHelper.withLookupKey("main", () -> {

            //轮询任务列表，如果任务是第一个任务，每个任务的后续任务都设为下一个任务，如果是最后一个任务，则设置后置任务为null。
            for (int i = 0; i < tasks.size(); i++) {
                CampaignExecutionTask task = tasks.get(i);
                if (i == tasks.size() - 1) {
                    task.setNextTaskId(null);
                } else {
                    task.setNextTaskId(tasks.get(i + 1).getId());
                }
                campaignExecutionTaskMapper.upsert(task);
            }
        });
    }

    public CampaignExecutionTask createPeriodicTask(CampaignFullDataDTO campaignFullData) {
        CampaignExecutionTask task = createBaseCampaignTask(campaignFullData.getCampaign());
        //set task type
        task.setTaskType(CampaignExecutionTask.TASK_TYPE_PERIODIC_SCHEDULER);
        return task;
    }


    public CampaignExecutionTask createStartEngageTask(CampaignFullDataDTO campaignFullData, CampaignOutboundEngage engage) {
        CampaignExecutionTask task = createBaseCampaignTask(campaignFullData.getCampaign(), engage);
        //set task type
        task.setTaskType(CampaignExecutionTask.TASK_TYPE_START_ENGAGE);
        return task;
    }

    public CampaignExecutionTask createGenerateFlowTask(CampaignFullDataDTO campaignFullData, CampaignOutboundEngage engage) {
        CampaignExecutionTask task = createBaseCampaignTask(campaignFullData.getCampaign(), engage);
        //set task type
        task.setTaskType(CampaignExecutionTask.TASK_TYPE_GENERATE_FLOW);
        //set engage id
        task.setEngageId(engage.getId());
        return task;
    }

    public CampaignExecutionTask createGenerateListAndFolderTask(CampaignFullDataDTO campaign) {
        CampaignExecutionTask task = createBaseCampaignTask(campaign.getCampaign());
        //set task type
        task.setTaskType(CampaignExecutionTask.TASK_TYPE_GENERATE_LIST_AND_FOLDER);

        return task;
    }

    public CampaignExecutionTask createSegmentationTask(MarketingCampaign campaign, CampaignOutboundEngage engage) {
        CampaignExecutionTask task = createBaseCampaignTask(campaign, engage);
        //set task type
        task.setTaskType(CampaignExecutionTask.TASK_TYPE_SEGMENTATION);
        //set isAsyncRemoteCall
        task.setIsAsyncRemoteCall(true);
        return task;
    }

    private CampaignExecutionTask createBaseCampaignTask(MarketingCampaign campaign){
        return createBaseCampaignTask(campaign, null);
    }
    private CampaignExecutionTask createBaseCampaignTask(MarketingCampaign campaign, CampaignOutboundEngage engage) {
        CampaignExecutionTask task = new CampaignExecutionTask();
        //set campaign id
        task.setCampaignId(campaign.getId());
        //set engage id
        if(engage != null){
            task.setEngageId(engage.getId());
        }
        //set task status not started
        task.setTaskStatus(CampaignExecutionTask.TASK_STATUS_NOT_STARTED);
        return task;
    }

    public void sortByTimeArrange(List<CampaignExecutionTask> taskList){

        Comparator<CampaignExecutionTask> byTriggerDate = Comparator
                .comparing(CampaignExecutionTask::getTaskTriggerDate, Comparator.nullsFirst(Comparator.naturalOrder()));
        taskList.sort(byTriggerDate);
    }

    public void updateTaskStatuses(long campaignId, String currentStatus, String newStatus) {
            List<CampaignExecutionTask> tasks = campaignExecutionTaskMapper.getByCampaignIdAndTaskStatus(campaignId, currentStatus);
            tasks.forEach(task -> {
                    task.setTaskStatus(newStatus);
                    campaignExecutionTaskMapper.updateById(task);
            });
    }

    public List<CampaignExecutionTask> getNotStartedAndScheduledTasks(long campaignId) {
        AtomicReference<List<CampaignExecutionTask>> notStartedAndScheduledTaskByCampaignId = new AtomicReference<>();
        DataSourceLookupHelper.withLookupKey("main", () -> {
            notStartedAndScheduledTaskByCampaignId.set(campaignExecutionTaskMapper.getNotStartedAndScheduledTaskByCampaignId(campaignId));
        });

        return notStartedAndScheduledTaskByCampaignId.get();
    }

    public List<CampaignExecutionTask> getRunningTasks(long campaignId) {
            return campaignExecutionTaskMapper.getRunningTasksByCampaignId(campaignId);
    }

    public CampaignExecutionTask getTask(String taskId){
        final CampaignExecutionTask[] task = {null};
        DataSourceLookupHelper.withLookupKey("main", () -> {
            task[0] = campaignExecutionTaskMapper.selectById(taskId);
        });

        if(task[0] == null){
            throw new BusinessException("Task not found", "");
        }
        return task[0];
    }

    public void updateTaskStatus(CampaignExecutionTask taskDef, String status){
        updateTaskStatus(taskDef, status, null);
    }

    public void updateTaskStatus(CampaignExecutionTask taskDef, String status, String executionInformation){
        DataSourceLookupHelper.withLookupKey("main", () -> {
            if(executionInformation != null){
                taskDef.setExecutionInformation(executionInformation);
            }
            taskDef.setTaskStatus(status);
            campaignExecutionTaskMapper.updateById(taskDef);
        });
    }

    public List<CampaignExecutionTask> getRunningAsyncCallTasks() {
        AtomicReference<List<CampaignExecutionTask>> runningAsyncRemoteCallTaskList = new AtomicReference<>();
        DataSourceLookupHelper.withLookupKey("main", () -> {
            runningAsyncRemoteCallTaskList.set(campaignExecutionTaskMapper.getRunningAsyncRemoteCallTaskList());
        });
        return runningAsyncRemoteCallTaskList.get();
    }

    public List<CampaignExecutionTask> getCampaignExecutionTasks(long campaignId) {
        AtomicReference<List<CampaignExecutionTask>> tasks = new AtomicReference<>();

        DataSourceLookupHelper.withLookupKey("main", () -> {
            tasks.set(campaignExecutionTaskMapper.getByCampaignIdAndTaskStatus(campaignId, CampaignExecutionTask.TASK_STATUS_SCHEDULED));
        });

        return tasks.get();
    }

    public void saveCampaignContextData(long campaignId, String dataKey, String dataValue){
        saveCampaignContextData(campaignId, -1L, dataKey, dataValue);
    }

    public void saveCampaignContextData(long campaignId, long engageId, String dataKey, String dataValue){

        DataSourceLookupHelper.withLookupKey("main", () -> {

            if (dataValue == null) {
                throw new RuntimeException("dataValue is null");
            }

            CampaignExecutionTaskData data = this.getCampaignContextData(campaignId, engageId, dataKey);
            if (data != null) {
                data.setDataValue(dataValue);
                return campaignExecutionTaskDataMapper.updateById(data);
            } else {
                data = new CampaignExecutionTaskData();
                data.setCampaignId(campaignId);
                data.setEngageId(engageId);
                data.setDataKey(dataKey);
                data.setDataValue(dataValue);
                return campaignExecutionTaskDataMapper.insert(data);
            }
        });
    }

    public CampaignExecutionTaskData getCampaignContextData(long campaignId, String dataKey){
        AtomicReference<List<CampaignExecutionTaskData>> data = new AtomicReference<>();
        DataSourceLookupHelper.withLookupKey("main", () -> {
            data.set(campaignExecutionTaskDataMapper.getByCampaignIdAndDataKey(campaignId, dataKey));
        });
        return data.get().isEmpty() ? null : data.get().get(0);
    }

    public CampaignExecutionTaskData getCampaignContextData(long campaignId, long engageId,  String dataKey){
        AtomicReference<List<CampaignExecutionTaskData>> data = new AtomicReference<>();
        DataSourceLookupHelper.withLookupKey("main", () -> {
            data.set(campaignExecutionTaskDataMapper.getByCampaignIdAndEngageIdAndDataKey(campaignId, engageId, dataKey));
        });
        return data.get().isEmpty() ? null : data.get().get(0);
    }


    public void saveTaskData(long campaignId, String taskId, String dataKey, String dataValue){
        saveTaskData(campaignId, -1L, taskId, dataKey, dataValue);
    }

    public void saveTaskData(long campaignId, long engageId, String taskId, String dataKey, String dataValue) {
        DataSourceLookupHelper.withLookupKey("main", () -> {
            List<CampaignExecutionTaskData> taskDatas = null;
            if(StringUtils.isEmpty(taskId)){
               throw new RuntimeException("taskId is null");
            }

            if(StringUtils.isEmpty(dataValue)){
                throw new RuntimeException("dataValue is null");
            }

            taskDatas =  campaignExecutionTaskDataMapper.getByCampainIdAndEngageIdTaskIdAndKey(campaignId, engageId, taskId, dataKey);

            if(taskDatas != null && taskDatas.size() > 0){
                taskDatas.get(0).setDataValue(dataValue);
                return campaignExecutionTaskDataMapper.updateById(taskDatas.get(0));
            }else{
                //保存task data
                CampaignExecutionTaskData taskData = new CampaignExecutionTaskData();
                taskData.setCampaignId(campaignId);
                taskData.setEngageId(engageId);
                taskData.setTaskId(taskId);
                taskData.setDataKey(dataKey);
                taskData.setDataValue(dataValue);
                return campaignExecutionTaskDataMapper.insert(taskData);
            }
        });
    }

    public CampaignExecutionTaskData getTaskData(long campaignId, String taskId,  String dataKey){
        List<CampaignExecutionTaskData> data = campaignExecutionTaskDataMapper.getByCampainIdTaskIdAndKey(campaignId, taskId, dataKey);
        return data.isEmpty() ? null : data.get(0);
    }

    public CampaignExecutionTaskData getTaskData(Long campaignId, Long engageId, String taskId,  String dataKey){
        AtomicReference<List<CampaignExecutionTaskData>> data = new AtomicReference<>();
        DataSourceLookupHelper.withLookupKey("main", () -> {
            data.set(campaignExecutionTaskDataMapper.getByCampainIdAndEngageIdTaskIdAndKey(campaignId, engageId, taskId, dataKey));
        });
        return data.get().isEmpty() ? null : data.get().get(0);
    }

    public List<CampaignExecutionTask> getTasksScheduledBeforeTime(Instant time) {
        AtomicReference<List<CampaignExecutionTask>> tasks = new AtomicReference<>();

        DataSourceLookupHelper.withLookupKey("main", () -> {
            tasks.set(campaignExecutionTaskMapper.getTasksScheduledBeforeTime(time));
        });

        return tasks.get();
    }

     public List<CampaignExecutionTask> getRunningTooLongTimeTasks(java.time.Instant time, int retryCount) {
        AtomicReference<List<CampaignExecutionTask>> tasks = new AtomicReference<>();

        DataSourceLookupHelper.withLookupKey("main", () -> {
            tasks.set(campaignExecutionTaskMapper.getRunningTooLongTimeTasks(time, retryCount));
        });

        return tasks.get();
    }

    public List<CampaignExecutionTask> getRemoteRunningTooLongTimeTasks(java.time.Instant time, int retryCount) {
        AtomicReference<List<CampaignExecutionTask>> tasks = new AtomicReference<>();

        DataSourceLookupHelper.withLookupKey("main", () -> {
            tasks.set(campaignExecutionTaskMapper.getRemoteRunningTooLongTimeTasks(time, retryCount));
        });

        return tasks.get();
    }

    public List<CampaignExecutionTask>  getFailedTasks(java.time.Instant time, int retryCount) {
        AtomicReference<List<CampaignExecutionTask>> tasks = new AtomicReference<>();

        DataSourceLookupHelper.withLookupKey("main", () -> {
            tasks.set(campaignExecutionTaskMapper.getFailedTasks(time, retryCount));
        });

        return tasks.get();
    }


}
