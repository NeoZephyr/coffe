package com.convertlab.macore.campaign.common.utils;

public class NameUtils {

    public static final String MAIN_GROUP = "main_group";
    public static final String FILTERED_GROUP = "filtered_group";
    public static final String EXCLUDED_GROUP = "excluded_group";
    public static final String CONTROL_GROUP = "control_group";
    public static final String TARGET_GROUP = "target_group";

    //定义渠道的事件归属阶段常量 sent, failed_to_send, delivered, failed_to_delivered, received, opened, clicked
    public static final String SENT_EVENT = "sent";
    public static final String FAILED_TO_SEND_EVENT = "failed_to_send";
    public static final String DELIVERED_EVENT = "delivered";
    public static final String FAILED_TO_DELIVERED_EVENT = "failed_to_delivered";
    public static final String FAILED_TO_SEND_OR_DELIVER = "failed_to_send_or_deliver";
    public static final String RECEIVED_EVENT = "received";
    public static final String OPENED_EVENT = "opened";
    public static final String CLICKED_EVENT = "clicked";

    public static final String FAILED_TO_SEND_FIELD = "failedToSendField";
    public static final String FAILED_TO_DELIVERED_FIELD = "failedToDeliveredField";

    //campaign internal etl list
    private static final String SPECIAL_CODE = "_ciel_";
    private static final String CAMPAIGN_PREFIX = "campaign_";
    private static final String ENGAGE_PREFIX = "engage_";

    //获取原始的群组名称
    public static String getMainListName(long campaignId){
        return CAMPAIGN_PREFIX + campaignId + SPECIAL_CODE + MAIN_GROUP ;
    }

    public static String getMainListName(long campaignId, long engageId){
        return getMainListName(campaignId) + getEngagePostfix(engageId);
    }

    //获取过滤后的群组名称
    public static String getFilteredListName(long campaignId){
        return CAMPAIGN_PREFIX + campaignId + SPECIAL_CODE + FILTERED_GROUP ;
    }

    public static String getFilteredListName(long campaignId, long engageId){
        return getFilteredListName(campaignId) + getEngagePostfix(engageId);
    }

    public static String getExcludedListName(long campaignId){
        return CAMPAIGN_PREFIX + campaignId + SPECIAL_CODE + EXCLUDED_GROUP ;
    }

    public static String getExcludedListName(long campaignId, long engageId){
        return getExcludedListName(campaignId) + getEngagePostfix(engageId);
    }

    public static String getControlGroupListName(long campaignId){
        return CAMPAIGN_PREFIX + campaignId + SPECIAL_CODE + CONTROL_GROUP ;
    }

    public static String getControlGroupListName(long campaignId, long engageId){
        return getControlGroupListName(campaignId) + getEngagePostfix(engageId);
    }

    public static String getTargetGroupListName(long campaignId){
        return CAMPAIGN_PREFIX + campaignId + SPECIAL_CODE + TARGET_GROUP;
    }

    public static String getTargetGroupListName(long campaignId, long engageId){
        return getTargetGroupListName(campaignId) + getEngagePostfix(engageId);
    }

    public static String getEngagePostfix(long engageId){
        return "_" + ENGAGE_PREFIX + engageId;
    }

    public static String getFlowName(long campaignId, long engageId){
        return CAMPAIGN_PREFIX + campaignId + SPECIAL_CODE + getEngagePostfix(engageId);
    }


}
