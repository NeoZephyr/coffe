package com.convertlab.macore.campaign.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CreateListRequest {
    String name;
    boolean isExternal= true;
    String description;
}
