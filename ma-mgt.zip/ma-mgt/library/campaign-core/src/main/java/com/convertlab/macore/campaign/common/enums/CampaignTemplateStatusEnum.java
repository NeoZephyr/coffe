package com.convertlab.macore.campaign.common.enums;

import lombok.Getter;

@Getter
public enum CampaignTemplateStatusEnum {

    ENABLED("enabled", "启用"),
    DISABLED("disabled", "禁用");

    private final String name;
    private final String desc;

    CampaignTemplateStatusEnum(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }

    public static boolean contains(String code) {
        for (CampaignTemplateStatusEnum templateEnum : CampaignTemplateStatusEnum.values()) {
            if (templateEnum.name.equals(code)) {
                return true;
            }
        }
        return false;
    }
}
