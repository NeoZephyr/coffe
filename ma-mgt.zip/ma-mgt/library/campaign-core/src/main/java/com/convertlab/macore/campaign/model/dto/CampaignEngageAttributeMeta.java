package com.convertlab.macore.campaign.model.dto;

import com.alibaba.excel.util.StringUtils;
import com.convertlab.foundation.library.gdmmeta.model.FieldType;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.gdmmeta.model.ImmutableGdmField;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.BizObjectExtAttrMeta;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.base.BizObjectPropBizMeta;
import com.convertlab.macore.mamgt.common.utils.NamingUtils;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@ToString
@EqualsAndHashCode(callSuper=false)
@Slf4j
public class CampaignEngageAttributeMeta extends BizObjectExtAttrMeta<CampaignEngageAttributeMeta.EngageExtPropMeta> {

    //按照目前产品设定，最多允许10个启用的扩展属性
    public static final Integer MAX_PROP_SIZE =30;

    /**
     * 新建bizObjectExtAttrMeta对象的时候，需要根据实际表结构，创建 EngageExtPropMeta 对象
     * 对于 campaign_engage_attribute table，有 attr1~15 个可扩展字段，
     * 在初始化的时候，就要创建 enabled == false 的EngageExtPropMeta 对象，并添加到 props 中
     */
    public CampaignEngageAttributeMeta() {
        initProps();
    }

    @Override
    public void initProps() {
        //实际对于 campaign_engage_attribute table，有 attr1~15 个可扩展字段，
        final int propSize = MAX_PROP_SIZE;
        this.props = new ArrayList<>(propSize + 3);

        this.props.addAll(getSysProps());

        for (int i = 1; i <= MAX_PROP_SIZE; i++) {
            String columnName = "attr" + i;
            EngageExtPropMeta engageExtPropMeta = new EngageExtPropMeta();
            engageExtPropMeta.setColumnName(columnName);
            engageExtPropMeta.setEnabled(false); //没有启用
            engageExtPropMeta.setHasOptions(false); //作为有没有被前端设置的标志
            engageExtPropMeta.setIsSystem(false);
            engageExtPropMeta.setIsVirtual(false);
            engageExtPropMeta.setIsAttr(true);

            this.props.add(engageExtPropMeta);
        }
    }

    @JsonIgnore
    public List<EngageExtPropMeta> getSysProps() {
        //system fields : id, campaign_id, engage_id
        return Stream.of("id", "campaign_id", "engage_id").map(fieldName -> {
            EngageExtPropMeta sysField = new EngageExtPropMeta();
            sysField.setIsAttr(false);
            sysField.setIsSystem(true);
            sysField.setIsVirtual(false);
            sysField.setColumnName(fieldName);
            sysField.setHasOptions(false);
            sysField.setFieldId(fieldName);
            sysField.setName(fieldName);
            return sysField;
        }).collect(Collectors.toList());
    }

    List<EngageExtPropMeta> props;

    /**
     * 保存成 GdmEntity 时，需要为 GdmField 的 columnName,
     * 在 GdmTable 可用的 columnList 中分配一个没有被使用的 columnName.
     *
     * 目前 campaign_engage_attribute 有  attr1 ~ attr15 一共 15 个可扩展的字段。
     * 规划先用 attr1 ~ attr10
     *
     * @param newFieldTypeNamesMap 例如： `<FieldType.String, ["c_mot", "c_channel", "c_vip_group"]>`
     *
     */
    @JsonIgnore
    @Override
    public List<GdmField> allocatePropsAndCreateGdmFields(Map<FieldType, List<String>> newFieldTypeNamesMap) {

        Assert.isTrue(newFieldTypeNamesMap.size() == 1 && newFieldTypeNamesMap.containsKey(FieldType.String),
                "campaign_engage_attribute 只有 FieldType.String 类型");

        //campaign_engage_attribute 只有 FieldType.String 类型
        List<String> newFieldIdList = newFieldTypeNamesMap.get(FieldType.String);
        if (newFieldIdList == null || newFieldIdList.isEmpty()) {
            throw new IllegalArgumentException("newFieldIdList is empty");
        }

        // 剩余可以分配的扩展属性需要够用
        List<EngageExtPropMeta> availableProps = props.stream()
                .filter(prop -> prop.getIsAttr() && !prop.getHasOptions()).collect(Collectors.toList());
        if (availableProps.size() < newFieldIdList.size()) {
            // IllegalStateException: not enough available props
            throw new IllegalStateException("not enough available props");
        }

        // 启用的扩展属性不能和新增的扩展属性重复，抛出的错误信息需要包含重复的属性
        List<EngageExtPropMeta> enabledProps = props.stream()
                .filter(prop -> prop.getIsAttr() && prop.getEnabled()).collect(Collectors.toList());
        List<String> duplicatedFieldIds = enabledProps.stream()
                .filter(prop -> newFieldIdList.contains(prop.getFieldId()))
                .map(BizObjectPropBizMeta::getName)
                .collect(Collectors.toList());
        if (!duplicatedFieldIds.isEmpty()) {
            throw new IllegalArgumentException("already existed props: " + duplicatedFieldIds);
        }

        //为新增的扩展属性分配 columnName
        for (String newFieldName : newFieldIdList) {
            props.stream().filter(prop -> prop.getIsAttr() && !prop.getHasOptions()).findFirst().ifPresent(prop -> {
                prop.setName(newFieldName);
                prop.setFieldId(newFieldName);
                prop.setEnabled(true);
                prop.setHasOptions(true);
            });
        }

        return props.stream().filter(meta -> meta.getHasOptions() || meta.getIsSystem())
                .map(EngageExtPropMeta::createGdmField).collect(Collectors.toList());
    }

    @Override
    public void recycleAllocatedProps(Map<FieldType, List<String>> tobeRemovedFieldNameMap) {

        Assert.isTrue(tobeRemovedFieldNameMap.size() == 1 && tobeRemovedFieldNameMap.containsKey(FieldType.String),
                "campaign_engage_attribute 只有 FieldType.String 类型");
        //campaign_engage_attribute 只有 FieldType.String 类型

        List<String> fieldNameList = tobeRemovedFieldNameMap.get(FieldType.String);
        if (fieldNameList == null || fieldNameList.isEmpty()) {
            throw new IllegalArgumentException("newFieldIdList is empty");
        }

        //剩余的props需要包含要删除的fieldName
        Set<String> currentFieldNameSet = props.stream().map(BizObjectPropBizMeta::getName).collect(Collectors.toSet());

        List<String> notExistsFieldNames = fieldNameList.stream()
                .filter(fieldName -> !currentFieldNameSet.contains(fieldName)).collect(Collectors.toList());
        if(!notExistsFieldNames.isEmpty()) {
            log.warn("Not found fields in entity: " + notExistsFieldNames);
        }

        //从当前的props中，删除要删除的fieldName
        for(EngageExtPropMeta prop: props) {
            if(fieldNameList.contains(prop.getName())) {
                log.info("delete bizObj prop: " + prop.getName());
                prop.setRequired(false);
                prop.setEnabled(false);
                prop.setFieldId(null);
                prop.setName(null);
                prop.setHasOptions(false);
                prop.setOptions(null);
            }
        }
    }


    @Data
    @ToString
    @NoArgsConstructor
    @EqualsAndHashCode(callSuper=false)
    public static class EngageExtPropMeta extends BizObjectPropBizMeta {
        //是否必填
        boolean required;

        //内部分配的时候使用，不会给到前端
        String columnName;

        //状态：启用中，已停用 ,使用 enabled 字段



        @JsonIgnore
        public GdmField createGdmField() {
            if (StringUtils.isBlank(columnName)) {
                throw new IllegalStateException("columnName is empty");
            }
            String unifiedName = NamingUtils.toUnderScoreCase(name);
            return ImmutableGdmField.builder()
                    .fieldName(unifiedName)
                    .fieldType( Boolean.TRUE.equals(this.isSystem) ? FieldType.Long : FieldType.String)
                    .dbColumnName(columnName)
                    .build();
        }

        public void updateProp(EngageExtPropMeta input) {
            this.required = input.required;
            this.enabled = input.enabled;
            this.label = input.label;
            this.options = input.options;
            this.hasOptions = true;
        }
    }
}
