package com.convertlab.macore.campaign.runtime.taskchain;

import com.convertlab.macore.campaign.model.dto.CronDTO;

import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.List;

@FunctionalInterface
public interface TriggerCalculator {
    List<ZonedDateTime> apply(CronDTO cron, Instant initialTime);

}