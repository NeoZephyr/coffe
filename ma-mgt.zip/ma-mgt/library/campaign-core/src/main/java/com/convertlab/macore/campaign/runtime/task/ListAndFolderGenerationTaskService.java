package com.convertlab.macore.campaign.runtime.task;


import com.convertlab.macore.campaign.common.utils.AudienceStrategyConstants;
import com.convertlab.macore.campaign.common.utils.ControlGroupStrategyConstants;
import com.convertlab.macore.campaign.common.utils.FolderNameUtils;
import com.convertlab.macore.campaign.common.utils.NameUtils;
import com.convertlab.macore.campaign.model.dto.*;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignListInfo;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
@Slf4j
@AllArgsConstructor

/**
 * 主要用于生成空的群组，以及群组对应的文件夹，以及自动流对应的文件夹。
 */
public class ListAndFolderGenerationTaskService extends AbstractTaskRuntimeService {

    private final CampaignListInfoService campaignListInfoService;
    private final MaCoreService maCoreService;

    @Override
    public TaskResult onStart(CampaignExecutionTask task) {

        //load Campaign setting data
        CampaignFullDataDTO campaignFullData = campaignService.getCampaignFullData(task.getCampaignId());

        //set status to preparing.
        changeEngageStatusToPreparing(campaignFullData);

        //create list folder and flow folder
        FolderDTO listFolder = this.createFolder(campaignFullData);

        //generate campaign list info
        List<CampaignListInfo> campaignListInfos = genCampaignListInfo(campaignFullData);

        //将campaignlistInfo保存到数据库中
        campaignListInfoService.saveListInfo(campaignListInfos);

        //调用customer服务创建list,后续需要改为调用cdp api
        createListAndUpdateListIdToEngageAndListInfo(campaignFullData, listFolder.getId());

        //finish 任务
        return new TaskResult(true);
    }

    void changeEngageStatusToPreparing(CampaignFullDataDTO campaignFullData){

        campaignFullData.getOutboundEngageList().forEach(outboundEngage -> {
                campaignService.updateEngageStatus(outboundEngage.getId(), CampaignOutboundEngage.ENGAGE_STATUS_PREPARING);
        });
    }

    void createListAndUpdateListIdToEngageAndListInfo(CampaignFullDataDTO campaignFullData, Long listFolderId){

        //reload list info from database
        List<CampaignListInfo> listInfo = campaignListInfoService.loadListInfo(campaignFullData.getCampaign().getId());

        //loop list info and create list and update list info with list id.
        listInfo.forEach(list -> {
            if(!list.isRoot() && StringUtils.isEmpty(list.getMapToListType()) && list.getListId() == null) {
                    //创建群组，并更新listInfo
                    ListDTO listDTO = maCoreService.upsertList(list.getListName(), listFolderId, list.getListName() + "_" + list.getListType(), campaignFullData.getCampaign());
                    //更新ListId
                    list.setListId(listDTO.getId());
                    campaignListInfoService.updateById(list);
            }
         });

        //查询所有的outbound engage
        List<CampaignOutboundEngage> outboundEngageList = this.campaignService.getEngageListByCampaignId(campaignFullData.getCampaign().getId());
        //轮询outboundEngageList，根据名字从listResults找到id，然后更新到outboundEngage
        for (CampaignOutboundEngage outboundEngage : outboundEngageList) {
            //根据campaignId以及outboundEngageId，查找对应的listInfo
            List<CampaignListInfo> engageListInfo = campaignListInfoService.selectByCampaignIdAndEngageId(outboundEngage.getCampaignId(), outboundEngage.getId());
            CampaignListInfo info = campaignListInfoService.findListInfoByType(engageListInfo, NameUtils.TARGET_GROUP);

            if(info != null && !StringUtils.isEmpty(info.getMapToListType())){
                info = campaignListInfoService.findListInfoByType(engageListInfo, info.getMapToListType());
            }

            if(info == null){
                throw new RuntimeException("target group not found");
            }

            outboundEngage.setListId(info.getListId());
            campaignService.updateEngageById(outboundEngage);
        }
     }

    /**
     * 创建群组目录和流程目录。
     * @param campaignFullData
     * @return
     */
    FolderDTO createFolder(CampaignFullDataDTO campaignFullData){
        //创建群组目录
        String listFolderName = FolderNameUtils.getCampaignListFolderName(campaignFullData.getCampaign().getId());
        FolderDTO listFolder = maCoreService.upsertFolder(listFolderName, "list", campaignFullData.getCampaign());

        //创建自动流目录
        String flowFolderName = FolderNameUtils.getCampaignFlowFolderName(campaignFullData.getCampaign().getId());
        FolderDTO flowFolder = maCoreService.upsertFolder(flowFolderName, "flow", campaignFullData.getCampaign());

         //saveTaskData
        campaignTaskService.saveCampaignContextData(campaignFullData.getCampaign().getId(), DATA_KEY_LIST_FOLDER_ID, String.valueOf(listFolder.getId()));
        campaignTaskService.saveCampaignContextData(campaignFullData.getCampaign().getId(), DATA_KEY_FLOW_FOLDER_ID, String.valueOf(flowFolder.getId()));

        return listFolder;
    }

    @Override
    public void onFinish(CampaignExecutionTask task) {

    }



    List<CampaignListInfo> genCampaignListInfo(CampaignFullDataDTO currentCampaign)
    {
        //获得segmentationStrategy
        String segmentationStrategy = currentCampaign.getAudienceStrategy().getSegmentationType();

        List<CampaignListInfo> listInfo = new ArrayList<>();

        //switch case segmentationStrategy
        switch (segmentationStrategy) {
            case AudienceStrategyConstants.MANUAL_SPECIFIED_SEGMENTATION:
                //创建活动群组
                listInfo = generateManualSpecifiedSegmentationListInfo(currentCampaign);
                break;
            case AudienceStrategyConstants.MANUAL_PERCENTAGE_SEGMENTATION:
            case AudienceStrategyConstants.MANUAL_QUANTITY_SEGMENTATION:
            case AudienceStrategyConstants.PSYCHOGRAPHIC_SEGMENTATION:
            case AudienceStrategyConstants.MULTIPLE_WAVED_SEGMENTATION:
                listInfo = generateSplitSegmentationListInfo(currentCampaign);
                break;
            default:
                break;
        }

        return listInfo;
    }


    List<CampaignListInfo> generateSplitSegmentationListInfo(CampaignFullDataDTO currentCampaign) {
        List<CampaignListInfo> listInfo = new ArrayList<>();
        Long filterId = currentCampaign.getAudienceStrategy().getFilterId();
        //首先加工campaign级别的group
        long manualSpecifiedListId = currentCampaign.getMainTargetAudience().get(0).getListId();
        CampaignListInfo mainGroup = this.createMainGroup(currentCampaign.getCampaign().getId());
        mainGroup.setListId(manualSpecifiedListId);
        mainGroup.setRoot(true);
        listInfo.add(mainGroup);

        long campaignId = currentCampaign.getCampaign().getId();
        boolean hasControlGroup = ControlGroupStrategyConstants.CONTROL_AT_CAMPAIGN.equals(currentCampaign.getAudienceStrategy().getControlGroupStrategy())
                && Double.valueOf(currentCampaign.getAudienceStrategy().getControlGroupPercentage()) > 0;

        // 先检查是否有filterId并处理，因为无论如何，如果有filterId，都要添加filter和excluded组
        if (filterId != null && filterId > 0) {
            listInfo.add(createFilteredGroup(campaignId));
            listInfo.add(createExcludedGroup(campaignId));
        }

        if (hasControlGroup) {
            // 控制组逻辑
            listInfo.add(createControlGroup(campaignId));
            listInfo.add(createTargetGroup(campaignId));
        } else {
            // 目标组逻辑，注意到在有filter的情况下已经添加了filtered和excluded组
            CampaignListInfo targetGroup = this.createTargetGroup(campaignId);
            if (filterId != null && filterId > 0) {
                targetGroup.setMapToListType(NameUtils.FILTERED_GROUP);
            } else {
                targetGroup.setMapToListType(NameUtils.MAIN_GROUP);
            }
            listInfo.add(targetGroup);
        }

        //其次加工engage级别的group
        currentCampaign.getOutboundEngageList().forEach(outboundEngage -> {
            //添加MainGroup
            listInfo.add(createMainGroup(currentCampaign.getCampaign().getId(), outboundEngage.getId()));

            if (ControlGroupStrategyConstants.CONTROL_AT_Engage.equals(outboundEngage.getControlGroupStrategy()) && getControlGroupPercentage(outboundEngage) > 0)
            {
                //如果控制组不为空，且百分比大于0,添加控制组和目标组
                listInfo.add(createControlGroup(currentCampaign.getCampaign().getId(), outboundEngage.getId()));
                listInfo.add(createTargetGroup(currentCampaign.getCampaign().getId(), outboundEngage.getId()));
            }else{
                //如果控制组为空，则目标组等于mainGroup
                CampaignListInfo targetGroup = this.createTargetGroup(currentCampaign.getCampaign().getId(), outboundEngage.getId());
                targetGroup.setMapToListType(NameUtils.MAIN_GROUP);
                listInfo.add(targetGroup);
            }

        });

        return listInfo;
    }

    double getControlGroupPercentage(CampaignOutboundEngage outboundEngage){
        try {
            JsonNode rootNode = objectMapper.readTree(outboundEngage.getControlGroupData());
            JsonNode percentageNode = rootNode.get("percentage");
            return percentageNode.doubleValue();
        }catch (Exception e){
            throw new RuntimeException("Failed to parse controlGroupData: " + outboundEngage.getControlGroupData(), e);
        }
    }

    List<CampaignListInfo> generateManualSpecifiedSegmentationListInfo(CampaignFullDataDTO currentCampaign) {
        List<CampaignListInfo> listInfo = new ArrayList<>();
        Long filterId = currentCampaign.getAudienceStrategy().getFilterId();

        currentCampaign.getOutboundEngageList().forEach(outboundEngage -> {
            //添加MainGroup
            long manualSpecifiedListId = getManualSpecifiedListId(outboundEngage);
            CampaignListInfo mainGroup = this.createMainGroup(currentCampaign.getCampaign().getId(), outboundEngage.getId());
            mainGroup.setListId(manualSpecifiedListId);
            mainGroup.setRoot(true);
            listInfo.add(mainGroup);

            boolean hasControlGroup = ControlGroupStrategyConstants.CONTROL_AT_Engage.equals(outboundEngage.getControlGroupStrategy())
                    && Double.valueOf(getControlGroupPercentage(outboundEngage)) > 0;

            if(filterId != null && filterId > 0){
                //如果有filter, 则添加filtergroup和excludedgroup，且此时目标组等于filtergroup
                listInfo.add(createFilteredGroup(currentCampaign.getCampaign().getId(), outboundEngage.getId()));
                listInfo.add(createExcludedGroup(currentCampaign.getCampaign().getId(), outboundEngage.getId()));
            }

            if(hasControlGroup){
                //如果控制组不为空，添加控制组和目标组
                listInfo.add(createControlGroup(currentCampaign.getCampaign().getId(), outboundEngage.getId()));
                listInfo.add(createTargetGroup(currentCampaign.getCampaign().getId(), outboundEngage.getId()));
            }
            else {
                // 目标组逻辑，注意到在有filter的情况下已经添加了filtered和excluded组
                CampaignListInfo targetGroup = this.createTargetGroup(currentCampaign.getCampaign().getId(), outboundEngage.getId());
                if (filterId != null && filterId > 0) {
                    targetGroup.setMapToListType(NameUtils.FILTERED_GROUP);
                } else {
                    targetGroup.setMapToListType(NameUtils.MAIN_GROUP);
                }
                listInfo.add(targetGroup);
            }

        });
        return listInfo;
    }

    CampaignListInfo createCampaignListInfo(long campaignId, String listType, String listName) {
        CampaignListInfo campaignListInfo = new CampaignListInfo();
        campaignListInfo.setCampaignId(campaignId);
        campaignListInfo.setListType(listType);
        campaignListInfo.setListName(listName);
        return campaignListInfo;
    }

    CampaignListInfo createCampaignListInfo(long campaignId, long engageId, String listType, String listName) {
        CampaignListInfo campaignListInfo = createCampaignListInfo(campaignId, listType, listName);
        campaignListInfo.setEngageId(engageId);
        return campaignListInfo;
    }

    CampaignListInfo createMainGroup(long campaignId) {
        return createCampaignListInfo(campaignId, NameUtils.MAIN_GROUP, NameUtils.getMainListName(campaignId));
    }

    CampaignListInfo createMainGroup(long campaignId, long engageId) {
        return createCampaignListInfo(campaignId, engageId, NameUtils.MAIN_GROUP, NameUtils.getMainListName(campaignId, engageId));
    }

    CampaignListInfo createTargetGroup(long campaignId) {
        return createCampaignListInfo(campaignId, NameUtils.TARGET_GROUP, NameUtils.getTargetGroupListName(campaignId));
    }

    CampaignListInfo createTargetGroup(long campaignId, long engageId) {
        return createCampaignListInfo(campaignId, engageId, NameUtils.TARGET_GROUP, NameUtils.getTargetGroupListName(campaignId, engageId));
    }

    CampaignListInfo createControlGroup(long campaignId) {
        return createCampaignListInfo(campaignId, NameUtils.CONTROL_GROUP, NameUtils.getControlGroupListName(campaignId));
    }

    CampaignListInfo createControlGroup(long campaignId, long engageId) {
        return createCampaignListInfo(campaignId, engageId, NameUtils.CONTROL_GROUP, NameUtils.getControlGroupListName(campaignId, engageId));
    }

    CampaignListInfo createFilteredGroup(long campaignId) {
        return createCampaignListInfo(campaignId, NameUtils.FILTERED_GROUP, NameUtils.getFilteredListName(campaignId));
    }

    CampaignListInfo createFilteredGroup(long campaignId, long engageId) {
        return createCampaignListInfo(campaignId, engageId, NameUtils.FILTERED_GROUP, NameUtils.getFilteredListName(campaignId, engageId));
    }

    CampaignListInfo createExcludedGroup(long campaignId) {
        return createCampaignListInfo(campaignId, NameUtils.EXCLUDED_GROUP, NameUtils.getExcludedListName(campaignId));
    }

    CampaignListInfo createExcludedGroup(long campaignId, long engageId) {
        return createCampaignListInfo(campaignId, engageId, NameUtils.EXCLUDED_GROUP, NameUtils.getExcludedListName(campaignId, engageId));
    }

    long getManualSpecifiedListId(CampaignOutboundEngage outboundEngage){
        if (outboundEngage == null) {
            throw new IllegalArgumentException("outboundEngage is null");
        }
        if (!AudienceStrategyConstants.MANUAL_SPECIFIED_SEGMENTATION.equals(outboundEngage.getAudienceStrategy())) {
            throw new IllegalArgumentException("Audience strategy is not MANUAL_SPECIFIED_SEGMENTATION");
        }
        try {
            JsonNode rootNode = objectMapper.readTree(outboundEngage.getAudienceData());
            return rootNode.path("listId").asLong(); // Using 'path' instead of 'get' to avoid NPE
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Failed to parse audienceData: " + outboundEngage.getAudienceData(), e);
        }
    }

    @Override
    public TaskResult checkProgress(CampaignExecutionTask task) {
        return new TaskResult(false);
    }
}
