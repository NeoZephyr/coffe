package com.convertlab.macore.campaign.model.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.convertlab.foundation.library.mybatisplus.entity.BaseTenantEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.Instant;

@Data
@EqualsAndHashCode(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TableName(value = "campaign_log", excludeProperty = {"version", "creatorId", "creatorName", "ownerId", "deptCode", "dateCreated", "lastUpdated","updaterId", "updaterName"})
public class CampaignLog extends BaseTenantEntity implements Serializable {

    @TableId("id")
    Long id;

    @TableField("campaign_id")
    Long campaignId;

    @TableField("engage_code")
    String engageCode;

    @TableField("profile_type")
    String profileType;

    @TableField("profile_id")
    String profileId;

    @TableField("date_log")
    Instant dateLog;

    @TableField("batch_id")
    String batchId;

    @TableField("phase_code")
    String phaseCode;

    @TableField("phase_status")
    String phaseStatus;

    @TableField("phase_failed_reason")
    String phaseFailedReason;

    @TableField("filter_id")
    Long filterId;

    @TableField("filter_description")
    String filterDescription;

    @TableField("control_group_description")
    String controlGroupDescription;

}
