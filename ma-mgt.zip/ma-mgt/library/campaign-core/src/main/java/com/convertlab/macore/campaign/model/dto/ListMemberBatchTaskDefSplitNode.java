package com.convertlab.macore.campaign.model.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ListMemberBatchTaskDefSplitNode {
    private String controlGroupListName;
    private Double controlGroupPercentage;
    private String targetGroupListName;
    private Double percentage;
    private Integer quantity;
    private Boolean remaining;
    private Boolean notInCondition;
    private Map<String, Object> condition;
}
