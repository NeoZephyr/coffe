package com.convertlab.macore.campaign.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.macore.campaign.mapper.MainTargetAudienceMappingMapper;
import com.convertlab.macore.campaign.model.entity.CampaignMainTargetAudienceMapping;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
@DataSourceLookup("main")
public class MainTargetAudienceService extends ServiceImpl<MainTargetAudienceMappingMapper, CampaignMainTargetAudienceMapping> {

    public boolean saveMainTargetAudience(Long campaignId, Long strategyId, String segmentation) {
        List<CampaignMainTargetAudienceMapping> mainList = buildMainTargetAudience(campaignId, strategyId, segmentation);
        if (CollUtil.isNotEmpty(mainList)) {
            return this.saveBatch(mainList);
        }
        return false;
    }

    public boolean updateMainTargetAudience(Long campaignId, Long strategyId, String segmentation) {
        this.lambdaUpdate().eq(CampaignMainTargetAudienceMapping::getCampaignId, campaignId)
                .eq(CampaignMainTargetAudienceMapping::getAudienceStrategyId, strategyId).remove();

        List<CampaignMainTargetAudienceMapping> mainList = buildMainTargetAudience(campaignId, strategyId, segmentation);
        if (CollUtil.isNotEmpty(mainList)) {
            return this.saveBatch(mainList);
        }
        return false;
    }

    public List<CampaignMainTargetAudienceMapping> buildMainTargetAudience(Long campaignId, Long strategyId, String segmentation) {
        return Arrays.stream(segmentation.split(","))
                .distinct().map(segment -> CampaignMainTargetAudienceMapping.builder()
                        .campaignId(campaignId)
                        .audienceStrategyId(strategyId)
                        .listId(Long.valueOf(segment))
                        .build()).collect(Collectors.toList());
    }

    public void copyMainTargetAudience(Long campaignId, Long copyCampaignId, Long copyStrategyId) {
        List<CampaignMainTargetAudienceMapping> mainTargetAudienceList = this.getMainTargetAudience(campaignId);
        if (CollUtil.isNotEmpty(mainTargetAudienceList)) {
            List<CampaignMainTargetAudienceMapping> copyMainTargetAudienceList = mainTargetAudienceList.stream()
                    .map(item -> BeanUtil.copyProperties(item, CampaignMainTargetAudienceMapping.class, "id", "tenantId", "campaignId"))
                    .peek(item -> {
                        item.setCampaignId(copyCampaignId);
                        item.setAudienceStrategyId(copyStrategyId);
                    }).collect(Collectors.toList());

            super.saveBatch(copyMainTargetAudienceList);
        }
    }

    public List<CampaignMainTargetAudienceMapping> getMainTargetAudience(Long campaignId) {
        return this.lambdaQuery().eq(CampaignMainTargetAudienceMapping::getCampaignId, campaignId).list();
    }
}
