package com.convertlab.macore.campaign.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.campaign.model.entity.CampaignBatchInfo;
import com.convertlab.macore.campaign.model.entity.CampaignChannelEventStage;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;
import java.util.Map;

@Mapper
public interface CampaignChannelEventStageMapper extends BaseMapper<CampaignChannelEventStage> {

    @Select({"<script>",
            "SELECT * FROM campaign_channel_event_stage t",
            "</script>"})
    List<CampaignChannelEventStage> selectAll();

    @Select({"<script>",
            "SELECT * FROM campaign_channel_event_stage t",
            "WHERE t.messaging_type = #{messagingType}",
            "</script>"})
    CampaignChannelEventStage selectByMessagingType( @Param("messagingType")Long messagingType);

    @Update({"<script>",
            "UPDATE campaign_channel_event_stage SET ",
            " <foreach collection=\"props\" index=\"key\" item=\"value\" separator=\",\">",
            "         ${key} = #{value}",
            "  </foreach>",
            " WHERE id = #{id}",
            "</script>"})
    int updateById(@Param("id") Long id, @Param("props") Map<String, String> props);
}