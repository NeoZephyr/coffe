package com.convertlab.macore.campaign.runtime;

import com.alibaba.ttl.threadpool.TtlExecutors;
import com.convertlab.data.job.core.biz.model.BizJobRunResult;
import com.convertlab.data.job.core.biz.model.ReturnT;
import com.convertlab.data.job.core.context.ClJobHelper;
import com.convertlab.data.job.core.handler.annotation.ClJob;
import com.convertlab.data.job.core.util.data.BizJobClient;
import com.convertlab.data.job.core.util.data.JobData;
import com.convertlab.foundation.library.business.feature.FeatureClient;
import com.convertlab.foundation.library.business.feature.QueryToggleTenantsResponse;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.principal.context.PrincipalContextHolder;
import com.convertlab.foundation.library.support.MdcTaskDecorator;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.runtime.task.*;
import com.convertlab.macore.campaign.runtime.taskchain.TimeStrategyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.NotImplementedException;
import org.springframework.core.task.TaskDecorator;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

@Service
@Slf4j
@RequiredArgsConstructor
public class TaskServiceFactory{

    final ListAndFolderGenerationTaskService listAndFolderGenerationTaskService;
    final FlowGenerationTaskService flowGenerationTaskService;
    final EnageStartTaskService enageStartTaskService;
    final StopCampaignTaskService stopCampaignTaskService;
    final SegmentationGenerationTaskService segmentationGenerationTaskService;
    final PeriodicSchedulerTaskService periodicSchedulerTaskService;
    private Map<String, ITaskRuntimeService> taskTypeToServiceMap;

    @PostConstruct
    public void init() {
        taskTypeToServiceMap = new HashMap<>();
        taskTypeToServiceMap.put(CampaignExecutionTask.TASK_TYPE_GENERATE_LIST_AND_FOLDER, listAndFolderGenerationTaskService);
        taskTypeToServiceMap.put(CampaignExecutionTask.TASK_TYPE_SEGMENTATION, segmentationGenerationTaskService);
        taskTypeToServiceMap.put(CampaignExecutionTask.TASK_TYPE_GENERATE_FLOW, flowGenerationTaskService);
        taskTypeToServiceMap.put(CampaignExecutionTask.TASK_TYPE_START_ENGAGE, enageStartTaskService);
        taskTypeToServiceMap.put(CampaignExecutionTask.TASK_TYPE_STOP_CAMPAIGN, stopCampaignTaskService);
        taskTypeToServiceMap.put(CampaignExecutionTask.TASK_TYPE_PERIODIC_SCHEDULER, periodicSchedulerTaskService);
    }

    public ITaskRuntimeService getTaskService(CampaignExecutionTask taskDef) {
        ITaskRuntimeService taskRuntimeService = taskTypeToServiceMap.get(taskDef.getTaskType());
        if (taskRuntimeService == null) {
            throw new BusinessException("Task type not supported: " + taskDef.getTaskType(), "");
        }
        return taskRuntimeService;
    }

}
