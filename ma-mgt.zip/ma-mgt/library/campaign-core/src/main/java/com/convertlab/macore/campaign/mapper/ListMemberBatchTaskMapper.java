package com.convertlab.macore.campaign.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.campaign.model.dto.FlowDTO;
import com.convertlab.macore.campaign.model.dto.FolderDTO;
import com.convertlab.macore.campaign.model.dto.ListDTO;
import com.convertlab.macore.campaign.model.dto.SaveFlowResponse;
import com.convertlab.macore.campaign.service.legacy.cms.model.ListMemberBatchTask;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

//TODO 未来需要封装到CDP接口中，以本地sdk方式存在。
@Mapper
public interface ListMemberBatchTaskMapper  extends BaseMapper<ListMemberBatchTask> {

    @Select("select id,status from list_member_batch_task t " +
            "WHERE t.id = #{id}")
    ListMemberBatchTask selectById(@Param("id")String id);

    //根据id list，查找list member batch task
    @Select({"<script>",
            "select id, status from list_member_batch_task t",
            "WHERE id in <foreach item='item' index='index' collection='idList' open='(' separator=',' close=')'>#{item}</foreach></script>"})
    List<ListMemberBatchTask> selectByIdList(@Param("idList")List<String> idList);

    //根据namePattern,查询所有的List;
    @Select("select id, name, status from list t " +
            "WHERE t.name like #{namePattern}")

    List<Map<String, Object>> selectByNamePattern(@Param("namePattern")String namePattern);

    @Select("<script> SELECT id, name, type FROM folder WHERE type = #{type}  " +
            "       <if test=\"name != null and name != ''\">" +
            "        AND name = #{name}" +
            "        </if> </script> ")
    FolderDTO selectFolderByTypeAndName(@Param("type") String type, @Param("name") String name);

    @Select("SELECT id, last_updated, name FROM list WHERE name = #{name}")
    ListDTO selectListByName(@Param("name") String name);

    @Select("SELECT id, last_updated, name FROM list WHERE id = #{id}")
    ListDTO selectListById(@Param("id") Long id);

    @Select("SELECT customer_count FROM list WHERE id = #{id}")
    Long selectListTotalById(@Param("id") Long id);

    @Select("SELECT id, version, status, name FROM flow WHERE name = #{name}")
    List<SaveFlowResponse> selectFlowByName(@Param("name") String name);

}
