package com.convertlab.macore.campaign.model.dto;

import lombok.Data;

@Data
public class OnSegmentFinishDTO {
    long campaignId;
    long engageId;
    long listMemberBatchTaskId;
    String status;
}
