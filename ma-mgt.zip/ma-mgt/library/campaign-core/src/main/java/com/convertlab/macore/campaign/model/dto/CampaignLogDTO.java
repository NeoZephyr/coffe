package com.convertlab.macore.campaign.model.dto;

import lombok.Data;

import java.io.Serializable;
import java.time.Instant;

@Data
public class CampaignLogDTO implements Serializable {

    Long id;

    Long campaignId;

    String engageCode;

    String profileType;

    String profileId;

    Instant dateLog;

    String batchId;

    String phaseCode;

    String phaseStatus;

    String phaseFailedReason;

    Long filterId;

    String filterDescription;

    String controlGroupDescription;

}
