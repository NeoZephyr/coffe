package com.convertlab.macore.campaign.runtime;

import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;

import java.util.List;

public interface ICampaignRuntime {

    boolean startCampaign(Long campaignId);

    boolean stopCampaign(Long campaignId, boolean isDelStrategy);

    boolean updateEngageList(Long campaignId, List<CampaignOutboundEngage> engages);


}
