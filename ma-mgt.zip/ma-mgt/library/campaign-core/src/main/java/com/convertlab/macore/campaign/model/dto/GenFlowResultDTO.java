package com.convertlab.macore.campaign.model.dto;

import com.convertlab.macore.campaign.model.dto.ChannelInfo;
import com.convertlab.macore.campaign.model.dto.FlowInfo;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import lombok.Data;

import java.util.List;

@Data
public class GenFlowResultDTO {
    String flowDefinition;
    FlowInfo flowInfo;
    List<ChannelInfo> channelInfoList;
    CampaignOutboundEngage campaignOutboundEngage;
}
