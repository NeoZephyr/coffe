package com.convertlab.macore.campaign.common.constants;


public class Constants {
    public static final String NEW_CAMPAIGN_KEY = "campaign";
}