package com.convertlab.macore.campaign.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
public class AddCampaignContentRes {

    private long id;

}
