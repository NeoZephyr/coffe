package com.convertlab.macore.campaign.model.dto;

import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTaskData;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class CampaignTaskDTO {
    CampaignExecutionTask task;
    List<CampaignExecutionTaskData> dataList = new ArrayList<>();
}
