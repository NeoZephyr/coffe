package com.convertlab.macore.campaign.model.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Map;

@Data
public class CampaignEngageDTO implements Serializable {

    private Long id;

    private Integer seq;

    private String code;

    private Long campaignId;

    private String status;

    private String audienceStrategy;

    private Map<String, Object> audienceData;

    private String controlGroupStrategy;

    private Map<String, Object> controlGroupData;

    private String channelStrategy;

    private Map<String, Object> channelData;

    private String timeStrategy;

    private Map<String, Object> timeData;

    private Map<String, String> engageAttribute;

    private String profileType;

    private Long listId;

    private Long flowId;
}
