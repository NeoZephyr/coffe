package com.convertlab.macore.campaign.runtime.task;


import com.convertlab.foundation.library.jdbc.datasource.lookup.DataSourceLookupHelper;
import com.convertlab.macore.campaign.mapper.CampaignOutboundEngageMapper;
import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.dto.UndeployFlowResponse;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.service.legacy.cms.client.FlowManagerServiceClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.concurrent.atomic.AtomicReference;


@Service
@Slf4j
public class StopCampaignTaskService extends AbstractTaskRuntimeService {

    @Autowired
    protected FlowManagerServiceClient flowManagerServiceClient;

    @Override
    public TaskResult onStart(CampaignExecutionTask task) {
        // Retrieve full campaign data
        CampaignFullDataDTO campaignFullData = campaignService.getCampaignFullData(task.getCampaignId());
        boolean allFlowsStopped = true;

        for (CampaignOutboundEngage engage : campaignFullData.getOutboundEngageList()) {
            if (engage.getFlowId() != null && !stopAndHandleFlow(engage)) {
                allFlowsStopped = false;
                // Log here is optional since stopAndHandleFlow already logs specific errors
            }
        }

        return new TaskResult(allFlowsStopped);
    }

    private boolean stopAndHandleFlow(CampaignOutboundEngage engage) {
        try {
            UndeployFlowResponse response = flowManagerServiceClient.undeployFlow(engage.getFlowId(), true);
            if (response.isSuccess()) {
                campaignService.updateEngageStatus(engage, CampaignOutboundEngage.ENGAGE_STATUS_STOPPED);
                return true;
            } else {
                campaignService.updateEngageStatus(engage, CampaignOutboundEngage.ENGAGE_STATUS_FAILED);
                log.error("Failed to stop flow, flowId: {}", engage.getFlowId());
                return false;
            }
        } catch (Exception e) {
            log.error("Error stopping flow, flowId: {}", engage.getFlowId(), e);
            return false;
        }
    }

    @Override
    public void onFinish(CampaignExecutionTask task) {

    }

    public UndeployFlowResponse stopFlow(Long flowId) {
        return flowManagerServiceClient.undeployFlow(flowId, true);
    }


    @Override
    public TaskResult checkProgress(CampaignExecutionTask task) {
        return new TaskResult(false);
    }
}
