package com.convertlab.macore.campaign.runtime.taskchain;

import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.runtime.task.CampaignTaskService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public abstract class AbstractTaskChainStrategy implements ITaskChainStrategy {

    final CampaignTaskService campaignTaskService;

    final TimeStrategyService timeStrategyService;

    final ObjectMapper objectMapper;

    public abstract List<CampaignExecutionTask> createTaskChain(CampaignFullDataDTO campaignFullData);

    List<CampaignExecutionTask> initializeTaskChain(CampaignFullDataDTO campaignFullData) {
        //create an empty task list
        List<CampaignExecutionTask> tasks = new ArrayList<>();

        //create task for create list and folder.
        tasks.add(campaignTaskService.createGenerateListAndFolderTask(campaignFullData));

        //iterate engageListByCampaignId and create generate flow task for each engage.
        tasks.addAll(campaignFullData.getOutboundEngageList().stream()
                .map(engage -> campaignTaskService.createGenerateFlowTask(campaignFullData, engage))
                .collect(Collectors.toList()));
        return tasks;
    }
}
