package com.convertlab.macore.campaign.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.campaign.model.entity.CampaignTemplate;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CampaignTemplateMapper extends BaseMapper<CampaignTemplate> {
}