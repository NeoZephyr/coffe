package com.convertlab.macore.campaign.model.dto;

import com.convertlab.macore.campaign.common.utils.NameUtils;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;
import lombok.Data;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Data
public class CampaignStatDataDTO {

    Long campaignId;
    CampaignReportQuery.ControlGroupType controlGroupType;

    List<CampaignGroupStageStat> campaignGroupStageStatList = Collections.emptyList();
    List<EngageGroupStageStat> engageGroupStageStatList = Collections.emptyList();
    List<BatchEventStageStat> batchEventStageStats = Collections.emptyList();

    /**
     * 批次事件统计
     * <batchId, eventStageName(sent|failed_to_send), count>
     * 暂时没有使用 batch 维度的其他事件
     */
    @Data
    public static class BatchEventStageStat {
        String batchId;
        String eventStageName;
        Integer count;

        private static final Set<String> EVENT_NAMES = new HashSet<>(Arrays.asList(NameUtils.DELIVERED_EVENT,
                NameUtils.FAILED_TO_DELIVERED_EVENT, NameUtils.RECEIVED_EVENT, NameUtils.CLICKED_EVENT,
                NameUtils.OPENED_EVENT, NameUtils.FAILED_TO_SEND_EVENT, NameUtils.SENT_EVENT));

        public BatchEventStageStat(String batchId, String eventStageName, Integer count) {
            if (!EVENT_NAMES.contains(eventStageName)) {
                throw new IllegalArgumentException("eventStageName '" + eventStageName + "' is not in eventNames");
            }

            this.batchId = batchId;
            this.eventStageName = eventStageName;
            this.count = count;
        }
    }

    public Table<String, String, Integer> getBatchEventStageCountTable() {
        Table<String, String, Integer> batechEventStageTable = HashBasedTable.create();
        batchEventStageStats.forEach(batchEventStageStat ->
                batechEventStageTable.put(batchEventStageStat.getBatchId(), batchEventStageStat.getEventStageName(), batchEventStageStat.getCount()));
        return batechEventStageTable;
    }

    public int getGroupStageCount(String groupStageName) {
        if (!isValidGroupStage(groupStageName)) {
            throw new IllegalArgumentException("campaignGroupStageName '" + groupStageName + "' is not in groupNames");
        }
        CampaignGroupStageStat campaignGroupStageStat = campaignGroupStageStatList.stream().filter(groupStageStat -> groupStageStat.getGroupStageName().equals(groupStageName))
                .findFirst().orElse(new CampaignGroupStageStat(groupStageName, 0));
        return campaignGroupStageStat.getCount();
    }

    private static boolean isValidGroupStage(String stageName) {
        final Set<String> GROUP_NAMES = new HashSet<>(Arrays.asList(NameUtils.CONTROL_GROUP,
                NameUtils.EXCLUDED_GROUP, NameUtils.FILTERED_GROUP, NameUtils.TARGET_GROUP, NameUtils.MAIN_GROUP,
                NameUtils.SENT_EVENT, NameUtils.DELIVERED_EVENT, NameUtils.FAILED_TO_SEND_OR_DELIVER,
                NameUtils.OPENED_EVENT, NameUtils.CLICKED_EVENT));
        return GROUP_NAMES.contains(stageName);
    }

    @Data
    public static class EngageGroupStageStat {

        String engageCode;
        String groupStageName;
        Integer count;

        public EngageGroupStageStat(String engageCode, String groupStageName, Integer count) {
            if (!isValidGroupStage(groupStageName)) {
                throw new IllegalArgumentException("engageGroupStageName '" + groupStageName + "' is not in groupNames");
            }

            this.engageCode = engageCode;
            this.groupStageName = groupStageName;
            this.count = count;
        }
    }

    @Data
    public static class CampaignGroupStageStat {

        String groupStageName;
        Integer count;

        public CampaignGroupStageStat(String groupStageName, Integer count) {
            if (!isValidGroupStage(groupStageName)) {
                throw new IllegalArgumentException("groupStageName '" + groupStageName + "' is not in groupNames");
            }

            this.groupStageName = groupStageName;
            this.count = count;
        }
    }
}