package com.convertlab.macore.campaign.runtime.taskchain;

import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.dto.CronDTO;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.runtime.task.CampaignTaskService;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.time.*;
import java.util.List;


public abstract class AbstractPeriodicTaskChainStrategy extends AbstractTaskChainStrategy{

    public AbstractPeriodicTaskChainStrategy(CampaignTaskService campaignTaskService, TimeStrategyService timeStrategyService, ObjectMapper objectMapper) {
        super(campaignTaskService, timeStrategyService, objectMapper);
    }

    CronDTO parseCronDTO(String timeJsonString){
        try {
            return objectMapper.readValue(timeJsonString, CronDTO.class);
        }catch (Exception e){
            throw new RuntimeException("Failed to parse timeJsonString " + timeJsonString);
        }
    }

    void addPeriodicTask(CampaignFullDataDTO campaignFullData, List<CampaignExecutionTask> tasks, Instant initialTime){
        ZonedDateTime periodicTaskTriggerTime = timeStrategyService.getLastSundayOfTheMonth(initialTime);
        CampaignExecutionTask periodicTask = campaignTaskService.createPeriodicTask(campaignFullData);
        if(periodicTaskTriggerTime.isAfter(timeStrategyService.now())){
            Instant instant = periodicTaskTriggerTime.toInstant();
            periodicTask.setTaskTriggerDate(instant);
        }
        tasks.add(periodicTask);
    }

    public Instant addOneMonth(Instant instant) {

        if(instant == null){
            instant = Instant.now();
        }

        // Convert Instant to ZonedDateTime
        ZonedDateTime zonedDateTime = instant.atZone(TimeStrategyService.ZONE_ID_BEIJING);

        // Add one month
        ZonedDateTime newZonedDateTime = zonedDateTime.plusMonths(1);

        // Convert back to Instant
        return newZonedDateTime.toInstant();
    }
}
