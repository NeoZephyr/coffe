package com.convertlab.macore.campaign.model.dto;


import lombok.Data;

import java.util.List;

@Data
public class GroupFactsDataDTO {

    public GroupFactOpt groupFactsOpt;
    public String campaignName;
    public String campaignId;
    public String listId;
    public String filteredInListId;
    public String filteredOutListId;
    public String groupDate;
    public String campaignControlGroupId;
    public String campaignTargetGroupId;
    public String audienceStrategy;
    public Boolean targetIsRef;
    public List<EngageControlGroup> engageControlGroups;

    public static class EngageControlGroup{
        public String engageId;
        public String engageCode;
        public String engageListId;
        public String engageControlGroupId;
        public String engageFilteredInListId;
        public String engageFilteredOutListId;
        public String engageTargetListId;
        public Boolean targetIsRef;
        public String engageStartDate;
        public String segmentationGeneratedDate;
    }

    public enum GroupFactOpt {
        UPDATE_ENGAGE_GROUP_DATE,
        INIT_GROUP_FACTS
    }
}
