package com.convertlab.macore.campaign.model.dto;

import com.convertlab.macore.campaign.model.entity.*;
import lombok.Data;

import java.util.List;

@Data
public class CampaignFullDataDTO {
    MarketingCampaign campaign;
    CampaignAudienceStrategy audienceStrategy;
    CampaignFilter campaignFilter;
    List<CampaignMainTargetAudienceMapping> mainTargetAudience;
    List<CampaignOutboundEngage> outboundEngageList;

    public CampaignOutboundEngage getEngageByEngageId(long engageId) {
        for (CampaignOutboundEngage engage : outboundEngageList) {
            if (engage.getId().equals(engageId)) {
                return engage;
            }
        }
        return null;
    }
}
