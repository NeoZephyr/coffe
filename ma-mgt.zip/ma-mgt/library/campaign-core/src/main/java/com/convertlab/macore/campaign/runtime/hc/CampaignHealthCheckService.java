package com.convertlab.macore.campaign.runtime.hc;

import com.convertlab.data.job.core.context.ClJobHelper;
import com.convertlab.data.job.core.handler.annotation.ClJob;
import com.convertlab.foundation.library.business.feature.FeatureClient;
import com.convertlab.foundation.library.business.feature.QueryToggleTenantsResponse;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.runtime.CampaignTaskExecutorService;
import com.convertlab.macore.campaign.runtime.task.CampaignTaskService;
import com.convertlab.macore.campaign.service.CampaignService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.Instant;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
@AllArgsConstructor
public class CampaignHealthCheckService {

    private static final String CAMPAIGN_TASK_HEALTH_CHECK_JOB_HANDLER = "campaignTaskHealthCheckHandler";
    private static final int MAX_RETRY_COUNT = 3;
    private static final int TASK_TTL_SECONDS = 600; // 10 minutes

    private static final int TASK_REMOTE_TTL_SECONDS = 3600; // 10 minutes


    private final FeatureClient featureClient;
    private final CampaignTaskService campaignTaskService;
    private final CampaignTaskExecutorService campaignTaskExecutorService;

    @ClJob(value = CAMPAIGN_TASK_HEALTH_CHECK_JOB_HANDLER)
    public void handleCampaignTaskHealthCheck(){
        log.info("Campaign Task Health Check Handler is triggered");
        QueryToggleTenantsResponse response = featureClient.getToggleTenants(CampaignService.FEATURE_CAMPAIGN_V4, 1000, 0);
        if (CollectionUtils.isEmpty(response.getRows())) {
            log.info("No tenant found, skipping health check.");
            return;
        }
        response.getRows().forEach(this::performHealthCheckForTenant);
    }

    void performHealthCheckForTenant(QueryToggleTenantsResponse.Feature feature){
        try (TemporaryTenantContext ignored = new TemporaryTenantContext(feature.getTenantId())) {
            log.info("Checking health for tenant: {}", feature.getTenantId());
            checkScheduledButNotStartedTasks();
            checkLongRunningTasks();
            checkRemoteLongRunningTasks();
            checkFailedTasks();
        } catch (Exception e) {
            log.error("Error during tenant health check: {}", feature.getTenantId(), e);
        }
    }

    void checkScheduledButNotStartedTasks(){
        List<CampaignExecutionTask> taskList = campaignTaskService.getTasksScheduledBeforeTime(Instant.now().minusSeconds(TASK_TTL_SECONDS));
        if (!CollectionUtils.isEmpty(taskList)) {
            taskList.forEach(this::triggerStartTask);
        }
    }

    void checkLongRunningTasks(){
        List<CampaignExecutionTask> taskList = campaignTaskService.getRunningTooLongTimeTasks(Instant.now().minusSeconds(TASK_TTL_SECONDS), MAX_RETRY_COUNT);
        if (!CollectionUtils.isEmpty(taskList)) {
            taskList.forEach(this::retryTask);
        }
    }

    void checkRemoteLongRunningTasks(){
        List<CampaignExecutionTask> taskList = campaignTaskService.getRemoteRunningTooLongTimeTasks(Instant.now().minusSeconds(TASK_REMOTE_TTL_SECONDS), MAX_RETRY_COUNT);
        if (!CollectionUtils.isEmpty(taskList)) {
            taskList.forEach(this::retryTask);
        }
    }


    void checkFailedTasks(){
        List<CampaignExecutionTask> taskList = campaignTaskService.getFailedTasks(Instant.now().minusSeconds(TASK_TTL_SECONDS), MAX_RETRY_COUNT);
        if (!CollectionUtils.isEmpty(taskList)) {
            taskList.forEach(this::retryTask);
        }
    }

    void triggerStartTask(CampaignExecutionTask task) {
        log.info("Triggering start for task: {}", task.getId());
        campaignTaskExecutorService.startDirectly(task.getId());
    }

    void retryTask(CampaignExecutionTask task) {
        log.info("Retrying task: {}", task.getId());
        task.setRetryCount(task.getRetryCount() + 1);
        campaignTaskService.updateTaskStatus(task, CampaignExecutionTask.TASK_STATUS_RUNNING);
        campaignTaskExecutorService.startDirectly(task.getId());
    }
}