package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.jdbc.datasource.lookup.DataSourceLookupHelper;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.campaign.common.utils.NameUtils;
import com.convertlab.macore.campaign.common.utils.TimingStrategyConstants;
import com.convertlab.macore.campaign.model.dto.*;
import com.convertlab.macore.campaign.model.entity.*;
import com.convertlab.macore.campaign.service.CampaignChannelConditionService;
import com.convertlab.macore.campaign.service.legacy.cms.client.CmsServiceClient;
import com.convertlab.macore.channel.service.generator.ChannelFlowSchemaGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.StringWriter;
import java.util.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class FlowGenerationTaskService extends AbstractTaskRuntimeService {

    @Autowired
    protected CampaignBatchInfoService campaignBatchInfoServie;

    @Autowired
    ChannelFlowSchemaGenerator channelFlowSchemaGenerator;

    @Autowired
    CampaignChannelConditionService campaignChannelConditionService;

    @Autowired
    CmsServiceClient cmsServiceClient;

    @Autowired
    MaCoreService maCoreService;

    Template flowTemplate;
    Template channelNodeTemplate;
    Template endNodeTemplate;
    Template branchNodeTemplateSms;
    Template branchNodeTemplateEmail;
    Template branchNodeTemplateWOA;
    Template branchNodeTemplateAppPush;
    Template branchNodeTemplateChannelCondition;
    Template flowTemplateStartFilter_normal;
    Template flowTemplateStartFilter_periodic;

    @PostConstruct
    public void init(){
        try {
            // 创建和配置FreeMarker配置实例
            Configuration cfg = new Configuration(Configuration.VERSION_2_3_31);
            cfg.setClassForTemplateLoading(FlowGenerationTaskService.class, "/template/flow");
            cfg.setDefaultEncoding("UTF-8");
            cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);

            // 加载模板
            flowTemplate = cfg.getTemplate("flow_template.ftl");
            channelNodeTemplate = cfg.getTemplate("channel_node_template.ftl");
            branchNodeTemplateSms = cfg.getTemplate("branch_node_template_sms.ftl");
            branchNodeTemplateEmail = cfg.getTemplate("branch_node_template_email.ftl");
            branchNodeTemplateWOA = cfg.getTemplate("branch_node_template_woa.ftl");
            branchNodeTemplateAppPush =  cfg.getTemplate("branch_node_template_apppush.ftl");
            endNodeTemplate = cfg.getTemplate("end_node_template.ftl");
            branchNodeTemplateChannelCondition = cfg.getTemplate("branch_node_template_channel_condition.ftl");
            flowTemplateStartFilter_normal = cfg.getTemplate("flow_template_start_filter_normal.ftl");
            flowTemplateStartFilter_periodic = cfg.getTemplate("flow_template_start_filter_periodic.ftl");

        } catch (Exception e) {
            throw new RuntimeException("init flowTemplate error", e);
        }
    }

    public Template getFlowTemplateStartFilter_normal(){
        return flowTemplateStartFilter_normal;
    }

    public Template getFlowTemplateStartFilter_periodic(){
        return flowTemplateStartFilter_periodic;
    }

    public Template getFlowTemplate() {
        return flowTemplate;
    }

    public Template getChannelNodeTemplate() {
        return channelNodeTemplate;
    }

    public Template getEndNodeTemplate() {
        return endNodeTemplate;
    }

    public Template getBranchNodeTemplateSms() {
        return branchNodeTemplateSms;
    }

    public Template getBranchNodeTemplateEmail() {
        return branchNodeTemplateEmail;
    }

    public Template getBranchNodeTemplateWOA() {
        return branchNodeTemplateWOA;
    }

    public Template getBranchNodeTemplateAppPush() {
        return branchNodeTemplateAppPush;
    }

    public Template getBranchNodeTemplateChannelCondition() {
        return branchNodeTemplateChannelCondition;
    }

    @Override
    public TaskResult onStart(CampaignExecutionTask task) {
        //1.获取Campaign设置数据。
        CampaignFullDataDTO campaignFullData = campaignService.getCampaignFullData(task.getCampaignId());

        //2.生成自动流程数据并调用flow manager服务保存。 此外生成的batchInfo也会保存。
        SaveFlowResponse saveFlowResponse = this.generateAndSaveFlow(task, campaignFullData);

        //3.执行结束。
        return new TaskResult(true);

    }

    private void saveFlowIdToEngage(long flowId, CampaignOutboundEngage outboundEngage){
        outboundEngage.setFlowId(flowId);
        campaignService.updateEngageById(outboundEngage);
    }

    private SaveFlowResponse generateAndSaveFlow(CampaignExecutionTask task, CampaignFullDataDTO campaignFullData){
        //1.生成自动流程定义。
        GenFlowResultDTO genFlowResultDTO = generateFlow(task, campaignFullData);
        //2.保存发布自动流程。
        SaveFlowResponse saveFlowResponse = maCoreService.saveFlow(getFlowFolderId(campaignFullData.getCampaign().getId()), genFlowResultDTO.getFlowInfo().getName(), genFlowResultDTO.getFlowDefinition(), campaignFullData);
        //3.更新CampaignContent
        cmsServiceClient.addCamapignContent(new AddCampaignContentReq(campaignFullData.getCampaign().getId(), saveFlowResponse.getId(),  "flow", campaignFullData.getCampaign().getUuid(), 0));
        //4.存储batchinfo，用于报表维度计算。
        this.saveBatchInfo(genFlowResultDTO.getChannelInfoList(), saveFlowResponse, genFlowResultDTO.getCampaignOutboundEngage());
        //5.将flowId更新到engage属性。
        this.saveFlowIdToEngage(saveFlowResponse.getId(), genFlowResultDTO.getCampaignOutboundEngage());
        return saveFlowResponse;
    }

    private void saveBatchInfo(List<ChannelInfo> channelInfoList, SaveFlowResponse saveFlowResponse, CampaignOutboundEngage outboundEngage){
        //生成新的batch记录
        List<CampaignBatchInfo> batchInfos = new ArrayList<>();
        channelInfoList.forEach(channelInfo -> {
            CampaignBatchInfo batchInfo = new CampaignBatchInfo();
            batchInfo.setCampaignId(outboundEngage.getCampaignId());
            batchInfo.setEngageId(outboundEngage.getId());
            batchInfo.setEngageCode(outboundEngage.getCode());
            batchInfo.setChannelType(channelInfo.getChannelType());
            batchInfo.setChannelInstanceId(channelInfo.getChannelInstanceId());
            batchInfo.setTemplateId(channelInfo.getTemplateId());
            batchInfo.setTemplateName(channelInfo.getTemplateName());
            batchInfo.setFlowId(saveFlowResponse.getId());
            batchInfo.setMessagingType(channelInfo.getMessagingType());
            batchInfo.setTunnelId(channelInfo.getTunnelId());
            batchInfo.setBatchId(generateBatchId(generateFlowKey(saveFlowResponse.getId(), saveFlowResponse.getVersion()), channelInfo.getFlowStepId()));
            batchInfos.add(batchInfo);
        });

        //调用batch info service
        campaignBatchInfoServie.refreshBatchInfo(outboundEngage.getCampaignId(), outboundEngage.getId(), batchInfos);
    }

    private GenFlowResultDTO generateFlow(CampaignExecutionTask task, CampaignFullDataDTO campaignFullData){

        //根据task的engageId，从campaignFullData中读取CampaignOutboundEngage.
        Optional<CampaignOutboundEngage> engageOpt = campaignFullData.getOutboundEngageList().stream().filter(e ->
             e.getId().equals(task.getEngageId())
        ).findFirst();

        if(!engageOpt.isPresent()){
            throw new BusinessException("engage not found", "engage not found");
        }

        CampaignOutboundEngage engage = engageOpt.get();

        FlowInfo flowInfo = new FlowInfo();
        flowInfo.setName(NameUtils.getFlowName(task.getCampaignId(), task.getEngageId()));
        flowInfo.setList(engage.getListId().toString());
        if(StringUtils.isBlank(engage.getControlGroupStrategy()) || !"Control_At_Engage".equals(engage.getControlGroupStrategy())){
            flowInfo.setControlGroup("0");
            flowInfo.setStrategyGroup("1");
        }else{
            try {
                JsonNode rootNode = objectMapper.readTree(engage.getControlGroupData());
                Double percentage = rootNode.get("percentage").doubleValue();
                flowInfo.setControlGroup(percentage.toString());
                Double strategyGroupPercentage = 1 - percentage;
                flowInfo.setStrategyGroup(strategyGroupPercentage.toString());
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }
        }

        //增加周期性策略。
        if(Objects.equals(TimingStrategyConstants.PERIODIC, engage.getTimeStrategy())){
            String timeData = engage.getTimeData();
            flowInfo.setStrategy("strategy:" + timeData + ",");
            flowInfo.setTriggerType("Periodicity");
            flowInfo.setRestartable("true");
        }

        log.info("flow info : {}", flowInfo);

        List<ChannelInfo> channelInfoList = getChannelInfos(campaignFullData, engage);

        log.info("Channel Info Size : {}", channelInfoList.size());
        channelInfoList.forEach(channelInfo -> log.info("Channel Info Detail : {}", channelInfo));

        String flowRequestBody = generateFlow(flowInfo, channelInfoList);

        GenFlowResultDTO result = new GenFlowResultDTO();
        result.setFlowDefinition(flowRequestBody);
        result.setFlowInfo(flowInfo);
        result.setChannelInfoList(channelInfoList);
        result.setCampaignOutboundEngage(engage);
        return result;
    }

    List<ChannelInfo> getChannelInfos(CampaignFullDataDTO campaignFullData, CampaignOutboundEngage engage) {
        List<ChannelInfo> channelInfoList = new ArrayList<>();
        try {
            JsonNode rootNode = objectMapper.readTree(engage.getChannelData());
            JsonNode dataNode = rootNode.path("messagingTypes");
            for (JsonNode node : dataNode) {
                //如果是第三方渠道
                if(Optional.ofNullable(node.get("isThirdPartyChannel")).isPresent()){
                    boolean isThirdParty = node.get("isThirdPartyChannel").asBoolean();
                    if(isThirdParty){
                        String actionBody = node.get("actionBody").toString();
                        ChannelInfo thirdPartyChannel = this.getSmsChannelInfo(node.get("channelType").asText(), campaignFullData.getCampaign().getUuid(),node.get("messagingType").asText(),  null, node.get("channelTemplateId").asLong(), node.get("channelTemplateName").asText());
                        thirdPartyChannel.setActionBody(actionBody);
                        thirdPartyChannel.setThirdPartyChannel(true);
                        thirdPartyChannel.setPluginId( node.get("pluginId").asText());
                        channelInfoList.add(thirdPartyChannel);
                        continue;
                    }
                }

                switch(node.get("channelType").asText()){
                    case "sms" :
                    case "mms" :
                    case "vms":
                        ChannelInfo smsChannelInfo = this.getSmsChannelInfo(node.get("channelType").asText(), campaignFullData.getCampaign().getUuid(),node.get("messagingType").asText(),  node.get("tunnelId").asText(), node.get("channelTemplateId").asLong(), node.get("channelTemplateName").asText());
                        channelInfoList.add(smsChannelInfo);
                        break;
                    case "email" :
                        ChannelInfo emailChannelInfo = this.getEmailChannelInfo(campaignFullData.getCampaign().getUuid(),node.get("messagingType").asText(),  node.get("tunnelId").asText(), node.get("channelTemplateId").asLong(),node.get("channelTemplateName").asText());
                        channelInfoList.add(emailChannelInfo);
                        break;
                    case "wechat_official_account" :
                        ChannelInfo wechatTemplateChannelInfo = this.getWechatOfficalAccountChannelInfo(campaignFullData.getCampaign().getUuid(),node.get("messagingType").asText(),  node.get("channelInstanceId").asText(), node.get("channelTemplateId").asLong(),node.get("channelTemplateName").asText(),node.get("wechatAccountId").asLong());
                        channelInfoList.add(wechatTemplateChannelInfo);
                        break;
                    case "app_push" :
                        ChannelInfo appPushInfo = this.getAppPushInfo(campaignFullData.getCampaign().getUuid(),node.get("messagingType").asText(),  node.get("channelInstanceId").asText(), node.get("channelTemplateId").asLong(), node.get("channelTemplateName").asText(), node.get("appId").asText());
                        channelInfoList.add(appPushInfo);
                        break;
                    case "wechat_mini_program" :
                        ChannelInfo wechatMiniProgramInfo = this.getMiniProgramPushInfo(campaignFullData.getCampaign().getUuid(),node.get("messagingType").asText(),  node.get("channelInstanceId").asText(), node.get("channelTemplateId").asLong(), node.get("channelTemplateName").asText(), node.get("appId").asText());
                        channelInfoList.add(wechatMiniProgramInfo);
                        break;
                    default:break;
                }
            }
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        return channelInfoList;
    }


    private Long getFlowFolderId(long campaignId){
        //读取Folder
        CampaignExecutionTaskData taskData = campaignTaskService.getCampaignContextData(campaignId, DATA_KEY_FLOW_FOLDER_ID);
        if(taskData != null){
            return Long.valueOf(taskData.getDataValue());
        }
        return null;
    }


    @Override
    public void onFinish(CampaignExecutionTask task) {
    }

    private String generateBatchId(String flowKey, String stepId){
        return flowKey + "_false@@" + stepId;
    }

    private String generateFlowKey(long flowId, int flowVersion){
        return "flow-" + flowId + "_" + flowVersion;
    }

    //generate flow
    public String generateFlow(FlowInfo flowInfo, List<ChannelInfo> channelInfoList) {
            Map<String, Object> templateData = new HashMap<>();
            Map<String, Object> flowData = new HashMap<>();
            templateData.put("flow", flowData);
            flowData.put("name", flowInfo.getName());
            flowData.put("list",flowInfo.getList());
            flowData.put("controlGroup",flowInfo.getControlGroup());
            flowData.put("strategyGroup",flowInfo.getStrategyGroup());
            flowData.put("strategy", flowInfo.getStrategy());
            flowData.put("triggerType", flowInfo.getTriggerType());
            flowData.put("restartable", flowInfo.getRestartable());

            String filterData = this.generateStartFilter(templateData);
            flowData.put("startFilters", filterData);

            String channelData = this.generateChannel(channelInfoList);
            flowData.put("channelNodes", channelData);

            Template template = getFlowTemplate();
            return processTemplate(template, templateData);
    }

    public String generateStartFilter( Map<String, Object> templateData){
        Map<String, Object> flowData = (Map<String, Object>) templateData.get("flow");
        if("Periodicity".equals(flowData.get("triggerType"))){
            return processTemplate(getFlowTemplateStartFilter_periodic(),templateData);
        }else{
            return processTemplate(getFlowTemplateStartFilter_normal(), templateData);
        }
    }

    public String generateChannel(List<ChannelInfo> channelInfoList){
        //如果为空，返回空
        if(channelInfoList == null || channelInfoList.isEmpty()){
            return null;
        }

        String channelContent = "";

        int startNodeId = 100;
        //轮询生成channel节点
        for (ChannelInfo channelInfo : channelInfoList) {
            if (channelInfo == channelInfoList.get(channelInfoList.size() - 1)) {
                //如果是最后一个，则只生成action和end
                int actionNodeId = startNodeId++;
                int endNodeId = startNodeId++;
                channelInfo.setFlowStepId(String.valueOf(actionNodeId));

                String actionNode = generateActionNode(actionNodeId, endNodeId, channelInfo);
                String endNode = generateEndNode(endNodeId);

                channelContent = channelContent + "," + actionNode + "," + endNode;

            } else {
                //如果不是最后一个，则生成branch, action, end
                int brachNodeId = startNodeId++;
                int actionNodeId = startNodeId++;
                int endNodeId = startNodeId++;
                int nextActionNode = startNodeId;

                channelInfo.setFlowStepId(String.valueOf(actionNodeId));

                String branchNode = generateBranchNode(channelInfo, brachNodeId, actionNodeId, nextActionNode);
                String actionNode = generateActionNode(actionNodeId, endNodeId, channelInfo);
                String endNode = generateEndNode(endNodeId);

                channelContent = channelContent + "," + branchNode + "," + actionNode + "," + endNode;

            }
        }
        return channelContent;
    }

    String generateBranchNode(ChannelInfo channelInfo, int branchNodeId, int leftActionId, int rightActionId){
        Map<String, Object> templateData = new HashMap<>();
        Map<String, Object> branchData = new HashMap<>();
        templateData.put("branch", branchData);
        branchData.put("nodeId", branchNodeId);
        branchData.put("leftActionId", leftActionId);
        branchData.put("rightActionId", rightActionId);
        branchData.put("channelInstanceId", channelInfo.getChannelInstanceId());
        branchData.put("wechatAccountId", channelInfo.getWechatAccountId());
        branchData.put("appId", channelInfo.getAppId());

        Template template = null;
        //如果channel condition已经设置，则使用channel condition构建branch  node
        CampaignChannelCondition condition = campaignChannelConditionService.getByChannelTypeAndMessagingType(channelInfo.getChannelType(), channelInfo.getMessagingType());
        if(condition != null && condition.getFilterCondition() != null){
            template = getBranchNodeTemplateChannelCondition();
            branchData.put("filters", condition.getFilterCondition());
        }else{
            switch (channelInfo.getChannelType())
            {
                case "sms":
                case "mms":
                case "vms":
                    template = getBranchNodeTemplateSms();
                    break;
                case "email":
                    template = getBranchNodeTemplateEmail();
                    break;
                case "wechat_official_account":
                    template = getBranchNodeTemplateWOA();
                    break;
                case "app_push":
                    template = getBranchNodeTemplateAppPush();
                    break;
                default:
                    throw new RuntimeException(String.format("channel type not supported %s, or you can set channel condition to avoid this problem.",  channelInfo.getChannelType()));
            }
        }

        return processTemplate(template, templateData);
    }

    private String processTemplate(Template template, Map<String, Object> data) {
        try (StringWriter out = new StringWriter()) {
            template.process(data, out);
            String result = out.getBuffer().toString();
            log.info(result);
            return result;
        } catch (Exception e) {
            throw new RuntimeException("Error processing template: " + e.getMessage(), e);
        }
    }

    private String generateActionNode(int actionNodeId, int endNodeId, ChannelInfo channelInfo) {
        Map<String, Object> templateData = new HashMap<>();
        Map<String, Object> channelData = new HashMap<>();
        templateData.put("channel", channelData);

        channelData.put("nodeId", actionNodeId);
        channelData.put("endNodeId", endNodeId);
        channelData.put("channelType", channelInfo.getChannelType());
        channelData.put("messagingType", channelInfo.getMessagingType());
        if(channelInfo.isThirdPartyChannel())
        {
            channelData.put("nodeType", channelInfo.getPluginId());
        }else{
            channelData.put("nodeType", "plugin_channel_system_" + channelInfo.getMessagingType());
        }

        DataSourceLookupHelper.withLookupKey("main", () -> {
            channelData.put("actionBody", generateActionBody(channelInfo));
        });

        Template template = getChannelNodeTemplate();
        return processTemplate(template, templateData);
    }

    private String generateEndNode(int endNodeId) {
        Map<String, Object> templateData = new HashMap<>();
        Map<String, Object> endData = new HashMap<>();
        templateData.put("end", endData);
        endData.put("nodeId", endNodeId);

        Template template = getEndNodeTemplate();
        return processTemplate(template, templateData);
    }

    private ChannelInfo createChannelInfo(String campaignCode, String channelType, String messagingType, String tunnelId, long templateId, String templateName, String audienceIdType, Map<String, Object> additionalProperties) {
        ChannelInfo channelInfo = new ChannelInfo();
        channelInfo.setCampaignCode(campaignCode);
        channelInfo.setChannelType(channelType);
        channelInfo.setMessagingType(messagingType);
        channelInfo.setTunnelId(tunnelId);
        channelInfo.setTemplateId(templateId);
        channelInfo.setTemplateName(templateName);
        channelInfo.setAudienceIdType(audienceIdType);

        // Set additional properties specific to channel types
        additionalProperties.forEach((key, value) -> {
            switch (key) {
                case "wechatAccountId":
                    channelInfo.setWechatAccountId((Long) value);
                    break;
                case "appId":
                    channelInfo.setAppId((String) value);
                    break;
                case "channelInstanceId":
                    channelInfo.setChannelInstanceId((String) value);
                    break;
            }
        });

        return channelInfo;
    }

    private ChannelInfo getSmsChannelInfo(String channelType, String campaignCode, String messagingType, String tunnelId, long templateId, String templateName){
        return createChannelInfo(campaignCode, channelType, messagingType, tunnelId, templateId, templateName, "mobile", new HashMap<>());
    }

    private ChannelInfo getEmailChannelInfo(String campaignCode, String messagingType, String tunnelId, long templateId, String templateName){
        return createChannelInfo(campaignCode, "email", messagingType, tunnelId, templateId, templateName, "email", new HashMap<>());
    }

    private ChannelInfo getWechatOfficalAccountChannelInfo(String campaignCode, String messagingType, String channelInstanceId, long templateId, String templateName, long wechatAccountId){
        Map<String, Object> properties = new HashMap<>();
        properties.put("wechatAccountId", wechatAccountId);
        properties.put("channelInstanceId", channelInstanceId);
        return createChannelInfo(campaignCode, "wechat_official_account", messagingType, null, templateId, templateName, "wechatOpenId", properties);
    }

    private ChannelInfo getAppPushInfo(String campaignCode, String messagingType, String channelInstanceId, long templateId, String templateName, String appId){
        Map<String, Object> properties = new HashMap<>();
        properties.put("appId", appId);
        properties.put("channelInstanceId", channelInstanceId);
        return createChannelInfo(campaignCode, "app_push", messagingType, null, templateId, templateName, "pushInfo", properties);
    }


    private ChannelInfo getMiniProgramPushInfo(String campaignCode, String messagingType, String channelInstanceId, long templateId, String templateName, String appId){
        Map<String, Object> properties = new HashMap<>();
        properties.put("appId", appId);
        properties.put("channelInstanceId", channelInstanceId);
        return createChannelInfo(campaignCode, "wechat_mini_program", messagingType, null, templateId, templateName, "identity.applet-wechat", properties);
    }
    public String generateActionBody(ChannelInfo channelInfo){
        if(channelInfo.isThirdPartyChannel()){
            return channelInfo.getActionBody();
        }
        return channelFlowSchemaGenerator.gen(channelInfo.getChannelType(), "customer", channelInfo.getAudienceIdType(), channelInfo.getTemplateId(), channelInfo.getCampaignCode());
    }

    @Override
    public TaskResult checkProgress(CampaignExecutionTask task) {
        return new TaskResult(false);
    }
}
