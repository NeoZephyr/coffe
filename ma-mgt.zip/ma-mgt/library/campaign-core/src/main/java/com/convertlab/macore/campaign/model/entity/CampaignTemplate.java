package com.convertlab.macore.campaign.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.convertlab.foundation.library.mybatisplus.entity.BaseTenantEntity;
import lombok.*;

import java.io.Serializable;

@Data
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TableName(value = "campaign_template", excludeProperty = {"version", "creatorId", "updaterId", "creatorName", "updaterName"})
public class CampaignTemplate extends BaseTenantEntity implements Serializable {

    @TableId(value = "id", type = IdType.AUTO)
    Long id;

    @TableField("template_name")
    String templateName;

    @TableField("description")
    String description;

    @TableField("folder_id")
    Integer folderId;

    @TableField("status")
    String status;

    @TableField("use_cnt")
    int useCnt;

    @TableField("attrs")
    String attrs;

    @TableField("execution_mode")
    String executionMode;

    @TableField("campaign_strategy")
    String campaignStrategy;

    @TableField("outbound_engage_strategy")
    String outboundEngageStrategy;

}
