package com.convertlab.macore.campaign.model.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Map;

@Data
public class CampaignStrategyDTO implements Serializable {

    private Long id;

    private Long campaignId;

    private String strategyType;

    private String profileType;

    private String segmentationType;

    private Long filterId;

    private Map<String, Object> strategyContent;
}
