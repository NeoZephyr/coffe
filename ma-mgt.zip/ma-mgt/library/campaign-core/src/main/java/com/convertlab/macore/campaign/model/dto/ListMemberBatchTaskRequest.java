package com.convertlab.macore.campaign.model.dto;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ListMemberBatchTaskRequest {

    String listId;
    String taskType = "campaign_list_etl";
    ListMemberBatchTaskDef taskDef ;
}

