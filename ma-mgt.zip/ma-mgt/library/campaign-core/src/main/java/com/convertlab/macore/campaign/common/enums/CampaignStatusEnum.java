package com.convertlab.macore.campaign.common.enums;

import lombok.Getter;

@Getter
public enum CampaignStatusEnum {
    DRAFT("Draft", "草稿"),
    NOT_STARTED("NotStarted", "未开始"),
    RUNNING("Running", "运行中"),
    FINISHED("Finished", "已完成"),
    STOPPING("Stopping", "停止中"),
    STOPPED("Stopped", "已停止"),
    DELETED("Deleted", "已删除"),
    ;
    private final String name;
    private final String desc;

    CampaignStatusEnum(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }
}
