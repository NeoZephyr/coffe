package com.convertlab.macore.campaign.common.enums;

import lombok.Getter;

@Getter
public enum TimeStrategyTypeEnum {
    IMMEDIATE("Immediate", "立即"),
    SCHEDULED("Scheduled", "定时"),
    PERIODIC("Periodic", "周期"),
    MULTI_PLE_WAVE("MultipleWave", "多波次"),
    ;
    private final String name;
    private final String desc;

    TimeStrategyTypeEnum(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }
}
