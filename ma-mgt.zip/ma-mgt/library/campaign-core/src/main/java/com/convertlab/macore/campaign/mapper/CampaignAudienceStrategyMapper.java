package com.convertlab.macore.campaign.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.campaign.model.entity.CampaignAudienceStrategy;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface CampaignAudienceStrategyMapper extends BaseMapper<CampaignAudienceStrategy> {

    //根据CampaignId查询CampaignAudienceStrategy, 写一段Sql
    @Select({"<script>",
            "SELECT * FROM campaign_audience_strategy t",
            "WHERE t.campaign_id = #{campaignId}",
            "</script>"})
    @ResultType(CampaignAudienceStrategy.class)
    CampaignAudienceStrategy selectByCampaignId(@Param("campaignId")Long campaignId);

    @Select({"<script>",
            "SELECT * FROM campaign_audience_strategy t",
            "WHERE t.campaign_id in ",
            "<foreach collection=\"campaignIds\" item=\"campaignId\" open=\"(\" separator=\",\" close=\")\">",
            "#{campaignId}",
            "</foreach>",
            "</script>"})
    List<CampaignAudienceStrategy> selectByBatchCampaignIds(@Param("campaignIds") List<Long> campaignIds);
}