package com.convertlab.macore.campaign.runtime.taskchain;

import com.alibaba.excel.util.StringUtils;
import com.convertlab.foundation.api.queryengine.FilterV4Dto;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.jdbc.datasource.lookup.DataSourceLookupHelper;
import com.convertlab.macore.campaign.mapper.LimitMapper;
import com.convertlab.macore.campaign.model.dto.CronDTO;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.model.entity.Limit;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.quartz.CronExpression;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.atomic.AtomicReference;


@Service
@Slf4j
@RequiredArgsConstructor
public class TimeStrategyService {

    public static final ZoneId ZONE_ID_BEIJING = ZoneId.of("Asia/Shanghai");

    final ObjectMapper objectMapper;

    public ZonedDateTime now(){
        return ZonedDateTime.now(ZONE_ID_BEIJING);
    }

    public ZonedDateTime getLastSundayOfTheMonth(){
        return getLastSundayOfTheMonth(now());
    }

    public ZonedDateTime getLastSundayOfTheMonth(Instant initialTime){
        return getLastSundayOfTheMonth(initialTime.atZone(ZONE_ID_BEIJING));
    }

    private ZonedDateTime getLastSundayOfTheMonth(ZonedDateTime now) {
        // Step 1: Find the last day of the month
        ZonedDateTime lastDayOfMonth = now
                .with(TemporalAdjusters.lastDayOfMonth());

        // Step 2: Find the last Sunday of the month
        ZonedDateTime lastSunday = lastDayOfMonth.with(TemporalAdjusters.previousOrSame(DayOfWeek.SUNDAY)).
                withHour(12).withMinute(0).withSecond(0);

        return lastSunday;
    }


    public  List<ZonedDateTime> calculateTriggersThisMonth(CronDTO dto) {
        return calculateTriggersThisMonth(dto, now());
    }

    public  List<ZonedDateTime> calculateTriggersThisMonth(CronDTO dto, Instant initDataTime) {
        return calculateTriggersThisMonth(dto, initDataTime.atZone(ZONE_ID_BEIJING));

    }

    public  List<ZonedDateTime> calculateTriggersThisMonth(CronDTO dto, ZonedDateTime now) {
        // 计算下个月的第一天的第一秒
        ZonedDateTime firstSecondOfNextMonth = now.with(TemporalAdjusters.firstDayOfNextMonth())
                .withHour(0).withMinute(0).withSecond(0);

        // 从下个月的第一天的第一秒减去2秒，得到本月最后一天的最后一秒
        ZonedDateTime lastSecondOfMonth = firstSecondOfNextMonth.minusSeconds(1);

        return calculateTriggers(dto, now, lastSecondOfMonth);
    }

    public  List<ZonedDateTime> calculateTriggersNextMonth(CronDTO dto, Instant initDataTime) {
        if(initDataTime == null){
            initDataTime = Instant.now();
        }
        return calculateTriggersNextMonth(dto, initDataTime.atZone(ZONE_ID_BEIJING));
    }


    public  List<ZonedDateTime> calculateTriggersNextMonth(CronDTO dto,  ZonedDateTime initDataTime) {
        // 计算下个月的第一天的第一秒
        ZonedDateTime firstSecondOfNextMonth = initDataTime.with(TemporalAdjusters.firstDayOfNextMonth())
                .withHour(0).withMinute(0).withSecond(0);

        //计算下个月的最后一天的最后一秒
        ZonedDateTime lastSecondOfNextMonth = firstSecondOfNextMonth.with(TemporalAdjusters.lastDayOfMonth())
                .withHour(23).withMinute(59).withSecond(59);

        return calculateTriggers(dto, firstSecondOfNextMonth, lastSecondOfNextMonth);
    }

    public  List<ZonedDateTime> calculateTriggers(CronDTO dto, ZonedDateTime now, ZonedDateTime endOfMonth) {
        if (StringUtils.isEmpty(dto.getFromDate())) {
            return calculateCronTriggers(dto, now, endOfMonth);
        } else {
            return calculateIntervalTriggers(dto, now, endOfMonth);
        }
    }

    private  List<ZonedDateTime> calculateCronTriggers(CronDTO dto, ZonedDateTime now, ZonedDateTime endOfMonth) {
        List<ZonedDateTime> triggers = new ArrayList<>();
        String cronStr = null;

        try {

            if (dto.getWeek() != null && !dto.getWeek().equals("?")) {
                cronStr = String.format("0 %s %s ? %s %s", dto.getMin(), dto.getHour(), dto.getMonth(), dto.getWeek());
            } else {
                cronStr = String.format("0 %s %s %s %s ?", dto.getMin(), dto.getHour(), dto.getDay(), dto.getMonth());
            }

            CronExpression cronExpression = new CronExpression(cronStr);
            cronExpression.setTimeZone(TimeZone.getTimeZone(ZONE_ID_BEIJING));
            Date currentTime = Date.from(now.toInstant());
            Date nextValidTimeAfter = cronExpression.getNextValidTimeAfter(currentTime);
            while (nextValidTimeAfter != null && nextValidTimeAfter.before(Date.from(endOfMonth.toInstant()))) {
                ZonedDateTime triggerDateTime = ZonedDateTime.ofInstant(nextValidTimeAfter.toInstant(), ZONE_ID_BEIJING);
                if (triggerDateTime.isAfter(now)) {
                    triggers.add(triggerDateTime);
                }
                nextValidTimeAfter = cronExpression.getNextValidTimeAfter(nextValidTimeAfter);
            }
        } catch (ParseException e) {
            log.error("parse cronStr error {}", cronStr, e);
            throw new RuntimeException(String.format("parse cronStr error s%", cronStr), e);
        }

        return triggers;
    }

    private  List<ZonedDateTime> calculateIntervalTriggers(CronDTO dto, ZonedDateTime now, ZonedDateTime endOfMonth) {

        List<ZonedDateTime> triggers = new ArrayList<>();
        // 解析 fromDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate localDate = LocalDate.parse(dto.getFromDate(), formatter);

        ZonedDateTime start = localDate.atStartOfDay(ZONE_ID_BEIJING)
        .withHour(Integer.parseInt(dto.getHour()))
                .withMinute(Integer.parseInt(dto.getMin()));

        // 如果 fromDate < now，找到第一个符合条件的触发时间
        if (start.isBefore(now)) {
            // 循环增加interval，直到找到大于now的时间
            while (start.isBefore(now)) {
                start = start.plusDays(dto.getIntervalDays() > 0 ? dto.getIntervalDays() : 1);
            }
        }

        // 计算触发时间，从找到的开始时间或直接从fromDate开始
        ZonedDateTime nextTrigger = start;
        while (nextTrigger.isBefore(endOfMonth) || nextTrigger.isEqual(endOfMonth)) {
            triggers.add(nextTrigger.withHour(Integer.parseInt(dto.getHour()))
                    .withMinute(Integer.parseInt(dto.getMin()))
                    .withSecond(0));

            // 增加间隔天数
            nextTrigger = nextTrigger.plusDays(dto.getIntervalDays() > 0 ? dto.getIntervalDays() : 1);
        }

        return triggers;
    }

    final LimitMapper limitMapper;
    final static String segmentScheduledTime = "campaign_v4_segment_scheduled_time";

    //默认早上5点计算群组。
    LocalTime getDefaultSegmentScheduledTime(){
        AtomicReference<LocalTime> localTime = new AtomicReference<>(LocalTime.of(5, 0));
        DataSourceLookupHelper.withLookupKey("main",  () -> {
            Limit limit = limitMapper.selectByFeature(segmentScheduledTime);
            if(limit == null){
                return;
            }
            localTime.set(LocalTime.of(limit.getQuantity() / 100, limit.getQuantity() % 100));
        });

        return localTime.get();
    }

    private static final String SCHEDULED_DATE_FIELD = "scheduledDate";
    private static final String DATE_OF_NEXT_WAVE_FIELD = "date_of_next_wave";

    Instant getScheduledTime(CampaignOutboundEngage engage) {
        if (engage == null || org.apache.commons.lang3.StringUtils.isEmpty(engage.getTimeData())) {
            throw new IllegalArgumentException("Engage or time data is null or empty");
        }

        String dateTimeStr = extractDateTimeStr(engage.getTimeData());

        if (org.apache.commons.lang3.StringUtils.isEmpty(dateTimeStr)) {
            throw new RuntimeException("Both scheduledDate and date_of_next_wave are null or empty");
        }

        return Instant.parse(dateTimeStr);
    }

    private String extractDateTimeStr(String timeData) {
        try {
            JsonNode rootNode = objectMapper.readTree(timeData);
            if (rootNode.hasNonNull(SCHEDULED_DATE_FIELD)) {
                return rootNode.get(SCHEDULED_DATE_FIELD).asText();
            } else if (rootNode.hasNonNull(DATE_OF_NEXT_WAVE_FIELD)) {
                return rootNode.get(DATE_OF_NEXT_WAVE_FIELD).asText();
            }
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error processing JSON", e);
        }
        return null;
    }

    public Instant getSegmentScheduledTime(Instant engageScheduleTime){
        return getSegmentScheduledTime(engageScheduleTime, this.now());
    }


    /**
     * Calculates the scheduled time for a segment based on the provided engagement schedule time.
     *
     * @param engageScheduleTime The time at which the engagement is scheduled to occur.
     * @param nowInCST The current time in China Standard Time (CST).
     * @return An Instant representing the scheduled time, or null if the segment should be executed immediately.
     */
    Instant getSegmentScheduledTime(Instant engageScheduleTime, ZonedDateTime nowInCST) {

        // Return null if the engagement schedule time is not specified.
        if (engageScheduleTime == null) {
            return null;
        }

        // Convert the engagement schedule time to CST.
        ZonedDateTime cstDateTime = engageScheduleTime.atZone(ZONE_ID_BEIJING);
        // Retrieve the default time of day for scheduling segments.
        LocalTime defaultSegmentScheduledTime = getDefaultSegmentScheduledTime();

        // Check if the engagement schedule time is on the same day as the current CST time.
        if (cstDateTime.toLocalDate().equals(nowInCST.toLocalDate())) {
            // If it's after the default time, execute immediately; otherwise, schedule for the default time today.
            return nowInCST.toLocalTime().isAfter(defaultSegmentScheduledTime) ? null : nowInCST.with(defaultSegmentScheduledTime).toInstant();
        }

        // If the engagement schedule time is not today, check if it's in the past or future.
        // If it's in the past, execute immediately; if it's in the future, schedule for the default time on that future date.
        return cstDateTime.isBefore(nowInCST) ? null : cstDateTime.with(defaultSegmentScheduledTime).toInstant();
    }

    public String convertUtcToCron(Instant utcTime) {

        // 转换为本地时间（如果你的调度器运行在非UTC时区）
        ZonedDateTime localDateTime = utcTime.atZone(ZoneId.of("Asia/Shanghai"));

        // 构建Cron表达式
        return String.format("%d %d %d %d %d ? %d",
                localDateTime.getSecond(),
                localDateTime.getMinute(),
                localDateTime.getHour(),
                localDateTime.getDayOfMonth(),
                localDateTime.getMonthValue(),
                localDateTime.getYear());
    }
}
