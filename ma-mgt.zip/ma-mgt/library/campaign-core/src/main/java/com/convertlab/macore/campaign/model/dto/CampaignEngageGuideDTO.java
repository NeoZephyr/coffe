package com.convertlab.macore.campaign.model.dto;

import com.convertlab.macore.campaign.common.enums.CampaignEngageStatusEnum;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Data
public class CampaignEngageGuideDTO implements Serializable {

//    private String version;

    private List<Node> engageList;

    @Getter
    @Setter
    public static class Node {
        private Long id;

        private int seq;

        private String code;

        private String status = CampaignEngageStatusEnum.DRAFT.getName();

        private Long campaignId;

        private String channelStrategy;

        private Map<String, Object> channelData;

        private String timeStrategy;

        private Map<String, Object> timeData;

        private String audienceStrategy;

        private Map<String, Object> audienceData;

        private String controlGroupStrategy;

        private Map<String, Object> controlGroupData;

        /**
         * <c_channel: 'SMS', c_mot: 'reg01'>
         */
        Map<String, String> engageAttribute;
    }
}
