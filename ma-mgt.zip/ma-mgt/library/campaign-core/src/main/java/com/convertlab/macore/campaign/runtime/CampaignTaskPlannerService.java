package com.convertlab.macore.campaign.runtime;


import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.macore.campaign.common.utils.AudienceStrategyConstants;
import com.convertlab.macore.campaign.common.utils.TimingStrategyConstants;
import com.convertlab.macore.campaign.common.utils.TransactionAwareUtils;
import com.convertlab.macore.campaign.mapper.CampaignExecutionTaskMapper;
import com.convertlab.macore.campaign.mapper.CampaignOutboundEngageMapper;
import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.runtime.task.CampaignTaskService;
import com.convertlab.macore.campaign.runtime.taskchain.CampaignSegmentPeriodicTaskChain;
import com.convertlab.macore.campaign.runtime.taskchain.CampaignSegmentTaskChain;
import com.convertlab.macore.campaign.runtime.taskchain.EngageSegmentPeriodicTaskChain;
import com.convertlab.macore.campaign.runtime.taskchain.EngageSegmentTaskChain;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@DataSourceLookup("main")
@Slf4j
@RequiredArgsConstructor
public class CampaignTaskPlannerService implements ICampaignTaskPlanner {

        final CampaignOutboundEngageMapper campaignOutboundEngageMapper;
        final CampaignTaskExecutorService campaignTaskExecutorService;
        final CampaignTaskService campaignTaskService;
        final CampaignExecutionTaskMapper campaignExecutionTaskMapper;
        final CampaignSegmentTaskChain campaignSegmentTaskChain;
        final EngageSegmentTaskChain engageSegmentTaskChain;
        final CampaignSegmentPeriodicTaskChain campaignSegmentPeriodicTaskChain;
        final EngageSegmentPeriodicTaskChain engageSegmentPeriodicTaskChain;

        /**
         * plan start campaign tasks.
         * @param campaignFullData
         */
        @Override
        public void planStartCampaign(CampaignFullDataDTO campaignFullData) {

                //create a task list
                List<CampaignExecutionTask> taskList =  createCampaignStartTaskList(campaignFullData);

                //排序
                campaignTaskService.sortByTimeArrange(taskList);

                //save and update task chain.
                campaignTaskService.saveAndUpdateTaskChain(taskList);

                //任务保存成功，事务结束后，将第一个任务推送给任务执行引擎执行。
                runFirstTask(taskList);

        }

        private void runFirstTask(List<CampaignExecutionTask> taskList) {
                TransactionAwareUtils.transactionAwareCmd(() -> {
                        campaignTaskExecutorService.startTask(taskList.get(0).getId());
                });
        }

        List<CampaignExecutionTask> createCampaignStartTaskList(CampaignFullDataDTO campaignFullData) {
                CampaignOutboundEngage firstEngage = campaignFullData.getOutboundEngageList().get(0);
                String audienceStrategy = firstEngage.getAudienceStrategy();
                String timingStrategy = firstEngage.getTimeStrategy();

                switch (timingStrategy) {
                        case TimingStrategyConstants.IMMEDIATE:
                        case TimingStrategyConstants.SCHEDULED:
                                switch (audienceStrategy) {
                                        case AudienceStrategyConstants.MANUAL_SPECIFIED_SEGMENTATION:
                                        case AudienceStrategyConstants.MULTIPLE_WAVED_SEGMENTATION:
                                                return engageSegmentTaskChain.createTaskChain(campaignFullData);
                                        default:
                                                return campaignSegmentTaskChain.createTaskChain(campaignFullData);
                                }
                        case TimingStrategyConstants.PERIODIC:
                                if (AudienceStrategyConstants.MANUAL_SPECIFIED_SEGMENTATION.equals(audienceStrategy)) {
                                        return engageSegmentPeriodicTaskChain.createTaskChain(campaignFullData);
                                } else {
                                        return campaignSegmentPeriodicTaskChain.createTaskChain(campaignFullData);
                                }
                        default:
                                throw new UnsupportedOperationException("Unsupported timing strategy: " + timingStrategy + ", with audience strategy: " + audienceStrategy);
                }
        }

        @Override
        public void planStopCampaign(CampaignFullDataDTO campaignFullData, boolean isDelStrategy) {
                campaignTaskService.updateTaskStatuses(campaignFullData.getCampaign().getId(), CampaignExecutionTask.TASK_STATUS_RUNNING, CampaignExecutionTask.TASK_STATUS_STOPPED);
                campaignTaskService.updateTaskStatuses(campaignFullData.getCampaign().getId(), CampaignExecutionTask.TASK_STATUS_NOT_STARTED, CampaignExecutionTask.TASK_STATUS_STOPPED);
                campaignTaskExecutorService.unscheduleAndStopTasks(campaignFullData.getCampaign().getId());

                CampaignExecutionTask stopTask = campaignTaskService.createStopTask(campaignFullData.getCampaign());
                campaignExecutionTaskMapper.upsert(stopTask);
                runTaskAfterTransaction(stopTask);
        }

        void runTaskAfterTransaction(CampaignExecutionTask stopTask){
                TransactionAwareUtils.transactionAwareCmd(() -> {
                        campaignTaskExecutorService.startTask(stopTask.getId());
                });
        }

        @Override
        public void planUpdateEngage(CampaignFullDataDTO campaignFullDataDTO, List<CampaignOutboundEngage> engageList){

                List<CampaignExecutionTask> notStartedOrScheduledTasks = campaignTaskService.getNotStartedAndScheduledTasks(campaignFullDataDTO.getCampaign().getId());
                unscheduleScheduledTasks(notStartedOrScheduledTasks);

                List<CampaignExecutionTask> runningTasks = campaignTaskService.getRunningTasks(campaignFullDataDTO.getCampaign().getId());
                List<CampaignExecutionTask> newTaskChain = createCampaignStartTaskList(campaignFullDataDTO);
                updateTaskTriggerDates(notStartedOrScheduledTasks, newTaskChain);

                List<CampaignExecutionTask> realignedTaskChain = createGenFlowTasksAndRealign(campaignFullDataDTO, engageList, notStartedOrScheduledTasks);
                campaignTaskService.sortByTimeArrange(realignedTaskChain);
                campaignTaskService.saveAndUpdateTaskChain(realignedTaskChain);

                startFirstTaskOrSetNextForRunning(runningTasks, realignedTaskChain);
        }


        private void unscheduleScheduledTasks(List<CampaignExecutionTask> tasks) {
                tasks.stream()
                        .filter(task -> CampaignExecutionTask.TASK_STATUS_SCHEDULED.equals(task.getTaskStatus()))
                        .forEach(campaignTaskExecutorService::_unscheduleTask);
        }

        private void updateTaskTriggerDates(List<CampaignExecutionTask> existingTasks, List<CampaignExecutionTask> newTaskChain) {
                existingTasks.forEach(task -> {
                        //如果task在newTaskChain里面，更新task的数据。
                        Optional<CampaignExecutionTask> matchingTask = newTaskChain.stream()
                                .filter(newTask ->
                                        Objects.equals(newTask.getTaskType(), task.getTaskType()) &&
                                                Objects.equals(newTask.getCampaignId(), task.getCampaignId()) &&
                                                Objects.equals(newTask.getEngageId(), task.getEngageId())
                                )
                                .findFirst();

                        if (matchingTask.isPresent()) {
                                CampaignExecutionTask foundTask = matchingTask.get();
                                task.setTaskTriggerDate(foundTask.getTaskTriggerDate());
                        } else {
                                log.error("Task not found in new task chain, task id:{}", task.getId());
                        }
                });
        }

        private List<CampaignExecutionTask> createGenFlowTasksAndRealign(CampaignFullDataDTO campaignFullDataDTO, List<CampaignOutboundEngage> engageList, List<CampaignExecutionTask> existingTasks) {
                List<CampaignExecutionTask> genFlowTasks = engageList.stream()
                        .map(engage -> campaignTaskService.createGenerateFlowTask(campaignFullDataDTO, engage))
                        .collect(Collectors.toList());
                genFlowTasks.addAll(existingTasks);
                return genFlowTasks;
        }

        private void startFirstTaskOrSetNextForRunning(List<CampaignExecutionTask> runningTasks, List<CampaignExecutionTask> realignedTaskChain) {
                if (runningTasks.isEmpty()) {
                        TransactionAwareUtils.transactionAwareCmd(() -> campaignTaskExecutorService.startTask(realignedTaskChain.get(0).getId()));
                } else {
                        runningTasks.forEach(task -> {
                                task.setNextTaskId(realignedTaskChain.get(0).getId());
                                campaignExecutionTaskMapper.upsert(task);
                        });
                }
        }

}
