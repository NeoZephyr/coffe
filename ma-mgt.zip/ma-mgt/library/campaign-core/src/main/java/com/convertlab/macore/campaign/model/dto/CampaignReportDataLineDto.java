package com.convertlab.macore.campaign.model.dto;


import com.convertlab.macore.campaign.common.utils.NameUtils;
import com.convertlab.macore.mamgt.common.utils.NamingUtils;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.convertlab.macore.campaign.model.dto.CampaignChannelEventStageDto.EVENT_STAGE_NAMES;
import static com.convertlab.macore.campaign.service.CampaignStatService.BATCH_ID_COLUMN;
import static com.convertlab.macore.campaign.service.CampaignStatService.GROUP_DATE_COLUMN;

@Data
public class CampaignReportDataLineDto {
    public static final String CAMPAIGN_ID_COLUMN = "campaign_id";
    public static final String ENGAGE_ID_COLUMN = "engage_id";
    public static final String ENGAGE_CODE_COLUMN = "engage_code";

    public static final String CAMPAIGN_FILTERED_FLAG_COLUMN = "campaign_filtered_flag";
    public static final String CAMPAIGN_CONTROL_FLAG_COLUMN = "campaign_control_flag";
    public static final String ENGAGE_FILTERED_FLAG_COLUMN = "engage_filtered_flag";
    public static final String ENGAGE_CONTROL_FLAG_COLUMN = "engage_control_flag";
    public static final String GROUP_COUNT_COLUMN = "cnt";

    public static final String EVENT_STAGE_FIELD = "eventStage";
    public static final String BATCH_ID_FIELD = "batchId";

    public static final String MAIN_GROUP_COUNT_FIELD = "mainGroupCount";
    public static final String CONTROL_GROUP_COUNT_FIELD = "controlGroupCount";
    public static final String TARGET_GROUP_COUNT_FIELD = "targetGroupCount";
    public static final String FILTERED_GROUP_COUNT_FIELD = "filteredGroupCount";
    public static final String EXCLUDED_GROUP_COUNT_FIELD = "excludedGroupCount";

    //0L 是默认值，代表不设置
    Long campaignId = -1L;
    Long engageId = -1L;

    //对应时间窗口单元
    String dateUnit = "";

    GroupStat campaignGroupStat = new GroupStat();
    GroupStat engageGroupStat = new GroupStat();
    List<BatchEventStageStat> batchEventStageStat = new ArrayList<>();

    /**
     *
     * @param engageStatList
     * Map数据Key：[
     *                campaign_id, campaign_filtered_flag , campaign_control_flag,
     *                engage_id, dateUnit as GROUP_DATE_FIELD,
     *                engage_filtered_flag , engage_control_flag,
     *                count(%s profile_id) as cnt
     *      ]
     */
    public CampaignReportDataLineDto(GroupAggregateDim dim,
                                     List<Map<String, Object>> engageStatList,
                                     List<Map<String, Object>> eventRawStatList) {

        this.campaignId = dim.getCampaignId();
        this.engageId = dim.getEngageId();
        //dateUnit 这里还是原始的格式，一般是unit第一天的 datetime，最后再根据 queryOptions 格式化
        this.dateUnit = dim.getDateUnit();

        for (Map<String, Object> groupFactRow : engageStatList) {
            boolean isCampaignExcluded = groupFactRow.get(CAMPAIGN_FILTERED_FLAG_COLUMN).equals(0);
            boolean isCampaignFiltered = groupFactRow.get(CAMPAIGN_FILTERED_FLAG_COLUMN).equals(1);
            boolean isCampaignInControl = groupFactRow.get(CAMPAIGN_CONTROL_FLAG_COLUMN).equals(1);
            boolean isCampaignInTarget = groupFactRow.get(CAMPAIGN_CONTROL_FLAG_COLUMN).equals(0);
            boolean isEngageInExcluded = groupFactRow.get(ENGAGE_FILTERED_FLAG_COLUMN).equals(0);
            boolean isEngageInFiltered = groupFactRow.get(ENGAGE_FILTERED_FLAG_COLUMN).equals(1);
            boolean isEngageInTarget = groupFactRow.get(ENGAGE_CONTROL_FLAG_COLUMN).equals(0);
            boolean isEngageInControl = groupFactRow.get(ENGAGE_CONTROL_FLAG_COLUMN).equals(1);
            int groupCnt = Integer.parseInt((String) groupFactRow.get(GROUP_COUNT_COLUMN));

            campaignGroupStat.mainGroupCount += groupCnt;
            if (isCampaignExcluded) {
                campaignGroupStat.excludedGroupCount += groupCnt;
            } else if (isCampaignFiltered) {
                campaignGroupStat.filteredGroupCount += groupCnt;
            } else if (isCampaignInControl) {
                campaignGroupStat.controlGroupCount += groupCnt;
            } else if (isCampaignInTarget) {
                campaignGroupStat.targetGroupCount += groupCnt;
            }

            if (engageId != -1L) {
                if (isEngageInExcluded) {
                    engageGroupStat.excludedGroupCount += groupCnt;
                } else if (isEngageInFiltered) {
                    engageGroupStat.filteredGroupCount += groupCnt;
                } else if (isEngageInTarget) {
                    engageGroupStat.targetGroupCount += groupCnt;
                } else if (isEngageInControl) {
                    engageGroupStat.controlGroupCount += groupCnt;
                }
            }
        }

        Map<String, BatchEventStageStat> batchEventStageStatMap = new HashMap<>();
        for (Map<String, Object> eventRawStat : eventRawStatList) {
            String batchId = (String) eventRawStat.get(BATCH_ID_COLUMN);
            String eventStage = (String) eventRawStat.get(EVENT_STAGE_FIELD);
            int eventCnt = Integer.parseInt((String) eventRawStat.get(GROUP_COUNT_COLUMN));

            if (!batchEventStageStatMap.containsKey(batchId)) {
                BatchEventStageStat batchValue = new BatchEventStageStat();
                batchValue.setBatchId(batchId);
                batchEventStageStatMap.put(batchId, batchValue);
                batchEventStageStat.add(batchValue) ;
            }

            BatchEventStageStat batchStat = batchEventStageStatMap.get(batchId);
            switch (eventStage) {
                case NameUtils.SENT_EVENT:
                    batchStat.sentCount += eventCnt;
                    break;
                case NameUtils.FAILED_TO_SEND_EVENT:
                    batchStat.failedToSendCount += eventCnt;
                    break;
                case NameUtils.DELIVERED_EVENT:
                    batchStat.deliveredCount += eventCnt;
                    break;
                case NameUtils.FAILED_TO_DELIVERED_EVENT:
                    batchStat.failedToDeliveredCount += eventCnt;
                    break;
                case NameUtils.OPENED_EVENT:
                    batchStat.openedCount += eventCnt;
                    break;
                case NameUtils.CLICKED_EVENT:
                    batchStat.clickedCount += eventCnt;
                    break;
                case NameUtils.RECEIVED_EVENT:
                    batchStat.receivedCount += eventCnt;
                    break;
                default:
                    throw new IllegalStateException("Unexpected eventStage: " + eventStage);
            }
        }
    }

    @Data
    public static class GroupAggregateDim {

        Long campaignId = 0L;
        Long engageId = 0L;
        String dateUnit = "";

        public GroupAggregateDim(Long campaignId, Long engageId, String dateUnit) {
            this.campaignId = campaignId;
            this.engageId = engageId;
            this.dateUnit = dateUnit;
        }

        public GroupAggregateDim(Map<String, Object> groupStat) {
            this.campaignId = Long.valueOf((String) groupStat.get(CAMPAIGN_ID_COLUMN));
            this.engageId = Long.valueOf((String) groupStat.get(ENGAGE_ID_COLUMN));
            this.dateUnit = (String) groupStat.get(GROUP_DATE_COLUMN);
        }
    }

    /**
     * ('campaign', 'engage', 'main_group');
     * ('campaign', 'engage', 'control_group');
     * ('campaign', 'engage', 'target_group');
     * ('campaign', 'engage', 'filtered_group');
     * ('campaign', 'engage', 'excluded_group');
     *
     * ('campaign', 'no engage', 'main_group');
     * ('campaign', 'no engage', 'target_group');
     * ('campaign', 'no engage', 'filtered_group');
     * ('campaign', 'no engage', 'excluded_group');
     * ('campaign', 'no engage', 'control_group');
     */
    @Data
    public static class GroupStat {
        int mainGroupCount = 0;
        int controlGroupCount = 0;
        int targetGroupCount = 0;
        int filteredGroupCount = 0;
        int excludedGroupCount = 0;

        public Map<String, Object> getGroupCountMap() {
            Map<String, Object> map = new HashMap<>();
            map.put(MAIN_GROUP_COUNT_FIELD, mainGroupCount);
            map.put(CONTROL_GROUP_COUNT_FIELD, controlGroupCount);
            map.put(TARGET_GROUP_COUNT_FIELD, targetGroupCount);
            map.put(FILTERED_GROUP_COUNT_FIELD, filteredGroupCount);
            return map;
        }
    }

    /**
     *     public static final String SENT_EVENT = "sent";
     *     public static final String FAILED_TO_SEND_EVENT = "failed_to_send";
     *     public static final String DELIVERED_EVENT = "delivered";
     *     public static final String FAILED_TO_DELIVERED_EVENT = "failed_to_delivered";
     *     public static final String RECEIVED_EVENT = "received";
     *     public static final String OPENED_EVENT = "opened";
     *     public static final String CLICKED_EVENT = "clicked";
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BatchEventStageStat {
        @Builder.Default
        String batchId = "";
        @Builder.Default
        int sentCount = 0;
        @Builder.Default
        int failedToSendCount = 0;
        @Builder.Default
        int deliveredCount = 0;
        @Builder.Default
        int failedToDeliveredCount = 0;
        @Builder.Default
        int receivedCount = 0;
        @Builder.Default
        int openedCount = 0;
        @Builder.Default
        int clickedCount = 0;

        public Map<String, Object> getEventCountMap() {
            return getEventCountMap(false);
        }

        public Map<String, Object> getEventCountMap(boolean useFieldKey) {
            Map<String, Object> map = new HashMap<>();
            map.put(BATCH_ID_FIELD, batchId);
            map.put(NameUtils.SENT_EVENT, sentCount);
            map.put(NameUtils.DELIVERED_EVENT, deliveredCount);

            String failedToSendEvent = useFieldKey ? NamingUtils.toLowerCamelCase(NameUtils.FAILED_TO_SEND_EVENT):  NameUtils.FAILED_TO_SEND_EVENT;
            map.put(failedToSendEvent, failedToSendCount);

            String failedToDeliveredEvent = useFieldKey ? NamingUtils.toLowerCamelCase(NameUtils.FAILED_TO_DELIVERED_EVENT):  NameUtils.FAILED_TO_DELIVERED_EVENT;
            map.put(failedToDeliveredEvent, failedToDeliveredCount);

            map.put(NameUtils.RECEIVED_EVENT, receivedCount);
            map.put(NameUtils.OPENED_EVENT, openedCount);
            map.put(NameUtils.CLICKED_EVENT, clickedCount);
            return map;
        }

        public BatchEventStageStat merge(BatchEventStageStat batchEventStageStat) {
            this.sentCount += batchEventStageStat.sentCount;
            this.failedToSendCount += batchEventStageStat.failedToSendCount;
            this.deliveredCount += batchEventStageStat.deliveredCount;
            this.failedToDeliveredCount += batchEventStageStat.failedToDeliveredCount;
            this.receivedCount += batchEventStageStat.receivedCount;
            this.openedCount += batchEventStageStat.openedCount;
            return this;
        }


        /**
         *             String batchId = (String) eventRawStat.get(BATCH_ID_COLUMN);
         *             String eventStage = (String) eventRawStat.get(EVENT_STAGE_FIELD);
         *             int eventCnt = Integer.parseInt((String) eventRawStat.get(GROUP_COUNT_COLUMN));
         * @return
         */
        public List<Map<String, Object>> getRawEventStageCountMap() {
            Map<String, Object> eventCountMap = getEventCountMap();
            List<Map<String, Object>> result = new ArrayList<>();
            for(String eventStage: EVENT_STAGE_NAMES) {
                String stageCount = String.valueOf( eventCountMap.get(eventStage));
                int cnt = Integer.parseInt(stageCount);
                if (cnt > 0 ) {
                    Map<String, Object> eventStageMap = new HashMap<>();
                    eventStageMap.put(BATCH_ID_COLUMN, batchId);
                    eventStageMap.put(EVENT_STAGE_FIELD, eventStage);
                    eventStageMap.put(GROUP_COUNT_COLUMN, stageCount);
                    result.add(eventStageMap);
                }
            }
            return result;
        }

    }
}
