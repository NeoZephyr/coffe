package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.foundation.library.jdbc.datasource.lookup.DataSourceLookupHelper;
import com.convertlab.macore.campaign.mapper.CampaignListInfoMapper;
import com.convertlab.macore.campaign.model.entity.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

@Service
@Slf4j
@RequiredArgsConstructor
public class CampaignListInfoService {

    final CampaignListInfoMapper campaignListInfoMapper;

    public void saveListInfo(List<CampaignListInfo> listInfo){
        DataSourceLookupHelper.withLookupKey("main", () -> {
            listInfo.forEach(list -> {
                campaignListInfoMapper.insert(list);
            });
        });
    }

    public List<CampaignListInfo> loadListInfo(long campaignId){
        AtomicReference<List<CampaignListInfo>> listInfoRef = new AtomicReference<>();
        DataSourceLookupHelper.withLookupKey("main", () -> {
            listInfoRef.set(campaignListInfoMapper.selectByCampaignId(campaignId));
        });
        return listInfoRef.get();
    }

    public List<CampaignListInfo> selectByCampaignIdAndEngageId(Long campaignId, Long id) {
        AtomicReference<List<CampaignListInfo>> listInfo = new AtomicReference<>();
        DataSourceLookupHelper.withLookupKey("main", () -> {
            listInfo.set(campaignListInfoMapper.selectByCampaignIdAndEngageId(campaignId, id));
        });
        return listInfo.get();
    }

    public CampaignListInfo findListInfoByType( List<CampaignListInfo> engageListInfo, String listType){
        return engageListInfo.stream().filter(list -> list.getListType().equals(listType)).findFirst().orElse(null);
    }

    public void updateById(CampaignListInfo list) {
        DataSourceLookupHelper.withLookupKey("main", () -> {
            campaignListInfoMapper.updateById(list);
        });
    }

    public List<CampaignListInfo> getCampaignListInfo(long campaignId){
        AtomicReference<List<CampaignListInfo>> campaignListInfos = new AtomicReference<>();

        DataSourceLookupHelper.withLookupKey("main", () -> {
            campaignListInfos.set(campaignListInfoMapper.selectByCampaignId(campaignId));

        });
        return campaignListInfos.get();
    }

    public  List<CampaignListInfo> getCampaignListInfo(long campaignId, long engageId){
        AtomicReference<List<CampaignListInfo>> campaignListInfos = new AtomicReference<>();

        DataSourceLookupHelper.withLookupKey("main", () -> {
            campaignListInfos.set(campaignListInfoMapper.selectByCampaignIdAndEngageId(campaignId, engageId));
        });
        return campaignListInfos.get();
    }

    public  CampaignListInfo getByCampaignIdAndEngageIdAndListType(long campaignId, long engageId, String listType){
        AtomicReference<CampaignListInfo> campaignListInfo = new AtomicReference<>();
        DataSourceLookupHelper.withLookupKey("main", () -> {
            campaignListInfo.set(campaignListInfoMapper.selectByCampaignIdAndEngageIdAndListType(campaignId, engageId, listType));
        });
        return campaignListInfo.get();
    }

    public List<CampaignListInfo> getCampaignLevelInfo(long campaignId, List<CampaignListInfo> campaignInfo) {
        List<CampaignListInfo> infoList = new ArrayList<>();
        campaignInfo.forEach(campaignListInfo -> {
            //找到所有营销活动的List信息。
            if (campaignListInfo.getCampaignId().equals(campaignId) && campaignListInfo.getEngageId() < 1L) {
                infoList.add(campaignListInfo);
            }
        });
        return infoList;
    }

    public List<CampaignListInfo> getEngageLevelListInfo(long campaignId, long engageId, List<CampaignListInfo> campaignInfo) {
        List<CampaignListInfo> infoList = new ArrayList<>();
        campaignInfo.forEach(campaignListInfo -> {
            //找到所有营销活动的List信息。
            if (campaignListInfo.getCampaignId().equals(campaignId) && campaignListInfo.getEngageId().equals(engageId)) {
                infoList.add(campaignListInfo);
            }
        });
        return infoList;
    }

    public CampaignListInfo updateExecutionTime(long campaignId, long engageId, String listType, Instant now) {
        CampaignListInfo listInfo = this.getByCampaignIdAndEngageIdAndListType(campaignId, engageId, listType);
        if(listInfo == null){
            log.error("List info not found for campaignId: {}, engageId: {}, listType: {}", campaignId, engageId, listType);
        }
        listInfo.setExecutionTime(now);
        this.updateById(listInfo);
        return listInfo;
    }
}
