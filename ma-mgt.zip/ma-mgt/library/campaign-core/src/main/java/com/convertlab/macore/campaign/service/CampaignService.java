package com.convertlab.macore.campaign.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.LocalDateTimeUtil;
import cn.hutool.core.lang.Dict;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.util.StrUtil;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.jdbc.datasource.lookup.DataSourceLookupHelper;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.principal.context.PrincipalContextHolder;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.campaign.common.enums.CampaignEngageStepEnum;
import com.convertlab.macore.campaign.common.enums.CampaignExuectionModeEnum;
import com.convertlab.macore.campaign.common.enums.TimeStrategyTypeEnum;
import com.convertlab.macore.campaign.common.helper.HandleAttrHelper;
import com.convertlab.macore.campaign.common.utils.BeanCopyUtils;
import com.convertlab.macore.campaign.common.utils.JacksonUtils;
import com.convertlab.macore.campaign.mapper.CampaignExecutionTaskMapper;
import com.convertlab.macore.campaign.mapper.CampaignFilterMapper;
import com.convertlab.macore.campaign.mapper.CampaignOutboundEngageMapper;
import com.convertlab.macore.campaign.mapper.MarketingCampaignMapper;
import com.convertlab.macore.campaign.model.dto.*;
import com.convertlab.macore.campaign.model.entity.*;
import com.convertlab.macore.campaign.service.legacy.cms.client.CmsServiceClient;
import com.convertlab.macore.campaign.service.legacy.cms.model.CampaignCheckExistsRequest;
import com.convertlab.macore.campaign.service.legacy.cms.model.CampaignCheckExistsResponse;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import static com.convertlab.macore.campaign.common.enums.SegmentationTypeEnum.*;
import static com.convertlab.macore.campaign.model.dto.CampaignChannelEventStageDto.SYSTEM_CHANNEL_TYPES;

/**
 * CampaignV3 CRUD，Validation, Edit Helper service
 */
@Service
@Slf4j
public class CampaignService {

    public final static String FEATURE_CAMPAIGN_V4 = "campaign_v4";

    public CampaignService(CmsServiceClient cmsServiceClient, HandleAttrHelper handleAttrHelper,
                           MarketingCampaignMapper marketCampaignMapper, CampaignStrategyService campaignStrategyService,
                           MainTargetAudienceService mainTargetAudienceService, OutboundEngageService outboundEngageService,
                           CampaignFilterMapper campaignFilterMapper, CampaignTemplateService campaignTemplateService,
                           CampaignOutboundEngageMapper campaignOutboundEngageMapper, CampaignMetaService campaignMetaService,
                           CampaignExecutionTaskMapper campaignExecutionTaskMapper) {
        this.cmsServiceClient = cmsServiceClient;
        this.handleAttrHelper = handleAttrHelper;
        this.marketCampaignMapper = marketCampaignMapper;
        this.campaignStrategyService = campaignStrategyService;
        this.mainTargetAudienceService = mainTargetAudienceService;
        this.outboundEngageService = outboundEngageService;
        this.campaignFilterMapper = campaignFilterMapper;
        this.campaignTemplateService = campaignTemplateService;
        this.campaignOutboundEngageMapper = campaignOutboundEngageMapper;
        this.campaignMetaService = campaignMetaService;
        this.campaignExecutionTaskMapper = campaignExecutionTaskMapper;
    }

    private final CmsServiceClient cmsServiceClient;
    private final HandleAttrHelper handleAttrHelper;
    private final MarketingCampaignMapper marketCampaignMapper;
    private final CampaignStrategyService campaignStrategyService;
    private final MainTargetAudienceService mainTargetAudienceService;
    private final OutboundEngageService outboundEngageService;

    private final CampaignTemplateService campaignTemplateService;
    private final CampaignFilterMapper campaignFilterMapper;
    private final CampaignExecutionTaskMapper campaignExecutionTaskMapper;
    private final CampaignMetaService campaignMetaService;

    @Value("${kafka.campaign.addCampaignLog.topic}")
    String addCampaignLogTopic;

    public boolean checkCampaignUuidExists(String campaignUuid) {
        CampaignCheckExistsRequest request = new CampaignCheckExistsRequest();
        request.setUuid(campaignUuid);
        CampaignCheckExistsResponse campaignCheckExistsResponse = cmsServiceClient.checkCampaignExists(request);
        return campaignCheckExistsResponse.isExistUuid();
    }

    /**
     * Save Campaign
     *
     * @param dto CampaignDTO
     */
    @DataSourceLookup("main")
    @Transactional
    public Long saveCampaign(CampaignDTO dto) {
        if (Objects.nonNull(dto.getDateEnd()) && dto.getDateEnd().isBefore(dto.getDateStart())) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000008", "dateEnd must be after dateStart");
        }

        if (this.checkCampaignUuidExists(dto.getCode())) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000009", "code already exists", new String[]{dto.getCode()});
        }

        // check data
        checkData(dto);

        // save campaign
        MarketingCampaign campaign = BeanUtil.copyProperties(dto, MarketingCampaign.class);
        campaign.setCreatedBy(PrincipalContextHolder.getUserId());
        marketCampaignMapper.insert(buildCampaign(dto, campaign));

        // save strategy
        CampaignAudienceStrategy strategy = campaignStrategyService.saveOrUpdateStrategy(dto, campaign.getId());

        // save target audience
        mainTargetAudienceService.saveMainTargetAudience(campaign.getId(), strategy.getId(), dto.getAudienceStrategy().getTargetSegmentation());

        // save outbound engage
        outboundEngageService.saveEngage(dto, campaign.getId(), strategy.getId());

        // update template use count
        campaignTemplateService.updateUseCnt(dto.getTemplateId());

        return campaign.getId();
    }

    /**
     * Update Campaign
     *
     * @param dto CampaignDTO
     */
    @DataSourceLookup("main")
    @Transactional
    public Long updateCampaign(Long id, CampaignDTO dto) {
        MarketingCampaign campaign = marketCampaignMapper.selectById(id);
        if (Objects.isNull(campaign)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000002", "campaign not found:{}", new String[]{String.valueOf(id)});
        }

        if (!StrUtil.equals(campaign.getUuid(), dto.getCode()) && this.checkCampaignUuidExists(dto.getCode())) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000009", "code already exists {}", new String[]{dto.getCode()});
        }

        if (dto.getIsUptEngage() && !StrUtil.equals(campaign.getStatus(), MarketingCampaign.STATUS_DRAFT) && !StrUtil.equals(campaign.getStatus(), MarketingCampaign.STATUS_NOT_STARTED)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000014", "Unable to update the campaign because its status is marked as {}", new String[]{campaign.getStatus()});
        }

        // update campaign
        marketCampaignMapper.updateById(buildCampaign(dto, campaign));

        // api/copy campaign no strategy
        if (Objects.isNull(dto.getAudienceStrategy())) {
            return campaign.getId();
        }

        // check data
        checkData(dto);

        // update strategy
        CampaignAudienceStrategy strategy = campaignStrategyService.saveOrUpdateStrategy(dto, campaign.getId());

        // update target audience
        mainTargetAudienceService.updateMainTargetAudience(campaign.getId(), strategy.getId(), dto.getAudienceStrategy().getTargetSegmentation());

        // update outbound engage
        if (dto.getIsUptEngage()) {
            outboundEngageService.updateEngage(dto, campaign.getId(), strategy.getId());
        }

        return campaign.getId();
    }

    @DataSourceLookup("main")
    @Transactional
    public Long guideEngage(Long id, CampaignEngageGuideDTO dto) {
        MarketingCampaign campaign = marketCampaignMapper.selectById(id);
        if (Objects.isNull(campaign)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000002", "campaign not found {}", new String[]{String.valueOf(id)});
        }

        if (CollUtil.isEmpty(dto.getEngageList())) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000015", "Unable to update engage because its engage list is empty.{}", new String[]{String.valueOf(id)});
        }

        if (hasMissingChannelTemplate(BeanCopyUtils.copyList(dto.getEngageList(), CampaignOutboundEngage::new))) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000020", "Channel strategy channel template is required");
        }

        CampaignEngageGuideDTO.Node engage = dto.getEngageList().get(0);
        if (Objects.nonNull(campaign.getDateFinish()) && campaign.getDateFinish().isBefore(LocalDateTime.now())) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000028", "DateEnd must be after current time");
        }

        if (Objects.nonNull(engage.getChannelData()) && isAnyChannelTypeNotSystem(engage.getChannelData())) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000032", "Channel type is not valid");
        }

        if (StrUtil.equals(PSYCHOGRAPHIC_SEGMENTATION.getName(), engage.getAudienceStrategy())
                && dto.getEngageList().stream().anyMatch(item -> Objects.isNull(item.getAudienceData()) || item.getAudienceData().isEmpty())) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000021", "Psychographic filters is required");
        }

        if (StrUtil.equals(engage.getTimeStrategy(), TimeStrategyTypeEnum.SCHEDULED.getName())
                && !StrUtil.equals(MULTIPLE_WAVED_SEGMENTATION.getName(), engage.getAudienceStrategy())
                && dto.getEngageList().stream().anyMatch(item -> Objects.isNull(item.getTimeData()) || item.getTimeData().isEmpty()
                || campaign.getDateStart().isAfter(LocalDateTimeUtil.parse(MapUtil.getStr(item.getTimeData(), "scheduledDate"), DatePattern.UTC_PATTERN)))) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000019", "scheduledDate must be after dateStart");
        }

        if (StrUtil.equals(MULTIPLE_WAVED_SEGMENTATION.getName(), engage.getAudienceStrategy())
                && dto.getEngageList().stream().anyMatch(item -> Objects.isNull(item.getTimeData())
                || campaign.getDateStart().isAfter(LocalDateTimeUtil.parse(MapUtil.getStr(item.getTimeData(), "date_of_next_wave"), DatePattern.UTC_PATTERN))
                || ((Objects.nonNull(campaign.getDateFinish()) && campaign.getDateFinish().isBefore(LocalDateTimeUtil.parse(MapUtil.getStr(engage.getTimeData(), "date_of_next_wave"), DatePattern.UTC_PATTERN)))))) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000022", "waveTime must be between dateStart and dateEnd");
        }

        if (StrUtil.equals(MULTIPLE_WAVED_SEGMENTATION.getName(), engage.getAudienceStrategy()) && isAnyConversionEventMissing(dto.getEngageList())) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000035", "Conversion event is required");
        }

        if (StrUtil.equals(MANUAL_PERCENTAGE_SEGMENTATION.getName(), engage.getAudienceStrategy())) {
            double totalRate = dto.getEngageList().stream().mapToDouble(item -> Double.parseDouble(item.getAudienceData().get("percentage").toString())).sum();
            if (totalRate != 1) {
                throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000011", "audience strategy percentage is not valid", new String[]{String.valueOf(totalRate)});
            }
        }

        if (dto.getEngageList().stream().anyMatch(item -> Double.parseDouble(item.getControlGroupData().get("percentage").toString()) > 1)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000013", "controlGroup percentage must be less than 1");
        }

        outboundEngageService.guideEngage(dto, id);
        return campaign.getId();
    }

    @DataSourceLookup("main")
    public CampaignDetailDTO findById(Long campaignId) {
        MarketingCampaign campaign = marketCampaignMapper.selectById(campaignId);
        if (Objects.isNull(campaign)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000002", "campaign not found", new String[]{String.valueOf(campaignId)});
        }
        CampaignDetailDTO detailDto = BeanUtil.copyProperties(campaign, CampaignDetailDTO.class);
        detailDto.setCode(campaign.getUuid());
        detailDto.setName(campaign.getTitle());
        detailDto.setDateEnd(campaign.getDateFinish());
        detailDto.setAttrs(handleAttrHelper.getCampaignAttr(campaign));

        CampaignAudienceStrategy strategy = campaignStrategyService.getStrategyByCampaignId(campaignId);
        if (Objects.isNull(strategy)) {
            strategy = new CampaignAudienceStrategy();
            strategy.setCampaignId(campaignId);
            strategy.setStrategyContent(JacksonUtils.toJSONString(MapUtil.newHashMap()));
        }
        detailDto.setStrategy(BeanCopyUtils.copyBean(strategy, CampaignStrategyDTO::new));

        List<CampaignOutboundEngage> engageList = outboundEngageService.getEngageByCampaignId(campaignId);
        Map<Long, Map<String, String>> engageAttributeDataMap = campaignMetaService.getEngageAttributeData(campaignId);
        List<CampaignEngageDTO> engages = engageList.stream().map(engage -> {
            CampaignEngageDTO newInstance = BeanCopyUtils.copyBean(engage, CampaignEngageDTO::new);
            newInstance.setEngageAttribute(engageAttributeDataMap.get(newInstance.getId()));
            return newInstance;
        }).collect(Collectors.toList());
        detailDto.setEngageList(engages);

        return detailDto;
    }

    /**
     * copy Campaign
     *
     * @param campaignId campaign id
     * @param name       campaign name
     * @param code       campaign code
     * @return boolean
     */
    @DataSourceLookup("main")
    @Transactional
    public Long copyCampaign(Long campaignId, String name, String code, Boolean isContainStrategy) {
        if (this.checkCampaignUuidExists(code)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000009", "code already exists {}", new String[]{code});
        }

        MarketingCampaign campaign = marketCampaignMapper.selectById(campaignId);
        if (Objects.isNull(campaign)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000002", "campaign not found {}", new String[]{String.valueOf(campaignId)});
        }

        MarketingCampaign copyCampaign = BeanUtil.copyProperties(campaign, MarketingCampaign.class, "id", "tenantId", "creatorName",
                "updaterName", "creatorId", "updaterId", "dateCreated", "lastUpdated");
        copyCampaign.setUuid(code);
        copyCampaign.setTitle(name);
        copyCampaign.setStatus(MarketingCampaign.STATUS_DRAFT);
        copyCampaign.setCreatedBy(PrincipalContextHolder.getUserId());
        copyCampaign.setOwnerId(PrincipalContextHolder.getUserId());
        copyCampaign.setDeptCode(PrincipalContextHolder.getDeptCode());
        marketCampaignMapper.insert(copyCampaign);

        if (Objects.nonNull(campaign.getTemplateId()) && campaign.getTemplateId() > 0) {
            campaignTemplateService.updateUseCnt(campaign.getTemplateId());
        }

        if (!isContainStrategy) {
            return copyCampaign.getId();
        }

        CampaignAudienceStrategy strategy = campaignStrategyService.getStrategyByCampaignId(campaignId);
        if (Objects.nonNull(strategy)) {
            CampaignAudienceStrategy copyStrategy = BeanUtil.copyProperties(strategy, CampaignAudienceStrategy.class, "id", "tenantId", "campaignId");
            copyStrategy.setCampaignId(copyCampaign.getId());
            campaignStrategyService.getBaseMapper().insert(copyStrategy);
            mainTargetAudienceService.copyMainTargetAudience(campaignId, copyCampaign.getId(), copyStrategy.getId());
        }

        outboundEngageService.copyEngine(campaignId, copyCampaign.getId());
        return copyCampaign.getId();
    }

    /**
     * delete Campaign
     *
     * @param id campaign id
     * @return boolean
     */
    @DataSourceLookup("main")
    public boolean delCampaign(Long id) {
        MarketingCampaign campaign = marketCampaignMapper.selectById(id);
        if (Objects.isNull(campaign)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000002", "campaign not found:{}", new String[]{String.valueOf(id)});
        }

        List<String> statusList = Arrays.asList(MarketingCampaign.STATUS_DRAFT, MarketingCampaign.STATUS_STOPPED);
        if (!statusList.contains(campaign.getStatus())) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000031", "campaign status is not allow to operate:{}", new String[]{String.valueOf(campaign.getStatus())});
        }

        campaign.setStatus(MarketingCampaign.STATUS_DELETED);
        return marketCampaignMapper.updateById(campaign) > 0;
    }

    /**
     * 获取engage steps
     *
     * @param campaignId 活动Id
     * @param engageId   计划Id
     * @return dto
     */
    @DataSourceLookup("main")
    public List<CampaignEngageStepDTO> findEngageSteps(Long campaignId, Long engageId) {
        MarketingCampaign campaign = marketCampaignMapper.selectById(campaignId);
        if (Objects.isNull(campaign)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000002", "campaign not found:{}", new String[]{String.valueOf(campaignId)});
        }

        CampaignOutboundEngage outboundEngage = outboundEngageService.getById(engageId);
        if (Objects.isNull(outboundEngage)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000006", "The campaign outbound engage could not be found using the provided ID. {}", new String[]{String.valueOf(engageId)});
        }

        List<CampaignExecutionTask> taskList = campaignExecutionTaskMapper.getByCampaignIdAndEngageId(campaignId, engageId);
        if (CollUtil.isEmpty(taskList)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000027", "The campaign task could not be found campaignId: {} engageId: {}", new String[]{String.valueOf(engageId), String.valueOf(campaignId)});
        }

        Map<String, String> map = taskList.stream().collect(Collectors.toMap(CampaignExecutionTask::getTaskType, CampaignExecutionTask::getTaskStatus, (v1, v2) -> v1));
        List<CampaignEngageStepDTO> dtoList = CampaignEngageStepEnum.toList();

        dtoList.forEach(item -> {
            if (map.containsKey(item.getStep())) {
                item.setStatus(map.get(item.getStep()));
            }

            if (StrUtil.equals(item.getStep(), CampaignEngageStepEnum.RUNNING.getName())) {
                if (StrUtil.equals(outboundEngage.getStatus(), CampaignOutboundEngage.ENGAGE_STATUS_RUNNING)) {
                    item.setStatus(CampaignExecutionTask.TASK_STATUS_RUNNING);
                }

                if (StrUtil.equals(outboundEngage.getStatus(), CampaignOutboundEngage.ENGAGE_STATUS_STOPPED)) {
                    item.setStatus(CampaignExecutionTask.TASK_STATUS_FINISHED);
                }

                // 周期性
                if (StrUtil.equals(outboundEngage.getTimeStrategy(), TimeStrategyTypeEnum.PERIODIC.getName())) {
                    List<CampaignEngageStepDTO.PeriodSegmentationResult> segmentationResults =
                            campaignExecutionTaskMapper.getByCampaignIdAndEngageIdAndTaskType(campaignId, engageId, CampaignExecutionTask.TASK_TYPE_SEGMENTATION)
                                    .stream()
                                    .map(task -> CampaignEngageStepDTO.PeriodSegmentationResult.builder()
                                            .taskTriggerDate(task.getTaskTriggerDate())
                                            .taskStatus(task.getTaskStatus())
                                            .build()).collect(Collectors.toList());
                    item.setSegmentationList(segmentationResults);
                }
            }
        });
        return dtoList;
    }


    public boolean sendCampaignLogToKafka(CampaignLogDTO campaignLogDTO) {
//        long uid = uidGenerator.getUID();
//        campaignLogDTO.setId(uid);
        Map<String, Object> dtoMap = JsonUtils.instance().convertToMap(campaignLogDTO);
        Long tenantId = TenantContextHolder.getTenantId();
        dtoMap.put("tenantId", tenantId);
        String requestId = MDC.get("x_request_id");
        dtoMap.put("requestId", requestId);


        Map<String, Object> dataMap = new HashMap<>();
        dtoMap.forEach((k, v) -> {
            if (v != null) {
                // key to underscore
                k = k.replaceAll("([A-Z])", "_$1").toLowerCase();
                dataMap.put(k, v);
            }
        });

        Map<String, Object> opData = new HashMap<>();
        opData.put("type", "insert");
        opData.put("data", dataMap);
//        kafkaTemplate.send(addCampaignLogTopic, opData);
        return true;
    }


    public MarketingCampaign buildCampaign(CampaignDTO dto, MarketingCampaign campaign) {
        campaign.setUuid(dto.getCode());
        campaign.setTitle(dto.getName());
        campaign.setDateStart(dto.getDateStart());
        campaign.setDateFinish(dto.getDateEnd());
        campaign.setEditorVersion("4.0");
        campaign.setApprovalId(dto.getApprovalId());
        campaign.setExecutionMode(CampaignExuectionModeEnum.FORM_MODE.getName());

        // 自定义属性
        if (!dto.getAttrs().isEmpty()) {
            handleAttrHelper.setCampaignAttr(dto.getAttrs(), campaign);
        }
        return campaign;
    }

    public void checkData(CampaignDTO dto) {
        CampaignDTO.AudienceStrategy audienceStrategy = dto.getAudienceStrategy();
        if (Objects.nonNull(audienceStrategy.getSegmentationType()) && StrUtil.equals(audienceStrategy.getSegmentationType(), MANUAL_PERCENTAGE_SEGMENTATION.getName())) {
            Map<String, Object> data = audienceStrategy.getData();
            if (Objects.isNull(data.get("rate"))) {
                throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000010", "audience strategy percentage is required");
            }

            String reteStr = data.get("rate").toString();
            String pureData = reteStr.substring(1, reteStr.length() - 1);
            List<String> dataList = Arrays.asList(pureData.split(", "));
            boolean isValid;
            if (MapUtil.getBool(data, "remaining_segmentation_enabled")) {
                isValid = dataList.stream().filter(item -> !item.equals("remain")).mapToDouble(Double::parseDouble).sum() > 1;
            } else {
                isValid = dataList.stream().mapToDouble(Double::parseDouble).sum() != 1;
            }

            if (isValid) {
                throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000011", "audience strategy percentage is not valid");
            }
        }

        if (StrUtil.equals(audienceStrategy.getSegmentationType(), MULTIPLE_WAVED_SEGMENTATION.getName())) {
            LocalDateTime dateOfFirstWave = LocalDateTimeUtil.parse(MapUtil.getStr(audienceStrategy.getData(), "dateOfFirstWave"), DatePattern.UTC_PATTERN);
            if (dto.getDateStart().isAfter(dateOfFirstWave)) {
                throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000022", "WaveTime must be after dateStart");
            }

            if (Objects.nonNull(dto.getDateEnd()) && dto.getDateEnd().isBefore(dateOfFirstWave)) {
                throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000023", "WaveTime must be before dateEnd");
            }
        }

        Map<String, Object> controlData = dto.getControlGroupStrategy().getData();
        if (Objects.isNull(controlData)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000012", "controlGroupStrategy is required");
        }

        Double percentage = MapUtil.getDouble(controlData, "percentage");
        if (percentage > 1) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000013", "controlGroup percentage must be less than 1", new String[]{String.valueOf(percentage)});
        }

        if (TimeStrategyTypeEnum.SCHEDULED.getName().equals(dto.getTimeStrategy().getStrategy())) {
            if (Objects.isNull(dto.getTimeStrategy().getData().get("scheduledDate"))) {
                throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000018", "scheduleTime is required");
            }

            LocalDateTime scheduledDate = LocalDateTimeUtil.parse(MapUtil.getStr(dto.getTimeStrategy().getData(), "scheduledDate"), DatePattern.UTC_PATTERN);
            if (scheduledDate.isBefore(dto.getDateStart()) || (Objects.nonNull(dto.getDateEnd()) && scheduledDate.isAfter(dto.getDateEnd()))) {
                throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000019", "scheduledDate must be between dateStart and dateEnd", new String[]{scheduledDate.toString()});
            }
        }
    }

    public CampaignFullDataDTO getCampaignFullData(long campaignId) {

        CampaignFullDataDTO campaignFullDataDTO = new CampaignFullDataDTO();

        DataSourceLookupHelper.withLookupKey("main", () -> {

            MarketingCampaign campaign = marketCampaignMapper.selectById(campaignId);
            if (campaign == null) {
                throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_108_000002", "The campaign could not be found using the provided ID. {}", new String[]{String.valueOf(campaignId)});
            }

            CampaignAudienceStrategy audienceStrategy = campaignStrategyService.getStrategyByCampaignId(campaignId);
            if (audienceStrategy == null) {
                throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_108_000005", "The campaign audience strategy could not be found using the provided ID. {}", new String[]{String.valueOf(campaignId)});
            }

            List<CampaignOutboundEngage> outboundEngageList = outboundEngageService.getEngageByCampaignId(campaignId);
            if (CollectionUtils.isEmpty(outboundEngageList)) {
                throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_108_000006", "The campaign outbound engage could not be found using the provided ID. {}", new String[]{String.valueOf(campaignId)});
            }

            if (Objects.nonNull(campaign.getDateFinish()) && campaign.getDateFinish().isBefore(LocalDateTime.now()) && StrUtil.equals(campaign.getStatus(), MarketingCampaign.STATUS_RUNNING)) {
                throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000028", "DateEnd must be after current time");
            }

            if (hasMissingChannelTemplate(outboundEngageList)) {
                throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000020", "Channel strategy channel template is required");
            }

            List<CampaignMainTargetAudienceMapping> mainTargetAudience = mainTargetAudienceService.getBaseMapper().selectByCampaignId(campaignId);
            if (CollectionUtils.isEmpty(mainTargetAudience)) {
                throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_108_000007", "The campaign main target audience could not be found using the provided ID. {}", new String[]{String.valueOf(campaignId)});
            }

            CampaignFilter campaignFilter = campaignFilterMapper.selectById(audienceStrategy.getFilterId());

            campaignFullDataDTO.setCampaign(campaign);
            campaignFullDataDTO.setAudienceStrategy(audienceStrategy);
            campaignFullDataDTO.setMainTargetAudience(mainTargetAudience);
            campaignFullDataDTO.setOutboundEngageList(outboundEngageList);
            campaignFullDataDTO.setCampaignFilter(campaignFilter);

        });
        return campaignFullDataDTO;
    }

    private boolean hasMissingChannelTemplate(List<CampaignOutboundEngage> outboundEngageList) {
        return outboundEngageList.stream().anyMatch(this::isChannelTemplateIdMissing);
    }

    private boolean isChannelTemplateIdMissing(CampaignOutboundEngage item) {
        Dict channelData = JacksonUtils.parseObject(item.getChannelData(), Dict.class);
        return Objects.isNull(channelData) || channelData.isEmpty()
                || Objects.isNull(channelData.get("messagingTypes"))
                || isAnyMessagingTypeMissing(channelData);
    }

    private boolean isAnyMessagingTypeMissing(Map<String, Object> channelData) {
        List<Dict> messagingTypes = JacksonUtils.parseArray(JacksonUtils.toJSONString(channelData.get("messagingTypes")), Dict.class);
        return messagingTypes.stream()
                .anyMatch(ms -> Objects.isNull(ms.get("channelTemplateId")));
    }

    private boolean isAnyChannelTypeNotSystem(Map<String, Object> channelData) {
        List<Dict> messagingTypes = JacksonUtils.parseArray(JacksonUtils.toJSONString(channelData.get("messagingTypes")), Dict.class);
        return messagingTypes.stream()
                .anyMatch(ms -> (!ms.containsKey("isThirdPartyChannel") && !SYSTEM_CHANNEL_TYPES.contains(ms.getStr("channelType"))));
    }

    private boolean isAnyConversionEventMissing(List<CampaignEngageGuideDTO.Node> engageList) {
        return engageList.stream()
                .anyMatch(ms -> Objects.isNull(ms.getAudienceData()) || !ms.getAudienceData().containsKey("conversionEvent"));
    }

    public void updateEngageStatus(long engageId, String status) {
        DataSourceLookupHelper.withLookupKey("main", () -> {
            CampaignOutboundEngage engage = outboundEngageService.getBaseMapper().selectById(engageId);
            if (engage != null) {
                engage.setStatus(status);
                outboundEngageService.getBaseMapper().updateById(engage);
            }
        });
    }

    public void updateCampaignStatus(long campaignId, String status) {
        DataSourceLookupHelper.withLookupKey("main", () -> {
            MarketingCampaign campaign = marketCampaignMapper.selectById(campaignId);
            if (campaign != null) {
                campaign.setStatus(status);
                marketCampaignMapper.updateById(campaign);
            }
        });
    }

    final CampaignOutboundEngageMapper campaignOutboundEngageMapper;

    public void updateEngageStatus(CampaignOutboundEngage engage, String status) {
        DataSourceLookupHelper.withLookupKey("main", () -> {
            engage.setStatus(status);
            campaignOutboundEngageMapper.updateById(engage);
        });
    }

    public List<CampaignOutboundEngage> getEngageListByCampaignId(Long campaignId) {
        AtomicReference<List<CampaignOutboundEngage>> engageListByCampaignId = new AtomicReference<>();
        DataSourceLookupHelper.withLookupKey("main", () -> {
            engageListByCampaignId.set(campaignOutboundEngageMapper.getEngageListByCampaignId(campaignId));
        });
        return engageListByCampaignId.get();
    }

    public CampaignAudienceStrategy getCampaignAudienceStrategy(Long campaignId) {
        return campaignStrategyService.getStrategyByCampaignId(campaignId);
    }

    public void updateEngageById(CampaignOutboundEngage engage) {
        DataSourceLookupHelper.withLookupKey("main", () -> {
            campaignOutboundEngageMapper.updateById(engage);
        });
    }
}
