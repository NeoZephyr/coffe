package com.convertlab.macore.campaign.service;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.excel.write.style.column.LongestMatchColumnWidthStyleStrategy;
import com.convertlab.foundation.api.queryengine.GdmQuery;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.gdmmeta.model.FieldType;
import com.convertlab.foundation.library.jdbc.datasource.lookup.DataSourceLookupHelper;
import com.convertlab.foundation.library.queryengine.client.QueryEngineClient;
import com.convertlab.foundation.library.sqlprocessor.ProcessingMode;
import com.convertlab.macore.campaign.common.utils.NameUtils;
import com.convertlab.macore.campaign.mapper.CampaignListInfoMapper;
import com.convertlab.macore.campaign.mapper.CampaignOutboundEngageMapper;
import com.convertlab.macore.campaign.mapper.ListMemberBatchTaskMapper;
import com.convertlab.macore.campaign.mapper.MarketingCampaignMapper;
import com.convertlab.macore.campaign.model.dto.CampaignExcelData;
import com.convertlab.macore.campaign.model.entity.CampaignListInfo;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.google.common.collect.Lists;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.util.*;

@Service
@Slf4j
public class CampaignReporterService {

    @Autowired
    QueryEngineClient queryEngineClient;
    @Autowired
    MarketingCampaignMapper marketCampaignMapper;
    @Autowired
    CampaignListInfoMapper campaignListInfoMapper;
    @Autowired
    CampaignOutboundEngageMapper campaignOutboundEngageMapper;
    @Autowired
    ListMemberBatchTaskMapper listMemberBatchTaskMapper;

    public byte[] getExcelData(Long campaignId){
        List<CampaignExcelData> reportData = getReportData(campaignId);
        return writeExcelData(reportData);
    }

    private List<CampaignExcelData> getReportData(Long campaignId){
        Long campaignIdLong = campaignId;
        MarketingCampaign marketingCampaign = getMarketingCampaignById(campaignId);
        if (marketingCampaign == null){
            return new ArrayList<>();
        }
        String campaignIdStr = marketingCampaign.getUuid();
        List<CampaignListInfo> campaignListInfos = selectByCampaignId(campaignId);
        CampaignListInfoUtil.appendTargetListId(campaignListInfos);

        String gdql = "select cbi.profile_type,cbi.engage_id,cbi.flow_id,cbi.batch_id,cbi.channel_type,cbi.messaging_type,cbi.channel_instance_id,cbi.tunnel_id,cbi.template_id,\n" +
                "       nvl(ces.send,0) as send,nvl(ces.failed_to_send,0) as failed_to_send,nvl(ces.delivered,0) as delivered,nvl(ces.received,0) as received,nvl(ces.failed_to_delivered,0) as failed_to_delivered,nvl(ces.opened,0) as opened,nvl(ces.clicked,0) as clicked\n" +
                "from (\n" +
                "        select campaign_id,profile_type,engage_id,flow_id,batch_id,channel_type,messaging_type,channel_instance_id,tunnel_id,template_id\n" +
                "        from campaign_batch_info where campaign_id = ? \n" +
                "        ) cbi left join\n" +
                "    (\n" +
                "        select\n" +
                "               batch_id,\n" +
                "               SUM(CASE WHEN event in ('send_sms','cp_mms_event_send_mms','cp_extzhuji_event_send_msg','email_requested','wechat_send_template_message','mobile_app_notification_requested','cp_extwechatapp_event_wechat_app_send_subscribe_msg') THEN cnt END) AS send,\n" +
                "                SUM(CASE WHEN event in ('sms_incorrect', 'cp_mms_event_mms_incorrect', 'cp_extzhuji_event_incorrect_msg','email_incorrect', 'wechat_template_msg_incorrect', 'send_mobile_app_notification_incorrect','cp_extwechatapp_event_wechat_app_send_msg_incorrect') THEN cnt END) AS failed_to_send,\n" +
                "                SUM(CASE WHEN event in ('sms_delivered', 'cp_mms_event_mms_delivered', 'cp_extzhuji_event_delivered_msg' ,'email_delivered', 'wechat_template_msg_delivered', 'send_mobile_app_notification','cp_extwechatapp_event_wechat_app_send_msg_success') THEN cnt END) AS delivered,\n" +
                "                SUM(CASE WHEN event in ('mobile_app_notification_received') THEN cnt END) AS received,\n" +
                "                SUM(CASE WHEN event in ('sms_failed', 'cp_mms_event_mms_failed', 'cp_extzhuji_event_failed_msg','email_invalid', 'wechat_template_msg_failed', 'cp_extwechatapp_event_wechat_app_send_msg_failed') THEN cnt END) AS failed_to_delivered,\n" +
                "                SUM(CASE WHEN event in ('email_opened') THEN cnt END) AS opened,\n" +
                "                SUM(CASE WHEN event in ('click_link_in_sms', 'cp_mms_event_mms_clicked' , 'cp_extzhuji_event_clicked_msg', 'click_link_in_email', 'click_mobile_app_notification') THEN cnt END) AS clicked\n" +
                "        from (\n" +
                "\t        select batch_id,event,count(*) as cnt\n" +
                "\t        from customer_event\n" +
                "\t        where batch_id is not null \n" +
                "\t        group by batch_id,event) a\n" +
                "        where event in ('send_sms','cp_mms_event_send_mms','cp_extzhuji_event_send_msg','email_requested','wechat_send_template_message','mobile_app_notification_requested','cp_extwechatapp_event_wechat_app_send_subscribe_msg',\n" +
                "                        'sms_incorrect', 'cp_mms_event_mms_incorrect', 'cp_extzhuji_event_incorrect_msg','email_incorrect', 'wechat_template_msg_incorrect', 'send_mobile_app_notification_incorrect','cp_extwechatapp_event_wechat_app_send_msg_incorrect',\n" +
                "                        'sms_delivered', 'cp_mms_event_mms_delivered', 'cp_extzhuji_event_delivered_msg' ,'email_delivered', 'wechat_template_msg_delivered', 'send_mobile_app_notification','cp_extwechatapp_event_wechat_app_send_msg_success',\n" +
                "                        'mobile_app_notification_received',\n" +
                "                        'sms_failed', 'cp_mms_event_mms_failed', 'cp_extzhuji_event_failed_msg','email_invalid', 'wechat_template_msg_failed', 'cp_extwechatapp_event_wechat_app_send_msg_failed',\n" +
                "                        'email_opened',\n" +
                "                        'click_link_in_sms', 'cp_mms_event_mms_clicked' , 'cp_extzhuji_event_clicked_msg', 'click_link_in_email', 'click_mobile_app_notification'\n" +
                "                        )\n" +
                "        group by batch_id\n" +
                "        ) ces on cbi.batch_id = ces.batch_id";

        List<GdmQuery.Arg> args = new ArrayList<>(Arrays.asList(
                new GdmQuery.Arg(campaignIdLong, FieldType.Long)));

        GdmQuery.Request request = new GdmQuery.Request(gdql, args, null, false, ProcessingMode.OLAP.toString());
        GdmQuery.Response response = queryEngineClient.queryEngineQuery(request);
        List<Map<String, Object>> rows = response.getRows();
        List<CampaignExcelData> resObj = new ArrayList<>();
        for (Map<String, Object> row : rows){
//            Map<String,Object> item = new HashMap<>();
            CampaignExcelData item = new CampaignExcelData();
            item.setCampaignName(marketingCampaign.getTitle());
            item.setCampaignCode(marketingCampaign.getUuid());
            item.setGroupType("实验组");

            Long engageId = null;
            if (row.containsKey("engage_id") && row.get("engage_id") != null){
                engageId =Long.parseLong(row.get("engage_id").toString());
            }
            item.setEngageId(engageId);
            item.setStrategyCode(getStrategyCode(engageId));

            Boolean bfind = false;
            if (campaignListInfos != null && campaignListInfos.size()>0){
                CampaignListInfo result = null;
                for (CampaignListInfo campaignListInfo : campaignListInfos){
                    if (campaignListInfo.getEngageId() != null && campaignListInfo.getEngageId().equals(engageId) && campaignListInfo.getListType().equalsIgnoreCase(NameUtils.TARGET_GROUP)){
                        result = campaignListInfo;
                        break;
                    }
                }
                if (result == null){
                    for (CampaignListInfo campaignListInfo : campaignListInfos){
                        if (campaignListInfo.getListType().equalsIgnoreCase(NameUtils.TARGET_GROUP)){
                            result = campaignListInfo;
                            break;
                        }
                    }
                }
                if (result!= null){
                    bfind = true;
                    item.setExecuteTime(result.getExecutionTime().toString());
                    item.setTotal(getListTotal(result.getListId()));
                    item.setListId(result.getListId());
                }
            }
            item.setChannelType(row.get("channel_type").toString());
            item.setTemplateName("");
            item.setSend(Long.parseLong(row.get("send").toString()));
            item.setFailedToSend(Long.parseLong(row.get("failed_to_send").toString()));
            item.setDelivered(Long.parseLong(row.get("delivered").toString()));
            item.setReceived(Long.parseLong(row.get("received").toString()));
            item.setFailedToDelivered(Long.parseLong(row.get("failed_to_delivered").toString()));
            item.setOpened(Long.parseLong(row.get("opened").toString()));
            item.setClicked(Long.parseLong(row.get("clicked").toString()));
            resObj.add(item);
        }
        //补对照组
        campaignListInfos.stream()
                .filter(listInfo->listInfo.getListType().equalsIgnoreCase(NameUtils.CONTROL_GROUP))
                .forEach(listInfo->{
//                    Map<String,Object> item = new HashMap<>();
                    CampaignExcelData item = new CampaignExcelData();
                    item.setCampaignName(marketingCampaign.getTitle());
                    item.setCampaignCode(marketingCampaign.getUuid());
                    item.setGroupType("对照组");

                    String strategyCode = getStrategyCode(listInfo.getEngageId());
                    item.setStrategyCode(strategyCode);
                    item.setExecuteTime(listInfo.getExecutionTime().toString());

                    item.setTotal(getListTotal(listInfo.getListId()));
//                    item.put("channelType", "");
//                    item.put("templateName","");
//                    item.put("send",0);
//                    item.put("failedToSend" ,0);
//                    item.put("delivered",0);
//                    item.put("received",0);
//                    item.put("failedToDelivered",0);
//                    item.put("opened",0);
//                    item.put("clicked",0);
                    resObj.add(item);
//                    resObj.add(CampaignExcelData.build(item));
                });
        return resObj;
    }

    public Long getListTotal(Long listId){
        return listMemberBatchTaskMapper.selectListTotalById(listId);
    }

    public String getStrategyCode(Long engageId){
        if (engageId == null){
            return null;
        }
        CampaignOutboundEngage campaignOutboundEngage = DataSourceLookupHelper.withLookupKey("main", () -> campaignOutboundEngageMapper.selectById(engageId));
        if (campaignOutboundEngage == null){
            return  null;
        }
        return campaignOutboundEngage.getCode();
    }

    public List<CampaignListInfo> selectByCampaignId(Long campaignId){
        List<CampaignListInfo> campaignListInfos = DataSourceLookupHelper.withLookupKey("main", () ->campaignListInfoMapper.selectByCampaignId(campaignId));
        return campaignListInfos;
    }

    public MarketingCampaign getMarketingCampaignById(Long campaignId){
        MarketingCampaign marketingCampaign = DataSourceLookupHelper.withLookupKey("main", () ->marketCampaignMapper.selectById(campaignId));
        return marketingCampaign;
    }

    public byte[] writeExcelData(List<CampaignExcelData> sheetData) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        EasyExcel.write(bos, CampaignExcelData.class).sheet("模板").doWrite(sheetData);
        return bos.toByteArray();
    }
}
