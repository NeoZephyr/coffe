package com.convertlab.macore.campaign.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Data
public class CampaignDetailDTO implements Serializable {

    private String name;

    private String code;

    private String status;

    private String executionMode;

    private Integer folderId;

    private Long approvalId;

    private Boolean editable;

    // 自定义属性 KV
    private Map<String, Object> attrs;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime dateStart;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime dateEnd;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime dateCreated;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime lastUpdated;

    private Long creatorId;

    private String creatorName;

    private Long updaterId;

    private String updaterName;

    private CampaignStrategyDTO strategy;

    private List<CampaignEngageDTO> engageList;

}
