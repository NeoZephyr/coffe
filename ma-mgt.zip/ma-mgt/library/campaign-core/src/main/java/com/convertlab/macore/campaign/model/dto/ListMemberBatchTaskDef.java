package com.convertlab.macore.campaign.model.dto;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ListMemberBatchTaskDef {

    private String campaignCode;
    private Map<String, Object> filter =  new HashMap<>();
    private String filteredListName;
    private String excludedListName;
    private String controlGroupListName;
    private Double controlGroupPercentage;
    private String targetGroupListName;
    private String splitStrategy;
    private List<ListMemberBatchTaskDefSplitNode> splitList = new ArrayList<>();

}

