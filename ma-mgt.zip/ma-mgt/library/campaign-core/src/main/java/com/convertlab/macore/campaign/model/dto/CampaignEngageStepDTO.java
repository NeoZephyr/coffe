package com.convertlab.macore.campaign.model.dto;

import lombok.*;

import java.io.Serializable;
import java.time.Instant;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
public class CampaignEngageStepDTO implements Serializable {

    private String step;

    private String status;

    private List<PeriodSegmentationResult> segmentationList;

    @Data
    @Builder
    public static class PeriodSegmentationResult {

        private String taskStatus;

        private Instant taskTriggerDate;
    }
}
