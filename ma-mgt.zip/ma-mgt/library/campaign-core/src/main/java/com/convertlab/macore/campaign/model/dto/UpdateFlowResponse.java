package com.convertlab.macore.campaign.model.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class UpdateFlowResponse extends SaveFlowResponse{

}
