package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.macore.campaign.common.utils.AudienceStrategyConstants;
import com.convertlab.macore.campaign.mapper.CampaignExecutionTaskMapper;
import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.runtime.taskchain.CampaignSegmentPeriodicTaskChain;
import com.convertlab.macore.campaign.runtime.taskchain.EngageSegmentPeriodicTaskChain;
import com.convertlab.macore.campaign.runtime.taskchain.TimeStrategyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@Service
@Slf4j
@RequiredArgsConstructor
public class PeriodicSchedulerTaskService extends AbstractTaskRuntimeService {

    final EngageSegmentPeriodicTaskChain engageSegmentPeriodicTaskChain;
    final CampaignSegmentPeriodicTaskChain campaignSegmentPeriodicTaskChain;
    final CampaignExecutionTaskMapper campaignExecutionTaskMapper;

    @Override
    public TaskResult onStart(CampaignExecutionTask task) {
        TaskResult result = new TaskResult(true);

        //load Campaign setting data
        CampaignFullDataDTO campaignFullData = campaignService.getCampaignFullData(task.getCampaignId());

        //generate task chain
        List<CampaignExecutionTask> taskList = generateTaskChainForNextMonth(campaignFullData, task);

        //将任务按照时间进行排序
        campaignTaskService.sortByTimeArrange(taskList);

        //将当前任务链的最后一个任务的nextTaskId设置为taskList中第一个值的id
        connectTaskChain(task, taskList);

        //save and update task chain.
        campaignTaskService.saveAndUpdateTaskChain(taskList);

        return result;
    }

    void connectTaskChain(CampaignExecutionTask task, List<CampaignExecutionTask> taskList){

        //如果当前的任务即为最后一个任务，则将其nextTaskId设置为taskList中第一个值的id
        if(task.getNextTaskId() == null){
            task.setNextTaskId(taskList.get(0).getId());
            taskList.add(0, task);
            return;
        }

        //如果当前任务不是最后一个任务, 获得所有未执行的任务列表。
        List<CampaignExecutionTask> notStartedAndPreparedTaskByCampaignId = campaignTaskService.getNotStartedAndScheduledTasks(task.getCampaignId());

        //找到nextTaskId为null的任务
        Optional<CampaignExecutionTask> first = notStartedAndPreparedTaskByCampaignId.stream()
                .filter(t -> t.getNextTaskId() == null).findFirst();

        if(first.isPresent()){
            first.get().setNextTaskId(taskList.get(0).getId());
            taskList.add(0, first.get());
        }else{
            throw new RuntimeException("Failed to find nextTaskId is null task");
        }
    }

    private List<CampaignExecutionTask> generateTaskChainForNextMonth(CampaignFullDataDTO campaignFullData, CampaignExecutionTask task) {
        switch (campaignFullData.getAudienceStrategy().getSegmentationType()){
            case AudienceStrategyConstants.MANUAL_SPECIFIED_SEGMENTATION:
                return engageSegmentPeriodicTaskChain.createTaskChainForNextMonth(campaignFullData,task.getTaskTriggerDate());

            default:
                return campaignSegmentPeriodicTaskChain.createTaskChainForNextMonth(campaignFullData, task.getTaskTriggerDate());
        }
    }


    @Override
    public void onFinish(CampaignExecutionTask task) {

    }

    @Override
    public TaskResult checkProgress(CampaignExecutionTask task) {
        return null;
    }
}
