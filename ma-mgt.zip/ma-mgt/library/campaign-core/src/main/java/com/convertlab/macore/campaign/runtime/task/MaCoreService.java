package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.foundation.library.context.Context;
import com.convertlab.foundation.library.context.ContextHelper;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.jdbc.datasource.lookup.DataSourceLookupHelper;
import com.convertlab.macore.campaign.mapper.ListMemberBatchTaskMapper;
import com.convertlab.macore.campaign.model.dto.*;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.service.legacy.cms.client.CustomerServiceClient;
import com.convertlab.macore.campaign.service.legacy.cms.client.FlowManagerServiceClient;
import com.convertlab.macore.campaign.service.legacy.cms.client.MaCoreServiceClient;
import com.convertlab.macore.campaign.service.legacy.cms.model.ListMemberBatchTask;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

@Service
@AllArgsConstructor
@Slf4j
public class MaCoreService {

    final ListMemberBatchTaskMapper listMemberBatchTaskMapper;

    final MaCoreServiceClient maCoreServiceClient;

    final CustomerServiceClient customerServiceClient;

    final FlowManagerServiceClient flowManagerServiceClient;

    public FolderDTO upsertFolder(String folderName, String folderType, MarketingCampaign campaign) {
        //如果数据库中已经有这个名字的文件夹，则直接返回。
        AtomicReference<FolderDTO> folderDTO = new AtomicReference<>();

        DataSourceLookupHelper.withLookupKey("main", () -> {
            folderDTO.set(listMemberBatchTaskMapper.selectFolderByTypeAndName(folderType, folderName));
        });

        if(folderDTO.get() != null){
            return folderDTO.get();
        }

        Context context = getContext(campaign);
        ContextHelper.withContext(context, () -> {
            //如果数据库中没有这个文件夹，则调用MaCoreServiceClient创建文件夹。
            FolderDTO folder = maCoreServiceClient.createFolder(new CreateFolderRequest(0, folderType, folderName));
            folderDTO.set(folder);
        });
        return folderDTO.get();
    }

    public ListDTO upsertList(String name, long folderId, String description, MarketingCampaign campaign){

        Context context = getContext(campaign);
        AtomicReference<ListDTO> listDTO = new AtomicReference<>();
        ContextHelper.withContext(context, () -> {

            //如果数据库中已经有这个名字的list，则直接返回。
            listDTO.set(listMemberBatchTaskMapper.selectListByName(name));

            //如果数据库中没有这个list，则调用CustomerServiceClient创建文件夹。
            if (listDTO.get() == null) {
                Map<String, Object> requestData = new HashMap<>();
                requestData.put("name", name);
                requestData.put("isEtl", true);
                requestData.put("isStatic", false);
                requestData.put("description", description);
                listDTO.set(customerServiceClient.createList(requestData));
            }

            if (listDTO.get().getId() < 1) {
                throw new BusinessException("创建list失败", "创建list失败");
            }

            //add to folder
            AddToFolderRequest request = new AddToFolderRequest();
            request.setFolderId(folderId);
            request.setType("list");
            List<String> contents = new ArrayList<>();
            contents.add(String.valueOf(listDTO.get().getId()));
            request.setContents(contents);

            maCoreServiceClient.addToFolder(request);
        });
        return listDTO.get();
    }


    public Context getContext(MarketingCampaign campaign) {
        Context context = new Context();
        context.setTenantId(campaign.getTenantId());
        context.setUserId(campaign.getOwnerId());
        context.setUserName(campaign.getCreatorName());
        context.setDeptCode(campaign.getDeptCode());
        return context;
    }

    public DeployFlowResponse deployFlow(CampaignFullDataDTO campaignFullData, CampaignOutboundEngage outboundEngage) {
        Context context = getContext(campaignFullData.getCampaign());

        AtomicReference<DeployFlowResponse> deployFlowResponse = new AtomicReference<>();
        ContextHelper.withContext(context, () -> {
            //发布flow
            deployFlowResponse.set(flowManagerServiceClient.deployFlow(outboundEngage.getFlowId()));
        });
        return deployFlowResponse.get();
    }

    public SaveFlowResponse saveFlow(long folderId, String flowName, String flowDefinition, CampaignFullDataDTO campaignFullData){
        Context context = getContext(campaignFullData.getCampaign());
        final SaveFlowResponse[] saveFlowResponse = {null};
        ContextHelper.withContext(context, () -> {
            DataSourceLookupHelper.withLookupKey("main", () -> {
                saveFlowResponse[0] = upsertFlow(flowName,  folderId, flowDefinition);
            });
        });

        return saveFlowResponse[0];
    }

    private SaveFlowResponse upsertFlow(String name, long folderId, String flowData){
        //如果数据库中已经有这个名字的flow，则直接返回。
        List<SaveFlowResponse> flowDTOs = listMemberBatchTaskMapper.selectFlowByName(name);

        SaveFlowResponse flowDTO = null;
        //如果数据库中没有这个flow，则调用flow创建自动流。
        if(flowDTOs.size() == 0){
            flowDTO = flowManagerServiceClient.saveFlow(flowData);
        }else{
            flowDTO = flowManagerServiceClient.updateFlow(flowDTOs.get(0).getId(), flowData);
        }

        if(flowDTO.getId() < 1){
            throw new BusinessException("创建flow失败", "创建flow失败");
        }

        //add to folder
        AddToFolderRequest request = new AddToFolderRequest();
        request.setFolderId(folderId);
        request.setType("flow");
        List<String> contents = new ArrayList<>();
        contents.add(String.valueOf(flowDTO.getId()));
        request.setContents(contents);

        maCoreServiceClient.addToFolder(request);
        return flowDTO;
    }

    public Map<String, Object> triggerListMemberBatchTask(ListMemberBatchTaskRequest request, MarketingCampaign campaign){
        //调用客户服务创建ListMemberBatchTask
        Context context = getContext(campaign);
        AtomicReference<Map<String, Object>> result = new AtomicReference<>(new HashMap<>());
        ContextHelper.withContext(context, () -> {
            Map<String, Object> listMemberBatchTask = customerServiceClient.createListMemberBatchTask(request);
            result.set(listMemberBatchTask);
        });
        return result.get();
    }

    public List<ListMemberBatchTask> selectByIdList(List<String> idList){
        return listMemberBatchTaskMapper.selectByIdList(idList);
    }

    public ListDTO selectListById(Long listId){
        return listMemberBatchTaskMapper.selectListById(listId);
    }

}
