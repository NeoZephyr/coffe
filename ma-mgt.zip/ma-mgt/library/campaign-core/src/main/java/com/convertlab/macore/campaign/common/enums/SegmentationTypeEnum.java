package com.convertlab.macore.campaign.common.enums;

import lombok.Getter;

@Getter
public enum SegmentationTypeEnum {
    MANUAL_SPECIFIED_SEGMENTATION("Manual_Specified_Segmentation", "目标群组"),
    MANUAL_PERCENTAGE_SEGMENTATION("Manual_Percentage_Segmentation", "比例切分"),
    MANUAL_QUANTITY_SEGMENTATION("Manual_Quantity_Segmentation", "固定数量切分"),
    PSYCHOGRAPHIC_SEGMENTATION("Psychographic_Segmentation", "客户画像"),
    MULTIPLE_WAVED_SEGMENTATION("Multiple_Waved_Segmentation", "活动波次"),
    ;
    private final String name;
    private final String desc;

    SegmentationTypeEnum(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }
}
