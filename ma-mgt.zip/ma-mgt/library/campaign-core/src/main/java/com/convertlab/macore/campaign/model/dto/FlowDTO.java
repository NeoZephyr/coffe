package com.convertlab.macore.campaign.model.dto;

import lombok.Data;

@Data
public class FlowDTO {
    long id;
    String name;
}
