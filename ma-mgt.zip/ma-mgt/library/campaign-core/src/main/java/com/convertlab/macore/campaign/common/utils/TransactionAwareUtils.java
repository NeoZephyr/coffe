package com.convertlab.macore.campaign.common.utils;

import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

public class TransactionAwareUtils {
    public static void transactionAwareCmd(Runnable cmd) {
        if (TransactionSynchronizationManager.isActualTransactionActive()) {
            TransactionSynchronizationManager.registerSynchronization(
                    new TransactionSynchronization() {
                        @Override
                        public void afterCommit() {
                            cmd.run();
                        }
                    }
            );
        } else {
            cmd.run();
        }
    }
}
