package com.convertlab.macore.campaign.service;

import com.convertlab.data.job.core.biz.model.ReturnT;
import com.convertlab.data.job.core.biz.model.datajob.DataJobParam;
import com.convertlab.data.job.core.constants.DataJobConstants;
import com.convertlab.data.job.core.context.ClJobContext;
import com.convertlab.data.job.core.context.ClJobHelper;
import com.convertlab.data.job.core.handler.annotation.ClJob;
import com.convertlab.data.job.core.util.DateUtil;
import com.convertlab.data.job.core.util.data.BizJobService;
import com.convertlab.data.job.core.util.data.JobData;
import com.convertlab.foundation.library.business.feature.FeatureClient;
import com.convertlab.foundation.library.business.feature.QueryToggleTenantsResponse;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClientWrapper;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.jdbc.datasource.lookup.DataSourceLookupHelper;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.support.ExecutorUtils;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.campaign.common.utils.NameUtils;
import com.convertlab.macore.campaign.mapper.CampaignListInfoMapper;
import com.convertlab.macore.campaign.mapper.CampaignOutboundEngageMapper;
import com.convertlab.macore.campaign.mapper.MarketingCampaignMapper;
import com.convertlab.macore.campaign.mapper.SegmentMapper;
import com.convertlab.macore.campaign.model.dto.CampaignChannelEventStageDto;
import com.convertlab.macore.campaign.model.dto.GroupFactsDataDTO;
import com.convertlab.macore.campaign.model.dto.ListDTO;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignListInfo;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.model.entity.Segment;
import com.convertlab.macore.campaign.runtime.task.MaCoreService;
import com.convertlab.macore.campaign.service.legacy.cms.client.SparkScheduleFeignClient;
import com.convertlab.macore.mamgt.common.utils.NamingUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

import static com.convertlab.foundation.library.constant.CommonErrors.VALIDATION_ERROR;

@Service
@Slf4j
public class CampaignFactsDataSyncService {
    public static final String CAMPAIGN_GROUP_FACTS_DATA_HANDLER = "CampaignGroupFactsDataHandler";
    public static final String CAMPAIGN_EVENT_FACTS_DATA_HANDLER = "CampaignEventFactsDataHandler";
    public static final String CAMPAIGN_GROUP_FACTS_JOB_TYPE = "campaign_group_facts_sync";
    public static final String CAMPAIGN_EVENT_FACTS_JOB_TYPE = "campaign_event_facts_sync";
    public static final String APP_NAME = "ma-mgt";
    private static final String LOG_PREFIX = "<CampaignFactsDataSyncService>";
    private static final String SPARK_JOB_JAR_NAME = "spark-jobs";
    private static final String CAMPAIGN_GROUP_FACTS_JOB_NAME = "spark-campaign-group-facts-job";
    private static final String CAMPAIGN_EVENT_FACTS_JOB_NAME = "spark-campaign-event-facts-job";
    private static final ZoneId SHANGHAI_ZONE = ZoneId.of("Asia/Shanghai");

    @Autowired
    BizJobService bizJobService;
    @Autowired
    SparkScheduleFeignClient sparkScheduleFeignClient;
    @Autowired
    CampaignListInfoMapper campaignListInfoMapper;
    @Autowired
    MarketingCampaignMapper marketCampaignMapper;
    @Autowired
    CampaignOutboundEngageMapper campaignOutboundEngageMapper;
    @Autowired
    SegmentMapper segmentMapper;
    @Autowired
    StringRedisTemplate stringRedisTemplate;

    @Autowired
    FeatureClient featureClient;

    @Autowired
    GsMetaClientWrapper gsMetaClientWrapper;

    @Autowired
    CampaignStatService campaignStatService;

    @Autowired
    MaCoreService maCoreService;

    Executor executor = ExecutorUtils.createMdcTtlExecutor("CampaignFactsDataSyncSubmit", 2);

    public void importGroupFactsData(Long campaignId, Long engageId, String audienceStrategy) {
        try {
            //MarketingCampaign 的定义
            MarketingCampaign campaign = DataSourceLookupHelper.withLookupKey("main", () -> marketCampaignMapper.selectById(campaignId));
            GroupFactsDataDTO dto = new GroupFactsDataDTO();
            dto.setAudienceStrategy(audienceStrategy);
            dto.setCampaignId(String.valueOf(campaignId));
            dto.setCampaignName(campaign.getTitle());
            dto.setGroupFactsOpt(GroupFactsDataDTO.GroupFactOpt.INIT_GROUP_FACTS);
            //如果是单个engage，也就是设置多波段或者周期性营销中，单个engage的群组生成后
            if (engageId != null && engageId > 0) {
                CampaignOutboundEngage campaignOutboundEngage = DataSourceLookupHelper.withLookupKey("main", () -> campaignOutboundEngageMapper.selectById(engageId));
                if (campaignOutboundEngage != null) {
                    GroupFactsDataDTO.EngageControlGroup engageControlGroup = new GroupFactsDataDTO.EngageControlGroup();
                    engageControlGroup.engageId = String.valueOf(engageId);
                    //无论是周期性营销的自动流使用的群组还是多波段的规则群组，都是targetGroup
                    //TODO 确认 mainList 为空，因为mainList是sparkjob判断是不是活动级别群组结果的依据
                    //TODO 确认 对应filter和controlGroup的情况
                    engageControlGroup.engageListId = String.valueOf(campaignOutboundEngage.getListId());
                    engageControlGroup.engageTargetListId = String.valueOf(campaignOutboundEngage.getListId());
                    dto.setEngageControlGroups(Collections.singletonList(engageControlGroup));
                } else {
                    log.error("Not found CampaignOutboundengage by engageId: {}", engageId);
                }
            }
            importGroupFactsData(dto);
        } catch(Exception exception) {
            String msg = "importGroupFactsData with exception for <campaignId: " + campaignId + ",engageId: "+ engageId + ",audienceStrategy: " + audienceStrategy +">";
            log.error(msg, exception);
        }
    }

    public void updateGroupFactsGroupDate(MarketingCampaign campaign, CampaignExecutionTask task,
                                          CampaignListInfo listInfo, CampaignOutboundEngage outboundEngage) {
        Long campaignId = task.getCampaignId();
        String campaignName = campaign.getTitle();
        Long engageId = task.getEngageId();
        Long engageTargetListId = outboundEngage.getListId();
        String audienceStrategy = outboundEngage.getAudienceStrategy();
        Instant executionTime = listInfo.getExecutionTime();
        
        try{
            Assert.notNull(executionTime, "executionTime is null for campaign_list_info.id: "+  listInfo.getId());
            Assert.notNull(engageTargetListId, "list_id is null for campaig_outbound_engage.id: " + engageId);

            updateGroupFactsGroupDate(campaignId, campaignName, engageId, engageTargetListId, audienceStrategy, executionTime);
        } catch (Exception e) {
            log.error("{} updateGroupFactsGroupDate failed for <campaignId: {},engageId: {}. errorMessage is: {}.", LOG_PREFIX, campaignId, engageId, e.getMessage(), e);
        }
    }

    public void updateGroupFactsGroupDate(Long campaignId, String campaignName, Long engageId,
                                          Long engageTargetListId, String audienceStrategy, Instant executionTime) {

        if (engageTargetListId == null) { //only occur for request from rest api
            CampaignOutboundEngage engage = DataSourceLookupHelper.withLookupKey("main", () ->
                    campaignOutboundEngageMapper.selectById(engageId)
            );
            if (engage != null) {
                engageTargetListId = engage.getListId();
            }
            Assert.state(engageTargetListId != null, "found null listId of campaign_outbound_engage.id: " + engageId);
        }
        ListDTO listDTO = maCoreService.selectListById(engageTargetListId);
        Assert.notNull(listDTO, "found null listDTO by listId: " + engageTargetListId);
        LocalDateTime lastUpdated = listDTO.getLastUpdated();
        ZonedDateTime segmentLastUpdate = lastUpdated.atZone(ZoneId.of("UTC"));
        ZonedDateTime shangHaiDateTime = segmentLastUpdate.withZoneSameInstant(SHANGHAI_ZONE);
        LocalDate segmentationGenDate = shangHaiDateTime.toLocalDate();
        if (executionTime == null) { //only occur for request from rest api
            CampaignListInfo campaignListInfo = DataSourceLookupHelper.withLookupKey("main", () ->
                campaignListInfoMapper.selectByCampaignIdAndEngageIdAndListType(campaignId, engageId, NameUtils.TARGET_GROUP)
            );
            if (campaignListInfo != null) {
                executionTime = campaignListInfo.getExecutionTime();
            }
            log.info("{} updateGroupFactsGroupDate getExecutionTime for <campaignId: {},engageId: {},listId: {}>", LOG_PREFIX, campaignId, engageId, engageTargetListId);

            Assert.state(executionTime != null, "found null executionTime of campaign_list_info.id: "+  campaignListInfo.getId());
        }
        LocalDate engageExecutionDate = executionTime.atZone(SHANGHAI_ZONE).toLocalDate();
        boolean segmentIsGeneratedInTheSameDay = segmentationGenDate.equals(engageExecutionDate);
        if (segmentIsGeneratedInTheSameDay) {
            log.info("segmentation is generated in the same day, no need to update group date for campaign_group_facts<campaignId: " + campaignId + ",engageId: "+ engageId + ">");
        } else {
            String segmentationGeneratedDate = segmentLastUpdate.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
            String engageStartDate = engageExecutionDate.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
            GroupFactsDataDTO dto = new GroupFactsDataDTO();
            dto.setAudienceStrategy(audienceStrategy);
            dto.setCampaignId(String.valueOf(campaignId));
            dto.setCampaignName(campaignName);
            dto.setGroupFactsOpt(GroupFactsDataDTO.GroupFactOpt.UPDATE_ENGAGE_GROUP_DATE);

            GroupFactsDataDTO.EngageControlGroup engageControlGroup = new GroupFactsDataDTO.EngageControlGroup();
            engageControlGroup.engageId = String.valueOf(engageId);
            engageControlGroup.engageListId = String.valueOf(engageTargetListId);
            engageControlGroup.engageTargetListId = String.valueOf(engageTargetListId);
            engageControlGroup.segmentationGeneratedDate = segmentationGeneratedDate;
            engageControlGroup.engageStartDate = engageStartDate;
            dto.setEngageControlGroups(Collections.singletonList(engageControlGroup));
            log.info("updateGroupFactsGroupDate for campaign_group_facts<campaignId: {}, engageId: {}>, the dto: {}",
                    campaignId, engageId, JsonUtils.instance().obj2Json(dto));
            importGroupFactsData(dto);
        }
    }

    public Map importGroupFactsData(GroupFactsDataDTO dto){

        String tenantId = MDC.get("x_tenant_id");
        List<String> jobIds = new ArrayList<>();
        jobIds.add(CAMPAIGN_GROUP_FACTS_JOB_TYPE);
        jobIds.add(tenantId);
        jobIds.add(dto.campaignId);

        if (dto.getEngageControlGroups() != null && dto.getEngageControlGroups().size() == 1) {
            jobIds.add(dto.getEngageControlGroups().get(0).engageId);
        }
        String jobNo = JobData.createJobNo(jobIds.toArray(new String[0]));
        JobData jobData = JobData.builder().build();
        jobData.setJobType(CAMPAIGN_GROUP_FACTS_JOB_TYPE);
        jobData.setJobNo(jobNo);
        jobData.setNeedNotification(true);
        jobData.setGroupNo(null);
        jobData.setGroupName(null);
        jobData.setJobParameters(JsonUtils.instanceOfDto().obj2Json(dto));
        jobData.setParentJobNos(null);
        jobData.setAppName(APP_NAME);
        jobData.setName(dto.campaignName);
        String userId = MDC.get("x_user_id");
        if (StringUtils.isBlank(userId) || !StringUtils.isNumeric(userId)) {
            jobData.setCreatorId(0L);
        } else {
            jobData.setCreatorId(Long.parseLong(userId));
        }
        jobData.setJobHandler(CAMPAIGN_GROUP_FACTS_DATA_HANDLER);
        jobData.setCronCondition(JsonUtils.instanceOfDto().obj2Json(buildManualCronCondition()));
        jobData.setRetryCount(1);
        jobData.setRetryWaitMinutes(5);
        log.info("{} create group facts data job, the job is: {}", LOG_PREFIX, jobData);

        boolean exist = bizJobService.exist(Integer.parseInt(tenantId), CAMPAIGN_GROUP_FACTS_JOB_TYPE, jobNo);
        log.info("{} create group facts data job, exist job is: {}", LOG_PREFIX, exist);
        ReturnT result = null;
        if (!exist) {
            // 若不存在则创建新任务。或者更新任务
            jobData.setBizUuid(UUID.randomUUID().toString());
            result = bizJobService.createAndStartBizJob(jobData);
            log.info("{} createAndStartBizJob result is: {}", LOG_PREFIX, result);
            if (result == null || result.getError() != null) {
                log.error("{} createAndStartBizJob failed, jobNo is: {}, result: {}", LOG_PREFIX, jobNo, result);
            }
        }else {
            result = bizJobService.updateJobAndGroup(jobData);
            log.info("{} updateJobAndGroup result is: {}", LOG_PREFIX, result);
            if (result == null || result.getError() != null) {
                log.error("{} updateJobAndGroup failed, jobNo is: {}, result: {}", LOG_PREFIX, jobNo, result);
            }else {
                result = bizJobService.runBizJobWithParams(jobData.getJobNo(), jobData.getJobParameters());
                log.info("{} runBizJobWithParams result is: {}", LOG_PREFIX, result);
                if (result == null || result.getError() != null){
                    log.error("{} runBizJobWithParams failed, jobNo is: {}, result: {}", LOG_PREFIX, jobNo, result);
                }
            }
        }
        return obj2Map(result);
    }

    @ClJob(value = CAMPAIGN_GROUP_FACTS_DATA_HANDLER)
    public void startGroupFactsJob() {
        log.info("{} start importGroupFactsData. tenantId: {}, jobParam: {}, batchNo: {}, jobNo: {}", LOG_PREFIX, ClJobHelper.getTenantId(), ClJobHelper.getJobParam(), ClJobHelper.getBatchNo(), ClJobHelper.getJobNo());
        String jobNo = ClJobHelper.getJobNo();
        String jobParam = ClJobHelper.getJobParam();

        GroupFactsDataDTO dto = JsonUtils.instanceOfDto().json2Obj(jobParam, GroupFactsDataDTO.class);
        Long tenantId = ClJobHelper.getTenantId();
        Long taskId = ClJobHelper.getTaskId();
        // 因为cl_job和foundation对于租户id的注入不兼容，需要手动设置临时租户ID
        try (TemporaryTenantContext ignore = new TemporaryTenantContext(tenantId, "")) {
            List<CampaignListInfo> campaignListInfos = getCampaignListInfos(dto);
            CampaignListInfoUtil.appendTargetListId(campaignListInfos);
            updateDtoFactGroupList(dto, campaignListInfos);
            log.info("{} GroupFactsDataDTO after appendTargetListId: {}", LOG_PREFIX, JsonUtils.instance().obj2Json(dto));
            Map<String, Object> data = obj2Map(dto);
            data.put("taskId", taskId);
            data.put("tenantId", tenantId);
            data.put("campaignListInfos", campaignListInfos);
            data.put("listTypeInfos",getListType(dto));
            DataJobParam dataJobParam = buildDatajobParma();
            log.info("{} submit {} data:{} to processing", LOG_PREFIX,CAMPAIGN_GROUP_FACTS_JOB_NAME,JsonUtils.instance().obj2Json(data));
            Map<String, Object> response = submitJob(CAMPAIGN_GROUP_FACTS_JOB_NAME, data, 3, dataJobParam);
            log.info("{} submit {} resp:{}", LOG_PREFIX,CAMPAIGN_GROUP_FACTS_JOB_NAME,JsonUtils.instance().obj2Json(response));

        } catch (Exception e) {
            log.error("{} startGroupFactsJob failed. errorMessage is: {}.", LOG_PREFIX, e.getMessage(), e);
            throw new RuntimeException(e.getMessage());
        }
    }

    static GroupFactsDataDTO.EngageControlGroup getEngageGroup(GroupFactsDataDTO dto,Map<Long,GroupFactsDataDTO.EngageControlGroup> tempCache,Long engageId){
        GroupFactsDataDTO.EngageControlGroup engageControlGroup = tempCache.get(engageId);
        if (engageControlGroup == null){
            engageControlGroup = new GroupFactsDataDTO.EngageControlGroup();
            tempCache.put(engageId,engageControlGroup);
            dto.engageControlGroups.add(engageControlGroup);
            engageControlGroup.engageId = engageId.toString();
        }
        return engageControlGroup;
    }

    protected static void updateDtoFactGroupList(GroupFactsDataDTO dto, List<CampaignListInfo> campaignListInfos){
        GroupFactsDataDTO.EngageControlGroup groupInJobParams = null;
        if ( dto.engageControlGroups != null &&  dto.engageControlGroups.size() == 1) {
            groupInJobParams =  dto.engageControlGroups.get(0);
        }

        dto.listId = "";
        dto.filteredInListId = "";
        dto.filteredOutListId = "";
        dto.campaignTargetGroupId = "";
        dto.campaignControlGroupId = "";
        dto.engageControlGroups = new ArrayList<>();

        Map<Long,GroupFactsDataDTO.EngageControlGroup> tempCache = new HashMap<>();
        for (CampaignListInfo listInfo : campaignListInfos){
            if (listInfo.getListType().equalsIgnoreCase(NameUtils.MAIN_GROUP)){
                if (listInfo.getEngageId().equals(-1L)){
                    dto.listId = listInfo.getListId().toString();
                }else {
                    GroupFactsDataDTO.EngageControlGroup engageControlGroup = getEngageGroup(dto,tempCache,listInfo.getEngageId());
                    engageControlGroup.engageListId = listInfo.getListId().toString();
                }
            }else if (listInfo.getListType().equalsIgnoreCase(NameUtils.FILTERED_GROUP)){
                if (listInfo.getEngageId().equals(-1L)){
                    dto.filteredInListId = listInfo.getListId().toString();
                }else {
                    GroupFactsDataDTO.EngageControlGroup engageControlGroup = getEngageGroup(dto,tempCache,listInfo.getEngageId());
                    engageControlGroup.engageFilteredInListId = listInfo.getListId().toString();
                }
            }else if (listInfo.getListType().equalsIgnoreCase(NameUtils.EXCLUDED_GROUP)){
                if (listInfo.getEngageId().equals(-1L)){
                    dto.filteredOutListId = listInfo.getListId().toString();
                }else {
                    GroupFactsDataDTO.EngageControlGroup engageControlGroup = getEngageGroup(dto,tempCache,listInfo.getEngageId());
                    engageControlGroup.engageFilteredOutListId = listInfo.getListId().toString();
                }
            }else if (listInfo.getListType().equalsIgnoreCase(NameUtils.CONTROL_GROUP)){
                if (listInfo.getEngageId().equals(-1L)){
                    dto.campaignControlGroupId = listInfo.getListId().toString();
                }else {
                    GroupFactsDataDTO.EngageControlGroup engageControlGroup = getEngageGroup(dto,tempCache,listInfo.getEngageId());
                    engageControlGroup.engageControlGroupId = listInfo.getListId().toString();
                }
            }else if (listInfo.getListType().equalsIgnoreCase(NameUtils.TARGET_GROUP)){
                if (listInfo.getEngageId().equals(-1L)){
                    dto.campaignTargetGroupId = listInfo.getListId().toString();
                }else {
                    GroupFactsDataDTO.EngageControlGroup engageControlGroup = getEngageGroup(dto,tempCache,listInfo.getEngageId());
                    engageControlGroup.engageTargetListId = listInfo.getListId().toString();

                    if (groupInJobParams != null
                            && StringUtils.equals(groupInJobParams.engageTargetListId, engageControlGroup.engageTargetListId)
                            && groupInJobParams.engageStartDate != null
                            && groupInJobParams.segmentationGeneratedDate != null) {
                        engageControlGroup.engageStartDate = groupInJobParams.engageStartDate;
                        engageControlGroup.segmentationGeneratedDate = groupInJobParams.segmentationGeneratedDate;
                    }
                }
            }
        }
    }


    private List<CampaignListInfo> getCampaignListInfos(GroupFactsDataDTO dto){
        String campaignId = dto.getCampaignId();
        List<CampaignListInfo> campaignListInfos = DataSourceLookupHelper.withLookupKey("main", () ->campaignListInfoMapper.selectByCampaignId(Long.parseLong(campaignId)));
        List<GroupFactsDataDTO.EngageControlGroup> engageGroups = dto.getEngageControlGroups();
        Long engageId = -1L;
        //处理多波段或者周期性营销等和campaign时间不同步分群的情况
        if (campaignListInfos != null && engageGroups != null && engageGroups.size() == 1) {
            GroupFactsDataDTO.EngageControlGroup engageGroup = engageGroups.get(0);
            final Long newEngageId = Long.valueOf(engageGroup.engageId);
            campaignListInfos = campaignListInfos.stream()
                    .filter(item -> item.getEngageId().equals(newEngageId))
                    .collect(Collectors.toList());
            engageId = newEngageId;
        }
        String listInfoStr = CollectionUtils.isEmpty(campaignListInfos)? "[]" : JsonUtils.instance().obj2Json(campaignListInfos);
        log.info("{} getCampaignListInfos of <campaignId, engageId> : <{}, {}>, the listInfos :{}", LOG_PREFIX, campaignId, engageId, listInfoStr);
        return campaignListInfos;
    }

    private Map<String, Object> buildManualCronCondition() {
        Map<String, Object> cronConditionMap = new HashMap<>();
        Map<String, Object> cycle = new HashMap<>();
        cycle.put("type", DataJobConstants.CronCycleType.manual);
        cycle.put("time", "");
        Map<String, Object> effect = new HashMap<>();
        effect.put("type", DataJobConstants.CronEffectType.forever);
        cronConditionMap.put("cycle", cycle);
        cronConditionMap.put("effect", effect);
        return cronConditionMap;
    }
    private Map<String, Object> buildCronCondition() {
        Map<String, Object> cronConditionMap = new HashMap<>();
        Map<String, Object> cycle = new HashMap<>();
        cycle.put("type", DataJobConstants.CronCycleType.day);
        cycle.put("time", "00:30");
        Map<String, Object> effect = new HashMap<>();
        effect.put("type", DataJobConstants.CronEffectType.forever);
        cronConditionMap.put("cycle", cycle);
        cronConditionMap.put("effect", effect);
        cronConditionMap.put("scheduleConstrain", "oneTimeSchedule");
        return cronConditionMap;
    }
    public Map<String, Object> submitJob(String jobName,  Map<String, Object> data, int replica,DataJobParam dataJobParam) {
        data.put("requestId", MDC.get("x_request_id"));
        log.info("{} SparkJobHelper submitJob. jobName:{} ,replica:{} ,data:{} ,dataJobParam:{}", LOG_PREFIX, jobName, replica,
                JsonUtils.instanceOfDto().obj2Json(data),
                dataJobParam !=null ? JsonUtils.instanceOfDto().obj2Json(dataJobParam) : "null");
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("jobName", jobName);
        requestBody.put("jarName", SPARK_JOB_JAR_NAME);
        requestBody.put("data", data);
        requestBody.put("replica", replica);
        if (dataJobParam != null) {
            requestBody.put("dataJobParam", dataJobParam);
        }
        return sparkScheduleFeignClient.submitSparkJob(requestBody);
    }
    private DataJobParam buildDatajobParma() {
        DataJobParam dataJobParam = new DataJobParam();
        dataJobParam.setBatchNo(ClJobHelper.getBatchNo());
        dataJobParam.setJobNo(ClJobHelper.getJobNo());
        dataJobParam.setTenantId(ClJobHelper.getTenantId());
        dataJobParam.setTriggerParam(ClJobContext.getClJobContext().getJobParam());
        return dataJobParam;
    }
    private Map obj2Map(Object obj){
        String json = JsonUtils.instanceOfDto().obj2Json(obj);
        Map res = JsonUtils.instanceOfDto().json2Obj(json,Map.class);
        return res;
    }


    public Map importEventFactsData(Long campaignId, LocalDate startDate, LocalDate endDate){
        String tenantId = MDC.get("x_tenant_id");
        String jobNo = CAMPAIGN_EVENT_FACTS_JOB_TYPE;
        ReturnT<?> result;

        // 为了能够让 cl_job 找到 job，临时改动 tenantId 为 -2
        try (TemporaryTenantContext ignored = new TemporaryTenantContext(-2L)) {
            Map<String, Object> data = new HashMap<>();
            data.put("tenantId", tenantId);
            if (campaignId != null) {
                data.put("campaignId", campaignId);
            }
            if (startDate != null) {
               data.put("startDate", startDate.toString()) ;
            }
            if (endDate != null) {
                data.put("endDate", endDate.toString());
            }
            String paramText = JsonUtils.instanceOfDto().obj2Json(data, false);
            result = bizJobService.runBizJobWithParams(jobNo, paramText);
        }

        log.info("{} runBizJobWithParams result is: {}", LOG_PREFIX, result);

        if (result == null || result.getError() != null) {
            log.error("{} runBizJobWithParams failed, jobNo is: {}, result: {}", LOG_PREFIX, jobNo, result);
        }

        return obj2Map(result);
    }

    @ClJob(value = CAMPAIGN_EVENT_FACTS_DATA_HANDLER)
    public void startEventFactsJob() {
        log.info("{} Campaign event facts job is trigger. batchNo: {}, jobNo: {}, taskId: {}, params: {}",
                LOG_PREFIX, ClJobHelper.getBatchNo(), ClJobHelper.getJobNo(), ClJobHelper.getTaskId(), ClJobHelper.getJobParam());

        Long taskId = ClJobHelper.getTaskId();
        Long tenantId = null;
        Long campaignId = null;
        LocalDate startDate = null;
        LocalDate endDate = null;

        if (StringUtils.isNotBlank(ClJobHelper.getJobParam())) {
            Map<?, ?> params = JsonUtils.instanceOfDto().json2Obj(ClJobHelper.getJobParam(), Map.class);

            if (params != null && params.containsKey("tenantId")) {
                tenantId = Long.valueOf(params.get("tenantId").toString());
            }
            if (params != null && params.containsKey("campaignId")){
                campaignId = Long.valueOf(params.get("campaignId").toString());
            }
            if (params != null && params.containsKey("startDate")) {
                startDate = LocalDate.parse(params.get("startDate").toString());
            }
            if (params != null && params.containsKey("endDate")) {
                endDate = LocalDate.parse(params.get("endDate").toString());
            }
        }

        if (tenantId != null) {
            try (TemporaryTenantContext ignored = new TemporaryTenantContext(tenantId)) {
                Long currentTenantId = tenantId;
                Long currentCampaignId = campaignId;
                LocalDate currentStartDate = startDate;
                LocalDate currentEndDate = endDate;
                executor.execute(() -> {
                    triggerEventFactsJob(currentTenantId, currentCampaignId, taskId, currentStartDate, currentEndDate);
                });
                log.info("{} Campaign event facts job trigger for tenant: {} success.", LOG_PREFIX, ClJobHelper.getTenantId());
            } catch (Exception e) {
                log.info("{} Campaign event facts job trigger for tenant: {} failed.", LOG_PREFIX, ClJobHelper.getTenantId(), e);
            }

            return;
        }

        QueryToggleTenantsResponse response = featureClient.getToggleTenants(
                CampaignService.FEATURE_CAMPAIGN_V4,
                1000,
                0);

        if (CollectionUtils.isEmpty(response.getRows())) {
            log.info("No tenant found, skip CampaignEventFactsDataHandler.");
            return;
        }

        response.getRows().forEach(feature -> {
            Long tid = feature.getTenantId();

            try (TemporaryTenantContext ignored = new TemporaryTenantContext(tid)) {
                executor.execute(() -> {
                    triggerEventFactsJob(tid, null, taskId, null, null);
                });
                log.info("{} Campaign event facts job trigger for tenant: {} success.", LOG_PREFIX, tid);
            } catch (Exception e) {
                log.info("{} Campaign event facts job trigger for tenant: {} failed.", LOG_PREFIX, tid, e);
            }
        });
    }

    public void triggerEventFactsJob(Long tenantId, Long campaignId, Long taskId, LocalDate startDate, LocalDate endDate) {
        try (TemporaryTenantContext ignored = new TemporaryTenantContext(tenantId)) {
            try {
                Map<String, Object> data = new HashMap<>();
                data.put("taskId", taskId);
                data.put("tenantId", tenantId);
                data.put("campaignId", campaignId);

                ZoneId zoneid = ZoneId.of("Asia/Shanghai");
                ZonedDateTime now = ZonedDateTime.now(zoneid);
                ZonedDateTime startOfTheDay = (startDate == null) ? now.truncatedTo(ChronoUnit.DAYS)
                        : ZonedDateTime.of(startDate, LocalTime.now(), zoneid).truncatedTo(ChronoUnit.DAYS);

                ZonedDateTime prevDay = now.minusDays(1);
                ZonedDateTime startOfPrevDay = prevDay.truncatedTo(ChronoUnit.DAYS);

                ZonedDateTime nextDay = now.plusDays(1);
                ZonedDateTime startOfNextDay = (endDate == null) ? nextDay.truncatedTo(ChronoUnit.DAYS) :
                        ZonedDateTime.of(endDate, LocalTime.now(), zoneid).truncatedTo(ChronoUnit.DAYS);

                if (campaignId != null) { //对单个营销活动执行当天的事件数据同步
                    MarketingCampaign marketingCampaign = DataSourceLookupHelper.withLookupKey("main", () -> marketCampaignMapper.selectById(campaignId));
                    if (!campaignId.equals(-1L)  && marketingCampaign == null) {
                        log.error("{} Campaign event facts job trigger for tenant: {} failed, campaignId: {} not found.",
                                LOG_PREFIX, tenantId, campaignId);
                        throw new BusinessException(VALIDATION_ERROR, "MSG_108_000002",
                                "The campaign could not be found using the provided ID: " + campaignId, new String[]{String.valueOf(campaignId)});
                    }

//                long dayMilliSec = 1000 * 24 * 60 * 60L;
//                long newStart = (new Date().getTime() / dayMilliSec) * dayMilliSec;
                    long newStart = startOfTheDay.toInstant().toEpochMilli();
//                long endTime = newStart + dayMilliSec;
                    long endTime = startOfNextDay.toInstant().toEpochMilli();
                    data.put("triggerType", "manual");
                    data.put("startEventTime", newStart);
                    data.put("endEventTime", endTime);
                } else { //对租户的所有活动执行昨天的事件数据同步，前提是在第二天凌晨执行同步
                    String redisKey = String.format("%s-campaignEventDataSync-timeRange", tenantId);
                    String timeRange = stringRedisTemplate.opsForValue().get(redisKey);
                    long newStart = 0L;
//                long dayMilliSec = 1000 * 24 * 60 * 60L;
//                Long endTime = (new Date().getTime() / dayMilliSec) * dayMilliSec;
                    long endTime = startOfTheDay.toInstant().toEpochMilli();

                    if (StringUtils.isNotBlank(timeRange)) {
                        String[] startEndTime = timeRange.split("-");
                        newStart = Long.parseLong(startEndTime[1]);
                    }
                    data.put("triggerType", "scheduled");
                    data.put("startEventTime", newStart);
                    data.put("endEventTime", endTime);
                    stringRedisTemplate.opsForValue().set(redisKey, String.format("%d-%d", newStart, endTime));
                }
                data.put("marketingCampaignInfos", getNotFinishCampaign(campaignId));
                addEventParams(data);
                DataJobParam dataJobParam = buildDatajobParma();

                log.info("{} submit {} data:{} to processing", LOG_PREFIX, CAMPAIGN_EVENT_FACTS_JOB_NAME, JsonUtils.instance().obj2Json(data));
                Map<String, Object> response = submitJob(CAMPAIGN_EVENT_FACTS_JOB_NAME, data, 3, dataJobParam);
                log.info("{} submit {} resp:{}", LOG_PREFIX, CAMPAIGN_EVENT_FACTS_JOB_NAME, JsonUtils.instance().obj2Json(response));
            } catch (Exception e) {
                log.error("{} startEventFactsJob failed. errorMessage is: {}.", LOG_PREFIX, e.getMessage(), e);
                throw new IllegalStateException(e.getMessage());
            }
        }
    }

    void addEventParams(Map<String, Object> data) {
        //eventStages
        List<CampaignChannelEventStageDto> eventStages = campaignStatService.getChannelEventStageList();
        Map<String, List<String>> eventStageMap = new HashMap<>();
        eventStageMap.put("sentEvents", eventStages.stream().map(CampaignChannelEventStageDto::getSentEventId).filter(StringUtils::isNotBlank).collect(Collectors.toList()));
        // deliveredEvents, failedToSendEvents, failedToDeliverEvents, openedEvents, clickedEvents, receivedEvents
        eventStageMap.put("deliveredEvents", eventStages.stream().map(CampaignChannelEventStageDto::getDeliveredEventId).filter(StringUtils::isNotBlank).collect(Collectors.toList()));
        eventStageMap.put("failedToSendEvents", eventStages.stream().map(CampaignChannelEventStageDto::getFailedToSendEventId).filter(StringUtils::isNotBlank).collect(Collectors.toList()));
        eventStageMap.put("failedToDeliverEvents", eventStages.stream().map(CampaignChannelEventStageDto::getFailedToDeliveredEventId).filter(StringUtils::isNotBlank).collect(Collectors.toList()));
        eventStageMap.put("openedEvents", eventStages.stream().map(CampaignChannelEventStageDto::getOpenedEventId).filter(StringUtils::isNotBlank).collect(Collectors.toList()));
        eventStageMap.put("clickedEvents", eventStages.stream().map(CampaignChannelEventStageDto::getClickedEventId).filter(StringUtils::isNotBlank).collect(Collectors.toList()));
        eventStageMap.put("receivedEvents", eventStages.stream().map(CampaignChannelEventStageDto::getReceivedEventId).filter(StringUtils::isNotBlank).collect(Collectors.toList()));

        data.put("eventStages", eventStageMap);

        //failedToSentEventField
        Map<String, String> failedToSentEventField = eventStages.stream().filter(eventStage -> eventStage.getFailedToSendField() != null)
                .collect(Collectors.toMap(CampaignChannelEventStageDto::getFailedToSendEventId, dto -> NamingUtils.toUnderScoreCase(dto.getFailedToSendField())));
        //failedToDeliverEventField
        Map<String, String> failedToDeliverEventField = eventStages.stream().filter(eventStage -> eventStage.getFailedToDeliveredField() != null)
                .collect(Collectors.toMap(CampaignChannelEventStageDto::getFailedToDeliveredEventId, dto -> NamingUtils.toUnderScoreCase(dto.getFailedToDeliveredField())));

        Map<String, String> eventFieldMap = new HashMap<>(failedToDeliverEventField);
        eventFieldMap.putAll(failedToSentEventField);
        Map<String, GdmEntity> entityMapByNames = gsMetaClientWrapper.getEntityMapByNames(new ArrayList<>(eventFieldMap.keySet()));

        //functor Map<String, String> ==> Map<String, String>
        UnaryOperator<Map<String, String>> getEventColumnMap = inputEventFieldMap -> inputEventFieldMap.entrySet().stream()
                .filter(e -> StringUtils.isNotBlank(e.getValue())) //如果 field 为空，就不会使用，相当于没有设置
                .collect(
                        Collectors.toMap(
                                Map.Entry::getKey,
                                entry -> {
                                    GdmEntity entity = entityMapByNames.get(entry.getKey());
                                    return Optional.ofNullable(entity)
                                            .map(GdmEntity::getFieldsMap)
                                            .map(m -> m.get(entry.getValue()))
                                            .map(GdmField::getDbColumnName).orElse("");
                                }));

        Map<String, String> failedToSentEventColumn = getEventColumnMap.apply(failedToSentEventField);
        data.put("failedToSentEventField", failedToSentEventColumn);
        Map<String, String> failedToDeliverEventColumn = getEventColumnMap.apply(failedToDeliverEventField);
        data.put("failedToDeliverEventField", failedToDeliverEventColumn);
    }

    public List<Segment> getListType(GroupFactsDataDTO dto){

        Set<Long> listIds = new HashSet<>();
        if (StringUtils.isNotBlank(dto.listId)){
            listIds.add(Long.parseLong(dto.listId));
        }
        if (StringUtils.isNotBlank(dto.campaignTargetGroupId)){
            listIds.add(Long.parseLong(dto.campaignTargetGroupId));
        }
        for (GroupFactsDataDTO.EngageControlGroup engageControlGroup : dto.engageControlGroups){
            if (StringUtils.isNotBlank(engageControlGroup.engageListId)){
                listIds.add(Long.parseLong(engageControlGroup.engageListId));
            }
            if (StringUtils.isNotBlank(engageControlGroup.engageTargetListId)){
                listIds.add(Long.parseLong(engageControlGroup.engageTargetListId));
            }
        }
        List<Segment> segments = segmentMapper.selectByIdList(listIds);
        return segments;
    }
    public List<Map<String,Object>> getNotFinishCampaign(Long campaignId){
        String yesterDay = DateUtil.formatDate(DateUtil.addDays(new Date(), -1));
        List<MarketingCampaign> marketingCampaigns = DataSourceLookupHelper.withLookupKey("main", () ->marketCampaignMapper.getNotFinishCampaign(yesterDay));
        if (campaignId != null && !campaignId.equals(-1L)) {
            marketingCampaigns = marketingCampaigns.stream()
                    .filter(item -> item.getId().equals(campaignId)).collect(Collectors.toList());
        }
        Map<Long, List<Long>> campaignEngageIds = getCampaignEngageIds(marketingCampaigns);
        List<Map<String,Object>> result = marketingCampaigns.stream().map(item -> {
            Map<String, Object> itemMap = new HashMap<>();
            itemMap.put("id", item.getId());
            itemMap.put("uuid", item.getUuid());
            itemMap.put("title", item.getTitle());
            itemMap.put("engageIdList", campaignEngageIds.get(item.getId()));
            return itemMap;
        }).collect(Collectors.toList());
        return result;
    }

    public Map<Long, List<Long>> getCampaignEngageIds(List<MarketingCampaign> campaigns) {
        List<Long> campaignIds = campaigns.stream().map(MarketingCampaign::getId).collect(Collectors.toList());
        List<CampaignOutboundEngage> engageList = DataSourceLookupHelper.withLookupKey("main",
                () -> campaignOutboundEngageMapper.getEngageListByBatchCampaignIds(campaignIds));
        return CollectionUtils.isEmpty(engageList) ? Collections.emptyMap()
        : engageList.stream().collect(Collectors.groupingBy(CampaignOutboundEngage::getCampaignId, Collectors.mapping(CampaignOutboundEngage::getId, Collectors.toList())));
    }


//    public void doStartEventFactsJob(Long tenantId){
//        Long taskId = 123456L;
//        TemporaryTenantContext temporaryTenantContext = null;
//        try {
//            temporaryTenantContext = new TemporaryTenantContext(tenantId, "");
//            Map<String, Object> data = new HashMap<>();
//            data.put("taskId", taskId);
//            data.put("tenantId", tenantId);
//            data.put("startEventTime", 0L);
//            data.put("endEventTime", new Date().getTime());
//            String yesterDay = DateUtil.formatDate(DateUtil.addDays(new Date(), -1));
//            data.put("marketingCampaignInfos",marketCampaignMapper.getNotFinishCampaign(yesterDay));     //todo 数据多怎么过滤
////            DataJobParam dataJobParam = buildDatajobParma();
//            DataJobParam dataJobParam = new DataJobParam();
//            log.info("{} submit {} data:{} to processing", LOG_PREFIX,CAMPAIGN_EVENT_FACTS_JOB_NAME,JsonUtils.instance().obj2Json(data));
//            Map<String, Object> response = submitJob(CAMPAIGN_EVENT_FACTS_JOB_NAME, data, 3, dataJobParam);
//            log.info("{} submit {} resp:{}", LOG_PREFIX,CAMPAIGN_EVENT_FACTS_JOB_NAME,JsonUtils.instance().obj2Json(response));
//
//        } catch (Exception e) {
//            log.error("{} startEventFactsJob failed. errorMessage is: {}.", LOG_PREFIX, e.getMessage(), e);
//            throw new RuntimeException(e.getMessage());
//        } finally {
//            if (temporaryTenantContext != null) {
//                temporaryTenantContext.close();
//            }
//        }
//    }
}
