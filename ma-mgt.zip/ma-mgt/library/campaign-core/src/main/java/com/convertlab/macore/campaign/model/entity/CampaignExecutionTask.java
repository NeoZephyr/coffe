package com.convertlab.macore.campaign.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.convertlab.foundation.library.mybatisplus.entity.BaseTenantEntity;
import lombok.*;

import java.io.Serializable;
import java.time.Instant;
import java.util.UUID;

@Data
@EqualsAndHashCode(callSuper = false)
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName(value = "campaign_execution_task", excludeProperty = {"version", "creatorId", "creatorName", "ownerId", "deptCode", "dateCreated", "lastUpdated", "updaterId", "updaterName"})
public class CampaignExecutionTask extends BaseTenantEntity implements Serializable {

    public static final String TASK_TYPE_START_ENGAGE = "StartEngage";
    public static final String TASK_TYPE_GENERATE_FLOW = "GenerateFlow";
    public static final String TASK_TYPE_SEGMENTATION = "Segmentation";
    public static final String TASK_TYPE_GENERATE_LIST_AND_FOLDER = "CreateListAndFolder";
    public static final String TASK_TYPE_PERIODIC_SCHEDULER = "PeriodicScheduler";
    public static final String TASK_TYPE_STOP_CAMPAIGN = "StopCampaign";


    //Task status 包括 NotStarted, Preparing, Prepared, Running, Finished, Failed, Stopped
    public static final String TASK_STATUS_NOT_STARTED = "NotStarted";
    public static final String TASK_STATUS_SCHEDULED = "Scheduled";
    public static final String TASK_STATUS_RUNNING = "Running";
    public static final String TASK_STATUS_FINISHED = "Finished";
    public static final String TASK_STATUS_FAILED = "Failed";
    public static final String TASK_STATUS_STOPPED = "Stopped";

//    public CampaignExecutionTask(){
//        id = UUID.randomUUID().toString();
//    }

    public CampaignExecutionTask(String taskType) {
        super();
        this.taskType = taskType;
    }

    //任务的唯一标识, 为UUID
    @Builder.Default
    @TableId(value = "id", type = IdType.ASSIGN_ID)
    String id = UUID.randomUUID().toString();

    @TableField("campaign_id")
    Long campaignId;

    @Builder.Default
    @TableField("engage_id")
    Long engageId = -1L;

    @TableField("task_type")
    String taskType;

    @TableField("task_status")
    String taskStatus;

    @TableField("next_task_id")
    String nextTaskId;

    @Builder.Default
    @TableField("is_async_remote_call")
    Boolean isAsyncRemoteCall = false;

    @TableField("task_trigger_date")
    Instant taskTriggerDate;

    @TableField("execution_information")
    String executionInformation;

    @Builder.Default
    @TableField("retry_count")
    Integer retryCount = 0;
}
