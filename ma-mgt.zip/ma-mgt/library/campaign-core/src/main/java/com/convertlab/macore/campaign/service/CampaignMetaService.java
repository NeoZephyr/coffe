package com.convertlab.macore.campaign.service;

import com.alibaba.excel.util.StringUtils;
import com.convertlab.foundation.api.gdmdata.GdmData;
import com.convertlab.foundation.api.gdmdata.GenericGdmModel;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.exception.business.DownstreamBusinessException;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.macore.campaign.model.dto.CampaignEngageAttributeMeta;
import com.convertlab.macore.campaign.service.legacy.cms.client.CmsServiceClient;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.base.BizObjectPropBizMeta;
import com.convertlab.macore.mamgt.cdp.service.GdmBizObjectMetaService;
import com.convertlab.macore.mamgt.cdp.service.GdmMetaDataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static com.convertlab.foundation.library.constant.CommonErrors.GENERAL_ERROR;
import static com.convertlab.foundation.library.constant.CommonErrors.VALIDATION_ERROR;
import static java.util.Collections.emptyList;

@Service
@Slf4j
public class CampaignMetaService {

    public static final String CAMPAIGN_ENGAGE_ATTRIBUTE = "campaign_engage_attribute";

    CmsServiceClient cmsServiceClient;
    GdmBizObjectMetaService<CampaignEngageAttributeMeta.EngageExtPropMeta, CampaignEngageAttributeMeta> gdmBizObjectMetaService;

    GdmMetaDataService gdmMetaDataService;
    GsMetaClient gsMetaClient;

    public CampaignMetaService( CmsServiceClient cmsServiceClient, GdmBizObjectMetaService gdmBizObjectMetaService,
                                GdmMetaDataService gdmMetaDataService, GsMetaClient gsMetaClient) {
        this.cmsServiceClient = cmsServiceClient;
        this.gdmBizObjectMetaService = gdmBizObjectMetaService;
        this.gdmMetaDataService = gdmMetaDataService;
        this.gsMetaClient = gsMetaClient;
    }

    public CampaignEngageAttributeMeta getCampaignEngageAttributeMeta() {
        return gdmBizObjectMetaService.getGdmObjectMeta(CAMPAIGN_ENGAGE_ATTRIBUTE, CampaignEngageAttributeMeta.class);
    }

    public void checkExists(List<String> newPropNameList){
        CampaignEngageAttributeMeta attributeMeta = getCampaignEngageAttributeMeta();
        if (attributeMeta != null){
            Set<String> propNames = attributeMeta.getProps().stream().map(BizObjectPropBizMeta::getName).collect(Collectors.toSet());
            //从 newPropNameList 中找出所有所有已经存在于 propNames 中的元素
            List<String> propNamesExists = newPropNameList.stream().filter(propNames::contains).collect(Collectors.toList());
            if (!propNamesExists.isEmpty()) {
                // 属性已存在，返回错误信息
                throw new BusinessException(VALIDATION_ERROR, "MSG_104_000000", "Existed property names: " + propNamesExists, propNamesExists.toArray(new String[0]));
            }
        }
    }

    public void checkExists(String newPropName){
        CampaignEngageAttributeMeta attributeMeta = getCampaignEngageAttributeMeta();
        if (attributeMeta != null){
            Set<String> propNames = attributeMeta.getProps().stream().map(BizObjectPropBizMeta::getName).collect(Collectors.toSet());
            if (propNames.contains(newPropName)) {
                // 属性已存在，返回错误信息
                throw new BusinessException(VALIDATION_ERROR, "MSG_104_000000", "Existed property names: " + newPropName, new String[]{newPropName});
            }
        }
    }

    public void checkNotExists(String propName){
        CampaignEngageAttributeMeta attributeMeta = getCampaignEngageAttributeMeta();
        if (attributeMeta == null){
            throw new BusinessException(VALIDATION_ERROR, "MSG_104_000000", "Not existed property name: " + propName, new String[]{propName});
        } else {
            Set<String> propNames = attributeMeta.getProps().stream().map(BizObjectPropBizMeta::getName).collect(Collectors.toSet());
            if (!propNames.contains(propName)) {
                throw new BusinessException(VALIDATION_ERROR, "MSG_104_000000", "Not existed property name: " + propName, new String[]{propName});
            }
        }
    }

    public List<CampaignEngageAttributeMeta.EngageExtPropMeta> getEngageExtPropMetaList() {
        CampaignEngageAttributeMeta objectMeta = gdmBizObjectMetaService.getGdmObjectMeta(CAMPAIGN_ENGAGE_ATTRIBUTE, CampaignEngageAttributeMeta.class);
        return (objectMeta == null) ? emptyList() : objectMeta.getProps();
    }

    //save
    public void appendCampaignEngageAttributeMetaList(List<CampaignEngageAttributeMeta.EngageExtPropMeta> propMetaRequests) {
        try {
            CampaignEngageAttributeMeta existedAttributeMeta = gdmBizObjectMetaService.getGdmObjectMeta(CAMPAIGN_ENGAGE_ATTRIBUTE, CampaignEngageAttributeMeta.class);
            Set<String> existedPropNames = existedAttributeMeta == null ? Collections.emptySet() :
                    existedAttributeMeta.getProps().stream().map(BizObjectPropBizMeta::getName).collect(Collectors.toSet());
            List<String> existedPropNamesInRequest = propMetaRequests.stream()
                    .map(BizObjectPropBizMeta::getName)
                    .filter(existedPropNames::contains).collect(Collectors.toList());
            //如果输入的属性中有存在，则抛出错误
            if (!existedPropNamesInRequest.isEmpty()) {
                throw new BusinessException(VALIDATION_ERROR, "MSG_104_000000", "Existed property names: " + existedPropNamesInRequest, existedPropNamesInRequest.toArray(new String[0]));
            }

            //如果输入的属性都是没有存在的，则直接添加
            if (existedAttributeMeta == null) {
                CampaignEngageAttributeMeta newAttributeMeta = new CampaignEngageAttributeMeta();
                gdmBizObjectMetaService.addNewPropListToGdmObjectMeta(CAMPAIGN_ENGAGE_ATTRIBUTE, newAttributeMeta, propMetaRequests);
            } else {
                existedAttributeMeta.setProps(propMetaRequests);
                gdmBizObjectMetaService.updateGdmObjectMeta(CAMPAIGN_ENGAGE_ATTRIBUTE, existedAttributeMeta, propMetaRequests);
            }
        } catch( DownstreamBusinessException e) {
            log.error("appendCampaignEngageAttributeMetaList error", e);
            throw e;
        } catch (Exception e) {
            log.error("appendCampaignEngageAttributeMetaList error", e);
            throw new BusinessException(GENERAL_ERROR, "MSG_104_000000", e.getMessage(), new String[]{});
        }
    }

    public CampaignEngageAttributeMeta updateEngagePropMeta(CampaignEngageAttributeMeta campaignEngageAttributeMeta) {
        return gdmBizObjectMetaService.updateGdmObjectMetaWithUpdatedProp(CAMPAIGN_ENGAGE_ATTRIBUTE, campaignEngageAttributeMeta);
    }

    public CampaignEngageAttributeMeta deleteEngagePropMeta(CampaignEngageAttributeMeta campaignEngageAttributeMeta, String propName) {
        return gdmBizObjectMetaService.updateGdmObjectMetaWithDeletedProp(CAMPAIGN_ENGAGE_ATTRIBUTE, campaignEngageAttributeMeta, propName);
    }

    public void deleteCampaignEngageAttributeMeta() {
        gdmBizObjectMetaService.deleteGdmObjectMeta(CAMPAIGN_ENGAGE_ATTRIBUTE);
    }

    public void addNewEngagePropMeta(CampaignEngageAttributeMeta.EngageExtPropMeta dto) {
        checkExists(dto.getName());
        try {
            CampaignEngageAttributeMeta currAttrMeta = getCampaignEngageAttributeMeta();
            if (currAttrMeta == null) {
                CampaignEngageAttributeMeta newAttributeMeta = new CampaignEngageAttributeMeta();
                gdmBizObjectMetaService.createNewGdmObjectMetaWithProp(CAMPAIGN_ENGAGE_ATTRIBUTE, newAttributeMeta, dto);
            } else {
                gdmBizObjectMetaService.addNewPropToCurrBizObject(CAMPAIGN_ENGAGE_ATTRIBUTE, currAttrMeta, dto);
            }
        } catch (DownstreamBusinessException e) {
            log.error("addNewEngagePropMeta error with DownstreamBusinessException:", e);
            throw e;
        } catch (Exception e) {
            log.error("addNewEngagePropMeta error", e);
            throw new BusinessException(GENERAL_ERROR, "MSG_104_000000", e.getMessage(), new String[]{});
        }
    }

    /**
     * engageAttributeMap: `<engageId, <fieldName, value> >`
     */
    public void saveOrUpdateEngageAttribute(Long campaignId, Map<Long, Map<String, String>> engageAttributeMap) {
        Set<String> fieldNames = gdmBizObjectMetaService.getAllocatedFieldNames(CAMPAIGN_ENGAGE_ATTRIBUTE, CampaignEngageAttributeMeta.class);

        List<GdmData> gdmDataList = getCampaignEngageAttributeData(campaignId, fieldNames);

        if (!gdmDataList.isEmpty()) {

            GdmEntity gdmEntity = gsMetaClient.getEntity(CAMPAIGN_ENGAGE_ATTRIBUTE);
            Assert.notNull(gdmEntity, String.format("GdmEntity of %s should not be null", CAMPAIGN_ENGAGE_ATTRIBUTE));

            //先删除，后添加
            List<Object> ids = gdmDataList.stream().filter(m -> m.containsKey("id")).map(m -> m.get("id")).collect(Collectors.toList());
            log.info("delete gdmDataList ids: {}", ids);
            gdmMetaDataService.deleteByIds(gdmEntity, ids);
        }

        engageAttributeMap.forEach((engageId, attrMap) -> {
            GdmEntity gdmEntity = gsMetaClient.getEntity(CAMPAIGN_ENGAGE_ATTRIBUTE);
            Assert.notNull(gdmEntity, String.format("GdmEntity of %s should not be null", CAMPAIGN_ENGAGE_ATTRIBUTE));
            Map<String, Object> dataMap = new HashMap<>(attrMap);
            dataMap.put("campaign_id", campaignId);
            dataMap.put("engage_id", engageId);
            log.info("saveOrUpdateEngageAttribute add gdmData: {}", dataMap);
            GenericGdmModel gdmDataModel = new GenericGdmModel(gdmEntity);
            gdmDataModel.setPk(null);
            gdmDataModel.props.putAll(dataMap);
            gdmMetaDataService.insert(gdmDataModel);
        });
    }

    private List<GdmData> getCampaignEngageAttributeData(Long campaignId, Set<String> fieldNames) {

        GdmEntity gdmEntity = gsMetaClient.getEntity(CAMPAIGN_ENGAGE_ATTRIBUTE);
        Assert.notNull(gdmEntity, String.format("GdmEntity of %s should not be null", CAMPAIGN_ENGAGE_ATTRIBUTE));

        Map<String, Object> campaignParam = new HashMap<>();
        campaignParam.put("campaign_id", campaignId);
        List<GenericGdmModel> gdmModels = gdmMetaDataService.selectByParams(gdmEntity, new ArrayList<>(fieldNames), campaignParam, 0, 30);
        return gdmModels.stream()
                .map(GenericGdmModel::toGdmData)
                .collect(Collectors.toList());
    }

    public Map<Long, Map<String, String>> getEngageAttributeData(Long campaignId) {
        Set<String> fieldNames = gdmBizObjectMetaService.getAllocatedFieldNames(CAMPAIGN_ENGAGE_ATTRIBUTE, CampaignEngageAttributeMeta.class);
        List<GdmData> gdmDataList = getCampaignEngageAttributeData(campaignId, fieldNames);

        return gdmDataList.stream()
                .collect(Collectors.toMap(m -> Long.valueOf(m.get("engage_id").toString()),
                        m -> m.entrySet().stream()
                                .filter(e -> !e.getKey().equals("id"))
                                .collect(Collectors.toMap(Map.Entry::getKey, e -> e.getValue().toString()))));
    }

    public Map<Long, Map<String, String>> getEngageAttributeData(List<Long> campaignIds) {
        Set<String> fieldNames = gdmBizObjectMetaService.getAllocatedFieldNames(CAMPAIGN_ENGAGE_ATTRIBUTE, CampaignEngageAttributeMeta.class);

        List<GdmData> gdmDataList = new ArrayList<>();
        //TODO 需要改成批量查询方式
        for (Long campaignId: campaignIds) {
            List<GdmData> campaignEngageAttributeData = getCampaignEngageAttributeData(campaignId, fieldNames);
            gdmDataList.addAll(campaignEngageAttributeData);
        }

        return gdmDataList.stream()
                .collect(Collectors.toMap(m -> Long.valueOf(m.get("engage_id").toString()),
                        m -> m.entrySet().stream()
                                .filter(e -> !e.getKey().equals("id"))
                                .collect(Collectors.toMap(Map.Entry::getKey, e -> e.getValue().toString()))));
    }

    public Map<Long, Map<String, Object>> getCampaignInfoMap(Map<Long, String> campaignIdCodeMap) {
        Map<Long, Map<String, Object>> campaignInfoMap = new HashMap<>();
        for (Map.Entry<Long, String> idCodeMap : campaignIdCodeMap.entrySet()) {
            Long campaignId = idCodeMap.getKey();
            String campaignCode = idCodeMap.getValue();
            Map<String, Object> campaignWithMeta = cmsServiceClient.getCampaignWithMetaByCode(campaignCode);

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> campaignMeta = (List<Map<String, Object>>) campaignWithMeta.get("_meta");
            Assert.notEmpty(campaignMeta, String.format("campaignMeta of %s should not be empty, the response: %s", campaignCode, campaignWithMeta));

            Map<String, String> fieldAttrMap = campaignMeta.stream().filter(m -> StringUtils.isNotBlank((String) m.get("attr")) && StringUtils.isNotBlank((String) m.get("name")))
                    .collect(Collectors.toMap(m -> (String) m.get("name"), m -> (String) m.get("attr")));


            Map<String, Object> campaignInfo = new HashMap<>();
            campaignInfo.put("campaignCode", campaignCode);
            campaignInfo.put("campaignName", campaignWithMeta.get("title"));
            campaignInfo.put("executionMode", campaignWithMeta.get("executionMode"));

            for (Map.Entry<String, String> fieldAttrMapEntry : fieldAttrMap.entrySet()) {
                String fieldName = fieldAttrMapEntry.getKey();
                String attrName = fieldAttrMapEntry.getValue();
                if (campaignWithMeta.containsKey(attrName))  {
                    campaignInfo.put(fieldName, campaignWithMeta.get(attrName));
                }
            }
            campaignInfoMap.put(campaignId, campaignInfo);

        }
        return campaignInfoMap;
    }
}
