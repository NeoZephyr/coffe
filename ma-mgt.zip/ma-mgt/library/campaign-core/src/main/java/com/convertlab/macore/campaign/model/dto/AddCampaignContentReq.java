package com.convertlab.macore.campaign.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AddCampaignContentReq {

    long  campaignId;
    long  contentId;
    String contentType;
    String eventCampaignUuid;
    long groupId;

}
