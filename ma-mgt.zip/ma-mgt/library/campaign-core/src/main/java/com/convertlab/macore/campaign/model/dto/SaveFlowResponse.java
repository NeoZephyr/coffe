package com.convertlab.macore.campaign.model.dto;

import lombok.Data;

@Data
public class SaveFlowResponse {

    long id;
    int version;
    String status;
    String name;
}
