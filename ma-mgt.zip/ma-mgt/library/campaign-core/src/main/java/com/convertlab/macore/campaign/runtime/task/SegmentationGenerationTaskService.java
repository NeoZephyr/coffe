package com.convertlab.macore.campaign.runtime.task;

import cn.hutool.core.collection.CollectionUtil;
import com.convertlab.macore.campaign.common.utils.AudienceStrategyConstants;
import com.convertlab.macore.campaign.common.utils.NameUtils;
import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.dto.ListMemberBatchTaskDef;
import com.convertlab.macore.campaign.model.dto.ListMemberBatchTaskDefSplitNode;
import com.convertlab.macore.campaign.model.dto.ListMemberBatchTaskRequest;
import com.convertlab.macore.campaign.model.dto.OnSegmentFinishDTO;
import com.convertlab.macore.campaign.model.entity.CampaignAudienceStrategy;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTaskData;
import com.convertlab.macore.campaign.model.entity.CampaignListInfo;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.service.CampaignFactsDataSyncService;
import com.convertlab.macore.campaign.service.legacy.cms.model.ListMemberBatchTask;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;

@Slf4j
@Service
public class SegmentationGenerationTaskService extends AbstractTaskRuntimeService {

    @Autowired
    protected CampaignListInfoService campaignListInfoService;

    @Autowired
    protected CampaignFactsDataSyncService campaignFactsDataSyncService;

    @Autowired
    protected MaCoreService maCoreService;


    @Override
    public TaskResult onStart(CampaignExecutionTask task) {
        //1.读取营销活动数据.
        CampaignFullDataDTO campaignFullData = campaignService.getCampaignFullData(task.getCampaignId());

        //2.生成request.
        ListMemberBatchTaskRequest request = this.genRequest(campaignFullData, task);

        //3.如果判断request只包含main和target, 且target等于main
        if(notRequireRemoteRequest(request)){
            TaskResult result = new TaskResult(true);

            if (result != null && result.isFinish) {
                CampaignAudienceStrategy campaignAudienceStrategy = campaignService.getCampaignAudienceStrategy(task.getCampaignId());
                String audienceStrategy = (campaignAudienceStrategy != null) ? campaignAudienceStrategy.getSegmentationType() : "";
                log.info("Segmentation is ready, starting campaign group facts job for Campaign ID: {}, EngageId: {}, AudienceStrategy: {}"
                        , task.getCampaignId(), task.getEngageId(), audienceStrategy);
                campaignFactsDataSyncService.importGroupFactsData(task.getCampaignId(), task.getEngageId(), audienceStrategy);
            }
            return result;
        }else{
            Map<String, Object> response = maCoreService.triggerListMemberBatchTask(request, campaignFullData.getCampaign());

            campaignTaskService.saveTaskData(task.getCampaignId(), task.getEngageId(), task.getId(), "listMemberBatchTaskId", response.get("id").toString());

            return new TaskResult(false);
        }
    }

    boolean notRequireRemoteRequest(ListMemberBatchTaskRequest request){
        ListMemberBatchTaskDef taskDef = request.getTaskDef();
        if(CollectionUtil.isEmpty(taskDef.getSplitList()) && StringUtils.isEmpty(taskDef.getExcludedListName())
                && StringUtils.isEmpty(taskDef.getControlGroupListName()) && StringUtils.isEmpty(taskDef.getFilteredListName())
                && !StringUtils.isEmpty(taskDef.getTargetGroupListName())
        ){
            return true;
        }
        else{
            return false;
        }
    }


    private ListMemberBatchTaskRequest genRequest(CampaignFullDataDTO campaignFullDataDTO, CampaignExecutionTask task) {

        ListMemberBatchTaskRequest request = null;

        //根据Campaign的audienceStrategy，创建不同的segmentation request。
        switch (campaignFullDataDTO.getAudienceStrategy().getSegmentationType()) {
            case AudienceStrategyConstants.MANUAL_PERCENTAGE_SEGMENTATION:
            case AudienceStrategyConstants.MANUAL_QUANTITY_SEGMENTATION:
            case AudienceStrategyConstants.PSYCHOGRAPHIC_SEGMENTATION:
                request = createSegmentationRequest(campaignFullDataDTO, campaignListInfoService.getCampaignListInfo(task.getCampaignId()));
                break;
            case AudienceStrategyConstants.MANUAL_SPECIFIED_SEGMENTATION:
                request = createSegmentationRequestForManualSpecified(campaignFullDataDTO, campaignListInfoService.getCampaignListInfo(task.getCampaignId(), task.getEngageId()), task.getEngageId());
                break;
            case AudienceStrategyConstants.MULTIPLE_WAVED_SEGMENTATION:
                if (isTheFirstEngage(campaignFullDataDTO.getOutboundEngageList(), task.getEngageId())) {
                    //如果是第一个wave
                    request = createSegmentationRequestForMultipleWaveFirst(campaignFullDataDTO, campaignListInfoService.getCampaignListInfo(task.getCampaignId()), task.getEngageId());
                } else {
                    //如果是第二个wave
                    request = createSegmentationRequestForMultipleWaveNext(campaignFullDataDTO, campaignListInfoService.getCampaignListInfo(task.getCampaignId()), task.getEngageId());
                }
                break;
            default:
                throw new RuntimeException("不支持的segmentation type:" + campaignFullDataDTO.getAudienceStrategy().getSegmentationType());
        }

        return request;

    }

    public boolean isTheFirstEngage(List<CampaignOutboundEngage> outboundEngageList, Long engageId) {
        return CollectionUtils.isNotEmpty(outboundEngageList)
                && outboundEngageList.stream()
                .min(Comparator.comparing(CampaignOutboundEngage::getId))
                .map(CampaignOutboundEngage::getId)
                .map(theMinEngageId -> theMinEngageId.equals(engageId)).orElse(false);
    }

    @Override
    public void onFinish(CampaignExecutionTask task) {
    }


    public ListMemberBatchTaskRequest createSegmentationRequest(CampaignFullDataDTO campaignFullDataDTO, List<CampaignListInfo> campaignListInfos) {
        ListMemberBatchTaskRequest request = new ListMemberBatchTaskRequest();
        request.setListId(campaignFullDataDTO.getMainTargetAudience().get(0).getListId().toString());
        ListMemberBatchTaskDef taskDef = new ListMemberBatchTaskDef();
        request.setTaskDef(taskDef);
        taskDef.setCampaignCode(campaignFullDataDTO.getCampaign().getUuid());
        taskDef.setSplitStrategy(campaignFullDataDTO.getAudienceStrategy().getSegmentationType());
        List<ListMemberBatchTaskDefSplitNode> nodes = new ArrayList<>();
        taskDef.setSplitList(nodes);

        // 设置 Campaign 级别的信息
        setCampaignLevelInfo(campaignFullDataDTO, campaignListInfos, taskDef);

        // 处理 OutboundEngage
        processOutboundEngages(campaignFullDataDTO, campaignListInfos, nodes);

        return request;
    }

    private void setCampaignLevelInfo(CampaignFullDataDTO campaignFullDataDTO, List<CampaignListInfo> campaignListInfos, ListMemberBatchTaskDef taskDef) {
        campaignListInfoService.getCampaignLevelInfo(campaignFullDataDTO.getCampaign().getId(), campaignListInfos).forEach(campaignListInfo -> {
            switch (campaignListInfo.getListType()) {
                case NameUtils.EXCLUDED_GROUP:
                    taskDef.setExcludedListName(campaignListInfo.getListName());
                    break;
                case NameUtils.FILTERED_GROUP:
                    taskDef.setFilteredListName(campaignListInfo.getListName());
                    setFilteredContent(campaignFullDataDTO, taskDef);
                    break;
                case NameUtils.CONTROL_GROUP:
                    taskDef.setControlGroupListName(campaignListInfo.getListName());
                    taskDef.setControlGroupPercentage(Double.parseDouble(campaignFullDataDTO.getAudienceStrategy().getControlGroupPercentage()));
                    break;
                case NameUtils.TARGET_GROUP:
                    if(StringUtils.isEmpty(campaignListInfo.getMapToListType())){
                        taskDef.setTargetGroupListName(campaignListInfo.getListName());
                    }
                    break;
            }
        });
    }

    private void setFilteredContent(CampaignFullDataDTO campaignFullDataDTO, ListMemberBatchTaskDef taskDef) {
        if (campaignFullDataDTO.getCampaignFilter() != null && !StringUtils.isEmpty(campaignFullDataDTO.getCampaignFilter().getFilterContent())) {
            try {
                Map<String, Object> v4Filter = parseMap(campaignFullDataDTO.getCampaignFilter().getFilterContent());
                taskDef.setFilter(v4Filter);
            } catch (Exception e) {
                throw new RuntimeException("Error parsing campaign filter", e);
            }
        }
    }

    private void processOutboundEngages(CampaignFullDataDTO campaignFullDataDTO, List<CampaignListInfo> campaignListInfos, List<ListMemberBatchTaskDefSplitNode> nodes) {
        for (CampaignOutboundEngage outboundEngage : campaignFullDataDTO.getOutboundEngageList()) {
            ListMemberBatchTaskDefSplitNode node = new ListMemberBatchTaskDefSplitNode();
            nodes.add(node);
            processNodeData(outboundEngage, node);
            linkEngageListInfos(outboundEngage, campaignListInfos, node);
        }
    }

    private void processNodeData(CampaignOutboundEngage outboundEngage, ListMemberBatchTaskDefSplitNode node) {
        try {
            JsonNode rootNode = objectMapper.readTree(outboundEngage.getAudienceData());
            setNodeDetails(node, rootNode);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error processing node data", e);
        }
    }

    private void setNodeDetails(ListMemberBatchTaskDefSplitNode node, JsonNode rootNode) {
        Optional.ofNullable(rootNode.get("percentage")).ifPresent(n -> node.setPercentage(n.doubleValue()));
        Optional.ofNullable(rootNode.get("quantity")).ifPresent(n -> node.setQuantity(n.intValue()));
        Optional.ofNullable(rootNode.get("filter")).map(JsonNode::toString).ifPresent(text -> node.setCondition(parseMap(text)));
        Optional.ofNullable(rootNode.get("remainingSegmentation")).ifPresent(n -> node.setRemaining(n.booleanValue()));
    }


    private void linkEngageListInfos(CampaignOutboundEngage outboundEngage, List<CampaignListInfo> campaignListInfos, ListMemberBatchTaskDefSplitNode node) {
        List<CampaignListInfo> engageListInfos = campaignListInfoService.getEngageLevelListInfo(outboundEngage.getCampaignId(), outboundEngage.getId(), campaignListInfos);
        for (CampaignListInfo engageListInfo : engageListInfos) {
            switch (engageListInfo.getListType()) {
                case NameUtils.CONTROL_GROUP:
                    node.setControlGroupListName(engageListInfo.getListName());
                    setControlGroupPercentage(outboundEngage, node);
                    break;
                case NameUtils.TARGET_GROUP:
                    setTargetGroupListName(node, engageListInfo, engageListInfos);
                    break;
                default:
                    break;
            }
        }
    }

    private void setControlGroupPercentage(CampaignOutboundEngage outboundEngage, ListMemberBatchTaskDefSplitNode node) {
        try {
            JsonNode rootNode = objectMapper.readTree(outboundEngage.getControlGroupData());
            JsonNode percentageNode = rootNode.get("percentage");
            if (percentageNode != null && !percentageNode.isNull()) {
                node.setControlGroupPercentage(percentageNode.doubleValue());
            }
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error parsing control group data", e);
        }
    }

    private void setTargetGroupListName(ListMemberBatchTaskDefSplitNode node, CampaignListInfo engageListInfo, List<CampaignListInfo> engageListInfos) {
        if (StringUtils.isEmpty(engageListInfo.getMapToListType())) {
            node.setTargetGroupListName(engageListInfo.getListName());
        } else {
            // 根据 mapToListType 找到相应的 engageListInfo
            engageListInfos.stream()
                    .filter(info -> info.getListType().equals(engageListInfo.getMapToListType()))
                    .findFirst()
                    .ifPresent(info -> node.setTargetGroupListName(info.getListName()));
        }
    }


    public ListMemberBatchTaskRequest createSegmentationRequestForMultipleWaveFirst(CampaignFullDataDTO campaignFullDataDTO, List<CampaignListInfo> campaignListInfos, long engageId) {
        ListMemberBatchTaskRequest request = new ListMemberBatchTaskRequest();
        request.setListId(campaignFullDataDTO.getMainTargetAudience().get(0).getListId().toString());

        ListMemberBatchTaskDef taskDef = initializeTaskDefinition(campaignFullDataDTO);
        request.setTaskDef(taskDef);

        setCampaignLevelInfo(campaignFullDataDTO, campaignListInfos, taskDef);

        CampaignOutboundEngage outboundEngage = findOutboundEngage(campaignFullDataDTO, engageId);
        ListMemberBatchTaskDefSplitNode node = processOutboundEngage(outboundEngage, campaignListInfos, taskDef.getSplitList());

        try {
            JsonNode rootNode = objectMapper.readTree(outboundEngage.getAudienceData());
            JsonNode conditionNode = rootNode.get("conversionEvent");

            if (conditionNode != null && !conditionNode.isNull()) {
                Map<String, Object> v4Filter = parseMap(conditionNode.toString());
                node.setCondition(v4Filter);
            }

        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        node.setNotInCondition(true);


        return request;
    }

    private ListMemberBatchTaskDef initializeTaskDefinition(CampaignFullDataDTO campaignFullDataDTO) {
        ListMemberBatchTaskDef taskDef = new ListMemberBatchTaskDef();
        taskDef.setCampaignCode(campaignFullDataDTO.getCampaign().getUuid());
        taskDef.setSplitStrategy(campaignFullDataDTO.getAudienceStrategy().getSegmentationType());
        taskDef.setSplitList(new ArrayList<>());
        return taskDef;
    }

    private CampaignOutboundEngage findOutboundEngage(CampaignFullDataDTO campaignFullDataDTO, long engageId) {
        return campaignFullDataDTO.getOutboundEngageList().stream()
                .filter(engage -> engage.getId().equals(engageId))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Cannot find outboundEngage by engageId: " + engageId));
    }

    private ListMemberBatchTaskDefSplitNode processOutboundEngage(CampaignOutboundEngage outboundEngage, List<CampaignListInfo> campaignListInfos, List<ListMemberBatchTaskDefSplitNode> nodes) {
        ListMemberBatchTaskDefSplitNode node = new ListMemberBatchTaskDefSplitNode();
        nodes.add(node);
        processNodeData(outboundEngage, node);
        linkEngageListInfos(outboundEngage, campaignListInfos, node);
        return node;
    }


    @SuppressWarnings("unchecked")
    private Map<String, Object> parseMap(String content) {
        Map<String, Object> result = null;
        try {
            result = objectMapper.readValue(content, Map.class);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        Map<String, Object> v4Filter = (Map<String, Object>) result.get("v4");
        return v4Filter;
    }



    public ListMemberBatchTaskRequest createSegmentationRequestForMultipleWaveNext(CampaignFullDataDTO campaignFullDataDTO, List<CampaignListInfo> campaignListInfos, long engageId) {
        ListMemberBatchTaskRequest request = new ListMemberBatchTaskRequest();
        //使用上一次生成的campaign级别targetGroup的listId
        //轮询campaignListInfos, 找到targetGroup的listId
        AtomicReference<String> targetGroupListId = new AtomicReference<>();
        for (CampaignListInfo campaignListInfo : campaignListInfos) {
            if (campaignListInfo.getListType().equals(NameUtils.TARGET_GROUP) && campaignListInfo.getEngageId() < 1) {
                if (campaignListInfo.getMapToListType() != null) {
                    //根据maptolisttype找到engageListInfo
                    campaignListInfos.forEach(engageListInfo -> {
                        if (engageListInfo.getListType().equals(campaignListInfo.getMapToListType()) && engageListInfo.getEngageId() < 1) {
                            targetGroupListId.set(engageListInfo.getListId().toString());
                            return;
                        }
                    });
                } else {
                    targetGroupListId.set(campaignListInfo.getListId().toString());
                }
                break;
            }
        }

        if (targetGroupListId.get() == null) {
            throw new RuntimeException("can not find targetGroupListId");
        }

        request.setListId(targetGroupListId.get());
        ListMemberBatchTaskDef taskDef = new ListMemberBatchTaskDef();
        request.setTaskDef(taskDef);
        taskDef.setCampaignCode(campaignFullDataDTO.getCampaign().getUuid());
        List<ListMemberBatchTaskDefSplitNode> nodes = new ArrayList<>();
        taskDef.setSplitStrategy(campaignFullDataDTO.getAudienceStrategy().getSegmentationType());
        taskDef.setSplitList(nodes);

        //根据当前engageId找到OutboundEngage
        Optional<CampaignOutboundEngage> outboundEngageOpt = campaignFullDataDTO.getOutboundEngageList().stream()
                .filter(engage -> engage.getId().equals(engageId))
                .findFirst();

        CampaignOutboundEngage outboundEngage = outboundEngageOpt.orElse(null);

        if (outboundEngage == null) {
            throw new RuntimeException("can not find outboundEngage by engageId:" + engageId);
        }

        ListMemberBatchTaskDefSplitNode node = new ListMemberBatchTaskDefSplitNode();
        nodes.add(node);
        try {
            JsonNode rootNode = objectMapper.readTree(outboundEngage.getAudienceData());
            JsonNode conditionNode = rootNode.get("conversionEvent");

            if (conditionNode != null && !conditionNode.isNull()) {
                Map<String, Object> v4Filter = parseMap(conditionNode.toString());
                node.setCondition(v4Filter);
            }

        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        node.setNotInCondition(true);

        List<CampaignListInfo> engageListInfos = campaignListInfoService.getEngageLevelListInfo(campaignFullDataDTO.getCampaign().getId(), outboundEngage.getId(), campaignListInfos);
        for (CampaignListInfo engageListInfo : engageListInfos) {
            switch (engageListInfo.getListType()) {
                case NameUtils.CONTROL_GROUP:
                    node.setControlGroupListName(engageListInfo.getListName());
                    try {
                        JsonNode rootNode = objectMapper.readTree(outboundEngage.getControlGroupData());
                        JsonNode percentageNode = rootNode.get("percentage");
                        // 检查获取的节点是否为 null，然后安全地访问值
                        if (percentageNode != null && !percentageNode.isNull()) {
                            node.setControlGroupPercentage(percentageNode.doubleValue());
                        }

                    } catch (JsonProcessingException e) {
                        throw new RuntimeException(e);
                    }

                    break;
                case NameUtils.TARGET_GROUP:
                    if (StringUtils.isEmpty(engageListInfo.getMapToListType())) {
                        node.setTargetGroupListName(engageListInfo.getListName());
                    } else {
                        //根据maptolisttype找到engageListInfo
                        engageListInfos.forEach(engageListInfo1 -> {
                            if (engageListInfo1.getListType().equals(engageListInfo.getMapToListType())) {
                                node.setTargetGroupListName(engageListInfo1.getListName());
                            }
                        });
                    }
                    break;
                default:
                    break;
            }
        }

        return request;
    }

    public ListMemberBatchTaskRequest createSegmentationRequestForManualSpecified(CampaignFullDataDTO campaignFullDataDTO, List<CampaignListInfo> campaignListInfos, long engageId) {
        ListMemberBatchTaskRequest request = new ListMemberBatchTaskRequest();

        Optional<CampaignOutboundEngage> outboundEngageOpt = campaignFullDataDTO.getOutboundEngageList().stream()
                .filter(engage -> engage.getId().equals(engageId))
                .findFirst();

        CampaignOutboundEngage outboundEngage = outboundEngageOpt.orElse(null);

        if (outboundEngage == null) {
            throw new RuntimeException("can not find outboundEngage by engageId:" + engageId);
        }

        try {
            JsonNode rootNode = objectMapper.readTree(outboundEngage.getAudienceData());
            JsonNode listIdNode = rootNode.get("listId");
            request.setListId(listIdNode.asText());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        ListMemberBatchTaskDef taskDef = new ListMemberBatchTaskDef();
        request.setTaskDef(taskDef);
        taskDef.setCampaignCode(campaignFullDataDTO.getCampaign().getUuid());
        taskDef.setSplitStrategy(campaignFullDataDTO.getAudienceStrategy().getSegmentationType());

        //设定Campaign级别参数。
        campaignListInfos.forEach(campaignListInfo -> {
            if(engageId == campaignListInfo.getEngageId()){
                switch (campaignListInfo.getListType()) {
                    case NameUtils.EXCLUDED_GROUP:
                        taskDef.setExcludedListName(campaignListInfo.getListName());
                        break;
                    case NameUtils.FILTERED_GROUP:
                        taskDef.setFilteredListName(campaignListInfo.getListName());
                        if (campaignFullDataDTO.getCampaignFilter() != null && !StringUtils.isEmpty(campaignFullDataDTO.getCampaignFilter().getFilterContent())) {
                            try {
                                // 将JSON字符串转换为Map
                                Map<String, Object> v4Filter = parseMap(campaignFullDataDTO.getCampaignFilter().getFilterContent());
                                //设置taskDef
                                taskDef.setFilter(v4Filter);
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        }
                        break;
                    case NameUtils.CONTROL_GROUP:
                        taskDef.setControlGroupListName(campaignListInfo.getListName());
                        try {
                            JsonNode rootNode = objectMapper.readTree(outboundEngage.getControlGroupData());
                            JsonNode percentageNode = rootNode.get("percentage");
                            // 检查获取的节点是否为 null，然后安全地访问值
                            if (percentageNode != null && !percentageNode.isNull()) {
                                taskDef.setControlGroupPercentage(percentageNode.doubleValue());
                            }

                        } catch (JsonProcessingException e) {
                            throw new RuntimeException(e);
                        }
                        break;

                    case NameUtils.TARGET_GROUP:
                        if (StringUtils.isEmpty(campaignListInfo.getMapToListType())) {
                            taskDef.setTargetGroupListName(campaignListInfo.getListName());
                            break;
                        } else {
                            campaignListInfos.forEach(engageListInfo1 -> {
                                if (engageId == engageListInfo1.getEngageId() && engageListInfo1.getListType().equals(campaignListInfo.getMapToListType())) {
                                    taskDef.setTargetGroupListName(engageListInfo1.getListName());
                                }
                            });
                        }
                        break;
                }
            }
        });

        return request;
    }


    @Override
    public TaskResult checkProgress(CampaignExecutionTask task) {
        CampaignExecutionTaskData campaignExecutionTaskData = campaignTaskService.getTaskData(
                task.getCampaignId(), task.getEngageId(), task.getId(), "listMemberBatchTaskId");

        if (campaignExecutionTaskData == null) {
            // Log and handle the absence of task data appropriately.
            log.error("No task data available for Campaign ID: {}", task.getCampaignId());
            return null;  // Or consider throwing an exception.
        }

        String dataValue = campaignExecutionTaskData.getDataValue();
        Optional<ListMemberBatchTask> listMemberBatchTask = maCoreService.selectByIdList(Collections.singletonList(dataValue))
                .stream()
                .filter(batchTask -> batchTask.getId().toString().equals(dataValue))
                .findFirst();

        if (!listMemberBatchTask.isPresent()) {
            log.error("No matching ListMemberBatchTask found for ID: {}", dataValue);
            return null;  // Or handle accordingly.
        }

        OnSegmentFinishDTO dto = new OnSegmentFinishDTO();
        dto.setCampaignId(campaignExecutionTaskData.getCampaignId());
        dto.setEngageId(campaignExecutionTaskData.getEngageId());
        dto.setStatus(listMemberBatchTask.get().getStatus());
        dto.setListMemberBatchTaskId(listMemberBatchTask.get().getId());

        TaskResult result = onSegmentationGenerationFinish(task, Collections.singletonList(dto));
        if (result != null && result.isFinish) {
            Long taskCampaignId = task.getCampaignId();
            Long taskEngageId = task.getEngageId();
            //对于多波段的campaign，如果是第一个wave，需要同步campaign的所有分群
            CampaignAudienceStrategy campaignAudienceStrategy = campaignService.getCampaignAudienceStrategy(task.getCampaignId());
            String audienceStrategy = (campaignAudienceStrategy != null) ? campaignAudienceStrategy.getSegmentationType() : "";
            taskEngageId = getEngageIdUsedToImportGroupFactsData(task, taskCampaignId, taskEngageId, audienceStrategy);
            log.info("Segmentation generation finished, starting campaign group facts job for Campaign ID: {}, EngageId: {}, AudienceStrategy: {}",
                    taskCampaignId, taskEngageId, audienceStrategy);
            campaignFactsDataSyncService.importGroupFactsData(taskCampaignId, taskEngageId, audienceStrategy);
        }

        return result;
    }

    private Long getEngageIdUsedToImportGroupFactsData(CampaignExecutionTask task, final Long taskCampaignId,
                                                       final Long taskEngageId, final String audienceStrategy) {
        Long result = taskEngageId;
        if (taskEngageId > 0) {
            boolean isMultiWavedSegmentation = AudienceStrategyConstants.MULTIPLE_WAVED_SEGMENTATION.equals(audienceStrategy);
            if (isMultiWavedSegmentation) {
                List<CampaignOutboundEngage> engageListByCampaignId = campaignService.getEngageListByCampaignId(taskCampaignId);
                //use the first engage as the first wave
                boolean isTheFirstWave = isTheFirstEngage(engageListByCampaignId, taskEngageId);
                if (isTheFirstWave) {
                    log.info("engageId {} is the first wave of campaign: {}, will use -1 as engageId ", task.getEngageId(), taskCampaignId);
                    result = -1L;
                } else {
                    log.info("engageId {} is not the first wave of campaign: {}, will use {} as engageId ", task.getEngageId(), taskCampaignId, taskEngageId);
                }
            }
        }
        return result;
    }

    public TaskResult onSegmentationGenerationFinish(CampaignExecutionTask task, List<OnSegmentFinishDTO> dtos) {
        // Early exit if dtos list is not exactly one item, which is expected as per current implementation.
        if (dtos == null || dtos.size() != 1) {
            log.error("Segmentation generation finish error, expected exactly one dto but found: {}", (dtos == null ? 0 : dtos.size()));
            return new TaskResult(false);
        }

        OnSegmentFinishDTO dto = dtos.get(0);
        // Further processing only if the status is "finished"


        if ("finished".equals(dto.getStatus())) {
            List<CampaignOutboundEngage> outboundEngageList = campaignService.getEngageListByCampaignId(task.getCampaignId());
            boolean isEngageIdNonZero = dto.getEngageId() > 0;

            outboundEngageList.forEach(outboundEngage -> {
                if (isEngageIdNonZero && outboundEngage.getId().equals(dto.getEngageId())) {
                    if(!CampaignOutboundEngage.ENGAGE_STATUS_RUNNING.equals(outboundEngage.getStatus())) {
                        //如果当前的状态不为running，则更新状态为prepared
                        campaignService.updateEngageStatus(outboundEngage, CampaignOutboundEngage.ENGAGE_STATUS_PREPARED);
                    }
                } else if (!isEngageIdNonZero) {
                    if(!CampaignOutboundEngage.ENGAGE_STATUS_RUNNING.equals(outboundEngage.getStatus())) {
                        //如果当前的状态不为running，则更新状态为prepared
                        campaignService.updateEngageStatus(outboundEngage, CampaignOutboundEngage.ENGAGE_STATUS_PREPARED);
                    }
                }
            });

            // Set the task as finished
            return new TaskResult(true);
        }else if("failed".equals(dto.getStatus())){
            return new TaskResult(false, true, "Segmentation generation failed with ListMemberBatchTask ID: " + dto.getListMemberBatchTaskId());
        }else{
            return new TaskResult(false);
        }
    }
}
