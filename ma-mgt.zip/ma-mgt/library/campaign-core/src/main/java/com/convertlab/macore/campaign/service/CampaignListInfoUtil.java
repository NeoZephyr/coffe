package com.convertlab.macore.campaign.service;

import com.convertlab.macore.campaign.common.utils.NameUtils;
import com.convertlab.macore.campaign.model.dto.GroupFactsDataDTO;
import com.convertlab.macore.campaign.model.entity.CampaignListInfo;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

public class CampaignListInfoUtil {
    public static void appendTargetListId(List<CampaignListInfo> campaignListInfos){

        for (CampaignListInfo listInfo : campaignListInfos){
            if (listInfo.getListType().equalsIgnoreCase(NameUtils.TARGET_GROUP)){
                String mapToListType = listInfo.getMapToListType();
                if (listInfo.getListId() == null && StringUtils.isNotBlank(mapToListType)){
                    CampaignListInfo otherListInfo = campaignListInfos.stream().filter(info -> (
                            !info.getId().equals(listInfo.getId()) &&
                            info.getListType().equalsIgnoreCase(mapToListType) &&
                            info.getEngageId().equals(listInfo.getEngageId()))
                    ).findFirst().orElse(new CampaignListInfo());
                    listInfo.setListId(otherListInfo.getListId());
                }
            }
        }
    }
}
