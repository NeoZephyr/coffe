package com.convertlab.macore.campaign.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.campaign.model.entity.CampaignFilter;
import com.convertlab.macore.campaign.model.entity.CampaignListInfo;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface CampaignListInfoMapper extends BaseMapper<CampaignListInfo> {

    //select campaignListInfo by campaignId
    @Select("SELECT * FROM campaign_list_info t " +
            "WHERE t.campaign_id = #{campaignId}")
    List<CampaignListInfo> selectByCampaignId(Long campaignId);

    @Select({"<script>",
            "SELECT * FROM campaign_list_info t",
            "WHERE t.campaign_id in ",
            "<foreach collection=\"campaignIds\" item=\"campaignId\" open=\"(\" separator=\",\" close=\")\">",
            "#{campaignId}",
            "</foreach>",
            "</script>"})
    List<CampaignListInfo> selectByBatchCampaignId(@Param("campaignIds") List<Long> campaignIds);

    @Select("SELECT * FROM campaign_list_info t " +
            "WHERE t.campaign_id = #{campaignId} and t.engage_id = #{engageId}")
    List<CampaignListInfo> selectByCampaignIdAndEngageId(@Param("campaignId") Long campaignId, @Param("engageId") Long engageId);

    @Select("SELECT * FROM campaign_list_info t " +
            "WHERE t.campaign_id = #{campaignId} and t.engage_id = #{engageId} and t.list_type = #{listType}")
    CampaignListInfo selectByCampaignIdAndEngageIdAndListType(@Param("campaignId") Long campaignId, @Param("engageId") Long engageId, @Param("listType") String listType);


    @Select("SELECT * FROM campaign_list_info t " +
            "WHERE t.campaign_id = #{campaignId} and t.list_type = #{listType}")
    List<CampaignListInfo> selectByCampaignIdAndListType(@Param("campaignId") Long campaignId, @Param("listType") String listType);

}