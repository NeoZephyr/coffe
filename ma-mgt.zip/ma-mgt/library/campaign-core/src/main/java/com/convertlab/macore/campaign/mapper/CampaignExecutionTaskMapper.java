package com.convertlab.macore.campaign.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import java.time.Instant;
import java.util.List;

public interface CampaignExecutionTaskMapper extends BaseMapper<CampaignExecutionTask> {

    //查询status为running并且isAsyncRemoteCall为true的CampaignExecutionTask
    @Select("SELECT * FROM campaign_execution_task t " +
            "WHERE t.task_status = 'Running' and t.is_async_remote_call = true")
    @ResultType(List.class)
    List<CampaignExecutionTask> getRunningAsyncRemoteCallTaskList();

    //查询status为running的CampaignExecutionTask
    @Select("SELECT * FROM campaign_execution_task t " +
            "WHERE  t.campaign_id = #{campaignId} and t.task_status = 'Running'")
    @ResultType(List.class)
    List<CampaignExecutionTask> getRunningTasksByCampaignId(@Param("campaignId") Long campaignId);

    @Select("SELECT * FROM campaign_execution_task t " +
            "WHERE  t.campaign_id = #{campaignId}  and t.task_status = #{taskStatus}")
    @ResultType(List.class)
    List<CampaignExecutionTask> getByCampaignIdAndTaskStatus(@Param("campaignId") Long campaignId, @Param("taskStatus") String taskStatus);

    @Select("SELECT * FROM campaign_execution_task t " +
            "WHERE  t.campaign_id = #{campaignId}  and t.task_status in ('Scheduled','NotStarted')")
    @ResultType(List.class)
    List<CampaignExecutionTask> getNotStartedAndScheduledTaskByCampaignId(@Param("campaignId") Long campaignId);

    @Select("SELECT id,task_type, task_status FROM campaign_execution_task t " +
            "WHERE  t.campaign_id = #{campaignId}  and (t.engage_id = #{engageId} or t.engage_id = -1) ")
    @ResultType(List.class)
    List<CampaignExecutionTask> getByCampaignIdAndEngageId(@Param("campaignId") Long campaignId, @Param("engageId") Long engageId);

    @Select("SELECT id,task_type,task_trigger_date, task_status FROM campaign_execution_task t " +
            "WHERE  t.campaign_id = #{campaignId}  and (t.engage_id = #{engageId} or t.engage_id = -1) " +
            "and t.task_type = #{taskType} and t.task_trigger_date<=now() order by task_trigger_date desc limit 3")
    @ResultType(List.class)
    List<CampaignExecutionTask> getByCampaignIdAndEngageIdAndTaskType(@Param("campaignId") Long campaignId, @Param("engageId") Long engageId, @Param("taskType") String taskType);

    @Select("SELECT * FROM campaign_execution_task t WHERE  t.task_status = 'Scheduled' and t.task_trigger_date is not null and t.task_trigger_date < #{ttlTime}")
    @ResultType(List.class)
    List<CampaignExecutionTask> getTasksScheduledBeforeTime(@Param("ttlTime") Instant ttlTime);


    @Select("select * from campaign_execution_task t where t.task_status = 'Running' and t.last_updated < #{time} " +
            "and is_async_remote_call = false and retry_count < #{retryCount} ")
    @ResultType(List.class)
    List<CampaignExecutionTask> getRunningTooLongTimeTasks(@Param("time") java.time.Instant time, @Param("retryCount") int retryCount);

    @Select("select * from campaign_execution_task t where t.task_status = 'Running' and t.last_updated < #{time} " +
            "and is_async_remote_call = true and retry_count < #{retryCount} ")
    @ResultType(List.class)
    List<CampaignExecutionTask> getRemoteRunningTooLongTimeTasks(@Param("time") java.time.Instant time, @Param("retryCount") int retryCount);

    @Select("select * from campaign_execution_task t where t.task_status = 'Failed' " +
            " and t.last_updated < #{time} and retry_count < #{retryCount} ")
    @ResultType(List.class)
    List<CampaignExecutionTask> getFailedTasks(@Param("time") java.time.Instant time, @Param("retryCount") int retryCount);


    default int upsert(CampaignExecutionTask task) {
        CampaignExecutionTask campaignExecutionTask = this.selectById(task.getId());
        if (campaignExecutionTask != null) {
            return this.updateById(task);
        } else {
            return this.insert(task);
        }
    }


}
