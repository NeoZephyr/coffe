package com.convertlab.macore.campaign.model.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.convertlab.foundation.library.mybatisplus.entity.BaseTenantEntity;
import lombok.*;

import java.io.Serializable;

@Data
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TableName(value = "campaign_audience_strategy", excludeProperty = {"version", "creatorId", "updaterId",
        "creatorName", "updaterName", "ownerId", "deptCode", "dateCreated", "lastUpdated"})
public class CampaignAudienceStrategy extends BaseTenantEntity implements Serializable {

    @TableId(value = "id", type = IdType.AUTO)
    Long id;

    @TableField("campaign_id")
    Long campaignId;

    @TableField("strategy_type")
    String strategyType;

    @TableField("profile_type")
    String profileType;

    @TableField("segmentation_type")
    String segmentationType;

    @TableField(value = "filter_id", updateStrategy = FieldStrategy.ALWAYS)
    Long filterId;

    @TableField(value = "strategy_content", updateStrategy = FieldStrategy.ALWAYS)
    String strategyContent;

    @TableField(value = "control_group_strategy", updateStrategy = FieldStrategy.ALWAYS)
    String controlGroupStrategy;

    @TableField(value = "control_group_percentage", updateStrategy = FieldStrategy.ALWAYS)
    String controlGroupPercentage;

}
