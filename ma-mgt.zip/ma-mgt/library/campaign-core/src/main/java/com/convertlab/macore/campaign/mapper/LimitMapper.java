package com.convertlab.macore.campaign.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.campaign.model.entity.CampaignTemplate;
import com.convertlab.macore.campaign.model.entity.Limit;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface LimitMapper extends BaseMapper<Limit> {

    //select limit by feature
    @Select("SELECT * FROM `limit` t " +
            "WHERE t.feature = #{feature}")
    Limit selectByFeature(@Param("feature") String feature);

}
