package com.convertlab.macore.campaign.model.dto;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class FolderDTO {
    long id;
    long parent;
    String type;
    String name;
}
