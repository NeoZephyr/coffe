package com.convertlab.macore.campaign.model.dto;

import com.convertlab.macore.campaign.common.utils.NameUtils;
import com.google.common.base.CaseFormat;
import com.google.common.collect.ImmutableSet;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class CampaignChannelEventStageDto {
    String channelType;
    String messagingName;
    String messagingType;
    Long pluginId;
    Long pluginVersionId;
    boolean isSystem;

    String sentEventId;
    String failedToSendEventId;
    String failedToSendField;
    String deliveredEventId;
    String failedToDeliveredEventId;
    String failedToDeliveredField;
    String receivedEventId;
    String openedEventId;
    String clickedEventId;

    public static final Set<String> EVENT_STAGE_NAMES = ImmutableSet.of(
            NameUtils.SENT_EVENT, NameUtils.DELIVERED_EVENT, NameUtils.RECEIVED_EVENT,
            NameUtils.OPENED_EVENT, NameUtils.CLICKED_EVENT,
            NameUtils.FAILED_TO_SEND_EVENT, NameUtils.FAILED_TO_DELIVERED_EVENT
    );

    public static final Set<String> SYSTEM_CHANNEL_TYPES = ImmutableSet.of(
           "sms", "email", "gsms", "mms", "vms", "app_push",
            "wechat_official_account", "wechat_mini_program"
    );

    public static final Map<String, String> EVENT_FIELD_MAP = EVENT_STAGE_NAMES.stream().collect(
            Collectors.toMap(
                    eventStageName -> eventStageName,
                    eventStageName -> CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL, eventStageName + "_event_id")));


    public Map<String, String> getFieldEventStageMap() {
        Map<String, String> eventStageMap = new HashMap<>();
        if (StringUtils.isNotBlank(this.getSentEventId())) {
            eventStageMap.put(this.getSentEventId(), NameUtils.SENT_EVENT);
        }
        if (StringUtils.isNotBlank(this.getDeliveredEventId())) {
            eventStageMap.put(this.getDeliveredEventId(), NameUtils.DELIVERED_EVENT);
        }
        if (StringUtils.isNotBlank(this.getReceivedEventId())) {
            eventStageMap.put(this.getReceivedEventId(), NameUtils.RECEIVED_EVENT);
        }
        if (StringUtils.isNotBlank(this.getOpenedEventId())) {
            eventStageMap.put(this.getOpenedEventId(), NameUtils.OPENED_EVENT);
        }
        if (StringUtils.isNotBlank(this.getClickedEventId())) {
            eventStageMap.put(this.getClickedEventId(), NameUtils.CLICKED_EVENT);
        }
        if (StringUtils.isNotBlank(this.getFailedToSendEventId())) {
            eventStageMap.put(this.getFailedToSendEventId(), NameUtils.FAILED_TO_SEND_EVENT);
        }
        if (StringUtils.isNotBlank(this.getFailedToDeliveredEventId())) {
            eventStageMap.put(this.getFailedToDeliveredEventId(), NameUtils.FAILED_TO_DELIVERED_EVENT);
        }
        return eventStageMap;
    }

    public Map<String, String> getUpdateFieldValueMap() {
        Map<String, String> result = new HashMap<>();
        result.put(EVENT_FIELD_MAP.get(NameUtils.SENT_EVENT), this.getSentEventId());
        result.put(EVENT_FIELD_MAP.get(NameUtils.DELIVERED_EVENT), this.getDeliveredEventId());
        result.put(EVENT_FIELD_MAP.get(NameUtils.RECEIVED_EVENT), this.getReceivedEventId());
        result.put(EVENT_FIELD_MAP.get(NameUtils.OPENED_EVENT), this.getOpenedEventId());
        result.put(EVENT_FIELD_MAP.get(NameUtils.CLICKED_EVENT), this.getClickedEventId());
        result.put(EVENT_FIELD_MAP.get(NameUtils.FAILED_TO_SEND_EVENT), this.getFailedToSendEventId());
        result.put(EVENT_FIELD_MAP.get(NameUtils.FAILED_TO_DELIVERED_EVENT), this.getFailedToDeliveredEventId());
        result.put(NameUtils.FAILED_TO_SEND_FIELD, this.getFailedToSendField());
        result.put(NameUtils.FAILED_TO_DELIVERED_FIELD, this.getFailedToDeliveredField());
        return result;
    }

}
