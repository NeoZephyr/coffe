package com.convertlab.macore.campaign.common.enums;

import lombok.Getter;

@Getter
public enum CampaignExuectionModeEnum {
    FORM_MODE("form_mode", "表单模式"),
    EXPERT_MODE("expert_mode", "专家模式"),
    ;
    private final String name;
    private final String desc;

    CampaignExuectionModeEnum(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }
}
