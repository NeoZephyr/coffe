package com.convertlab.macore.campaign.runtime;

import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;

import java.util.List;

public interface ICampaignTaskExecutor {

    void startTask(String taskId);

    void stopTask(String taskId);

    void scheduleTask(String taskId);

    void unscheduleTask(String taskId);

    void finishTask(String taskId);

    void failTask(String taskId);

}
