package com.convertlab.macore.campaign.common.enums;

import lombok.Getter;

@Getter
public enum CampaignEngageStatusEnum {
    DRAFT("Draft", "草稿"),
    NOT_STARTED("NotStarted", "未开始"),
    PREPARING("Preparing", "准备中"),
    PREPARED("Prepared", "准备完成"),
    RUNNING("Running", "运行中"),
    STOPPED("stopped", "已停止"),
    FAILED("Failed", "失败"),
    FINISHED("Finished", "已完成"),

    ;
    private final String name;
    private final String desc;

    CampaignEngageStatusEnum(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }
}