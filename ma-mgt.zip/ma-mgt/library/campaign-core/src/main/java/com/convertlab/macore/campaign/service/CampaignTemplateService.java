package com.convertlab.macore.campaign.service;

import cn.hutool.core.lang.Dict;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.model.GenericPage;
import com.convertlab.macore.campaign.common.enums.CampaignTemplateStatusEnum;
import com.convertlab.macore.campaign.common.utils.BeanCopyUtils;
import com.convertlab.macore.campaign.common.utils.JacksonUtils;
import com.convertlab.macore.campaign.mapper.CampaignTemplateMapper;
import com.convertlab.macore.campaign.model.dto.CampaignTemplateDTO;
import com.convertlab.macore.campaign.model.dto.CampaignTemplateSaveDTO;
import com.convertlab.macore.campaign.model.entity.CampaignTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Objects;

@Service
@Slf4j
@DataSourceLookup("main")
public class CampaignTemplateService {

    private final CampaignTemplateMapper campaignTemplateMapper;

    public CampaignTemplateService(CampaignTemplateMapper campaignTemplateMapper) {
        this.campaignTemplateMapper = campaignTemplateMapper;
    }

    /**
     * 查询模板列表
     *
     * @param name 过滤器名称
     */
    public GenericPage<CampaignTemplateDTO> listByPage(String name, String status, Integer pageNum, Integer pageSize) {
        Page<CampaignTemplate> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<CampaignTemplate> queryWrapper = new LambdaQueryWrapper<>();
        if (StrUtil.isNotBlank(name)) {
            queryWrapper.like(CampaignTemplate::getTemplateName, name);
        }

        if (StrUtil.isNotBlank(status)) {
            queryWrapper.eq(CampaignTemplate::getStatus, status);
        }

        queryWrapper.orderByDesc(CampaignTemplate::getLastUpdated);

        Page<CampaignTemplate> pageResult = campaignTemplateMapper.selectPage(page, queryWrapper);
        return GenericPage.<CampaignTemplateDTO>builder()
                .current((int) pageResult.getCurrent())
                .total((int) pageResult.getTotal())
                .records(BeanCopyUtils.copyList(pageResult.getRecords(), CampaignTemplateDTO::new))
                .build();
    }

    /**
     * 保存或更新模版信息
     *
     * @param dto 模板信息
     */
    public boolean saveOrUpdateTemplate(CampaignTemplateSaveDTO dto) {
        if (Objects.isNull(dto.getId())) {
            Long count = campaignTemplateMapper.selectCount(new LambdaQueryWrapper<CampaignTemplate>().eq(CampaignTemplate::getTemplateName, dto.getTemplateName()));
            if (count > 0) {
                throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000029", "campaign template name is exists. {}", new String[]{dto.getTemplateName()});
            }

            return campaignTemplateMapper.insert(buildEntity(dto)) > 0;
        }

        CampaignTemplate campaignTemplate = campaignTemplateMapper.selectById(dto.getId());
        if (Objects.isNull(campaignTemplate)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000024", "campaign template is not exists. {}", new String[]{dto.getId().toString()});
        }

        return campaignTemplateMapper.updateById(buildEntity(dto)) > 0;
    }

    /**
     * 模版详情
     *
     * @param id 模版Id
     */
    public CampaignTemplateDTO findById(Long id) {
        CampaignTemplate campaignTemplate = campaignTemplateMapper.selectById(id);
        if (Objects.isNull(campaignTemplate)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000024", "campaign template is not exists. {}", new String[]{id.toString()});
        }

        return BeanCopyUtils.copyBean(campaignTemplate, CampaignTemplateDTO::new);
    }

    /**
     * 复制模板信息
     *
     * @param id 模版Id
     */
    public boolean copyCampaignTemplate(Long id) {
        CampaignTemplate campaignTemplate = campaignTemplateMapper.selectById(id);
        if (Objects.isNull(campaignTemplate)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000024", "campaign template is not exists. {}", new String[]{id.toString()});
        }

        CampaignTemplate template = BeanCopyUtils.copyBean(campaignTemplate, CampaignTemplate::new, "id", "tenantId", "useCnt");
        template.setTemplateName(template.getTemplateName() + "_复制");
        template.setLastUpdated(Instant.now());
        return campaignTemplateMapper.insert(template) > 0;
    }

    /**
     * 模板删除
     *
     * @param id 过滤器ID
     */
    public boolean del(Long id) {
        return campaignTemplateMapper.deleteById(id) > 0;
    }

    /**
     * 模板启用/禁用
     *
     * @param id     模板ID
     * @param status 状态
     * @return boolean
     */
    public boolean updateStatus(Long id, String status) {
        CampaignTemplate campaignTemplate = campaignTemplateMapper.selectById(id);
        if (Objects.isNull(campaignTemplate)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000024", "campaign template is not exists. {}", new String[]{id.toString()});
        }

        if (!CampaignTemplateStatusEnum.contains(status)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000025", "campaign template status is not valid. {}", new String[]{status});
        }

        campaignTemplate.setStatus(status);
        return campaignTemplateMapper.updateById(campaignTemplate) > 0;
    }

    public void updateUseCnt(Long id) {
        if (Objects.isNull(id)) {
            return;
        }

        CampaignTemplate campaignTemplate = campaignTemplateMapper.selectById(id);
        if (Objects.isNull(campaignTemplate)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR.getCode(), "MSG_108_000024", "campaign template is not exists. {}", new String[]{id.toString()});
        }

        campaignTemplate.setUseCnt(campaignTemplate.getUseCnt() + 1);
        campaignTemplateMapper.updateById(campaignTemplate);
    }

    private CampaignTemplate buildEntity(CampaignTemplateSaveDTO dto) {
        return CampaignTemplate.builder()
                .id(dto.getId())
                .templateName(dto.getTemplateName())
                .description(dto.getDescription())
                .folderId(dto.getFolderId())
                .attrs(JacksonUtils.toJSONString(dto.getAttrs()))
                .campaignStrategy(JacksonUtils.toJSONString(Dict.create()
                        .set("audienceStrategy", dto.getAudienceStrategy())
                        .set("channelStrategy", dto.getChannelStrategy())
                        .set("timeStrategy", dto.getTimeStrategy())
                        .set("controlGroupStrategy", dto.getControlGroupStrategy())))
                .build();
    }
}
