package com.convertlab.macore.campaign.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.campaign.model.entity.CampaignMainTargetAudienceMapping;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface MainTargetAudienceMappingMapper extends BaseMapper<CampaignMainTargetAudienceMapping> {

    //根据CampaignId返回List Of CampaignMainTargetAudienceMapping
    @Select({"<script>",
            "SELECT * FROM campaign_main_target_audience_mapping t",
            "WHERE t.campaign_id = #{campaignId}",
            "</script>"})
    List<CampaignMainTargetAudienceMapping> selectByCampaignId(@Param("campaignId")Long campaignId);
}