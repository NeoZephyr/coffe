package com.convertlab.macore.campaign.common.utils;

public class AudienceStrategyConstants {

    // 按目标群组划分
    public static final String MANUAL_SPECIFIED_SEGMENTATION = "Manual_Specified_Segmentation";

    // 按比例切分目标群组
    public static final String MANUAL_PERCENTAGE_SEGMENTATION = "Manual_Percentage_Segmentation";

    // 按固定数量切分目标群组
    public static final String MANUAL_QUANTITY_SEGMENTATION = "Manual_Quantity_Segmentation";

    // 按客户画像划分
    public static final String PSYCHOGRAPHIC_SEGMENTATION = "Psychographic_Segmentation";

    // 按活动波次划分
    public static final String MULTIPLE_WAVED_SEGMENTATION = "Multiple_Waved_Segmentation";


}
