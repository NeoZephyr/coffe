package com.convertlab.macore.campaign.common.utils;

public class ControlGroupStrategyConstants {

    //Control_At_Edege
    public static final String CONTROL_AT_Engage = "Control_At_Engage";
    public static final String CONTROL_AT_CAMPAIGN = "Control_At_Campaign";


    //Control_At_Engage



}
