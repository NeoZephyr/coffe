package com.convertlab.macore.campaign.runtime.taskchain;

import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.dto.CronDTO;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.runtime.task.CampaignTaskService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.*;
import java.util.*;
import java.util.function.Function;

/**
 *
 *
 */
@Service
@Slf4j
public class EngageSegmentPeriodicTaskChain extends AbstractPeriodicTaskChainStrategy{

    public EngageSegmentPeriodicTaskChain(CampaignTaskService campaignTaskService, TimeStrategyService timeStrategyService, ObjectMapper objectMapper) {
        super(campaignTaskService, timeStrategyService, objectMapper);
    }

    @Override
    public List<CampaignExecutionTask> createTaskChain(CampaignFullDataDTO campaignFullData) {

        //初始化task chain, 默认添加create folder and list, 以及generate flow.
        List<CampaignExecutionTask> tasks = initializeTaskChain(campaignFullData);

        //iterate engageListByCampaignId and start engage task for each engage.
        buildTaskChain(campaignFullData, timeStrategyService::calculateTriggersThisMonth, tasks);

        return tasks;
    }

    public List<CampaignExecutionTask> createTaskChainForNextMonth(CampaignFullDataDTO campaignFullData, Instant initialTime) {

        //初始化task chain, 默认添加create folder and list, 以及generate flow.
        List<CampaignExecutionTask> tasks = new ArrayList<>();

        //iterate engageListByCampaignId and start engage task for each engage.
        buildTaskChainForNextMonth(campaignFullData, timeStrategyService::calculateTriggersNextMonth, tasks, initialTime);

        return tasks;
    }

    void buildTaskChain(CampaignFullDataDTO campaignFullData, Function<CronDTO, List<ZonedDateTime>> triggerCalculator, List<CampaignExecutionTask> tasks) {
        //iterate engageListByCampaignId and start engage task for each engage.
        for (CampaignOutboundEngage engage : campaignFullData.getOutboundEngageList()) {
            try {
                CronDTO cronDTO = parseCronDTO(engage.getTimeData());
                List<ZonedDateTime> triggers = triggerCalculator.apply(cronDTO);
                addSegmentAndEngageTasks(campaignFullData, tasks, engage, triggers);

            } catch (Exception e) {
                throw new RuntimeException("Failed to parse timeData for engage: " + engage.getId());
            }
        }
        //计算一个重算时间.
        addPeriodicTask(campaignFullData, tasks, Instant.now());
    }

    void buildTaskChainForNextMonth(CampaignFullDataDTO campaignFullData, TriggerCalculator triggerCalculator, List<CampaignExecutionTask> tasks, Instant initTime) {
        //iterate engageListByCampaignId and start engage task for each engage.
        for (CampaignOutboundEngage engage : campaignFullData.getOutboundEngageList()) {
            try {
                CronDTO cronDTO = parseCronDTO(engage.getTimeData());
                List<ZonedDateTime> triggers = triggerCalculator.apply(cronDTO, initTime);
                addSegmentTasks(campaignFullData, tasks, engage, triggers);

            } catch (Exception e) {
                throw new RuntimeException("Failed to parse timeData for engage: " + engage.getId());
            }
        }
        //计算一个重算时间.
        addPeriodicTask(campaignFullData, tasks, addOneMonth(initTime));
    }




    void addSegmentTasks(CampaignFullDataDTO campaignFullData, List<CampaignExecutionTask> tasks, CampaignOutboundEngage engage, List<ZonedDateTime> triggers){
            triggers.forEach(trigger -> {
                Instant instant = trigger.toInstant();
                //为每一个trigger时间点，创建一个segmentationTask
                CampaignExecutionTask segmentationTask = campaignTaskService.createSegmentationTask(campaignFullData.getCampaign(), engage);
                Instant segmentScheduledTime = timeStrategyService.getSegmentScheduledTime(instant);
                segmentationTask.setTaskTriggerDate(segmentScheduledTime);
                tasks.add(segmentationTask);
        });
    }
    void addSegmentAndEngageTasks(CampaignFullDataDTO campaignFullData, List<CampaignExecutionTask> tasks, CampaignOutboundEngage engage, List<ZonedDateTime> triggers) {

        if(triggers.isEmpty()){
            //如果未找到triggers,则默认启动engage
            CampaignExecutionTask startEngageTask = campaignTaskService.createStartEngageTask(campaignFullData, engage);
            tasks.add(startEngageTask);
            return;
        }

        triggers.forEach(trigger -> {
            Instant instant = trigger.toInstant();
            if(trigger == triggers.get(0)){
                //为第一个trigger增加start engage task，启动周期性自动流。
                CampaignExecutionTask startEngageTask = campaignTaskService.createStartEngageTask(campaignFullData, engage);
                //适当的提前10分钟执行任务，避免自动流程周期性营销错过第一个时间点。
                startEngageTask.setTaskTriggerDate(instant.minusSeconds(600));
                //为每一个engage,创建一个
                CampaignExecutionTask segmentationTask = campaignTaskService.createSegmentationTask(campaignFullData.getCampaign(), engage);
                Instant segmentScheduledTime = timeStrategyService.getSegmentScheduledTime(instant);
                segmentationTask.setTaskTriggerDate(segmentScheduledTime);

                //添加任务到任务序列
                tasks.add(segmentationTask);
                tasks.add(startEngageTask);
            }else{
                //为每一个trigger时间点，创建一个segmentationTask
                CampaignExecutionTask segmentationTask = campaignTaskService.createSegmentationTask(campaignFullData.getCampaign(), engage);
                Instant segmentScheduledTime = timeStrategyService.getSegmentScheduledTime(instant);
                segmentationTask.setTaskTriggerDate(segmentScheduledTime);
                tasks.add(segmentationTask);
            }
        });
    }


}
