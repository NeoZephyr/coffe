package com.convertlab.macore.campaign.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.campaign.model.entity.CampaignFilter;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CampaignFilterMapper extends BaseMapper<CampaignFilter> {
}