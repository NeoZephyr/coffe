package com.convertlab.macore.campaign.model.dto;

import com.alibaba.excel.util.StringUtils;
import com.convertlab.macore.campaign.common.utils.AudienceStrategyConstants;
import com.convertlab.macore.campaign.common.utils.NameUtils;
import com.convertlab.macore.campaign.model.entity.CampaignAudienceStrategy;
import com.convertlab.macore.campaign.model.entity.CampaignListInfo;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import lombok.Builder;
import lombok.Data;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Data
public class CampaignEngageBatchContext {

    List<CampaignEngageBatchDim> engageBatchDimList;
    Map<Long, CampaignAudienceStrategy> campaignAudienceStrategyMap;
    Map<Long, Map<String, Object>> campaignInfoMap;
    Map<Long, Map<String, Object>> engageInfoMap;
    Map<Long, Map<String, Object>> filterInfoMap;
    Map<Long, CampaignOutboundEngage> engageMap;
    Map<Long, List<CampaignListInfo>> campaignListMap;

    public CampaignEngageBatchContext(){
        engageBatchDimList = new ArrayList<>();
    }

    public CampaignEngageBatchContext(List<CampaignEngageBatchDim> campaignStatList,
                                      Map<Long, Map<String, Object>> campaignInfoMap,
                                      Map<Long, Map<String, Object>> engageInfoMap,
                                      Map<Long, List<CampaignListInfo>> campaignListMap,
                                      Map<Long, Map<String, Object>> filterInfoMap,
                                      Map<Long, CampaignAudienceStrategy> campaignAudienceStrategyMap) {
        this.engageBatchDimList = campaignStatList;
        this.campaignInfoMap = campaignInfoMap;
        this.engageInfoMap = engageInfoMap;
        this.campaignListMap = campaignListMap;
        this.filterInfoMap = filterInfoMap;
        this.campaignAudienceStrategyMap = campaignAudienceStrategyMap;
    }

    public List<String> getBatchIds() {
        return engageBatchDimList.stream().map(CampaignEngageBatchDim::getBatchId).collect(Collectors.toList());
    }

    public Map<String, CampaignEngageBatchDim> getBatchInfoMap() {
        return engageBatchDimList.stream().collect(Collectors.toMap(CampaignEngageBatchDim::getBatchId, dim -> dim));
    }

    public List<CampaignListInfo> getCampaignListByListType(Long campaignId, String listType) {

        if (CollectionUtils.isEmpty(campaignListMap) || CollectionUtils.isEmpty(campaignListMap.get(campaignId))){
            return Collections.emptyList();
        }

        List<CampaignListInfo> campaignListInfos = campaignListMap.get(campaignId);
        return campaignListInfos.stream().filter(info -> StringUtils.equals(info.getListType(), listType))
                .collect(Collectors.toList());
    }

    public boolean hasEngageFilterGroup(Long campaignId) {
        List<CampaignListInfo> campaignListByListType = getCampaignListByListType(campaignId, NameUtils.FILTERED_GROUP);
        return campaignListByListType.stream().anyMatch(e -> NameUtils.FILTERED_GROUP.equals(e.getListType()) && e.getEngageId() > 0);
    }

    public boolean hasFilterGroup(Long campaignId) {
        List<CampaignListInfo> campaignListByListType = getCampaignListByListType(campaignId, NameUtils.FILTERED_GROUP);
        return !campaignListByListType.isEmpty();
    }

    public boolean isMultiWavedSegmentation(Long campaignId) {
        CampaignAudienceStrategy strategy = getCampaignAudienceStrategyMap().get(campaignId);
        return strategy != null && AudienceStrategyConstants.MULTIPLE_WAVED_SEGMENTATION.equals(strategy.getSegmentationType());
    }

    public boolean isMinEngageId(Long currEngageId) {
        Set<Long> engageIds = getEngageInfoMap().keySet();
        //get min from engageIds
        return engageIds.stream().min(Comparator.comparing(Long::longValue)).orElse(0L).equals(currEngageId);
    }

    @Data
    @Builder
    public static class CampaignEngageBatchDim {
        String campaignName;
        String campaignCode;
        Long campaignId;
        Long engageId ;
        String engageName;
        String engageCode;
        Long flowId;
        String batchId;
        String channelType;
        String messagingType;
        Long templateId;
        String templateName;
    }
}