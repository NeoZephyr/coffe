package com.convertlab.macore.campaign.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.LocalDateTimeUtil;
import cn.hutool.core.lang.Dict;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.macore.campaign.common.enums.CampaignEngageStatusEnum;
import com.convertlab.macore.campaign.common.enums.CampaignStatusEnum;
import com.convertlab.macore.campaign.common.enums.SegmentationTypeEnum;
import com.convertlab.macore.campaign.common.enums.TimeStrategyTypeEnum;
import com.convertlab.macore.campaign.common.utils.BeanCopyUtils;
import com.convertlab.macore.campaign.common.utils.JacksonUtils;
import com.convertlab.macore.campaign.mapper.CampaignOutboundEngageMapper;
import com.convertlab.macore.campaign.mapper.MarketingCampaignMapper;
import com.convertlab.macore.campaign.model.dto.CampaignDTO;
import com.convertlab.macore.campaign.model.dto.CampaignEngageGuideDTO;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.runtime.CampaignRuntimeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static com.convertlab.macore.campaign.common.enums.SegmentationTypeEnum.PSYCHOGRAPHIC_SEGMENTATION;

@Service
@Slf4j
public class OutboundEngageService extends ServiceImpl<CampaignOutboundEngageMapper, CampaignOutboundEngage> {
    @Lazy
    @Resource
    private CampaignRuntimeService campaignRuntimeService;

    @Resource
    private MarketingCampaignMapper marketingCampaignMapper;

    @Resource
    private CampaignMetaService campaignMetaService;

    @DataSourceLookup("main")
    public boolean saveEngage(CampaignDTO dto, Long campaignId, Long strategyId) {
        CampaignDTO.AudienceStrategy audienceStrategy = dto.getAudienceStrategy();
        SegmentationTypeEnum segmentationType = SegmentationTypeEnum.valueOf(audienceStrategy.getSegmentationType().toUpperCase());
        List<String> targetAudienceList = Arrays.stream(audienceStrategy.getTargetSegmentation().split(",")).collect(Collectors.toList());
        int loop;
        switch (segmentationType) {
            case MANUAL_SPECIFIED_SEGMENTATION:
                loop = targetAudienceList.size();
                break;
            case MULTIPLE_WAVED_SEGMENTATION:
                loop = Integer.parseInt(Optional.ofNullable(audienceStrategy.getData().get("waveNumber")).orElse("0").toString());
                break;
            default:
                loop = Integer.parseInt(Optional.ofNullable(audienceStrategy.getData().get("amount")).orElse("0").toString());
                break;
        }

        if (loop == 0) {
            log.error("Audience strategy amount is empty, campaignId: {}", campaignId);
            return false;
        }

        List<CampaignOutboundEngage> engageList = IntStream.range(0, loop)
                .mapToObj(i -> buildEngage(dto, campaignId, targetAudienceList, i + 1))
                .collect(Collectors.toList());

        boolean result = false;
        if (CollUtil.isNotEmpty(engageList)) {
            result = this.saveBatch(engageList);
        }

        return result;
    }

    @DataSourceLookup("main")
    public boolean updateEngage(CampaignDTO dto, Long campaignId, Long strategyId) {
        this.lambdaUpdate().eq(CampaignOutboundEngage::getCampaignId, campaignId).remove();
        return saveEngage(dto, campaignId, strategyId);
    }

    @DataSourceLookup("main")
    public boolean guideEngage(CampaignEngageGuideDTO dto, Long campaignId) {
        List<CampaignOutboundEngage> engageList = getEngageByCampaignId(campaignId);
        if (CollUtil.isEmpty(engageList)) {
            log.error("engageList is empty, campaignId: {}", campaignId);
            return false;
        }

        MarketingCampaign campaign = marketingCampaignMapper.selectById(campaignId);
        if (Objects.isNull(campaign)) {
            log.error("campaign is empty, campaignId: {}", campaignId);
            return false;
        }

        // delete status draft
        this.lambdaUpdate().eq(CampaignOutboundEngage::getCampaignId, campaignId)
                .eq(CampaignOutboundEngage::getStatus, CampaignEngageStatusEnum.DRAFT.getName())
                .remove();

        List<String> statusList = Arrays.asList(CampaignEngageStatusEnum.DRAFT.getName(), CampaignEngageStatusEnum.NOT_STARTED.getName(),
                CampaignEngageStatusEnum.PREPARING.getName(), CampaignEngageStatusEnum.PREPARED.getName());

        List<CampaignEngageGuideDTO.Node> dtoList = dto.getEngageList();
        List<CampaignOutboundEngage> dbList = dtoList.stream()
                .sorted(Comparator.comparing(CampaignEngageGuideDTO.Node::getSeq))
                .peek(engage -> engage.setSeq(dtoList.indexOf(engage) + 1))
                .filter(engage -> statusList.contains(engage.getStatus()))
                .map(engage -> {
                    CampaignOutboundEngage outboundEngage = BeanCopyUtils.copyBean(engage, CampaignOutboundEngage::new);
                    if (Objects.isNull(outboundEngage.getId())) {
                        outboundEngage.setCampaignId(campaignId);
                        outboundEngage.setCode(StrUtil.isBlank(engage.getCode()) ? getCampaignCode(campaignId) : engage.getCode());
                    }

                    if (PSYCHOGRAPHIC_SEGMENTATION.getName().equals(outboundEngage.getAudienceStrategy()) && outboundEngage.getAudienceData().contains("filter")) {
                        Dict dict = JacksonUtils.parseObject(outboundEngage.getAudienceData(), Dict.class);
                        dict.remove("remainingSegmentation");
                        outboundEngage.setAudienceData(JacksonUtils.toJSONString(dict));
                    }
                    return outboundEngage;
                }).collect(Collectors.toList());

        if (CollUtil.isNotEmpty(dbList)) {
            super.saveOrUpdateBatch(dbList);

            // 更新engageAttribute
            Map<Long, Map<String, String>> engageAttributeMap = buildEngageAttr(dtoList, dbList);
            if (!engageAttributeMap.isEmpty()) {
                campaignMetaService.saveOrUpdateEngageAttribute(campaignId, engageAttributeMap);
            }

            // 更新engageList
            if (StrUtil.equals(CampaignStatusEnum.RUNNING.getName(), campaign.getStatus())) {
                campaignRuntimeService.updateEngageList(campaignId, dbList);
            }
        }
        return true;
    }

    @DataSourceLookup("main")
    public void copyEngine(Long campaignId, Long copyCampaignId) {
        List<CampaignOutboundEngage> engageList = this.getEngageByCampaignId(campaignId);
        if (CollUtil.isNotEmpty(engageList)) {
            List<CampaignOutboundEngage> copyEngageList = engageList.stream()
                    .map(item -> {
                        CampaignOutboundEngage outboundEngage = BeanUtil.copyProperties(item, CampaignOutboundEngage.class, "id", "tenantId", "campaignId", "flowId");
                        outboundEngage.setCampaignId(copyCampaignId);
                        outboundEngage.setStatus(CampaignEngageStatusEnum.DRAFT.getName());
                        return outboundEngage;
                    }).collect(Collectors.toList());
            super.saveBatch(copyEngageList);

            Map<Long, Map<String, String>> engageAttributeData = campaignMetaService.getEngageAttributeData(campaignId);
            if (MapUtil.isNotEmpty(engageAttributeData)) {
                List<Map<String, String>> engageAttrs = new ArrayList<>(engageAttributeData.values());
                Map<Long, Map<String, String>> copyEngageAttributeData = engageAttrs.stream()
                        .collect(Collectors.toMap(
                                map -> copyEngageList.get(engageAttrs.indexOf(map)).getId(),
                                map -> map
                        ));
                campaignMetaService.saveOrUpdateEngageAttribute(copyCampaignId, copyEngageAttributeData);
            }
        }
    }

    @DataSourceLookup("main")
    public List<CampaignOutboundEngage> getEngageByCampaignId(Long campaignId) {
        return this.lambdaQuery().eq(CampaignOutboundEngage::getCampaignId, campaignId).orderByAsc(CampaignOutboundEngage::getSeq).list();
    }

    private CampaignOutboundEngage buildEngage(CampaignDTO dto, Long campaignId, List<String> audienceList, int seq) {
        CampaignDTO.AudienceStrategy audienceStrategy = dto.getAudienceStrategy();
        CampaignDTO.TimeStrategy timeStrategy = dto.getTimeStrategy();
        CampaignDTO.ChannelStrategy channelStrategy = dto.getChannelStrategy();
        CampaignDTO.ControlGroupStrategy controlGroupStrategy = dto.getControlGroupStrategy();
        return CampaignOutboundEngage.builder()
                .seq(seq)
                .code(getCampaignCode(campaignId))
                .campaignId(campaignId)
                .status(CampaignEngageStatusEnum.DRAFT.getName())
                .audienceStrategy(audienceStrategy.getSegmentationType())
                .audienceData(JacksonUtils.toJSONString(getAudienceData(audienceStrategy, audienceList, seq)))
                .channelStrategy(channelStrategy.getStrategy())
                .channelData(JacksonUtils.toJSONString(channelStrategy.getData()))
                .timeStrategy(SegmentationTypeEnum.MULTIPLE_WAVED_SEGMENTATION.getName().equals(audienceStrategy.getSegmentationType())
                        ? TimeStrategyTypeEnum.SCHEDULED.getName() : timeStrategy.getStrategy())
                .timeData(JacksonUtils.toJSONString(getTimeData(timeStrategy, audienceStrategy, seq)))
                .controlGroupStrategy(controlGroupStrategy.getStrategy())
                .controlGroupData(JacksonUtils.toJSONString(controlGroupStrategy.getData()))
                .build();
    }

    private Map<String, Object> getAudienceData(CampaignDTO.AudienceStrategy audienceStrategy, List<String> audienceList, int seq) {
        Dict dict = Dict.create();
        Map<String, Object> data = audienceStrategy.getData();
        SegmentationTypeEnum type = SegmentationTypeEnum.valueOf(audienceStrategy.getSegmentationType().toUpperCase());
        switch (type) {
            case MANUAL_SPECIFIED_SEGMENTATION:
                dict.set("listId", audienceList.get(seq - 1));
                break;
            case MANUAL_PERCENTAGE_SEGMENTATION:
                dict.set("percentage", getAudienceRate(data, seq));
                break;
            case MANUAL_QUANTITY_SEGMENTATION:
                String quantity = handlerRates(data).get(seq - 1);
                if (StrUtil.equals("remain", quantity)) {
                    dict.set("remainingSegmentation", MapUtil.getBool(data, "remaining_segmentation_enabled"));
                } else {
                    dict.set("quantity", Integer.parseInt(quantity));
                }
                break;
            case PSYCHOGRAPHIC_SEGMENTATION:
                dict.set("remainingSegmentation", MapUtil.getBool(data, "remaining_segmentation_enabled"));
                break;
            case MULTIPLE_WAVED_SEGMENTATION:
                dict.set("listId", audienceStrategy.getTargetSegmentation())
                        .set("conversionEvent", data.get("conversionEvent"))
                        .set("listCalculateDate", listCalculateDate(seq, data));
                break;
            default:
                break;
        }
        return dict;
    }

    private BigDecimal getAudienceRate(Map<String, Object> data, int seq) {
        List<String> dataList = handlerRates(data);
        String rate = dataList.get(seq - 1);

        if (StrUtil.equals("remain", rate)) {
            double remain = dataList.stream().filter(item -> !item.equals("remain")).mapToDouble(Double::parseDouble).sum();
            return BigDecimal.ONE.subtract(BigDecimal.valueOf(remain));
        }
        return BigDecimal.valueOf(Double.parseDouble(rate));
    }

    private Map<String, Object> getTimeData(CampaignDTO.TimeStrategy timeStrategy, CampaignDTO.AudienceStrategy audienceStrategy, int seq) {
        if (SegmentationTypeEnum.MULTIPLE_WAVED_SEGMENTATION.getName().equals(audienceStrategy.getSegmentationType())) {
            return Dict.create().set("date_of_next_wave", listCalculateDate(seq, audienceStrategy.getData()));
        }

        return timeStrategy.getData();
    }

    private List<String> handlerRates(Map<String, Object> data) {
        String reteStr = data.get("rate").toString();
        String pureData = reteStr.substring(1, reteStr.length() - 1);
        return Arrays.asList(pureData.split(", "));
    }

    private LocalDateTime listCalculateDate(int seq, Map<String, Object> data) {
        LocalDateTime dateOfFirstWave = LocalDateTimeUtil.parse(MapUtil.getStr(data, "dateOfFirstWave"), DatePattern.UTC_PATTERN);
        int interval = MapUtil.getInt(data, "daysOfWaveInterval");
        return dateOfFirstWave.plusDays((long) (seq - 1) * interval);
    }

    private static String getCampaignCode(Long campaignId) {
        return "CAM_V4_" + campaignId + "_" + RandomUtil.randomNumbers(6);
    }

    private static Map<Long, Map<String, String>> buildEngageAttr(List<CampaignEngageGuideDTO.Node> dtoList, List<CampaignOutboundEngage> dbList) {
        return dtoList.stream()
                .filter(v -> MapUtil.isNotEmpty(v.getEngageAttribute()))
                .collect(Collectors.toMap(
                        node -> {
                            Long engageId = node.getId();
                            if (Objects.isNull(engageId)) {
                                engageId = dbList.stream().filter(v -> StrUtil.equals(v.getCode(), node.getCode())).findFirst().map(CampaignOutboundEngage::getId).orElse(null);
                            }
                            return engageId;
                        },
                        CampaignEngageGuideDTO.Node::getEngageAttribute
                ));
    }
}
