package com.convertlab.macore.campaign.runtime.taskchain;

import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.dto.CronDTO;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.runtime.task.CampaignTaskService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Slf4j
public class CampaignSegmentPeriodicTaskChain extends AbstractPeriodicTaskChainStrategy {

    public CampaignSegmentPeriodicTaskChain(CampaignTaskService campaignTaskService, TimeStrategyService timeStrategyService, ObjectMapper objectMapper) {
        super(campaignTaskService, timeStrategyService, objectMapper);
    }

    @Override
    public List<CampaignExecutionTask> createTaskChain(CampaignFullDataDTO campaignFullData) {

        //初始化task chain, 默认添加create folder and list, 以及generate flow.
        List<CampaignExecutionTask> tasks = initializeTaskChain(campaignFullData);

        //iterate engageListByCampaignId and start engage task for each engage.
        buildTaskChain(campaignFullData, timeStrategyService::calculateTriggersThisMonth, tasks);

        return tasks;
    }

    public List<CampaignExecutionTask> createTaskChainForNextMonth(CampaignFullDataDTO campaignFullData, Instant initialTime) {
        List<CampaignExecutionTask> tasks = new ArrayList<>();

        //iterate engageListByCampaignId and start engage task for each engage.
        buildTaskChainNextMonth(campaignFullData, timeStrategyService::calculateTriggersNextMonth, tasks, initialTime);

        return tasks;
    }
    void buildTaskChain(CampaignFullDataDTO campaignFullData, TriggerCalculator triggerCalculator, List<CampaignExecutionTask> tasks) {
        List<ZonedDateTime> allTriggers = generateTriggers(campaignFullData, triggerCalculator, Instant.now());
        processTriggersTasks(campaignFullData, allTriggers, tasks, true, Instant.now());
        addPeriodicTask(campaignFullData, tasks, Instant.now());
    }

    void buildTaskChainNextMonth(CampaignFullDataDTO campaignFullData, TriggerCalculator triggerCalculator, List<CampaignExecutionTask> tasks, Instant initialTime) {
        List<ZonedDateTime> allTriggers = generateTriggers(campaignFullData, triggerCalculator, initialTime);
        processTriggersTasks(campaignFullData, allTriggers, tasks, false, initialTime);
        addPeriodicTask(campaignFullData, tasks, addOneMonth(initialTime));
    }

    private List<ZonedDateTime> generateTriggers(CampaignFullDataDTO campaignFullData, TriggerCalculator triggerCalculator, Instant initialTime) {
        List<ZonedDateTime> allTriggers = new ArrayList<>();
        for (CampaignOutboundEngage engage : campaignFullData.getOutboundEngageList()) {
            try {
                CronDTO cronDTO = parseCronDTO(engage.getTimeData());
                List<ZonedDateTime> triggers = triggerCalculator.apply(cronDTO, initialTime);
                allTriggers.addAll(triggers);
            } catch (Exception e) {
                throw new RuntimeException("Failed to parse timeData for engage: " + engage.getId(), e);
            }
        }
        return allTriggers;
    }

    private void processTriggersTasks(CampaignFullDataDTO campaignFullData, List<ZonedDateTime> allTriggers, List<CampaignExecutionTask> tasks, boolean addEngageTasks, Instant initialTime) {
        if (addEngageTasks) {
            for (CampaignOutboundEngage engage : campaignFullData.getOutboundEngageList()) {
                List<ZonedDateTime> triggers = allTriggers; // Assuming triggers are already calculated
                addEngageTask(campaignFullData, engage, triggers, tasks);
            }
        }
        addSegmentTask(campaignFullData, allTriggers, tasks);
    }

    void addSegmentTask(CampaignFullDataDTO campaignFullData, List<ZonedDateTime> allTriggers, List<CampaignExecutionTask> tasks) {
        //按照日期进行group by
        Map<LocalDate, List<ZonedDateTime>> groupedByDate = allTriggers.stream()
                .collect(Collectors.groupingBy(zdt -> zdt.toLocalDate()));

        //针对每个独立的日期，创建一个segmentationTask
        groupedByDate.forEach((date, triggers) -> {
            CampaignExecutionTask segmentationTask = campaignTaskService.createSegmentationTask(campaignFullData.getCampaign(), null);
            //将date装换为ZoneDateTime
            ZonedDateTime zdt = date.atStartOfDay(TimeStrategyService.ZONE_ID_BEIJING).withHour(12);
            Instant segmentScheduledTime = timeStrategyService.getSegmentScheduledTime(zdt.toInstant());
            segmentationTask.setTaskTriggerDate(segmentScheduledTime);
            tasks.add(segmentationTask);
        });
    }

    void addEngageTask(CampaignFullDataDTO campaignFullData, CampaignOutboundEngage engage, List<ZonedDateTime> triggers, List<CampaignExecutionTask> tasks) {
        if(triggers.isEmpty()){
            CampaignExecutionTask startEngageTask = campaignTaskService.createStartEngageTask(campaignFullData, engage);
            tasks.add(startEngageTask);
            return;
        }

        Instant instant = triggers.get(0).toInstant();
        CampaignExecutionTask startEngageTask = campaignTaskService.createStartEngageTask(campaignFullData, engage);
        startEngageTask.setTaskTriggerDate(instant.minusSeconds(600));
        tasks.add(startEngageTask);
    }

}
