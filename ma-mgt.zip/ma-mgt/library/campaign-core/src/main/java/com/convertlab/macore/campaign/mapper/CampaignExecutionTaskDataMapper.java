package com.convertlab.macore.campaign.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTaskData;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface CampaignExecutionTaskDataMapper extends BaseMapper<CampaignExecutionTaskData> {

    //根据taskId, 以及Key, 读取CampaignExecutionTaskData.
    @Select("SELECT * FROM campaign_execution_task_data t " +
            "WHERE t.campaign_id = #{campaignId} and t.task_id = #{taskId} and t.data_key = #{key}")
    List<CampaignExecutionTaskData> getByCampainIdTaskIdAndKey(@Param("campaignId")Long campaignId, @Param("taskId")String taskId, @Param("key")String key);

    @Select("SELECT * FROM campaign_execution_task_data t " +
            "WHERE t.campaign_id = #{campaignId} and t.engage_id = #{engageId} and t.task_id = #{taskId} and t.data_key = #{key}")
    List<CampaignExecutionTaskData> getByCampainIdAndEngageIdTaskIdAndKey(@Param("campaignId")Long campaignId, @Param("engageId")Long engageId, @Param("taskId")String taskId, @Param("key")String key);

    @Select("SELECT * FROM campaign_execution_task_data t " +
            "WHERE t.campaign_id = #{campaignId} and t.data_key = #{key}")
    List<CampaignExecutionTaskData> getByCampaignIdAndDataKey(@Param("campaignId")Long campaignId, @Param("key")String key);

    @Select("SELECT * FROM campaign_execution_task_data t " +
            "WHERE t.campaign_id = #{campaignId} and t.engage_id = #{engageId} and t.data_key = #{key}")
    List<CampaignExecutionTaskData> getByCampaignIdAndEngageIdAndDataKey(@Param("campaignId")Long campaignId, @Param("engageId")Long engageId, @Param("key")String key);

}
