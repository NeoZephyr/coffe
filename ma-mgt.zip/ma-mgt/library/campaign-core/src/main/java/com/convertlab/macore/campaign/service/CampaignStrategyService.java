package com.convertlab.macore.campaign.service;


import cn.hutool.core.lang.Dict;
import cn.hutool.core.map.MapUtil;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.macore.campaign.common.utils.JacksonUtils;
import com.convertlab.macore.campaign.mapper.CampaignAudienceStrategyMapper;
import com.convertlab.macore.campaign.model.dto.CampaignDTO;
import com.convertlab.macore.campaign.model.entity.CampaignAudienceStrategy;
import org.springframework.stereotype.Service;

/**
 * load channel instance, template, and so on.
 */
@Service
public class CampaignStrategyService extends ServiceImpl<CampaignAudienceStrategyMapper, CampaignAudienceStrategy> {

    @DataSourceLookup("main")
    public CampaignAudienceStrategy saveOrUpdateStrategy(CampaignDTO dto, Long campaignId) {
        CampaignAudienceStrategy strategy = buildEntity(dto, campaignId);
        this.saveOrUpdate(strategy);
        return strategy;
    }

    @DataSourceLookup("main")
    public CampaignAudienceStrategy getStrategyByCampaignId(Long campaignId) {
        return this.lambdaQuery().eq(CampaignAudienceStrategy::getCampaignId, campaignId).last("limit 1").one();
    }

    @DataSourceLookup("main")
    public Long countByFilterId(Long filterId) {
        return this.lambdaQuery().eq(CampaignAudienceStrategy::getFilterId, filterId).count();
    }

    private CampaignAudienceStrategy buildEntity(CampaignDTO dto, Long campaignId) {
        return CampaignAudienceStrategy.builder()
                .id(dto.getStrategyId())
                .campaignId(campaignId)
                .strategyType("ma_ta_strategy")
                .segmentationType(dto.getAudienceStrategy().getSegmentationType())
                .profileType(dto.getAudienceStrategy().getProfileType())
                .filterId(dto.getAudienceStrategy().getFilterId())
                .controlGroupStrategy(dto.getControlGroupStrategy().getStrategy())
                .controlGroupPercentage(MapUtil.getStr(dto.getControlGroupStrategy().getData(), "percentage"))
                .strategyContent(JacksonUtils.toJSONString(Dict.create()
                        .set("audienceStrategy", dto.getAudienceStrategy())
                        .set("channelStrategy", dto.getChannelStrategy())
                        .set("timeStrategy", dto.getTimeStrategy())
                        .set("controlGroupStrategy", dto.getControlGroupStrategy())))
                .build();
    }
}
