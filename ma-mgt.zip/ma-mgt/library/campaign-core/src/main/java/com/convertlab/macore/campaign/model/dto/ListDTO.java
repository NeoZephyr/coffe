package com.convertlab.macore.campaign.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ListDTO {
    long id;
    String name;
    LocalDateTime lastUpdated;
}
