package com.convertlab.macore.campaign.service;

import com.convertlab.foundation.api.queryengine.GdmQuery;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.gdmmeta.model.FieldType;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.queryengine.client.QueryEngineClient;
import com.convertlab.foundation.library.sqlprocessor.ProcessingMode;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.campaign.common.utils.BeanCopyUtils;
import com.convertlab.macore.campaign.common.utils.DateTimeFormatterUtils;
import com.convertlab.macore.campaign.common.utils.NameUtils;
import com.convertlab.macore.campaign.mapper.CampaignAudienceStrategyMapper;
import com.convertlab.macore.campaign.mapper.CampaignBatchInfoMapper;
import com.convertlab.macore.campaign.mapper.CampaignChannelEventStageMapper;
import com.convertlab.macore.campaign.mapper.CampaignFilterMapper;
import com.convertlab.macore.campaign.mapper.CampaignListInfoMapper;
import com.convertlab.macore.campaign.mapper.CampaignOutboundEngageMapper;
import com.convertlab.macore.campaign.mapper.MarketingCampaignMapper;
import com.convertlab.macore.campaign.model.dto.CampaignChannelEventStageDto;
import com.convertlab.macore.campaign.model.dto.CampaignEngageBatchContext;
import com.convertlab.macore.campaign.model.dto.CampaignReportDataLineDto;
import com.convertlab.macore.campaign.model.dto.CampaignReportDataLineDto.GroupAggregateDim;
import com.convertlab.macore.campaign.model.dto.CampaignReportQuery;
import com.convertlab.macore.campaign.model.dto.CampaignReportQuery.CampaignReportQueryOptions;
import com.convertlab.macore.campaign.model.dto.CampaignReportQuery.ControlGroupType;
import com.convertlab.macore.campaign.model.dto.CampaignReportQuery.EngageDateUnit;
import com.convertlab.macore.campaign.model.dto.CampaignReportResultDto;
import com.convertlab.macore.campaign.model.dto.CampaignStatDataDTO;
import com.convertlab.macore.campaign.model.entity.CampaignAudienceStrategy;
import com.convertlab.macore.campaign.model.entity.CampaignBatchInfo;
import com.convertlab.macore.campaign.model.entity.CampaignChannelEventStage;
import com.convertlab.macore.campaign.model.entity.CampaignFilter;
import com.convertlab.macore.campaign.model.entity.CampaignListInfo;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.service.legacy.cms.client.CmsServiceClient;
import com.convertlab.macore.channel.model.dto.ChannelPluginVersionWithMessagingTypeDTO;
import com.convertlab.macore.channel.service.CompositeChannelPluginInstanceService;
import com.convertlab.macore.mamgt.common.utils.NamingUtils;
import com.google.common.collect.ImmutableMap;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

import static com.convertlab.foundation.library.constant.CommonErrors.VALIDATION_ERROR;
import static com.convertlab.macore.campaign.model.dto.CampaignReportDataLineDto.BATCH_ID_FIELD;
import static com.convertlab.macore.campaign.model.dto.CampaignReportDataLineDto.CAMPAIGN_CONTROL_FLAG_COLUMN;
import static com.convertlab.macore.campaign.model.dto.CampaignReportDataLineDto.CAMPAIGN_ID_COLUMN;
import static com.convertlab.macore.campaign.model.dto.CampaignReportDataLineDto.ENGAGE_CODE_COLUMN;
import static com.convertlab.macore.campaign.model.dto.CampaignReportDataLineDto.ENGAGE_CONTROL_FLAG_COLUMN;
import static com.convertlab.macore.campaign.model.dto.CampaignReportQuery.CAMPAIGN_CODE_DIM;
import static com.convertlab.macore.campaign.model.dto.CampaignReportQuery.CAMPAIGN_NAME_DIM;
import static com.convertlab.macore.campaign.model.dto.CampaignReportQuery.FILTER_NAME_DIM;
import static java.util.Collections.emptyList;
import static java.util.Collections.emptyMap;
import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.toCollection;

@Slf4j
@Service
@DataSourceLookup("main")
public class CampaignStatService {

    public static final String DISTINCT_KEYWORD = "DISTINCT";
    public static final String GROUP_DATE_COLUMN = "group_date";
    public static final String CONTROL_GROUP_COLUMN = "control_group";
    public static final String GROUP_TYPE_COLUMN = "group_type";
    public static final String BATCH_ID_COLUMN = "batch_id";
    public static final String TEMPLATE_ID_FIELD = "templateId";
    public static final String TEMPLATE_NAME_FIELD = "templateName";
    public static final String TEMPLATE_NAME_COLUMN = "template_name";
    public static final String CHANNEL_TYPE_FIELD = "channelType";
    public static final String CHANNEL_TYPE_COLUMN = "channel_type";
    public static final String ENGAGE_CODE_FIELD = "engageCode";
    public static final String CAMPAIGN_ID_FIELD = "campaignId";
    public static final String CAMPAIGN_NAME_FIELD = "campaignName";
    public static final String CAMPAIGN_CODE_FIELD = "campaignCode";
    public static final String ENGAGE_ID_FIELD = "engageId";
    public static final String DATE_UNIT_PARAM_KEY = "dateUnit";
    public static final String GROUP_COUNT_FIELD = "groupCount";
    public static final String FILTER_NAME_FIELD = "filterName";
    public static final String FILTER_NAME_COLUMN = "filter_name";
    public static final String CONTROL_GROUP_TYPE_FIELD = "groupType";
    public static final String FILTER_ID_FIELD = "filterId";
    public static final String CAMPAIGN_FILTERED_FLAG_COLUMN = "campaign_filtered_flag";
    public static final String CAMPAIGN_FILTERED_FLAG_COLUMN_ALIAS = "campaign_filtered_flag0";
    public static final Integer zero = 0;
    public static final Integer one = 1;
    public static final Integer negOne = -1;
    public static final String CAMPAIGN_NAME_COLUMN = "title";
    public static final String CAMPAIGN_CODE_COLUMN = "uuid";

    QueryEngineClient queryEngineClient;
    CmsServiceClient cmsServiceClient;

    CampaignMetaService campaignMetaService;
    CampaignStrategyService campaignStrategyService;
    CompositeChannelPluginInstanceService compositeChannelPluginInstanceService;

    CampaignBatchInfoMapper campaignBatchInfoMapper;

    CampaignListInfoMapper campaignListInfoMapper;

    MarketingCampaignMapper marketingCampaignMapper;

    CampaignOutboundEngageMapper campaignOutboundEngageMapper;

    CampaignChannelEventStageMapper campaignChannelEventStageMapper;

    CampaignAudienceStrategyMapper campaignAudienceStrategyMapper;

    CampaignFilterMapper campaignFilterMapper;



    public CampaignStatService(QueryEngineClient queryEngineClient,
                               CmsServiceClient cmsServiceClient,
                               CampaignMetaService campaignMetaService,
                               CampaignStrategyService campaignStrategyService,
                               CompositeChannelPluginInstanceService compositeChannelPluginInstanceService,
                               MarketingCampaignMapper marketingCampaignMapper,
                               CampaignListInfoMapper campaignListInfoMapper,
                               CampaignBatchInfoMapper campaignBatchInfoMapper,
                               CampaignOutboundEngageMapper campaignOutboundEngageMapper,
                               CampaignChannelEventStageMapper campaignChannelEventStageMapper,
                               CampaignAudienceStrategyMapper campaignAudienceStrategyMapper,
                               CampaignFilterMapper campaignFilterMapper) {
        this.queryEngineClient = queryEngineClient;
        this.cmsServiceClient = cmsServiceClient;
        this.campaignMetaService = campaignMetaService;
        this.campaignStrategyService = campaignStrategyService;
        this.compositeChannelPluginInstanceService = compositeChannelPluginInstanceService;
        this.marketingCampaignMapper = marketingCampaignMapper;
        this.campaignBatchInfoMapper = campaignBatchInfoMapper;
        this.campaignListInfoMapper = campaignListInfoMapper;
        this.campaignOutboundEngageMapper = campaignOutboundEngageMapper;
        this.campaignChannelEventStageMapper = campaignChannelEventStageMapper;
        this.campaignAudienceStrategyMapper = campaignAudienceStrategyMapper;
        this.campaignFilterMapper = campaignFilterMapper;
    }

    /**
     * 查询营销活动的总体统计数据， 包括人数和人次（通过is_unique字段判断）
     * <p>
     * 其中，营销活动的总体统计数据有：
     * <li>
     *     <ol>营销活动总人群人数</ol>
     *     <ol>过滤器拦截掉的人数</ol>
     *     <ol>进入对照组的人数</ol>
     * </li>
     * <p>
     * 按渠道区分的触达统计数据有：
     * <li>
     *     <ol>不满足发送条件或者发送失败的人数</ol>
     *     <ol>发送的人数</ol>
     *     <ol>触达的人数</ol>
     *     <ol>打开的人数</ol>
     *     <ol>点击的人数</ol>
     * </li>
     * <p>
     * 输入的参数有:
     *
     * @param campaignId 营销活动id
     * @param isUnique   人数还是人次统计
     */
    public CampaignStatDataDTO getCampaignStatData(Long campaignId, Long engageId, String messagingType,
                                                   LocalDateTime startTime, LocalDateTime endTime, boolean isUnique,
                                                   CampaignEngageBatchContext campaignEngageBatchContext) {

        List<CampaignEngageBatchContext.CampaignEngageBatchDim> eventBatchDimList = campaignEngageBatchContext.getEngageBatchDimList();

        //如果messagingType为空，则返回所有messagingType；否则只筛选messagingType相同的batchId
        Predicate<CampaignEngageBatchContext.CampaignEngageBatchDim> usedBatchInfoPredicate = batchInfo -> StringUtils.isBlank(messagingType) || batchInfo.getMessagingType().equals(messagingType);
        List<String> usedBatchIds = eventBatchDimList.stream()
                .filter(usedBatchInfoPredicate)
                .map(CampaignEngageBatchContext.CampaignEngageBatchDim::getBatchId).collect(Collectors.toList());

        //<batch_id, event_id, cnt>
        // 没有转化到 NamingUtils 中定义的名称，比如 event_id 还是 send_sms 而不是 sent
        List<Map<String, Object>> batchEventRawStats = usedBatchIds.isEmpty() ? emptyList() :
                getCampaignEventRawStatData(usedBatchIds, startTime, endTime, isUnique);

        //<campaign_filtered_flag , campaign_control_flag, engage_id, engage_filtered_flag , engage_control_flag>
        List<Map<String, Object>> engageGroupRawStats = getCampaignGroupRawStat(isUnique, campaignId, startTime, endTime);

        Map<Long, CampaignOutboundEngage> engageMap = getEnagegeMap(campaignId);
        Map<String, String> eventStageMap = getEventStageMap();
        return composeToStatData(campaignId, eventBatchDimList, engageGroupRawStats, batchEventRawStats, engageMap, eventStageMap);
    }

    public Map<Long, CampaignOutboundEngage> getEnagegeMap(Long campaignId) {
        List<CampaignOutboundEngage> engageList = campaignOutboundEngageMapper.getEngageListByCampaignId(campaignId);
        return engageList.stream().collect(Collectors.toMap(CampaignOutboundEngage::getId, e -> e));
    }

    public Map<Long, Map<String, Object>> getEnagegeInfoMap(Long campaignId) {
        List<CampaignOutboundEngage> engageList = campaignOutboundEngageMapper.getEngageListByCampaignId(campaignId);
        Map<Long, Map<String, String>> engageAttributeData = campaignMetaService.getEngageAttributeData(campaignId);
        return getEngageInfoMap(engageList, engageAttributeData);
    }

    public Map<Long, Map<String, Object>> getEnagegeInfoMap(List<Long> campaignIds) {
        List<CampaignOutboundEngage> engageList = campaignOutboundEngageMapper.getEngageListByBatchCampaignIds(campaignIds);
        Map<Long, Map<String, String>> engageAttributeData = campaignMetaService.getEngageAttributeData(campaignIds);
        return getEngageInfoMap(engageList, engageAttributeData);
    }

    public Map<Long, Map<String, Object>> getFilterInfoMap(List<Long> campaignIds) {
        Map<Long, Map<String, Object>> result = new HashMap<>();
        for (Long campaignId: campaignIds) {
            result.put(campaignId, new HashMap<>());
        }

        List<CampaignAudienceStrategy> campaignAudienceStrategies = campaignAudienceStrategyMapper.selectByBatchCampaignIds(campaignIds);
        Map<Long, Long> campaignFilterMapping = campaignAudienceStrategies.stream()
                .filter(strategy -> strategy.getFilterId() != null)
                .collect(Collectors.toMap(CampaignAudienceStrategy::getCampaignId, CampaignAudienceStrategy::getFilterId));

        if (campaignFilterMapping.isEmpty()) {
            return result;
        }

        Set<Long> filterIds = new HashSet<>(campaignFilterMapping.values());
        List<CampaignFilter> campaignFilters = campaignFilterMapper.selectBatchIds(filterIds);

        Map<Long, CampaignFilter> filterMap = campaignFilters.stream().collect(Collectors.toMap(CampaignFilter::getId, filter -> filter));

        campaignFilterMapping.forEach ((campaignId, filterId) -> {
            if (filterMap.containsKey(filterId)) {
                CampaignFilter filter = filterMap.get(filterId);
                String filterName = filter.getFilterName();
                Map<String, Object> filterInfo = new HashMap<>();
                filterInfo.put(FILTER_ID_FIELD, filterId);
                filterInfo.put(FILTER_NAME_FIELD, filterName);
                result.get(campaignId).putAll(filterInfo);
            }
        });
        return result;
    }
    private static Map<Long, Map<String, Object>> getEngageInfoMap(List<CampaignOutboundEngage> engageList, Map<Long, Map<String, String>> engageAttributeData) {
        Map<Long, Map<String, Object>> result = new HashMap<>();
        for(CampaignOutboundEngage engage: engageList) {
            Long engageId = engage.getId();
            HashMap<String, Object> engageInfo = new HashMap<>();
            engageInfo.put(ENGAGE_CODE_FIELD, engage.getCode());
            if (engageAttributeData.containsKey(engageId)) {
                Map<String, String> engageAttributes = engageAttributeData.get(engageId);
                engageInfo.putAll(engageAttributes);
            }
            result.put(engageId, engageInfo);
        }
        return result;
    }

    public Map<Long, MarketingCampaign> getCampaignMap(List<Long> campaignIds) {
        List<MarketingCampaign> marketingCampaigns = marketingCampaignMapper.selectBatchIds(campaignIds);
        return marketingCampaigns.stream().collect(Collectors.toMap(MarketingCampaign::getId, e -> e));
    }

    public Map<Long, CampaignAudienceStrategy> getCampaignAudienceStrategyMap(List<Long> campaignIds) {
        List<CampaignAudienceStrategy> campaignAudienceStrategies = campaignAudienceStrategyMapper.selectByBatchCampaignIds(campaignIds);
        return campaignAudienceStrategies.stream().collect(Collectors.toMap(CampaignAudienceStrategy::getCampaignId, e -> e));
    }

    public CampaignEngageBatchContext initCampaignStatDimData(Long campaignId, Long engageId) {
        final MarketingCampaign campaign;
        final CampaignAudienceStrategy campaignAudienceStrategy;
        final Map<Long, CampaignAudienceStrategy> campaignAudienceStrategyMap;
        final Map<Long, Map<String, Object>> campaignInfoMap;
        final Map<Long, Map<String, Object>> engageInfoMap;
        List<CampaignListInfo> campaignListInfos = null;
        List<CampaignEngageBatchContext.CampaignEngageBatchDim> eventBatchDimList = null;

        try {
            //MarketingCampaign 的定义
            campaign = marketingCampaignMapper.selectById(campaignId);
            campaignAudienceStrategy = campaignStrategyService.getStrategyByCampaignId(campaignId);
            Assert.notNull(campaign, "campaign is null, the campaignId: " + campaignId);
            Assert.notNull(campaignAudienceStrategy, "campaign audience strategy is null, the campaignId: " + campaignId);
            campaignInfoMap = campaignMetaService.getCampaignInfoMap(ImmutableMap.of(campaignId, campaign.getUuid()));
            campaignAudienceStrategyMap = ImmutableMap.of(campaignId, campaignAudienceStrategy);

            //Campaign的group数据，batch 数据
            engageInfoMap = getEnagegeInfoMap(campaignId);
            List<CampaignBatchInfo> batchInfoList = engageId == null ?
                    campaignBatchInfoMapper.selectByCampaignId(campaignId)
                    : campaignBatchInfoMapper.selectByCampaignIdAndEngageId(campaignId, engageId);
            campaignListInfos = campaignListInfoMapper.selectByCampaignId(campaignId);

            //维度 DTO
            eventBatchDimList = batchInfoList.stream()
                    .map(batchInfo -> {
                        Map<String, Object> engageInfo = engageInfoMap.get(batchInfo.getEngageId());
                        Assert.notNull(engageInfo, "engageInfo is null, the engageId: " + batchInfo.getEngageId());
                        String engageCode = (String) engageInfo.get(ENGAGE_CODE_FIELD);

                        return CampaignEngageBatchContext.CampaignEngageBatchDim.builder().campaignId(batchInfo.getCampaignId())
                                .campaignName(campaign.getTitle()).campaignCode(campaign.getUuid())
                                .engageId(batchInfo.getEngageId())
                                .engageCode(engageCode).engageName(engageCode) //engageInfo 没有 name
                                .flowId(batchInfo.getFlowId()).batchId(batchInfo.getBatchId())
                                .channelType(batchInfo.getChannelType())
                                .messagingType(batchInfo.getMessagingType())
                                .templateName(batchInfo.getTemplateName())
                                .templateId(batchInfo.getTemplateId()).build() ;
                    }).collect(Collectors.toList());
        } catch (Exception e) {
            throw new IllegalStateException("failed to init CampaignEngageBatchContext with exception: ", e);
        }
        return new CampaignEngageBatchContext(eventBatchDimList, campaignInfoMap, engageInfoMap,
                ImmutableMap.of(campaignId, campaignListInfos), emptyMap(), campaignAudienceStrategyMap);
    }


    private List<Map<String, Object>> getCampaignGroupRawStat(boolean isUnique, Long campaignId, LocalDateTime startTime, LocalDateTime endTime) {
        String profileCount = isUnique ? DISTINCT_KEYWORD : "";
        String startTimeCondition = (startTime != null) ? "and group_date >= ? " : "" ;
        String endTimeCondition = (endTime != null) ? "and group_date < ? " : "" ;
        String groupFactsStat = String.format(
                "select campaign_filtered_flag , campaign_control_flag, engage_id, engage_filtered_flag , engage_control_flag, count(%s profile_id) as cnt " +
                        "from campaign_group_facts " +
                        "where campaign_id = ? %s %s" +
                        "group by campaign_filtered_flag , campaign_control_flag, engage_id, engage_filtered_flag, engage_control_flag",
                profileCount, startTimeCondition, endTimeCondition );
        List<GdmQuery.Arg> args = new ArrayList<>();
        args.add(new GdmQuery.Arg(campaignId, FieldType.Long));
        if (startTime != null) {
            String startTimeString = startTime.atZone(ZoneId.of("UTC")).format(DateTimeFormatterUtils.simpleFormat());
            args.add(new GdmQuery.Arg(startTimeString, FieldType.DateTime));
        }
        if(endTime != null) {
            String endTimeString = endTime.atZone(ZoneId.of("UTC")).format(DateTimeFormatterUtils.simpleFormat());
            args.add(new GdmQuery.Arg(endTimeString, FieldType.DateTime));
        }
        GdmQuery.Request request = new GdmQuery.Request(groupFactsStat, args, null, false, ProcessingMode.OLAP.toString());
        GdmQuery.Response response = queryEngineClient.queryEngineQuery(request);
        return response.getRows();
    }

    /**
     *
     *
     *
     */
    public List<Map<String, Object>> getCampaignGroupRawStat(boolean isDistinct, List<Long> campaignIds, CampaignReportQueryOptions queryOptions) {

        String profileCount = isDistinct ? DISTINCT_KEYWORD : "";
        String campaignIdCondition = campaignIds.stream().map(cid -> "?").collect(Collectors.joining(","));
        String dateField = GROUP_DATE_COLUMN;
        EngageDateUnit dateUnit = queryOptions.getEngageDateUnit();

        String groupDateAlias = dateUnit == EngageDateUnit.NOT_SET ? "" : GROUP_DATE_COLUMN;
        String dateUnitColumn = dateUnit == EngageDateUnit.NOT_SET ? ""
                : getDateUnitColumn(dateUnit, dateField, dateField) + ", ";
        String tailingGroupClause = dateUnit == EngageDateUnit.NOT_SET ? "engage_filtered_flag, engage_control_flag"
                : groupDateAlias + " , engage_filtered_flag, engage_control_flag";

        String groupStatSql = String.format(
                "select campaign_id, campaign_filtered_flag , campaign_control_flag, engage_id, %s  engage_filtered_flag , engage_control_flag, count(%s profile_id) as cnt " +
                        "from campaign_group_facts " +
                        "where campaign_id in (%s) " +
                        "group by campaign_id, campaign_filtered_flag , campaign_control_flag, engage_id, %s",
                dateUnitColumn, profileCount, campaignIdCondition, tailingGroupClause);

        log.info("getCampaignGroupRawStat sql: {}, with args: {}", groupStatSql, campaignIds);
        List<GdmQuery.Arg> args = new ArrayList<>();
        for (Long campaignId : campaignIds) {
            args.add(new GdmQuery.Arg(campaignId, FieldType.Long));
        }
        GdmQuery.Request request = new GdmQuery.Request(groupStatSql, args, null, false, ProcessingMode.OLAP.toString());
        GdmQuery.Response response = queryEngineClient.queryEngineQuery(request);
        return response.getRows();
    }

    static String getDateUnitColumn(EngageDateUnit engageDateUnit, String fieldDate, String fieldDateGroupAlias) {
        String tw = "";
        if (engageDateUnit == EngageDateUnit.NOT_SET) {
            return tw;
        }

        String tt = "trunc(FROM_UTC_TIMESTAMP(%s,'Asia/Shanghai'), '%s') as %s";
        switch (engageDateUnit) {
            case YEAR_DAY:
            case YEAR_WEEK:
            case YEAR_MONTH:
            case YEAR_QUARTER:
            case YEAR:
                tw = String.format(tt, fieldDate, engageDateUnit.getImpalaUnit(), fieldDateGroupAlias);
                break;
            default:
                throw new IllegalStateException("engageDateUnit is not set: " + engageDateUnit);
        }
        return tw;
    }

    /**
     * TODO 在customer_event 中正确的保存了 campaign 之后， 这里可能就要改为使用 campaign_code
     */
    public List<Map<String, Object>> getCampaignEventRawStat(List<String> batchIds, boolean isUnique, CampaignReportQueryOptions queryOptions) {
        if (batchIds.isEmpty()) {
            return emptyList();
        }
        EngageDateUnit dateUnit = queryOptions.getEngageDateUnit();

        String groupDateAlias = dateUnit == EngageDateUnit.NOT_SET ? "" : GROUP_DATE_COLUMN;
        String dateUnitColumn = dateUnit == EngageDateUnit.NOT_SET ? ""
                : getDateUnitColumn(dateUnit, "ce.field_date", groupDateAlias) + ", ";
        String groupClause = dateUnit == EngageDateUnit.NOT_SET ? "ce.batch_id, ce.event" : groupDateAlias + ", ce.batch_id, ce.event";

        String profileCount = isUnique ? DISTINCT_KEYWORD : "";
        String eventEntity = "customer_event";
        String batchIdCondition = batchIds.stream().map(batchId -> "?").collect(Collectors.joining(","));


        String eventFactsStatSql = String.format(
                "select %s ce.batch_id as batch_id, ce.event, count(%s customer_id) as cnt " +
                        "from %s ce " +
                        "where ce.batch_id in (%s) " +
                        "group by %s",
                dateUnitColumn, profileCount, eventEntity, batchIdCondition, groupClause);

        List<GdmQuery.Arg> args = new ArrayList<>();
        batchIds.forEach(batchId -> args.add(new GdmQuery.Arg(batchId, FieldType.String)));

        log.info("getCampaignEventRawStat sql: {}, with args: {}", eventFactsStatSql, batchIds);

        GdmQuery.Request request = new GdmQuery.Request(eventFactsStatSql, args, null, false, ProcessingMode.OLAP.toString());
        GdmQuery.Response response = queryEngineClient.queryEngineQuery(request);
        return response.getRows();

    }

    public List<Map<String, Object>> getCampaignEventRawStatData(List<String> batchIds, LocalDateTime startTime, LocalDateTime endTime, boolean isUnique) {


        String profileCount = isUnique ? DISTINCT_KEYWORD : "";
        String eventEntity = "customer_event";
        String batchIdCondition = batchIds.stream().map(batchId -> "?").collect(Collectors.joining(","));
        String startTimeCondition = (startTime != null) ? "and ce.field_date >= ? " : "";
        String endTimeCondition = (endTime != null) ? "and ce.field_date < ? " : "";

        String eventFactsStatSql = String.format(
                "select ce.batch_id, ce.event, count(%s customer_id) as cnt " +
                        "from %s ce " +
                        "where ce.batch_id in (%s) %s %s" +
                        "group by ce.batch_id, ce.event",
                profileCount, eventEntity, batchIdCondition, startTimeCondition, endTimeCondition);

        List<GdmQuery.Arg> args = new ArrayList<>();
        batchIds.forEach(batchId -> args.add(new GdmQuery.Arg(batchId, FieldType.String)));
        if (startTime != null) {
            String startTimeString = startTime.atZone(ZoneId.of("UTC")).format(DateTimeFormatterUtils.simpleFormat());
            args.add(new GdmQuery.Arg(startTimeString, FieldType.DateTime));
        }
        if (endTime != null) {
            String endTimeString = endTime.atZone(ZoneId.of("UTC")).format(DateTimeFormatterUtils.simpleFormat());
            args.add(new GdmQuery.Arg(endTimeString, FieldType.DateTime));
        }

        GdmQuery.Request request = new GdmQuery.Request(eventFactsStatSql, args, null, false, ProcessingMode.OLAP.toString());
        GdmQuery.Response response = queryEngineClient.queryEngineQuery(request);
        return response.getRows();
    }

    protected CampaignStatDataDTO composeToStatData(Long campaignId,
                                                    List<CampaignEngageBatchContext.CampaignEngageBatchDim> eventBatchDimList,
                                                    List<Map<String, Object>> campaignAndEngageGroupStat,
                                                    List<Map<String, Object>> batchEventRawStats,
                                                    Map<Long, CampaignOutboundEngage> engageMap,
                                                    Map<String, String> eventStageMap) {


        CampaignStatDataDTO result = new CampaignStatDataDTO();
        result.setCampaignId(campaignId);

        ControlGroupType controlGroupType = getControlGroupType(campaignId);
        result.setControlGroupType(controlGroupType);

        /**
         *  <batchId, eventStageName(sent|failed_to_send), count>
         */
        List<CampaignStatDataDTO.BatchEventStageStat> batchEventStageStatList = new ArrayList<>();

        /**
         * campaign level 的 group_stage_name, 和 count
         */
        List<CampaignStatDataDTO.CampaignGroupStageStat> campaignGroupStatList = new ArrayList<>();

        /**
         * engage level 的 engage_code, group_stage_name, 和 count
         *
         */
        List<CampaignStatDataDTO.EngageGroupStageStat> engageGroupStatList = new ArrayList<>();


        int campaignMainCount = 0;
        int campaignExcludedCount = 0;
        int campaignFilteredCount = 0;
        int campaignControlCount = 0;
        int campaignTargetCount = 0;

        int sentCount = 0;
        int failedToSendCount = 0;
        int deliveredCount = 0;
        int failedToDeliveredCount = 0;
        int openedCount = 0;
        int clickedCount = 0;

        Map<Long, Map<String, Integer>> engageGroupStats = new HashMap<>();
        for (Map<String, Object> groupFactRow : campaignAndEngageGroupStat) {
            boolean isCampaignExcluded = groupFactRow.get(CAMPAIGN_FILTERED_FLAG_COLUMN).equals(0);
            boolean isCampaignFiltered = groupFactRow.get(CAMPAIGN_FILTERED_FLAG_COLUMN).equals(1);
            boolean isCampaignInControl = groupFactRow.get("campaign_control_flag").equals(1);
            boolean isCampaignInTarget = groupFactRow.get("campaign_control_flag").equals(0);
            boolean isEngageInExcluded = groupFactRow.get("engage_filtered_flag").equals(0);
            boolean isEngageInFiltered = groupFactRow.get("engage_filtered_flag").equals(1);
            boolean isEngageInTarget = groupFactRow.get("engage_control_flag").equals(0);
            boolean isEngageInControl = groupFactRow.get("engage_control_flag").equals(1);
            Integer groupCnt = Integer.valueOf((String) groupFactRow.get("cnt"));

            campaignMainCount += groupCnt;
            if (isCampaignExcluded) {
                campaignExcludedCount += groupCnt;
            }
            if (isCampaignFiltered) {
                campaignFilteredCount += groupCnt;
            }
            if (isCampaignInControl) {
                campaignControlCount += groupCnt;
            }
            if (isCampaignInTarget) {
                campaignTargetCount += groupCnt;
            }

            Long engageId = (groupFactRow.get("engage_id") != null) ? Long.valueOf((String) groupFactRow.get("engage_id")) : null;
            if (engageId != null) {
                if (!engageGroupStats.containsKey(engageId)) {
                    HashMap<String, Integer> engageGroupStat = new HashMap<>();
                    engageGroupStat.put(NameUtils.EXCLUDED_GROUP, 0);
                    engageGroupStat.put(NameUtils.FILTERED_GROUP, 0);
                    engageGroupStat.put(NameUtils.TARGET_GROUP, 0);
                    engageGroupStat.put(NameUtils.CONTROL_GROUP, 0);
                    engageGroupStats.put(engageId, engageGroupStat);
                }
                Map<String, Integer> engageStats = engageGroupStats.get(engageId);

                if (isEngageInExcluded) {
                    engageStats.put(NameUtils.EXCLUDED_GROUP, engageStats.getOrDefault(NameUtils.EXCLUDED_GROUP, 0) + groupCnt);
                } else if (isEngageInFiltered) {
                    engageStats.put(NameUtils.FILTERED_GROUP, engageStats.getOrDefault(NameUtils.FILTERED_GROUP, 0) + groupCnt);
                }
                if (isEngageInTarget) {
                    engageStats.put(NameUtils.TARGET_GROUP, engageStats.getOrDefault(NameUtils.TARGET_GROUP, 0) + groupCnt);
                } else if (isEngageInControl) {
                    engageStats.put(NameUtils.CONTROL_GROUP, engageStats.getOrDefault(NameUtils.CONTROL_GROUP, 0) + groupCnt);
                }
            }
        }
        engageGroupStats.forEach((engageId, engageGroupStat) -> {
            if (engageId == null || engageId == 0L || engageId == -1L) {
                return;
            }
            CampaignOutboundEngage engage = engageMap.get(engageId);
            engageGroupStat.forEach((stageGroup, count) -> {
                engageGroupStatList.add(new CampaignStatDataDTO.EngageGroupStageStat(
                        engage.getCode(), stageGroup, count));
            });
        });
        result.setEngageGroupStageStatList(engageGroupStatList);

        log.info("campaign engage group statData: {}", engageGroupStats);

        Map<String, Map<String, Integer>> batchEventStats = new HashMap<>();
        eventBatchDimList.forEach(batchInfo -> {
            String batchId = batchInfo.getBatchId();
            if (!batchEventStats.containsKey(batchId)) {
                Map<String, Integer> batchEventStat = new HashMap<>();
                batchEventStat.put(NameUtils.SENT_EVENT, 0);
                batchEventStat.put(NameUtils.FAILED_TO_SEND_EVENT, 0);
                batchEventStat.put(NameUtils.DELIVERED_EVENT, 0);
                batchEventStat.put(NameUtils.FAILED_TO_DELIVERED_EVENT, 0);
                batchEventStat.put(NameUtils.RECEIVED_EVENT, 0);
                batchEventStat.put(NameUtils.OPENED_EVENT, 0);
                batchEventStat.put(NameUtils.CLICKED_EVENT, 0);
                batchEventStats.put(batchId, batchEventStat);
            }
        });

        for (Map<String, Object> row : batchEventRawStats) {
            String event = (String) row.get("event");
            String eventStage = eventStageMap.get(event);
            if (eventStage == null) {
                log.warn("eventStage does not exist for event: {}", event);
                continue;
            }

            int eventCnt = Integer.parseInt((String) row.get("cnt"));

            String batchId = (String) row.get(BATCH_ID_COLUMN);
            Map<String, Integer> batchStat = batchEventStats.get(batchId);
            batchStat.put(eventStage, batchStat.get(eventStage) + eventCnt);

            switch (eventStage) {
                case NameUtils.SENT_EVENT:
                    sentCount += eventCnt;
                    break;
                case NameUtils.FAILED_TO_SEND_EVENT:
                    failedToSendCount += eventCnt;
                    break;
                case NameUtils.DELIVERED_EVENT:
                    deliveredCount += eventCnt;
                    break;
                case NameUtils.FAILED_TO_DELIVERED_EVENT:
                    failedToDeliveredCount += eventCnt;
                    break;
                case NameUtils.OPENED_EVENT:
                    openedCount += eventCnt;
                    break;
                case NameUtils.CLICKED_EVENT:
                    clickedCount += eventCnt;
                    break;
                default:
                    log.error("unknown event stage: {}, count: {}", eventStage, eventCnt);
            }
        }
        log.info("batch event statData: {}", batchEventStats);

        batchEventStats.forEach((batchId, batchEvent) -> {
            batchEventStageStatList.add(new CampaignStatDataDTO.BatchEventStageStat(batchId, NameUtils.SENT_EVENT, batchEvent.get(NameUtils.SENT_EVENT)));
            batchEventStageStatList.add(new CampaignStatDataDTO.BatchEventStageStat(batchId, NameUtils.FAILED_TO_SEND_EVENT, batchEvent.get(NameUtils.FAILED_TO_SEND_EVENT)));
        });
        result.setBatchEventStageStats(batchEventStageStatList);

        campaignGroupStatList.add(new CampaignStatDataDTO.CampaignGroupStageStat(NameUtils.MAIN_GROUP, campaignMainCount));
        campaignGroupStatList.add(new CampaignStatDataDTO.CampaignGroupStageStat(NameUtils.FILTERED_GROUP, campaignFilteredCount));
        campaignGroupStatList.add(new CampaignStatDataDTO.CampaignGroupStageStat(NameUtils.FAILED_TO_SEND_OR_DELIVER, failedToSendCount + failedToDeliveredCount));
        campaignGroupStatList.add(new CampaignStatDataDTO.CampaignGroupStageStat(NameUtils.EXCLUDED_GROUP, campaignExcludedCount));
        campaignGroupStatList.add(new CampaignStatDataDTO.CampaignGroupStageStat(NameUtils.CONTROL_GROUP, campaignControlCount));
        campaignGroupStatList.add(new CampaignStatDataDTO.CampaignGroupStageStat(NameUtils.TARGET_GROUP, campaignTargetCount));
        campaignGroupStatList.add(new CampaignStatDataDTO.CampaignGroupStageStat(NameUtils.SENT_EVENT, sentCount));
        campaignGroupStatList.add(new CampaignStatDataDTO.CampaignGroupStageStat(NameUtils.DELIVERED_EVENT, deliveredCount));
        campaignGroupStatList.add(new CampaignStatDataDTO.CampaignGroupStageStat(NameUtils.OPENED_EVENT, openedCount));
        campaignGroupStatList.add(new CampaignStatDataDTO.CampaignGroupStageStat(NameUtils.CLICKED_EVENT, clickedCount));
        result.setCampaignGroupStageStatList(campaignGroupStatList);
        return result;
    }

    public void upsertChannelEventStage(CampaignChannelEventStageDto eventStageDto) {

        List<CampaignChannelEventStage> currEventStages = campaignChannelEventStageMapper.selectAll();
        //需要过滤掉当前提交的messagingType已经使用的eventId
        Set<String> currentEventIds = currEventStages.stream()
                .filter(currEventStage -> !currEventStage.getMessagingType().equals(eventStageDto.getMessagingType()))
                .flatMap(CampaignChannelEventStage::getEventIdStream).collect(Collectors.toSet());

        List<String> duplicatedInputEventIds = CampaignChannelEventStage.newInstance(eventStageDto).getEventIdStream()
                .filter(currentEventIds::contains)
                .collect(Collectors.toList());
        if (!duplicatedInputEventIds.isEmpty()) {
            String eventIds = String.join(",", duplicatedInputEventIds);
            throw new BusinessException(VALIDATION_ERROR, "MSG_108_000033", "found used event ids: " + eventIds, new String[]{eventIds});
        }

        //如果存在则更新
        CampaignChannelEventStage existedEventStage = currEventStages.stream()
                .filter(currEventStage -> currEventStage.getMessagingType().equals(eventStageDto.getMessagingType()))
                .findFirst().orElse(null);

        if (existedEventStage != null) {
            Map<String, String> props = eventStageDto.getUpdateFieldValueMap();
            campaignChannelEventStageMapper.updateById(existedEventStage.getId(), props);
        } else {
            CampaignChannelEventStage eventStage = CampaignChannelEventStage.newInstance(eventStageDto);
            campaignChannelEventStageMapper.insert(eventStage);
        }

        log.info("{} channel event stage: {}", (existedEventStage != null) ? "update" : "create", eventStageDto);
    }

    public List<CampaignChannelEventStageDto> getChannelEventStageList() {
        List<CampaignChannelEventStageDto> result = new ArrayList<>();
        List<ChannelPluginVersionWithMessagingTypeDTO> messagingTypeList = compositeChannelPluginInstanceService.getPluginVersionWithMessagingTypeList();
        List<CampaignChannelEventStage> tenantDefChannelEventStages = campaignChannelEventStageMapper.selectAll();
        Map<String, CampaignChannelEventStageDto> systemMessagingTypeEventMap = systemMessagingTypeEventMap();

        Map<String, CampaignChannelEventStage> tenantDefChannelEventStageMap = tenantDefChannelEventStages.stream().collect(Collectors.toMap(CampaignChannelEventStage::getMessagingType, Function.identity()));

        //如果租户有定义，就使用租户的定义，而不是系统默认的
        for (ChannelPluginVersionWithMessagingTypeDTO messagingTypeDto : messagingTypeList) {
            String messagingTypeCode = messagingTypeDto.getCode();
            String availabilityLevel = messagingTypeDto.getAvailabilityLevel();
            String channelType = messagingTypeDto.getChannelType();
            String desc = messagingTypeDto.getDesc();
            Long pluginId = messagingTypeDto.getPluginId();
            Long pluginVersionId = messagingTypeDto.getPluginVersionId();
            boolean isSystemMessagingType = "system".equals(availabilityLevel);

            //对于系统的 消息类型，并不是所有的 messagingTypeDto 都是营销活动渠道指标需要的，不需要的就跳过
            if (isSystemMessagingType && !systemMessagingTypeEventMap.containsKey(messagingTypeCode)) {
                log.info("skip system messaging type: {}", messagingTypeCode);
                continue;
            }

            //租户有定义，则使用租户定义
            if (tenantDefChannelEventStageMap.containsKey(messagingTypeCode)) {
                CampaignChannelEventStage eventStage = tenantDefChannelEventStageMap.get(messagingTypeCode);
                CampaignChannelEventStageDto campaignChannelEventStageDto = CampaignChannelEventStageDto.builder()
                        .messagingType(eventStage.getMessagingType())
                        .messagingName(desc)
                        .channelType(eventStage.getChannelType())
                        .pluginId(pluginId)
                        .pluginVersionId(pluginVersionId)
                        .isSystem(isSystemMessagingType)
                        .sentEventId(eventStage.getSentEventId())
                        .failedToSendEventId(eventStage.getFailedToSendEventId())
                        .failedToSendField(eventStage.getFailedToSendField())
                        .deliveredEventId(eventStage.getDeliveredEventId())
                        .failedToDeliveredEventId(eventStage.getFailedToDeliveredEventId())
                        .failedToDeliveredField(eventStage.getFailedToDeliveredField())
                        .receivedEventId(eventStage.getReceivedEventId())
                        .openedEventId(eventStage.getOpenedEventId())
                        .clickedEventId(eventStage.getClickedEventId())
                        .build();
                result.add(campaignChannelEventStageDto);
            } else if (isSystemMessagingType) { //如果是系统类型，且租户没有定义，则使用系统默认的
                CampaignChannelEventStageDto eventStageDto = systemMessagingTypeEventMap.get(messagingTypeCode);
                CampaignChannelEventStageDto defaultSystemEventStageDto = CampaignChannelEventStageDto.builder()
                        .messagingType(messagingTypeCode)
                        .messagingName(desc)
                        .channelType(channelType)
                        .pluginId(pluginId)
                        .pluginVersionId(pluginVersionId)
                        .isSystem(isSystemMessagingType)
                        .sentEventId(eventStageDto.getSentEventId())
                        .failedToSendEventId(eventStageDto.getFailedToSendEventId())
                        .failedToSendField(eventStageDto.getFailedToSendField())
                        .deliveredEventId(eventStageDto.getDeliveredEventId())
                        .failedToDeliveredEventId(eventStageDto.getFailedToDeliveredEventId())
                        .failedToDeliveredField(eventStageDto.getFailedToDeliveredField())
                        .receivedEventId(eventStageDto.getReceivedEventId())
                        .openedEventId(eventStageDto.getOpenedEventId())
                        .clickedEventId(eventStageDto.getClickedEventId())
                        .build();
                result.add(defaultSystemEventStageDto);
            } else {
                CampaignChannelEventStageDto dtoWithEmptyStages = CampaignChannelEventStageDto.builder()
                        .messagingType(messagingTypeCode)
                        .messagingName(desc)
                        .channelType(channelType)
                        .pluginId(pluginId)
                        .pluginVersionId(pluginVersionId)
                        .isSystem(isSystemMessagingType)
                        .sentEventId(null)
                        .failedToSendEventId(null)
                        .failedToSendField(null)
                        .deliveredEventId(null)
                        .failedToDeliveredEventId(null)
                        .failedToDeliveredField(null)
                        .receivedEventId(null)
                        .openedEventId(null)
                        .clickedEventId(null)
                        .build();
                result.add(dtoWithEmptyStages);
            }
        }
        log.info("get channel event stage list: {}", result);
        return result;
    }

    public List<CampaignChannelEventStageDto> getChannelMessagingTypesByCampaignId(Long campaignId) {
        List<CampaignChannelEventStageDto> dtoList = BeanCopyUtils.copyList(campaignBatchInfoMapper.selectByCampaignId(campaignId), CampaignChannelEventStageDto::new);
        List<ChannelPluginVersionWithMessagingTypeDTO> messagingTypeList = compositeChannelPluginInstanceService.getPluginVersionWithMessagingTypeList();
        return dtoList.stream()
                .collect(Collectors.collectingAndThen(
                        toCollection(() ->
                                new TreeSet<>(comparing(CampaignChannelEventStageDto::getChannelType)
                                        .thenComparing(CampaignChannelEventStageDto::getMessagingType))),
                        ArrayList::new))
                .stream()
                .peek(item -> messagingTypeList.stream().filter(messagingTypeDto -> messagingTypeDto.getCode().equals(item.getMessagingType())).findFirst().ifPresent(messagingTypeDto -> {
                    item.setMessagingName(messagingTypeDto.getDesc());
                    item.setPluginId(messagingTypeDto.getPluginId());
                    item.setPluginVersionId(messagingTypeDto.getPluginVersionId());
                })).collect(Collectors.toList());
    }

    /**
     * sms-sending_sms	短信-发送短信	sms	短信
     * gsms-sending_gsms	国际短信-发送国际短信	gsms	国际短信
     * app_push-sending_app_push	App消息推送-发送App消息推送	app_push	App消息推送
     * vms-sending_vms	彩信-发送彩信	vms	视频短信
     * mms-sending_mms	视频短信-发送视频短信	mms	彩信
     * email-sending_email	邮件-发送邮件	email	邮件
     * wechat_official_account-sending_template_message	微信公众号-发送模版消息	wechat_official_account	微信公众号
     * wechat_official_account-sending_subscription_notification	微信公众号-发送订阅通知	wechat_official_account	微信公众号
     * wechat_mini_program-sending_subscription_notification	微信小程序-发送订阅通知	wechat_mini_program	微信小程序
     *
     * @Deprecated
     */
    @Deprecated
    public Map<String, MessagingTypeInfo> systemMessagingTypeMapForCampaign() {
        List<MessagingTypeInfo> typeList = new ArrayList<>();
        typeList.add(new MessagingTypeInfo("sms-sending_sms", "短信-发送短信", "sms", "短信"));
        typeList.add(new MessagingTypeInfo("gsms-sending_gsms", "国际短信-发送国际短信", "gsms", "国际短信"));
        typeList.add(new MessagingTypeInfo("app_push-sending_app_push", "App消息推送-发送App消息推送", "app_push", "App消息推送"));
        typeList.add(new MessagingTypeInfo("vms-sending_vms", "彩信-发送彩信", "vms", "视频短信"));
        typeList.add(new MessagingTypeInfo("mms-sending_mms", "视频短信-发送视频短信", "mms", "彩信"));
        typeList.add(new MessagingTypeInfo("email-sending_email", "邮件-发送邮件", "email", "邮件"));
        typeList.add(new MessagingTypeInfo("wechat_official_account-sending_template_message", "微信公众号-发送模版消息", "wechat_official_account", "微信公众号"));
//        typeList.add(new MessagingTypeInfo("wechat_official_account-sending_subscription_notification", "微信公众号-发送订阅通知", "wechat_official_account", "微信公众号"));
//        typeList.add(new MessagingTypeInfo("wechat_mini_program-sending_subscription_notification", "微信小程序-发送订阅通知", "wechat_mini_program", "微信小程序"));
        return typeList.stream().collect(Collectors.toMap(MessagingTypeInfo::getMessagingType, Function.identity()));
    }

    @Deprecated
    @Data
    static class MessagingTypeInfo {
        String channelType;
        String messagingType;
        String channelName;
        String description;

        public MessagingTypeInfo(String messagingType, String description, String channelType, String channelName) {
            this.messagingType = messagingType;
            this.channelName = channelName;
            this.channelType = channelType;
            this.description = description;
        }
    }

    protected static Map<String, CampaignChannelEventStageDto> systemMessagingTypeEventMap() {
        List<CampaignChannelEventStageDto> campaignChannelEventStageDtos;
        try {
            InputStream is = CampaignChannelEventStageDto.class.getClassLoader().getResourceAsStream("config/messaging_type_event_stages.json");
            if (is == null) {
                throw new IllegalStateException("failed to load system event stages config file of messaging types");
            }
            String jsonStr = IOUtils.toString(is, StandardCharsets.UTF_8);
            campaignChannelEventStageDtos = JsonUtils.instanceOfDto()
                    .json2List(jsonStr, CampaignChannelEventStageDto.class);
        } catch (IOException e) {
            throw new IllegalStateException("failed to load system event stages config file of messaging types");
        }
        return campaignChannelEventStageDtos.stream().collect(Collectors.toMap(CampaignChannelEventStageDto::getMessagingType, Function.identity()));
    }


    /**
     * 根据输入的维度和指标需求， 组装最终的报表数据
     */
    public List<Map<String, Object>> _composeReportDataMap(
            List<CampaignReportDataLineDto> campaignReportDataList, CampaignReportQuery reportQuery,
            CampaignEngageBatchContext batchContext, CampaignReportQueryOptions queryOptions) {

        List<Map<String, Object>> reportDataMap = new ArrayList<>();

        for (CampaignReportDataLineDto dataLine : campaignReportDataList) {
            Long engageId = dataLine.getEngageId();

            if (engageId == -1L) {
                log.info("engageId is -1L, skip data line: {}", dataLine);
                continue;
            }
            Long campaignId = dataLine.getCampaignId();

            Map<String, Object> campaignInfo = new HashMap<>();
            if (Boolean.TRUE.equals(queryOptions.getNeedCampaignId()) || queryOptions.getControlGroupType() == ControlGroupType.SET_IN_CAMPAIGN_LEVEL) {
                Map<String, Object> marketingCampaignInfo = batchContext.getCampaignInfoMap().get(campaignId);
                Set<String> sysCampaignFields = new HashSet<>(Arrays.asList(CAMPAIGN_ID_FIELD, CAMPAIGN_NAME_FIELD, CAMPAIGN_CODE_FIELD));
                campaignInfo.put(CAMPAIGN_ID_FIELD, campaignId);
                campaignInfo.put(CAMPAIGN_NAME_FIELD, marketingCampaignInfo.get(CAMPAIGN_NAME_FIELD));
                campaignInfo.put(CAMPAIGN_CODE_FIELD, marketingCampaignInfo.get(CAMPAIGN_CODE_FIELD));

                List<String> campaignDims = reportQuery.getDimension().getCampaignDims();
                if (campaignDims != null && !campaignDims.isEmpty()) {
                    for (String campaignDim : campaignDims) {
                        if (!sysCampaignFields.contains(campaignDim)) {
                            campaignInfo.put(campaignDim, marketingCampaignInfo.get(campaignDim));
                        }
                    }
                }
            }

            CampaignReportDataLineDto.GroupStat engageGroupStat = dataLine.getEngageGroupStat();
            Map<String, Object> groupCountMap = new HashMap<>(campaignInfo);

            if (Boolean.TRUE.equals(queryOptions.getNeedEngageId()) || queryOptions.getControlGroupType() == ControlGroupType.SET_IN_ENGAGE_LEVEL) {
                groupCountMap.put(ENGAGE_ID_FIELD, engageId);
                Map<String, Object> engageInfo = batchContext.getEngageInfoMap().get(engageId);
                groupCountMap.put(ENGAGE_CODE_FIELD, engageInfo.get(ENGAGE_CODE_FIELD));

                List<String> engageDims = reportQuery.getDimension().getEngageDims();
                if (engageDims != null && !engageDims.isEmpty()) {
                    for (String engageDim : engageDims) {
                        groupCountMap.put(engageDim, engageInfo.get(engageDim));
                    }
                }
            }

            EngageDateUnit engageDateUnit = queryOptions.getEngageDateUnit();
            if (engageDateUnit.isSet()) {
                String formattedUnit = engageDateUnit.formatUnit(dataLine.getDateUnit());
                groupCountMap.put(DATE_UNIT_PARAM_KEY, formattedUnit);
            }

            //engageGroupStat
            groupCountMap.putAll(engageGroupStat.getGroupCountMap());
            List<CampaignReportDataLineDto.BatchEventStageStat> batchEventStageStatList = dataLine.getBatchEventStageStat();
            if (!batchEventStageStatList.isEmpty()) {
                for (CampaignReportDataLineDto.BatchEventStageStat batchEventStageStat : batchEventStageStatList) {
                    Map<String, Object> retMap = new HashMap<>();
                    retMap.putAll(groupCountMap);
                    retMap.putAll(batchEventStageStat.getEventCountMap());

                    String batchId = batchEventStageStat.getBatchId();
                    Map<String, CampaignEngageBatchContext.CampaignEngageBatchDim> batchInfoMap = batchContext.getBatchInfoMap();
                    if (!batchInfoMap.isEmpty()) {
                        CampaignEngageBatchContext.CampaignEngageBatchDim campaignEngageBatchDim = batchInfoMap.get(batchId);
                        if (campaignEngageBatchDim != null) {
                            retMap.put(TEMPLATE_ID_FIELD, campaignEngageBatchDim.getTemplateId());
                            retMap.put(TEMPLATE_NAME_FIELD, campaignEngageBatchDim.getTemplateName());
                        }
                    }

                    reportDataMap.add(retMap);
                }
            } else {
                reportDataMap.add(new HashMap<>(groupCountMap));
            }
        }
        return reportDataMap;
    }

    /**
     * 根据输入的维度和指标需求， 组装最终的报表数据
     */
    public static List<Map<String, Object>> composeReportDataMap(
            List<CampaignReportDataLineDto> campaignReportDataList, CampaignReportQuery reportQuery,
            CampaignEngageBatchContext batchContext, CampaignReportQueryOptions queryOptions) {

        //如果包含filter
        boolean needFilterGroup = queryOptions.getNeedFilterId();
        //对照组类型
        ControlGroupType controlGroupType = queryOptions.getControlGroupType();
        //是否需要渠道维度信息
        Boolean needBatchId = queryOptions.getNeedBatchId();

        List<Map<String, Object>> reportDataMap = new ArrayList<>();

        //如果同时包含campaign和engage维度，则粒度拆分到Engage维度的targetGroup
        if (queryOptions.getNeedEngageId().equals(Boolean.TRUE)) {

            for (CampaignReportDataLineDto dataLine : campaignReportDataList) {
                Long campaignId = dataLine.getCampaignId();
                //先获取响应的campaign信息
                Map<String, Object> responseCampaignInfo = getResponseCampaignInfo(reportQuery, batchContext, queryOptions, campaignId);
                Long engageId = dataLine.getEngageId();

                //如果租户级别设置了过滤器，添加过滤器信息
                if (engageId == -1L) {
                    if (needFilterGroup) {
                        int filteredGroupCount = dataLine.getCampaignGroupStat().getExcludedGroupCount();
                        Map<String, Object> filteredGroupInfo = new HashMap<>(responseCampaignInfo);
                        filteredGroupInfo.put(CAMPAIGN_ID_FIELD, dataLine.getCampaignId());
                        Map<String, Object> filterInfo = batchContext.getFilterInfoMap().get(campaignId);
                        if (filterInfo.containsKey(FILTER_NAME_FIELD)) {
                            filteredGroupInfo.put(FILTER_NAME_FIELD, filterInfo.get(FILTER_NAME_FIELD));
                        }
                        filteredGroupInfo.put(GROUP_COUNT_FIELD, filteredGroupCount);
                        reportDataMap.add(filteredGroupInfo);
                        log.info("engageId is -1L, get filtered data: {}, the dateLine: {}", filteredGroupInfo, dataLine);
                    }

                    continue;
                }
                Map<String, Object> responseEngageInfo = getResponseEngageInfo(reportQuery, batchContext, queryOptions, engageId);
                CampaignReportDataLineDto.GroupStat engageGroupStat = dataLine.getEngageGroupStat();

                Map<String, Object> engageTargetGroupMap = new HashMap<>(responseCampaignInfo);
                engageTargetGroupMap.putAll(responseEngageInfo);
                engageTargetGroupMap.put(GROUP_COUNT_FIELD, engageGroupStat.getTargetGroupCount());

                //如果维度设置了 dateUnit，就加上 dateUnit
                EngageDateUnit engageDateUnit = queryOptions.getEngageDateUnit();
                if (engageDateUnit.isSet()) {
                    String formattedUnit = engageDateUnit.formatUnit(dataLine.getDateUnit());
                    engageTargetGroupMap.put(DATE_UNIT_PARAM_KEY, formattedUnit);
                }

                //如果维度设置了对照组，就添加对照组记录
                if (controlGroupType == ControlGroupType.SET_IN_ENGAGE_LEVEL) {
                    Map<String, Object> controlGroupInfo = new HashMap<>(engageTargetGroupMap);
                    controlGroupInfo.put(CONTROL_GROUP_TYPE_FIELD, "control");
                    controlGroupInfo.put(GROUP_COUNT_FIELD, engageGroupStat.getControlGroupCount());
                    reportDataMap.add(controlGroupInfo);

                    engageTargetGroupMap.put(CONTROL_GROUP_TYPE_FIELD, "target");
                }

                //如果指标设置了渠道发送信息，就添加渠道发送信息
                if (!reportQuery.getMetric().getChannelMetrics().isEmpty()) {
                    List<CampaignReportDataLineDto.BatchEventStageStat> batchEventStageStatList = dataLine.getBatchEventStageStat();
                    if (needBatchId) {
                        //对于有batchId维度的查询，需要为每个batch生成一条记录信息
                        for (CampaignReportDataLineDto.BatchEventStageStat batchEventStageStat : batchEventStageStatList) {
                            Map<String, Object> batchSendInfoMap = new HashMap<>(engageTargetGroupMap);
                            String batchId = batchEventStageStat.getBatchId();
                            batchSendInfoMap.put(BATCH_ID_FIELD, batchId);
                            Map<String, CampaignEngageBatchContext.CampaignEngageBatchDim> batchInfoMap = batchContext.getBatchInfoMap();
                            if (!batchInfoMap.isEmpty()) {
                                CampaignEngageBatchContext.CampaignEngageBatchDim campaignEngageBatchDim = batchInfoMap.get(batchId);
                                if (campaignEngageBatchDim != null) {
                                    batchSendInfoMap.put(TEMPLATE_ID_FIELD, campaignEngageBatchDim.getTemplateId());
                                    batchSendInfoMap.put(TEMPLATE_NAME_FIELD, campaignEngageBatchDim.getTemplateName());
                                }
                            }
                            reportDataMap.add(batchSendInfoMap);
                        }
                    } else {
                        //对于没有batchId维度的查询， 只需要获取 engage + dateUnit 对应的所有batch信息，聚合成一条记录，补充到 targetGroupMap
                        Map<String, Object> batchSendInfoMap = accumulateBatchSendInfo(batchEventStageStatList);
                        engageTargetGroupMap.putAll(batchSendInfoMap);
                    }
                } else {
                    //如果不查询渠道指标，直接添加 engage + dateUnit 维度的记录
                    reportDataMap.add(engageTargetGroupMap);
                }
            }
        }

        return reportDataMap;
    }

    private static Map<String, Object> accumulateBatchSendInfo(List<CampaignReportDataLineDto.BatchEventStageStat> batchEventStageStatList) {
        CampaignReportDataLineDto.BatchEventStageStat stat = new CampaignReportDataLineDto.BatchEventStageStat();
        for (CampaignReportDataLineDto.BatchEventStageStat batchEventStageStat : batchEventStageStatList) {
            stat.merge(batchEventStageStat);
        }
        Map<String, Object> eventCountMap = stat.getEventCountMap(true);
        eventCountMap.remove(BATCH_ID_FIELD);
        return eventCountMap;
    }

    private static Map<String, Object> getResponseEngageInfo(CampaignReportQuery reportQuery, CampaignEngageBatchContext batchContext, CampaignReportQueryOptions queryOptions, Long engageId) {
        Map<String, Object> groupCountMap = new HashMap<>();
        if (Boolean.TRUE.equals(queryOptions.getNeedEngageId())) {
            groupCountMap.put(ENGAGE_ID_FIELD, engageId);
            Map<String, Object> engageInfo = batchContext.getEngageInfoMap().get(engageId);
            groupCountMap.put(ENGAGE_CODE_FIELD, engageInfo.get(ENGAGE_CODE_FIELD));

            List<String> engageDims = reportQuery.getDimension().getEngageDims();
            if (engageDims != null && !engageDims.isEmpty()) {
                for (String engageDim : engageDims) {
                    //engage 的自定义属性需要加上前缀
                    String engageProp = StringUtils.startsWith(engageDim, "c_") ? String.format("engage.%s", engageDim) : engageDim;
                    groupCountMap.put(engageProp, engageInfo.get(engageDim));
                }
            }
        }
        return groupCountMap;
    }

    private static Map<String, Object> getResponseCampaignInfo(CampaignReportQuery reportQuery, CampaignEngageBatchContext batchContext, CampaignReportQueryOptions queryOptions, Long campaignId) {
        Map<String, Object> responseCampaignInfo = new HashMap<>();
        if (Boolean.TRUE.equals(queryOptions.getNeedCampaignId())) {
            Map<String, Object> marketingCampaignInfo = batchContext.getCampaignInfoMap().get(campaignId);
            Set<String> sysCampaignFields = new HashSet<>(Arrays.asList(CAMPAIGN_ID_FIELD, CAMPAIGN_NAME_FIELD, CAMPAIGN_CODE_FIELD));
            responseCampaignInfo.put(CAMPAIGN_ID_FIELD, campaignId);
            responseCampaignInfo.put(CAMPAIGN_NAME_FIELD, marketingCampaignInfo.get(CAMPAIGN_NAME_FIELD));
            responseCampaignInfo.put(CAMPAIGN_CODE_FIELD, marketingCampaignInfo.get(CAMPAIGN_CODE_FIELD));

            //设置营销活动的自定义属性
            List<String> campaignDims = reportQuery.getDimension().getCampaignDims();
            if (campaignDims != null && !campaignDims.isEmpty()) {
                for (String campaignDim : campaignDims) {
                    if (!sysCampaignFields.contains(campaignDim)) {
                        //自定义属性可能会和engage的属性重名，所以需要加上前缀
                        String campaignProp = StringUtils.startsWith(campaignDim, "c_") ? String.format("campaign.%s", campaignDim) : campaignDim;
                        responseCampaignInfo.put(campaignProp, marketingCampaignInfo.get(campaignDim));
                    }
                }
            }
        }
        return responseCampaignInfo;
    }

    /**
     * 返回 campaign 对应的 control group 类型
     */
    public Map<Long, ControlGroupType> getControlGroupTypes(List<Long> campaignIds) {
        Map<Long, ControlGroupType> campaignIdControlGroupTypeMap = new HashMap<>();
        for (Long campaignId : campaignIds) {
            ControlGroupType groupType = getControlGroupType(campaignId);
            campaignIdControlGroupTypeMap.put(campaignId, groupType);
        }

        return campaignIdControlGroupTypeMap;
    }

    public List<Long> getCampaignIdsNotMatchControlGroup(List<Long> campaignIds, ControlGroupType queryControlGroupType) {
        if(queryControlGroupType == ControlGroupType.NOT_SET) {
            return emptyList();
        }

        return campaignIds.stream().filter(campaignId -> {
            ControlGroupType groupType = getControlGroupType(campaignId);
            return groupType != ControlGroupType.NOT_SET &&
                    !groupType.equals(queryControlGroupType);
        }).collect(Collectors.toList());
    }

    ControlGroupType getControlGroupType(Long campaignId) {
        final Long NON_ENGAGE_ID = 1L;
        ControlGroupType groupType = ControlGroupType.NOT_SET;
        List<CampaignListInfo> controlGroupList = campaignListInfoMapper.selectByCampaignIdAndListType(campaignId, NameUtils.CONTROL_GROUP);
        if (!controlGroupList.isEmpty()) {
            Set<ControlGroupType> controlGroupTypeSet = controlGroupList.stream().map(cg -> {
                Long engageId = cg.getEngageId();
                //无论 engageId 是 0 还是 -1 ，都会被认为是 campaign level
                return engageId < NON_ENGAGE_ID ? ControlGroupType.SET_IN_CAMPAIGN_LEVEL : ControlGroupType.SET_IN_ENGAGE_LEVEL;
            }).collect(Collectors.toSet());
            Assert.isTrue(controlGroupTypeSet.size() == 1, "campaign#" + campaignId + " can only has one controlGroup, the current types: " + controlGroupTypeSet);
            groupType = controlGroupTypeSet.iterator().next();
        }
        return groupType;
    }


    public CampaignReportResultDto getCampaignReportData(CampaignReportQuery reportQuery) {

        Boolean isDistinct = reportQuery.getIsDistinct();
        List<Long> campaignIds = reportQuery.getCampaignIds();

        CampaignReportResultDto resultDto = new CampaignReportResultDto();
        CampaignReportQueryOptions queryOptions = validateQueryAndGetReportQueryOptions(reportQuery);
        List<Long> violationCampaignIds = queryOptions.getViolationCampaignIds();
        Map<Long, MarketingCampaign> campaignMap = getCampaignMap(campaignIds);
        List<String> campaignNames = violationCampaignIds.stream().map(campaignMap::get).map(MarketingCampaign::getTitle).collect(Collectors.toList());
        resultDto.setViolationCampaigns(campaignNames);

        List<Long> reportCampaignIds = queryOptions.getReportCampaignIds();
        if (CollectionUtils.isEmpty(reportCampaignIds)) {
           return resultDto;
        }

        CampaignEngageBatchContext batchContext = initCampaignEngageBatchContext(reportCampaignIds);
        List<Map<String, Object>> reportData = getTargetGroupReportDataMap(isDistinct, reportCampaignIds, queryOptions, reportQuery, batchContext);
        resultDto.setReportData(reportData);
        return resultDto;
    }


//        if (queryOptions.getNeedBatchId()) { //聚合维度包含了campaignCode/campaignName和engageCode
//
//            //获取事件原始聚合数据
//            List<String> batchIds = batchContext.getBatchIds();
//            List<Map<String, Object>> eventRawStat = getCampaignEventRawStat(batchIds, isDistinct, queryOptions);
//            //获取分群原始聚合数据
//            List<Map<String, Object>> groupRawStat = getCampaignGroupRawStat(isDistinct, reportCampaignIds, queryOptions);
//
//            //组装报表数据
//            //报表的返回结构，最好是静态类型，包含**必须的**维度（包含campaignId和engageId， 不过不会包括 campaignCode， engage自定义属性这些）和指标，
//            // 只是会根据 queryOptions/dimensions，生成最终的返回数据
//            //最终返回给前台的数据结构，大概率是 List<Map<String, Object>> 的类型
//            List<CampaignReportDataLineDto> reportLines = getCampaignReportLines(eventRawStat, groupRawStat, batchContext, queryOptions);
//            composeReportDataMap(reportLines, reportQuery, batchContext, queryOptions);
//        }



    protected List<Map<String, Object>> getTargetGroupReportDataMap(Boolean isDistinct, List<Long> campaignIds,
                                                                    CampaignReportQueryOptions queryOptions,
                                                                    CampaignReportQuery reportQuery,
                                                                    CampaignEngageBatchContext batchContext) {

        if (campaignIds.isEmpty()) {
            return emptyList();
        }

        EngageDateUnit dateUnit = queryOptions.getEngageDateUnit();
        String distinctCount = Boolean.TRUE.equals(isDistinct) ? DISTINCT_KEYWORD : "";
        String eventSumClause = "";
        String campaignIdCondition = campaignIds.stream().map(batchId -> "?").collect(Collectors.joining(","));

        CampaignReportQuery.ReportQueryDimension dimension = reportQuery.getDimension();
        CampaignReportQuery.ReportQueryMetric metric = reportQuery.getMetric();
        List<String> selectFields = new ArrayList<>();
        List<String> selectGroupDimension = new ArrayList<>(Arrays.asList("cbi.campaign_id", "cbi.engage_id", "cbi.engage_code"));
        List<String> groupByFields = new ArrayList<>();
        List<String> selectEventFactsFields = new ArrayList<>(Arrays.asList("cef.campaign_id", "cef.campaign_code",
                "cef.engage_id", "cef.engage_code", "cef.group_date", "cef.batch_id", "cef.message_type", "cef.profile_id",
                "cef.send", "cef.failed_to_send", "cef.failed_to_send_reason", "cef.delivered", "cef.failed_to_deliver",
                "cef.failed_to_deliver_reason", "cef.received", "cef.opened", "cef.click"));

        List<String> campaignDims = dimension.getCampaignDims();
        List<String> engageDims = dimension.getEngageDims();
        Map<Long, Map<String, Object>> filterInfoMap = batchContext.getFilterInfoMap();
        boolean containsFilter = campaignDims.contains(FILTER_NAME_DIM)
                || campaignDims.contains(CAMPAIGN_NAME_DIM)
                || campaignDims.contains(CAMPAIGN_CODE_DIM);
        if (containsFilter) { //TODO 可能需要同时考虑不包含campaign信息的情况下，也需要添加过滤器
            selectFields.add("case when cgf.campaign_filtered_flag != 0 then 1 else 0 end as campaign_filtered_flag0");
            groupByFields.add("campaign_filtered_flag0");
        }

        if (!dimension.getCampaignDims().isEmpty()) {
            List<String> campaignColumns = campaignDims.stream()
                    .filter(d -> !d.equals(FILTER_NAME_DIM)) //filter在单独的逻辑里面处理
                    .map(d -> {
                        if (CAMPAIGN_NAME_FIELD.equals(d)) {
                            return CAMPAIGN_NAME_COLUMN;
                        } else if (CAMPAIGN_CODE_FIELD.equals(d)) {
                            return CAMPAIGN_CODE_COLUMN;
                        } else {
                            return NamingUtils.toUnderScoreCase(d);
                        }
                    }).distinct().collect(Collectors.toList());
            //如果有活动名称或者活动代码作为维度，需要添加 活动id
            if (!campaignDims.contains(CAMPAIGN_ID_FIELD) && (campaignDims.contains(CAMPAIGN_NAME_FIELD) || campaignDims.contains(CAMPAIGN_CODE_FIELD))) {
                campaignColumns.add(CAMPAIGN_ID_COLUMN);
            }
            //campaign_id 要使用主数据表的campaign_id，如果使用维度表，可能会因为关联不上得到null值
            selectFields.addAll(campaignColumns.stream().map(c -> CAMPAIGN_ID_COLUMN.equals(c) ? "cgf." + c : "cbd." + c).collect(Collectors.toList()));
            //marketing_campaign.id ==> campaign_batch_info.campaign_id
            selectGroupDimension.addAll(campaignColumns.stream().map(c -> "campaign_id".equals(c) ? "cbi." + c : "mk." + c).collect(Collectors.toList()));
            groupByFields.addAll(campaignColumns.stream().map(c -> "campaign_id".equals(c) ? "cgf." + c : "cbd." + c).collect(Collectors.toList()));

        }
        if (queryOptions.getControlGroupType() == ControlGroupType.SET_IN_CAMPAIGN_LEVEL) {
            selectFields.add("cgf.campaign_control_flag");
            groupByFields.add("cgf.campaign_control_flag");
        }
        if (queryOptions.getControlGroupType() == ControlGroupType.SET_IN_ENGAGE_LEVEL) {
            selectFields.add("cgf.engage_control_flag");
            groupByFields.add("cgf.engage_control_flag");
        }
        if (!dimension.getEngageDims().isEmpty()) {
            List<String> engageColumns = dimension.getEngageDims().stream()
                    .map(NamingUtils::toUnderScoreCase)
                    .distinct().collect(Collectors.toList());

            selectFields.addAll(engageColumns.stream().map(c -> "cbd." + c).collect(Collectors.toList()));
            List<String> engageDimensions = engageColumns.stream()
                    .map(c -> "engage_code".equals(c)
                            ? "cbi.engage_code"
                            : "cea." + c).collect(Collectors.toList());
            selectGroupDimension.addAll(engageDimensions);
            groupByFields.addAll(engageColumns.stream().map(c -> "cbd." + c).collect(Collectors.toList()));
        }
        if (!dimension.getChannelDims().isEmpty()) { //channel_type, template_name/ failed_to_deliver_reason, failed_to_send_reason
            List<String> channelColumns = dimension.getChannelDims().stream()
                    .map(NamingUtils::toUnderScoreCase).distinct().collect(Collectors.toList());
            selectFields.addAll(channelColumns.stream().map(c -> "cefx." + c).collect(Collectors.toList()));
            for (String c : channelColumns) {
                if (CHANNEL_TYPE_COLUMN.equals(c) || TEMPLATE_NAME_COLUMN.equals(c)) {
                    selectEventFactsFields.add("cbi." + c);
                }
            }
            groupByFields.addAll(channelColumns.stream().map(c -> "cefx." + c).collect(Collectors.toList()));
        }
        if (dimension.getDateUnit() != EngageDateUnit.NOT_SET) {

            String dateField = GROUP_DATE_COLUMN;
            selectFields.add(getDateUnitColumn(dateUnit, "cgf." + dateField, dateField));
            groupByFields.add(dateField);
        }

        LinkedHashMap<String, String> eventColumnAliasMap = new LinkedHashMap<>();
        eventColumnAliasMap.put("send", "sent");
        eventColumnAliasMap.put("failed_to_send", "failed_to_send");
        eventColumnAliasMap.put("delivered", "delivered");
        eventColumnAliasMap.put("failed_to_deliver", "failed_to_deliver");
        eventColumnAliasMap.put("received", "received");
        eventColumnAliasMap.put("opened", "opened");
        eventColumnAliasMap.put("click", "clicked");

        if (!metric.getChannelMetrics().isEmpty()) {

            // lambda to get the count clause of one event column
            //  count( DISTINCT (case when coalesce(cefx.${eventColumn}, 0) = 1 then cgf.profile_id else '0' end)  ) AS ${eventColumn}
            BiFunction<String, String, String> getCountClause = (eventColumn, alias) -> {
                String eventColumnToProfileId = " (case when coalesce(cefx." + eventColumn + ", 0) = 1 then cgf.profile_id else '' end) ";
                return "count(" + DISTINCT_KEYWORD + eventColumnToProfileId +  ") -1 AS " + alias + "_cnt";
            };

            //lambda to get sum clause of one event column
            // sum(coalesce(cefx.%1, 0)) as %2
            BiFunction<String, String, String> getSumClause = (eventColumn, alias) -> "sum(coalesce(cefx." + eventColumn + ", 0)) as " + alias;

            List<String> sumClauseList = eventColumnAliasMap.entrySet().stream()
                    .map(e -> getSumClause.apply(e.getKey(), e.getValue()))
                    .collect(Collectors.toList());

            if (isDistinct) {
                eventColumnAliasMap.entrySet().stream().map(e -> getCountClause.apply(e.getKey(), e.getValue()))
                        .forEach(sumClauseList::add);
            }

            eventSumClause = "," + String.join(",", sumClauseList);
        }

        String selectFieldsClause = String.join(",", selectFields);
        String selectGroupDimensionClause = selectGroupDimension.stream().distinct().collect(Collectors.joining(","));
        String groupByFieldsClause = String.join(",", groupByFields);
        String selectEventFactsFieldsClause = String.join(",", selectEventFactsFields);


        String eventFactsStatSql = String.format(
                "select %s ,count(%s cgf.profile_id) as group_count %s " + //<1 <2 <3
                        "    from campaign_group_facts cgf " +
                        "         left join (" +
                        "             select distinct %s " +   //<4
                        "             from campaign_batch_info cbi " +
                        "                 left join marketing_campaign mk " +
                        "                     on cbi.campaign_id = mk.id " +
                        "                 left join campaign_engage_attribute cea " +
                        "                     on cbi.engage_id = cea.engage_id and cbi.campaign_id = cea.campaign_id) cbd " +
                        "           on cgf.campaign_id = cbd.campaign_id and cgf.engage_id = cbd.engage_id " +
                        "         left join (" +
                        "             select %s " + //<5
                        "             from campaign_event_facts cef " +
                        "                 left join campaign_batch_info cbi " +
                        "                     on cef.campaign_id = cbi.campaign_id and cef.batch_id = cbi.batch_id ) cefx " +
                        "           on cgf.campaign_id = cefx.campaign_id and cgf.engage_id = cefx.engage_id and cgf.group_date = cefx.group_date  and cgf.profile_id = cefx.profile_id " +
                        "where cgf.campaign_id in (%s) " + //<6
                        "group by %s ", //<7
                selectFieldsClause, distinctCount, eventSumClause, selectGroupDimensionClause, selectEventFactsFieldsClause, campaignIdCondition, groupByFieldsClause);

        List<GdmQuery.Arg> args = new ArrayList<>();
        campaignIds.forEach(campaignId -> args.add(new GdmQuery.Arg(campaignId, FieldType.Long)));

        log.info("getCampaignEventFactsRawStat sql: {}, with args: {}", eventFactsStatSql, campaignIds);

        GdmQuery.Request request = new GdmQuery.Request(eventFactsStatSql, args, null, false, ProcessingMode.OLAP.toString());
        GdmQuery.Response response = queryEngineClient.queryEngineQuery(request);
        List<Map<String, Object>> rows = response.getRows();
        log.info("getCampaignEventFactsRawStat rows: {}", rows);

        //处理过滤器相关的逻辑：找出没有通过过滤器的数据/删除过滤器字段
        Set<Integer> excludeIndexSet = new HashSet<>();
        for (int i = 0; i < rows.size(); i++) { //需要通过 index 找出可能要删除的行
            Map<String, Object> row = rows.get(i);
            updateRowCampaignInfo(batchContext, row, campaignDims);
            if (isDistinct) {
                updateRowEventCountInfo(eventColumnAliasMap, row);
            }
            if (zero.equals(row.get(CAMPAIGN_FILTERED_FLAG_COLUMN_ALIAS))) {
                row.remove(CAMPAIGN_FILTERED_FLAG_COLUMN_ALIAS);
                row.remove(CAMPAIGN_CONTROL_FLAG_COLUMN);
                eventColumnAliasMap.values().forEach(row::remove);
                updateFilterName(row, filterInfoMap);
//                if (zero.equals(row.get(ENGAGE_FILTERED_FLAG_COLUMN))) {
//                    updateRowEngageInfo(batchContext, row, engageDims);
//                }
                excludeIndexSet.add(i);
            } else { // if (one.equals(row.get(CAMPAIGN_FILTERED_FLAG_COLUMN)))
                //删除过滤器字段
                if (row.containsKey(CAMPAIGN_FILTERED_FLAG_COLUMN_ALIAS)) {
                    row.remove(CAMPAIGN_FILTERED_FLAG_COLUMN_ALIAS);
                    row.put(FILTER_NAME_COLUMN, "--");
                }
                if (queryOptions.getControlGroupType() != ControlGroupType.NOT_SET) {
                    updateRowControlGroupInfo(queryOptions, batchContext, row);
                }
                // 不需要额外添加Engage信息，都会从 db 获取
//                 updateRowEngageInfo(batchContext, row, engageDims);
            }
        }
        boolean filterInReport = dimension.getCampaignDims().contains(FILTER_NAME_DIM);
        if (!filterInReport) {  //如果不包含过滤器，需要去掉被排除的组
            Iterator<Map<String, Object>> rowIter = rows.iterator();

            int rowIdx = 0;
            while(rowIter.hasNext()) {
                rowIter.next();
                if (excludeIndexSet.contains(rowIdx)) {
                    rowIter.remove();
                }
                rowIdx++;
            }
        }

        UnaryOperator<Map<String, Object>> toCamelCaseKeyAndFormatDateUnitValue = row -> {
            if (row.containsKey(GROUP_DATE_COLUMN) && dateUnit != EngageDateUnit.NOT_SET) {
                row.put(GROUP_DATE_COLUMN, dateUnit.formatUnit((String) row.get(GROUP_DATE_COLUMN)));
            }
            Map<String, Object> newMap = new HashMap<>();
            row.forEach((k, v) -> {
                String lowerCamelCase = NamingUtils.toLowerCamelCase(k);
                if (CAMPAIGN_NAME_COLUMN.equals(lowerCamelCase)) {
                    lowerCamelCase = CAMPAIGN_NAME_FIELD;
                } else if (CAMPAIGN_CODE_COLUMN.equals(lowerCamelCase)) {
                    lowerCamelCase = CAMPAIGN_CODE_FIELD;
                } else if (lowerCamelCase.startsWith("attr")) {
                    lowerCamelCase = String.format("campaign.%s", lowerCamelCase);
                } else if (lowerCamelCase.startsWith("c_")) {
                    lowerCamelCase = String.format("engage.%s", lowerCamelCase);
                }
                newMap.put(lowerCamelCase, v);
            });
            return newMap;
        };

        List<Map<String, Object>> result = rows.stream().map(toCamelCaseKeyAndFormatDateUnitValue).collect(Collectors.toList());
        log.info("getCampaignEventFactsRawStat result: {}", result);
        return result;
    }

    static void updateRowEventCountInfo(Map<String, String> eventColumnAliasMap, Map<String, Object> row) {
        eventColumnAliasMap.values().forEach(alias -> {
            Integer eventSum = Integer.valueOf((String) row.getOrDefault(alias, 0));
            String cntAlias = alias + "_cnt";
            Integer eventCnt = Integer.valueOf((String) row.getOrDefault(cntAlias, 0));
            Integer groupCnt = Integer.valueOf((String) row.getOrDefault("group_count", 0));

            Integer distinctEventCnt ;
            //eventCnt 计算时的逻辑等同于，所有profile都发生了的事件，计算时会在总数上减1
            //所以，如果所有的profile都发生了某个事件, 就要把 1 加回来
            //只能修正一种情况， TODO：可能最终要改为 对 profileId group 后再group的做法
            if (eventSum.equals(groupCnt) && eventSum == eventCnt + 1) {
                distinctEventCnt = groupCnt;
            } else {
                distinctEventCnt = eventCnt;
            }
            row.put(alias, distinctEventCnt );
            row.remove(cntAlias);
        });
    }

    static void updateRowControlGroupInfo(CampaignReportQueryOptions queryOptions, CampaignEngageBatchContext batchContext, Map<String, Object> row) {
        ControlGroupType controlGroupType = queryOptions.getControlGroupType();
        String flagColumn = controlGroupType == ControlGroupType.SET_IN_CAMPAIGN_LEVEL
                ? CAMPAIGN_CONTROL_FLAG_COLUMN
                : ENGAGE_CONTROL_FLAG_COLUMN;
        if (zero.equals(row.get(flagColumn))) { //实验组
            row.put(GROUP_TYPE_COLUMN, "target");
            row.remove(flagColumn);
        } else if (one.equals(row.get(flagColumn))) { //对照组
            row.put(GROUP_TYPE_COLUMN, "control");
            row.remove(flagColumn);
        } else if (negOne.equals(row.get(flagColumn))) {
            //flag: -1
            row.remove(flagColumn);
        } else {
            Assert.isTrue(false, "flag: " + row.get(flagColumn) + " is not supported");
        }
    }

    static void updateFilterName(Map<String, Object> row, Map<Long, Map<String, Object>> filterInfoMap) {
        if (row.containsKey(CAMPAIGN_ID_COLUMN)
                && StringUtils.isNumeric(row.get(CAMPAIGN_ID_COLUMN).toString())) {
            Map<String, Object> campaignFilterInfo = filterInfoMap.get(Long.valueOf(row.get(CAMPAIGN_ID_COLUMN).toString()));
            if (campaignFilterInfo != null && !campaignFilterInfo.isEmpty() && campaignFilterInfo.containsKey(FILTER_NAME_FIELD)) {
                String filterName = campaignFilterInfo.getOrDefault(FILTER_NAME_FIELD, "--").toString();
                row.put(FILTER_NAME_COLUMN, filterName);
            } else {
                row.put(FILTER_NAME_COLUMN, "--");
            }
        }
    }

    private void updateRowEngageInfo(CampaignEngageBatchContext batchContext, Map<String, Object> row, List<String> engageDims) {
        if (!row.containsKey(ENGAGE_CODE_COLUMN) || row.get(ENGAGE_CODE_COLUMN) == null
                || StringUtils.isBlank(row.get(ENGAGE_CODE_COLUMN).toString())) {
            log.info("engageId code null in row, row: {}", row);
            //如果没有engageCode，可能有两种情况：1. 没有其他engageLeve的维度，2. 其他engage自定义属性的维度
            //对于 1. 就没有其他enage的属性需要补充值了
            //对于 2. 这些维度应该出现在 row 中，也就是直接通过 sql 原始数据查询得到
        } else {
            Map<String, Map<String, Object>> engageInfoMap = batchContext.getEngageInfoMap().values().stream()
                    .filter(ei -> ei.containsKey(ENGAGE_CODE_FIELD) && StringUtils.isNotBlank(ei.get(ENGAGE_CODE_FIELD).toString()))
                    .collect(Collectors.toMap( //TODO engageCode 可能跨campaign复用
                            ei -> ei.get(ENGAGE_CODE_FIELD).toString(),
                            ei -> ei
                    ));
            Map<String, Object> engageInfo = engageInfoMap.getOrDefault(row.get(ENGAGE_CODE_COLUMN).toString(), emptyMap());
            for (String engageDim : engageDims) {
                String rowColumnKey = NamingUtils.toUnderScoreCase(engageDim);
                Object engageRowValue = row.getOrDefault(rowColumnKey, null);
                boolean engageRowValueIsBlank = engageRowValue == null || StringUtils.isBlank(engageRowValue.toString());
                if (engageRowValueIsBlank && engageInfo.containsKey(engageDim)) {
                    row.put(rowColumnKey, engageInfo.get(engageDim));
                }
            }

        }
    }

    static void updateRowCampaignInfo(CampaignEngageBatchContext batchContext, Map<String, Object> row, List<String> campaignDims) {
        Map<Long, Map<String, Object>> campaignInfoMap = batchContext.getCampaignInfoMap();
        if (!row.containsKey(CAMPAIGN_ID_COLUMN) || row.get(CAMPAIGN_ID_COLUMN) == null
                || !StringUtils.isNumeric(row.get(CAMPAIGN_ID_COLUMN).toString())) {
            log.warn("campaignId is null in row, row: {}", row);
            return;
        }
        Map<String, Object> campaignInfo = campaignInfoMap.getOrDefault(Long.valueOf(row.get(CAMPAIGN_ID_COLUMN).toString()), emptyMap());
        for (String campaignDim : campaignDims) {
            String rowColumnKey = NamingUtils.toUnderScoreCase(campaignDim);
            Object campaignRowValue = row.getOrDefault(rowColumnKey, null);
            boolean campaignRowValueIsBlank = campaignRowValue == null || StringUtils.isBlank(campaignRowValue.toString());
            if (campaignRowValueIsBlank && campaignInfo.containsKey(campaignDim)) {
                row.put(rowColumnKey, campaignInfo.get(campaignDim));
            }
        }
    }


    private CampaignReportQueryOptions validateQueryAndGetReportQueryOptions(CampaignReportQuery reportQuery) {

        CampaignReportQueryOptions queryOptions = reportQuery.createQueryOptions();
        List<Long> reportCampaignIds = reportQuery.getCampaignIds();

        if (CollectionUtils.isEmpty(reportCampaignIds)) {
            throw new BusinessException(VALIDATION_ERROR.getCode(), "MSG_108_000034", "CampaignIds are required.");
        }

        //设置默认的对照组维度，也就是不设置
        ControlGroupType queryControlGroup = queryOptions.getControlGroupType();
        //如果查询中有对照组维度，需要验证所有的营销活动，是否有同一类型的对照组，
        // 如果不是，则报错，如果是，则更新queryOptions中的对照组类型
        if (queryControlGroup != ControlGroupType.NOT_SET) {
            List<Long> campaignIdsNotMatchControlGroup = getCampaignIdsNotMatchControlGroup(reportCampaignIds, queryControlGroup);
            if (!CollectionUtils.isEmpty(campaignIdsNotMatchControlGroup)) {
               queryOptions.setViolationCampaignIds(campaignIdsNotMatchControlGroup);
                reportCampaignIds = reportCampaignIds.stream().filter(cid -> !campaignIdsNotMatchControlGroup.contains(cid)).collect(Collectors.toList());
            }
        }
        queryOptions.setReportCampaignIds(reportCampaignIds);
        return queryOptions;
    }

    private static String getErrorMessage(Map<ControlGroupType, List<Long>> controlGroupTypeListMap) {
        return Arrays.stream(ControlGroupType.values())
                .filter(controlGroupTypeListMap::containsKey)
                .map(cgt -> String.format("campaignIds(%s): %s, ", cgt, controlGroupTypeListMap.get(cgt)))
                .collect(Collectors.joining(", "));
    }

    /**
     * @param eventRawStat event原始的统计数据，Map数据格式是: [dateUnit as GROUP_DATE_FIELD, batchId: $batchId, event: $eventId, cnt: $groupCount] <br/>
     *                     所以输入的eventId需要转换成eventStage
     * @param groupRawStat 分群的原始统计数据，Map数据Key：[
     *                     campaign_id, campaign_filtered_flag , campaign_control_flag,
     *                     engage_id, dateUnit as GROUP_DATE_FIELD,
     *                     engage_filtered_flag , engage_control_flag,
     *                     count(%s profile_id) as cnt
     *                     ]
     */
    public List<CampaignReportDataLineDto> getCampaignReportLines(
            List<Map<String, Object>> eventRawStat, List<Map<String, Object>> groupRawStat,
            CampaignEngageBatchContext batchContext,
            CampaignReportQueryOptions queryOptions) {

        List<CampaignReportDataLineDto> dataLine = new ArrayList<>();

        Map<String, String> eventStageMap = getEventStageMap();

        /**
         * 首先实现的是，包含所有的维度[campaignId, engageId, dateUnit, batchId]，先不考虑维度有聚合的情况
         * 理论上，其他的情况也可以在这个最细粒度维度的基础上聚合完成。
         */

        // 格式化 eventRawStat
        // eventRawStat 是按照[dateUnit, groupId, eventId, cnt] 的格式输入的，第一步预处理得到的数据格式是 [dateUnit, batchId, eventStage, cnt]
        // 之后参考batch 维度信息，按照 [campaignId, engageId, dateUnit] 的维度聚合，
        // 预处理后期望得到的是 [ keyBy(campaignId, engageId, dateUnit), group of eventRawStat]
        Map<GroupAggregateDim, List<Map<String, Object>>> eventRawStatMap =
                aggregateEventRawStatByEngageAndDateUnit(eventRawStat, batchContext, eventStageMap);

        // 格式化 groupRawStat
        // groupRawStat 数据是原始的从table group by 之后得到的数据，这里需要根据维度[campaignId, engageId, dateUnit] 聚合一次。
        // 预处理后期望得到的是 [ keyBy(campaignId, engageId, dateUnit), group of groupRawStat]
        Map<GroupAggregateDim, List<Map<String, Object>>> groupRawStatMap = groupRawStat.stream().collect(
                Collectors.groupingBy(GroupAggregateDim::new));

        //foreach groupRawStatMap.entrySet()
        for (Map.Entry<GroupAggregateDim, List<Map<String, Object>>> rawStatEntry : groupRawStatMap.entrySet()) {
            GroupAggregateDim groupAggregateDim = rawStatEntry.getKey();
            List<Map<String, Object>> groupRawStatList = rawStatEntry.getValue();
            List<Map<String, Object>> eventRawStatList = CollectionUtils.isEmpty(eventRawStatMap.get(groupAggregateDim)) ?
                    emptyList() : eventRawStatMap.get(groupAggregateDim);
            CampaignReportDataLineDto campaignReportDataLineDto = new CampaignReportDataLineDto(groupAggregateDim, groupRawStatList, eventRawStatList);
            dataLine.add(campaignReportDataLineDto);
        }

        return dataLine;
    }

    public Map<String, String> getEventStageMap() {
        List<CampaignChannelEventStageDto> channelEventStageList = getChannelEventStageList();
        return channelEventStageList.stream()
                .flatMap(stageDto -> stageDto.getFieldEventStageMap().entrySet().stream())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    private Map<GroupAggregateDim, List<Map<String, Object>>> aggregateEventRawStatByEngageAndDateUnit(
            List<Map<String, Object>> eventRawStat, CampaignEngageBatchContext batchContext,
            Map<String, String> eventStageMap) {

        Map<String, CampaignEngageBatchContext.CampaignEngageBatchDim> batchInfoMap = batchContext.getBatchInfoMap();
        return eventRawStat.stream()
                .filter(rawEvent -> eventStageMap.containsKey(rawEvent.get("event")))
                .map(rawEvent -> {
                    String eventId = (String) rawEvent.get("event");
                    Map<String, Object> mapWithEventStage = new HashMap<>(rawEvent);
                    String eventStage = eventStageMap.get(eventId);
                    Assert.notNull(eventStage, String.format("eventId: %s has empty eventStage, the eventStageMap: %s", eventId, eventStageMap));
                    mapWithEventStage.put("eventStage", eventStage);
                    return mapWithEventStage;
                }).collect(Collectors.groupingBy(
                        er -> {
                            String dateUnit = (String) er.get(GROUP_DATE_COLUMN);
                            String batchId = (String) er.get(BATCH_ID_COLUMN);
                            CampaignEngageBatchContext.CampaignEngageBatchDim batchDim = batchInfoMap.get(batchId);
                            return new GroupAggregateDim(batchDim.getCampaignId(), batchDim.getEngageId(), dateUnit);
                        }
                ));
    }

    private CampaignEngageBatchContext initCampaignEngageBatchContext(List<Long> campaignIds) {

        try {
            List<CampaignEngageBatchContext.CampaignEngageBatchDim> batchDimList = new ArrayList<>();
            List<CampaignBatchInfo> campaignBatchInfos = campaignBatchInfoMapper.selectByBatchCampaignIds(campaignIds);

            Map<Long, MarketingCampaign> campaignMap = getCampaignMap(campaignIds);
            Map<Long, CampaignAudienceStrategy> campaignAudienceStrategyMap = getCampaignAudienceStrategyMap(campaignIds);
            Map<Long, String> campaignIdCodeMap = campaignMap.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().getUuid()));
            Map<Long, Map<String, Object>> campaignInfoMap = campaignMetaService.getCampaignInfoMap(campaignIdCodeMap);
            Map<Long, Map<String, Object>> enagegeInfoMap = getEnagegeInfoMap(campaignIds);
            Map<Long, List<CampaignListInfo>> campaignListMap = getCampaignListMap(campaignIds);
            Map<Long, Map<String, Object>> filterInfoMap = getFilterInfoMap(campaignIds);

            for (CampaignBatchInfo campaignBatchInfo : campaignBatchInfos) {
                Long engageId = campaignBatchInfo.getEngageId();
                Long campaignId = campaignBatchInfo.getCampaignId();
                Map<String, Object> engageInfo = enagegeInfoMap.get(engageId);
                MarketingCampaign campaign = campaignMap.get(campaignId);

                CampaignEngageBatchContext.CampaignEngageBatchDim batchDim = CampaignEngageBatchContext.CampaignEngageBatchDim.builder()
                        .campaignCode(campaign.getUuid())
                        .campaignName(campaign.getTitle())
                        .campaignId(campaign.getId())
                        .engageId(engageId)
                        .engageCode((String) engageInfo.get(ENGAGE_CODE_FIELD))
                        .engageName((String) engageInfo.get(ENGAGE_CODE_FIELD)) //engage has no name, use code instead
                        .flowId(campaignBatchInfo.getFlowId())
                        .channelType(campaignBatchInfo.getChannelType())
                        .messagingType(campaignBatchInfo.getMessagingType())
                        .templateId(campaignBatchInfo.getTemplateId())
                        .templateName(campaignBatchInfo.getTemplateName())
                        .batchId(campaignBatchInfo.getBatchId())
                        .build();
                batchDimList.add(batchDim);
            }

            return new CampaignEngageBatchContext(batchDimList, campaignInfoMap, enagegeInfoMap, campaignListMap, filterInfoMap, campaignAudienceStrategyMap);
        } catch (Exception e) {
            throw new IllegalStateException("failed to init CampaignEngageBatchContext with exception: ", e);
        }
    }

    public Map<Long, List<CampaignListInfo>> getCampaignListMap(List<Long> campaignIds) {
        List<CampaignListInfo> campaignListInfos = campaignListInfoMapper.selectByBatchCampaignId(campaignIds);
        return campaignListInfos.stream().collect(Collectors.groupingBy(CampaignListInfo::getCampaignId));
    }

    public boolean isValidControlGroup(String controlGroupName) {
        return true;
    }
}
