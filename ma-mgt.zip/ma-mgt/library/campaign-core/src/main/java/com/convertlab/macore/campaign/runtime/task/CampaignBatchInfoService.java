package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.foundation.library.jdbc.datasource.lookup.DataSourceLookupHelper;
import com.convertlab.macore.campaign.mapper.CampaignBatchInfoMapper;
import com.convertlab.macore.campaign.model.dto.ChannelInfo;
import com.convertlab.macore.campaign.model.dto.SaveFlowResponse;
import com.convertlab.macore.campaign.model.entity.CampaignBatchInfo;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

@Service
@Slf4j
@RequiredArgsConstructor
public class CampaignBatchInfoService {

    final CampaignBatchInfoMapper campaignBatchInfoMapper;

    public void refreshBatchInfo( long campaignId, long engageId, List<CampaignBatchInfo> batchInfos){
        List<CampaignBatchInfo> campaignBatchInfos = selectBatchInfo(campaignId, engageId);
        campaignBatchInfos.forEach(batchInfo -> {
            deleteBatchInfo(batchInfo);
        });
        saveBatchInfo(batchInfos);
    }

    public void saveBatchInfo( List<CampaignBatchInfo> batchInfos){
        DataSourceLookupHelper.withLookupKey("main", () -> {
            batchInfos.forEach(batchInfo -> {
                campaignBatchInfoMapper.insert(batchInfo);
            });
        });
    }

    public void deleteBatchInfo(CampaignBatchInfo info){
        DataSourceLookupHelper.withLookupKey("main", () -> {
             campaignBatchInfoMapper.deleteById(info);
        });
    }
    public List<CampaignBatchInfo> selectBatchInfo(long campaignId, long engageId){
        AtomicReference<List<CampaignBatchInfo>> campaignBatchInfos = new AtomicReference<>();
        DataSourceLookupHelper.withLookupKey("main", () -> {
            campaignBatchInfos.set(campaignBatchInfoMapper.selectByCampaignIdAndEngageId(campaignId, engageId));
        });
        return campaignBatchInfos.get();
    }

}
