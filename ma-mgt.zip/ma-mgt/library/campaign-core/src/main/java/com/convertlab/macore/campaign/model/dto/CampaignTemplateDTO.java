package com.convertlab.macore.campaign.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Map;

@Data
public class CampaignTemplateDTO implements Serializable {

    private Long id;

    private String templateName;

    private String description;

    private String status;

    private int useCnt;

    private Integer folderId;

    private Map<String, Object> attrs;

    private String executionMode;

    private Map<String, Object> campaignStrategy;

    private Map<String, Object> outboundEngageStrategy;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime lastUpdated;
}
