package com.convertlab.macore.campaign.service;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.jdbc.datasource.lookup.DataSourceLookupHelper;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.campaign.common.utils.BeanCopyUtils;
import com.convertlab.macore.campaign.mapper.CampaignChannelConditionMapper;
import com.convertlab.macore.campaign.model.dto.CampaignChannelConditionDTO;
import com.convertlab.macore.campaign.model.entity.CampaignChannelCondition;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

@Service
@Slf4j
@DataSourceLookup("main")
@RequiredArgsConstructor
public class CampaignChannelConditionService {

    private final CampaignChannelConditionMapper campaignChannelConditionMapper;

    @SuppressWarnings("unchecked")
    public List<CampaignChannelConditionDTO> list(){
        QueryWrapper<CampaignChannelCondition> queryWrapper = new QueryWrapper<>();
        List<CampaignChannelCondition> results = campaignChannelConditionMapper.selectList(queryWrapper);

        List<CampaignChannelConditionDTO> dtos = new ArrayList<>();
        for (CampaignChannelCondition result : results) {
            CampaignChannelConditionDTO dto = new CampaignChannelConditionDTO();
            dto.setChannelType(result.getChannelType());
            dto.setMessagingType(result.getMessagingType());
            dto.setFilterCondition(result.getFilterCondition() == null ? null : JsonUtils.instanceOfDto().json2Obj(result.getFilterCondition(), HashMap.class));
            dtos.add(dto);
        }
        return BeanCopyUtils.copyList(results, CampaignChannelConditionDTO::new);
    }

    public int save(CampaignChannelConditionDTO dto) {
        QueryWrapper<CampaignChannelCondition> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("channel_type", dto.getChannelType());
        queryWrapper.eq("messaging_type", dto.getMessagingType());
        CampaignChannelCondition campaignChannelCondition = campaignChannelConditionMapper.selectOne(queryWrapper);
        //如果不存在，则插入新的condition。
        if (campaignChannelCondition == null) {
            campaignChannelCondition = new CampaignChannelCondition();
            campaignChannelCondition.setChannelType(dto.getChannelType());
            campaignChannelCondition.setMessagingType(dto.getMessagingType());
            campaignChannelCondition.setFilterCondition(dto.getFilterCondition() == null ? null : JsonUtils.instanceOfDto().obj2Json(dto.getFilterCondition()));
            return campaignChannelConditionMapper.insert(campaignChannelCondition);
        } else {
            campaignChannelCondition.setFilterCondition(dto.getFilterCondition() == null ? null : JsonUtils.instanceOfDto().obj2Json(dto.getFilterCondition()));
            return campaignChannelConditionMapper.updateById(campaignChannelCondition);
        }
    }

    public CampaignChannelCondition getByChannelTypeAndMessagingType(String channelType, String messagingType){
        AtomicReference<CampaignChannelCondition> campaignChannelCondition = new AtomicReference<>();
        DataSourceLookupHelper.withLookupKey("main", () -> {
            QueryWrapper<CampaignChannelCondition> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("channel_type", channelType);
            queryWrapper.eq("messaging_type", messagingType);
            campaignChannelCondition.set(campaignChannelConditionMapper.selectOne(queryWrapper));
        });
        return campaignChannelCondition.get();
    }
}
