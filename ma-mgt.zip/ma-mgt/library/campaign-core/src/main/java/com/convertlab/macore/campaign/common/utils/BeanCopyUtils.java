package com.convertlab.macore.campaign.common.utils;

import org.springframework.cglib.beans.BeanCopier;
import org.springframework.cglib.core.Converter;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class BeanCopyUtils {

    private static final ConcurrentHashMap<String, BeanCopier> BEAN_COPIER_MAP = new ConcurrentHashMap<>();

    /**
     * Bean属性复制工具方法。
     *
     * @param source   目标对象
     * @param supplier 目标类::new(eg: UserVO::new)
     */
    public static <T> T copyBean(Object source, Supplier<T> supplier) {
        T t = supplier.get();
        getBeanCopier(source.getClass(), t.getClass()).copy(source, t, getConverter());
        return t;
    }

    /**
     * Bean属性复制工具方法，支持忽略字段
     *
     * @param source       目标对象
     * @param supplier     目标类::new(eg: UserVO::new)
     * @param ignoreFields 忽略的字段
     */
    public static <T> T copyBean(Object source, Supplier<T> supplier, String... ignoreFields) {
        T t = supplier.get();
        Set<String> ignoreFieldSet = Arrays.stream(ignoreFields)
                .map(field -> "set" + Character.toUpperCase(field.charAt(0)) + field.substring(1))
                .collect(Collectors.toSet());
        getBeanCopier(source.getClass(), t.getClass()).copy(source, t, getConverter(ignoreFieldSet));
        return t;
    }

    /**
     * Bean属性集合复制工具方法。
     *
     * @param sources   原始集合
     * @param supplier: 目标类::new(eg: UserVO::new)
     */
    public static <S, T> List<T> copyList(List<S> sources, Supplier<T> supplier) {
        List<T> list = new ArrayList<>(sources.size());
        if (sources.size() != 0) {
            BeanCopier beanCopier = getBeanCopier(sources.get(0).getClass(), supplier.get().getClass());
            for (S source : sources) {
                T t = supplier.get();
                beanCopier.copy(source, t, getConverter());
                list.add(t);
            }
        }
        return list;
    }

    /**
     * Bean属性集合复制工具方法，支持忽略字段
     *
     * @param sources      原始集合
     * @param supplier     目标类::new(eg: UserVO::new)
     * @param ignoreFields 忽略的字段
     */
    public static <S, T> List<T> copyList(List<S> sources, Supplier<T> supplier, String... ignoreFields) {
        List<T> list = new ArrayList<>(sources.size());
        if (sources.size() != 0) {
            Set<String> ignoreFieldSet = Arrays.stream(ignoreFields)
                    .map(field -> "set" + Character.toUpperCase(field.charAt(0)) + field.substring(1))
                    .collect(Collectors.toSet());
            BeanCopier beanCopier = getBeanCopier(sources.get(0).getClass(), supplier.get().getClass());
            for (S source : sources) {
                T t = supplier.get();
                beanCopier.copy(source, t, getConverter(ignoreFieldSet));
                list.add(t);
            }
        }
        return list;
    }

    /**
     * 获取BeanCopier对象 如果缓存中有从缓存中获取 如果没有则新创建对象并加入缓存
     */
    private static BeanCopier getBeanCopier(Class<?> sourceClass, Class<?> targetClass) {
        String key = getKey(sourceClass.getName(), targetClass.getName());
        BeanCopier beanCopier;
        beanCopier = BEAN_COPIER_MAP.get(key);
        if (beanCopier == null) {
            beanCopier = BeanCopier.create(sourceClass, targetClass, true);
            BEAN_COPIER_MAP.put(key, beanCopier);
        }
        return beanCopier;
    }

    /**
     * 生成缓存key
     */
    private static String getKey(String sourceClassName, String targetClassName) {
        return sourceClassName + targetClassName;
    }

    @SuppressWarnings("unchecked")
    private static Converter getConverter() {
        return (source, target, o1) -> {
            if ((source instanceof Instant) && (target.isAssignableFrom(LocalDateTime.class))) {
                return LocalDateTime.ofInstant((Instant) source, ZoneId.systemDefault());
            } else if ((source instanceof LocalDateTime) && (target.isAssignableFrom(Instant.class))) {
                return ((LocalDateTime) source).toInstant(ZoneOffset.UTC);
            } else if ((source instanceof Map || source instanceof List) && (target.isAssignableFrom(String.class))) {
                return JacksonUtils.toJSONString(source);
            } else if ((source instanceof String) && (target.isAssignableFrom(Map.class))) {
                return JacksonUtils.parseObject(source.toString(), Map.class);
            } else if ((source instanceof String) && (target.isAssignableFrom(List.class))) {
                return JacksonUtils.parseObject(source.toString(), List.class);
            } else {
                return source;
            }
        };
    }

    @SuppressWarnings("unchecked")
    private static Converter getConverter(Set<String> ignoreFieldSet) {
        return (source, target, o1) -> {
            if (ignoreFieldSet.contains(o1.toString())) {
                return null;
            }

            if ((source instanceof Instant) && (target.isAssignableFrom(LocalDateTime.class))) {
                return LocalDateTime.ofInstant((Instant) source, ZoneId.systemDefault());
            } else if ((source instanceof LocalDateTime) && (target.isAssignableFrom(Instant.class))) {
                return ((LocalDateTime) source).toInstant(ZoneOffset.UTC);
            } else if ((source instanceof Map || source instanceof List) && (target.isAssignableFrom(String.class))) {
                return JacksonUtils.toJSONString(source);
            } else if ((source instanceof String) && (target.isAssignableFrom(Map.class))) {
                return JacksonUtils.parseObject(source.toString(), Map.class);
            } else if ((source instanceof String) && (target.isAssignableFrom(List.class))) {
                return JacksonUtils.parseObject(source.toString(), List.class);
            } else {
                return source;
            }
        };
    }

}
