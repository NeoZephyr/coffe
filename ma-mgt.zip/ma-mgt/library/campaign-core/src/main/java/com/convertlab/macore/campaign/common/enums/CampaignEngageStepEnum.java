package com.convertlab.macore.campaign.common.enums;

import com.convertlab.macore.campaign.model.dto.CampaignEngageStepDTO;
import lombok.Getter;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Getter
public enum CampaignEngageStepEnum {
    GENERATE_FLOW("GenerateFlow", "搭建自动流"),
    SEGMENTATION("Segmentation", "创建人群包"),
    RUNNING("Running", "运行中"),
    STOP_CAMPAIGN("StopCampaign", "已停止"),
    ;
    private final String name;
    private final String desc;

    CampaignEngageStepEnum(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }

    public static List<CampaignEngageStepDTO> toList() {
        return Arrays.stream(CampaignEngageStepEnum.values()).map(e -> new CampaignEngageStepDTO(e.getName(), "", null)).collect(Collectors.toList());
    }
}