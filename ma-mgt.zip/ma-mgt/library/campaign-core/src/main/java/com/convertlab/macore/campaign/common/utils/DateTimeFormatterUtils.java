package com.convertlab.macore.campaign.common.utils;

import java.time.format.DateTimeFormatter;

public class DateTimeFormatterUtils {

    private static final DateTimeFormatter SIMPLE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final DateTimeFormatter STANDARD_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
    private static final DateTimeFormatter YEAR_MONTH_FORMATTER = DateTimeFormatter.ofPattern("yyyy.MM");

    public static DateTimeFormatter standardFormat() {
        return STANDARD_FORMATTER;
    }

    public static DateTimeFormatter simpleFormat() {
        return SIMPLE_FORMATTER;
    }

    public static DateTimeFormatter yearMonthFormat() {
        return YEAR_MONTH_FORMATTER;
    }
}
