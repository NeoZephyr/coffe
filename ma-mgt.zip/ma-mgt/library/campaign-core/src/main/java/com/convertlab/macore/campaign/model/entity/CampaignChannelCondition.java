package com.convertlab.macore.campaign.model.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.convertlab.foundation.library.mybatisplus.entity.BaseTenantEntity;
import lombok.*;

import java.io.Serializable;

@Data
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TableName(value = "campaign_channel_condition", excludeProperty = {"version", "creatorId", "updaterId", "creatorName", "updaterName"})
public class CampaignChannelCondition extends BaseTenantEntity implements Serializable {

    @TableId(value = "id", type = IdType.AUTO)
    Long id;

    @TableField("channel_type")
    String channelType;

    @TableField("messaging_type")
    String messagingType;

    @TableField(value = "filter_condition", updateStrategy = FieldStrategy.ALWAYS)
    String filterCondition;

}
