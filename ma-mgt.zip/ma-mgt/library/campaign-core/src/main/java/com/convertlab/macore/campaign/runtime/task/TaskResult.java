package com.convertlab.macore.campaign.runtime.task;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
public class TaskResult {

    public TaskResult(boolean isFinish, boolean isFailed, String message) {
        this.isFinish = isFinish;
        this.isFailed = isFailed;
        this.message = message;
    }
    public TaskResult(boolean isFinish) {
        this.isFinish = isFinish;
    }

    boolean isFinish;
    boolean isFailed;
    String message;
}
