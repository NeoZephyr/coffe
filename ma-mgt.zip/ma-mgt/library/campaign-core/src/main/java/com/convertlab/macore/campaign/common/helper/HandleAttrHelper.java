package com.convertlab.macore.campaign.common.helper;


import cn.hutool.core.lang.TypeReference;
import cn.hutool.core.map.MapUtil;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.service.legacy.cms.client.CustomerServiceClient;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.springframework.stereotype.Component;

import java.beans.PropertyDescriptor;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Component
public class HandleAttrHelper {

    private final CustomerServiceClient customerServiceClient;

    public HandleAttrHelper(CustomerServiceClient customerServiceClient) {
        this.customerServiceClient = customerServiceClient;
    }

    public void setCampaignAttr(Map<String, Object> attrMap, MarketingCampaign campaign) {
        List<Map<String, Object>> metaRows = getCampaignMeta();
        Map<String, String> metaMap = metaRows.stream().filter(row -> !MapUtil.getBool(row, "isSystemMeta")).collect(Collectors.toMap(
                row -> MapUtil.getStr(row, "name"),
                row -> MapUtil.getStr(row, "attr")));

        attrMap.forEach((key, value) -> {
            try {
                if (metaMap.containsKey(key)) {
                    BeanUtils.setProperty(campaign, metaMap.get(key), value);
                }
            } catch (Exception e) {
                log.error("set campaign attr error", e);
            }
        });
    }

    public Map<String, Object> getCampaignAttr(MarketingCampaign campaign) {
        List<Map<String, Object>> metaRows = getCampaignMeta();
        Map<String, String> metaMap = metaRows.stream().filter(row -> !MapUtil.getBool(row, "isSystemMeta")).collect(Collectors.toMap(
                row -> MapUtil.getStr(row, "attr"),
                row -> MapUtil.getStr(row, "name")));

        Map<String, Object> attrMap = MapUtil.newHashMap();
        PropertyDescriptor[] propertyNames = PropertyUtils.getPropertyDescriptors(campaign);
        for (PropertyDescriptor propertyName : propertyNames) {
            if (propertyName.getName().startsWith("attr")) {
                try {
                    String value = BeanUtils.getProperty(campaign, propertyName.getName());
                    if (metaMap.containsKey(propertyName.getName())) {
                        attrMap.put(metaMap.get(propertyName.getName()), value);
                    }
                } catch (Exception e) {
                    log.error("get campaign attr error", e);
                }
            }
        }
        return attrMap;
    }

    private List<Map<String, Object>> getCampaignMeta() {
        Map<String, Object> campaignMeta = customerServiceClient.getCampaignMeta();
        return MapUtil.get(campaignMeta, "rows", new TypeReference<List<Map<String, Object>>>() {
        });
    }

}

