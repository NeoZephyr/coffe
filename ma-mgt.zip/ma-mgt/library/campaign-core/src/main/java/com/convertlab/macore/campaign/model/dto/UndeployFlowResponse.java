package com.convertlab.macore.campaign.model.dto;

import lombok.Data;

import java.util.List;

@Data
public class UndeployFlowResponse {

    boolean success;
    List<String> content;

}
