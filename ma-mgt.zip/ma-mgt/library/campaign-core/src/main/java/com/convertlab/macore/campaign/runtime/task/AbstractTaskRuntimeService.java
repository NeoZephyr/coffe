package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.foundation.library.context.Context;
import com.convertlab.macore.campaign.mapper.CampaignExecutionTaskDataMapper;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTaskData;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.service.CampaignService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@RequiredArgsConstructor
@Component
public abstract  class AbstractTaskRuntimeService implements ITaskRuntimeService{


    public static final String DATA_KEY_LIST_FOLDER_ID = "listFolderId";
    public static final String DATA_KEY_FLOW_FOLDER_ID = "flowFolderId";


    @Autowired
    protected CampaignService campaignService;

    @Autowired
    protected CampaignTaskService campaignTaskService;

    @Autowired
    protected CampaignExecutionTaskDataMapper campaignExecutionTaskDataMapper;

    @Autowired
    protected ObjectMapper objectMapper;


    @Override
    public TaskResult start(CampaignExecutionTask task) {
        return onStart(task);
    }

    @Override
    public void stop(CampaignExecutionTask task) {
        //TODO
    }

    @Override
    public void finish(CampaignExecutionTask task) {
        //更新当前task的状态。
        campaignTaskService.updateTaskStatus(task, CampaignExecutionTask.TASK_STATUS_FINISHED);
    }

    public abstract TaskResult onStart(CampaignExecutionTask task);

    public abstract void onFinish(CampaignExecutionTask task);

}
