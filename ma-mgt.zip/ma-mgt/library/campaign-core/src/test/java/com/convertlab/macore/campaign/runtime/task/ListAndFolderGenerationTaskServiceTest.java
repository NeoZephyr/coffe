package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.macore.campaign.common.utils.AudienceStrategyConstants;
import com.convertlab.macore.campaign.common.utils.ControlGroupStrategyConstants;
import com.convertlab.macore.campaign.common.utils.NameUtils;
import com.convertlab.macore.campaign.model.dto.CampaignDTO;
import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.dto.FolderDTO;
import com.convertlab.macore.campaign.model.dto.ListDTO;
import com.convertlab.macore.campaign.model.entity.*;
import com.convertlab.macore.campaign.service.CampaignService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class ListAndFolderGenerationTaskServiceTest {

    @Mock
    private CampaignOutboundEngage outboundEngage;
    ObjectMapper objectMapper = new ObjectMapper();
    private CampaignFullDataDTO mockCampaignFullDataDTO;
    private CampaignAudienceStrategy mockAudienceStrategy;
    private List<CampaignOutboundEngage> mockOutboundEngages;
    @Mock
    private MaCoreService maCoreService;
    @Mock
    private CampaignTaskService campaignTaskService;
    @Mock
    private CampaignListInfoService campaignListInfoService;
    @Mock
    private CampaignService campaignService;

    @InjectMocks
    ListAndFolderGenerationTaskService listAndFolderGenerationTaskService;

    @Test
    void getManualSpecifiedListId_ValidAudienceData_ReturnsListId() throws JsonProcessingException {

        listAndFolderGenerationTaskService.objectMapper = objectMapper;
        String audienceData = "{\"listId\": \"123\"}";
        when(outboundEngage.getAudienceStrategy()).thenReturn(AudienceStrategyConstants.MANUAL_SPECIFIED_SEGMENTATION);
        when(outboundEngage.getAudienceData()).thenReturn(audienceData);

        long listId = listAndFolderGenerationTaskService.getManualSpecifiedListId(outboundEngage);

        assertEquals(123L, listId);
    }

    @Test
    void getManualSpecifiedListId_NullOutboundEngage_ThrowsException() {
        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> listAndFolderGenerationTaskService.getManualSpecifiedListId(null)
        );

        assertEquals("outboundEngage is null", exception.getMessage());
    }

    @Test
    void getManualSpecifiedListId_IncorrectAudienceStrategy_ThrowsException() {
        when(outboundEngage.getAudienceStrategy()).thenReturn("SOME_OTHER_STRATEGY");

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> listAndFolderGenerationTaskService.getManualSpecifiedListId(outboundEngage)
        );

        assertEquals("Audience strategy is not MANUAL_SPECIFIED_SEGMENTATION", exception.getMessage());
    }

    @Test
    void getManualSpecifiedListId_MalformedAudienceData_ThrowsException() throws JsonProcessingException {
        String audienceData = "malformed json";
        when(outboundEngage.getAudienceStrategy()).thenReturn(AudienceStrategyConstants.MANUAL_SPECIFIED_SEGMENTATION);
        when(outboundEngage.getAudienceData()).thenReturn(audienceData);
        listAndFolderGenerationTaskService.objectMapper = objectMapper;

        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> listAndFolderGenerationTaskService.getManualSpecifiedListId(outboundEngage)
        );

        assertTrue(exception.getMessage().contains("Failed to parse audienceData"));
    }

    @Test
    void createCampaignListInfo_WithCampaignIdListTypeListName_ReturnsCorrectInfo() {
        long campaignId = 1L;
        String listType = "main";
        String listName = "Main List";

        CampaignListInfo info = listAndFolderGenerationTaskService.createCampaignListInfo(campaignId, listType, listName);

        assertNotNull(info);
        assertEquals(campaignId, info.getCampaignId());
        assertEquals(listType, info.getListType());
        assertEquals(listName, info.getListName());
    }

    @Test
    void createCampaignListInfo_WithCampaignIdEngageIdListTypeListName_ReturnsCorrectInfo() {
        long campaignId = 1L;
        long engageId = 2L;
        String listType = "main";
        String listName = "Main List";

        CampaignListInfo info = listAndFolderGenerationTaskService.createCampaignListInfo(campaignId, engageId, listType, listName);

        assertNotNull(info);
        assertEquals(campaignId, info.getCampaignId());
        assertEquals(engageId, info.getEngageId());
        assertEquals(listType, info.getListType());
        assertEquals(listName, info.getListName());
    }

    // Additional tests for createMainGroup, createTargetGroup, createControlGroup, createFilteredGroup, createExcludedGroup
    // would follow a similar structure, asserting the correct properties are set based on the method called.

    // Example test for createMainGroup
    @Test
    void createMainGroup_WithCampaignId_ReturnsCorrectInfo() {
        long campaignId = 1L;
        CampaignListInfo info = listAndFolderGenerationTaskService.createMainGroup(campaignId);

        assertNotNull(info);
        assertEquals(campaignId, info.getCampaignId());
        assertEquals(NameUtils.MAIN_GROUP, info.getListType());
        assertEquals(NameUtils.getMainListName(campaignId), info.getListName());
    }

    @Test
    void createMainGroup_WithCampaignIdAndEngageId_ReturnsCorrectInfo() {
        long campaignId = 1L;
        long engageId = 2L;

        CampaignListInfo info = listAndFolderGenerationTaskService.createMainGroup(campaignId, engageId);

        assertNotNull(info);
        assertEquals(campaignId, info.getCampaignId());
        assertEquals(engageId, info.getEngageId());
        assertEquals(NameUtils.MAIN_GROUP, info.getListType());
        assertEquals(NameUtils.getMainListName(campaignId, engageId), info.getListName());
    }


    @Test
    void createTargetGroup_WithCampaignId_ReturnsCorrectInfo() {
        long campaignId = 1L;
        CampaignListInfo info = listAndFolderGenerationTaskService.createTargetGroup(campaignId);

        assertEquals(campaignId, info.getCampaignId());
        assertEquals(NameUtils.TARGET_GROUP, info.getListType());
    }

    @Test
    void createTargetGroup_WithCampaignIdAndEngageId_ReturnsCorrectInfo() {
        long campaignId = 1L;
        long engageId = 2L;

        CampaignListInfo info = listAndFolderGenerationTaskService.createTargetGroup(campaignId, engageId);

        assertEquals(campaignId, info.getCampaignId());
        assertEquals(engageId, info.getEngageId());
        assertEquals(NameUtils.TARGET_GROUP, info.getListType());
    }


    @Test
    void createControlGroup_WithCampaignId_ReturnsCorrectInfo() {
        long campaignId = 1L;
        CampaignListInfo info = listAndFolderGenerationTaskService.createControlGroup(campaignId);

        assertEquals(campaignId, info.getCampaignId());
        assertEquals(NameUtils.CONTROL_GROUP, info.getListType());
    }

    @Test
    void createControlGroup_WithCampaignIdAndEngageId_ReturnsCorrectInfo() {
        long campaignId = 1L;
        long engageId = 2L;

        CampaignListInfo info = listAndFolderGenerationTaskService.createControlGroup(campaignId, engageId);

        assertEquals(campaignId, info.getCampaignId());
        assertEquals(engageId, info.getEngageId());
        assertEquals(NameUtils.CONTROL_GROUP, info.getListType());
    }

    @Test
    void createFilterGroup_WithCampaignId_ReturnsCorrectInfo() {
        long campaignId = 1L;
        CampaignListInfo info = listAndFolderGenerationTaskService.createFilteredGroup(campaignId);

        assertEquals(campaignId, info.getCampaignId());
        assertEquals(NameUtils.FILTERED_GROUP, info.getListType());
    }

    @Test
    void createFilterGroup_WithCampaignIdAndEngageId_ReturnsCorrectInfo() {
        long campaignId = 1L;
        long engageId = 2L;

        CampaignListInfo info = listAndFolderGenerationTaskService.createFilteredGroup(campaignId, engageId);

        assertEquals(campaignId, info.getCampaignId());
        assertEquals(engageId, info.getEngageId());
        assertEquals(NameUtils.FILTERED_GROUP, info.getListType());
    }



    @Test
    void creatExcludedGroup_WithCampaignId_ReturnsCorrectInfo() {
        long campaignId = 1L;
        CampaignListInfo info = listAndFolderGenerationTaskService.createExcludedGroup(campaignId);

        assertEquals(campaignId, info.getCampaignId());
        assertEquals(NameUtils.EXCLUDED_GROUP, info.getListType());
    }

    @Test
    void createExcludedGroup_WithCampaignIdAndEngageId_ReturnsCorrectInfo() {
        long campaignId = 1L;
        long engageId = 2L;

        CampaignListInfo info = listAndFolderGenerationTaskService.createExcludedGroup(campaignId, engageId);

        assertEquals(campaignId, info.getCampaignId());
        assertEquals(engageId, info.getEngageId());
        assertEquals(NameUtils.EXCLUDED_GROUP, info.getListType());
    }


    private void setupMockCampaignFullDataDTO_for_ManualSpecifiedSegmentationListInfo(Long filterId, String controlGroupStrategy) {
        // 设置环境无控制组和无过滤器
        mockCampaignFullDataDTO = new CampaignFullDataDTO();
        mockAudienceStrategy = new CampaignAudienceStrategy();
        mockOutboundEngages = new ArrayList<>();
        CampaignOutboundEngage engage = new CampaignOutboundEngage();
        engage.setId(2L);
        engage.setAudienceData("{\"listId\": \"123\"}");
        mockOutboundEngages.add(engage);
        mockCampaignFullDataDTO.setOutboundEngageList(mockOutboundEngages);
        mockCampaignFullDataDTO.setAudienceStrategy(mockAudienceStrategy);
        MarketingCampaign campaign = new MarketingCampaign();
        campaign.setId(1L);
        campaign.setDeptCode("abc");
        campaign.setOwnerId(123L);
        campaign.setTenantId(1L);
        mockCampaignFullDataDTO.setCampaign(campaign);

        engage.setAudienceStrategy(AudienceStrategyConstants.MANUAL_SPECIFIED_SEGMENTATION);
        engage.setControlGroupStrategy(controlGroupStrategy);
        mockAudienceStrategy.setFilterId(filterId);
    }

    @Test
    public void testGenerateManualSpecifiedSegmentationListInfo_NoControlNoFilter() {

        listAndFolderGenerationTaskService.objectMapper = objectMapper;
        setupMockCampaignFullDataDTO_for_ManualSpecifiedSegmentationListInfo(null, null);

        List<CampaignListInfo> result = listAndFolderGenerationTaskService.generateManualSpecifiedSegmentationListInfo(mockCampaignFullDataDTO);
        // 验证结果应该只包含主组和目标组
        assertEquals(2, result.size());
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.MAIN_GROUP)));
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.TARGET_GROUP)));
    }

    @Test
    public void testGenerateManualSpecifiedSegmentationListInfo_NoControlNoFilter_1() {

        listAndFolderGenerationTaskService.objectMapper = objectMapper;
        setupMockCampaignFullDataDTO_for_ManualSpecifiedSegmentationListInfo(null, null);
        mockCampaignFullDataDTO.getOutboundEngageList().get(0).setControlGroupData("{\"percentage\":0}");

        List<CampaignListInfo> result = listAndFolderGenerationTaskService.generateManualSpecifiedSegmentationListInfo(mockCampaignFullDataDTO);
        // 验证结果应该只包含主组和目标组
        assertEquals(2, result.size());
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.MAIN_GROUP)));
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.TARGET_GROUP)));
    }

    @Test
    public void testGenerateManualSpecifiedSegmentationListInfo_NoControlWithFilter() {
        listAndFolderGenerationTaskService.objectMapper = objectMapper;
        setupMockCampaignFullDataDTO_for_ManualSpecifiedSegmentationListInfo(1L, null);
        listAndFolderGenerationTaskService.objectMapper = objectMapper;

        List<CampaignListInfo> result = listAndFolderGenerationTaskService.generateManualSpecifiedSegmentationListInfo(mockCampaignFullDataDTO);
        // 验证结果应该只包含主组和目标组
        assertEquals(4, result.size());
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.MAIN_GROUP)));
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.TARGET_GROUP)));
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.FILTERED_GROUP)));
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.EXCLUDED_GROUP)));
    }

    @Test
    public void testGenerateManualSpecifiedSegmentationListInfo_NoControlWithFilter_1() {
        listAndFolderGenerationTaskService.objectMapper = objectMapper;
        setupMockCampaignFullDataDTO_for_ManualSpecifiedSegmentationListInfo(1L, null);
        listAndFolderGenerationTaskService.objectMapper = objectMapper;
        mockCampaignFullDataDTO.getOutboundEngageList().get(0).setControlGroupData("{\"percentage\":0}");

        List<CampaignListInfo> result = listAndFolderGenerationTaskService.generateManualSpecifiedSegmentationListInfo(mockCampaignFullDataDTO);
        // 验证结果应该只包含主组和目标组
        assertEquals(4, result.size());
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.MAIN_GROUP)));
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.TARGET_GROUP)));
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.FILTERED_GROUP)));
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.EXCLUDED_GROUP)));
    }

    @Test
    public void testGenerateManualSpecifiedSegmentationListInfo_WithControlNoFilter() {
        listAndFolderGenerationTaskService.objectMapper = objectMapper;
        setupMockCampaignFullDataDTO_for_ManualSpecifiedSegmentationListInfo(null, ControlGroupStrategyConstants.CONTROL_AT_Engage);
        listAndFolderGenerationTaskService.objectMapper = objectMapper;
        mockCampaignFullDataDTO.getOutboundEngageList().get(0).setControlGroupData("{\"percentage\":0.05}");

        List<CampaignListInfo> result = listAndFolderGenerationTaskService.generateManualSpecifiedSegmentationListInfo(mockCampaignFullDataDTO);
        // 验证结果应该只包含主组和目标组
        assertEquals(3, result.size());
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.MAIN_GROUP)));
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.TARGET_GROUP)));
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.CONTROL_GROUP)));
    }

    @Test
    public void testGenerateManualSpecifiedSegmentationListInfo_WithControlWithFilter() {
        setupMockCampaignFullDataDTO_for_ManualSpecifiedSegmentationListInfo(1L, ControlGroupStrategyConstants.CONTROL_AT_Engage);
        listAndFolderGenerationTaskService.objectMapper = objectMapper;
        mockCampaignFullDataDTO.getOutboundEngageList().get(0).setControlGroupData("{\"percentage\":0.05}");

        List<CampaignListInfo> result = listAndFolderGenerationTaskService.generateManualSpecifiedSegmentationListInfo(mockCampaignFullDataDTO);
        // 验证结果应该只包含主组和目标组
        assertEquals(5, result.size());
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.MAIN_GROUP)));
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.TARGET_GROUP)));
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.CONTROL_GROUP)));
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.FILTERED_GROUP)));
        assertTrue(result.stream().anyMatch(info -> info.getListType().equals(NameUtils.EXCLUDED_GROUP)));

    }


    private void setupMockCampaignFullDataDTO_for_SplitSegmentationListInfo(Long filterId, String controlGroupStrategy) {
        // 设置环境无控制组和无过滤器
        mockCampaignFullDataDTO = new CampaignFullDataDTO();
        mockAudienceStrategy = new CampaignAudienceStrategy();
        mockOutboundEngages = new ArrayList<>();
        List<CampaignMainTargetAudienceMapping> mainTargetAudience = new ArrayList<>();
        mockCampaignFullDataDTO.setMainTargetAudience(mainTargetAudience);
        CampaignMainTargetAudienceMapping mapping = new CampaignMainTargetAudienceMapping();
        mapping.setListId(123L);
        mainTargetAudience.add(mapping);
        CampaignOutboundEngage engage1 = new CampaignOutboundEngage();
        engage1.setId(1L);
        engage1.setAudienceData("{\"listId\": \"123\"}");
        CampaignOutboundEngage engage2 = new CampaignOutboundEngage();
        engage2.setId(2L);
        engage2.setAudienceData("{\"listId\": \"123\"}");

        if(ControlGroupStrategyConstants.CONTROL_AT_Engage.equals(controlGroupStrategy)){
            engage1.setControlGroupStrategy(controlGroupStrategy);
            engage1.setControlGroupData("{\"percentage\":0.05}");
            engage2.setControlGroupStrategy(controlGroupStrategy);
            engage2.setControlGroupData("{\"percentage\":0.05}");

        }
        mockOutboundEngages.add(engage1);
        mockOutboundEngages.add(engage2);
        mockCampaignFullDataDTO.setOutboundEngageList(mockOutboundEngages);
        mockCampaignFullDataDTO.setAudienceStrategy(mockAudienceStrategy);
        MarketingCampaign campaign = new MarketingCampaign();
        campaign.setId(1L);
        mockCampaignFullDataDTO.setCampaign(campaign);

        engage1.setAudienceStrategy(AudienceStrategyConstants.MANUAL_PERCENTAGE_SEGMENTATION);

        mockAudienceStrategy.setFilterId(filterId);
        if( ControlGroupStrategyConstants.CONTROL_AT_CAMPAIGN.equals(controlGroupStrategy)){
            mockAudienceStrategy.setControlGroupStrategy(controlGroupStrategy);
            mockAudienceStrategy.setControlGroupPercentage("0.05");
        }
    }

    @Test
    public void testGenerateSplitSegmentationListInfo_NoFilterNoControlGroup() {
        listAndFolderGenerationTaskService.objectMapper = objectMapper;
        setupMockCampaignFullDataDTO_for_SplitSegmentationListInfo(null, ControlGroupStrategyConstants.CONTROL_AT_CAMPAIGN);

        List<CampaignListInfo> result = listAndFolderGenerationTaskService.generateSplitSegmentationListInfo(mockCampaignFullDataDTO);

        // Expect only main and target group (at campaign level)
        assertEquals(7, result.size()); // Check for the number of groups created
    }

    @Test
    public void testGenerateSplitSegmentationListInfo_FilterNoControlGroup() {
        listAndFolderGenerationTaskService.objectMapper = objectMapper;
        setupMockCampaignFullDataDTO_for_SplitSegmentationListInfo(2L, ControlGroupStrategyConstants.CONTROL_AT_CAMPAIGN);

        List<CampaignListInfo> result = listAndFolderGenerationTaskService.generateSplitSegmentationListInfo(mockCampaignFullDataDTO);

        // Expect only main and target group (at campaign level)
        assertEquals(9, result.size()); // Check for the number of groups created
    }

    @Test
    public void testGenerateSplitSegmentationListInfo_NoFilterControlGroup() {
        listAndFolderGenerationTaskService.objectMapper = objectMapper;
        setupMockCampaignFullDataDTO_for_SplitSegmentationListInfo(null, ControlGroupStrategyConstants.CONTROL_AT_Engage);

        List<CampaignListInfo> result = listAndFolderGenerationTaskService.generateSplitSegmentationListInfo(mockCampaignFullDataDTO);

        // Expect only main and target group (at campaign level)
        assertEquals(8, result.size()); // Check for the number of groups created
    }

    @Test
    public void testGenerateSplitSegmentationListInfo_FilterControlGroup() {
        listAndFolderGenerationTaskService.objectMapper = objectMapper;
        setupMockCampaignFullDataDTO_for_SplitSegmentationListInfo(2L, ControlGroupStrategyConstants.CONTROL_AT_Engage);

        List<CampaignListInfo> result = listAndFolderGenerationTaskService.generateSplitSegmentationListInfo(mockCampaignFullDataDTO);

        // Expect only main and target group (at campaign level)
        assertEquals(10, result.size()); // Check for the number of groups created
    }


    @Test
    public void testGenCampaignListInfo_WithManualSpecifiedSegmentation() {

        listAndFolderGenerationTaskService.objectMapper = objectMapper;
        setupMockCampaignFullDataDTO_for_ManualSpecifiedSegmentationListInfo(null, null);
        this.mockAudienceStrategy.setSegmentationType(AudienceStrategyConstants.MANUAL_SPECIFIED_SEGMENTATION);

        List<CampaignListInfo> result = listAndFolderGenerationTaskService.genCampaignListInfo(mockCampaignFullDataDTO);
        assertNotNull(result);
        assertFalse(result.isEmpty()); // Assuming generateManualSpecifiedSegmentationListInfo returns non-empty list
    }

    @Test
    public void testGenCampaignListInfo_WithPercentageSegmentation() {
        listAndFolderGenerationTaskService.objectMapper = objectMapper;
        setupMockCampaignFullDataDTO_for_SplitSegmentationListInfo(null, ControlGroupStrategyConstants.CONTROL_AT_Engage);
        this.mockAudienceStrategy.setSegmentationType(AudienceStrategyConstants.MANUAL_PERCENTAGE_SEGMENTATION);

        List<CampaignListInfo> result = listAndFolderGenerationTaskService.genCampaignListInfo(mockCampaignFullDataDTO);
        assertNotNull(result);
        assertFalse(result.isEmpty()); // Assuming generateSplitSegmentationListInfo returns non-empty list
    }

    @Test
    public void testGenCampaignListInfo_WithDefaultSegmentation() {
        setupMockCampaignFullDataDTO_for_ManualSpecifiedSegmentationListInfo(null, null);
        this.mockAudienceStrategy.setSegmentationType("UNKNOWN_SEGMENTATION_TYPE");

        List<CampaignListInfo> result = listAndFolderGenerationTaskService.genCampaignListInfo(mockCampaignFullDataDTO);
        assertTrue(result.isEmpty()); // Assuming default case returns an empty list
    }

    @Test
    public void testCreateFolder() {

        setupMockCampaignFullDataDTO_for_ManualSpecifiedSegmentationListInfo(null, null);
        listAndFolderGenerationTaskService.campaignTaskService = campaignTaskService;

        // Arrange
        FolderDTO expectedListFolder = new FolderDTO();
        expectedListFolder.setId(1L);
        FolderDTO expectedFlowFolder = new FolderDTO();
        expectedFlowFolder.setId(2L);

        when(maCoreService.upsertFolder(anyString(), eq("list"), any())).thenReturn(expectedListFolder);
        when(maCoreService.upsertFolder(anyString(), eq("flow"), any())).thenReturn(expectedFlowFolder);

        // Act
        FolderDTO result = listAndFolderGenerationTaskService.createFolder(mockCampaignFullDataDTO);

        // Assert
        assertNotNull(result);
        assertEquals(Long.valueOf(1L), result.getId());

        // Verify that the folders were created with the correct names
        verify(maCoreService).upsertFolder(eq("campaign_list_1"), eq("list"), eq(mockCampaignFullDataDTO.getCampaign()));
        verify(maCoreService).upsertFolder(eq("campaign_flow_1"), eq("flow"), eq(mockCampaignFullDataDTO.getCampaign()));

        // Verify that the IDs were saved
        verify(campaignTaskService).saveCampaignContextData(eq(1L), eq(AbstractTaskRuntimeService.DATA_KEY_LIST_FOLDER_ID), eq("1"));
        verify(campaignTaskService).saveCampaignContextData(eq(1L), eq(AbstractTaskRuntimeService.DATA_KEY_FLOW_FOLDER_ID), eq("2"));
    }

    @Test
    public void testCreateListAndUpdateListIdToEngageAndListInfo() {
        Long listFolderId = 1L;
        MarketingCampaign campaign = new MarketingCampaign();
        campaign.setId(1L);

        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO();
        campaignFullData.setCampaign(campaign);

        CampaignListInfo listInfo1 = new CampaignListInfo();
        listInfo1.setId(1L);
        listInfo1.setListType("type1");
        listInfo1.setListName("list1");
        listInfo1.setListId(null);
        listInfo1.setRoot(false);
        listInfo1.setMapToListType(null);

        CampaignListInfo listInfo2 = new CampaignListInfo();
        listInfo2.setId(2L);
        listInfo2.setListType("type2");
        listInfo2.setListName("list2");
        listInfo2.setListId(null);
        listInfo1.setRoot(false);
        listInfo2.setMapToListType(null);


        List<CampaignListInfo> listInfos = Arrays.asList(
                listInfo1,listInfo2
        );

        ListDTO createdList = new ListDTO(100L, "New List", LocalDateTime.now());
        when(campaignListInfoService.loadListInfo(anyLong())).thenReturn(listInfos);
        when(maCoreService.upsertList(anyString(), anyLong(), anyString(), any(MarketingCampaign.class))).thenReturn(createdList);


        // Setting up outbound engages
        CampaignOutboundEngage outboundEngage = new CampaignOutboundEngage();
        outboundEngage.setCampaignId(1L);
        outboundEngage.setId(101L);
        listAndFolderGenerationTaskService.campaignService = campaignService;
        when(campaignService.getEngageListByCampaignId(1L)).thenReturn(Arrays.asList(outboundEngage));

        // Setting up list info
        CampaignListInfo listInfo = new CampaignListInfo();
        listInfo.setListId(201L);
        when(campaignListInfoService.selectByCampaignIdAndEngageId(1L, 101L)).thenReturn(Arrays.asList(listInfo));
        when(campaignListInfoService.findListInfoByType(any(), eq(NameUtils.TARGET_GROUP))).thenReturn(listInfo);

        listAndFolderGenerationTaskService.createListAndUpdateListIdToEngageAndListInfo(campaignFullData, listFolderId);

        verify(campaignService).updateEngageById(outboundEngage);
        assertEquals(201L, outboundEngage.getListId());
    }

//    @Test
//    void testOnStart() {
//
//        campaignService = mock(CampaignService.class);
//        campaignListInfoService = mock(CampaignListInfoService.class);
//
//        ListAndFolderGenerationTaskService listAndFolderGenerationTaskService = spy(new ListAndFolderGenerationTaskService(campaignListInfoService, null));
//        listAndFolderGenerationTaskService.campaignService = campaignService;
//
//        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO();
//        List<CampaignListInfo> campaignListInfos = new ArrayList<>();
//        FolderDTO listFolder = new FolderDTO();
//        listFolder.setId(1L);
//        CampaignExecutionTask task = new CampaignExecutionTask();
//        task.setTaskType("taskStatus");
//        task.setCampaignId(1L);
//
//        when(campaignService.getCampaignFullData(task.getCampaignId())).thenReturn(campaignFullData);
//        when(listAndFolderGenerationTaskService.createFolder(campaignFullData)).thenReturn(listFolder);
//        when(listAndFolderGenerationTaskService.genCampaignListInfo(campaignFullData)).thenReturn(campaignListInfos);
//        doNothing().when(campaignListInfoService).saveListInfo(campaignListInfos);
//
//        TaskResult result = listAndFolderGenerationTaskService.onStart(task);
//
//        verify(listAndFolderGenerationTaskService).changeEngageStatusToPreparing(campaignFullData);
//        verify(listAndFolderGenerationTaskService).createFolder(campaignFullData);
//        verify(listAndFolderGenerationTaskService).genCampaignListInfo(campaignFullData);
//        verify(campaignListInfoService).saveListInfo(campaignListInfos);
//        verify(listAndFolderGenerationTaskService).createListAndUpdateListIdToEngageAndListInfo(campaignFullData, listFolder.getId());
//
//        // Additional checks can be made to ensure no unintended interactions
//        verifyNoMoreInteractions(campaignService, campaignListInfoService);
//    }campaignListInfoService

}