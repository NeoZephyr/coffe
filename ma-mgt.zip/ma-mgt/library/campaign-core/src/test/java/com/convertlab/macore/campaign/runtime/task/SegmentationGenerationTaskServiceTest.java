package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.macore.campaign.common.utils.AudienceStrategyConstants;
import com.convertlab.macore.campaign.common.utils.ControlGroupStrategyConstants;
import com.convertlab.macore.campaign.common.utils.NameUtils;
import com.convertlab.macore.campaign.model.dto.*;
import com.convertlab.macore.campaign.model.entity.*;
import com.convertlab.macore.campaign.service.CampaignService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SegmentationGenerationTaskServiceTest {

    @InjectMocks
    private SegmentationGenerationTaskService segmentationGenerationTaskService;

    @Mock
    private CampaignListInfoService campaignListInfoService;

    @Mock
    private MaCoreService maCoreService;


    @Test
    void test_createSegmentationRequest() {

        CampaignFullDataDTO campaignFullDataDTO = new CampaignFullDataDTO();
        MarketingCampaign campaign = new MarketingCampaign();
        campaign.setId(1L);
        campaign.setUuid("abcd1234");
        campaignFullDataDTO.setCampaign(campaign);

        CampaignAudienceStrategy audienceStrategy = new CampaignAudienceStrategy();
        audienceStrategy.setSegmentationType(AudienceStrategyConstants.MANUAL_PERCENTAGE_SEGMENTATION);
        audienceStrategy.setControlGroupStrategy(ControlGroupStrategyConstants.CONTROL_AT_Engage);
        audienceStrategy.setFilterId(1L);
        campaignFullDataDTO.setAudienceStrategy(audienceStrategy);
        CampaignMainTargetAudienceMapping mapping = new CampaignMainTargetAudienceMapping();
        mapping.setListId(123L);
        campaignFullDataDTO.setMainTargetAudience(Arrays.asList(mapping));

        CampaignOutboundEngage engage1 = new CampaignOutboundEngage();
        engage1.setId(1L);
        engage1.setCampaignId(1L);
        engage1.setControlGroupStrategy("Control_At_Engage");
        engage1.setControlGroupData("{\"percentage\": 0.05}");
        engage1.setAudienceData("{\"percentage\": 0.2}");
        CampaignOutboundEngage engage2 = new CampaignOutboundEngage();
        engage2.setId(2L);
        engage2.setCampaignId(1L);
        engage2.setControlGroupStrategy("Control_At_Engage");
        engage2.setControlGroupData("{\"percentage\": 0.05}");
        engage2.setAudienceData("{\"percentage\": 0.8}");

        campaignFullDataDTO.setOutboundEngageList(Arrays.asList(engage1, engage2));

        CampaignFilter filter = new CampaignFilter();
        filter.setId(1L);
        filter.setFilterContent("{\"v4\":{\"table\":\"customer\",\"version\":4,\"where\":{\"logicalOp\":{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"eq\":{\"left\":{\"type\":\"COLUMN\",\"value\":\"name\"},\"right\":{\"type\":\"VALUE\",\"value\":\"1\"},\"extraParams\":{\"category\":\"customer\",\"conditionPropertyType\":\"Text\"},\"category\":\"customer\"}}]}}]}}]}}}}}");
        campaignFullDataDTO.setCampaignFilter(filter);

        CampaignListInfo campaignMainGroup = new CampaignListInfo(1L, -1L, NameUtils.MAIN_GROUP, "campaign_mainGroup", 123L, null, true);
        CampaignListInfo campaignFilteredGroup = new CampaignListInfo(1L, -1L, NameUtils.FILTERED_GROUP, "campaign_filteredGroup", 124L, null, false);
        CampaignListInfo campaignExcludedGroup = new CampaignListInfo(1L, -1L, NameUtils.EXCLUDED_GROUP, "campaign_excludedGroup", 125L, null, false);
        CampaignListInfo campaignTargetGroup = new CampaignListInfo(1L, -1L, NameUtils.TARGET_GROUP, "campaign_targetGroup", null, "filteredGroup", false);
        CampaignListInfo engage1MainGroup = new CampaignListInfo(1L, 1L, NameUtils.MAIN_GROUP, "engage1_mainGroup", 126L, null, false);
        CampaignListInfo engage1TargetGroup = new CampaignListInfo(1L, 1L, NameUtils.TARGET_GROUP, "engage1_targetGroup", 127L, null, false);
        CampaignListInfo engage1ControlGroup = new CampaignListInfo(1L, 1L, NameUtils.CONTROL_GROUP, "engage1_controlGroup", 128L, null, false);
        CampaignListInfo engage2MainGroup = new CampaignListInfo(1L, 2L, NameUtils.MAIN_GROUP, "engage2_mainGroup", 129L, null, false);
        CampaignListInfo engage2TargetGroup = new CampaignListInfo(1L ,2L, NameUtils.TARGET_GROUP, "engage2_targetGroup", 130L, null, false);
        CampaignListInfo engage2ControlGroup = new CampaignListInfo(1L, 2L, NameUtils.CONTROL_GROUP, "engage2_controlGroup", 131L, null, false);

        List<CampaignListInfo> campaignListInfos = Arrays.asList(campaignMainGroup, campaignFilteredGroup, campaignExcludedGroup, campaignTargetGroup, engage1MainGroup, engage1TargetGroup, engage1ControlGroup, engage2MainGroup, engage2TargetGroup, engage2ControlGroup);

        segmentationGenerationTaskService.objectMapper = new ObjectMapper();
        segmentationGenerationTaskService.campaignListInfoService = new CampaignListInfoService(null);
        ListMemberBatchTaskRequest request = segmentationGenerationTaskService.createSegmentationRequest(campaignFullDataDTO, campaignListInfos);

        assertEquals("campaign_list_etl", request.getTaskType());
        assertNotNull(request.getTaskDef());
        assertEquals("123", request.getListId());

        ListMemberBatchTaskDef taskDef = request.getTaskDef();
        assertEquals(campaign.getUuid(), taskDef.getCampaignCode());
        assertNotNull(taskDef.getFilter());
        assertNotNull(taskDef.getFilteredListName());
        assertNotNull(taskDef.getExcludedListName());
        assertNull(taskDef.getTargetGroupListName());
        assertNull(taskDef.getControlGroupListName());
        assertNotNull(taskDef.getSplitList());
        assertEquals(AudienceStrategyConstants.MANUAL_PERCENTAGE_SEGMENTATION, taskDef.getSplitStrategy());
        assertEquals(2, taskDef.getSplitList().size());

        ListMemberBatchTaskDefSplitNode node1 = taskDef.getSplitList().get(0);
        assertEquals(0.2, node1.getPercentage());
        assertNotNull(node1.getControlGroupListName());
        assertNotNull(node1.getTargetGroupListName());
        assertEquals(0.05, node1.getControlGroupPercentage());

        ListMemberBatchTaskDefSplitNode node2 = taskDef.getSplitList().get(1);
        assertEquals(0.8, node2.getPercentage());
        assertNotNull(node2.getControlGroupListName());
        assertNotNull(node2.getTargetGroupListName());
        assertEquals(0.05, node2.getControlGroupPercentage());

        assertFalse(segmentationGenerationTaskService.notRequireRemoteRequest(request));

    }


    @Test
    void test_createSegmentationRequestForManualSpecified() {

        CampaignFullDataDTO campaignFullDataDTO = new CampaignFullDataDTO();
        MarketingCampaign campaign = new MarketingCampaign();
        campaign.setId(1L);
        campaign.setUuid("abcd1234");
        campaignFullDataDTO.setCampaign(campaign);

        CampaignAudienceStrategy audienceStrategy = new CampaignAudienceStrategy();
        audienceStrategy.setSegmentationType(AudienceStrategyConstants.MANUAL_SPECIFIED_SEGMENTATION);
        audienceStrategy.setControlGroupStrategy(ControlGroupStrategyConstants.CONTROL_AT_Engage);
        audienceStrategy.setFilterId(1L);
        campaignFullDataDTO.setAudienceStrategy(audienceStrategy);
        CampaignMainTargetAudienceMapping mapping1 = new CampaignMainTargetAudienceMapping();
        mapping1.setListId(123L);
        CampaignMainTargetAudienceMapping mapping2 = new CampaignMainTargetAudienceMapping();
        mapping2.setListId(456L);
        campaignFullDataDTO.setMainTargetAudience(Arrays.asList(mapping1, mapping2));

        CampaignOutboundEngage engage1 = new CampaignOutboundEngage();
        engage1.setId(1L);
        engage1.setCampaignId(1L);
        engage1.setControlGroupStrategy("Control_At_Engage");
        engage1.setControlGroupData("{\"percentage\": 0.05}");
        engage1.setAudienceData("{\"listId\": \"123\"}");
        engage1.setListId(123L);
        CampaignOutboundEngage engage2 = new CampaignOutboundEngage();
        engage2.setId(2L);
        engage2.setCampaignId(1L);
        engage2.setControlGroupStrategy("Control_At_Engage");
        engage2.setControlGroupData("{\"percentage\": 0.05}");
        engage2.setAudienceData("{\"listId\": \"456\"}");
        engage2.setListId(456L);

        campaignFullDataDTO.setOutboundEngageList(Arrays.asList(engage1, engage2));

        CampaignFilter filter = new CampaignFilter();
        filter.setId(1L);
        filter.setFilterContent("{\"v4\":{\"table\":\"customer\",\"version\":4,\"where\":{\"logicalOp\":{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"eq\":{\"left\":{\"type\":\"COLUMN\",\"value\":\"name\"},\"right\":{\"type\":\"VALUE\",\"value\":\"1\"},\"extraParams\":{\"category\":\"customer\",\"conditionPropertyType\":\"Text\"},\"category\":\"customer\"}}]}}]}}]}}}}}");
        campaignFullDataDTO.setCampaignFilter(filter);

        CampaignListInfo campaignMainGroup = new CampaignListInfo(1L, -1L, NameUtils.MAIN_GROUP, "campaign_mainGroup", 123L, null, true);
        CampaignListInfo campaignFilteredGroup = new CampaignListInfo(1L, 1L, NameUtils.FILTERED_GROUP, "campaign_filteredGroup", 124L, null, false);
        CampaignListInfo campaignExcludedGroup = new CampaignListInfo(1L, 1L, NameUtils.EXCLUDED_GROUP, "campaign_excludedGroup", 125L, null, false);
        CampaignListInfo campaignTargetGroup = new CampaignListInfo(1L, -1L, NameUtils.TARGET_GROUP, "campaign_targetGroup", null, "filteredGroup", false);
        CampaignListInfo engage1MainGroup = new CampaignListInfo(1L, 1L, NameUtils.MAIN_GROUP, "engage1_mainGroup", 126L, null, false);
        CampaignListInfo engage1TargetGroup = new CampaignListInfo(1L, 1L, NameUtils.TARGET_GROUP, "engage1_targetGroup", 127L, null, false);
        CampaignListInfo engage1ControlGroup = new CampaignListInfo(1L, 1L, NameUtils.CONTROL_GROUP, "engage1_controlGroup", 128L, null, false);
        CampaignListInfo engage2MainGroup = new CampaignListInfo(1L, 2L, NameUtils.MAIN_GROUP, "engage2_mainGroup", 129L, null, false);
        CampaignListInfo engage2TargetGroup = new CampaignListInfo(1L ,2L, NameUtils.TARGET_GROUP, "engage2_targetGroup", 130L, null, false);
        CampaignListInfo engage2ControlGroup = new CampaignListInfo(1L, 2L, NameUtils.CONTROL_GROUP, "engage2_controlGroup", 131L, null, false);

        List<CampaignListInfo> campaignListInfos = Arrays.asList(campaignMainGroup, campaignFilteredGroup, campaignExcludedGroup, campaignTargetGroup, engage1MainGroup, engage1TargetGroup, engage1ControlGroup, engage2MainGroup, engage2TargetGroup, engage2ControlGroup);

        segmentationGenerationTaskService.objectMapper = new ObjectMapper();
        segmentationGenerationTaskService.campaignListInfoService = new CampaignListInfoService(null);

        ListMemberBatchTaskRequest request = segmentationGenerationTaskService.createSegmentationRequestForManualSpecified(campaignFullDataDTO, campaignListInfos, 1);

        assertEquals("campaign_list_etl", request.getTaskType());
        assertNotNull(request.getTaskDef());
        assertEquals("123", request.getListId());

        ListMemberBatchTaskDef taskDef = request.getTaskDef();
        assertEquals(campaign.getUuid(), taskDef.getCampaignCode());
        assertNotNull(taskDef.getFilter());
        assertNotNull(taskDef.getFilteredListName());
        assertNotNull(taskDef.getExcludedListName());
        assertNotNull(taskDef.getTargetGroupListName());
        assertNotNull(taskDef.getControlGroupListName());
        assertEquals(0, taskDef.getSplitList().size());
        assertEquals(AudienceStrategyConstants.MANUAL_SPECIFIED_SEGMENTATION, taskDef.getSplitStrategy());
        assertEquals(0.05, taskDef.getControlGroupPercentage());

        assertFalse(segmentationGenerationTaskService.notRequireRemoteRequest(request));

    }

    @Test
    void test_notRequireRemoteRequest() {

        CampaignFullDataDTO campaignFullDataDTO = new CampaignFullDataDTO();
        MarketingCampaign campaign = new MarketingCampaign();
        campaign.setId(1L);
        campaign.setUuid("abcd1234");
        campaignFullDataDTO.setCampaign(campaign);

        CampaignAudienceStrategy audienceStrategy = new CampaignAudienceStrategy();
        audienceStrategy.setSegmentationType(AudienceStrategyConstants.MANUAL_SPECIFIED_SEGMENTATION);
        audienceStrategy.setControlGroupStrategy(ControlGroupStrategyConstants.CONTROL_AT_Engage);
        audienceStrategy.setFilterId(1L);
        campaignFullDataDTO.setAudienceStrategy(audienceStrategy);
        CampaignMainTargetAudienceMapping mapping1 = new CampaignMainTargetAudienceMapping();
        mapping1.setListId(123L);
        CampaignMainTargetAudienceMapping mapping2 = new CampaignMainTargetAudienceMapping();
        mapping2.setListId(456L);
        campaignFullDataDTO.setMainTargetAudience(Arrays.asList(mapping1, mapping2));

        CampaignOutboundEngage engage1 = new CampaignOutboundEngage();
        engage1.setId(1L);
        engage1.setCampaignId(1L);
        engage1.setControlGroupStrategy("Control_At_Engage");
        engage1.setControlGroupData("{\"percentage\": 0.05}");
        engage1.setAudienceData("{\"listId\": \"123\"}");
        engage1.setListId(123L);
        CampaignOutboundEngage engage2 = new CampaignOutboundEngage();
        engage2.setId(2L);
        engage2.setCampaignId(1L);
        engage2.setControlGroupStrategy("Control_At_Engage");
        engage2.setControlGroupData("{\"percentage\": 0.05}");
        engage2.setAudienceData("{\"listId\": \"456\"}");
        engage2.setListId(456L);

        campaignFullDataDTO.setOutboundEngageList(Arrays.asList(engage1, engage2));

        CampaignFilter filter = new CampaignFilter();
        filter.setId(1L);
        filter.setFilterContent("{\"v4\":{\"table\":\"customer\",\"version\":4,\"where\":{\"logicalOp\":{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"eq\":{\"left\":{\"type\":\"COLUMN\",\"value\":\"name\"},\"right\":{\"type\":\"VALUE\",\"value\":\"1\"},\"extraParams\":{\"category\":\"customer\",\"conditionPropertyType\":\"Text\"},\"category\":\"customer\"}}]}}]}}]}}}}}");
        campaignFullDataDTO.setCampaignFilter(filter);

        CampaignListInfo engage1MainGroup = new CampaignListInfo(1L, 1L, NameUtils.MAIN_GROUP, "engage1_mainGroup", 126L, null, false);
        CampaignListInfo engage1TargetGroup = new CampaignListInfo(1L, 1L, NameUtils.TARGET_GROUP, "engage1_targetGroup", 127L,  NameUtils.MAIN_GROUP, false);
        CampaignListInfo engage2MainGroup = new CampaignListInfo(1L, 2L, NameUtils.MAIN_GROUP, "engage2_mainGroup", 129L, null, false);
        CampaignListInfo engage2TargetGroup = new CampaignListInfo(1L ,2L, NameUtils.TARGET_GROUP, "engage2_targetGroup", 130L, NameUtils.MAIN_GROUP, false);

        List<CampaignListInfo> campaignListInfos = Arrays.asList( engage1MainGroup, engage1TargetGroup, engage2MainGroup, engage2TargetGroup);

        segmentationGenerationTaskService.objectMapper = new ObjectMapper();
        segmentationGenerationTaskService.campaignListInfoService = new CampaignListInfoService(null);

        ListMemberBatchTaskRequest request = segmentationGenerationTaskService.createSegmentationRequestForManualSpecified(campaignFullDataDTO, campaignListInfos, 1);
        assertTrue(segmentationGenerationTaskService.notRequireRemoteRequest(request));
    }

    @Test
    void test_createSegmentationRequestForMultipleWaveFirst(){
        CampaignFullDataDTO campaignFullDataDTO = new CampaignFullDataDTO();
        MarketingCampaign campaign = new MarketingCampaign();
        campaign.setId(1L);
        campaign.setUuid("abcd1234");
        campaignFullDataDTO.setCampaign(campaign);

        CampaignAudienceStrategy audienceStrategy = new CampaignAudienceStrategy();
        audienceStrategy.setSegmentationType(AudienceStrategyConstants.MULTIPLE_WAVED_SEGMENTATION);
        audienceStrategy.setControlGroupStrategy(ControlGroupStrategyConstants.CONTROL_AT_CAMPAIGN);
        audienceStrategy.setControlGroupPercentage("0.05");
        audienceStrategy.setFilterId(1L);
        campaignFullDataDTO.setAudienceStrategy(audienceStrategy);
        CampaignMainTargetAudienceMapping mapping = new CampaignMainTargetAudienceMapping();
        mapping.setListId(123L);
        campaignFullDataDTO.setMainTargetAudience(Arrays.asList(mapping));

        CampaignOutboundEngage engage1 = new CampaignOutboundEngage();
        engage1.setId(1L);
        engage1.setCampaignId(1L);
        engage1.setControlGroupStrategy("Control_At_Campaign");
        engage1.setControlGroupData("{\"percentage\": 0.05}");
        engage1.setAudienceData("{\"listId\":123, \"conversionEvent\" : {\"v4\":{\"table\":\"customer\",\"version\":4,\"where\":{\"logicalOp\":{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"eq\":{\"left\":{\"type\":\"COLUMN\",\"value\":\"name\"},\"right\":{\"type\":\"VALUE\",\"value\":\"1\"},\"extraParams\":{\"category\":\"customer\",\"conditionPropertyType\":\"Text\"},\"category\":\"customer\"}}]}}]}}]}}}}}}");
        CampaignOutboundEngage engage2 = new CampaignOutboundEngage();
        engage2.setId(2L);
        engage2.setCampaignId(1L);
        engage2.setControlGroupStrategy("Control_At_Campaign");
        engage2.setControlGroupData("{\"percentage\": 0.05}");
        engage1.setAudienceData("{\"listId\":123, \"conversionEvent\" : {\"v4\":{\"table\":\"customer\",\"version\":4,\"where\":{\"logicalOp\":{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"eq\":{\"left\":{\"type\":\"COLUMN\",\"value\":\"name\"},\"right\":{\"type\":\"VALUE\",\"value\":\"1\"},\"extraParams\":{\"category\":\"customer\",\"conditionPropertyType\":\"Text\"},\"category\":\"customer\"}}]}}]}}]}}}}}}");

        campaignFullDataDTO.setOutboundEngageList(Arrays.asList(engage1, engage2));

        CampaignFilter filter = new CampaignFilter();
        filter.setId(1L);
        filter.setFilterContent("{\"v4\":{\"table\":\"customer\",\"version\":4,\"where\":{\"logicalOp\":{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"eq\":{\"left\":{\"type\":\"COLUMN\",\"value\":\"name\"},\"right\":{\"type\":\"VALUE\",\"value\":\"1\"},\"extraParams\":{\"category\":\"customer\",\"conditionPropertyType\":\"Text\"},\"category\":\"customer\"}}]}}]}}]}}}}}");
        campaignFullDataDTO.setCampaignFilter(filter);

        CampaignListInfo campaignMainGroup = new CampaignListInfo(1L, -1L, NameUtils.MAIN_GROUP, "campaign_mainGroup", 123L, null, true);
        CampaignListInfo campaignFilteredGroup = new CampaignListInfo(1L, -1L, NameUtils.FILTERED_GROUP, "campaign_filteredGroup", 124L, null, false);
        CampaignListInfo campaignExcludedGroup = new CampaignListInfo(1L, -1L, NameUtils.EXCLUDED_GROUP, "campaign_excludedGroup", 125L, null, false);
        CampaignListInfo campaignControlGroup = new CampaignListInfo(1L, -1L, NameUtils.CONTROL_GROUP, "campaign_controlGroup", 128L, null, false);
        CampaignListInfo campaignTargetGroup = new CampaignListInfo(1L, -1L, NameUtils.TARGET_GROUP, "campaign_targetGroup", 131L, null, false);
        CampaignListInfo engage1MainGroup = new CampaignListInfo(1L, 1L, NameUtils.MAIN_GROUP, "engage1_mainGroup", 126L, null, false);
        CampaignListInfo engage1TargetGroup = new CampaignListInfo(1L, 1L, NameUtils.TARGET_GROUP, "engage1_targetGroup", 127L, null, false);
        CampaignListInfo engage2MainGroup = new CampaignListInfo(1L, 2L, NameUtils.MAIN_GROUP, "engage2_mainGroup", 129L, null, false);
        CampaignListInfo engage2TargetGroup = new CampaignListInfo(1L ,2L, NameUtils.TARGET_GROUP, "engage2_targetGroup", 130L, null, false);

        List<CampaignListInfo> campaignListInfos = Arrays.asList(campaignMainGroup, campaignFilteredGroup, campaignExcludedGroup, campaignTargetGroup, engage1MainGroup, engage1TargetGroup, campaignControlGroup, engage2MainGroup, engage2TargetGroup);

        segmentationGenerationTaskService.objectMapper = new ObjectMapper();
        segmentationGenerationTaskService.campaignListInfoService = new CampaignListInfoService(null);
        ListMemberBatchTaskRequest request = segmentationGenerationTaskService.createSegmentationRequestForMultipleWaveFirst(campaignFullDataDTO, campaignListInfos, 1L);

        assertEquals("campaign_list_etl", request.getTaskType());
        assertNotNull(request.getTaskDef());
        assertEquals("123", request.getListId());

        ListMemberBatchTaskDef taskDef = request.getTaskDef();
        assertEquals(campaign.getUuid(), taskDef.getCampaignCode());
        assertNotNull(taskDef.getFilter());
        assertNotNull(taskDef.getFilteredListName());
        assertNotNull(taskDef.getExcludedListName());
        assertNotNull(taskDef.getControlGroupListName());
        assertNotNull(taskDef.getTargetGroupListName());
        assertNotNull(taskDef.getSplitList());
        assertEquals(AudienceStrategyConstants.MULTIPLE_WAVED_SEGMENTATION, taskDef.getSplitStrategy());
        assertEquals(1, taskDef.getSplitList().size());

        ListMemberBatchTaskDefSplitNode node1 = taskDef.getSplitList().get(0);
        assertTrue(node1.getNotInCondition());
        assertNotNull(node1.getCondition());
        assertNotNull(node1.getTargetGroupListName());

        assertFalse(segmentationGenerationTaskService.notRequireRemoteRequest(request));

    }

    @Test
    void test_createSegmentationRequestForMultipleWaveNext(){
        CampaignFullDataDTO campaignFullDataDTO = new CampaignFullDataDTO();
        MarketingCampaign campaign = new MarketingCampaign();
        campaign.setId(1L);
        campaign.setUuid("abcd1234");
        campaignFullDataDTO.setCampaign(campaign);

        CampaignAudienceStrategy audienceStrategy = new CampaignAudienceStrategy();
        audienceStrategy.setSegmentationType(AudienceStrategyConstants.MULTIPLE_WAVED_SEGMENTATION);
        audienceStrategy.setControlGroupStrategy(ControlGroupStrategyConstants.CONTROL_AT_CAMPAIGN);
        audienceStrategy.setControlGroupPercentage("0.05");
        audienceStrategy.setFilterId(1L);
        campaignFullDataDTO.setAudienceStrategy(audienceStrategy);
        CampaignMainTargetAudienceMapping mapping = new CampaignMainTargetAudienceMapping();
        mapping.setListId(123L);
        campaignFullDataDTO.setMainTargetAudience(Arrays.asList(mapping));

        CampaignOutboundEngage engage1 = new CampaignOutboundEngage();
        engage1.setId(1L);
        engage1.setCampaignId(1L);
        engage1.setControlGroupStrategy("Control_At_Campaign");
        engage1.setControlGroupData("{\"percentage\": 0.05}");
        engage1.setAudienceData("{\"listId\":123, \"conversionEvent\" : {\"v4\":{\"table\":\"customer\",\"version\":4,\"where\":{\"logicalOp\":{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"eq\":{\"left\":{\"type\":\"COLUMN\",\"value\":\"name\"},\"right\":{\"type\":\"VALUE\",\"value\":\"1\"},\"extraParams\":{\"category\":\"customer\",\"conditionPropertyType\":\"Text\"},\"category\":\"customer\"}}]}}]}}]}}}}}}");
        CampaignOutboundEngage engage2 = new CampaignOutboundEngage();
        engage2.setId(2L);
        engage2.setCampaignId(1L);
        engage2.setControlGroupStrategy("Control_At_Campaign");
        engage2.setControlGroupData("{\"percentage\": 0.05}");
        engage1.setAudienceData("{\"listId\":123, \"conversionEvent\" : {\"v4\":{\"table\":\"customer\",\"version\":4,\"where\":{\"logicalOp\":{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"eq\":{\"left\":{\"type\":\"COLUMN\",\"value\":\"name\"},\"right\":{\"type\":\"VALUE\",\"value\":\"1\"},\"extraParams\":{\"category\":\"customer\",\"conditionPropertyType\":\"Text\"},\"category\":\"customer\"}}]}}]}}]}}}}}}");

        campaignFullDataDTO.setOutboundEngageList(Arrays.asList(engage1, engage2));

        CampaignFilter filter = new CampaignFilter();
        filter.setId(1L);
        filter.setFilterContent("{\"v4\":{\"table\":\"customer\",\"version\":4,\"where\":{\"logicalOp\":{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[{\"eq\":{\"left\":{\"type\":\"COLUMN\",\"value\":\"name\"},\"right\":{\"type\":\"VALUE\",\"value\":\"1\"},\"extraParams\":{\"category\":\"customer\",\"conditionPropertyType\":\"Text\"},\"category\":\"customer\"}}]}}]}}]}}}}}");
        campaignFullDataDTO.setCampaignFilter(filter);

        CampaignListInfo campaignMainGroup = new CampaignListInfo(1L, -1L, NameUtils.MAIN_GROUP, "campaign_mainGroup", 123L, null, true);
        CampaignListInfo campaignFilteredGroup = new CampaignListInfo(1L, -1L, NameUtils.FILTERED_GROUP, "campaign_filteredGroup", 124L, null, false);
        CampaignListInfo campaignExcludedGroup = new CampaignListInfo(1L, -1L, NameUtils.EXCLUDED_GROUP, "campaign_excludedGroup", 125L, null, false);
        CampaignListInfo campaignControlGroup = new CampaignListInfo(1L, -1L, NameUtils.CONTROL_GROUP, "campaign_controlGroup", 128L, null, false);
        CampaignListInfo campaignTargetGroup = new CampaignListInfo(1L, -1L, NameUtils.TARGET_GROUP, "campaign_targetGroup", 131L, null, false);
        CampaignListInfo engage1MainGroup = new CampaignListInfo(1L, 1L, NameUtils.MAIN_GROUP, "engage1_mainGroup", 126L, null, false);
        CampaignListInfo engage1TargetGroup = new CampaignListInfo(1L, 1L, NameUtils.TARGET_GROUP, "engage1_targetGroup", 127L, null, false);
        CampaignListInfo engage2MainGroup = new CampaignListInfo(1L, 2L, NameUtils.MAIN_GROUP, "engage2_mainGroup", 129L, null, false);
        CampaignListInfo engage2TargetGroup = new CampaignListInfo(1L ,2L, NameUtils.TARGET_GROUP, "engage2_targetGroup", 130L, null, false);

        List<CampaignListInfo> campaignListInfos = Arrays.asList(campaignMainGroup, campaignFilteredGroup, campaignExcludedGroup, campaignTargetGroup, engage1MainGroup, engage1TargetGroup, campaignControlGroup, engage2MainGroup, engage2TargetGroup);

        segmentationGenerationTaskService.objectMapper = new ObjectMapper();
        segmentationGenerationTaskService.campaignListInfoService = new CampaignListInfoService(null);
        ListMemberBatchTaskRequest request = segmentationGenerationTaskService.createSegmentationRequestForMultipleWaveNext(campaignFullDataDTO, campaignListInfos, 1L);

        assertEquals("campaign_list_etl", request.getTaskType());
        assertNotNull(request.getTaskDef());
        assertEquals("131", request.getListId());

        ListMemberBatchTaskDef taskDef = request.getTaskDef();
        assertEquals(campaign.getUuid(), taskDef.getCampaignCode());
        assertNotNull(taskDef.getSplitList());
        assertEquals(AudienceStrategyConstants.MULTIPLE_WAVED_SEGMENTATION, taskDef.getSplitStrategy());
        assertEquals(1, taskDef.getSplitList().size());

        ListMemberBatchTaskDefSplitNode node1 = taskDef.getSplitList().get(0);
        assertTrue(node1.getNotInCondition());
        assertNotNull(node1.getCondition());
        assertNotNull(node1.getTargetGroupListName());

        assertFalse(segmentationGenerationTaskService.notRequireRemoteRequest(request));

    }

    @Mock
    CampaignTaskService  campaignTaskService;
    @Mock
    CampaignService campaignService;

    @Test
    public void testCheckProgress_NoTaskDataAvailable() {
        CampaignExecutionTask task = new CampaignExecutionTask();
        task.setCampaignId(123L);
        task.setEngageId(456L);
        task.setId("789");

        segmentationGenerationTaskService.campaignTaskService = campaignTaskService;

        when(campaignTaskService.getTaskData(anyLong(), anyLong(), anyString(), anyString())).thenReturn(null);

        TaskResult result = segmentationGenerationTaskService.checkProgress(task);

        assertNull(result);
    }

    @Test
    public void testCheckProgress_NoMatchingBatchTask() {
        CampaignExecutionTask task = new CampaignExecutionTask();
        task.setCampaignId(123L);
        task.setEngageId(456L);
        task.setId("789");
        CampaignExecutionTaskData taskData = new CampaignExecutionTaskData();
        taskData.setDataValue("101");

        when(campaignTaskService.getTaskData(anyLong(), anyLong(), anyString(), anyString())).thenReturn(taskData);
        when(maCoreService.selectByIdList(anyList())).thenReturn(Collections.emptyList());
        segmentationGenerationTaskService.campaignTaskService = campaignTaskService;

        TaskResult result = segmentationGenerationTaskService.checkProgress(task);

        assertNull(result);
    }


    @Test
    public void testOnSegmentationGenerationFinish_DtoListSizeNotOne() {
        CampaignExecutionTask task = new CampaignExecutionTask();

        TaskResult result = segmentationGenerationTaskService.onSegmentationGenerationFinish(task, Collections.emptyList());

        assertFalse(result.isFinish());
    }

    @Test
    public void testOnSegmentationGenerationFinish_SuccessfulUpdate() {
        CampaignExecutionTask task = new CampaignExecutionTask();
        task.setCampaignId(123L);
        OnSegmentFinishDTO dto = new OnSegmentFinishDTO();
        dto.setStatus("finished");
        dto.setEngageId(456L);

        segmentationGenerationTaskService.campaignService = campaignService;
        segmentationGenerationTaskService.campaignTaskService = campaignTaskService;
        CampaignOutboundEngage outboundEngage = new CampaignOutboundEngage();
        outboundEngage.setId(456L);
        outboundEngage.setCampaignId(123L);
        List<CampaignOutboundEngage> engages = Collections.singletonList(outboundEngage);
        when(campaignService.getEngageListByCampaignId(123L)).thenReturn(engages);

        TaskResult result = segmentationGenerationTaskService.onSegmentationGenerationFinish(task, Collections.singletonList(dto));

        assertTrue(result.isFinish());
        verify(campaignService).updateEngageStatus(any(CampaignOutboundEngage.class), eq(CampaignOutboundEngage.ENGAGE_STATUS_PREPARED));
    }


    @Test
    void isTheFirstEngage_happyPath() {
        List<CampaignOutboundEngage> outboundEngageList = new ArrayList<>();
        CampaignOutboundEngage engage1 = new CampaignOutboundEngage();
        engage1.setId(1L);
        engage1.setCampaignId(1L);
        outboundEngageList.add(engage1);

        CampaignOutboundEngage engage2 = new CampaignOutboundEngage();
        engage2.setId(2L);
        engage2.setCampaignId(1L);
        outboundEngageList.add(engage2);

        boolean result = segmentationGenerationTaskService.isTheFirstEngage(outboundEngageList, 1L);
        assertTrue(result);

    }

    @Test
    void isTheFirstEngage_notMatch() {
        List<CampaignOutboundEngage> outboundEngageList = new ArrayList<>();
        CampaignOutboundEngage engage1 = new CampaignOutboundEngage();
        engage1.setId(1L);
        engage1.setCampaignId(1L);
        outboundEngageList.add(engage1);

        CampaignOutboundEngage engage2 = new CampaignOutboundEngage();
        engage2.setId(2L);
        engage2.setCampaignId(1L);
        outboundEngageList.add(engage2);

        boolean result = segmentationGenerationTaskService.isTheFirstEngage(outboundEngageList, 5L);
        assertFalse(result);
    }


    @Test
    void isTheFirstEngage_emptyList() {
        List<CampaignOutboundEngage> outboundEngageList = new ArrayList<>();
        boolean result = segmentationGenerationTaskService.isTheFirstEngage(outboundEngageList, 5L);
        assertFalse(result);
    }

}