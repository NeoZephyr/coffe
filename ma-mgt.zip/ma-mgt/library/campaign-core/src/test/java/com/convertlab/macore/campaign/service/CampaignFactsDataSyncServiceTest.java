package com.convertlab.macore.campaign.service;

import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.campaign.mapper.CampaignListInfoMapper;
import com.convertlab.macore.campaign.model.dto.GroupFactsDataDTO;
import com.convertlab.macore.campaign.model.dto.ListDTO;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignListInfo;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.runtime.task.MaCoreService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.convertlab.macore.campaign.common.utils.AudienceStrategyConstants.MANUAL_PERCENTAGE_SEGMENTATION;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@Slf4j
@ExtendWith(MockitoExtension.class)
class CampaignFactsDataSyncServiceTest {

    @Mock
    private CampaignListInfoMapper campaignListInfoMapper;

    @Mock
    private MaCoreService maCoreService;

    @InjectMocks
    private CampaignFactsDataSyncService campaignFactsDataSyncService;

    @Test
    void updateDtoFactGroupList() {

        GroupFactsDataDTO dto = new GroupFactsDataDTO();
        dto.setCampaignId("18781");
        GroupFactsDataDTO.EngageControlGroup engageControlGroup = new GroupFactsDataDTO.EngageControlGroup();
        engageControlGroup.engageId = "4171";
        engageControlGroup.segmentationGeneratedDate = "20240620";
        engageControlGroup.engageStartDate = "20240621";
        engageControlGroup.engageListId = "1778344620455923712";
        engageControlGroup.engageTargetListId = "1778344620455923712";
        dto.setEngageControlGroups(Collections.singletonList(engageControlGroup));
        List<CampaignListInfo> listInfos = new ArrayList<>();

        /**
         * [ {
         *   "version" : 2,
         *   "dateCreated" : "2024-05-20T07:33:18Z",
         *   "lastUpdated" : "2024-05-20T07:33:18Z",
         *   "tenantId" : 10,
         *   "id" : 8867,
         *   "profileType" : "customer",
         *   "campaignId" : 18781,
         *   "engageId" : 4171,
         *   "listType" : "main_group",
         *   "listId" : 1778344620455923712,
         *   "listName" : "campaign_18781_ciel_main_group_engage_4171",
         *   "root" : false
         * }, {
         *   "version" : 2,
         *   "dateCreated" : "2024-05-20T07:33:18Z",
         *   "lastUpdated" : "2024-05-21T07:43:40Z",
         *   "tenantId" : 10,
         *   "id" : 8868,
         *   "profileType" : "customer",
         *   "campaignId" : 18781,
         *   "engageId" : 4171,
         *   "listType" : "target_group",
         *   "mapToListType" : "main_group",
         *   "listName" : "campaign_18781_ciel_target_group_engage_4171",
         *   "executionTime" : "2024-05-21T07:43:40Z",
         *   "root" : false
         * } ]
         */

        CampaignListInfo mainGroup = new CampaignListInfo();
        mainGroup.setId(1L);
        mainGroup.setListType("main_group");
        mainGroup.setListId(1778344620455923712L);
        mainGroup.setCampaignId(18781L);
        mainGroup.setEngageId(4171L);
        listInfos.add(mainGroup);

        CampaignListInfo targetGroup = new CampaignListInfo();
        targetGroup.setId(2L);
        targetGroup.setListType("target_group");
        targetGroup.setCampaignId(18781L);
        targetGroup.setEngageId(4171L);
        targetGroup.setMapToListType("main_group");
        listInfos.add(targetGroup);
        CampaignListInfoUtil.appendTargetListId(listInfos);
        CampaignFactsDataSyncService.updateDtoFactGroupList(dto, listInfos);

        log.info("dto:{}", JsonUtils.instanceOfDto().obj2Json(dto));
        listInfos.forEach(it -> assertNotNull(it.getListId(), "listId should be mapped."));
    }

    @Test
    void testCampaignDto() {
        String jobParmaStr = "{\n" +
                "  \"campaignId\" : \"18781\",\n" +
                "  \"engageControlGroups\" : [ {\n" +
                "    \"engageId\" : \"4171\"\n" +
                "  } ]\n" +
                "}";
        GroupFactsDataDTO dto = JsonUtils.instanceOfDto().json2Obj(jobParmaStr, GroupFactsDataDTO.class);

        assertEquals("18781", dto.getCampaignId());
        assertEquals("4171", dto.getEngageControlGroups().get(0).engageId);
    }

    @Test
    void testUpdateGroupFactsGroupDateWithValidData() {
        // Setup mock objects
        MarketingCampaign campaign = new MarketingCampaign();
        CampaignExecutionTask task = new CampaignExecutionTask();
        CampaignListInfo targetGroup = new CampaignListInfo();
        CampaignOutboundEngage outboundEngage = new CampaignOutboundEngage();

        // Initialize object properties as required for tests
        campaign.setTitle("定时发送三天");

        task.setCampaignId(50531L);
        task.setEngageId(329L);

        outboundEngage.setListId(1806009389933647872L);
        outboundEngage.setAudienceStrategy(MANUAL_PERCENTAGE_SEGMENTATION);

        targetGroup.setExecutionTime(Instant.now());
        targetGroup.setListId(null);

        // Spy on the service to mock only the specific method
        CampaignFactsDataSyncService spyService = Mockito.spy(campaignFactsDataSyncService);

        // Given
        String mapToListType = "main_group";
        targetGroup.setMapToListType(mapToListType);

        // When
        spyService.updateGroupFactsGroupDate(campaign, task, targetGroup, outboundEngage);

        // Then
        verify(spyService, times(1)).updateGroupFactsGroupDate(
                eq(task.getCampaignId()),
                eq(campaign.getTitle()),
                eq(task.getEngageId()),
                eq(outboundEngage.getListId()),
                eq(MANUAL_PERCENTAGE_SEGMENTATION),
                eq(targetGroup.getExecutionTime()));

    }
}