package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.dto.UndeployFlowResponse;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.service.CampaignService;
import com.convertlab.macore.campaign.service.legacy.cms.client.FlowManagerServiceClient;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class StopCampaignTaskServiceTest {

    @Mock
    private FlowManagerServiceClient flowManagerServiceClient;

    @Mock
    private CampaignService campaignService;

    @InjectMocks
    StopCampaignTaskService stopCampaignTaskService;

    @Test
    public void testOnStart_AllFlowsSuccessfullyStopped() {
        CampaignExecutionTask task = new CampaignExecutionTask();
        task.setCampaignId(1L);

        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO();
        CampaignOutboundEngage engage = new CampaignOutboundEngage();
        engage.setFlowId(123L);

        List<CampaignOutboundEngage> engages = Arrays.asList(engage);
        campaignFullData.setOutboundEngageList(engages);

        when(campaignService.getCampaignFullData(anyLong())).thenReturn(campaignFullData);
        UndeployFlowResponse response = new UndeployFlowResponse();
        response.setSuccess(true);
        when(flowManagerServiceClient.undeployFlow(anyLong(), eq(true))).thenReturn(response);

        TaskResult result = stopCampaignTaskService.onStart(task);

        assertTrue(result.isFinish());
        verify(campaignService, times(1)).updateEngageStatus(engage, CampaignOutboundEngage.ENGAGE_STATUS_STOPPED);
    }

    @Test
    public void testOnStart_SomeFlowsFailedToStop() {
        CampaignExecutionTask task = new CampaignExecutionTask();
        task.setCampaignId(1L);

        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO();
        CampaignOutboundEngage successfulEngage = new CampaignOutboundEngage();
        successfulEngage.setFlowId(123L);
        CampaignOutboundEngage failedEngage = new CampaignOutboundEngage();
        failedEngage.setFlowId(456L);

        List<CampaignOutboundEngage> engages = Arrays.asList(successfulEngage, failedEngage);
        campaignFullData.setOutboundEngageList(engages);

        when(campaignService.getCampaignFullData(anyLong())).thenReturn(campaignFullData);
        UndeployFlowResponse response1 = new UndeployFlowResponse();
        response1.setSuccess(true);
        UndeployFlowResponse response2 = new UndeployFlowResponse();
        response2.setSuccess(false);
        when(flowManagerServiceClient.undeployFlow(eq(123L), eq(true))).thenReturn(response1);
        when(flowManagerServiceClient.undeployFlow(eq(456L), eq(true))).thenReturn(response2);

        TaskResult result = stopCampaignTaskService.onStart(task);

        assertFalse(result.isFinish());
        verify(campaignService, times(1)).updateEngageStatus(successfulEngage, CampaignOutboundEngage.ENGAGE_STATUS_STOPPED);
        verify(campaignService, times(1)).updateEngageStatus(failedEngage, CampaignOutboundEngage.ENGAGE_STATUS_FAILED);
    }


}