package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.foundation.library.context.Context;
import com.convertlab.foundation.library.context.ContextHelper;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.macore.campaign.mapper.ListMemberBatchTaskMapper;
import com.convertlab.macore.campaign.model.dto.*;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.service.legacy.cms.client.CustomerServiceClient;
import com.convertlab.macore.campaign.service.legacy.cms.client.FlowManagerServiceClient;
import com.convertlab.macore.campaign.service.legacy.cms.client.MaCoreServiceClient;
import com.convertlab.macore.campaign.service.legacy.cms.model.ListMemberBatchTask;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MaCoreServiceTest {

    @Mock
    ListMemberBatchTaskMapper listMemberBatchTaskMapper;

    @Mock
    MaCoreServiceClient maCoreServiceClient;

    @Mock
    CustomerServiceClient customerServiceClient;

    @Mock
    FlowManagerServiceClient flowManagerServiceClient;

    @InjectMocks
    MaCoreService maCoreService ;
    @Test
    void getContext_ReturnsContextWithCampaignProperties() {
        MarketingCampaign campaign = new MarketingCampaign();
        campaign.setTenantId(1L);
        campaign.setOwnerId(2L);
        campaign.setCreatorName("John Doe");
        campaign.setDeptCode("D123");

        Context context = maCoreService.getContext(campaign);

        assertNotNull(context);
        assertEquals(1L, context.getTenantId());
        assertEquals(2L, context.getUserId());
        assertEquals("John Doe", context.getUserName());
        assertEquals("D123", context.getDeptCode());
    }

    @Test
    public void testUpsertFolderWhenFolderDoesNotExist() {
        // Arrange
        String folderName = "NewFolder";
        String folderType = "Marketing";
        MarketingCampaign campaign = new MarketingCampaign();

        when(listMemberBatchTaskMapper.selectFolderByTypeAndName(folderType, folderName)).thenReturn(null);
        FolderDTO dto = new FolderDTO();
        dto.setName(folderName);
        dto.setType(folderType);
        when(maCoreServiceClient.createFolder(any(CreateFolderRequest.class))).thenReturn(dto);

        // Act
        FolderDTO result = maCoreService.upsertFolder(folderName, folderType, campaign);

        // Assert
        verify(listMemberBatchTaskMapper, times(1)).selectFolderByTypeAndName(folderType, folderName);
        verify(maCoreServiceClient, times(1)).createFolder(any(CreateFolderRequest.class));
        assertNotNull(result);
        assertEquals( folderName, result.getName());
        assertEquals( folderType, result.getType());
    }

    @Test
    public void testUpsertFolderReturnsExistingFolderCorrectly() {
        // Arrange
        String folderName = "ExistingFolder";
        String folderType = "Marketing";
        MarketingCampaign campaign = new MarketingCampaign(); // Assume this is correctly instantiated.

        FolderDTO existingFolderDTO = new FolderDTO();
        existingFolderDTO.setName(folderName);
        existingFolderDTO.setType(folderType);
        existingFolderDTO.setId(123); // Assuming there's an ID field or similar identifier

        when(listMemberBatchTaskMapper.selectFolderByTypeAndName(folderType, folderName)).thenReturn(existingFolderDTO);

        // Act
        FolderDTO result = maCoreService.upsertFolder(folderName, folderType, campaign);

        // Assert
        verify(listMemberBatchTaskMapper, times(1)).selectFolderByTypeAndName(folderType, folderName);
        verify(maCoreServiceClient, never()).createFolder(any(CreateFolderRequest.class)); // No call to create a new folder
        assertNotNull( result);
        assertEquals( folderName, result.getName());
        assertEquals( folderType, result.getType());
        assertEquals( 123, result.getId());
    }

    @Test
    public void testUpsertListReturnsExistingList() {
        // Arrange
        String name = "ExistingList";
        long folderId = 1L;
        String description = "Test Description";
        MarketingCampaign campaign = new MarketingCampaign(); // Assume proper instantiation

        ListDTO existingList = new ListDTO();
        existingList.setName(name);
        existingList.setId(123); // Assume an ID is set

        when(listMemberBatchTaskMapper.selectListByName(name)).thenReturn(existingList);

        // Act
        ListDTO result = maCoreService.upsertList(name, folderId, description, campaign);

        // Assert
        verify(listMemberBatchTaskMapper, times(1)).selectListByName(name);
        verify(customerServiceClient, never()).createList(any(Map.class));
        assertEquals( existingList, result);
    }


    @Test
    public void testUpsertListCreatesNewListAndAddsToFolder() {
        // Arrange
        String name = "NewList";
        long folderId = 1L;
        String description = "New Description";
        MarketingCampaign campaign = new MarketingCampaign();

        when(listMemberBatchTaskMapper.selectListByName(name)).thenReturn(null);

        ListDTO newList = new ListDTO();
        newList.setId(456);
        newList.setName(name);

        when(customerServiceClient.createList(any(Map.class))).thenReturn(newList);

        // Act
        ListDTO result = maCoreService.upsertList(name, folderId, description, campaign);

        // Assert
        verify(listMemberBatchTaskMapper, times(1)).selectListByName(name);
        verify(customerServiceClient, times(1)).createList(any(Map.class));
        verify(maCoreServiceClient, times(1)).addToFolder(any(AddToFolderRequest.class));
        assertNotNull( result);
        assertEquals( 456, result.getId());
    }


    @Test
    public void testUpsertListCreationFailureThrowsException() {
        // Arrange
        String name = "FaultyList";
        long folderId = 1L;
        String description = "Faulty Description";
        MarketingCampaign campaign = new MarketingCampaign();

        when(listMemberBatchTaskMapper.selectListByName(name)).thenReturn(null);

        ListDTO faultyList = new ListDTO();
        faultyList.setId(0); // Simulate creation failure
        when(customerServiceClient.createList(any(Map.class))).thenReturn(faultyList);

        assertThrows(BusinessException.class, () -> {
            maCoreService.upsertList(name, folderId, description, campaign);
        }, "A BusinessException should be thrown");

    }

    @Test
    public void testDeployFlowSuccessful() {
        // Arrange
        MarketingCampaign campaign = new MarketingCampaign();  // Assume this has necessary setters/getters
        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO();
        campaignFullData.setCampaign(campaign);
        CampaignOutboundEngage outboundEngage = new CampaignOutboundEngage();
        outboundEngage.setFlowId(12345L);

        DeployFlowResponse expectedResponse = new DeployFlowResponse();
        expectedResponse.setSuccess(true);

        when(flowManagerServiceClient.deployFlow(12345L)).thenReturn(expectedResponse);

        // Act
        DeployFlowResponse actualResponse = maCoreService.deployFlow(campaignFullData, outboundEngage);

        // Assert
        verify(flowManagerServiceClient, times(1)).deployFlow(12345L);
        assertEquals( true, actualResponse.isSuccess());
    }


    @Test
    public void testUpdateExistingFlow() {
        // Arrange
        long folderId = 2L;
        String flowName = "ExistingFlow";
        String flowDefinition = "{flow:data}";
        MarketingCampaign campaign = new MarketingCampaign();
        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO();
        campaignFullData.setCampaign(campaign);

        SaveFlowResponse existingFlowResponse = new SaveFlowResponse();
        existingFlowResponse.setId(456);
        List<SaveFlowResponse> existingFlows = Collections.singletonList(existingFlowResponse);
        when(listMemberBatchTaskMapper.selectFlowByName(flowName)).thenReturn(existingFlows);

        UpdateFlowResponse updatedFlowResponse = new UpdateFlowResponse();
        updatedFlowResponse.setId(456);
        when(flowManagerServiceClient.updateFlow(456, flowDefinition)).thenReturn(updatedFlowResponse);

        // Act
        SaveFlowResponse result = maCoreService.saveFlow(folderId, flowName, flowDefinition, campaignFullData);

        // Assert
        verify(flowManagerServiceClient, times(1)).updateFlow(456, flowDefinition);
        assertNotNull(result);
        assertEquals(456, result.getId());
    }

    @Test
    public void testSaveNewFlow() {
        // Arrange
        long folderId = 1L;
        String flowName = "NewFlow";
        String flowDefinition = "{flow:data}";
       MarketingCampaign campaign = new MarketingCampaign();
        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO();
        campaignFullData.setCampaign(campaign);

        when(listMemberBatchTaskMapper.selectFlowByName(flowName)).thenReturn(new ArrayList<>());

        SaveFlowResponse newFlowResponse = new SaveFlowResponse();
        newFlowResponse.setId(123);
        when(flowManagerServiceClient.saveFlow(flowDefinition)).thenReturn(newFlowResponse);

        // Act
        SaveFlowResponse result = maCoreService.saveFlow(folderId, flowName, flowDefinition, campaignFullData);

        // Assert
        verify(flowManagerServiceClient, times(1)).saveFlow(flowDefinition);
        assertNotNull(result);
        assertEquals(123, result.getId());
    }


    @Test
    public void testTriggerListMemberBatchTask() {
        // Arrange
        ListMemberBatchTaskRequest request = new ListMemberBatchTaskRequest(); // Assume this is correctly set up
        MarketingCampaign campaign = new MarketingCampaign(); // Assume this is correctly set up

        Map<String, Object> expectedResponse = new HashMap<>();
        expectedResponse.put("success", true);
        expectedResponse.put("id", 12345);

        when(customerServiceClient.createListMemberBatchTask(request)).thenReturn(expectedResponse);

        // Act
        Map<String, Object> result = maCoreService.triggerListMemberBatchTask(request, campaign);

        // Assert
        assertEquals(expectedResponse, result, "The response should match the expected map");
        verify(customerServiceClient, times(1)).createListMemberBatchTask(request);
    }

    @Test
    public void testSelectByIdList() {
        // Arrange
        List<String> idList = Arrays.asList("1", "2", "3");
        ListMemberBatchTask task1 = new ListMemberBatchTask();
        task1.setId(1L);
        ListMemberBatchTask task2 = new ListMemberBatchTask();
        task2.setId(2L);

        List<ListMemberBatchTask> expectedTasks = Arrays.asList(task1, task2);
        when(listMemberBatchTaskMapper.selectByIdList(idList)).thenReturn(expectedTasks);

        // Act
        List<ListMemberBatchTask> actualTasks = maCoreService.selectByIdList(idList);

        // Assert
        assertEquals(expectedTasks, actualTasks, "The returned list should match the expected list from the mapper");
        verify(listMemberBatchTaskMapper, times(1)).selectByIdList(idList); // Verifies that the mapper method is called exactly once with the correct parameters
    }

}