package com.convertlab.macore.campaign.common.utils;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FolderNameUtilsTest {

    @Test
    void getCampaignListFolderName_ReturnsExpectedName_WhenIdIsPositive() {
        long campaignId = 123;
        String expected = FolderNameUtils.CAMPAIGN_LIST_PREFIX + "123";
        assertEquals(expected, FolderNameUtils.getCampaignListFolderName(campaignId));
    }

    @Test
    void getCampaignListFolderName_ThrowsException_WhenIdIsNegative() {
        long campaignId = -1;
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            FolderNameUtils.getCampaignListFolderName(campaignId);
        });
        assertEquals("Campaign ID must be positive.", exception.getMessage());
    }

    @Test
    void getCampaignFlowFolderName_ReturnsExpectedName_WhenIdIsPositive() {
        long campaignId = 456;
        String expected = FolderNameUtils.CAMPAIGN_FLOW_PREFIX + "456";
        assertEquals(expected, FolderNameUtils.getCampaignFlowFolderName(campaignId));
    }

    @Test
    void getCampaignFlowFolderName_ThrowsException_WhenIdIsNegative() {
        long campaignId = -2;
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            FolderNameUtils.getCampaignFlowFolderName(campaignId);
        });
        assertEquals("Campaign ID must be positive.", exception.getMessage());
    }
}