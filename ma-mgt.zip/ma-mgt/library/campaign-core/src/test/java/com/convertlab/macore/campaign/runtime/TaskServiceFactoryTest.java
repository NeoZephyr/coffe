package com.convertlab.macore.campaign.runtime;

import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.runtime.task.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;

class TaskServiceFactoryTest {

    @Mock
    private ListAndFolderGenerationTaskService listAndFolderGenerationTaskService;
    @Mock
    private FlowGenerationTaskService flowGenerationTaskService;
    @Mock
    private EnageStartTaskService enageStartTaskService;
    @Mock
    private StopCampaignTaskService stopCampaignTaskService;
    @Mock
    private SegmentationGenerationTaskService segmentationGenerationTaskService;
    @Mock
    private PeriodicSchedulerTaskService periodicSchedulerTaskService;



    private TaskServiceFactory taskServiceFactory;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        taskServiceFactory = new TaskServiceFactory(
                listAndFolderGenerationTaskService,
                flowGenerationTaskService,
                enageStartTaskService,
                stopCampaignTaskService,
                segmentationGenerationTaskService,
                periodicSchedulerTaskService
        );
        taskServiceFactory.init(); // Initialize the service map
    }

    @Test
    void getTaskService_ReturnsCorrectServiceForListAndFolderTask() {
        CampaignExecutionTask task = new CampaignExecutionTask();
        task.setTaskType(CampaignExecutionTask.TASK_TYPE_GENERATE_LIST_AND_FOLDER);

        ITaskRuntimeService service = taskServiceFactory.getTaskService(task);

        assertSame(listAndFolderGenerationTaskService, service);
    }

    @Test
    void getTaskService_ReturnsCorrectServiceForFlowGenerationTask() {
        CampaignExecutionTask task = new CampaignExecutionTask();
        task.setTaskType(CampaignExecutionTask.TASK_TYPE_GENERATE_FLOW);

        ITaskRuntimeService service = taskServiceFactory.getTaskService(task);

        assertSame(flowGenerationTaskService, service);
    }

    @Test
    void getTaskService_ThrowsExceptionForUnsupportedTaskType() {
        CampaignExecutionTask task = new CampaignExecutionTask();
        task.setTaskType("UNSUPPORTED_TASK_TYPE");

        BusinessException exception = assertThrows(BusinessException.class, () -> taskServiceFactory.getTaskService(task));
    }
}