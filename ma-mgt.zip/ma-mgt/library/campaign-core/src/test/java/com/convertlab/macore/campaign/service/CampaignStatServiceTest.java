package com.convertlab.macore.campaign.service;

import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.queryengine.client.QueryEngineClient;

import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.campaign.mapper.CampaignAudienceStrategyMapper;
import com.convertlab.macore.campaign.mapper.CampaignBatchInfoMapper;
import com.convertlab.macore.campaign.mapper.CampaignChannelEventStageMapper;
import com.convertlab.macore.campaign.mapper.CampaignFilterMapper;
import com.convertlab.macore.campaign.mapper.CampaignListInfoMapper;
import com.convertlab.macore.campaign.mapper.CampaignOutboundEngageMapper;
import com.convertlab.macore.campaign.mapper.MarketingCampaignMapper;
import com.convertlab.macore.campaign.model.dto.CampaignChannelEventStageDto;
import com.convertlab.macore.campaign.model.dto.CampaignEngageBatchContext;
import com.convertlab.macore.campaign.model.dto.CampaignReportDataLineDto;
import com.convertlab.macore.campaign.model.dto.CampaignReportQuery;
import com.convertlab.macore.campaign.model.entity.CampaignChannelEventStage;
import com.convertlab.macore.campaign.service.legacy.cms.client.CmsServiceClient;
import com.convertlab.macore.channel.service.CompositeChannelPluginInstanceService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.convertlab.macore.campaign.service.CampaignReportDataSetHelper.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class CampaignStatServiceTest {

    private CampaignStatService campaignStatService;

    @Mock
    private QueryEngineClient queryEngineClient;
    @Mock
    private CmsServiceClient cmsServiceClient;
    @Mock
    private CampaignMetaService campaignMetaService;
    @Mock
    private CampaignStrategyService campaignStrategyService;
    @Mock
    private CompositeChannelPluginInstanceService compositeChannelPluginInstanceService;
    @Mock
    private MarketingCampaignMapper marketingCampaignMapper;
    @Mock
    private CampaignListInfoMapper campaignListInfoMapper;
    @Mock
    private CampaignBatchInfoMapper campaignBatchInfoMapper;
    @Mock
    private CampaignOutboundEngageMapper campaignOutboundEngageMapper;
    @Mock
    private CampaignChannelEventStageMapper campaignChannelEventStageMapper;
    @Mock
    private CampaignAudienceStrategyMapper campaignAudienceStrategyMapper;
    @Mock
    private CampaignFilterMapper campaignFilterMapper;


    @BeforeEach
    void setUp() {

        campaignStatService = new CampaignStatService(
                queryEngineClient,
                cmsServiceClient,
                campaignMetaService,
                campaignStrategyService,
                compositeChannelPluginInstanceService,
                marketingCampaignMapper,
                campaignListInfoMapper,
                campaignBatchInfoMapper,
                campaignOutboundEngageMapper,
                campaignChannelEventStageMapper,
                campaignAudienceStrategyMapper,
                campaignFilterMapper
        );
    }

    /**
     *
     */
    @Test
    void test_composeReportDataMap_() {

        List<CampaignReportDataLineDto> campaignReportDataList = mockReportDataList();
        CampaignReportQuery reportQuery =  mockReportQuery();
        CampaignEngageBatchContext batchContext = mockBatchContext();
        CampaignReportQuery.CampaignReportQueryOptions queryOptions = reportQuery.createQueryOptions();
        List<Map<String, Object>> reportDataMap = CampaignStatService.composeReportDataMap(campaignReportDataList, reportQuery, batchContext, queryOptions);

        String s = JsonUtils.instanceOfDto().obj2Json(reportDataMap);
        log.info("report result : {}", s );

        assertNotNull(reportDataMap);
    }

    @Test
    void test_upsertChannelEventStage(){

        List<CampaignChannelEventStage> existedEventStageList = new ArrayList<>();
        CampaignChannelEventStage emailEventStage = CampaignChannelEventStage.builder()
                .messagingType("email_sending-email")
                .sentEventId("email_requested")
                .deliveredEventId("email_delivered")
                .openedEventId("email_opened")
                .clickedEventId("email_clicked")
                .build();
        existedEventStageList.add(emailEventStage);
        CampaignChannelEventStage smsEventStage = CampaignChannelEventStage.builder()
                .messagingType("sms_sending-sms")
                .sentEventId("send_sms")
                .deliveredEventId("sms_delivered")
                .openedEventId("email_opened")
                .clickedEventId("click_link_in_sms")
                .build();
        existedEventStageList.add(smsEventStage);
        when(campaignChannelEventStageMapper.selectAll()).thenReturn(existedEventStageList);


        CampaignChannelEventStageDto eventStageDto = CampaignChannelEventStageDto.builder()
                .messagingType("email_sending-email")
                .sentEventId("email_requested")
                .deliveredEventId("email_delivered")
                .openedEventId("email_opened") // <-- 这里会是重复的
                .build();
        //expect BusinessException with message: found used event ids: email_opened
        assertThrows(BusinessException.class, () -> {
            campaignStatService.upsertChannelEventStage(eventStageDto);
        });
    }

}