package com.convertlab.macore.campaign.designtime;

import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.macore.campaign.mapper.CampaignTemplateMapper;
import com.convertlab.macore.campaign.model.dto.CampaignTemplateSaveDTO;
import com.convertlab.macore.campaign.model.entity.CampaignTemplate;
import com.convertlab.macore.campaign.service.CampaignTemplateService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CampaignTemplateServiceTest {

    @Mock
    private CampaignTemplateMapper campaignTemplateMapper;

    @InjectMocks
    private CampaignTemplateService campaignTemplateService;

    private CampaignTemplateSaveDTO dto;

    @BeforeEach
    void setUp() {
        dto = new CampaignTemplateSaveDTO();
        dto.setTemplateName("TestTemplate");
        dto.setDescription("Test Description");
        dto.setAttrs(new HashMap<>());
    }

    @Test
    void testSaveTemplate() {
        // Arrange
        when(campaignTemplateMapper.selectCount(any())).thenReturn(0L);
        when(campaignTemplateMapper.insert(any(CampaignTemplate.class))).thenReturn(1);

        // Act
        boolean result = campaignTemplateService.saveOrUpdateTemplate(dto);

        // Assert
        assertTrue(result);
        verify(campaignTemplateMapper, times(1)).insert(any(CampaignTemplate.class));
    }

    @Test
    void testSaveTemplateWhenNameExists() {
        // Arrange
        when(campaignTemplateMapper.selectCount(any())).thenReturn(1L);

        // Act & Assert
        assertThrows(BusinessException.class, () -> campaignTemplateService.saveOrUpdateTemplate(dto));
    }

    @Test
    void testUpdateTemplate() {
        // Arrange
        dto.setId(1L);
        CampaignTemplate campaignTemplate = new CampaignTemplate();
        campaignTemplate.setId(dto.getId());
        when(campaignTemplateMapper.selectById(dto.getId())).thenReturn(campaignTemplate);
        when(campaignTemplateMapper.updateById(any(CampaignTemplate.class))).thenReturn(1);

        // Act
        boolean result = campaignTemplateService.saveOrUpdateTemplate(dto);

        // Assert
        assertTrue(result);
        verify(campaignTemplateMapper, times(1)).updateById(any(CampaignTemplate.class));
    }

    @Test
    void testCopyCampaignTemplate_Success() {
        // Arrange
        when(campaignTemplateMapper.selectById(any(Long.class))).thenReturn(mock(CampaignTemplate.class));
        when(campaignTemplateMapper.insert(any(CampaignTemplate.class))).thenReturn(1);

        // Act
        boolean result = campaignTemplateService.copyCampaignTemplate(1L);

        // Assert
        assertTrue(result, "Copy should be successful");
        verify(campaignTemplateMapper, times(1)).selectById(any(Long.class));
        verify(campaignTemplateMapper, times(1)).insert(any(CampaignTemplate.class));
    }

    @Test
    void testCopyCampaignTemplate_NotExists() {
        // Arrange
        when(campaignTemplateMapper.selectById(any(Long.class))).thenReturn(null);

        // Act & Assert
        assertThrows(BusinessException.class, () -> {
            campaignTemplateService.copyCampaignTemplate(99L);
        });

        verify(campaignTemplateMapper, times(1)).selectById(any(Long.class));
        verify(campaignTemplateMapper, never()).insert(any(CampaignTemplate.class));
    }
}
