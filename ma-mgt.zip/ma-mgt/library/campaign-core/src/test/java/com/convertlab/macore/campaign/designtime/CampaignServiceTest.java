package com.convertlab.macore.campaign.designtime;

import cn.hutool.core.date.LocalDateTimeUtil;
import com.convertlab.macore.campaign.common.enums.SegmentationTypeEnum;
import com.convertlab.macore.campaign.common.helper.HandleAttrHelper;
import com.convertlab.macore.campaign.mapper.MarketingCampaignMapper;
import com.convertlab.macore.campaign.model.dto.CampaignDTO;
import com.convertlab.macore.campaign.model.entity.CampaignAudienceStrategy;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.service.*;
import com.convertlab.macore.campaign.service.legacy.cms.client.CmsServiceClient;
import com.convertlab.macore.campaign.service.legacy.cms.model.CampaignCheckExistsRequest;
import com.convertlab.macore.campaign.service.legacy.cms.model.CampaignCheckExistsResponse;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CampaignServiceTest {

    @InjectMocks
    private CampaignService campaignService;
    @Mock
    private OutboundEngageService outboundEngageService;

    @Mock
    private MarketingCampaignMapper marketCampaignMapper;

    @Mock
    private CampaignStrategyService campaignStrategyService;

    @Mock
    private MainTargetAudienceService mainTargetAudienceService;

    @Mock
    private CampaignTemplateService campaignTemplateService;

    @Mock
    private CmsServiceClient cmsServiceClient;

    @Mock
    private HandleAttrHelper handleAttrHelper;

    @Test
    @DisplayName("测试添加一个按目标群组的营销活动")
    void test_Add_New_Campaign_Manual_Specified() {
        // 准备测试数据
        CampaignDTO dto = CampaignDTO.builder()
                .name("Test_Manual_Specified")
                .code("Test_Manual_Specified_" + RandomStringUtils.randomNumeric(5))
                .dateStart(LocalDateTime.now())
                .dateEnd(LocalDateTime.now().plusDays(1))
                .attrs(new HashMap<String, Object>(2) {{
                    put("c_test", 1);
                }})
                .audienceStrategy(CampaignDTO.AudienceStrategy.builder()
                        .segmentationType(SegmentationTypeEnum.MANUAL_SPECIFIED_SEGMENTATION.getName())
                        .targetSegmentation("1,2,3")
                        .build())
                .channelStrategy(CampaignDTO.ChannelStrategy.builder()
                        .data(new HashMap<String, Object>(2) {{
                            put("messagingTypes", Collections.singletonList(new HashMap<String, Object>(16) {{
                                put("pluginId", 1);
                                put("pluginCode", "彩信");
                                put("messagingType", "mms-sending_mms");
                                put("actionId", "plugin_channel_system_mms-sending_mms");
                                put("actionName", "彩信");
                                put("channelType", "mms");
                                put("isSystem", true);
                            }}));
                        }})
                        .build())
                .timeStrategy(CampaignDTO.TimeStrategy.builder()
                        .strategy("IMMEDIATELY")
                        .build())
                .controlGroupStrategy(CampaignDTO.ControlGroupStrategy.builder()
                        .strategy("Control_At_Engage")
                        .data(new HashMap<String, Object>(2) {{
                            put("percentage", 0.05);
                        }})
                        .build())
                .build();

        MarketingCampaign marketingCampaign = MarketingCampaign.builder().id(1L).build();
        CampaignAudienceStrategy campaignStrategy = CampaignAudienceStrategy.builder().id(1L).build();

        CampaignCheckExistsRequest request = new CampaignCheckExistsRequest();
        request.setUuid(dto.getCode());

        when(marketCampaignMapper.insert(any())).thenReturn(1);
        dto.setId(marketingCampaign.getId());

        when(campaignStrategyService.saveOrUpdateStrategy(dto, marketingCampaign.getId())).thenReturn(campaignStrategy);
        when(mainTargetAudienceService.saveMainTargetAudience(marketingCampaign.getId(), campaignStrategy.getId(), "1,2,3")).thenReturn(true);
        when(outboundEngageService.saveEngage(dto, marketingCampaign.getId(), campaignStrategy.getId())).thenReturn(true);
        when(cmsServiceClient.checkCampaignExists(request)).thenReturn(new CampaignCheckExistsResponse(false, false));
        doNothing().when(campaignTemplateService).updateUseCnt(null);

        // 执行测试方法
        Long campaignId = campaignService.saveCampaign(dto);
        dto.setId(marketingCampaign.getId());

        // 验证测试结果
        assertNotNull(campaignId);
        verify(marketCampaignMapper, times(1)).insert(any());
        verify(campaignStrategyService, times(1)).saveOrUpdateStrategy(dto, marketingCampaign.getId());
        verify(campaignStrategyService, times(1)).saveOrUpdateStrategy(dto, marketingCampaign.getId());
        verify(outboundEngageService, times(1)).saveEngage(dto, marketingCampaign.getId(), 1L);
    }


    @Test
    @DisplayName("测试添加一个按比例切分的营销活动")
    void test_Add_New_Campaign_Manual_Percentage() {
        // 准备测试数据
        CampaignDTO dto = CampaignDTO.builder()
                .name("Test_Manual_Percentage")
                .code("Test_Manual_Percentage_" + RandomStringUtils.randomNumeric(5))
                .dateStart(LocalDateTime.now())
                .dateEnd(LocalDateTime.now().plusDays(3))
                .attrs(new HashMap<String, Object>(2) {{
                    put("c_test", 1);
                }})
                .audienceStrategy(CampaignDTO.AudienceStrategy.builder()
                        .segmentationType(SegmentationTypeEnum.MANUAL_PERCENTAGE_SEGMENTATION.getName())
                        .targetSegmentation("1,2,3")
                        .filterId(1L)
                        .data(new HashMap<String, Object>(4) {{
                            put("remaining_segmentation_enabled", true);
                            put("amount", 3);
                            put("rate", Stream.of(0.3, 0.3, 0.4).collect(Collectors.toList()));
                        }})
                        .build())
                .channelStrategy(CampaignDTO.ChannelStrategy.builder()
                        .data(new HashMap<String, Object>(2) {{
                            put("messagingTypes", Collections.singletonList(new HashMap<String, Object>(16) {{
                                put("pluginId", 1);
                                put("pluginCode", "彩信");
                                put("messagingType", "mms-sending_mms");
                                put("actionId", "plugin_channel_system_mms-sending_mms");
                                put("actionName", "彩信");
                                put("channelType", "mms");
                                put("isSystem", true);
                            }}));
                        }})
                        .build())
                .timeStrategy(CampaignDTO.TimeStrategy.builder()
                        .strategy("Scheduled")
                        .data(new HashMap<String, Object>(2) {{
                            put("scheduledDate", LocalDateTimeUtil.format(LocalDateTimeUtil.now().plusDays(1), "yyyy-MM-dd'T'HH:mm:ss'Z'"));
                        }})
                        .build())
                .controlGroupStrategy(CampaignDTO.ControlGroupStrategy.builder()
                        .strategy("Control_At_Engage")
                        .data(new HashMap<String, Object>(2) {{
                            put("percentage", 0.05);
                        }})
                        .build())
                .build();

        MarketingCampaign marketingCampaign = MarketingCampaign.builder().id(1L).build();
        CampaignAudienceStrategy campaignStrategy = CampaignAudienceStrategy.builder().id(1L).build();

        CampaignCheckExistsRequest request = new CampaignCheckExistsRequest();
        request.setUuid(dto.getCode());

        when(marketCampaignMapper.insert(any())).thenReturn(1);
        dto.setId(marketingCampaign.getId());

        when(campaignStrategyService.saveOrUpdateStrategy(dto, marketingCampaign.getId())).thenReturn(campaignStrategy);
        when(mainTargetAudienceService.saveMainTargetAudience(marketingCampaign.getId(), campaignStrategy.getId(), "1,2,3")).thenReturn(true);
        when(outboundEngageService.saveEngage(dto, marketingCampaign.getId(), campaignStrategy.getId())).thenReturn(true);
        when(cmsServiceClient.checkCampaignExists(request)).thenReturn(new CampaignCheckExistsResponse(false, false));
        doNothing().when(campaignTemplateService).updateUseCnt(null);


        // 执行测试方法
        Long campaignId = campaignService.saveCampaign(dto);

        // 验证测试结果
        assertNotNull(campaignId);
        verify(marketCampaignMapper, times(1)).insert(any());
        verify(campaignStrategyService, times(1)).saveOrUpdateStrategy(dto, marketingCampaign.getId());
        verify(campaignStrategyService, times(1)).saveOrUpdateStrategy(dto, marketingCampaign.getId());
        verify(outboundEngageService, times(1)).saveEngage(dto, marketingCampaign.getId(), 1L);
    }

    @Test
    @DisplayName("测试添加一个按固定数量的营销活动")
    void test_Add_New_Campaign_Manual_Quantity() {
        // 准备测试数据
        CampaignDTO dto = CampaignDTO.builder()
                .name("Test_Manual_Quantity")
                .code("Test_Manual_Quantity_" + RandomStringUtils.randomNumeric(5))
                .dateStart(LocalDateTime.now())
                .dateEnd(LocalDateTime.now().plusDays(3))
                .attrs(new HashMap<String, Object>(2) {{
                    put("c_test", 1);
                }})
                .audienceStrategy(CampaignDTO.AudienceStrategy.builder()
                        .segmentationType(SegmentationTypeEnum.MANUAL_QUANTITY_SEGMENTATION.getName())
                        .targetSegmentation("1,2,3")
                        .filterId(1L)
                        .data(new HashMap<String, Object>(4) {{
                            put("remaining_segmentation_enabled", true);
                            put("amount", 3);
                            put("rate", Stream.of(10, 20, "remain").collect(Collectors.toList()));
                        }})
                        .build())
                .channelStrategy(CampaignDTO.ChannelStrategy.builder()
                        .data(new HashMap<String, Object>(2) {{
                            put("messagingTypes", Collections.singletonList(new HashMap<String, Object>(16) {{
                                put("pluginId", 1);
                                put("pluginCode", "彩信");
                                put("messagingType", "mms-sending_mms");
                                put("actionId", "plugin_channel_system_mms-sending_mms");
                                put("actionName", "彩信");
                                put("channelType", "mms");
                                put("isSystem", true);
                            }}));
                        }})
                        .build())
                .timeStrategy(CampaignDTO.TimeStrategy.builder()
                        .strategy("Scheduled")
                        .data(new HashMap<String, Object>(2) {{
                            put("scheduledDate", LocalDateTimeUtil.format(LocalDateTimeUtil.now().plusDays(1), "yyyy-MM-dd'T'HH:mm:ss'Z'"));
                        }})
                        .build())
                .controlGroupStrategy(CampaignDTO.ControlGroupStrategy.builder()
                        .strategy("Control_At_Engage")
                        .data(new HashMap<String, Object>(2) {{
                            put("percentage", 0.05);
                        }})
                        .build())
                .build();

        MarketingCampaign marketingCampaign = MarketingCampaign.builder().id(1L).build();
        CampaignAudienceStrategy campaignStrategy = CampaignAudienceStrategy.builder().id(1L).build();

        CampaignCheckExistsRequest request = new CampaignCheckExistsRequest();
        request.setUuid(dto.getCode());

        when(marketCampaignMapper.insert(any())).thenReturn(1);
        dto.setId(marketingCampaign.getId());

        when(campaignStrategyService.saveOrUpdateStrategy(dto, marketingCampaign.getId())).thenReturn(campaignStrategy);
        when(mainTargetAudienceService.saveMainTargetAudience(marketingCampaign.getId(), campaignStrategy.getId(), "1,2,3")).thenReturn(true);
        when(outboundEngageService.saveEngage(dto, marketingCampaign.getId(), campaignStrategy.getId())).thenReturn(true);
        when(cmsServiceClient.checkCampaignExists(request)).thenReturn(new CampaignCheckExistsResponse(false, false));
        doNothing().when(campaignTemplateService).updateUseCnt(null);


        // 执行测试方法
        Long campaignId = campaignService.saveCampaign(dto);

        // 验证测试结果
        assertNotNull(campaignId);
        verify(marketCampaignMapper, times(1)).insert(any());
        verify(campaignStrategyService, times(1)).saveOrUpdateStrategy(dto, marketingCampaign.getId());
        verify(campaignStrategyService, times(1)).saveOrUpdateStrategy(dto, marketingCampaign.getId());
        verify(outboundEngageService, times(1)).saveEngage(dto, marketingCampaign.getId(), 1L);
    }


    @Test
    @DisplayName("测试添加一个按客户画像的营销活动")
    void test_Add_New_Campaign_Psychographic() {
        // 准备测试数据
        CampaignDTO dto = CampaignDTO.builder()
                .name("Test_Manual_Psychographic")
                .code("Test_Manual_Psychographic_" + RandomStringUtils.randomNumeric(5))
                .dateStart(LocalDateTime.now())
                .dateEnd(LocalDateTime.now().plusDays(3))
                .attrs(new HashMap<String, Object>(2) {{
                    put("c_test", 1);
                }})
                .audienceStrategy(CampaignDTO.AudienceStrategy.builder()
                        .segmentationType(SegmentationTypeEnum.PSYCHOGRAPHIC_SEGMENTATION.getName())
                        .targetSegmentation("1,2,3")
                        .filterId(1L)
                        .data(new HashMap<String, Object>(4) {{
                            put("remaining_segmentation_enabled", true);
                            put("amount", 3);
                        }})
                        .build())
                .channelStrategy(CampaignDTO.ChannelStrategy.builder()
                        .data(new HashMap<String, Object>(2) {{
                            put("messagingTypes", Collections.singletonList(new HashMap<String, Object>(16) {{
                                put("pluginId", 1);
                                put("pluginCode", "彩信");
                                put("messagingType", "mms-sending_mms");
                                put("actionId", "plugin_channel_system_mms-sending_mms");
                                put("actionName", "彩信");
                                put("channelType", "mms");
                                put("isSystem", false);
                            }}));
                        }})
                        .build())
                .timeStrategy(CampaignDTO.TimeStrategy.builder()
                        .strategy("Periodic")
                        .data(new HashMap<String, Object>(4) {{
                            put("day", "*");
                            put("min", "0");
                            put("hour", "8");
                        }})
                        .build())
                .controlGroupStrategy(CampaignDTO.ControlGroupStrategy.builder()
                        .strategy("Control_At_Engage")
                        .data(new HashMap<String, Object>(2) {{
                            put("percentage", 0.05);
                        }})
                        .build())
                .build();

        MarketingCampaign marketingCampaign = MarketingCampaign.builder().id(1L).build();
        CampaignAudienceStrategy campaignStrategy = CampaignAudienceStrategy.builder().id(1L).build();

        CampaignCheckExistsRequest request = new CampaignCheckExistsRequest();
        request.setUuid(dto.getCode());

        when(marketCampaignMapper.insert(any())).thenReturn(1);
        dto.setId(marketingCampaign.getId());

        when(campaignStrategyService.saveOrUpdateStrategy(dto, marketingCampaign.getId())).thenReturn(campaignStrategy);
        when(mainTargetAudienceService.saveMainTargetAudience(marketingCampaign.getId(), campaignStrategy.getId(), "1,2,3")).thenReturn(true);
        when(outboundEngageService.saveEngage(dto, marketingCampaign.getId(), campaignStrategy.getId())).thenReturn(true);
        when(cmsServiceClient.checkCampaignExists(request)).thenReturn(new CampaignCheckExistsResponse(false, false));
        doNothing().when(campaignTemplateService).updateUseCnt(null);


        // 执行测试方法
        Long campaignId = campaignService.saveCampaign(dto);

        // 验证测试结果
        assertNotNull(campaignId);
        verify(marketCampaignMapper, times(1)).insert(any());
        verify(campaignStrategyService, times(1)).saveOrUpdateStrategy(dto, marketingCampaign.getId());
        verify(campaignStrategyService, times(1)).saveOrUpdateStrategy(dto, marketingCampaign.getId());
        verify(outboundEngageService, times(1)).saveEngage(dto, marketingCampaign.getId(), 1L);
    }

    @Test
    @DisplayName("测试添加一个按多波段的营销活动")
    void test_Add_New_Campaign_Multiple_Waved() {
        // 准备测试数据
        String filterv4;
        try {
            InputStream is = getClass().getClassLoader().getResourceAsStream("config/filterv4_case.json");
            filterv4 = IOUtils.toString(is, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        String finalFilterv = filterv4;
        CampaignDTO dto = CampaignDTO.builder()
                .name("Test_Multiple_Waved")
                .code("Test_Multiple_Waved_" + RandomStringUtils.randomNumeric(5))
                .dateStart(LocalDateTime.now())
                .dateEnd(LocalDateTime.now().plusDays(3))
                .attrs(new HashMap<String, Object>(2) {{
                    put("c_test", 1);
                }})
                .audienceStrategy(CampaignDTO.AudienceStrategy.builder()
                        .segmentationType(SegmentationTypeEnum.MULTIPLE_WAVED_SEGMENTATION.getName())
                        .targetSegmentation("1,2,3")
                        .filterId(1L)
                        .data(new HashMap<String, Object>(4) {{
                            put("conversionEvent", finalFilterv);
                            put("dateOfFirstWave", LocalDateTimeUtil.format(LocalDateTimeUtil.now().plusDays(1), "yyyy-MM-dd'T'HH:mm:ss'Z'"));
                            put("daysOfWaveInterval", 3);
                            put("waveNumber", 2);
                        }})
                        .build())
                .channelStrategy(CampaignDTO.ChannelStrategy.builder()
                        .data(new HashMap<String, Object>(2) {{
                            put("messagingTypes", Collections.singletonList(new HashMap<String, Object>(16) {{
                                put("pluginId", 1);
                                put("pluginCode", "彩信");
                                put("messagingType", "mms-sending_mms");
                                put("actionId", "plugin_channel_system_mms-sending_mms");
                                put("actionName", "彩信");
                                put("channelType", "mms");
                                put("isSystem", true);
                            }}));
                        }})
                        .build())
                .timeStrategy(CampaignDTO.TimeStrategy.builder()
                        .strategy("Periodic")
                        .data(new HashMap<String, Object>(4) {{
                            put("day", "*");
                            put("min", "0");
                            put("hour", "8");
                        }})
                        .build())
                .controlGroupStrategy(CampaignDTO.ControlGroupStrategy.builder()
                        .strategy("Control_At_Engage")
                        .data(new HashMap<String, Object>(2) {{
                            put("percentage", 0.05);
                        }})
                        .build())
                .build();

        MarketingCampaign marketingCampaign = MarketingCampaign.builder().id(1L).build();
        CampaignAudienceStrategy campaignStrategy = CampaignAudienceStrategy.builder().id(1L).build();

        CampaignCheckExistsRequest request = new CampaignCheckExistsRequest();
        request.setUuid(dto.getCode());

        when(marketCampaignMapper.insert(any())).thenReturn(1);
        dto.setId(marketingCampaign.getId());

        when(campaignStrategyService.saveOrUpdateStrategy(dto, marketingCampaign.getId())).thenReturn(campaignStrategy);
        when(mainTargetAudienceService.saveMainTargetAudience(marketingCampaign.getId(), campaignStrategy.getId(), "1,2,3")).thenReturn(true);
        when(outboundEngageService.saveEngage(dto, marketingCampaign.getId(), campaignStrategy.getId())).thenReturn(true);
        when(cmsServiceClient.checkCampaignExists(request)).thenReturn(new CampaignCheckExistsResponse(false, false));
        doNothing().when(campaignTemplateService).updateUseCnt(null);

        // 执行测试方法
        Long campaignId = campaignService.saveCampaign(dto);
        dto.setId(marketingCampaign.getId());

        // 验证测试结果
        assertNotNull(campaignId);
        verify(marketCampaignMapper, times(1)).insert(any());
        verify(campaignStrategyService, times(1)).saveOrUpdateStrategy(dto, marketingCampaign.getId());
        verify(campaignStrategyService, times(1)).saveOrUpdateStrategy(dto, marketingCampaign.getId());
        verify(outboundEngageService, times(1)).saveEngage(dto, marketingCampaign.getId(), 1L);
    }

    @Test
    @DisplayName("测试使用活动模版添加一个营销活动")
    void test_Add_New_Campaign_From_Template() {
        // 准备测试数据
        CampaignDTO dto = CampaignDTO.builder()
                .name("Test_From_Template")
                .code("Test_From_Template_" + RandomStringUtils.randomNumeric(5))
                .dateStart(LocalDateTime.now())
                .dateEnd(LocalDateTime.now().plusDays(1))
                .templateId(1L)
                .attrs(new HashMap<String, Object>(2) {{
                }})
                .audienceStrategy(CampaignDTO.AudienceStrategy.builder()
                        .segmentationType(SegmentationTypeEnum.MANUAL_SPECIFIED_SEGMENTATION.getName())
                        .targetSegmentation("1,2,3")
                        .build())
                .channelStrategy(CampaignDTO.ChannelStrategy.builder()
                        .data(new HashMap<String, Object>(2) {{
                            put("messagingTypes", Collections.singletonList(new HashMap<String, Object>(16) {{
                                put("pluginId", 1);
                                put("pluginCode", "彩信");
                                put("messagingType", "mms-sending_mms");
                                put("actionId", "plugin_channel_system_mms-sending_mms");
                                put("actionName", "彩信");
                                put("channelType", "mms");
                                put("isSystem", true);
                            }}));
                        }})
                        .build())
                .timeStrategy(CampaignDTO.TimeStrategy.builder()
                        .strategy("IMMEDIATELY")
                        .build())
                .controlGroupStrategy(CampaignDTO.ControlGroupStrategy.builder()
                        .strategy("Control_At_Engage")
                        .data(new HashMap<String, Object>(2) {{
                            put("percentage", 0.05);
                        }})
                        .build())
                .build();

        MarketingCampaign marketingCampaign = MarketingCampaign.builder().id(1L).build();
        CampaignAudienceStrategy campaignStrategy = CampaignAudienceStrategy.builder().id(1L).build();

        CampaignCheckExistsRequest request = new CampaignCheckExistsRequest();
        request.setUuid(dto.getCode());

        when(marketCampaignMapper.insert(any())).thenReturn(1);
        dto.setId(marketingCampaign.getId());

        when(campaignStrategyService.saveOrUpdateStrategy(dto, marketingCampaign.getId())).thenReturn(campaignStrategy);
        when(mainTargetAudienceService.saveMainTargetAudience(marketingCampaign.getId(), campaignStrategy.getId(), "1,2,3")).thenReturn(true);
        when(outboundEngageService.saveEngage(dto, marketingCampaign.getId(), campaignStrategy.getId())).thenReturn(true);
        when(cmsServiceClient.checkCampaignExists(request)).thenReturn(new CampaignCheckExistsResponse(false, false));
        doNothing().when(campaignTemplateService).updateUseCnt(1L);

        // 执行测试方法
        Long campaignId = campaignService.saveCampaign(dto);

        // 验证测试结果
        assertNotNull(campaignId);
        verify(marketCampaignMapper, times(1)).insert(any());
        verify(campaignStrategyService, times(1)).saveOrUpdateStrategy(dto, marketingCampaign.getId());
        verify(campaignStrategyService, times(1)).saveOrUpdateStrategy(dto, marketingCampaign.getId());
        verify(outboundEngageService, times(1)).saveEngage(dto, marketingCampaign.getId(), 1L);
    }

    @Test
    @DisplayName("测试复制一个营销活动")
    void test_Copy_Campaign() {
        // Arrange
        Long oldCampaignId = 1L;
        MarketingCampaign marketingCampaign = new MarketingCampaign();
        marketingCampaign.setId(oldCampaignId);
        marketingCampaign.setTitle("Test_Copy_Campaign");
        marketingCampaign.setUuid("Test_Copy_Campaign_" + RandomStringUtils.randomNumeric(5));

        CampaignAudienceStrategy strategy = new CampaignAudienceStrategy();
        strategy.setId(1L);
        strategy.setCampaignId(oldCampaignId);

        List<CampaignOutboundEngage> engageList = new ArrayList<>();
        CampaignOutboundEngage engage = new CampaignOutboundEngage();
        engage.setId(1L);
        engage.setCampaignId(oldCampaignId);
        engageList.add(engage);

        CampaignCheckExistsRequest request = new CampaignCheckExistsRequest();
        request.setUuid(marketingCampaign.getUuid());

        when(cmsServiceClient.checkCampaignExists(request)).thenReturn(new CampaignCheckExistsResponse(false, false));
        when(marketCampaignMapper.selectById(anyLong())).thenReturn(marketingCampaign);
        when(marketCampaignMapper.insert(any())).thenReturn(1);

        // 执行测试方法
        Long newCampaignId = campaignService.copyCampaign(oldCampaignId, marketingCampaign.getTitle(), marketingCampaign.getUuid(), false);

        // 验证测试结果
        assertNotEquals(oldCampaignId, newCampaignId);
        verify(marketCampaignMapper, times(1)).selectById(anyLong());
        verify(marketCampaignMapper, times(1)).insert(any());
    }
}