package com.convertlab.macore.campaign.designtime;

import cn.hutool.core.date.LocalDateTimeUtil;
import cn.hutool.core.map.MapUtil;
import com.convertlab.macore.campaign.common.enums.SegmentationTypeEnum;
import com.convertlab.macore.campaign.model.dto.CampaignDTO;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.service.OutboundEngageService;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class OutboundEngageServiceTest {

    @InjectMocks
    private OutboundEngageService outboundEngageService;

    @Test
    void test_Add_Engage_Manual_Specified_Immediately() {
        // 准备测试数据
        CampaignDTO dto = CampaignDTO.builder()
                .audienceStrategy(CampaignDTO.AudienceStrategy.builder()
                        .segmentationType(SegmentationTypeEnum.MANUAL_SPECIFIED_SEGMENTATION.getName())
                        .targetSegmentation("1,2,3")
                        .build())
                .channelStrategy(CampaignDTO.ChannelStrategy.builder()
                        .data(new HashMap<String, Object>(2) {{
                            put("messagingTypes", Collections.singletonList(new HashMap<String, Object>(16) {{
                                put("pluginId", 1);
                                put("pluginCode", "彩信");
                                put("messagingType", "mms-sending_mms");
                                put("actionId", "plugin_channel_system_mms-sending_mms");
                                put("actionName", "彩信");
                                put("channelType", "mms");
                            }}));
                        }})
                        .build())
                .timeStrategy(CampaignDTO.TimeStrategy.builder()
                        .strategy("IMMEDIATELY")
                        .build())
                .controlGroupStrategy(CampaignDTO.ControlGroupStrategy.builder()
                        .strategy("Control_At_Engage")
                        .data(new HashMap<String, Object>(2) {{
                            put("percentage", 0.05);
                        }})
                        .build())
                .build();

        MarketingCampaign marketingCampaign = MarketingCampaign.builder().id(1L).build();
        OutboundEngageService spyService = spy(outboundEngageService);
        when(spyService.saveBatch(anyList())).thenReturn(true);

        // 执行测试方法
        boolean result = spyService.saveEngage(dto, marketingCampaign.getId(), 1L);

        // 验证测试结果
        assertTrue(result);
        verify(spyService, times(2)).saveBatch(anyList());
    }

    @Test
    void test_Add_Engage_Manual_Specified_Without_Audience() {
        // 准备测试数据
        CampaignDTO dto = CampaignDTO.builder()
                .audienceStrategy(CampaignDTO.AudienceStrategy.builder()
                        .segmentationType(SegmentationTypeEnum.MANUAL_QUANTITY_SEGMENTATION.getName())
                        .targetSegmentation("1,2,3")
                        .data(MapUtil.newHashMap())
                        .build())
                .channelStrategy(CampaignDTO.ChannelStrategy.builder()
                        .data(new HashMap<String, Object>(2) {{
                            put("messagingTypes", Collections.singletonList(new HashMap<String, Object>(16) {{
                                put("pluginId", 1);
                                put("pluginCode", "彩信");
                                put("messagingType", "mms-sending_mms");
                                put("actionId", "plugin_channel_system_mms-sending_mms");
                                put("actionName", "彩信");
                                put("channelType", "mms");
                            }}));
                        }})
                        .build())
                .timeStrategy(CampaignDTO.TimeStrategy.builder()
                        .strategy("IMMEDIATELY")
                        .build())
                .controlGroupStrategy(CampaignDTO.ControlGroupStrategy.builder()
                        .strategy("Control_At_Engage")
                        .data(new HashMap<String, Object>(2) {{
                            put("percentage", 0.05);
                        }})
                        .build())
                .build();

        MarketingCampaign marketingCampaign = MarketingCampaign.builder().id(1L).build();
        OutboundEngageService spyService = spy(outboundEngageService);

        // 执行测试方法
        boolean result = spyService.saveEngage(dto, marketingCampaign.getId(), 1L);

        // 验证测试结果
        assertFalse(result);
    }

    @Test
    void test_Add_Engage_Manual_Percentage_Scheduled() {
        // 准备测试数据
        CampaignDTO dto = CampaignDTO.builder()
                .audienceStrategy(CampaignDTO.AudienceStrategy.builder()
                        .segmentationType(SegmentationTypeEnum.MANUAL_PERCENTAGE_SEGMENTATION.getName())
                        .targetSegmentation("1,2,3")
                        .filterId(1L)
                        .data(new HashMap<String, Object>(4) {{
                            put("remaining_segmentation_enabled", true);
                            put("amount", 3);
                            put("rate", Stream.of(0.3, 0.3, 0.4).collect(Collectors.toList()));
                        }})
                        .build())
                .channelStrategy(CampaignDTO.ChannelStrategy.builder()
                        .data(new HashMap<String, Object>(2) {{
                            put("messagingTypes", Collections.singletonList(new HashMap<String, Object>(16) {{
                                put("pluginId", 1);
                                put("pluginCode", "彩信");
                                put("messagingType", "mms-sending_mms");
                                put("actionId", "plugin_channel_system_mms-sending_mms");
                                put("actionName", "彩信");
                                put("channelType", "mms");
                            }}));
                        }})
                        .build())
                .timeStrategy(CampaignDTO.TimeStrategy.builder()
                        .strategy("Scheduled")
                        .data(new HashMap<String, Object>(2) {{
                            put("scheduledDate", LocalDateTimeUtil.format(LocalDateTimeUtil.now().plusDays(1), "yyyy-MM-dd'T'HH:mm:ss'Z'"));
                        }})
                        .build())
                .controlGroupStrategy(CampaignDTO.ControlGroupStrategy.builder()
                        .strategy("Control_At_Engage")
                        .data(new HashMap<String, Object>(2) {{
                            put("percentage", 0.05);
                        }})
                        .build())
                .build();

        MarketingCampaign marketingCampaign = MarketingCampaign.builder().id(1L).build();
        OutboundEngageService spyService = spy(outboundEngageService);
        when(spyService.saveBatch(anyList())).thenReturn(true);

        // 执行测试方法
        boolean result = spyService.saveEngage(dto, marketingCampaign.getId(), 1L);

        // 验证测试结果
        assertTrue(result);
        verify(spyService, times(2)).saveBatch(anyList());
    }

    @Test
    void test_Add_Engage_Manual_Quantity_Scheduled() {
        // 准备测试数据
        CampaignDTO dto = CampaignDTO.builder()
                .audienceStrategy(CampaignDTO.AudienceStrategy.builder()
                        .segmentationType(SegmentationTypeEnum.MANUAL_QUANTITY_SEGMENTATION.getName())
                        .targetSegmentation("1,2,3")
                        .filterId(1L)
                        .data(new HashMap<String, Object>(4) {{
                            put("remaining_segmentation_enabled", true);
                            put("amount", 3);
                            put("rate", Stream.of(10, 20, "remain").collect(Collectors.toList()));
                        }})
                        .build())
                .channelStrategy(CampaignDTO.ChannelStrategy.builder()
                        .data(new HashMap<String, Object>(2) {{
                            put("messagingTypes", Collections.singletonList(new HashMap<String, Object>(16) {{
                                put("pluginId", 1);
                                put("pluginCode", "彩信");
                                put("messagingType", "mms-sending_mms");
                                put("actionId", "plugin_channel_system_mms-sending_mms");
                                put("actionName", "彩信");
                                put("channelType", "mms");
                            }}));
                        }})
                        .build())
                .timeStrategy(CampaignDTO.TimeStrategy.builder()
                        .strategy("Scheduled")
                        .data(new HashMap<String, Object>(2) {{
                            put("scheduledDate", LocalDateTimeUtil.format(LocalDateTimeUtil.now().plusDays(1), "yyyy-MM-dd'T'HH:mm:ss'Z'"));
                        }})
                        .build())
                .controlGroupStrategy(CampaignDTO.ControlGroupStrategy.builder()
                        .strategy("Control_At_Engage")
                        .data(new HashMap<String, Object>(2) {{
                            put("percentage", 0.05);
                        }})
                        .build())
                .build();

        MarketingCampaign marketingCampaign = MarketingCampaign.builder().id(1L).build();
        OutboundEngageService spyService = spy(outboundEngageService);
        when(spyService.saveBatch(anyList())).thenReturn(true);

        // 执行测试方法
        boolean result = spyService.saveEngage(dto, marketingCampaign.getId(), 1L);

        // 验证测试结果
        assertTrue(result);
        verify(spyService, times(2)).saveBatch(anyList());
    }


    @Test
    void test_Add_Engage_Psychographic_Periodic() {
        // 准备测试数据
        CampaignDTO dto = CampaignDTO.builder()
                .audienceStrategy(CampaignDTO.AudienceStrategy.builder()
                        .segmentationType(SegmentationTypeEnum.PSYCHOGRAPHIC_SEGMENTATION.getName())
                        .targetSegmentation("1,2,3")
                        .filterId(1L)
                        .data(new HashMap<String, Object>(4) {{
                            put("remaining_segmentation_enabled", true);
                            put("amount", 3);
                        }})
                        .build())
                .channelStrategy(CampaignDTO.ChannelStrategy.builder()
                        .data(new HashMap<String, Object>(2) {{
                            put("messagingTypes", Collections.singletonList(new HashMap<String, Object>(16) {{
                                put("pluginId", 1);
                                put("pluginCode", "彩信");
                                put("messagingType", "mms-sending_mms");
                                put("actionId", "plugin_channel_system_mms-sending_mms");
                                put("actionName", "彩信");
                                put("channelType", "mms");
                            }}));
                        }})
                        .build())
                .timeStrategy(CampaignDTO.TimeStrategy.builder()
                        .strategy("Periodic")
                        .data(new HashMap<String, Object>(4) {{
                            put("day", "*");
                            put("min", "0");
                            put("hour", "8");
                        }})
                        .build())
                .controlGroupStrategy(CampaignDTO.ControlGroupStrategy.builder()
                        .strategy("Control_At_Engage")
                        .data(new HashMap<String, Object>(2) {{
                            put("percentage", 0.05);
                        }})
                        .build())
                .build();

        MarketingCampaign marketingCampaign = MarketingCampaign.builder().id(1L).build();
        OutboundEngageService spyService = spy(outboundEngageService);
        when(spyService.saveBatch(anyList())).thenReturn(true);

        // 执行测试方法
        boolean result = spyService.saveEngage(dto, marketingCampaign.getId(), 1L);

        // 验证测试结果
        assertTrue(result);
        verify(spyService, times(2)).saveBatch(anyList());
    }

    @Test
    void test_Add_Engage_Multiple_Waved_Periodic() {
        // 准备测试数据
        String filterv4;
        try {
            InputStream is = getClass().getClassLoader().getResourceAsStream("config/filterv4_case.json");
            filterv4 = IOUtils.toString(is, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        String finalFilterv = filterv4;
        CampaignDTO dto = CampaignDTO.builder()
                .audienceStrategy(CampaignDTO.AudienceStrategy.builder()
                        .segmentationType(SegmentationTypeEnum.MULTIPLE_WAVED_SEGMENTATION.getName())
                        .targetSegmentation("1,2,3")
                        .filterId(1L)
                        .data(new HashMap<String, Object>(4) {{
                            put("conversionEvent", finalFilterv);
                            put("dateOfFirstWave", LocalDateTimeUtil.format(LocalDateTimeUtil.now().plusDays(1), "yyyy-MM-dd'T'HH:mm:ss'Z'"));
                            put("daysOfWaveInterval", 3);
                            put("waveNumber", 2);
                        }})
                        .build())
                .channelStrategy(CampaignDTO.ChannelStrategy.builder()
                        .data(new HashMap<String, Object>(2) {{
                            put("messagingTypes", Collections.singletonList(new HashMap<String, Object>(16) {{
                                put("pluginId", 1);
                                put("pluginCode", "彩信");
                                put("messagingType", "mms-sending_mms");
                                put("actionId", "plugin_channel_system_mms-sending_mms");
                                put("actionName", "彩信");
                                put("channelType", "mms");
                            }}));
                        }})
                        .build())
                .timeStrategy(CampaignDTO.TimeStrategy.builder()
                        .strategy("Periodic")
                        .data(new HashMap<String, Object>(4) {{
                            put("day", "*");
                            put("min", "0");
                            put("hour", "8");
                        }})
                        .build())
                .controlGroupStrategy(CampaignDTO.ControlGroupStrategy.builder()
                        .strategy("Control_At_Engage")
                        .data(new HashMap<String, Object>(2) {{
                            put("percentage", 0.05);
                        }})
                        .build())
                .build();

        MarketingCampaign marketingCampaign = MarketingCampaign.builder().id(1L).build();
        OutboundEngageService spyService = spy(outboundEngageService);
        when(spyService.saveBatch(anyList())).thenReturn(true);

        // 执行测试方法
        boolean result = spyService.saveEngage(dto, marketingCampaign.getId(), 1L);

        // 验证测试结果
        assertTrue(result);
        verify(spyService, times(2)).saveBatch(anyList());
    }
}