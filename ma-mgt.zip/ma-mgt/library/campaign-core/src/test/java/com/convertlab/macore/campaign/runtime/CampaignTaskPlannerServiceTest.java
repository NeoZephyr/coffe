package com.convertlab.macore.campaign.runtime;

import com.convertlab.macore.campaign.common.utils.AudienceStrategyConstants;
import com.convertlab.macore.campaign.common.utils.TimingStrategyConstants;
import com.convertlab.macore.campaign.mapper.CampaignExecutionTaskMapper;
import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.runtime.task.CampaignTaskService;
import com.convertlab.macore.campaign.runtime.taskchain.CampaignSegmentPeriodicTaskChain;
import com.convertlab.macore.campaign.runtime.taskchain.CampaignSegmentTaskChain;
import com.convertlab.macore.campaign.runtime.taskchain.EngageSegmentPeriodicTaskChain;
import com.convertlab.macore.campaign.runtime.taskchain.EngageSegmentTaskChain;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class CampaignTaskPlannerServiceTest {

    @Mock
    private CampaignTaskService campaignTaskService;

    @Mock
    private CampaignTaskExecutorService campaignTaskExecutorService;

    @Mock
    private CampaignSegmentTaskChain campaignSegmentTaskChain;

    @Mock
    private EngageSegmentTaskChain engageSegmentTaskChain;

    @Mock
    CampaignSegmentPeriodicTaskChain campaignSegmentPeriodicTaskChain;

    @Mock
    EngageSegmentPeriodicTaskChain engageSegmentPeriodicTaskChain;

    @Mock
    CampaignExecutionTaskMapper campaignExecutionTaskMapper;

    @InjectMocks
    private CampaignTaskPlannerService campaignTaskPlannerService; // 假设你的服务类叫YourCampaignService

    @Captor
    private ArgumentCaptor<List<CampaignExecutionTask>> beforeSortTaskList;

    @Captor
    private ArgumentCaptor<List<CampaignExecutionTask>> sortedTaskList;

    @Test
    void planStartCampaign_CreatesSortsSavesRunsTasks() {

        List<CampaignExecutionTask> taskList = Arrays.asList(new CampaignExecutionTask(), new CampaignExecutionTask());

        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO();
        CampaignOutboundEngage firstEngage = new CampaignOutboundEngage();
        firstEngage.setAudienceStrategy(AudienceStrategyConstants.MANUAL_PERCENTAGE_SEGMENTATION);
        firstEngage.setTimeStrategy(TimingStrategyConstants.IMMEDIATE);
        campaignFullData.setOutboundEngageList(Arrays.asList(firstEngage));

        doNothing().when(campaignTaskService).sortByTimeArrange(taskList);
        doNothing().when(campaignTaskService).saveAndUpdateTaskChain(taskList);
        doNothing().when(campaignTaskExecutorService).startTask(any());
        when(campaignSegmentTaskChain.createTaskChain(campaignFullData)).thenReturn(taskList);

        campaignTaskPlannerService.planStartCampaign(campaignFullData);

        verify(campaignTaskService).sortByTimeArrange(taskList);
        verify(campaignTaskService).saveAndUpdateTaskChain(taskList);
        verify(campaignTaskExecutorService).startTask(taskList.get(0).getId());
    }



    @Test
    void createCampaignStartTaskList_ImmediateManualSpecified_ReturnsEngageSegmentTasks() {
        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO();
        CampaignOutboundEngage firstEngage = mock(CampaignOutboundEngage.class);
        campaignFullData.setOutboundEngageList(Arrays.asList(firstEngage));
        when(firstEngage.getTimeStrategy()).thenReturn(TimingStrategyConstants.IMMEDIATE);
        when(firstEngage.getAudienceStrategy()).thenReturn(AudienceStrategyConstants.MANUAL_SPECIFIED_SEGMENTATION);
        when(engageSegmentTaskChain.createTaskChain(campaignFullData)).thenReturn(Arrays.asList(mock(CampaignExecutionTask.class)));

        List<CampaignExecutionTask> tasks = campaignTaskPlannerService.createCampaignStartTaskList(campaignFullData);

        verify(engageSegmentTaskChain).createTaskChain(campaignFullData);
        assertNotNull(tasks);
    }

    @Test
    void createCampaignStartTaskList_ScheduledDefault_ReturnsCampaignSegmentTasks() {
        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO();
        CampaignOutboundEngage firstEngage = mock(CampaignOutboundEngage.class);
        campaignFullData.setOutboundEngageList(Arrays.asList(firstEngage));
        when(firstEngage.getTimeStrategy()).thenReturn(TimingStrategyConstants.SCHEDULED);
        when(firstEngage.getAudienceStrategy()).thenReturn(AudienceStrategyConstants.MANUAL_PERCENTAGE_SEGMENTATION);
        when(campaignSegmentTaskChain.createTaskChain(campaignFullData)).thenReturn(Arrays.asList(mock(CampaignExecutionTask.class)));

        List<CampaignExecutionTask> tasks = campaignTaskPlannerService.createCampaignStartTaskList(campaignFullData);

        verify(campaignSegmentTaskChain).createTaskChain(campaignFullData);
        assertNotNull(tasks);
    }


    @Test
    void createCampaignStartTaskList_PeriodicNotManualSpecified_ReturnsCampaignSegmentPeriodicTasks() {
        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO();
        CampaignOutboundEngage firstEngage = mock(CampaignOutboundEngage.class);
        campaignFullData.setOutboundEngageList(Arrays.asList(firstEngage));
        when(firstEngage.getTimeStrategy()).thenReturn(TimingStrategyConstants.PERIODIC);
        when(firstEngage.getAudienceStrategy()).thenReturn(AudienceStrategyConstants.MANUAL_PERCENTAGE_SEGMENTATION);
        when(campaignSegmentPeriodicTaskChain.createTaskChain(campaignFullData)).thenReturn(Arrays.asList(mock(CampaignExecutionTask.class)));

        List<CampaignExecutionTask> tasks = campaignTaskPlannerService.createCampaignStartTaskList(campaignFullData);

        verify(campaignSegmentPeriodicTaskChain).createTaskChain(campaignFullData);
        assertNotNull(tasks);
    }

    @Test
    void createCampaignStartTaskList_PeriodicManualSpecified_ReturnsEngageSegmentPeriodicTasks() {
        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO();
        CampaignOutboundEngage firstEngage = mock(CampaignOutboundEngage.class);
        campaignFullData.setOutboundEngageList(Arrays.asList(firstEngage));
        when(firstEngage.getTimeStrategy()).thenReturn(TimingStrategyConstants.PERIODIC);
        when(firstEngage.getAudienceStrategy()).thenReturn(AudienceStrategyConstants.MANUAL_SPECIFIED_SEGMENTATION);
        when(engageSegmentPeriodicTaskChain.createTaskChain(campaignFullData)).thenReturn(Arrays.asList(mock(CampaignExecutionTask.class)));

        List<CampaignExecutionTask> tasks = campaignTaskPlannerService.createCampaignStartTaskList(campaignFullData);

        verify(engageSegmentPeriodicTaskChain).createTaskChain(campaignFullData);
        assertNotNull(tasks);
    }

    @Test
    void createCampaignStartTaskList_UnsupportedStrategy_ThrowsException() {
        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO();
        CampaignOutboundEngage firstEngage = mock(CampaignOutboundEngage.class);
        campaignFullData.setOutboundEngageList(Arrays.asList(firstEngage));
        when(firstEngage.getTimeStrategy()).thenReturn("UnsupportedStrategy");

        Exception exception = assertThrows(UnsupportedOperationException.class, () -> campaignTaskPlannerService.createCampaignStartTaskList(campaignFullData));
        assertTrue(exception.getMessage().contains("Unsupported timing strategy"));
    }

    @Test
    void planStopCampaign_GivenCampaignFullData_StopsCampaign() {
        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO();
        MarketingCampaign  campaign = new MarketingCampaign();
        campaign.setId(1L);
        campaignFullData.setCampaign(campaign);

        CampaignExecutionTask stopTask = new CampaignExecutionTask();

        doNothing().when(campaignTaskService).updateTaskStatuses(1L, CampaignExecutionTask.TASK_STATUS_RUNNING, CampaignExecutionTask.TASK_STATUS_STOPPED);
        doNothing().when(campaignTaskService).updateTaskStatuses(1L, CampaignExecutionTask.TASK_STATUS_NOT_STARTED, CampaignExecutionTask.TASK_STATUS_STOPPED);
        doNothing().when(campaignTaskExecutorService).unscheduleAndStopTasks(1L);
        when(campaignTaskService.createStopTask(campaignFullData.getCampaign())).thenReturn(stopTask);
        when(campaignExecutionTaskMapper.upsert(stopTask)).thenReturn(1);
        doNothing().when(campaignTaskExecutorService).startTask(stopTask.getId());

        campaignTaskPlannerService.planStopCampaign(campaignFullData, false);

        verify(campaignTaskService).updateTaskStatuses(1L, CampaignExecutionTask.TASK_STATUS_RUNNING, CampaignExecutionTask.TASK_STATUS_STOPPED);
        verify(campaignTaskService).updateTaskStatuses(1L, CampaignExecutionTask.TASK_STATUS_NOT_STARTED, CampaignExecutionTask.TASK_STATUS_STOPPED);
        verify(campaignTaskExecutorService).unscheduleAndStopTasks(1L);

        verify(campaignExecutionTaskMapper).upsert(stopTask);
        verify(campaignTaskExecutorService).startTask(stopTask.getId());

    }

    @Test
    public void testPlanUpdateEngage_flow1() {
        // Mock data setup
        CampaignFullDataDTO campaignFullDataDTO = new CampaignFullDataDTO();
        MarketingCampaign campaign = new MarketingCampaign();
        campaign.setId(1L);
        campaignFullDataDTO.setCampaign(campaign); // Assume Campaign is a valid object

        CampaignOutboundEngage engage1 = new CampaignOutboundEngage();
        engage1.setTimeStrategy(TimingStrategyConstants.SCHEDULED);
        engage1.setAudienceStrategy(AudienceStrategyConstants.MANUAL_PERCENTAGE_SEGMENTATION);
        CampaignOutboundEngage engage2 = new CampaignOutboundEngage();
        engage2.setTimeStrategy(TimingStrategyConstants.SCHEDULED);
        engage2.setTimeData("{\"scheduledDate\":\"2024-08-05T00:00:00Z\"}");
        CampaignOutboundEngage engage3 = new CampaignOutboundEngage();
        engage3.setTimeStrategy(TimingStrategyConstants.SCHEDULED);
        engage3.setTimeData("{\"scheduledDate\":\"2024-08-01T00:00:00Z\"}");

        campaignFullDataDTO.setOutboundEngageList(Arrays.asList(engage1, engage2, engage3));

        //old chain :
        CampaignExecutionTask createListTask = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_GENERATE_LIST_AND_FOLDER);
        CampaignExecutionTask genFlowTask1 = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_GENERATE_FLOW);
        CampaignExecutionTask genFlowTask2 = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_GENERATE_FLOW);
        CampaignExecutionTask genFlowTask3 =  new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_GENERATE_FLOW);
        CampaignExecutionTask segmentTask = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_SEGMENTATION);
        CampaignExecutionTask startEngageTask1 = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_START_ENGAGE);
        startEngageTask1.setEngageId(1L);
        CampaignExecutionTask startEngageTask2 = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_START_ENGAGE);
        startEngageTask2.setEngageId(2L);
        CampaignExecutionTask startEngageTask3 = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_START_ENGAGE);
        startEngageTask3.setEngageId(3L);
        startEngageTask1.setTaskStatus(CampaignExecutionTask.TASK_STATUS_RUNNING);

        //new chain :
        CampaignExecutionTask newSegmentTask = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_SEGMENTATION);
        CampaignExecutionTask newStartEngageTask1 = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_START_ENGAGE);
        newStartEngageTask1.setEngageId(1L);
        CampaignExecutionTask newStartEngageTask2 = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_START_ENGAGE);
        newStartEngageTask2.setTaskTriggerDate(Instant.parse("2024-08-05T00:00:00Z"));
        newStartEngageTask2.setEngageId(2L);
        CampaignExecutionTask newStartEngageTask3 = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_START_ENGAGE);
        newStartEngageTask3.setEngageId(3L);
        newStartEngageTask3.setTaskTriggerDate(Instant.parse("2024-08-01T00:00:00Z"));

        // Setup mocks
        List<CampaignExecutionTask> notStartedOrPreparedTasks = Arrays.asList(startEngageTask2, startEngageTask3);
        when(campaignTaskService.getNotStartedAndScheduledTasks(anyLong())).thenReturn(notStartedOrPreparedTasks);
        when(campaignTaskService.getRunningTasks(anyLong())).thenReturn( Arrays.asList(startEngageTask1));
        when(campaignTaskService.createGenerateFlowTask(any(), any())).thenReturn(genFlowTask1).thenReturn(genFlowTask2);
//        doNothing().when(campaignTaskExecutorService).unscheduleTask(any());
        when(campaignSegmentTaskChain.createTaskChain(any(CampaignFullDataDTO.class))).thenReturn( Arrays.asList(newSegmentTask,newStartEngageTask1, newStartEngageTask2, newStartEngageTask3));
        doNothing().when(campaignTaskService).sortByTimeArrange(anyList());
        doNothing().when(campaignTaskService).saveAndUpdateTaskChain(anyList());
        when(campaignExecutionTaskMapper.upsert(any())).thenReturn(1);

        // Call the method under test
        campaignTaskPlannerService.planUpdateEngage(campaignFullDataDTO, Arrays.asList(engage2, engage3));

        // Verify the interactions
        verify(campaignTaskService, times(1)).getNotStartedAndScheduledTasks(anyLong());
        verify(campaignTaskService, times(1)).getRunningTasks(anyLong());
//        verify(campaignTaskExecutorService, times(0)).unscheduleTask(any());
        verify(campaignTaskService, times(1)).sortByTimeArrange(beforeSortTaskList.capture());
        List<CampaignExecutionTask> lists = beforeSortTaskList.getValue();
        assertEquals(4, lists.size());
        assertEquals(CampaignExecutionTask.TASK_TYPE_GENERATE_FLOW, lists.get(0).getTaskType());
        assertEquals(CampaignExecutionTask.TASK_TYPE_GENERATE_FLOW, lists.get(1).getTaskType());
        assertEquals(newStartEngageTask2, lists.get(2));
        assertEquals(newStartEngageTask3, lists.get(3));
        verify(campaignTaskService, times(1)).saveAndUpdateTaskChain(sortedTaskList.capture());
        lists = sortedTaskList.getValue();

        new CampaignTaskService(null, null).sortByTimeArrange(lists);

        assertEquals(4, lists.size());
        assertEquals(CampaignExecutionTask.TASK_TYPE_GENERATE_FLOW, lists.get(0).getTaskType());
        assertEquals(CampaignExecutionTask.TASK_TYPE_GENERATE_FLOW, lists.get(1).getTaskType());
        assertEquals(newStartEngageTask3, lists.get(2));
        assertEquals(newStartEngageTask2, lists.get(3));
        assertEquals(startEngageTask1.getNextTaskId(),lists.get(0).getId());
    }

    @Test
    public void testPlanUpdateEngage_flow2() {
        // Mock data setup
        CampaignFullDataDTO campaignFullDataDTO = new CampaignFullDataDTO();
        MarketingCampaign campaign = new MarketingCampaign();
        campaign.setId(1L);
        campaignFullDataDTO.setCampaign(campaign); // Assume Campaign is a valid object

        CampaignOutboundEngage engage1 = new CampaignOutboundEngage();
        engage1.setTimeStrategy(TimingStrategyConstants.SCHEDULED);
        engage1.setAudienceStrategy(AudienceStrategyConstants.MANUAL_PERCENTAGE_SEGMENTATION);
        CampaignOutboundEngage engage2 = new CampaignOutboundEngage();
        engage2.setTimeStrategy(TimingStrategyConstants.SCHEDULED);
        engage2.setTimeData("{\"scheduledDate\":\"2024-08-05T00:00:00Z\"}");
        CampaignOutboundEngage engage3 = new CampaignOutboundEngage();
        engage3.setTimeStrategy(TimingStrategyConstants.SCHEDULED);
        engage3.setTimeData("{\"scheduledDate\":\"2024-08-01T00:00:00Z\"}");

        campaignFullDataDTO.setOutboundEngageList(Arrays.asList(engage1, engage2, engage3));

        //old chain :
        CampaignExecutionTask createListTask = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_GENERATE_LIST_AND_FOLDER);
        CampaignExecutionTask genFlowTask1 = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_GENERATE_FLOW);
        CampaignExecutionTask genFlowTask2 = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_GENERATE_FLOW);
        CampaignExecutionTask genFlowTask3 =  new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_GENERATE_FLOW);
        CampaignExecutionTask segmentTask = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_SEGMENTATION);
        CampaignExecutionTask startEngageTask1 = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_START_ENGAGE);
        startEngageTask1.setEngageId(1L);
        startEngageTask1.setTaskStatus(CampaignExecutionTask.TASK_STATUS_SCHEDULED);
        CampaignExecutionTask startEngageTask2 = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_START_ENGAGE);
        startEngageTask2.setEngageId(2L);
        CampaignExecutionTask startEngageTask3 = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_START_ENGAGE);
        startEngageTask3.setEngageId(3L);

        //new chain :
        CampaignExecutionTask newSegmentTask = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_SEGMENTATION);
        CampaignExecutionTask newStartEngageTask1 = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_START_ENGAGE);
        newStartEngageTask1.setEngageId(1L);
        CampaignExecutionTask newStartEngageTask2 = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_START_ENGAGE);
        newStartEngageTask2.setTaskTriggerDate(Instant.parse("2024-08-05T00:00:00Z"));
        newStartEngageTask2.setEngageId(2L);
        CampaignExecutionTask newStartEngageTask3 = new CampaignExecutionTask(CampaignExecutionTask.TASK_TYPE_START_ENGAGE);
        newStartEngageTask3.setEngageId(3L);
        newStartEngageTask3.setTaskTriggerDate(Instant.parse("2024-08-01T00:00:00Z"));

        // Setup mocks
        List<CampaignExecutionTask> notStartedOrPreparedTasks = Arrays.asList(startEngageTask1, startEngageTask2, startEngageTask3);
        when(campaignTaskService.getNotStartedAndScheduledTasks(anyLong())).thenReturn(notStartedOrPreparedTasks);
        when(campaignTaskService.getRunningTasks(anyLong())).thenReturn( Arrays.asList());
        when(campaignTaskService.createGenerateFlowTask(any(), any())).thenReturn(genFlowTask1).thenReturn(genFlowTask2);
        doNothing().when(campaignTaskExecutorService)._unscheduleTask(startEngageTask1);
        when(campaignSegmentTaskChain.createTaskChain(any(CampaignFullDataDTO.class))).thenReturn( Arrays.asList(newSegmentTask,newStartEngageTask1, newStartEngageTask2, newStartEngageTask3));
        doNothing().when(campaignTaskService).sortByTimeArrange(anyList());
        doNothing().when(campaignTaskService).saveAndUpdateTaskChain(anyList());

        // Call the method under test
        campaignTaskPlannerService.planUpdateEngage(campaignFullDataDTO, Arrays.asList(engage2, engage3));

        // Verify the interactions
        verify(campaignTaskService, times(1)).getNotStartedAndScheduledTasks(anyLong());
        verify(campaignTaskService, times(1)).getRunningTasks(anyLong());
        verify(campaignTaskExecutorService, times(1))._unscheduleTask(startEngageTask1);
        verify(campaignTaskService, times(1)).sortByTimeArrange(beforeSortTaskList.capture());
        List<CampaignExecutionTask> lists = beforeSortTaskList.getValue();
        assertEquals(5, lists.size());
        assertEquals(CampaignExecutionTask.TASK_TYPE_GENERATE_FLOW, lists.get(0).getTaskType());
        assertEquals(CampaignExecutionTask.TASK_TYPE_GENERATE_FLOW, lists.get(1).getTaskType());
        assertEquals(startEngageTask1, lists.get(2));
        assertEquals(startEngageTask2, lists.get(3));
        assertEquals(startEngageTask3, lists.get(4));
        verify(campaignTaskService, times(1)).saveAndUpdateTaskChain(sortedTaskList.capture());
        lists = sortedTaskList.getValue();

        new CampaignTaskService(null, null).sortByTimeArrange(lists);

        assertEquals(5, lists.size());
        assertEquals(CampaignExecutionTask.TASK_TYPE_GENERATE_FLOW, lists.get(0).getTaskType());
        assertEquals(CampaignExecutionTask.TASK_TYPE_GENERATE_FLOW, lists.get(1).getTaskType());
        assertEquals(startEngageTask1, lists.get(2));
        assertEquals(startEngageTask3, lists.get(3));
        assertEquals(startEngageTask2, lists.get(4));
        assertEquals(startEngageTask1.getNextTaskId(),lists.get(0).getId());
    }
}