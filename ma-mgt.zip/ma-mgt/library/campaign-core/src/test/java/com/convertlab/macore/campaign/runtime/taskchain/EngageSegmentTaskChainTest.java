package com.convertlab.macore.campaign.runtime.taskchain;

import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.runtime.task.CampaignTaskService;
import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EngageSegmentTaskChainTest {

    @Mock
    private CampaignTaskService campaignTaskService;

    @Mock
    private TimeStrategyService timeStrategyService;

    @InjectMocks
    private EngageSegmentTaskChain taskChain; // 假设你的createTaskChain方法在这个类中


    @Test
    void createTaskChain_NoOutboundEngages_ReturnsInitialTasksOnly() {
        CampaignFullDataDTO campaignFullData = mock(CampaignFullDataDTO.class);
        when(campaignFullData.getOutboundEngageList()).thenReturn(Collections.emptyList());

        List<CampaignExecutionTask> tasks = taskChain.createTaskChain(campaignFullData);

        assertTrue(tasks.size() > 0); // Assuming initializeTaskChain adds at least one task
        verify(campaignTaskService, never()).createSegmentationTask(any(), any());
        verify(campaignTaskService, never()).createStartEngageTask(any(), any());
    }

    @Test
    void createTaskChain_MultipleOutboundEngages_ReturnsAllTasks() {
        CampaignFullDataDTO campaignFullData = mock(CampaignFullDataDTO.class);
        CampaignOutboundEngage engage1 = mock(CampaignOutboundEngage.class);
        CampaignOutboundEngage engage2 = mock(CampaignOutboundEngage.class);
        when(campaignFullData.getOutboundEngageList()).thenReturn(Arrays.asList(engage1, engage2));
        when(engage1.getTimeStrategy()).thenReturn("Scheduled");
        when(engage2.getTimeStrategy()).thenReturn("NotScheduled");
        when(timeStrategyService.getScheduledTime(engage1)).thenReturn(Instant.now());
        when(timeStrategyService.getSegmentScheduledTime(any(Instant.class))).thenReturn(Instant.now());
        when(campaignTaskService.createSegmentationTask(any(), any())).thenReturn(mock(CampaignExecutionTask.class));
        when(campaignTaskService.createStartEngageTask(any(), any())).thenReturn(mock(CampaignExecutionTask.class));

        List<CampaignExecutionTask> tasks = taskChain.createTaskChain(campaignFullData);

        assertNotNull(tasks);
        assertEquals(7, tasks.size()); // Assuming initializeTaskChain adds no tasks, 2 tasks per engage
        verify(campaignTaskService).createSegmentationTask(any(), eq(engage1));
        verify(campaignTaskService).createStartEngageTask(any(), eq(engage1));
        verify(campaignTaskService).createSegmentationTask(any(), eq(engage2));
        verify(campaignTaskService).createStartEngageTask(any(), eq(engage2));
        verify(timeStrategyService).getScheduledTime(engage1);
        verify(timeStrategyService, never()).getScheduledTime(engage2);
    }

}
