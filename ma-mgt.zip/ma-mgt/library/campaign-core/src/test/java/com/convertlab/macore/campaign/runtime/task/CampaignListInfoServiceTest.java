package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.macore.campaign.mapper.CampaignListInfoMapper;
import com.convertlab.macore.campaign.model.entity.CampaignListInfo;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CampaignListInfoServiceTest {

    @Mock
    CampaignListInfoMapper campaignListInfoMapper;

    @InjectMocks
    CampaignListInfoService campaignListInfoService;



    @Test
    public void testSaveListInfo() {

        List<CampaignListInfo> listInfo = new ArrayList<>();
        listInfo.add(new CampaignListInfo());

        campaignListInfoService.saveListInfo(listInfo);

        verify(campaignListInfoMapper, times(1)).insert(any(CampaignListInfo.class));
    }

    @Test
    public void testLoadListInfo() {
        long campaignId = 1L;
        List<CampaignListInfo> expectedList = new ArrayList<>();
        when(campaignListInfoMapper.selectByCampaignId(campaignId)).thenReturn(expectedList);

        List<CampaignListInfo> resultList = campaignListInfoService.loadListInfo(campaignId);

        assertEquals(expectedList, resultList);
        verify(campaignListInfoMapper, times(1)).selectByCampaignId(campaignId);
    }

    @Test
    public void testFindListInfoByType() {
        List<CampaignListInfo> listInfos = new ArrayList<>();
        CampaignListInfo info1 = new CampaignListInfo();
        info1.setListType("Email");
        listInfos.add(info1);
        CampaignListInfo info2 = new CampaignListInfo();
        info2.setListType("SMS");
        listInfos.add(info2);

        CampaignListInfo result = campaignListInfoService.findListInfoByType(listInfos, "Email");

        assertNotNull(result);
        assertEquals("Email", result.getListType());
    }


    @Test
    public void testUpdateById() {
        CampaignListInfo listInfo = new CampaignListInfo();
        listInfo.setId(1L);

        campaignListInfoService.updateById(listInfo);

        verify(campaignListInfoMapper, times(1)).updateById(listInfo);
    }

    @Test
    public void testGetCampaignLevelInfo() {
        long campaignId = 1L;
        List<CampaignListInfo> campaignInfo = new ArrayList<>();
        CampaignListInfo info1 = new CampaignListInfo();
        info1.setCampaignId(campaignId);
        info1.setEngageId(0L); // Campaign level info
        campaignInfo.add(info1);

        CampaignListInfo info2 = new CampaignListInfo();
        info2.setCampaignId(campaignId);
        info2.setEngageId(1L); // Not campaign level info
        campaignInfo.add(info2);

        List<CampaignListInfo> result = campaignListInfoService.getCampaignLevelInfo(campaignId, campaignInfo);

        assertEquals(1, result.size());
        assertTrue(result.contains(info1));
    }

    @Test
    public void testGetEngageLevelListInfo() {
        long campaignId = 1L;
        long engageId = 1L;
        List<CampaignListInfo> campaignInfo = new ArrayList<>();
        CampaignListInfo info1 = new CampaignListInfo();
        info1.setCampaignId(campaignId);
        info1.setEngageId(engageId);
        campaignInfo.add(info1);

        CampaignListInfo info2 = new CampaignListInfo();
        info2.setCampaignId(campaignId);
        info2.setEngageId(2L); // Different engagement
        campaignInfo.add(info2);

        List<CampaignListInfo> result = campaignListInfoService.getEngageLevelListInfo(campaignId, engageId, campaignInfo);

        assertEquals(1, result.size());
        assertTrue(result.contains(info1));
    }

    @Test
    public void testSaveListInfoErrorHandling() {
        List<CampaignListInfo> listInfo = new ArrayList<>();
        listInfo.add(new CampaignListInfo());
        doThrow(new RuntimeException()).when(campaignListInfoMapper).insert(any(CampaignListInfo.class));
        assertThrows(RuntimeException.class, () -> campaignListInfoService.saveListInfo(listInfo));
    }



    @Test
    public void testSelectByCampaignIdAndEngageId() {
        long campaignId = 1L;
        long engageId = 100L;
        List<CampaignListInfo> expectedList = new ArrayList<>();
        expectedList.add(new CampaignListInfo());

        when(campaignListInfoMapper.selectByCampaignIdAndEngageId(campaignId, engageId)).thenReturn(expectedList);

        List<CampaignListInfo> resultList = campaignListInfoService.selectByCampaignIdAndEngageId(campaignId, engageId);

        assertEquals(expectedList, resultList);
        verify(campaignListInfoMapper, times(1)).selectByCampaignIdAndEngageId(campaignId, engageId);
    }


    @Test
    public void testGetCampaignListInfo_Success() {
        long campaignId = 123L;
        List<CampaignListInfo> expectedList = new ArrayList<>();
        expectedList.add(new CampaignListInfo()); // Add details to CampaignListInfo as needed

        when(campaignListInfoMapper.selectByCampaignId(campaignId)).thenReturn(expectedList);

        List<CampaignListInfo> resultList = campaignListInfoService.getCampaignListInfo(campaignId);

        assertSame(expectedList, resultList, "The retrieved list should be the same as expected");
        verify(campaignListInfoMapper, times(1)).selectByCampaignId(campaignId);
    }


    @Test
    public void testGetCampaignListInfo_WithCampaignAndEngageId_Success() {
        long campaignId = 1L;
        long engageId = 2L;
        List<CampaignListInfo> expectedList = new ArrayList<>();
        expectedList.add(new CampaignListInfo()); // Populate with mock data as necessary

        when(campaignListInfoMapper.selectByCampaignIdAndEngageId(campaignId, engageId)).thenReturn(expectedList);

        List<CampaignListInfo> resultList = campaignListInfoService.getCampaignListInfo(campaignId, engageId);

        assertSame(expectedList, resultList, "The retrieved list should be the same as expected");
        verify(campaignListInfoMapper, times(1)).selectByCampaignIdAndEngageId(campaignId, engageId);
    }

}