package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.foundation.library.context.Context;
import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.runtime.taskchain.AbstractPeriodicTaskChainStrategy;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
class AbstractTaskRuntimeServiceTest {
    @Mock
    private CampaignTaskService campaignTaskService;
    @Mock
    private CampaignExecutionTask task;

    AbstractTaskRuntimeService taskRuntimeService;
    @BeforeEach
    void setUp() {
        taskRuntimeService = new AbstractTaskRuntimeService(){
            @Override
            public TaskResult checkProgress(CampaignExecutionTask task) {
                return null;
            }

            @Override
            public TaskResult onStart(CampaignExecutionTask task) {
                return null;
            }

            @Override
            public void onFinish(CampaignExecutionTask task) {

            }

        };
        taskRuntimeService.campaignTaskService = campaignTaskService;
    }

    @Test
    void finish_UpdatesTaskStatusToFinished() {

        doNothing().when(campaignTaskService).updateTaskStatus(task, CampaignExecutionTask.TASK_STATUS_FINISHED);
        taskRuntimeService.finish(task);

        verify(campaignTaskService).updateTaskStatus(task, CampaignExecutionTask.TASK_STATUS_FINISHED);
    }



}