package com.convertlab.macore.campaign.runtime;

import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.runtime.task.ITaskRuntimeService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

import static java.lang.Thread.sleep;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TaskExecutorServiceTest {

    @Mock
    private TaskServiceFactory taskServiceFactory;

    @Mock
    private CampaignExecutionTask task;

    @Mock
    private ITaskRuntimeService taskService;

    @Mock
    private CampaignTaskExecutorService campaignTaskExecutorService;

    @Mock
    private TaskExecutorAction action;

    @Mock
    private Executor executor;



    @InjectMocks
    private TaskExecutorService taskExecutor;

    @Test
    void initExecutor_InitializesThreadPoolTaskExecutor() {
        TaskExecutorService campaignTaskExecutorService = new TaskExecutorService(taskServiceFactory);
        String expectedNamePrefix = "CampaignTaskExecutorService-";
        int expectedPoolSize = 10;

        campaignTaskExecutorService.initExecutor("CampaignTaskExecutorService", expectedPoolSize);

        ThreadPoolTaskExecutor executor = campaignTaskExecutorService.threadPoolTaskExecutor;
        assertNotNull(executor);
        assertEquals(expectedPoolSize, executor.getCorePoolSize());
        assertEquals(expectedPoolSize, executor.getMaxPoolSize());
        assertTrue(executor.getThreadNamePrefix().startsWith(expectedNamePrefix));

        Executor taskExecutor = campaignTaskExecutorService.executor;
        assertNotNull(taskExecutor);

        ThreadPoolExecutor threadPoolExecutor = campaignTaskExecutorService.executorService;
        assertEquals(expectedPoolSize, threadPoolExecutor.getCorePoolSize());
        assertEquals(expectedPoolSize, threadPoolExecutor.getMaximumPoolSize());
    }


    @Test
    void runTaskAsync_ExecutesActionWithCorrectService() throws Exception {
        when(taskServiceFactory.getTaskService(task)).thenReturn(taskService);
        taskExecutor.executor = this.executor;
        taskExecutor.runTaskAsync(task, action, campaignTaskExecutorService);

        verify(taskServiceFactory).getTaskService(task);
        verify(executor).execute(any(Runnable.class));}

    @Test
    void runTaskAsync_ExecutesActionWithCorrectService2() throws Exception {
        when(taskServiceFactory.getTaskService(task)).thenReturn(taskService);
        taskExecutor.init();
        doNothing().when(action).execute(any(), any());

        taskExecutor.runTaskAsync(task, action, campaignTaskExecutorService);
        sleep(100);

        verify(taskServiceFactory).getTaskService(task);
        verify(action).execute(taskService, task);
    }

    @Test
    void runTaskAsync_HandlesExceptionsAndFailsTask() throws Exception {
        when(taskServiceFactory.getTaskService(task)).thenReturn(taskService);
        taskExecutor.init();
        doThrow(new RuntimeException("Task execution failed")).when(action).execute(any(), any());

        taskExecutor.runTaskAsync(task, action, campaignTaskExecutorService);
        sleep(100);

        verify(taskServiceFactory).getTaskService(task);
        verify(action).execute(taskService, task);
        verify(campaignTaskExecutorService)._failTask(eq(task), any(RuntimeException.class));
    }
}