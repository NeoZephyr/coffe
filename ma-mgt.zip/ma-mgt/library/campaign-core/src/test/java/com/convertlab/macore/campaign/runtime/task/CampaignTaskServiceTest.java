package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.macore.campaign.mapper.CampaignExecutionTaskMapper;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class CampaignTaskServiceTest {

    @Mock
    CampaignExecutionTaskMapper campaignExecutionTaskMapper;

    @InjectMocks
    CampaignTaskService campaignTaskService ;

    @Test
    void sortByTimeArrange_EmptyList_NoException() {
        List<CampaignExecutionTask> taskList = Collections.emptyList();
        assertDoesNotThrow(() -> campaignTaskService.sortByTimeArrange(taskList));
    }

    @Test
    void sortByTimeArrange_NonNullDates_SortedCorrectly() {
        Instant now = Instant.now();
        CampaignExecutionTask task1 = new CampaignExecutionTask();
        task1.setTaskTriggerDate(now.plusSeconds(10L));
        CampaignExecutionTask task2 = new CampaignExecutionTask();
        task2.setTaskTriggerDate(now.plusSeconds(20));
        CampaignExecutionTask task3 = new CampaignExecutionTask();
        task3.setTaskTriggerDate(now);
        List<CampaignExecutionTask> taskList = Arrays.asList(task1, task2, task3);

        campaignTaskService.sortByTimeArrange(taskList);

        assertEquals(task3, taskList.get(0));
        assertEquals(task1, taskList.get(1));
        assertEquals(task2, taskList.get(2));
    }

    @Test
    void sortByTimeArrange_NullAndNonNullDates_SortedCorrectly() {
        Instant now = Instant.now();
        CampaignExecutionTask task1 = new CampaignExecutionTask();
        CampaignExecutionTask task2 = new CampaignExecutionTask();
        task2.setTaskTriggerDate(now.plusSeconds(10));
        CampaignExecutionTask task3 = new CampaignExecutionTask();
        List<CampaignExecutionTask> taskList = Arrays.asList(task1, task2, task3);

        campaignTaskService.sortByTimeArrange(taskList);

        assertEquals(task1, taskList.get(0));
        assertEquals(task3, taskList.get(1));
        assertEquals(task2, taskList.get(2));
    }

    @Test
    void sortByTimeArrange_AllNullDates_OrderUnchanged() {
        CampaignExecutionTask task1 = new CampaignExecutionTask();
        CampaignExecutionTask task2 = new CampaignExecutionTask();
        List<CampaignExecutionTask> taskList = Arrays.asList(task1, task2);

        campaignTaskService.sortByTimeArrange(taskList);

        assertEquals(task1, taskList.get(0));
        assertEquals(task2, taskList.get(1));
    }


    @Test
    public void testSaveAndUpdateTaskChainWithEmptyList() {
        List<CampaignExecutionTask> emptyList = Collections.emptyList();
        campaignTaskService.saveAndUpdateTaskChain(emptyList);
        verify(campaignExecutionTaskMapper, never()).upsert(any(CampaignExecutionTask.class));
    }

    @Test
    public void testSaveAndUpdateTaskChainWithOneTask() {
        CampaignExecutionTask task = new CampaignExecutionTask();
        task.setId("task1");

        campaignTaskService.saveAndUpdateTaskChain(Collections.singletonList(task));
        assertNull(task.getNextTaskId());
        verify(campaignExecutionTaskMapper).upsert(task);
    }

    @Test
    public void testSaveAndUpdateTaskChainWithMultipleTasks() {
        CampaignExecutionTask task1 = new CampaignExecutionTask();
        task1.setId("task1");
        CampaignExecutionTask task2 = new CampaignExecutionTask();
        task2.setId("task2");
        CampaignExecutionTask task3 = new CampaignExecutionTask();
        task3.setId("task3");

        List<CampaignExecutionTask> tasks = Arrays.asList(task1, task2, task3);
        campaignTaskService.saveAndUpdateTaskChain(tasks);
        assertEquals("task2", task1.getNextTaskId());
        assertEquals("task3", task2.getNextTaskId());
        assertNull(task3.getNextTaskId());

        verify(campaignExecutionTaskMapper).upsert(task1);
        verify(campaignExecutionTaskMapper).upsert(task2);
        verify(campaignExecutionTaskMapper).upsert(task3);
    }


    @Test
    public void testCreateSegmentationTask() {


        MarketingCampaign campaign = new MarketingCampaign();
        campaign.setId(123L);
        // Action
        CampaignExecutionTask resultTask = campaignTaskService.createSegmentationTask(campaign, null);

        // Assert
        assertNotNull(resultTask);
        assertTrue(resultTask.getIsAsyncRemoteCall());
        assertEquals(CampaignExecutionTask.TASK_TYPE_SEGMENTATION, resultTask.getTaskType());
        assertEquals(-1L, resultTask.getEngageId());
        assertEquals(123L, resultTask.getCampaignId());

    }
}