package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.macore.campaign.common.utils.TimingStrategyConstants;
import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.dto.ChannelInfo;
import com.convertlab.macore.campaign.model.dto.SaveFlowResponse;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTaskData;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.service.CampaignService;
import com.convertlab.macore.campaign.service.legacy.cms.client.CmsServiceClient;
import com.convertlab.macore.channel.service.generator.ChannelFlowSchemaGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;
import freemarker.template.Configuration;
import freemarker.template.Template;
import org.checkerframework.checker.units.qual.C;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FlowGenerationTaskServiceTest {

    @Mock
    private CampaignBatchInfoService campaignBatchInfoService;
    @Mock
    private ChannelFlowSchemaGenerator channelFlowSchemaGenerator;

    @Mock
    private CmsServiceClient cmsServiceClient;

    @Mock
    private MaCoreService maCoreService;
    @Mock
    private CampaignService campaignService;
    @Mock
    private CampaignTaskService campaignTaskService;
    @Mock
    private Configuration freemarkerConfig;
    @InjectMocks
    FlowGenerationTaskService flowGenerationTaskService;
    @BeforeEach
    public void setUp() throws Exception {
        flowGenerationTaskService.init();  // Initialize templates
    }

    @Test
    public void testInit_LoadsTemplatesSuccessfully() {
        assertDoesNotThrow(() -> flowGenerationTaskService.init());
    }


    @Test
    public void testOnStart_SuccessfulFlowGenerationAndSave() throws Exception {
        CampaignExecutionTask task = new CampaignExecutionTask();
        task.setCampaignId(1L);
        task.setEngageId(2L);
        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO();
        CampaignOutboundEngage outboundEngage = new CampaignOutboundEngage();
        outboundEngage.setCampaignId(5L);
        outboundEngage.setId(2L);
        outboundEngage.setListId(3L);
        outboundEngage.setTimeStrategy(TimingStrategyConstants.IMMEDIATE);
        outboundEngage.setChannelData("{\"messagingTypes\":[{\"channelType\":\"sms\",\"messagingType\":\"sms-sending_sms\",\"channelTemplateId\":\"1750760038907250688\",\"channelTemplateName\":\"test041201\",\"tunnelId\":\"76\"}]}");
        outboundEngage.setFlowId(123L);
        campaignFullData.setOutboundEngageList(Arrays.asList(outboundEngage));
        MarketingCampaign campaign = new MarketingCampaign();
        campaign.setId(5L);
        campaign.setUuid("Test Campaign");
        campaignFullData.setCampaign(campaign);

        when(campaignService.getCampaignFullData(task.getCampaignId())).thenReturn(campaignFullData);
        when(channelFlowSchemaGenerator.gen(anyString(),anyString(),anyString(),anyLong(),anyString())).thenReturn("flowSchema");
        SaveFlowResponse saveFlowResponse = new SaveFlowResponse();
        saveFlowResponse.setId(123L);

        when(maCoreService.saveFlow(anyLong(), anyString(), anyString(), any())).thenReturn(saveFlowResponse);
        when(cmsServiceClient.addCamapignContent(any())).thenReturn(null);
        CampaignExecutionTaskData taskData = new CampaignExecutionTaskData();
        taskData.setDataValue("456");
        when(campaignTaskService.getCampaignContextData(anyLong(), anyString())).thenReturn(taskData);
        doNothing().when(campaignBatchInfoService).refreshBatchInfo(anyLong(), anyLong(), any());

        flowGenerationTaskService.objectMapper = new ObjectMapper();
        TaskResult result = flowGenerationTaskService.onStart(task);

        assertTrue(result.isFinish());
        verify(maCoreService, times(1)).saveFlow(anyLong(), anyString(), anyString(), any());
        verify(campaignBatchInfoService, times(1)).refreshBatchInfo(anyLong(), anyLong(), any());
    }

    @Test
    void testNormalCase() throws Exception {
        flowGenerationTaskService.objectMapper = new ObjectMapper();
        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO(); // 假设有对应的构造方法或者设置方法
        MarketingCampaign campaign = new MarketingCampaign();
        campaign.setId(123L);
        campaignFullData.setCampaign(campaign); // 假设 Campaign 类有相应的构造函数

        String jsonInput = "{\"messagingTypes\":[{\"channelType\":\"sms\",\"messagingType\":\"transactional\",\"tunnelId\":\"tunnel123\",\"channelTemplateId\":101,\"channelTemplateName\":\"Template A\"},{\"channelType\":\"email\",\"messagingType\":\"promotional\",\"tunnelId\":\"tunnel456\",\"channelTemplateId\":102,\"channelTemplateName\":\"Template B\"}]}";

        CampaignOutboundEngage engage = new CampaignOutboundEngage();
        engage.setChannelData(jsonInput);
        List<ChannelInfo> result = flowGenerationTaskService.getChannelInfos(campaignFullData, engage);
        assertEquals(2, result.size());

        // 验证第一个 ChannelInfo 的详细信息
        ChannelInfo smsInfo = result.get(0);
        assertEquals("sms", smsInfo.getChannelType());
        assertEquals("transactional", smsInfo.getMessagingType());
        assertEquals(101, smsInfo.getTemplateId());
        assertEquals("Template A", smsInfo.getTemplateName());

        // 验证第二个 ChannelInfo 的详细信息
        ChannelInfo emailInfo = result.get(1);
        assertEquals("email", emailInfo.getChannelType());
        assertEquals("promotional", emailInfo.getMessagingType());
        assertEquals(102, emailInfo.getTemplateId());
        assertEquals("Template B", emailInfo.getTemplateName());
    }

    @Test
    void testJsonProcessingException() {
        flowGenerationTaskService.objectMapper = new ObjectMapper();
        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO(); // 假设有对应的构造方法或者设置方法
        MarketingCampaign campaign = new MarketingCampaign();
        campaign.setId(123L);
        campaignFullData.setCampaign(campaign);

        // 故意制造格式错误的 JSON
        String jsonInput = "{ 'messagingTypes': [ { 'channelType': 'sms', 'messagingType': 'transactional' }";

        CampaignOutboundEngage engage = new CampaignOutboundEngage();
        engage.setChannelData(jsonInput);

        assertThrows(RuntimeException.class, () -> {
            flowGenerationTaskService.getChannelInfos(campaignFullData, engage);
        });
    }

    @Test
    void testEmptyChannelData() throws Exception {
        flowGenerationTaskService.objectMapper = new ObjectMapper();
        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO(); // 假设有对应的构造方法或者设置方法
        MarketingCampaign campaign = new MarketingCampaign();
        campaign.setId(123L);
        campaignFullData.setCampaign(campaign);

        String jsonInput = "{}"; // 空的 JSON 数据

        CampaignOutboundEngage engage = new CampaignOutboundEngage();
        engage.setChannelData(jsonInput);
        List<ChannelInfo> result = flowGenerationTaskService.getChannelInfos(campaignFullData, engage);
        assertTrue(result.isEmpty()); // 预期返回空列表
    }

    @Test
    void testThirdPartyChannel() throws Exception {
        flowGenerationTaskService.objectMapper = new ObjectMapper();
        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO(); // 假设有对应的构造方法或者设置方法
        MarketingCampaign campaign = new MarketingCampaign();
        campaign.setId(123L);
        campaignFullData.setCampaign(campaign);

        String jsonInput = "{\"messagingTypes\":[{\"channelType\":\"sms\",\"messagingType\":\"transactional\",\"channelTemplateId\":101,\"channelTemplateName\":\"Template C\",\"isThirdPartyChannel\":true,\"actionBody\":{},\"pluginId\":\"123\"}]}";

        CampaignOutboundEngage engage = new CampaignOutboundEngage();
        engage.setChannelData(jsonInput);
        List<ChannelInfo> result = flowGenerationTaskService.getChannelInfos(campaignFullData, engage);
        assertEquals(1, result.size());

        // 验证 ChannelInfo 是否正确处理为第三方渠道
        ChannelInfo thirdPartyInfo = result.get(0);
        assertTrue(thirdPartyInfo.isThirdPartyChannel());
        assertEquals("sms", thirdPartyInfo.getChannelType());
        assertEquals("transactional", thirdPartyInfo.getMessagingType());
        assertEquals(101, thirdPartyInfo.getTemplateId());
        assertEquals("Template C", thirdPartyInfo.getTemplateName());
        assertEquals("{}", thirdPartyInfo.getActionBody()); // 验证 actionBody 是否正确设置
    }


    @Test
    void testNumberFormat(){
        try {
            // 创建Freemarker配置实例
            Configuration cfg = new Configuration(Configuration.VERSION_2_3_31);

            // 定义模板内容
            String templateContent = "Hello ${number?c}";

            // 创建模板对象
            Template template = new Template("templateName", new StringReader(templateContent), cfg);

            // 创建数据模型
            Map<String, Object> dataModel = new HashMap<>();
            dataModel.put("number", 123456);

            // 合并模板和数据模型
            StringWriter out = new StringWriter();
            template.process(dataModel, out);
            String string = out.getBuffer().toString();

            assertEquals("Hello 123456", string);

        }catch(Exception e){
            e.printStackTrace();
        }
    }

}