package com.convertlab.macore.campaign.common.utils;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class NameUtilsTest {


    @Test
    void getCampaignListFolderName_ReturnsExpectedName_WhenIdIsPositive() {
        long campaignId = 123;
        String expected = FolderNameUtils.CAMPAIGN_LIST_PREFIX + "123";
        assertEquals(expected, FolderNameUtils.getCampaignListFolderName(campaignId));
    }

    @Test
    void getCampaignListFolderName_ThrowsException_WhenIdIsNegative() {
        long campaignId = -1;
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            FolderNameUtils.getCampaignListFolderName(campaignId);
        });
        assertEquals("Campaign ID must be positive.", exception.getMessage());
    }

    @Test
    void getCampaignFlowFolderName_ReturnsExpectedName_WhenIdIsPositive() {
        long campaignId = 456;
        String expected = FolderNameUtils.CAMPAIGN_FLOW_PREFIX + "456";
        assertEquals(expected, FolderNameUtils.getCampaignFlowFolderName(campaignId));
    }

    @Test
    void getCampaignFlowFolderName_ThrowsException_WhenIdIsNegative() {
        long campaignId = -2;
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            FolderNameUtils.getCampaignFlowFolderName(campaignId);
        });
        assertEquals("Campaign ID must be positive.", exception.getMessage());
    }

    @Test
    void testGetMainListName_CampaignIdOnly() {
        long campaignId = 123;
        String expected = "campaign_123_ciel_main_group";
        assertEquals(expected, NameUtils.getMainListName(campaignId));
    }

    @Test
    void testGetMainListName_CampaignIdAndEngageId() {
        long campaignId = 123;
        long engageId = 456;
        String expected = "campaign_123_ciel_main_group_engage_456";
        assertEquals(expected, NameUtils.getMainListName(campaignId, engageId));
    }

    @Test
    void testGetFilteredListName_CampaignIdOnly() {
        long campaignId = 123;
        String expected = "campaign_123_ciel_filtered_group";
        assertEquals(expected, NameUtils.getFilteredListName(campaignId));
    }

    @Test
    void testGetFilteredListName_CampaignIdAndEngageId() {
        long campaignId = 123;
        long engageId = 456;
        String expected = "campaign_123_ciel_filtered_group_engage_456";
        assertEquals(expected, NameUtils.getFilteredListName(campaignId, engageId));
    }

    @Test
    void testGetExcludedListName_CampaignIdOnly() {
        long campaignId = 123;
        String expected = "campaign_123_ciel_excluded_group";
        assertEquals(expected, NameUtils.getExcludedListName(campaignId));
    }

    @Test
    void testGetExcludedListName_CampaignIdAndEngageId() {
        long campaignId = 123;
        long engageId = 456;
        String expected = "campaign_123_ciel_excluded_group_engage_456";
        assertEquals(expected, NameUtils.getExcludedListName(campaignId, engageId));
    }

}