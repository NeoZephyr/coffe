package com.convertlab.macore.campaign.service;

import com.convertlab.macore.campaign.model.dto.CampaignEngageBatchContext;
import com.convertlab.macore.campaign.model.dto.CampaignReportDataLineDto;
import com.convertlab.macore.campaign.model.dto.CampaignReportQuery;
import com.google.common.collect.ImmutableMap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.convertlab.macore.campaign.service.CampaignStatService.FILTER_ID_FIELD;
import static com.convertlab.macore.campaign.service.CampaignStatService.FILTER_NAME_FIELD;

public class CampaignReportDataSetHelper {

    //create List of GroupAggregateDim
    public static List<CampaignReportDataLineDto.GroupAggregateDim> createGroupAggregateDim(Long campaignId, Map<Long, String> engageIdDateUnitMap) {
        return engageIdDateUnitMap.entrySet().stream().map(entry ->
                new CampaignReportDataLineDto.GroupAggregateDim(campaignId, entry.getKey(), entry.getValue())
        ).collect(Collectors.toList());
    }


    /**
     *  GroupFactDataRow代表了group 统计表聚合之后的一条记录
     *  和 @CampaignReportDataLineDto.GroupStat 是不一样的，这里更贴近数据库聚合后的结构
     *  而 @CampaignReportDataLineDto.GroupStat 的则是代表 campaign或者engage level 多条RowData聚合后的结果
     */
    public static class GroupFactDataRow {

        int campaignFilteredFlag;
        int campaignControlFlag;
        int engageFilteredFlag;
        int engageControlFlag;
        int groupCount;

        public GroupFactDataRow(int campaignFilteredFlag, int campaignControlFlag, int engageFilteredFlag, int engageControlFlag, int groupCount) {
            this.campaignFilteredFlag = campaignFilteredFlag;
            this.campaignControlFlag = campaignControlFlag;
            this.engageFilteredFlag = engageFilteredFlag;
            this.engageControlFlag = engageControlFlag;
            this.groupCount = groupCount;
        }

        public Map<String, Object> dataMap() {
            ImmutableMap<String, Object> dataMap = ImmutableMap.of(
                    CampaignReportDataLineDto.CAMPAIGN_FILTERED_FLAG_COLUMN, campaignFilteredFlag,
                    CampaignReportDataLineDto.CAMPAIGN_CONTROL_FLAG_COLUMN, campaignControlFlag,
                    CampaignReportDataLineDto.ENGAGE_FILTERED_FLAG_COLUMN, engageFilteredFlag,
                    CampaignReportDataLineDto.ENGAGE_CONTROL_FLAG_COLUMN, engageControlFlag,
                    CampaignReportDataLineDto.GROUP_COUNT_COLUMN, String.valueOf(groupCount)
            );
            return dataMap;
        }

    }

    /**
     * 使用如下 native sql 获取campaign_group_facts 表的聚合结果
     * <code>
     *     select campaign_id, engage_id,
     *        campaign_filtered_flag,
     *        campaign_control_flag,
     *        -- gdql has converted group_date to timestamp
     *         trunc(FROM_UTC_TIMESTAMP( CAST(group_date/1000 AS TIMESTAMP), 'Asia/Shanghai'), 'DD') as group_date,
     *        engage_filtered_flag,
     *        engage_control_flag,
     *        count(profile_id)                                            as cnt
     * from campaign_group_facts
     * where campaign_id in (17590)
     * group by campaign_id, campaign_filtered_flag, campaign_control_flag, engage_id, group_date, engage_filtered_flag,
     *          engage_control_flag;
     * </code>
     * @param groupFactDataRowList
     * @return
     */
    public static List<Map<String, Object>> createGroupFactDataRowList(GroupFactDataRow... groupFactDataRowList) {
        return Arrays.stream(groupFactDataRowList).map(GroupFactDataRow::dataMap).collect(Collectors.toList());
    }

    public static List<Map<String, Object>> createEventStageStatList(CampaignReportDataLineDto.BatchEventStageStat... batchEventStageStatList) {
        return Arrays.stream(batchEventStageStatList)
                .flatMap( stat  -> stat.getRawEventStageCountMap().stream())
                .collect(Collectors.toList());
    }



    public static CampaignEngageBatchContext mockBatchContext() {
        CampaignEngageBatchContext batchContext = new CampaignEngageBatchContext();
        Map<Long,  Map<String, Object>> campaignInfoMap = new HashMap<>();
        Long campaignid = 17590L;
        Map<String, Object> singleCampaignInfo = new HashMap<>();
        singleCampaignInfo.put("campaignName", "test_campaign");
        singleCampaignInfo.put("campaignCode", "test_campaign_code");
        singleCampaignInfo.put("campaignId", campaignid);
        campaignInfoMap.put(campaignid, singleCampaignInfo);
        batchContext.setCampaignInfoMap(campaignInfoMap);

        Map<Long, Map<String, Object>> engageInfoMap = new HashMap<>();
        Map<String, Object> engageInfo01 = new HashMap<>();
        engageInfo01.put("engageCode", "test_engage_code_01");
        engageInfo01.put("engageId", 2753L);
        engageInfo01.put("c_channel", "");
        Map<String, Object> engageInfo02 = new HashMap<>();
        engageInfo02.put("engageCode", "test_engage_code_02");
        engageInfo02.put("engageId", 2754L);
        engageInfo02.put("c_channel", "");
        Map<String, Object> engageInfo03 = new HashMap<>();
        engageInfo03.put("engageCode", "test_engage_code_03");
        engageInfo03.put("engageId", 2755L);
        engageInfo03.put("c_channel", "");

        engageInfoMap.put(2753L, engageInfo01);
        engageInfoMap.put(2754L, engageInfo02);
        engageInfoMap.put(2755L, engageInfo03);

        batchContext.setEngageInfoMap(engageInfoMap);

        /**
         * | batch\_id | template\_id | template\_name |
         * | :--- | :--- | :--- |
         * | flow-96433\_0\_false@@101 | 1750792804172564480 | test041201-短链 |
         * | flow-96433\_0\_false@@104 | 1647199279359725568 | 123456 |
         * | flow-96433\_0\_false@@107 | 1750879025607477248 | asdfasdf |
         * | flow-96433\_0\_false@@110 | 1750760038907250688 | test041201 |
         * | flow-96433\_0\_false@@113 | 1694864313732562944 | fcx |
         * | flow-96433\_0\_false@@115 | 1753539813816139776 | campaign\_test-短链 |
         * | flow-96434\_0\_false@@101 | 1750792804172564480 | test041201-短链 |
         * | flow-96434\_0\_false@@104 | 1623328632267341824 | 12423 |
         * | flow-96434\_0\_false@@107 | 1750879025607477248 | asdfasdf |
         * | flow-96434\_0\_false@@110 | 1750760038907250688 | test041201 |
         * | flow-96434\_0\_false@@113 | 1694864313732562944 | fcx |
         * | flow-96434\_0\_false@@115 | 1753539813816139776 | campaign\_test-短链 |
         * | flow-96435\_0\_false@@101 | 1750792804172564480 | test041201-短链 |
         * | flow-96435\_0\_false@@104 | 1623328632267341824 | 12423 |
         * | flow-96435\_0\_false@@107 | 1750879025607477248 | asdfasdf |
         * | flow-96435\_0\_false@@110 | 1750760038907250688 | test041201 |
         * | flow-96435\_0\_false@@113 | 1694864313732562944 | fcx |
         * | flow-96435\_0\_false@@115 | 1753539813816139776 | campaign\_test-短链 |
         */
        List<CampaignEngageBatchContext.CampaignEngageBatchDim> engageBacheDimList = new ArrayList<>();
        engageBacheDimList.add(CampaignEngageBatchContext.CampaignEngageBatchDim.builder().batchId("flow-96433_0_false@@101").templateId(1750792804172564480L).templateName("test041201-短链").build());
        engageBacheDimList.add(CampaignEngageBatchContext.CampaignEngageBatchDim.builder().batchId("flow-96433_0_false@@104").templateId(1647199279359725568L).templateName("123456").build());
        engageBacheDimList.add(CampaignEngageBatchContext.CampaignEngageBatchDim.builder().batchId("flow-96433_0_false@@107").templateId(1750879025607477248L).templateName("asdfasdf").build());
        engageBacheDimList.add(CampaignEngageBatchContext.CampaignEngageBatchDim.builder().batchId("flow-96433_0_false@@110").templateId(1750760038907250688L).templateName("test041201").build());
        engageBacheDimList.add(CampaignEngageBatchContext.CampaignEngageBatchDim.builder().batchId("flow-96433_0_false@@113").templateId(1694864313732562944L).templateName("fcx").build());
        engageBacheDimList.add(CampaignEngageBatchContext.CampaignEngageBatchDim.builder().batchId("flow-96433_0_false@@115").templateId(1753539813816139776L).templateName("campaign_test-短链").build());
        engageBacheDimList.add(CampaignEngageBatchContext.CampaignEngageBatchDim.builder().batchId("flow-96434_0_false@@101").templateId(1750792804172564480L).templateName("test041201-短链").build());
        engageBacheDimList.add(CampaignEngageBatchContext.CampaignEngageBatchDim.builder().batchId("flow-96434_0_false@@104").templateId(1623328632267341824L).templateName("12423").build());
        engageBacheDimList.add(CampaignEngageBatchContext.CampaignEngageBatchDim.builder().batchId("flow-96434_0_false@@107").templateId(1750879025607477248L).templateName("asdfasdf").build());
        engageBacheDimList.add(CampaignEngageBatchContext.CampaignEngageBatchDim.builder().batchId("flow-96434_0_false@@110").templateId(1750760038907250688L).templateName("test041201").build());
        engageBacheDimList.add(CampaignEngageBatchContext.CampaignEngageBatchDim.builder().batchId("flow-96434_0_false@@113").templateId(1694864313732562944L).templateName("fcx").build());
        engageBacheDimList.add(CampaignEngageBatchContext.CampaignEngageBatchDim.builder().batchId("flow-96434_0_false@@115").templateId(1753539813816139776L).templateName("campaign_test-短链").build());
        engageBacheDimList.add(CampaignEngageBatchContext.CampaignEngageBatchDim.builder().batchId("flow-96435_0_false@@101").templateId(1750792804172564480L).templateName("test041201-短链").build());
        engageBacheDimList.add(CampaignEngageBatchContext.CampaignEngageBatchDim.builder().batchId("flow-96435_0_false@@104").templateId(1623328632267341824L).templateName("12423").build());
        engageBacheDimList.add(CampaignEngageBatchContext.CampaignEngageBatchDim.builder().batchId("flow-96435_0_false@@107").templateId(1750879025607477248L).templateName("asdfasdf").build());
        engageBacheDimList.add(CampaignEngageBatchContext.CampaignEngageBatchDim.builder().batchId("flow-96435_0_false@@110").templateId(1750760038907250688L).templateName("test041201").build());
        engageBacheDimList.add(CampaignEngageBatchContext.CampaignEngageBatchDim.builder().batchId("flow-96435_0_false@@113").templateId(1694864313732562944L).templateName("fcx").build());
        engageBacheDimList.add(CampaignEngageBatchContext.CampaignEngageBatchDim.builder().batchId("flow-96435_0_false@@115").templateId(1753539813816139776L).templateName("campaign_test-短链").build());

        batchContext.setEngageBatchDimList(engageBacheDimList);


        Map<Long, Map<String, Object>> filterInfoMap = new HashMap<>();
        Map<String, Object> campaignFilterInfo = new HashMap<>();
        campaignFilterInfo.put(FILTER_ID_FIELD, 1L);
        campaignFilterInfo.put(FILTER_NAME_FIELD, "filter_name_01");
        filterInfoMap.put(campaignid,campaignFilterInfo);
        batchContext.setFilterInfoMap(filterInfoMap);
        return batchContext;
    }

    /**
     * {"distinct":false,"dimensions":{"campaign":["campaignName","engageCode","c_channel","filterName"],"controlGroup":"groupType","engage":[],"channel":[],"dateUnit":"YEAR_DAY"},"metrics":{"campaign":["groupCount"]},"campaignIds":[17590]}
     * @return
     */
    public static CampaignReportQuery mockReportQuery() {
        CampaignReportQuery.ReportQueryDimension dimension = new CampaignReportQuery.ReportQueryDimension();
        dimension.setCampaignDims(Arrays.asList("campaignName", "filterName"));
        dimension.setControlGroupDim(CampaignReportQuery.ControlGroupType.SET_IN_ENGAGE_LEVEL);
        dimension.setEngageDims(Arrays.asList("engageCode", "c_channel"));
        dimension.setChannelDims(Arrays.asList("templateId", "templateName"));
        dimension.setDateUnit(CampaignReportQuery.EngageDateUnit.YEAR_DAY);

        CampaignReportQuery.ReportQueryMetric metric = new CampaignReportQuery.ReportQueryMetric();
        metric.setCampaignMetrics(Collections.singletonList("groupCount"));
        metric.setChannelMetrics(Collections.singletonList("sent"));

        return CampaignReportQuery.builder().isDistinct(false)
                .campaignIds(Collections.singletonList(17590L))
                .dimension(dimension).metric(metric)
                .build();
    }

    public static List<CampaignReportDataLineDto> mockReportDataList() {
        List<CampaignReportDataLineDto> result = new ArrayList<>();

        /**
         * | campaign\_id | engage\_id | group\_date | campaign\_filtered\_flag | campaign\_control\_flag | engage\_filtered\_flag | engage\_control\_flag | cnt |
         * | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
         * | 17590 | -1 | 2024-04-25 00:00:00.000000000 | 0 | -1 | -1 | -1 | 2 |
         * | 17590 | 2753 | 2024-04-25 00:00:00.000000000 | 1 | 1 | -1 | 1 | 1 |
         * | 17590 | 2753 | 2024-04-25 00:00:00.000000000 | 1 | 0 | -1 | 0 | 7 |
         * | 17590 | 2754 | 2024-04-25 00:00:00.000000000 | 1 | 1 | -1 | 1 | 1 |
         * | 17590 | 2754 | 2024-04-25 00:00:00.000000000 | 1 | 0 | -1 | 0 | 7 |
         * | 17590 | 2755 | 2024-04-25 00:00:00.000000000 | 1 | 0 | -1 | 0 | 8 |
         * | 17590 | 2755 | 2024-04-25 00:00:00.000000000 | 1 | 1 | -1 | 1 | 1 |
         */

        CampaignReportDataLineDto reportDataLineDto00 = new CampaignReportDataLineDto(
                new CampaignReportDataLineDto.GroupAggregateDim(17590L, -1L, "2024-04-25T00:00:00Z"),
                CampaignReportDataSetHelper.createGroupFactDataRowList(
                        new GroupFactDataRow(0, -1, -1, -1, 2)
                ), Collections.emptyList()
        );
        result.add(reportDataLineDto00);

        /**
         * | batch\_id |
         * | :--- |
         * | flow-96433\_0\_false@@101 |
         * | flow-96433\_0\_false@@101 |
         * | flow-96433\_0\_false@@101 |
         * | flow-96433\_0\_false@@104 |
         * | flow-96433\_0\_false@@113 |
         * | flow-96434\_0\_false@@101 |
         * | flow-96434\_0\_false@@101 |
         * | flow-96434\_0\_false@@101 |
         * | flow-96434\_0\_false@@107 |
         * | flow-96434\_0\_false@@113 |
         * | flow-96435\_0\_false@@101 |
         * | flow-96435\_0\_false@@101 |
         * | flow-96435\_0\_false@@101 |
         * | flow-96435\_0\_false@@107 |
         * | flow-96435\_0\_false@@113 |
         * | flow-96433\_0\_false@@113 |
         * | flow-96434\_0\_false@@113 |
         * | flow-96435\_0\_false@@113 |
         */

        CampaignReportDataLineDto reportDataLineDto01 = new CampaignReportDataLineDto(
                new CampaignReportDataLineDto.GroupAggregateDim(17590L, 2753L, "2024-04-25T00:00:00Z"),
                /**
                 *          * | 17590 | 2753 | 2024-04-25 00:00:00.000000000 | 1 | 1 | -1 | 1 | 1 |
                 *          * | 17590 | 2753 | 2024-04-25 00:00:00.000000000 | 1 | 0 | -1 | 0 | 7 |
                 */
                CampaignReportDataSetHelper.createGroupFactDataRowList(
                        new GroupFactDataRow(1, 1, -1, 1, 1),
                        new GroupFactDataRow(1, 0, -1, 0, 7)
                ),
                /**
                 *          * | flow-96433\_0\_false@@101 |
                 *          * | flow-96433\_0\_false@@101 |
                 *          * | flow-96433\_0\_false@@101 |
                 *          * | flow-96433\_0\_false@@104 |
                 *          * | flow-96433\_0\_false@@113 |
                 *
                 *
                 *          | batch\_id | event | cnt |
                 * | :--- | :--- | :--- |
                 * | flow-96433\_0\_false@@101 | email\_delivered | 2 |
                 * | flow-96433\_0\_false@@101 | email\_invalid | 1 |
                 * | flow-96433\_0\_false@@101 | email\_requested | 3 |
                 * | flow-96433\_0\_false@@104 | mobile\_app\_notification\_requested | 1 |
                 * | flow-96433\_0\_false@@113 | cp\_mms\_event\_send\_mms | 3 |
                 * | flow-96433\_0\_false@@113 | cp\_mms\_event\_mms\_failed | 3 |
                 */
                CampaignReportDataSetHelper.createEventStageStatList(
                        CampaignReportDataLineDto.BatchEventStageStat.builder().batchId("flow-96433_0_false@@101").sentCount(3).failedToSendCount(1).deliveredCount(2).build(),
                        CampaignReportDataLineDto.BatchEventStageStat.builder().batchId("flow-96433_0_false@@104").sentCount(1).build(),
                        CampaignReportDataLineDto.BatchEventStageStat.builder().batchId("flow-96433_0_false@@113").sentCount(3).failedToDeliveredCount(3).build()
                )
        );
        result.add(reportDataLineDto01);


        CampaignReportDataLineDto reportDataLineDto02 = new CampaignReportDataLineDto(
                new CampaignReportDataLineDto.GroupAggregateDim(17590L, 2754L, "2024-04-25T00:00:00Z"),
                /**
                 *          * | 17590 | 2754 | 2024-04-25 00:00:00.000000000 | 1 | 1 | -1 | 1 | 1 |
                 *          * | 17590 | 2754 | 2024-04-25 00:00:00.000000000 | 1 | 0 | -1 | 0 | 7 |
                 */
                CampaignReportDataSetHelper.createGroupFactDataRowList(
                        new GroupFactDataRow(1, 1, -1, 1, 1),
                        new GroupFactDataRow(1, 0, -1, 0, 7)
                ),
                /**
                 *          * | flow-96434\_0\_false@@101 |
                 *          * | flow-96434\_0\_false@@107 |
                 *          * | flow-96434\_0\_false@@113 |
                 | batch\_id | event | cnt |
                 | :--- | :--- | :--- |
                 | flow-96434\_0\_false@@101 | email\_requested | 5 |
                 | flow-96434\_0\_false@@101 | email\_delivered | 4 |
                 | flow-96434\_0\_false@@101 | email\_invalid | 1 |
                 | flow-96434\_0\_false@@107 | wechat\_template\_msg\_incorrect | 1 |
                 | flow-96434\_0\_false@@113 | cp\_mms\_event\_send\_mms | 1 |
                 | flow-96434\_0\_false@@113 | cp\_mms\_event\_mms\_failed | 1 |
                 *
                 *
                 *
                 */
                CampaignReportDataSetHelper.createEventStageStatList(
                        CampaignReportDataLineDto.BatchEventStageStat.builder().batchId("flow-96434_0_false@@101").sentCount(5).failedToSendCount(1).deliveredCount(4).build(),
                        CampaignReportDataLineDto.BatchEventStageStat.builder().batchId("flow-96434_0_false@@107").failedToSendCount(1).build(),
                        CampaignReportDataLineDto.BatchEventStageStat.builder().batchId("flow-96434_0_false@@113").sentCount(1).failedToDeliveredCount(1).build()
                )
        );
        result.add(reportDataLineDto02);

        CampaignReportDataLineDto reportDataLineDto03 = new CampaignReportDataLineDto(
                new CampaignReportDataLineDto.GroupAggregateDim(17590L, 2755L, "2024-04-25T00:00:00Z"),
                /**
                 *          * | 17590 | 2755 | 2024-04-25 00:00:00.000000000 | 1 | 0 | -1 | 0 | 8 |
                 *          * | 17590 | 2755 | 2024-04-25 00:00:00.000000000 | 1 | 1 | -1 | 1 | 1 |
                 */
                CampaignReportDataSetHelper.createGroupFactDataRowList(
                        new GroupFactDataRow(1, 0, -1, 0, 8),
                        new GroupFactDataRow(1, 1, -1, 1, 1)
                ),
                /**
                 * | batch\_id |
                 * | :--- |
                 * | flow-96435\_0\_false@@101 |
                 * | flow-96435\_0\_false@@107 |
                 * | flow-96435\_0\_false@@113 |
                 *
                 * | batch\_id | event | cnt |
                 * | :--- | :--- | :--- |
                 * | flow-96435\_0\_false@@101 | email\_delivered | 2 |
                 * | flow-96435\_0\_false@@101 | email\_requested | 4 |
                 * | flow-96435\_0\_false@@101 | email\_invalid | 2 |
                 * | flow-96435\_0\_false@@107 | wechat\_template\_msg\_incorrect | 1 |
                 * | flow-96435\_0\_false@@113 | cp\_mms\_event\_send\_mms | 3 |
                 * | flow-96435\_0\_false@@113 | cp\_mms\_event\_mms\_failed | 3 |
                 */
                CampaignReportDataSetHelper.createEventStageStatList(
                        CampaignReportDataLineDto.BatchEventStageStat.builder().batchId("flow-96435_0_false@@101").sentCount(4).failedToSendCount(2).deliveredCount(2).build(),
                        CampaignReportDataLineDto.BatchEventStageStat.builder().batchId("flow-96435_0_false@@107").failedToSendCount(1).build(),
                        CampaignReportDataLineDto.BatchEventStageStat.builder().batchId("flow-96435_0_false@@113").sentCount(3).failedToDeliveredCount(3).build()
                )
        );
        result.add(reportDataLineDto03);

        return result;
    }
}
