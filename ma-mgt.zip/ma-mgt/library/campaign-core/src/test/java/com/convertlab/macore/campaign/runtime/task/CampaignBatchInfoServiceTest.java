package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.macore.campaign.mapper.CampaignBatchInfoMapper;
import com.convertlab.macore.campaign.mapper.CampaignListInfoMapper;
import com.convertlab.macore.campaign.model.entity.CampaignBatchInfo;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CampaignBatchInfoServiceTest {

    @Mock
    CampaignBatchInfoMapper campaignBatchInfoMapper;

    @InjectMocks
    CampaignBatchInfoService campaignBatchInfoService;

    @Test
    public void testRefreshBatchInfo() {
        long campaignId = 1L;
        long engageId = 2L;
        List<CampaignBatchInfo> existingBatchInfos = new ArrayList<>();
        existingBatchInfos.add(new CampaignBatchInfo());  // Add specifics to your CampaignBatchInfo objects if necessary

        List<CampaignBatchInfo> newBatchInfos = new ArrayList<>();
        newBatchInfos.add(new CampaignBatchInfo());

        when(campaignBatchInfoMapper.selectByCampaignIdAndEngageId(campaignId, engageId)).thenReturn(existingBatchInfos);

        // Execute the method to test
        campaignBatchInfoService.refreshBatchInfo(campaignId, engageId, newBatchInfos);

        // Verify the interactions
        verify(campaignBatchInfoMapper, times(1)).selectByCampaignIdAndEngageId(campaignId, engageId);
        verify(campaignBatchInfoMapper, times(existingBatchInfos.size())).deleteById(any(CampaignBatchInfo.class));
        verify(campaignBatchInfoMapper, times(newBatchInfos.size())).insert(any(CampaignBatchInfo.class));
    }

}