package com.convertlab.macore.campaign.runtime.taskchain;
import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.runtime.task.CampaignTaskService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.mockito.Mockito.*;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class AbstractTaskChainStrategyTest {

    @Mock
    private CampaignTaskService campaignTaskService;
    @Mock
    private TimeStrategyService timeStrategyService;

    private AbstractTaskChainStrategy strategy;
    private CampaignFullDataDTO campaignFullData;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        strategy = new AbstractTaskChainStrategy(campaignTaskService, timeStrategyService, new ObjectMapper()) {
            @Override
            public List<CampaignExecutionTask> createTaskChain(CampaignFullDataDTO campaignFullData) {
                return initializeTaskChain(campaignFullData);
            }
        };
        campaignFullData = mock(CampaignFullDataDTO.class);
    }

    @Test
    void initializeTaskChain_NoOutboundEngages_ReturnsListAndFolderTaskOnly() {
        when(campaignFullData.getOutboundEngageList()).thenReturn(Arrays.asList());

        List<CampaignExecutionTask> tasks = strategy.createTaskChain(campaignFullData);

        assertEquals(1, tasks.size());
        verify(campaignTaskService).createGenerateListAndFolderTask(campaignFullData);
    }

    @Test
    void initializeTaskChain_MultipleOutboundEngages_ReturnsAllTasks() {
        CampaignOutboundEngage engage1 = mock(CampaignOutboundEngage.class);
        CampaignOutboundEngage engage2 = mock(CampaignOutboundEngage.class);
        when(campaignFullData.getOutboundEngageList()).thenReturn(Arrays.asList(engage1, engage2));

        List<CampaignExecutionTask> tasks = strategy.createTaskChain(campaignFullData);

        assertEquals(3, tasks.size()); // 1 list/folder task + 2 flow tasks
        verify(campaignTaskService).createGenerateListAndFolderTask(campaignFullData);
        verify(campaignTaskService, times(2)).createGenerateFlowTask(eq(campaignFullData), any(CampaignOutboundEngage.class));
    }
}