package com.convertlab.macore.campaign.runtime.taskchain;

import com.convertlab.macore.campaign.common.utils.AudienceStrategyConstants;
import com.convertlab.macore.campaign.common.utils.ControlGroupStrategyConstants;
import com.convertlab.macore.campaign.mapper.LimitMapper;
import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.entity.*;
import com.convertlab.macore.campaign.runtime.task.CampaignTaskService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class CampaignSegmentPeriodicTaskChainTest {

    final ObjectMapper mapper = new ObjectMapper();
    CampaignOutboundEngage engage1;
    CampaignOutboundEngage engage2;
    @Mock
    LimitMapper limitMapper;


    private CampaignFullDataDTO buildCmpaignFullDataDTO(){
        CampaignFullDataDTO campaignFullDataDTO = new CampaignFullDataDTO();
        MarketingCampaign campaign = new MarketingCampaign();
        campaign.setId(1L);
        campaign.setUuid("abcd1234");
        campaignFullDataDTO.setCampaign(campaign);

        CampaignAudienceStrategy audienceStrategy = new CampaignAudienceStrategy();
        audienceStrategy.setSegmentationType(AudienceStrategyConstants.MANUAL_PERCENTAGE_SEGMENTATION);
        audienceStrategy.setControlGroupStrategy(ControlGroupStrategyConstants.CONTROL_AT_Engage);
        audienceStrategy.setFilterId(1L);
        campaignFullDataDTO.setAudienceStrategy(audienceStrategy);
        CampaignMainTargetAudienceMapping mapping = new CampaignMainTargetAudienceMapping();
        mapping.setListId(123L);
        campaignFullDataDTO.setMainTargetAudience(Arrays.asList(mapping));

        engage1 = new CampaignOutboundEngage();
        engage1.setId(1L);
        engage1.setCampaignId(1L);
        engage1.setTimeData("{\"day\":\"*\",\"min\":\"0\",\"hour\":\"8\"}");
        engage2 = new CampaignOutboundEngage();
        engage2.setId(2L);
        engage2.setCampaignId(1L);
        engage2.setTimeData("{\"week\":\"MON,WED\",\"min\":\"0\",\"hour\":\"8\"}");

        campaignFullDataDTO.setOutboundEngageList(Arrays.asList(engage1, engage2));
        return campaignFullDataDTO;
    }

    @Test
    void test_createTaskChain(){
        CampaignSegmentPeriodicTaskChain taskChain = new CampaignSegmentPeriodicTaskChain(new CampaignTaskService(null, null), new TimeStrategyService(mapper, limitMapper), mapper);
        List<CampaignExecutionTask> taskList = taskChain.createTaskChain(buildCmpaignFullDataDTO());

        List<ZonedDateTime> triggers1 = taskChain.timeStrategyService.calculateTriggersThisMonth(taskChain.parseCronDTO(engage1.getTimeData()));
        List<ZonedDateTime> triggers2 = taskChain.timeStrategyService.calculateTriggersThisMonth(taskChain.parseCronDTO(engage2.getTimeData()));
        triggers1.addAll(triggers2);
        Map<LocalDate, List<ZonedDateTime>> groupedByDate = triggers1.stream()
                .collect(Collectors.groupingBy(zdt -> zdt.toLocalDate()));

        int sizeOfTask = 3 + groupedByDate.keySet().size() + 2 + 1;
        assertEquals(sizeOfTask, taskList.size());
    }


    @Test
    void test_createTaskChainForNextMonth(){
        CampaignSegmentPeriodicTaskChain taskChain = new CampaignSegmentPeriodicTaskChain(new CampaignTaskService(null, null), new TimeStrategyService(mapper, limitMapper), mapper);
        Instant initialTime = Instant.now();
        List<CampaignExecutionTask> taskList = taskChain.createTaskChainForNextMonth(buildCmpaignFullDataDTO(), initialTime);
        List<ZonedDateTime> triggers1 = taskChain.timeStrategyService.calculateTriggersNextMonth(taskChain.parseCronDTO(engage1.getTimeData()),initialTime);
        List<ZonedDateTime> triggers2 = taskChain.timeStrategyService.calculateTriggersNextMonth(taskChain.parseCronDTO(engage2.getTimeData()),initialTime);
        triggers1.addAll(triggers2);
        Map<LocalDate, List<ZonedDateTime>> groupedByDate = triggers1.stream()
                .collect(Collectors.groupingBy(zdt -> zdt.toLocalDate()));

        int sizeOfTask = groupedByDate.keySet().size() + 1;
        assertEquals(sizeOfTask, taskList.size());
    }
}