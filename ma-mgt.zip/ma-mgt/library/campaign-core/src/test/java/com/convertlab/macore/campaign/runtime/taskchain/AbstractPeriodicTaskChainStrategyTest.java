package com.convertlab.macore.campaign.runtime.taskchain;

import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.dto.CronDTO;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.runtime.task.CampaignTaskService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AbstractPeriodicTaskChainStrategyTest {

    @Mock
    private CampaignTaskService campaignTaskService;
    @Mock
    private TimeStrategyService timeStrategyService;

    private AbstractPeriodicTaskChainStrategy strategy;

    private CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO();


    @BeforeEach
    void setUp() {
        strategy = new AbstractPeriodicTaskChainStrategy(campaignTaskService,  timeStrategyService, new ObjectMapper()){
            @Override
            public List<CampaignExecutionTask> createTaskChain(CampaignFullDataDTO campaignFullData) {
                return null;
            }
        };
    }

    @Test
    void addPeriodicTask_AddsTaskToList() {
        List<CampaignExecutionTask> tasks = new ArrayList<>();
        CampaignExecutionTask periodicTask = new CampaignExecutionTask();
        when(campaignTaskService.createPeriodicTask(campaignFullData)).thenReturn(periodicTask);
        when(timeStrategyService.getLastSundayOfTheMonth(any())).thenReturn(ZonedDateTime.now());
        when(timeStrategyService.now()).thenReturn(ZonedDateTime.now());

        strategy.addPeriodicTask(campaignFullData, tasks, Instant.now());

        assertFalse(tasks.isEmpty());
        assertTrue(tasks.contains(periodicTask));
    }

    @Test
    void addPeriodicTask_SetsTriggerDateWhenLastSundayIsAfterNow() {
        List<CampaignExecutionTask> tasks = new ArrayList<>();
        ZonedDateTime lastSunday = ZonedDateTime.now().plusWeeks(1); // Future date
        CampaignExecutionTask periodicTask = new CampaignExecutionTask();
        when(timeStrategyService.getLastSundayOfTheMonth(any())).thenReturn(lastSunday);
        when(timeStrategyService.now()).thenReturn(ZonedDateTime.now());
        when(campaignTaskService.createPeriodicTask(campaignFullData)).thenReturn(periodicTask);

        strategy.addPeriodicTask(campaignFullData, tasks, Instant.now());

        assertEquals(lastSunday.toInstant(), periodicTask.getTaskTriggerDate());
    }

    @Test
    void addPeriodicTask_DoesNotSetTriggerDateWhenLastSundayIsNotAfterNow() {
        List<CampaignExecutionTask> tasks = new ArrayList<>();
        ZonedDateTime lastSunday = ZonedDateTime.now().minusWeeks(1); // Past date
        CampaignExecutionTask periodicTask = new CampaignExecutionTask();
        when(timeStrategyService.getLastSundayOfTheMonth(any())).thenReturn(lastSunday);
        when(timeStrategyService.now()).thenReturn(ZonedDateTime.now());
        when(campaignTaskService.createPeriodicTask(campaignFullData)).thenReturn(periodicTask);

        strategy.addPeriodicTask(campaignFullData, tasks,Instant.now());

        assertNull(periodicTask.getTaskTriggerDate());
    }

    @Test
    void parseCronDTO_ReturnsCronDTO() {
        String timeString1 = "{\"fromDate\": null,   \"intervalDays\": 0,   \"week\": \"?\",   \"day\": \"*\",   \"hour\": \"*\",   \"min\": \"0\",   \"month\": \"*\" }";
        String timeString2 = "{\"fromDate\":\"2023-01-02\",\"intervalDays\":7}";
        CronDTO cronDTO1 = strategy.parseCronDTO(timeString1);
        CronDTO cronDTO2 =strategy.parseCronDTO(timeString2);

        assertEquals("?", cronDTO1.getWeek());
        assertEquals("*", cronDTO1.getDay());
        assertEquals("*", cronDTO1.getHour());
        assertEquals("0", cronDTO1.getMin());
        assertEquals("*", cronDTO1.getMonth());
        assertEquals(0, cronDTO1.getIntervalDays());
        assertNull(cronDTO1.getFromDate());

        assertEquals("2023-01-02", cronDTO2.getFromDate());
        assertEquals(7, cronDTO2.getIntervalDays());
    }

}