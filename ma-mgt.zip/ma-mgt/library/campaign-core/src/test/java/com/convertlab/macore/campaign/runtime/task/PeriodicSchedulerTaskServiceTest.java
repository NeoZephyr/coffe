package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.macore.campaign.common.utils.AudienceStrategyConstants;
import com.convertlab.macore.campaign.mapper.CampaignExecutionTaskMapper;
import com.convertlab.macore.campaign.model.dto.CampaignDTO;
import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.entity.CampaignAudienceStrategy;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.runtime.taskchain.CampaignSegmentPeriodicTaskChain;
import com.convertlab.macore.campaign.runtime.taskchain.EngageSegmentPeriodicTaskChain;
import com.convertlab.macore.campaign.service.CampaignService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PeriodicSchedulerTaskServiceTest {
    @Mock
    private CampaignService campaignService;
    @Mock
    private CampaignTaskService campaignTaskService;
    @Mock
    private CampaignExecutionTaskMapper campaignExecutionTaskMapper;
    @Mock
    private EngageSegmentPeriodicTaskChain engageSegmentPeriodicTaskChain;
    @Mock
    private CampaignSegmentPeriodicTaskChain campaignSegmentPeriodicTaskChain;
    @InjectMocks
    PeriodicSchedulerTaskService periodicSchedulerTaskService;
    @BeforeEach
    public void setUp() {
        periodicSchedulerTaskService.campaignTaskService = campaignTaskService;
        periodicSchedulerTaskService.campaignService = campaignService;
    }

    @Test
    public void testConnectTaskChain_LastTask() {
        CampaignExecutionTask currentTask = new CampaignExecutionTask();
        currentTask.setId("3");
        currentTask.setNextTaskId(null);

        CampaignExecutionTask firstTask = new CampaignExecutionTask();
        firstTask.setId("1");

        List<CampaignExecutionTask> taskList = new ArrayList<>();
        taskList.add(firstTask);

        periodicSchedulerTaskService.connectTaskChain(currentTask, taskList);

        assertEquals("1", currentTask.getNextTaskId());
        assertTrue(taskList.contains(currentTask));
    }


    @Test
    public void testConnectTaskChain_NotLastTask() {
        CampaignExecutionTask currentTask = new CampaignExecutionTask();
        currentTask.setId("2");
        currentTask.setCampaignId(123L);
        currentTask.setNextTaskId("3");

        CampaignExecutionTask nextTaskNull = new CampaignExecutionTask();
        nextTaskNull.setId("4");
        nextTaskNull.setNextTaskId(null);

        CampaignExecutionTask firstTask = new CampaignExecutionTask();
        firstTask.setId("1");

        List<CampaignExecutionTask> taskList = new ArrayList<>();
        taskList.add(firstTask);
        List<CampaignExecutionTask> notStartedTasks = Arrays.asList(nextTaskNull);


        when( campaignTaskService.getNotStartedAndScheduledTasks(123L)).thenReturn(notStartedTasks);

        periodicSchedulerTaskService.connectTaskChain(currentTask, taskList);

        assertEquals("1", nextTaskNull.getNextTaskId());
        assertTrue(taskList.contains(nextTaskNull));
        verify(campaignTaskService).getNotStartedAndScheduledTasks(123L);
    }

    @Test
    public void testConnectTaskChain_NoNullNextTaskIdFound() {
        CampaignExecutionTask currentTask = new CampaignExecutionTask();
        currentTask.setId("2");
        currentTask.setCampaignId(123L);
        currentTask.setNextTaskId("3");

        List<CampaignExecutionTask> taskList = Arrays.asList(new CampaignExecutionTask());

        when(campaignTaskService.getNotStartedAndScheduledTasks(123L)).thenReturn(Arrays.asList());

        Exception exception = assertThrows(RuntimeException.class, () -> {
            periodicSchedulerTaskService.connectTaskChain(currentTask, taskList);
        });

        verify(campaignTaskService).getNotStartedAndScheduledTasks(123L);
    }

    @Test
    public void testOnStart_SuccessfulTaskChainManagement() {
        CampaignExecutionTask task = new CampaignExecutionTask();
        task.setCampaignId(123L);
        task.setNextTaskId(null); // Simulate this is the last task

        CampaignFullDataDTO campaignFullData = new CampaignFullDataDTO();
        CampaignAudienceStrategy audienceStrategy = new CampaignAudienceStrategy();
        audienceStrategy.setSegmentationType(AudienceStrategyConstants.MANUAL_SPECIFIED_SEGMENTATION);
        campaignFullData.setAudienceStrategy(audienceStrategy);

        List<CampaignExecutionTask> taskList = new ArrayList<>();
        taskList.add(new CampaignExecutionTask());
        Instant now = Instant.now();
        when(campaignService.getCampaignFullData(task.getCampaignId())).thenReturn(campaignFullData);
        when(engageSegmentPeriodicTaskChain.createTaskChainForNextMonth(eq(campaignFullData), any())).thenReturn(taskList);
//        when(campaignExecutionTaskMapper.getNotStartedAndScheduledTaskByCampaignId(task.getCampaignId())).thenReturn(Arrays.asList(task));

        periodicSchedulerTaskService.onStart(task);

        verify(campaignTaskService).sortByTimeArrange(taskList);
        verify(campaignTaskService).saveAndUpdateTaskChain(taskList);
        assertNotNull(task.getNextTaskId());
    }


}