package com.convertlab.macore.campaign.runtime.taskchain;

import cn.hutool.core.lang.Assert;
import com.convertlab.macore.campaign.mapper.LimitMapper;
import com.convertlab.macore.campaign.model.dto.CronDTO;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.List;

import static com.convertlab.macore.campaign.runtime.taskchain.TimeStrategyService.ZONE_ID_BEIJING;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
public class TimeStrategyServiceTest {

    final ObjectMapper mapper = new ObjectMapper();

    @Mock
    LimitMapper limitMapper;

    @Test
    void testCalculateCronTriggers() {
        // 测试数据准备
        CronDTO dto = new CronDTO();
        // 设置cron表达式为每天的中午12点执行
        dto.setDay("*");
        dto.setHour("12");
        dto.setMin("0");
        dto.setMonth("*");

        // 设置当前时间为测试月份的第一天
        ZonedDateTime now = ZonedDateTime.now(ZoneId.of("Asia/Shanghai")).withDayOfMonth(1).withHour(0).withMinute(1);

        // 计算下个月的第一天的第一秒
        ZonedDateTime firstSecondOfNextMonth = now.with(TemporalAdjusters.firstDayOfNextMonth())
                .withHour(0).withMinute(0).withSecond(0);

        // 从下个月的第一天的第一秒减去2秒，得到本月最后一天的最后一秒
        ZonedDateTime lastSecondOfMonth = firstSecondOfNextMonth.minusSeconds(1);

        // 计算当前月内的触发时间
        List<ZonedDateTime> triggers = new TimeStrategyService(mapper, limitMapper).calculateTriggers(dto, now, lastSecondOfMonth);

        LocalDate currentDate = LocalDate.now(ZoneId.of("Asia/Shanghai"));

        // 获取当前年月
        YearMonth currentYearMonth = YearMonth.from(currentDate);

        // 获取当前月份的天数
        int daysInMonth = currentYearMonth.lengthOfMonth();

        // 验证
        assertEquals(daysInMonth, triggers.size(), "触发次数应与预期相符");

        // 验证每个触发时间都是在中午12点
        boolean allTriggersAtNoon = triggers.stream().allMatch(trigger -> trigger.getHour() == 12 && trigger.getMinute() == 0);
        assertTrue(allTriggersAtNoon, "所有触发时间都应在中午12点");
    }

    @Test
    void testCalculateCronTriggersForWednesdayAndFriday() {
        // 测试数据准备
        CronDTO dto = new CronDTO();
        // 设置cron表达式为每周三和每周五的中午12点执行
        dto.setDay("?"); // 在这种情况下，日期字段不被使用，设置为问号
        dto.setHour("12");
        dto.setMin("0");
        dto.setMonth("*");
        dto.setWeek("WED,FRI"); // 使用星期字段表示每周三（3）和每周五（5）

        // 设置当前时间为测试月份的第一天
        ZonedDateTime now = ZonedDateTime.now(ZoneId.of("Asia/Shanghai"));

        // 计算下个月的第一天的第一秒
        ZonedDateTime firstSecondOfNextMonth = now.with(TemporalAdjusters.firstDayOfNextMonth())
                .withHour(0).withMinute(0).withSecond(0);

        // 从下个月的第一天的第一秒减去1秒，得到本月最后一天的最后一秒
        ZonedDateTime lastSecondOfMonth = firstSecondOfNextMonth.minusSeconds(1);

        // 计算当前月内的触发时间
        List<ZonedDateTime> triggers = new TimeStrategyService(mapper, limitMapper).calculateTriggers(dto, now, lastSecondOfMonth);

        // 计算从现在到月底，每周三和每周五的总次数
        int expectedTriggerCount = calculateWednesdaysAndFridaysCount(now, lastSecondOfMonth);

        assertEquals(expectedTriggerCount, triggers.size(), "触发次数应与预期相符");

        // 验证每个触发时间都是在中午12点，并且是周三或周五
        boolean allTriggersAtNoonOnWedOrFri = triggers.stream()
                .allMatch(trigger -> trigger.getHour() == 12 && trigger.getMinute() == 0 &&
                        (trigger.getDayOfWeek() == DayOfWeek.WEDNESDAY || trigger.getDayOfWeek() == DayOfWeek.FRIDAY));
        assertTrue(allTriggersAtNoonOnWedOrFri, "所有触发时间都应在中午12点的周三或周五");
    }

    private int calculateWednesdaysAndFridaysCount(ZonedDateTime start, ZonedDateTime end) {
        int count = 0;
        for (ZonedDateTime date = start; date.isBefore(end); date = date.plusDays(1)) {
            if (date.getDayOfWeek() == DayOfWeek.WEDNESDAY || date.getDayOfWeek() == DayOfWeek.FRIDAY) {
                count++;
            }
        }

        if((start.getDayOfWeek() ==  DayOfWeek.WEDNESDAY || start.getDayOfWeek() ==  DayOfWeek.FRIDAY)
          && start.getHour()>=12){
            count--;
        }
        return count;
    }


//    @Test
//    void testCalculateIntervalTriggersFromDateAfterNow() {
//        CronDTO dto = new CronDTO();
//        dto.setFromDate(ZonedDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))); // 设定为明天
//        dto.setIntervalDays(2); // 每隔2天
//        dto.setHour("10");
//        dto.setMin("30");
//
//        ZonedDateTime now = ZonedDateTime.now(ZoneId.of("Asia/Shanghai"));
//        ZonedDateTime endOfMonth = now.withDayOfMonth(now.getMonth().length(now.toLocalDate().isLeapYear()));
//
//        List<ZonedDateTime> triggers = new TimeStrategyService(mapper).calculateTriggers(dto, now, endOfMonth);
//
//        Assertions.assertFalse(triggers.isEmpty(), "Triggers list should not be empty.");
//        assertTrue(triggers.get(0).isAfter(now), "The first trigger should be after now.");
//        assertTrue(triggers.get(0).getHour() == 10 && triggers.get(0).getMinute() == 30, "The first trigger should be at 10:30.");
//    }

    @Test
    void testCalculateIntervalTriggersFromDateAfterNow_1() {
        CronDTO dto = new CronDTO();
        dto.setFromDate("2024-04-23"); // 设定为明天
        dto.setIntervalDays(1); // 每隔2天
        dto.setHour("10");
        dto.setMin("30");

        ZonedDateTime now = ZonedDateTime.now(ZoneId.of("Asia/Shanghai")).withYear(2024).withMonth(4).withDayOfMonth(23).withHour(10).withMinute(20);
        ZonedDateTime endOfMonth = now.withDayOfMonth(30).withHour(23).withMinute(59).withSecond(59);

        List<ZonedDateTime> triggers = new TimeStrategyService(mapper, limitMapper).calculateTriggers(dto, now, endOfMonth);

        Assertions.assertEquals(8, triggers.size());
    }

    @Test
    void testCalculateIntervalTriggersFromDateBeforeNow() {
        CronDTO dto = new CronDTO();
        dto.setFromDate("2024-04-23"); // 设定为明天
        dto.setIntervalDays(1); // 每隔2天
        dto.setHour("10");
        dto.setMin("30");

        ZonedDateTime now = ZonedDateTime.now(ZoneId.of("Asia/Shanghai")).withYear(2024).withMonth(4).withDayOfMonth(23).withHour(10).withMinute(40);
        ZonedDateTime endOfMonth = now.withDayOfMonth(30).withHour(23).withMinute(59).withSecond(59);

        List<ZonedDateTime> triggers = new TimeStrategyService(mapper, limitMapper).calculateTriggers(dto, now, endOfMonth);

        Assertions.assertEquals(7, triggers.size());
    }

    @Test
    void testCalculateTriggersThisMonth() {
        CronDTO dto = new CronDTO();
        // 填充dto的属性，比如设置每天中午12点触发
        dto.setHour("12");
        dto.setMin("0");
        // 假定测试在北京时间区域
        ZonedDateTime now = ZonedDateTime.of(2024, 3, 15, 0, 0, 0, 0, ZoneId.of("Asia/Shanghai"));

        List<ZonedDateTime> triggers = new TimeStrategyService(mapper, limitMapper).calculateTriggersThisMonth(dto, now);

        // 验证触发时间都在本月
        boolean allInThisMonth = triggers.stream()
                .allMatch(date -> date.getMonth() == now.getMonth() && date.getYear() == now.getYear());
        assertTrue(allInThisMonth, "All triggers should be in the current month.");

        // 验证触发时间的小时和分钟符合预期
        boolean allAtNoon = triggers.stream()
                .allMatch(date -> date.getHour() == 12 && date.getMinute() == 0);
        assertTrue(allAtNoon, "All triggers should be at noon.");
    }

    @Test
    void testCalculateTriggersNextMonth() {
        CronDTO dto = new CronDTO();
        // 填充dto的属性，比如设置每天中午12点触发
        dto.setHour("12");
        dto.setMin("0");
        ZonedDateTime now = ZonedDateTime.of(2024, 3, 15, 0, 0, 0, 0, ZoneId.of("Asia/Shanghai"));

        List<ZonedDateTime> triggers = new TimeStrategyService(mapper, limitMapper).calculateTriggersNextMonth(dto, now);

        // 验证触发时间都在下个月
        boolean allInNextMonth = triggers.stream()
                .allMatch(date -> date.getMonth() == now.plusMonths(1).getMonth() && date.getYear() == now.getYear());
        assertTrue(allInNextMonth, "All triggers should be in the next month.");

        // 验证触发时间的小时和分钟符合预期
        boolean allAtNoon = triggers.stream()
                .allMatch(date -> date.getHour() == 12 && date.getMinute() == 0);
        assertTrue(allAtNoon, "All triggers should be at noon.");
    }

    @Test
    void testCalculateTriggersNextMonth_1() {

        CronDTO dto = new CronDTO();
        // 填充dto的属性，比如设置每天中午12点触发
        dto.setHour("12");
        dto.setMin("0");
        ZonedDateTime now = ZonedDateTime.of(2024, 3, 15, 0, 0, 0, 0, ZoneId.of("Asia/Shanghai"));

        List<ZonedDateTime> triggers = new TimeStrategyService(mapper, limitMapper).calculateTriggersNextMonth(dto, now.toInstant());

        // 验证触发时间都在下个月
        boolean allInNextMonth = triggers.stream()
                .allMatch(date -> date.getMonth() == now.plusMonths(1).getMonth() && date.getYear() == now.getYear());
        assertTrue(allInNextMonth, "All triggers should be in the next month.");

        // 验证触发时间的小时和分钟符合预期
        boolean allAtNoon = triggers.stream()
                .allMatch(date -> date.getHour() == 12 && date.getMinute() == 0);
        assertTrue(allAtNoon, "All triggers should be at noon.");


    }

    @Test
    void testCalculateTriggersNextMonth_2() {

        CronDTO dto = new CronDTO();
        // 填充dto的属性，比如设置每天中午12点触发
        dto.setHour("12");
        dto.setMin("0");
        Instant instant = null;
        Instant now = Instant.now();

        List<ZonedDateTime> triggers = new TimeStrategyService(mapper, limitMapper).calculateTriggersNextMonth(dto, instant);

        List<ZonedDateTime> triggers2 = new TimeStrategyService(mapper, limitMapper).calculateTriggersNextMonth(dto, now);

        Assert.equals(triggers.size(), triggers2.size());

    }


        @Test
    void testGetLastSundayOfTheMonth() {

        // 设定一个已知的日期时间，这里以2024年3月为例
        ZonedDateTime now = ZonedDateTime.of(2024, 3, 15, 10, 0, 0, 0, ZoneId.of("Asia/Shanghai"));
        ZonedDateTime expectedLastSunday = ZonedDateTime.of(2024, 3, 31, 12, 0, 0, 0, ZoneId.of("Asia/Shanghai"));

        ZonedDateTime actualLastSunday = new TimeStrategyService(mapper, limitMapper).getLastSundayOfTheMonth(now.toInstant());

        assertEquals(expectedLastSunday.toLocalDate(), actualLastSunday.toLocalDate(), "The dates should be the same");
        assertEquals(12, actualLastSunday.getHour(), "The hour should be noon (12)");
        assertEquals(0, actualLastSunday.getMinute(), "The minute should be 0");
        assertEquals(0, actualLastSunday.getSecond(), "The second should be 0");
        assertEquals(expectedLastSunday.getDayOfWeek(), actualLastSunday.getDayOfWeek(), "Both should be Sunday");
        assertEquals(expectedLastSunday.getZone(), actualLastSunday.getZone(), "Time zones should match");
    }
    @Test
    void testGetSegmentScheduledTimeWithNull() {
        assertNull(new TimeStrategyService(mapper, limitMapper).getSegmentScheduledTime(null, ZonedDateTime.now(ZONE_ID_BEIJING)));
    }

    @Test
    void testGetSegmentScheduledTimeSameDayAfterDefaultTime() {
        ZonedDateTime nowInCST = ZonedDateTime.now(ZONE_ID_BEIJING);
        ZonedDateTime afterDefaultTime = nowInCST.with(LocalTime.of(6, 0)); // Assuming default time is 05:00
        assertNull(new TimeStrategyService(mapper, limitMapper).getSegmentScheduledTime(afterDefaultTime.toInstant(), afterDefaultTime));
    }

    @Test
    void testGetSegmentScheduledTimeSameDayBeforeDefaultTime() {
        ZonedDateTime nowInCST = ZonedDateTime.now(ZONE_ID_BEIJING);
        ZonedDateTime beforeDefaultTime = nowInCST.with(LocalTime.of(4, 0)); // Assuming default time is 05:00
        Instant expected = nowInCST.with(LocalTime.of(5, 0)).toInstant();
        assertEquals(expected, new TimeStrategyService(mapper, limitMapper).getSegmentScheduledTime(beforeDefaultTime.toInstant(), beforeDefaultTime));
    }

    @Test
    void testGetSegmentScheduledTimePast() {
        ZonedDateTime nowInCST = ZonedDateTime.now(ZONE_ID_BEIJING);
        ZonedDateTime past = nowInCST.minusDays(1);
        assertNull(new TimeStrategyService(mapper, limitMapper).getSegmentScheduledTime(past.toInstant(), nowInCST));
    }

    @Test
    void testGetSegmentScheduledTimeFuture() {
        ZonedDateTime nowInCST = ZonedDateTime.now(ZONE_ID_BEIJING);
        ZonedDateTime future = nowInCST.plusDays(1);
        Instant expected = future.with(LocalTime.of(5, 0)).toInstant(); // Assuming default time is 05:00
        assertEquals(expected, new TimeStrategyService(mapper, limitMapper).getSegmentScheduledTime(future.toInstant(), nowInCST));
    }


    @Test
    void testNowIsNotNull() {
        assertNotNull(new TimeStrategyService(mapper, limitMapper).now());
    }

    @Test
    void testNowIsInCorrectTimeZone() {
        assertEquals(ZONE_ID_BEIJING, new TimeStrategyService(mapper, limitMapper).now().getZone());
    }

    @Test
    void testNowIsCloseToSystemTime() {
        ZonedDateTime now = new TimeStrategyService(mapper, limitMapper).now();
        ZonedDateTime systemNow = ZonedDateTime.now(ZONE_ID_BEIJING);
        long differenceInSeconds = ChronoUnit.SECONDS.between(now, systemNow);
        assertTrue(Math.abs(differenceInSeconds) < 2, "The time should be within 2 seconds of the system time.");
    }


    @Test
    void getScheduledTime_NullEngage_ThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () ->  new TimeStrategyService(mapper, limitMapper).getScheduledTime(null));
    }

    @Test
    void getScheduledTime_EmptyTimeData_ThrowsIllegalArgumentException() {
        CampaignOutboundEngage engage = new CampaignOutboundEngage();
        assertThrows(IllegalArgumentException.class, () ->  new TimeStrategyService(mapper, limitMapper).getScheduledTime(engage));
    }

    @Test
    void getScheduledTime_ValidScheduledDate_ReturnsInstant() throws JsonProcessingException {
        String timeData = "{\"scheduledDate\":\"2023-04-01T10:00:00Z\"}";
        CampaignOutboundEngage engage = new CampaignOutboundEngage();
        engage.setTimeData(timeData);
        Instant expected = Instant.parse("2023-04-01T10:00:00Z");
        assertEquals(expected, new TimeStrategyService(mapper, limitMapper).getScheduledTime(engage));
    }

    @Test
    void getScheduledTime_ValidDateOfNextWave_ReturnsInstant() throws JsonProcessingException {
        String timeData = "{\"date_of_next_wave\":\"2023-04-02T10:00:00Z\"}";
        CampaignOutboundEngage engage = new CampaignOutboundEngage();
        engage.setTimeData(timeData);
        Instant expected = Instant.parse("2023-04-02T10:00:00Z");
        assertEquals(expected, new TimeStrategyService(mapper, limitMapper).getScheduledTime(engage));
    }

    @Test
    void getScheduledTime_InvalidJson_ThrowsRuntimeException() {
        CampaignOutboundEngage engage = new CampaignOutboundEngage();
        engage.setTimeData("invalid json");
        assertThrows(RuntimeException.class, () -> new TimeStrategyService(mapper, limitMapper).getScheduledTime(engage));
    }

    @Test
    void getScheduledTime_MissingBothFields_ThrowsRuntimeException() {
        String timeData = "{}";
        CampaignOutboundEngage engage = new CampaignOutboundEngage();
        engage.setTimeData(timeData);
        assertThrows(RuntimeException.class, () -> new TimeStrategyService(mapper, limitMapper).getScheduledTime(engage));
    }

}
