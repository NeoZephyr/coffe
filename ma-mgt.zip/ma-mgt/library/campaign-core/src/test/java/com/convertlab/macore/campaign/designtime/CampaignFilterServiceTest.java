package com.convertlab.macore.campaign.designtime;

import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.macore.campaign.mapper.CampaignFilterMapper;
import com.convertlab.macore.campaign.model.dto.CampaignFilterDTO;
import com.convertlab.macore.campaign.model.entity.CampaignFilter;
import com.convertlab.macore.campaign.service.CampaignFilterService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@Slf4j
public class CampaignFilterServiceTest {

    @Mock
    private CampaignFilterMapper campaignFilterMapper;

    @InjectMocks
    private CampaignFilterService campaignFilterService;

    private CampaignFilterDTO dto;

    @BeforeEach
    void setUp() {
        dto = new CampaignFilterDTO();
        dto.setFilterName("TestFilter");
        dto.setDescription("Test description");
        dto.setProfileType("TestType");
        dto.setLastUpdated(LocalDateTime.now());
    }

    @Test
    void testSaveOrUpdateCampaignFilterInsert() {
        // Arrange
        when(campaignFilterMapper.selectCount(any())).thenReturn(0L);
        when(campaignFilterMapper.insert(any(CampaignFilter.class))).thenReturn(1);

        // Act
        boolean result = campaignFilterService.saveOrUpdateCampaignFilter(dto);

        // Assert
        assertTrue(result);
        verify(campaignFilterMapper, times(1)).insert(any(CampaignFilter.class));
    }

    @Test
    void testSaveOrUpdateCampaignFilterUpdate() {
        // Arrange
        Long existingId = 1L;
        dto.setId(existingId);
        CampaignFilter existingFilter = new CampaignFilter();
        existingFilter.setId(existingId);
        existingFilter.setFilterName("TestFilter");
        when(campaignFilterMapper.selectCount(any())).thenReturn(0L);
        when(campaignFilterMapper.selectById(existingId)).thenReturn(existingFilter);
        when(campaignFilterMapper.updateById(any(CampaignFilter.class))).thenReturn(1);

        // Act
        boolean result = campaignFilterService.saveOrUpdateCampaignFilter(dto);

        // Assert
        assertTrue(result);
        verify(campaignFilterMapper, times(1)).updateById(any(CampaignFilter.class));
    }

    @Test
    void testSaveOrUpdateCampaignFilterNameExists() {
        // Arrange
        when(campaignFilterMapper.selectCount(any())).thenReturn(1L);

        // Act & Assert
        assertThrows(BusinessException.class, () -> campaignFilterService.saveOrUpdateCampaignFilter(dto));
    }

    @Test
    void testSaveOrUpdateCampaignFilterNotExists() {
        // Arrange
        Long nonExistingId = 99L;
        dto.setId(nonExistingId);
        when(campaignFilterMapper.selectCount(any())).thenReturn(0L);
        when(campaignFilterMapper.selectById(nonExistingId)).thenReturn(null);

        // Act & Assert
        assertThrows(BusinessException.class, () -> campaignFilterService.saveOrUpdateCampaignFilter(dto));
    }
}
