package com.convertlab.macore.campaign.runtime.hc;

import com.convertlab.foundation.library.business.feature.FeatureClient;
import com.convertlab.foundation.library.business.feature.QueryToggleTenantsResponse;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.runtime.CampaignTaskExecutorService;
import com.convertlab.macore.campaign.runtime.task.CampaignTaskService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CampaignHealthCheckServiceTest {

    @Mock
    private FeatureClient featureClient;

    @Mock
    private CampaignTaskService campaignTaskService;

    @Mock
    private CampaignTaskExecutorService campaignTaskExecutorService;

    @InjectMocks
    private CampaignHealthCheckService campaignHealthCheckService;

    @Test
    public void testHandleCampaignTaskHealthCheck() {
        // Mocking featureClient.getToggleTenants to return a list of tenants
        QueryToggleTenantsResponse.Feature feature = new QueryToggleTenantsResponse.Feature();
        feature.setTenantId(123L);
        feature.setFeature("abc");
        feature.setEnabled(true);
        QueryToggleTenantsResponse response = new QueryToggleTenantsResponse();
        response.setRows(Collections.singletonList(feature));

        when(featureClient.getToggleTenants(any(), anyInt(), anyInt()))
                .thenReturn(response);

        // Mocking campaignTaskService methods
        CampaignExecutionTask task1 = new CampaignExecutionTask();
        task1.setId("taskId1");
        when(campaignTaskService.getTasksScheduledBeforeTime(any()))
                .thenReturn(Collections.singletonList(task1));

        CampaignExecutionTask task2 = new CampaignExecutionTask();
        task2.setId("taskId2");
        when(campaignTaskService.getRunningTooLongTimeTasks(any(), anyInt()))
                .thenReturn(Collections.singletonList(task2));

        CampaignExecutionTask task3 = new CampaignExecutionTask();
        task3.setId("taskId3");
        when(campaignTaskService.getFailedTasks(any(), anyInt()))
                .thenReturn(Collections.singletonList(task3));

        // Calling the method to be tested
        campaignHealthCheckService.handleCampaignTaskHealthCheck();

        // Verifying that the expected methods were called
        verify(campaignTaskExecutorService).startDirectly("taskId1");
        verify(campaignTaskExecutorService).startDirectly("taskId2");
        verify(campaignTaskExecutorService).startDirectly("taskId3");
        verify(campaignTaskService, times(2)).updateTaskStatus(any(), anyString());
    }

}