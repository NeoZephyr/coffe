package com.convertlab.macore.campaign.runtime;

import com.convertlab.data.job.core.biz.model.BizJob;
import com.convertlab.data.job.core.biz.model.BizJobRunResult;
import com.convertlab.data.job.core.biz.model.ReturnCode;
import com.convertlab.data.job.core.biz.model.ReturnT;
import com.convertlab.data.job.core.util.data.BizJobClient;
import com.convertlab.foundation.library.business.feature.FeatureClient;
import com.convertlab.foundation.library.business.feature.QueryToggleTenantsResponse;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.runtime.task.CampaignTaskService;
import com.convertlab.macore.campaign.runtime.task.ITaskRuntimeService;
import com.convertlab.macore.campaign.runtime.taskchain.TimeStrategyService;
import com.convertlab.macore.campaign.service.CampaignService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.*;

import static java.lang.Thread.sleep;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CampaignTaskExecutorServiceServiceTest {

    @Mock
    private CampaignTaskService campaignTaskService;
    @Mock
    private CampaignExecutionTask task;

    @Mock
    private TimeStrategyService timeStrategyService;

    @Mock
    private BizJobClient bizJobClient;

    @Mock
    private TaskServiceFactory taskServiceFactory;
    @Mock
    private ITaskRuntimeService taskService;
    @Mock
    private TaskExecutorService taskExecutors;
    @Mock
    private TaskExecutorAction action;
    @Mock
    private CampaignService campaignService;

    @Mock
    private FeatureClient featureClient;

    @InjectMocks
    private CampaignTaskExecutorService campaignTaskExecutorService;


    @Test
    void scheduleTask_WithStoppedTask_DoesNotProceed() {
        when(task.getTaskStatus()).thenReturn(CampaignExecutionTask.TASK_STATUS_STOPPED);

        campaignTaskExecutorService._scheduleTask(task);

        verify(bizJobClient, never()).createAndStartBizJob(any());
        verify(campaignTaskService, never()).updateTaskStatus(any(), any());
    }

//
    @Test
    void scheduleTask_WithActiveTask_SchedulesAndUpdatesStatus() {
        when(task.getTaskStatus()).thenReturn(CampaignExecutionTask.TASK_STATUS_NOT_STARTED);
        when(task.getId()).thenReturn("taskId");
        when(task.getTenantId()).thenReturn(1L);
        when(task.getTaskTriggerDate()).thenReturn(Instant.now());
        when(timeStrategyService.convertUtcToCron(any())).thenReturn("cronExpression");
        ReturnT returnT = new ReturnT<>(new BizJob());
        returnT.setCode(ReturnCode.SUCCESS);
        when(bizJobClient.createBizJob(any())).thenReturn(returnT);

        campaignTaskExecutorService._scheduleTask(task);

        verify(bizJobClient).createBizJob(any());
        verify(campaignTaskService).updateTaskStatus(task, CampaignExecutionTask.TASK_STATUS_SCHEDULED);
    }


    @Test
    void unscheduleTask_CallsDeleteJobAndDefaultJobGroup() {
        String jobNo = "JOB_10_campaignTaskSchedulerHandler-1-taskId";
        when(task.getTenantId()).thenReturn(1L);
        when(task.getId()).thenReturn("taskId");
        when(bizJobClient.deleteJobAndDefaultJobGroup(jobNo)).thenReturn(new ReturnT<>(new BizJobRunResult()));

        campaignTaskExecutorService._unscheduleTask(task);

        verify(bizJobClient).deleteJobAndDefaultJobGroup(jobNo);
    }

    @Test
    void unscheduleTask_LogsErrorOnException() {
        String jobNo = "JOB_10_campaignTaskSchedulerHandler-1-taskId";
        when(task.getTenantId()).thenReturn(1L);
        when(task.getId()).thenReturn("taskId");
        doThrow(new RuntimeException("Failed to delete job")).when(bizJobClient).deleteJobAndDefaultJobGroup(jobNo);

        campaignTaskExecutorService._unscheduleTask(task);
    }

    @Test
    void startTaskDirectly_WithStoppedTask_DoesNotProceed() {
        when(task.getTaskStatus()).thenReturn(CampaignExecutionTask.TASK_STATUS_STOPPED);
        when(task.getId()).thenReturn("taskId");

        campaignTaskExecutorService._startTaskDirectly(task);

        verify(campaignTaskService, never()).updateTaskStatus(any(), any());
        verify(taskServiceFactory, never()).getTaskService(any());

    }

    @Test
    void startTaskDirectly_WithActiveTask_UpdatesStatusAndRunsTask() {
        when(task.getTaskStatus()).thenReturn(CampaignExecutionTask.TASK_STATUS_NOT_STARTED);
        when(task.getId()).thenReturn("taskId");

        campaignTaskExecutorService._startTaskDirectly(task);

        verify(campaignTaskService).updateTaskStatus(task, CampaignExecutionTask.TASK_STATUS_RUNNING);
        verify(taskExecutors).runTaskAsync(eq(task), any(), eq(campaignTaskExecutorService));
    }


    @Test
    void startTask_WithScheduledTask_CallsScheduleTask() {
        when(task.getTaskTriggerDate()).thenReturn(Instant.now());
        when(task.getTaskStatus()).thenReturn(CampaignExecutionTask.TASK_STATUS_NOT_STARTED);
        when(task.getId()).thenReturn("taskId");
        when(campaignTaskService.getTask("taskId")).thenReturn(task);

        when(task.getTaskStatus()).thenReturn(CampaignExecutionTask.TASK_STATUS_NOT_STARTED);
        when(task.getId()).thenReturn("taskId");
        when(task.getTenantId()).thenReturn(1L);
        when(task.getTaskTriggerDate()).thenReturn(Instant.now().plusSeconds(300));
        when(timeStrategyService.convertUtcToCron(any())).thenReturn("cronExpression");
        ReturnT returnT = new ReturnT<>(new BizJob());
        returnT.setCode(ReturnCode.SUCCESS);
        when(bizJobClient.createBizJob(any())).thenReturn(returnT);

        campaignTaskExecutorService.startTask("taskId");

        verify(bizJobClient).createBizJob(any());
        verify(campaignTaskService).updateTaskStatus(task, CampaignExecutionTask.TASK_STATUS_SCHEDULED);
    }

    @Test
    void startTask_WithTaskToStartDirectly_CallsStartTaskDirectly() {
        when(task.getTaskTriggerDate()).thenReturn(null);
        when(task.getTaskStatus()).thenReturn(CampaignExecutionTask.TASK_STATUS_NOT_STARTED);
        when(task.getId()).thenReturn("taskId");
        when(campaignTaskService.getTask("taskId")).thenReturn(task);

        campaignTaskExecutorService.startTask("taskId");

        verify(campaignTaskService).updateTaskStatus(task, CampaignExecutionTask.TASK_STATUS_RUNNING);
        verify(taskExecutors).runTaskAsync(eq(task), any(), eq(campaignTaskExecutorService));
    }

    @Mock
    private CampaignExecutionTask currentTask;
    @Mock
    private CampaignExecutionTask nextTask;

    @Test
    void startNextTask_WithNextTaskId_StartsNextTask() {
        when(currentTask.getNextTaskId()).thenReturn("nextTaskId");
        when(campaignTaskService.getTask("nextTaskId")).thenReturn(nextTask);
        when(nextTask.getId()).thenReturn("nextTaskId");

        campaignTaskExecutorService.startNextTask(currentTask);

        verify(campaignTaskService, times(2)).getTask("nextTaskId");
        verify(taskExecutors).runTaskAsync(eq(nextTask), any(), eq(campaignTaskExecutorService));
    }

    @Test
    void startNextTask_WithNoNextTaskId_DoesNothing() {
        when(currentTask.getNextTaskId()).thenReturn(null);

        campaignTaskExecutorService.startNextTask(currentTask);

        verify(campaignTaskService, never()).getTask(any());
    }

    @Test
    void startNextTask_WithNonExistentNextTask_ThrowsException() {
        when(currentTask.getNextTaskId()).thenReturn("nonExistentTaskId");
        when(campaignTaskService.getTask("nonExistentTaskId")).thenReturn(null);

        BusinessException exception = assertThrows(
                BusinessException.class,
                () -> campaignTaskExecutorService.startNextTask(currentTask)
        );
    }


    @Test
    void failTask_UpdatesTaskStatusAndLogsError() {
        Exception exception = new RuntimeException("Error message");
        when(task.getId()).thenReturn("taskId");
        when(task.getEngageId()).thenReturn(2L); // Engage ID greater than 1

        campaignTaskExecutorService._failTask(task, exception);

        verify(campaignTaskService).updateTaskStatus(task, CampaignExecutionTask.TASK_STATUS_FAILED, "Error message");
        verify(campaignService).updateEngageStatus(2L, CampaignOutboundEngage.ENGAGE_STATUS_FAILED);
    }

    @Test
    void failTask_UpdatesCampaignStatusWhenNoEngageId() {
        Exception exception = new RuntimeException("Error message");
        when(task.getId()).thenReturn("taskId");
        when(task.getEngageId()).thenReturn(0L); // No Engage ID
        when(task.getCampaignId()).thenReturn(1L); // Campaign ID

        campaignTaskExecutorService._failTask(task, exception);

        verify(campaignService).updateCampaignStatus(1L, MarketingCampaign.STATUS_FAILED);
    }

    @Test
    void finishTask_CallsFinishAndUpdateStatusAndStartsNextTask() {

        when(task.getNextTaskId()).thenReturn("nextTaskId");
        BusinessException exception = assertThrows(
                BusinessException.class,
                () ->  campaignTaskExecutorService._finishTask(task, taskService)
        );


        verify(taskService).finish(task);
        verify(campaignTaskService).updateTaskStatus(task, CampaignExecutionTask.TASK_STATUS_FINISHED);
    }

    @Mock
    private JsonUtils jsonUtils;
    @Test
    public void testCampaignTaskSchedulerHandler_Success() {
        // Arrange
        String jsonInput = "{\"tenantId\":\"1\", \"taskId\":\"task123\"}";
        Map<String, Object> jobData = new HashMap<>();
        jobData.put("tenantId", "1");
        jobData.put("taskId", "task123");

        when(jsonUtils.json2Obj(jsonInput, Map.class)).thenReturn(jobData);
        CampaignExecutionTask mockTask = new CampaignExecutionTask();  // Assuming there's a constructor or a builder
        mockTask.setTaskStatus(CampaignExecutionTask.TASK_STATUS_SCHEDULED);
        when(campaignTaskService.getTask("task123")).thenReturn(mockTask);

        // Act
        campaignTaskExecutorService._campaignTaskSchedulerHandler(jsonUtils, jsonInput);

        // Assert
        verify(campaignTaskService, times(1)).getTask("task123");
        verify(taskExecutors).runTaskAsync(eq(mockTask), any(), eq(campaignTaskExecutorService));
    }



    @Test
    void whenNoTenantFound_ShouldSkipHandler() {
        QueryToggleTenantsResponse response = new QueryToggleTenantsResponse();
        response.setRows(Collections.emptyList());
        when(featureClient.getToggleTenants(anyString(), anyInt(), anyInt())).thenReturn(response);

        campaignTaskExecutorService.campaignTaskAsyncJobHandler();

        verify(featureClient).getToggleTenants(anyString(), anyInt(), anyInt());
        verifyNoMoreInteractions(campaignTaskService, taskExecutors);
        // 可以添加日志断言
    }

    @Test
    void whenTenantFoundButNoTasks_ShouldSkipHandlerForTenant() {
        QueryToggleTenantsResponse response = mockResponseWithTenants();
        when(featureClient.getToggleTenants(anyString(), anyInt(), anyInt())).thenReturn(response);
        when(campaignTaskService.getRunningAsyncCallTasks()).thenReturn(Collections.emptyList());

        campaignTaskExecutorService.campaignTaskAsyncJobHandler();

        // 确认对每个feature进行了处理，但没有任务要执行
        verify(taskExecutors, never()).runTaskAsync(any(), any(), any());
        // 可以添加日志断言
    }

    @Test
    void whenTenantFoundAndTasksExist_ShouldExecuteTasksAsync() {
        QueryToggleTenantsResponse response = mockResponseWithTenants();
        when(featureClient.getToggleTenants(anyString(), anyInt(), anyInt())).thenReturn(response);
        when(campaignTaskService.getRunningAsyncCallTasks()).thenReturn(mockTasks());

        campaignTaskExecutorService.campaignTaskAsyncJobHandler();

        // 确认任务被异步执行了
        verify(taskExecutors, atLeastOnce()).runTaskAsync(any(CampaignExecutionTask.class), any(), any());
    }

    private QueryToggleTenantsResponse mockResponseWithTenants() {
        QueryToggleTenantsResponse response = new QueryToggleTenantsResponse();
        QueryToggleTenantsResponse.Feature feature = new QueryToggleTenantsResponse.Feature(); // 假设 Feature 是一个有效的类
        feature.setTenantId(123L); // 示例值
        response.setRows(Arrays.asList(feature));
        return response;
    }

    private List<CampaignExecutionTask> mockTasks() {
        CampaignExecutionTask task = new CampaignExecutionTask(); // 假设 CampaignExecutionTask 是一个有效的类
        // 设置task的属性...
        return Arrays.asList(task);
    }


    @Test
    void testStartTask_scheduler() {
        // 创建被测类的实例
        CampaignTaskExecutorService service = new CampaignTaskExecutorService(null,null,null,campaignTaskService,null,null,null);

        // 使用spy监视实例，因为我们可能需要验证方法的内部调用
        CampaignTaskExecutorService spiedService = spy(service);

        // Mock 相关的服务和任务对象
        CampaignExecutionTask task = mock(CampaignExecutionTask.class);

        // 当请求特定任务ID时，返回模拟的任务对象
        when(campaignTaskService.getTask("taskId")).thenReturn(task);

        // 设置任务触发日期
        Instant triggerDate = Instant.now().plusSeconds(300); // 5分钟后
        when(task.getTaskTriggerDate()).thenReturn(triggerDate);
        doNothing().when(spiedService)._scheduleTask(any(CampaignExecutionTask.class));

        // 调用方法
        spiedService.startTask("taskId");

        // 验证是否调用了_scheduleTask而不是_startTaskDirectly
        verify(spiedService).startTask("taskId");
        verify(spiedService)._scheduleTask(task);
        verify(spiedService, never())._startTaskDirectly(task);

        // 确保获取了任务
        verify(campaignTaskService).getTask("taskId");

        // 确认触发日期被检查
        verify(task, times(2)).getTaskTriggerDate();
    }


    @Test
    void testStartTask_start_task_schedule_before_now() {
        // 创建被测类的实例
        CampaignTaskExecutorService service = new CampaignTaskExecutorService(null,null,null,campaignTaskService,null,null,null);

        // 使用spy监视实例，因为我们可能需要验证方法的内部调用
        CampaignTaskExecutorService spiedService = spy(service);

        // Mock 相关的服务和任务对象
        CampaignExecutionTask task = mock(CampaignExecutionTask.class);

        // 当请求特定任务ID时，返回模拟的任务对象
        when(campaignTaskService.getTask("taskId")).thenReturn(task);

        // 设置任务触发日期
        Instant triggerDate = Instant.now().minusSeconds(300); // 5分钟后
        when(task.getTaskTriggerDate()).thenReturn(triggerDate);
        doNothing().when(spiedService)._startTaskDirectly(any(CampaignExecutionTask.class));

        // 调用方法
        spiedService.startTask("taskId");

        // 验证是否调用了_scheduleTask而不是_startTaskDirectly
        verify(spiedService).startTask("taskId");
        verify(spiedService, never())._scheduleTask(task);
        verify(spiedService)._startTaskDirectly(task);

        // 确保获取了任务
        verify(campaignTaskService).getTask("taskId");

        // 确认触发日期被检查
        verify(task, times(2)).getTaskTriggerDate();
    }

    @Test
    void testStartTask_start_task_without_trigger_date() {
        // 创建被测类的实例
        CampaignTaskExecutorService service = new CampaignTaskExecutorService(null,null,null,campaignTaskService,null,null,null);

        // 使用spy监视实例，因为我们可能需要验证方法的内部调用
        CampaignTaskExecutorService spiedService = spy(service);

        // Mock 相关的服务和任务对象
        CampaignExecutionTask task = mock(CampaignExecutionTask.class);

        // 当请求特定任务ID时，返回模拟的任务对象
        when(campaignTaskService.getTask("taskId")).thenReturn(task);

        // 设置任务触发日期
        when(task.getTaskTriggerDate()).thenReturn(null);
        doNothing().when(spiedService)._startTaskDirectly(any(CampaignExecutionTask.class));

        // 调用方法
        spiedService.startTask("taskId");

        // 验证是否调用了_scheduleTask而不是_startTaskDirectly
        verify(spiedService).startTask("taskId");
        verify(spiedService, never())._scheduleTask(task);
        verify(spiedService)._startTaskDirectly(task);

        // 确保获取了任务
        verify(campaignTaskService).getTask("taskId");

        // 确认触发日期被检查
        verify(task).getTaskTriggerDate();
    }
}