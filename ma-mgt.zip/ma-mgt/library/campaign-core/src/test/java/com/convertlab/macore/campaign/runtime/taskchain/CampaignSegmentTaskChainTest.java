package com.convertlab.macore.campaign.runtime.taskchain;

import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.runtime.task.CampaignTaskService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class CampaignSegmentTaskChainTest {

    @Mock
    private CampaignTaskService campaignTaskService;

    @Mock
    private TimeStrategyService timeStrategyService;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private CampaignSegmentTaskChain campaignSegmentTaskChain;

    private CampaignFullDataDTO campaignFullData;


    @BeforeEach
    void setUp() {
        campaignFullData = mock(CampaignFullDataDTO.class);
    }

    @Test
    public void testCreateTaskChainWithScheduledEngages() {
        // 准备输入数据
        CampaignFullDataDTO campaignFullData = mock(CampaignFullDataDTO.class);
        MarketingCampaign campaign = mock(MarketingCampaign.class);
        when(campaignFullData.getCampaign()).thenReturn(campaign);
        CampaignOutboundEngage outboundEngage1 = new CampaignOutboundEngage();
        outboundEngage1.setTimeStrategy("Scheduled");
        outboundEngage1.setTimeData("{\"scheduledDate\":\"2024-5-6T10:00:00Z\"}");
        CampaignOutboundEngage outboundEngage2 = new CampaignOutboundEngage();
        outboundEngage2.setTimeStrategy("Scheduled");
        outboundEngage2.setTimeData("{\"scheduledDate\":\"2024-5-7T10:00:00Z\"}");

        when(campaignFullData.getOutboundEngageList()).thenReturn(Arrays.asList(
                outboundEngage1,
                outboundEngage2
        ));

        // 配置模拟行为
        when(campaignTaskService.createSegmentationTask(any(), any())).thenReturn(new CampaignExecutionTask());
        when(campaignTaskService.createStartEngageTask(any(), any())).thenReturn(new CampaignExecutionTask());
        when(timeStrategyService.getScheduledTime(any())).thenReturn(Instant.now());
        when(timeStrategyService.getSegmentScheduledTime(any())).thenReturn(Instant.now().plusSeconds(300));

        // 执行测试的方法
        List<CampaignExecutionTask> tasks = campaignSegmentTaskChain.createTaskChain(campaignFullData);

        // 验证
        assertEquals(6, tasks.size()); // 确保创建了三个任务：1个分段任务和2个启动engage的任务
        verify(campaignTaskService, times(1)).createSegmentationTask(any(), any());
        verify(campaignTaskService, times(2)).createStartEngageTask(any(), any());
        // 可以进一步验证设置的时间等逻辑
    }

    @Test
    public void testCreateTaskChainWithScheduledEngagesAndVerifyTime() {
        // 定义具体的时间点
        Instant now = Instant.now();
        Instant engageTime1 = now.plusSeconds(600); // 第一个engage的计划时间
        Instant engageTime2 = now.plusSeconds(1200); // 第二个engage的计划时间
        Instant expectedSegmentTime = now.plusSeconds(300); // 期望的最早segment计算时间

        // 配置mock对象返回特定的时间
        CampaignOutboundEngage engage1 = mock(CampaignOutboundEngage.class);
        CampaignOutboundEngage engage2 = mock(CampaignOutboundEngage.class);
        when(engage1.getTimeStrategy()).thenReturn("Scheduled");
        when(engage2.getTimeStrategy()).thenReturn("Scheduled");
        when(timeStrategyService.getScheduledTime(engage1)).thenReturn(engageTime1);
        when(timeStrategyService.getScheduledTime(engage2)).thenReturn(engageTime2);
        when(timeStrategyService.getSegmentScheduledTime(engageTime1)).thenReturn(expectedSegmentTime);
        when(timeStrategyService.getSegmentScheduledTime(engageTime2)).thenReturn(engageTime2);
        CampaignExecutionTask segementTask = new CampaignExecutionTask();
        segementTask.setTaskType("Segmentation");
        when(campaignTaskService.createSegmentationTask(any(), any())).thenReturn(segementTask);
        when(campaignTaskService.createStartEngageTask(any(), any())).thenReturn(new CampaignExecutionTask()).thenReturn(new CampaignExecutionTask());

        // 配置campaignFullData
        when(campaignFullData.getOutboundEngageList()).thenReturn(Arrays.asList(engage1, engage2));

        // 执行方法
        List<CampaignExecutionTask> tasks = campaignSegmentTaskChain.createTaskChain(campaignFullData);

        // 验证tasks列表中分段任务的时间是否被设置为最早的segment计算时间
        Optional<CampaignExecutionTask> segmentationTask = tasks.stream()
                .filter(Objects::nonNull) // 首先过滤掉null任务
                .filter(
                        task -> "Segmentation".equals(task.getTaskType())
                ) // 假设你有方法区分任务类型
                .findFirst();

        assertTrue(segmentationTask.isPresent());
        assertEquals(expectedSegmentTime, segmentationTask.get().getTaskTriggerDate());
    }

}