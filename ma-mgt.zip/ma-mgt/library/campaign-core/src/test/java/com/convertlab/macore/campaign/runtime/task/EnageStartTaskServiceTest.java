package com.convertlab.macore.campaign.runtime.task;

import com.convertlab.macore.campaign.model.dto.CampaignFullDataDTO;
import com.convertlab.macore.campaign.model.dto.DeployFlowResponse;
import com.convertlab.macore.campaign.model.entity.CampaignExecutionTask;
import com.convertlab.macore.campaign.model.entity.CampaignListInfo;
import com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage;
import com.convertlab.macore.campaign.model.entity.MarketingCampaign;
import com.convertlab.macore.campaign.service.CampaignFactsDataSyncService;
import com.convertlab.macore.campaign.service.CampaignService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage.ENGAGE_STATUS_FAILED;
import static com.convertlab.macore.campaign.model.entity.CampaignOutboundEngage.ENGAGE_STATUS_RUNNING;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EnageStartTaskServiceTest {

    @Mock
    CampaignTaskService campaignTaskService;

    @Mock
    CampaignService campaignService;

    @Mock
    MaCoreService  maCoreService;

    @Mock
    CampaignListInfoService campaignListInfoService;

    @Mock
    CampaignFactsDataSyncService campaignFactsDataSyncService;

    @InjectMocks
    EnageStartTaskService enageStartTaskService;


    @Test
    public void testOnStart_SuccessfulDeployment() {
        CampaignExecutionTask task = new CampaignExecutionTask();
        task.setCampaignId(123L);
        task.setEngageId(456L);

        CampaignFullDataDTO campaignFullData = mock(CampaignFullDataDTO.class);
        CampaignOutboundEngage outboundEngage = new CampaignOutboundEngage();
        outboundEngage.setFlowId(789L);

        when(campaignService.getCampaignFullData(task.getCampaignId())).thenReturn(campaignFullData);
        when(campaignFullData.getEngageByEngageId(task.getEngageId())).thenReturn(outboundEngage);

        DeployFlowResponse deployFlowResponse = new DeployFlowResponse();
        deployFlowResponse.setSuccess(true);
        when(maCoreService.deployFlow(campaignFullData, outboundEngage)).thenReturn(deployFlowResponse);
        CampaignListInfo listInfo = new CampaignListInfo();
        doNothing().when(campaignFactsDataSyncService).updateGroupFactsGroupDate(any(), any(), any(), any());

        TaskResult result = enageStartTaskService.onStart(task);

        assertTrue(result.isFinish());
        verify(campaignService).updateEngageStatus(task.getEngageId(), ENGAGE_STATUS_RUNNING);
    }


    @Test
    public void testOnStart_UnsuccessfulDeployment() {
        CampaignExecutionTask task = new CampaignExecutionTask();
        task.setCampaignId(123L);
        task.setEngageId(456L);

        CampaignFullDataDTO campaignFullData = mock(CampaignFullDataDTO.class);
        CampaignOutboundEngage outboundEngage = new CampaignOutboundEngage();
        outboundEngage.setFlowId(789L);

        when(campaignService.getCampaignFullData(task.getCampaignId())).thenReturn(campaignFullData);
        when(campaignFullData.getEngageByEngageId(task.getEngageId())).thenReturn(outboundEngage);

        DeployFlowResponse deployFlowResponse = new DeployFlowResponse();
        deployFlowResponse.setSuccess(false);
        when(maCoreService.deployFlow(campaignFullData, outboundEngage)).thenReturn(deployFlowResponse);
//        doNothing().when(campaignListInfoService).updateExecutionTime(anyLong(), anyLong(), anyString(), any());
        TaskResult result = enageStartTaskService.onStart(task);

        assertFalse(result.isFinish);
        verify(maCoreService).deployFlow(campaignFullData, outboundEngage); // Ensure deployFlow was called
        verify(campaignService).updateEngageStatus(task.getEngageId(), ENGAGE_STATUS_FAILED);

    }


}