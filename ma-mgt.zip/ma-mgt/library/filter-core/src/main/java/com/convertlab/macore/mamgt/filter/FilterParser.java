package com.convertlab.macore.mamgt.filter;

import com.convertlab.foundation.api.queryengine.FilterV4Dto;
import com.convertlab.foundation.api.queryengine.SqlBuilder;
import com.convertlab.macore.mamgt.filter.model.filterV4.TimelineFilterV4;
import com.convertlab.macore.mamgt.filter.model.filterV4.request.FilterV4VO;
import com.convertlab.macore.mamgt.filter.model.filterv2.Filters;
import com.convertlab.macore.mamgt.filter.model.filterv2.Preview;
import org.springframework.lang.Nullable;


public interface FilterParser {

    public FilterV4Dto parseTimeLineFilterV4(String profileName, Preview preview, TimelineFilterV4 timelineFilterV4);

    /**
     * 高级筛选返回档案数量，兼容FilterV2 和ViewModel的输入
     *
     * @param preview
     * @return
     */
    public Long filterV4Count(String profileName, Preview<FilterV4VO> preview);


    /**
     * 将filterV2条件字符串，转换为ViewModel
     *
     * @param profileName
     * @param filterV2String
     * @return
     * @throws Exception
     */
    public FilterV4VO convertFilterV2ToViewModel(String profileName, String filterV2String) throws Exception;

    public FilterV4VO convertFilterV2ToViewModel(String profileName, Filters filterV2) throws Exception;

    public FilterV4Dto convertFilterV2ToFilterV4(String profileName, String sqlDialect, String primaryKeyAlias,
                                                 FilterV4VO filterV4VO) throws Exception;

    /**
     * 将FilterV2转换为FilterV4，是convertFilterV2ToViewModel 和 convertViewModelToFilterV4的组合
     *
     * @param profileName
     * @param filterV2
     * @return
     */
    public FilterV4Dto convertFilterV2ToFilterV4(String profileName, String sqlDialect, String primaryKeyAlias, Filters filterV2) throws Exception;

    /**
     * 将FilterV4转换为NativeSQL
     *
     * @param filterV4Dto 完整的FilterV4结构，发给Foundation
     * @param sqlDialect  转换方言
     * @param impersonate 伪装用户，生成带数据权限的SQL
     * @return
     */
    public String convertFilterV4ToSqlWithDialect(String profileName, FilterV4Dto filterV4Dto, SqlBuilder.SQLDialect sqlDialect,
                                                  @Nullable SqlBuilder.Impersonate impersonate) throws Exception;

    public String convertFilterV4ToGdqlWithDialect(String profileName, FilterV4Dto filterV4Dto, SqlBuilder.SQLDialect sqlDialect, @Nullable SqlBuilder.Impersonate impersonate) throws Exception;

    /**
     * 初始化JavaScript Engine
     */
    public void initJavaScriptEngine();
}
