package com.convertlab.macore.mamgt.filter.filters;

import cn.hutool.core.map.MapUtil;
import com.convertlab.common.crypto.client.enums.AttrType;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto;
import com.convertlab.foundation.api.queryengine.FilterV4Dto;
import com.convertlab.foundation.api.queryengine.GdmCount;
import com.convertlab.foundation.api.queryengine.GdmQuery;
import com.convertlab.foundation.api.queryengine.SqlBuilder;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClientWrapper;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmInheritance;
import com.convertlab.foundation.library.jdbc.datasource.lookup.DataSourceLookupHelper;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.mamgt.cdp.client.GdmModelClientWrapper;
import com.convertlab.macore.mamgt.cdp.common.utils.FilterV4VOBuilder;
import com.convertlab.macore.mamgt.cdp.dto.Profile;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.GeneralProfileBizMeta;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.ProfileBizMeta;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.associated.ProfileEventBizMeta;
import com.convertlab.macore.mamgt.cdp.meta.service.ProfileEventMetaService;
import com.convertlab.macore.mamgt.cdp.meta.service.ProfileMetaService;
import com.convertlab.macore.mamgt.cdp.meta.utils.FeatureHelper;
import com.convertlab.macore.mamgt.cdp.profile.common.utils.EncryptionHelper;
import com.convertlab.macore.mamgt.cdp.profile.mapper.TenantRelatedMapper;
import com.convertlab.macore.mamgt.cdp.profile.service.ProfileExtService;
import com.convertlab.macore.mamgt.common.service.ServiceUnitService;
import com.convertlab.macore.mamgt.filter.FilterParser;
import com.convertlab.macore.mamgt.filter.filters.misc.client.QueryEngineFeignClient;
import com.convertlab.macore.mamgt.common.utils.NamingUtils;
import com.convertlab.macore.mamgt.filter.constants.Constants;
import com.convertlab.macore.mamgt.filter.enums.IdentifierTypeEnum;
import com.convertlab.macore.mamgt.filter.filters.model.FilterResponse;
import com.convertlab.macore.mamgt.filter.filters.model.mapping.ConvertMapping;
import com.convertlab.macore.mamgt.filter.model.filterV4.*;
import com.convertlab.macore.mamgt.filter.model.filterV4.request.FilterV4VO;
import com.convertlab.macore.mamgt.filter.model.filterV4.request.IdentifierVO;
import com.convertlab.macore.mamgt.filter.model.filterV4.request.TimelineFilterV4VO;
import com.convertlab.macore.mamgt.filter.model.filterV4.request.WhereVO;
import com.convertlab.macore.mamgt.filter.model.filterv2.Filters;
import com.convertlab.macore.mamgt.filter.model.filterv2.Preview;
import com.convertlab.macore.mamgt.filter.filters.model.mapping.Sort;
import com.convertlab.macore.mamgt.filter.filters.service.FilterMetaService;
import com.convertlab.macore.mamgt.filter.filters.model.dto.GdmEntityBizMeta;
import com.convertlab.macore.mamgt.filter.filters.model.dto.function.FunctionBody;
import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.base.CaseFormat;
import lombok.Synchronized;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.checkerframework.checker.initialization.qual.Initialized;
import org.checkerframework.checker.nullness.qual.KeyForBottom;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.UnknownKeyFor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StopWatch;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import static com.convertlab.foundation.library.constant.CommonErrors.VALIDATION_ERROR;
import static com.convertlab.macore.mamgt.cdp.common.constants.ProfileConstants.PROFILE_CUSTOMER;
import static com.convertlab.macore.mamgt.filter.enums.IdentifierTypeEnum.*;

import com.convertlab.macore.mamgt.filter.filters.visitor.*;


@Slf4j
@Service
public class FilterV4Parser implements FilterParser {
    private static final String LOG_PREFIX = "<ma-mgt> <FilterV4Parser>";
    private static final String IS_TIMELINE = "_timeline";
    private static final String OTHERS_TABLE_NAME = "others";
    public static final String AS = " as ";
    private final QueryEngineFeignClient queryEngineFeignClient;
    private final ConditionsConvertVisitor conditionsConvertVisitor;
    private final ConditionsRemoveVisitor conditionsRemoveVisitor;
    private final ConditionsAddSinceIdVisitor conditionsAddSinceIdVisitor;
    private final ConditionsAggFuncVisitor conditionsAggFuncVisitor;
    private final ConditionsAddAdditionalConditionVisitor conditionsAddAdditionalConditionVisitor;
    private final ConditionsDefaultVisitor conditionsDefaultVisitor;
    private final ConditionsValueConvertVisitor conditionsValueConvertVisitor;
    private final FilterMetaService metaService;
    private final ProfileMetaService profileMetaService;
    private final ProfileEventMetaService profileEventMetaService;
    private final ProfileExtService profileExtService;
    private final GsMetaClientWrapper gsMetaClient;
    private final GdmModelClientWrapper gdmModelClient;
    private final ServiceUnitService serviceUnitService;
    private final TenantRelatedMapper tenantRelatedMapper;
    //private final FiltersV4Mapper filtersV4Mapper;

    private static final Map<String, String> tableNameMap;
    private static final Map<String, List<String>> columnsMap;
    private static final Map<String, String> filtersColumnMap;

    static {
        columnsMap = new HashMap<>();
        tableNameMap = new HashMap<>();
        filtersColumnMap = new HashMap<>();
        List<String> customerSegmentColumns = Arrays.asList("is_feature", "is_external", "is_system", "total", "is_static", "date_created", "auto_update", "version", "id", "filters");
        List<String> customerTraitColumns = Arrays.asList("id", "definition");
        List<String> udoSegmentColumns = Arrays.asList("last_updated", "date_created", "version", "id", "filters"); // GDQL 的select
        columnsMap.put("customer_segment", customerSegmentColumns);
        columnsMap.put("customer_trait", customerTraitColumns);
        columnsMap.put("udo_segment", udoSegmentColumns);
        tableNameMap.put("customer_segment", "list");
        tableNameMap.put("customer_trait", "tag_rule");
        tableNameMap.put("udo_segment", "udo_list");
        filtersColumnMap.put("customer_segment", "filters");
        filtersColumnMap.put("customer_trait", "definition");
        filtersColumnMap.put("udo_segment", "rule"); // GDQL 不支持On duplicated key

    }
    public FilterV4Parser(QueryEngineFeignClient queryEngineFeignClient, ConditionsConvertVisitor conditionsConvertVisitor,
                          ConditionsRemoveVisitor conditionsRemoveVisitor,
                          ConditionsAddSinceIdVisitor conditionsAddSinceIdVisitor,
                          ConditionsAggFuncVisitor conditionsAggFuncVisitor,
                          ConditionsDefaultVisitor conditionsDefaultVisitor,
                          ConditionsAddAdditionalConditionVisitor conditionsAddAdditionalConditionVisitor,
                          ConditionsValueConvertVisitor conditionsValueConvertVisitor,
                          FilterMetaService metaService,
                          ProfileMetaService profileMetaService,
                          ProfileEventMetaService profileEventMetaService,
                          ProfileExtService profileExtService,
                          GsMetaClientWrapper gsMetaClient,
                          GdmModelClientWrapper gdmModelClient,
                          ServiceUnitService serviceUnitService,
                          TenantRelatedMapper tenantRelatedMapper) {
                          //FiltersV4Mapper filtersV4Mapper) {
        this.queryEngineFeignClient = queryEngineFeignClient;
        this.conditionsConvertVisitor = conditionsConvertVisitor;
        this.conditionsRemoveVisitor = conditionsRemoveVisitor;
        this.conditionsAddSinceIdVisitor = conditionsAddSinceIdVisitor;
        this.conditionsAggFuncVisitor = conditionsAggFuncVisitor;
        this.conditionsDefaultVisitor = conditionsDefaultVisitor;
        this.conditionsAddAdditionalConditionVisitor = conditionsAddAdditionalConditionVisitor;
        this.conditionsValueConvertVisitor = conditionsValueConvertVisitor;
        this.metaService = metaService;
        this.profileMetaService = profileMetaService;
        this.profileEventMetaService = profileEventMetaService;
        this.profileExtService = profileExtService;
        this.gsMetaClient = gsMetaClient;
        this.gdmModelClient = gdmModelClient;
        this.serviceUnitService = serviceUnitService;
        this.tenantRelatedMapper = tenantRelatedMapper;
        //this.filtersV4Mapper = filtersV4Mapper;
    }

    private static final TypeReference<GdmQuery.Response> GDM_RESPONSE_TYPE_REFERENCE = new TypeReference<GdmQuery.Response>() {
    };
    private static final TypeReference<GdmCount.Response> GDM_COUNT_RESPONSE_TYPE_REFERENCE = new TypeReference<GdmCount.Response>() {
    };
    private static final TypeReference<SqlBuilder.Response> SQL_BUILDER_RESPONSE_TYPE_REFERENCE = new TypeReference<SqlBuilder.Response>() {
    };

    @Value("${queryEngineServer.serverUrl}")
    private String queryEngineServerUrl;

    @Value("${convertlab.filter.persist-v4-model}")
    private Boolean persistV4Model;

    private ScriptEngineManager scriptEngineManager;

    private ScriptEngine scriptEngine;

    //@Override
    public FilterResponse filterV4List(String entityName, Preview<FilterV4VO> preview, Boolean isTimeline) {
        final String profileName = NamingUtils.toLowerUnderScoreCase(entityName);
        //validate some key fields
        FilterV4VO filterV4VO = preview.getFilters().getV4();
        FilterResponse validateResult = validateParam(filterV4VO);
        if (!ObjectUtils.isEmpty(validateResult)) {
            return validateResult;
        }
        preHandleRequest(filterV4VO);

        String filterV4Json = JsonUtils.instanceOfDto().obj2Json(filterV4VO);
        // support event sequence logic
        TimelineFilterV4 timelineFilterV4 = JsonUtils.instanceOfDto().json2Obj(filterV4Json, TimelineFilterV4.class);
        FilterV4Dto filterV4Dto = parseTimeLineFilterV4(profileName, preview, timelineFilterV4);

        if(isTimeline) {
            String table = filterV4Dto.getTable();
            Sort.EntitySort entitySort = getSort(profileName, table, true);
            if (entitySort != null) {
                List<FilterV4Dto.OrderByItem> orderBy = entitySort.getOrderBy().stream()
                        .map(item -> new FilterV4Dto.OrderByItem(table + "." + item.getField(), item.getDesc()))
                        .collect(Collectors.toList());
                filterV4Dto.setOrderBy(orderBy);
            }

        }

        log.info("Request filterV4 to query-engine is: " + JsonUtils.instanceOfDto().obj2Json(filterV4Dto));
        GdmQuery.Response gdmQueryResponse = null;
        try {
            String primaryKey = isTimeline ? "id" : Optional.ofNullable(gsMetaClient.getEntity(NamingUtils.toLowerUnderScoreCase(profileName)))
                    .map(GdmEntity::getPrimaryKeyField).orElse(null);
            if (StringUtils.isBlank(primaryKey)) {
                throw new BusinessException(CommonErrors.GENERAL_ERROR,
                        "MSG_100_000020", "PrimaryKey is missing for " + profileName, new String[]{profileName});
            }
            List<FilterV4Dto.Identifier> tmpSelect =
                    Arrays.asList(new FilterV4Dto.Identifier(FilterV4Dto.IdentifierType.COLUMN.getType(), primaryKey));
            List<@KeyForBottom @NonNull @Initialized ? extends FilterV4Dto.@UnknownKeyFor @NonNull @Initialized Identifier> finalSelect
                    = filterV4Dto.getSelect();
            if(1 == finalSelect.size()
                    && ((FilterV4Dto.Identifier) finalSelect.get(0)).getValue().toString().equals(primaryKey)){
                gdmQueryResponse = queryEngineFeignClient.queryEngineQuery(new GdmQuery.Request(null, null,
                        filterV4Dto, preview.isNeedTotal(), null));
            }else if(false == preview.getAppendPrimaryKeyInSelect()){
                // 不需要后台自动拼主键
                gdmQueryResponse = queryEngineFeignClient.queryEngineQuery(new GdmQuery.Request(null, null,
                        filterV4Dto, preview.isNeedTotal(), null));
            }else{
                // 克服impala select多个字段性能低下问题，分2次查询，第一次只查主键（id或bk）第二次使用in的方式查所有字段
                filterV4Dto.setSelect(tmpSelect);

                gdmQueryResponse = queryEngineFeignClient.queryEngineQuery(new GdmQuery.Request(null, null,
                        filterV4Dto, preview.isNeedTotal(), null));

                List<Map<String, Object>> res = gdmQueryResponse.getRows();
                if(Objects.nonNull(res) && res.size() > 0){
                    List<String> ids = new ArrayList<>();
                    res.forEach(map -> {
                        if (map != null && map.get(primaryKey) != null) {
                            if(isTimeline){
                                ids.add(map.get(primaryKey).toString());
                            }else{
                                ids.add("'" + map.get(primaryKey).toString() + "'");
                            }
                        }
                    });

                    List<String> listSelectField = new ArrayList<>();
                    finalSelect.forEach( ele -> {
                        if("source1".equals(ele.getValue())){
                            ele.setValue("medium");
                            ele.setAlias("source1");
                        }
                        if("source2".equals(ele.getValue())){
                            ele.setValue("term");
                            ele.setAlias("source2");
                        }
                        String strSingleField = ele.getValue();
                        if(Objects.nonNull(ele.getAlias())){
                            strSingleField += AS + ele.getAlias();
                        }
                        listSelectField.add(strSingleField);
                    });

                    // 需要查询创建人的时候，必须带上creator_id，然后再BffResponseBodyAdvice中根据查出来的creator_id插入creator
                    if(listSelectField.stream().filter(f -> f.contains("creator")).count() >0
                            && listSelectField.stream().filter(f -> f.contains("creator_id")).count() ==0){
                        listSelectField.add("creator_id");
                    }
                    String strSelect = String.join(",", listSelectField);
                    String strIds = String.join(",", ids);
                    String tableName = NamingUtils.toLowerUnderScoreCase(timelineFilterV4.getTable());

                    Sort.EntitySort entitySort = getSort(profileName, tableName, isTimeline);
                    String strOrderBy = "";
                    if (Objects.nonNull(entitySort)) {
                        OrderByItem orderByItem = entitySort.getOrderBy().get(0);
                        strOrderBy = String.format("order by %s %s",
                                orderByItem.getField(), orderByItem.getDesc() ? "desc" : "asc");
                    }

                    String strGDQL = String.format("select %s from %s where %s in (%s) %s",
                            strSelect, tableName, primaryKey, strIds, strOrderBy);
                    log.info("Request GDQL to query-engine is: " + strGDQL);

                    long total = -1L;
                    if(preview.isNeedTotal()){
                        total = gdmQueryResponse.getTotal();
                    }
                    gdmQueryResponse = queryEngineFeignClient.queryEngineQuery(
                            new GdmQuery.Request(strGDQL, null, null, false, "OLAP"));
                    gdmQueryResponse.setTotal(total);
                }
            }
        } catch (Exception e) {
            log.error("failed to query query-engine", e);
            throw new BusinessException(CommonErrors.GENERAL_ERROR, "MSG_100_000019", "Exception while querying query-engine", new String[]{e.getMessage()});
        }
        List<Map<String, Object>> res = gdmQueryResponse.getRows();
        res.forEach(map -> {
            if (map != null && map.get("id") != null) {
                map.put("idStr", String.valueOf(map.get("id")));
            }
        });
        log.info("Response filterV4 from query-engine count: {} total: {}", res.size(), gdmQueryResponse.getTotal());
        return FilterResponse.builder().records(res.stream()
                .map(Profile::new).map(profile -> profileExtService.addCodeListValueToProfile(filterV4VO.getTable(), profile))
                .collect(Collectors.toList())).total(gdmQueryResponse.getTotal()).build();
    }


    @Override
    public Long filterV4Count(String entityName, Preview<FilterV4VO> preview) {
        final String profileName = NamingUtils.toLowerUnderScoreCase(entityName);
        //validate some key fields
        FilterV4VO filterV4VO = preview.getFilters().getV4();
        validateParam(filterV4VO);
        preHandleRequest(filterV4VO);

        String filterV4Json = JsonUtils.instanceOfDto().obj2Json(filterV4VO);


        //support event sequence logic
        TimelineFilterV4 timelineFilterV4 = JsonUtils.instanceOfDto().json2Obj(filterV4Json, TimelineFilterV4.class);
        FilterV4Dto filterV4Dto = parseTimeLineFilterV4(profileName, preview, timelineFilterV4);
        log.info("Transformation request query-engine count json is:" + JsonUtils.instanceOfDto().obj2Json(filterV4Dto));
        GdmCount.Response gdmCountResponse = queryEngineFeignClient.queryEngineQueryCount(new GdmCount.Request(filterV4Dto, null));
        log.debug("Transformation response query-engine count json is:" + JsonUtils.instanceOfDto().obj2Json(gdmCountResponse));
        return gdmCountResponse.getTotal();
    }

    /**
     * 将filterV4转换为SQL
     *
     * @param entityName  档案名称
     * @param filterV4Dto 完整的FilterV4结构，发给Foundation
     * @param sqlDialect  转换方言
     * @param impersonate 伪装用户，生成带数据权限的SQL
     * @return
     * @throws Exception
     */
    @Override
    public String convertFilterV4ToSqlWithDialect(String entityName, FilterV4Dto filterV4Dto, SqlBuilder.SQLDialect sqlDialect,
                                                  @Nullable SqlBuilder.Impersonate impersonate) throws Exception {
        final String profileName = NamingUtils.toLowerUnderScoreCase(entityName);
        //v4-> nativeSQl without addition impersonate info
        SqlBuilder.Response gdqlResponse = queryEngineFeignClient.queryEngineSql(new SqlBuilder.Request(null, filterV4Dto, SqlBuilder.OutputFormat.SQL, sqlDialect, impersonate));
        if (gdqlResponse != null && gdqlResponse.getSql() != null) {
            return gdqlResponse.getSql();
        } else {
            log.error("failed to convertFilterV4ToSqlWithDialect " + JsonUtils.instanceOfDto().obj2Json(filterV4Dto) + " \n to  " + sqlDialect + " \n result: " + gdqlResponse);
            throw new RuntimeException("failed to convertFilterV4ToSqlWithDialect");
        }
    }

    /**
     * 将filterV4转换为SQL
     *
     * @param entityName  档案名称
     * @param filterV4Dto 完整的FilterV4结构，发给Foundation
     * @param sqlDialect  转换方言
     * @return
     * @throws Exception
     */
    @Override
    public String convertFilterV4ToGdqlWithDialect(String entityName, FilterV4Dto filterV4Dto, SqlBuilder.SQLDialect sqlDialect,
                                                   @Nullable SqlBuilder.Impersonate impersonate) throws Exception {
        final String profileName = NamingUtils.toLowerUnderScoreCase(entityName);
        //v4-> nativeSQl without addition impersonate info
        SqlBuilder.Response gdqlResponse = queryEngineFeignClient.queryEngineSql(new SqlBuilder.Request(null, filterV4Dto, SqlBuilder.OutputFormat.GDQL, sqlDialect, impersonate));
        if (gdqlResponse != null && gdqlResponse.getGdql() != null) {
            return gdqlResponse.getGdql();
        } else {
            log.error("failed to convertFilterV4ToGdqlWithDialect " + JsonUtils.instanceOfDto().obj2Json(filterV4Dto) + " \n to  " + sqlDialect + " \n result: " + gdqlResponse);
            throw new RuntimeException("failed to convertFilterV4ToGdqlWithDialect");
        }
    }

    /**
     * Compatible support event sequence logic
     *
     * @param preview
     * @param timelineFilterV4
     * @return
     */
    @Override
    public FilterV4Dto parseTimeLineFilterV4(@Nonnull String profileName, Preview preview, TimelineFilterV4 timelineFilterV4) {
        try{
            // convert table name to lower cased
            if (timelineFilterV4.getTable() != null) {
                timelineFilterV4.setTable(NamingUtils.toLowerUnderScoreCase(timelineFilterV4.getTable()));
            }
            String primaryKeyField = Optional.ofNullable(gsMetaClient.getEntity(NamingUtils.toLowerUnderScoreCase(profileName)))
                    .map(GdmEntity::getPrimaryKeyField).orElse(null);
            if (StringUtils.isBlank(primaryKeyField)) {
                throw new BusinessException(CommonErrors.GENERAL_ERROR, "MSG_100_000020", "PrimaryKeyField is missing for " + profileName, new String[]{profileName});
            }
            //parse preview select columns
            List<Select> selectList = Optional.ofNullable(preview.getSelect())
                    .map(select -> {
                        if (!select.contains(primaryKeyField)) {
                            select += ("," + primaryKeyField);
                        }
                        return Arrays.stream(select.split(","))
                                .map(e -> getSelect(timelineFilterV4.getTable(), e))
                                .collect(Collectors.toList());
                    })
                    .orElseGet(() -> Collections.singletonList(new Select(COLUMN.getType(), primaryKeyField)));

            //set v4 select fields
            Optional.ofNullable(timelineFilterV4.getSelect())
                    .ifPresent(select -> selectList.addAll(select));
            timelineFilterV4.setSelect(selectList);
            //set v4 limit
            Optional.of(preview.getRows())
                    .filter(rows -> rows > 0)
                    .ifPresent(rows -> timelineFilterV4.setLimit(new Limit(rows)));
            //set v4 order fields
            setOrderBy(profileName, timelineFilterV4);

            Map<String, Object> compareOperatorMap = new HashMap<>();
            compareOperatorMap.put(Constants.MAIN_TABLE, timelineFilterV4.getTable());

            Optional.ofNullable(preview.getSinceId()).ifPresent(sinceId -> {
                if (false == sinceId.isEmpty()) {
                    compareOperatorMap.put(Constants.SINCEID, sinceId);
                    Where.LogicalOperator logicalOp = timelineFilterV4.getWhere().getLogicalOp();
                    if (Objects.isNull(logicalOp)) {
                        Where.LogicalOperator child = FilterV4VOBuilder.buildLogicalNode(Where.Operator.Constants.AND);
                        conditionsAddSinceIdVisitor.getFilterV4Convert().addSinceIdCondition(null,
                                compareOperatorMap, child.getConditions().listIterator());
                        Where.LogicalOperator parent = FilterV4VOBuilder.buildLogicalNode(Where.Operator.Constants.AND, child);
                        logicalOp = parent;
                    }
                    logicalOp.accept(profileName, conditionsAddSinceIdVisitor, compareOperatorMap, null);
                    timelineFilterV4.getWhere().setLogicalOp(logicalOp);
                }
            });


            //support common query logic
            Optional.ofNullable(timelineFilterV4.getWhere().getLogicalOp())
                    .ifPresent(logicalOp -> {

                        compareOperatorMap.put(Constants.V4_CURRENT_STEP, Constants.V4_CURRENT_STEP_1);
                        compareOperatorMap.put(Constants.V4_CONDITION_DEEP_LEVEL, 0);
                        compareOperatorMap.put(Constants.V4_ROOT_NODE_INDEX, 0);
                        if (logicalOp.getConditions().isEmpty()) {
                            timelineFilterV4.getWhere().setLogicalOp(null);
                            return;
                        }

                        logicalOp.accept(profileName, conditionsConvertVisitor, compareOperatorMap, null);
                        if (!compareOperatorMap.isEmpty()) {
                            logicalOp.accept(profileName, conditionsRemoveVisitor, compareOperatorMap, null);
                        }

                        logicalOp.accept(profileName, conditionsAggFuncVisitor, compareOperatorMap, null);

                        compareOperatorMap.put(Constants.V4_CONDITION_DEEP_LEVEL, 0);
                        logicalOp.accept(profileName, conditionsDefaultVisitor, compareOperatorMap, null);
                        if (!compareOperatorMap.isEmpty()) {
                            logicalOp.accept(profileName, conditionsRemoveVisitor, compareOperatorMap, null);
                        }

                        logicalOp.accept(profileName, conditionsValueConvertVisitor, compareOperatorMap, null);

                        compareOperatorMap.put(Constants.V4_CONDITION_DEEP_LEVEL_FOR_ADDITIONAL_CONDITION, 0);
                        logicalOp.accept(profileName, conditionsAddAdditionalConditionVisitor, compareOperatorMap, null);
                        //convert fields camel to underline
                        iteratorConditionsAndUpdateIdentifier.accept(logicalOp.getConditions().listIterator());
                    });
            //support event sequence logic
            Optional.ofNullable(timelineFilterV4.getWhere().getTimeline())
                    .ifPresent(timeline -> {
                        compareOperatorMap.put(Constants.V4_CURRENT_STEP, Constants.V4_CURRENT_STEP_2);
                        compareOperatorMap.put(Constants.V4_CONDITION_DEEP_LEVEL, 0);
                        compareOperatorMap.put(Constants.V4_ROOT_NODE_INDEX, 0);

                        timeline.forEach(existence -> existence.getConditions().accept(profileName, conditionsConvertVisitor, compareOperatorMap, null));
                        if (!compareOperatorMap.isEmpty()) {
                            timeline.forEach(existence -> existence.getConditions().accept(profileName, conditionsRemoveVisitor, compareOperatorMap, null));
                        }

                        timeline.forEach(existence -> existence.getConditions().accept(profileName, conditionsDefaultVisitor, compareOperatorMap, null));
                        if (!compareOperatorMap.isEmpty()) {
                            timeline.forEach(existence -> existence.getConditions().accept(profileName, conditionsRemoveVisitor, compareOperatorMap, null));
                        }
                        //convert fields camel to underline
                        timeline.forEach(existence -> iteratorConditionsAndUpdateIdentifier.accept(existence.getConditions().getConditions().listIterator()));
                    });

            String filterV4Json = JsonUtils.instanceOfDto().obj2Json(timelineFilterV4);
            return JsonUtils.instanceOfDto().json2Obj(filterV4Json, FilterV4Dto.class);
        }catch(Exception e){
            log.error("failed to parseTimeLineFilterV4", e);
            throw new BusinessException(CommonErrors.GENERAL_ERROR, "MSG_100_000018", "Exception while parsing timelineFilterV4", new String[]{profileName, e.getMessage()});
        }
    }

    private final Consumer<Identifier> updateIdentifierToLowerUnderscore = identifier -> {
        Optional<String> optionalValue = Optional.ofNullable(identifier.getType());
        if (optionalValue.isPresent()) {
            boolean isExist = Arrays.stream(Constants.UNDER_SCORE_CASE_TYPES).anyMatch(identifier.getType()::equals);
            if (isExist) {
                String fieldIdentifier = identifier.getValue();
                String join = NamingUtils.toUnderScoreCase(fieldIdentifier);
                identifier.setValue(join);
            }
        } else {
            throw new BusinessException(CommonErrors.MISSING_FIELD, "MSG_100_000002", new String[]{}, 0);
        }
    };

    private final Consumer<Identifier> updateIdentifierValidEntity = identifier -> {
        Optional<String> optionalValue = Optional.ofNullable(identifier.getType());
        if (optionalValue.isPresent()) {
            boolean isExist = Arrays.stream(Constants.UNDER_SCORE_CASE_TYPES).anyMatch(identifier.getType()::equals);
            if (isExist) {
                String fieldIdentifier = identifier.getValue();
                String result = NamingUtils.convertInvalidBOToValidEntity(fieldIdentifier);
                identifier.setValue(result);
            }
        } else {
            throw new BusinessException(CommonErrors.MISSING_FIELD, "MSG_100_000002", new String[]{}, 0);
        }
    };

    private final Consumer<ListIterator<Where.Operator>> iteratorConditionsAndUpdateIdentifier = operatorListIterator -> {
        while (operatorListIterator.hasNext()) {
            Where.Operator operator = operatorListIterator.next();
            if (operator instanceof Where.CompareOperator) {
                Where.CompareOperator compareOperator = (Where.CompareOperator) operator;
                Identifier left = compareOperator.getLeft();
                Optional.ofNullable(left).ifPresent(updateIdentifierToLowerUnderscore);
                Optional.ofNullable(left).ifPresent(updateIdentifierValidEntity);
                Identifier right = compareOperator.getRight();
                Optional.ofNullable(right).ifPresent(updateIdentifierToLowerUnderscore);
            } else if (operator instanceof Where.LogicalOperator) {
                Where.LogicalOperator logicalOperator = (Where.LogicalOperator) operator;
                ListIterator<Where.Operator> listIterator = logicalOperator.getConditions().listIterator();
                this.iteratorConditionsAndUpdateIdentifier.accept(listIterator);
            }
        }
    };

    private FilterResponse validateParam(FilterV4VO filterV4) {
        if (Objects.isNull(filterV4)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_100_000003", new String[]{}, 0);
        }
        if (filterV4.getVersion() != Constants.FILTER_VERSION) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_100_000004", new String[]{}, 0);
        }
        return null;
    }

    private void preHandleRequest(FilterV4VO filterV4) {
        Optional.ofNullable(filterV4.getWhere())
                .ifPresent(where -> {
                    //加密身份参数
                    encryptCustomerIdentity(where.getLogicalOp());
                    TimelineFilterV4VO.TimeRange timeRange = where.getTimeRange();
                    Optional.ofNullable(timeRange).ifPresent(ele -> {
                        if (IdentifierTypeEnum.VALUE.getType()
                                .equalsIgnoreCase(ele.getFrom().getType())) {
                            ele.getFrom().setExpr(ele.getFrom().getExpr().toString().replace("T", " "));
                            ele.getFrom().setExpr(ele.getFrom().getExpr().toString().replace("Z", ""));
                        }

                        if (IdentifierTypeEnum.VALUE.getType()
                                .equalsIgnoreCase(ele.getTo().getType())) {
                            ele.getTo().setValue(ele.getTo().getExpr().toString());
                            ele.getTo().setExpr(ele.getTo().getExpr().toString().replace("T", " "));
                            ele.getTo().setExpr(ele.getTo().getExpr().toString().replace("Z", ""));
                        }
                    });

                    Optional.ofNullable(where.getTimeline())
                            .ifPresent(timeline -> {
                                timeline.forEach(occurrence -> {
                                    occurrence.setTimeRange(timeRange);
                                });
                            });
                });

    }

    /**
     * filterV4条件对象 加密身份参数
     *
     * @param logicalOp filterV4条件对象
     */
    private void encryptCustomerIdentity(WhereVO.LogicalOperator logicalOp) {
        encryptCustomerOrIdentityAttr(logicalOp, "identity");
    }

    /**
     * filterV4条件对象 加密身份参数
     *
     * @param logicalOp    filterV4条件对象
     * @param categoryName category类型（customer,identity）
     */
    private void encryptCustomerOrIdentityAttr(WhereVO.LogicalOperator logicalOp, String categoryName) {
        if (logicalOp == null || CollectionUtils.isEmpty(logicalOp.getConditions())) {
            return;
        }
        AttrType attrType = AttrType.PROPS_ATTRS;
        if ("identity".equals(categoryName)) {
            attrType = AttrType.IDENTITY;
        }
        List<WhereVO.Operator> conditions = logicalOp.getConditions();
        for (WhereVO.Operator condition : conditions) {
            if (condition == null) {
                continue;
            } else if (condition instanceof WhereVO.LogicalOperator) {
                encryptCustomerIdentity((WhereVO.LogicalOperator) condition);
            } else if (condition instanceof WhereVO.CompareOperator) {
                WhereVO.CompareOperator compareCondition = ((WhereVO.CompareOperator) condition);
                Map<String, Object> extraParams = compareCondition.getExtraParams();
                if (extraParams == null || extraParams.isEmpty()) {
                    continue;
                }
                Object category = extraParams.get("category");
                if (category == null || !categoryName.equals(category.toString())) {
                    continue;
                }
                Object columnName = getValueFromCompareOperatorByType(compareCondition, "COLUMN");
                if (columnName == null) {
                    continue;
                }
                String valueIdentifierType = "VALUE";
                Object columnValue = getValueFromCompareOperatorByType(compareCondition, valueIdentifierType);
                if (columnValue == null) {
                    valueIdentifierType = "VALUES";
                    columnValue = getValueFromCompareOperatorByType(compareCondition, valueIdentifierType);
                }
                if (columnValue == null) {
                    continue;
                }
                String attrName = columnName.toString();
                if (attrName.contains(".")) {
                    String[] split = attrName.split("\\.");
                    attrName = split[split.length - 1];
                }

                if (columnValue instanceof List) {
                    List<Object> list = new ArrayList<>();
                    for (Object val : (List<?>) columnValue) {
                        //加密身份参数
                        val = EncryptionHelper.encryptCustomerOrIdentityAttr(attrType, attrName, val.toString());
                        list.add(val);
                    }
                    columnValue = list;
                } else {
                    //加密身份参数
                    columnValue = EncryptionHelper.encryptCustomerOrIdentityAttr(attrType, attrName, columnValue.toString());
                }
                setValueFromCompareOperatorByType(compareCondition, valueIdentifierType, "expr", columnValue);
            }
        }
    }

    /**
     * 根据类型获取CompareOperator内的IdentifierVO对象
     *
     * @param compareCondition 对象
     * @param identifierType   Identifier类型
     * @return
     */
    private IdentifierVO getIdentifierVOByType(WhereVO.CompareOperator compareCondition, String identifierType) {
        if (compareCondition == null || StringUtils.isBlank(identifierType)) {
            return null;
        }
        IdentifierVO left = compareCondition.getLeft();
        if (left != null && identifierType.equalsIgnoreCase(left.getType())) {
            return left;
        }
        IdentifierVO right = compareCondition.getRight();
        if (right != null && identifierType.equalsIgnoreCase(right.getType())) {
            return right;
        }
        return null;
    }

    /**
     * 获取IdentifierVO对象的值
     *
     * @param identifierVO 对象
     * @return
     */
    private Object getValueFromIdentifierVO(IdentifierVO identifierVO) {
        if (identifierVO == null) {
            return null;
        }
        Object value = identifierVO.getExpr();
        if (value == null) {
            value = identifierVO.getValue();
        }
        if (value == null) {
            value = identifierVO.getValues();
        }
        return value;
    }

    /**
     * 设置IdentifierVO对象的值
     *
     * @param identifierVO 对象
     * @param valueType    要设置的字段类型（value，expr，values，alias）
     * @param value        具体的值
     */
    private void setValueFromIdentifierVO(IdentifierVO identifierVO, String valueType, Object value) {
        if (identifierVO == null) {
            return;
        }
        if (StringUtils.isBlank(valueType)) {
            valueType = "value";
        }
        if ("expr".equalsIgnoreCase(valueType)) {
            identifierVO.setExpr(value);
        } else if ("value".equalsIgnoreCase(valueType)) {
            if (value == null) {
                identifierVO.setValue(null);
            } else {
                identifierVO.setValue(value.toString());
            }
        } else if ("values".equalsIgnoreCase(valueType)) {
            if (value == null) {
                identifierVO.setValues(null);
            } else {
                identifierVO.setValues(((List<?>) value).stream().filter(Objects::nonNull).map(Object::toString).collect(Collectors.toList()));
            }
        } else if ("alias".equalsIgnoreCase(valueType)) {
            if (value == null) {
                identifierVO.setAlias(null);
            } else {
                identifierVO.setAlias(value.toString());
            }
        }
    }

    /**
     * 获取CompareOperator内的指定类型的IdentifierVO对象的值
     *
     * @param compareCondition 对象
     * @param identifierType   IdentifierVO对象的类型
     * @return
     */
    private Object getValueFromCompareOperatorByType(WhereVO.CompareOperator compareCondition, String identifierType) {
        IdentifierVO identifierVO = getIdentifierVOByType(compareCondition, identifierType);
        return getValueFromIdentifierVO(identifierVO);
    }

    /**
     * 根据identifier类型 和值类型设置CompareOperator对象的值
     *
     * @param compareCondition 对象
     * @param identifierType   identifier类型
     * @param valueType        值类型（value，expr，values，alias）
     * @param value            填充的值
     */
    private void setValueFromCompareOperatorByType(WhereVO.CompareOperator compareCondition, String identifierType, String valueType, Object value) {
        IdentifierVO identifierVO = getIdentifierVOByType(compareCondition, identifierType);
        setValueFromIdentifierVO(identifierVO, valueType, value);
    }

    private Select getSelect(String profileName, String columnName) {
        Map<String, String> selectItemAsMap = getColumnName(profileName, columnName);
        return new Select(ObjectUtils.isEmpty(selectItemAsMap.get(Constants.UIDF)) ? COLUMN.getType() : FUNC.getType(),
                selectItemAsMap.get(VALUE.getType()),
                selectItemAsMap.get(Constants.ALIAS));
    }

    public void setOrderBy(String profileName, FilterV4 filterV4) {
        String table = filterV4.getTable();
        Sort.EntitySort entitySort = getSort(profileName, table, false);
        if (entitySort != null) {
            List<OrderByItem> orderBy = entitySort.getOrderBy().stream()
                    .map(item -> new OrderByItem(table + "." + item.getField(), item.getDesc()))
                    .collect(Collectors.toList());
            filterV4.setOrderBy(orderBy);
        }
    }

    private Sort.EntitySort getSort(String profileName, String table, boolean isTimeline){
        if(isTimeline){
            table += IS_TIMELINE;
        }
        Sort sort = metaService.getFilterConvertMappings(profileName).getConvertMapping().getEntity().getSort();
        Sort.EntitySort entitySort = sort.getEntities().get(table);
        if (entitySort == null) {
            String otherTable = isTimeline ? OTHERS_TABLE_NAME + IS_TIMELINE : OTHERS_TABLE_NAME;
            entitySort = sort.getEntities().get(otherTable);
        }

        return entitySort;
    }

    private Map<String, String> getColumnName(String profileName, String fieldName) {
        String aliasName = null;
        if(fieldName.contains(AS)){
            String[] parts = fieldName.split(AS);
            if(parts.length == 2){
                fieldName = parts[0].trim();
                aliasName = parts[1].trim();
            }
        }
        Map<String, String> map = MapUtil.newHashMap();
        ConvertMapping convertMapping = metaService.getFilterConvertMappings(profileName).getConvertMapping();
        List<String> fieldNamePrefix = convertMapping.getFieldNamePrefix();
        List<Map<String, Object>> selectMappings = convertMapping.getEntity().getSelectMappings();
        for (String fieldPrefix : fieldNamePrefix) {
            if (fieldName.startsWith(fieldPrefix)) {
                fieldName = fieldName.substring(fieldPrefix.length());
            }
        }
        String finalFieldName = fieldName;
        String finalAliasName = aliasName != null ? aliasName: fieldName;
        Assert.notNull(finalFieldName, "finalFieldName is null");
        Assert.notNull(finalAliasName, "finalAliasName is null");
        List<String> customizedColumnName = selectMappings.stream()
                .filter(mapping -> mapping.containsKey(finalFieldName))
                .map(mapping -> mapping.get(finalFieldName).toString())
                .collect(Collectors.toList());
        if (!customizedColumnName.isEmpty()) {
            map.put(VALUE.getType(), customizedColumnName.get(0));
            map.put(Constants.ALIAS, finalAliasName);
            map.put(Constants.UIDF, "true");
        } else {
            String columnName = fieldName;
            if (StringUtils.startsWithIgnoreCase(fieldName, "c_")
                    || StringUtils.startsWithIgnoreCase(fieldName, "cp_")) {
                map.put(VALUE.getType(), columnName);
            } else {
                columnName = CaseFormat.LOWER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, columnName);
                map.put(VALUE.getType(), columnName);
                if (!StringUtils.equals(columnName, fieldName)) {
                    map.put(Constants.ALIAS, finalAliasName);
                }
            }
        }
        return map;
    }

    private ProfileBizMeta loadProfileMeta(String profileName) {
        ProfileBizMeta meta = profileMetaService.getProfileBizMeta(profileName, true, true, false, false,
                false, false, false, Arrays.asList(
                        FeatureHelper.Feature.OneId,
                        FeatureHelper.Feature.Event,
                        FeatureHelper.Feature.Indicator,
                        FeatureHelper.Feature.Order,
                        FeatureHelper.Feature.Source,
                        FeatureHelper.Feature.Member,
                        FeatureHelper.Feature.Campaign
                ));
        if (meta == null) {
            throw new BusinessException(CommonErrors.GENERAL_ERROR, "MSG_100_000013", new String[]{});
        }
        List<ProfileEventBizMeta> events = profileEventMetaService.getBizEventMetas(profileName, false, false,
                false, false, false, true);
        ((GeneralProfileBizMeta) meta).setEvents(events);
        return meta;
    }

    /**
     * 将FilterV2 转换为FilterV4的ViewModel
     *
     * @param filterV2String FilterV2 JSON String
     * @return
     */
    @Override
    public FilterV4VO convertFilterV2ToViewModel(String entityName, String filterV2String) throws Exception {
        final String profileName = NamingUtils.toLowerUnderScoreCase(entityName);
        StopWatch sw = new StopWatch();
        sw.start();
        final ProfileBizMeta profileBizMeta = loadProfileMeta(profileName);
        if (profileBizMeta == null) {
            throw new BusinessException(CommonErrors.GENERAL_ERROR, "MSG_100_000012", new String[]{});
        }
        sw.stop();
        log.info("convertFilterV2ToViewModel load loadProfileMeta in : " + sw.getLastTaskTimeMillis() + "ms");
        String profileMeta = JsonUtils.instanceOfDto().obj2Json(profileBizMeta);
        if(sw.getLastTaskTimeMillis() > 100){
//            log.debug("convertFilterV2ToViewModel profileMeta : {}", profileMeta);
        }

        sw.start();
        List<FunctionBody> functionBodyList = metaService.getMetaFunction();
        if (functionBodyList == null || functionBodyList.size() == 0) {
            throw new BusinessException(CommonErrors.GENERAL_ERROR, "MSG_100_000012", new String[]{});
        }
        sw.stop();
        String functionMetaString = JsonUtils.instanceOfDto().obj2Json(functionBodyList);

        sw.start();
        Map<String, Object> meta = metaService.getMetaRelation(profileName);
        if (meta == null) {
            throw new BusinessException(CommonErrors.GENERAL_ERROR, "MSG_100_000013", new String[]{});
        }
        sw.stop();
        log.info("convertFilterV2ToViewModel load relationMeta in : " + sw.getLastTaskTimeMillis() + "ms");
        String relationMeta = JsonUtils.instanceOfDto().obj2Json(meta.get("metaRelations"));
        if(sw.getLastTaskTimeMillis() > 100){
//            log.debug("convertFilterV2ToViewModel relationMeta : {}", relationMeta);
        }

        sw.start();
        Map<String, GdmEntityBizMeta> gdmMetaJson = metaService.batchGetGdmBizMeta(profileName, Collections.emptyList());
        if (meta == null) {
            throw new BusinessException(CommonErrors.GENERAL_ERROR, "MSG_100_000013", new String[]{});
        }
        sw.stop();
        log.info("convertFilterV2ToViewModel load gdmMeta in : " + sw.getLastTaskTimeMillis() + "ms");
        String gdmMeta = JsonUtils.instanceOfDto().obj2Json(gdmMetaJson);
        if(sw.getLastTaskTimeMillis() > 100){
//            log.debug("convertFilterV2ToViewModel gdmMeta : {}", gdmMeta);
        }

        if (StringUtils.isBlank(profileMeta) || profileMeta.length() < 3
                || StringUtils.isBlank(functionMetaString) || functionMetaString.length() < 3
                || StringUtils.isBlank(relationMeta) || relationMeta.length() < 3
                || StringUtils.isBlank(gdmMeta) || gdmMeta.length() < 3) {
            throw new BusinessException(CommonErrors.GENERAL_ERROR, "MSG_100_000012", new String[]{});
        }
        return executeConvertorJavaScript(profileName, profileMeta, functionMetaString, relationMeta, gdmMeta, filterV2String);
    }

    @Synchronized
    @Override
    public void initJavaScriptEngine(){
        StopWatch sw = new StopWatch();
        if (scriptEngineManager == null) {
            scriptEngineManager = new ScriptEngineManager();
        }
        if (scriptEngine == null) {
            sw.start();
            scriptEngine = scriptEngineManager.getEngineByName("JavaScript");
            String jsContent = com.converlab.macore.filter.ViewModelConverter.getFilterV2ToViewModelScript();
            try {
                scriptEngine.eval("var global = {}");
                scriptEngine.eval(jsContent);
                sw.stop();
                log.info("convertFilterV2ToViewModel load javascript in : " + sw.getLastTaskTimeMillis() + "ms");
            } catch (Exception e) {
                sw.stop();
                log.error("failed to initialize javascript engine", e);
                scriptEngine = null;
            }
        }
    }

    @Synchronized
    private FilterV4VO executeConvertorJavaScript(final String profileName,
                                                  final String profileMeta,
                                                  final String functionMetaString,
                                                  final String relationMeta,
                                                  final String gdmMeta,
                                                  final String filterV2String) throws BusinessException {
/*        log.info("{} enter executeConvertorJavaScript profileName {}," +
                "profileMeta {}," +
                "functionMetaString {}," +
                "relationMeta {}, " +
                "gdmMeta {}," +
                "filterV2String {}", LOG_PREFIX, profileName, profileMeta, functionMetaString,
                relationMeta, gdmMeta, filterV2String);*/
        StopWatch sw = new StopWatch();
        if(scriptEngine ==null){
            log.warn("javascript engine is not initialized, will initialize it now");
            initJavaScriptEngine();
        }

        if (scriptEngine != null) {
            try {
                sw.start();
                Invocable invoke = null;
                if (scriptEngine instanceof Invocable) {
                    invoke = (Invocable) scriptEngine;
                }
                Object global = scriptEngine.get("global");
                log.info("convertV2ToV4 from filterV2: " + filterV2String);
                Object result = invoke.invokeMethod(global, "convertV2ToV4", filterV2String, profileMeta, functionMetaString, relationMeta, gdmMeta, profileName);
                sw.stop();
                log.info("convertFilterV2ToViewModel execute convert filters v2 to view model in : " + sw.getLastTaskTimeMillis() + "ms");
                if (result != null && StringUtils.isNotBlank(result.toString())) {
                    String condition = result.toString();
                    log.info("convertV2ToV4 got viewModel: " + condition);
                    if (condition != null && condition.contains("{\"table\":\"customer\",\"version\":4,\"where\":{\"logicalOp\":{\"and\":{\"conditions\":[{\"and\":{\"conditions\":[]}}]}}}}}")) {
                        log.warn("{} convertV2ToV4 got empty v4 condition: {}, profileMeta: {}, relationMeta: {}, gdmMeta: {}",
                                profileName, condition, profileMeta, relationMeta, gdmMeta);
                    }
                    sw.start();
                    Preview<FilterV4VO> viewModel = JsonUtils.dtoMapper().readValue(condition, new TypeReference<Preview<FilterV4VO>>() {
                    });
                    sw.stop();
                    log.info("convertFilterV2ToViewModel deserialize in : " + sw.getLastTaskTimeMillis() + "ms");
                    return viewModel.getFilters().getV4();
                }
                throw new BusinessException(CommonErrors.GENERAL_ERROR, "MSG_100_000018", new String[]{profileName, "javascript engine returns null"});
            } catch (Exception e) {
                log.error("Failed convertFilterV2ToViewModel " + e.getMessage(), e);
                throw new BusinessException(CommonErrors.GENERAL_ERROR, "MSG_100_000018", new String[]{profileName, e.getMessage()});
            }
        } else {
            throw new BusinessException(CommonErrors.GENERAL_ERROR, "MSG_100_000022", new String[]{});
        }
    }

    /**
     * 将Filters 格式的FilterV2 转换为FilterV4的ViewModel
     * @param profileName
     * @param filterV2
     * @return
     * @throws Exception
     */
    @Override
    public FilterV4VO convertFilterV2ToViewModel(String profileName, Filters filterV2) throws Exception {
        StopWatch sw = new StopWatch();
        sw.start();
        String primaryKeyField = Optional.ofNullable(gsMetaClient.getEntity(NamingUtils.toLowerUnderScoreCase(profileName)))
                .map(GdmEntity::getPrimaryKeyField).orElse(null);
        if (StringUtils.isBlank(primaryKeyField)) {
            throw new BusinessException(CommonErrors.GENERAL_ERROR, "MSG_100_000017", "profileName is missing", new String[]{"profileName"});
        }

        Preview<FilterV4> preview = new Preview<>();
        preview.setFilters(filterV2);
        preview.setSelect(primaryKeyField);
        FilterV4VO filterV4VO = null;
        String originOfFilterV4Vo = ""; // v4的来源，用来在日志中打印出来，方便排查问题
        if(persistV4Model == false){
            filterV2.setV4(null);
        }
        if (filterV2.getV4() != null && filterV2.getV4() instanceof Map) {
            filterV4VO = JsonUtils.instanceOfDto().convertFromMap((Map<String, Object>) filterV2.getV4(), FilterV4VO.class);
            originOfFilterV4Vo = "Map in request";
        } else if (filterV2.getV4() != null) {
            filterV4VO = (FilterV4VO) filterV2.getV4();
            originOfFilterV4Vo = "FilterV4VO in request";
        }
        if (Objects.isNull(filterV4VO)) {
            log.debug("there is not v4 node in preview, will convert filterV2 to viewModel using filterv2-convertor.jar ");
            String strFilterV2 = JsonUtils.instance().obj2Json(preview);
            filterV4VO = convertFilterV2ToViewModel(profileName, strFilterV2);
            filterV2.setV4(filterV4VO);
            log.debug("successfully convert filterV2 to V4 using filterv2-convertor.jar");
            originOfFilterV4Vo = "convert from V2";
        }
        sw.stop();
        log.info("got viewModel from {} cost: {}ms", originOfFilterV4Vo, sw.getLastTaskTimeMillis());
        if(filterV4VO == null) {
            log.error("failed to transform profile {}'s filterV2 to viewModel, filterv2 is: {}", profileName, JsonUtils.instanceOfDto().obj2Json(filterV2));
            throw new BusinessException(CommonErrors.GENERAL_ERROR, "MSG_100_000018", "Failed to convert profile {}'s filterV2 to viewmodel,  filterV2 is : {}",
                    new String[]{profileName, JsonUtils.instanceOfDto().obj2Json(filterV2)});
        }
        log.info("convertFilterV2ToViewModel from {}", originOfFilterV4Vo);
        return filterV4VO;
    }

    /**
     * 将 FilterV4VO 结构的ViewModel转换为FilterV4
     * @param profileName
     * @param sqlDialect
     * @param primaryKeyAlias
     * @param filterV4VO
     * @return
     * @throws Exception
     */
    @Override
    public FilterV4Dto convertFilterV2ToFilterV4(String profileName, String sqlDialect, String primaryKeyAlias,
                                                 FilterV4VO filterV4VO) throws Exception {
        String primaryKeyField = Optional.ofNullable(gsMetaClient.getEntity(NamingUtils.toLowerUnderScoreCase(profileName)))
                .map(GdmEntity::getPrimaryKeyField).orElse(null);
        if (StringUtils.isBlank(primaryKeyField)) {
            throw new BusinessException(CommonErrors.GENERAL_ERROR, "MSG_100_000017", "profileName is missing", new String[]{"profileName"});
        }
        preHandleRequest(filterV4VO);
        String viewModelString = JsonUtils.instance().obj2Json(filterV4VO);
        log.info("use viewModel: {} to generate V4", viewModelString);

        final String pkStr = StringUtils.isNotBlank(primaryKeyAlias) ? primaryKeyAlias : "id";
        TimelineFilterV4 timelineFilterV4 = JsonUtils.instance().json2Obj(viewModelString, TimelineFilterV4.class);

        Preview<FilterV4> preview = new Preview<>();
        Filters filters = new Filters();
        filters.setV4(filterV4VO);
        preview.setFilters(filters);
        preview.setSelect(primaryKeyField);

        FilterV4Dto filterV4Dto = parseTimeLineFilterV4(profileName, preview, timelineFilterV4);
        log.info("convertFilterV2ToFilterV4 return V4 {}", JsonUtils.instance().obj2Json(filterV4Dto));
        if (sqlDialect != null && sqlDialect.equalsIgnoreCase("spark")) {
            if (filterV4Dto != null && filterV4Dto.getTable().equals(PROFILE_CUSTOMER)) {
                for (int i = 0; i < filterV4Dto.getSelect().size(); i++) {
                    FilterV4Dto.Identifier s = filterV4Dto.getSelect().get(i);
                    if (COLUMN.getType().equals(s.getType()) && "id".equals(s.getValue())) {
                        if (s.getAlias() == null) {
                            s.setAlias(pkStr);
                        }
                    }
                }
            }
        }
        return filterV4Dto;
    }

    /**
     * 将FilterV2转换为FilterV4，如果filterV2中已有v4节点，将直接使用v4作为ViewModel进行转换
     * 返回的FilterV4将自动在Select中填充主键字段
     *
     * @param profileName
     * @param filterV2
     * @return
     */
    @Override
    public FilterV4Dto convertFilterV2ToFilterV4(@Nonnull String profileName, String sqlDialect, String primaryKeyAlias, Filters filterV2) throws Exception {
        FilterV4VO filterV4VO = this.convertFilterV2ToViewModel(profileName, filterV2);
        return this.convertFilterV2ToFilterV4(profileName, sqlDialect, primaryKeyAlias, filterV4VO);
    }

    /**
     * @param entityName
     * @param preview
     * @param response
     */
    //@Override
    public void postHandlerForTimelineRsp(String entityName, Preview<FilterV4VO> preview, FilterResponse response) {
        final String profileName = NamingUtils.toLowerUnderScoreCase(entityName);
        GdmEntity entity = gsMetaClient.getEntity(preview.getFilters().getV4().getTable());
        if (entity == null) {
            log.error("{} postHandlerForTimelineRsp stop . have a error . table name:{} not existed .", LOG_PREFIX, preview.getFilters().getV4().getTable());
            throw new BusinessException(VALIDATION_ERROR, "MSG_104_000011", "Invalid profile name: " + preview.getFilters().getV4().getTable(), new String[]{preview.getFilters().getV4().getTable()});
        }
        GdmInheritance inheritance = entity.getInheritance();
        if (Objects.nonNull(inheritance) && inheritance.isSubtype()
                && gsMetaClient.isEventEntity(entity)) {
            GdmModelDto gdmModelDto = gdmModelClient.findByName(profileName);
            if (gdmModelDto == null) {
                log.error("{} postHandlerForTimelineRsp stop . have a error . profile name:{} not existed .", LOG_PREFIX, profileName);
                throw new BusinessException(VALIDATION_ERROR, "MSG_104_000011", "Invalid profile name: " + preview.getFilters().getV4().getTable(), new String[]{preview.getFilters().getV4().getTable()});
            }
            String tableName = preview.getFilters().getV4().getTable();
            String strEvent = "";
            GdmPatternDto.ProvisionProperties props = gdmModelDto.getProps();
            if (Objects.nonNull(props)) {
                GdmPatternDto.ProfileEvent[] events = props.getEvents();
                if (Objects.nonNull(events)) {
                    for (GdmPatternDto.ProfileEvent event : events) {
                        if (event.getEventEntityName().equals(tableName)) {
                            strEvent = event.getEventId().toString();
                        }
                    }
                }
            }

            final String finalEvent = strEvent;
            Optional.ofNullable(response.getRecords()).ifPresent(records -> {
                records.forEach(record -> {
                    record.put("event", finalEvent);
                });
            });
        }
    }

    /**
     * 清理服务单元下所有租户的的FilterV4节点
     * @param serviceUnit 服务单元id
     * @param type 类型
     * @return
     */
    /*public void clearFilterV4ByServiceUnit(String serviceUnit, String type){
        log.info("{} start clearV4. serviceUnit: {} type: {}", LOG_PREFIX, serviceUnit, type);
        if (StringUtils.isNotBlank(type)) {
            if (!Arrays.asList("customer_segment", "customer_trait", "udo_segment").contains(type)) {
                log.error("{} Unknown type. Only customer_segment or customer_trait or udo_segment can be specified, or none can be specified. type: {}", LOG_PREFIX, type);
                throw new BusinessException(VALIDATION_ERROR, "MSG_104_000001", "Unknown type. Only customer_segment or customer_trait or udo_segment can be specified, or none can be specified.", new String[]{type});
            }
        }
        if (StringUtils.isNotBlank(serviceUnit)) {
            Set<String> allServiceUnit = serviceUnitService.getAllServiceUnit();
            if (!allServiceUnit.contains(serviceUnit)) {
                log.error("{} Unknown serviceUnit. serviceUnit: {}", LOG_PREFIX, serviceUnit);
                throw new BusinessException(VALIDATION_ERROR, "MSG_104_000001", "Unknown serviceUnit.", new String[]{serviceUnit});
            }
        }
        Map<String, List<Long>> suTenantIdMap = buildSuTenantIdMap(serviceUnit);
        suTenantIdMap.forEach((su, tenantIdList) -> tenantIdList.forEach(tenantId -> {
            try (TemporaryTenantContext ignored = new TemporaryTenantContext(tenantId)) {
                log.info("{} start serviceUnit: {} tenant: {} clearV4.", LOG_PREFIX, su, tenantId);
                if (StringUtils.isBlank(type)) {
                    clearFilterV4ByTenant("customer_segment");
                    clearFilterV4ByTenant("customer_trait");
                    clearFilterV4ByTenant("udo_segment");
                } else {
                    clearFilterV4ByTenant(type);
                }
            }
        }));
    }*/

    /*public void clearFilterV4ByTenant(String type){
        List<Map<String, Object>> filtersByTenantId = null;
        try{
            switch (type) {
                case "customer_segment":
                    filtersByTenantId = filtersV4Mapper.getSegmentFilters();
                    break;
                case "customer_trait":
                    filtersByTenantId = filtersV4Mapper.getTraitFilters();
                    break;
                case "udo_segment":
                    filtersByTenantId = filtersV4Mapper.getUdoSegmentFilters();
                    break;
                default:
                    // do nothing
                    break;
            }
        }catch (Exception e) {
            log.error("{} current tenantId select filters failed. type: {}", LOG_PREFIX, type, e);
            return;
        }
        if (filtersByTenantId == null || filtersByTenantId.size() == 0) {
            log.warn("{} current tenantId not have filtersV4. type: {}", LOG_PREFIX, type);
            return;
        }
        bulkUpdateFilters(type, filtersByTenantId);


    }*/

    /**
     * 批量清除群组标签条件中的V4节点
     * @param type
     * @param allFilters
     */
    /*private void bulkUpdateFilters(String type, List<Map<String, Object>> allFilters) {
        List<List<Object>> values = new ArrayList<>();
        for (Map<String, Object> map : allFilters) {
            List<Object> value = new ArrayList<>();
            Long segmentTraitId = (Long) map.getOrDefault("id", null);
            String filters = (String) map.getOrDefault("filters", null);
            if (segmentTraitId == null || StringUtils.isBlank(filters)) {
                log.warn("{} current segmentTraitId is empty or filters is empty. type: {}", LOG_PREFIX, type);
                break;
            }

            Map<String, Object> filtersJson = JsonUtils.instanceOfDto().json2Obj(filters, Map.class);
            try {
                if (filtersJson != null) {
                    filtersJson.remove("v4");
                    String noV4Filters = JsonUtils.instanceOfDto().obj2Json(filtersJson, false);
                    if ("customer_segment".equals(type)) {
                        boolean isFeature = (boolean) map.getOrDefault("is_feature", false);
                        boolean isExternal = (boolean) map.getOrDefault("is_external", false);
                        boolean isSystem = (boolean) map.getOrDefault("is_system", false);
                        long total = (long) map.getOrDefault("total", 0);
                        Object dateCreated = map.get("date_created");
                        boolean autoUpdate = (boolean) map.getOrDefault("auto_update", true);
                        long version = (long) map.getOrDefault("version", 1);
                        value.add(isFeature);
                        value.add(isExternal);
                        value.add(isSystem);
                        value.add(total);
                        value.add(false);
                        value.add(dateCreated);
                        value.add(autoUpdate);
                        value.add(version);
                        value.add(segmentTraitId);
                        value.add(noV4Filters);
                    }
                    if ("customer_trait".equals(type)) {
                        value.add(segmentTraitId);
                        value.add(noV4Filters);
                    }
                    if ("udo_segment".equals(type)) {
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                        String lastUpdate = simpleDateFormat.format(new Date());
                        Object dateCreate = map.get("date_created");
                        long version = (long) map.getOrDefault("version", 1);
                        value.add(lastUpdate);
                        value.add(dateCreate);
                        value.add(version);
                        value.add(segmentTraitId);
                        value.add(noV4Filters);
                    }
                }
                if (value.isEmpty()) {
                    log.warn("{} filters json parse to Filters<FilterV4VO> failed. type: {} segmentTraitId: {} filters: {}", LOG_PREFIX, type, segmentTraitId, filters);
                } else {
                    values.add(value);
                }
            } catch (Exception e) {
                log.error("{} fillBulkUpdateValue failed. segmentTraitId: {} filters: {}", LOG_PREFIX, segmentTraitId, filters, e);
                break;
            }
        }
        if(!values.isEmpty()){
            filtersV4Mapper.bulkUpdateFilters(tableNameMap.get(type), columnsMap.get(type), filtersColumnMap.get(type), values);
        } else {
            log.warn("{} bulkUpdateFilters values is empty. do nothing.", LOG_PREFIX);
        }
    }*/


    /**
     * 获取每个su的tenantId
     * e.g. su1 -> [1,2,3]
     *
     * @param serviceUnit serviceUnit
     * @return map
     * @author Mr.黄
     * @since 2024/4/2
     */
    public Map<String, List<Long>> buildSuTenantIdMap(String serviceUnit) {
        Set<Integer> suIds;
        if (StringUtils.isBlank(serviceUnit)) {
            suIds = serviceUnitService
                    .getAllServiceUnit()
                    .stream()
                    .map(s -> Integer.parseInt(s.split("su")[1]))
                    .collect(Collectors.toSet());
        } else {
            suIds = Collections.singleton(Integer.parseInt(serviceUnit.split("su")[1]));
        }
        return DataSourceLookupHelper.withLookupKey("main", () -> {
            List<Map<String, Object>> validTenantIdBySuIds = tenantRelatedMapper.getValidTenantIdBySuIds(suIds);
            Map<String, List<Long>> map = new HashMap<>();
            validTenantIdBySuIds.forEach(stringLongMap -> {
                Integer suId = (Integer) stringLongMap.get("su_id");
                Long tenantId = (Long) stringLongMap.get("tenant_id");
                if (suId != null && tenantId != null && suId > 0 && tenantId > 0) {
                    String su = "su" + suId;
                    List<Long> orDefault = map.getOrDefault(su, new ArrayList<>());
                    orDefault.add(tenantId);
                    map.put(su, orDefault);
                }
            });
            return map;
        });
    }

    public void setPersistV4Model(Boolean persistV4Model) {
        this.persistV4Model = persistV4Model;
    }
}
