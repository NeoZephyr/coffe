package com.convertlab.macore.campaign.autoconfigure;

import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import com.convertlab.macore.mamgt.cdp.service.GdmBizObjectMetaService;


@Configuration
@ComponentScan("com.convertlab.macore.campaign")
@ComponentScan("com.convertlab.macore.campaign.service")
public class CampaignAutoConfiguration {


    @Bean
    @ConditionalOnMissingBean
    public GdmBizObjectMetaService gdmBizObjectMetaService(@Qualifier("gsMetaClient") GsMetaClient gsMetaClient) {
        return new GdmBizObjectMetaService(gsMetaClient);
    }
}
