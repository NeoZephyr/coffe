package com.convertlab.macore.mamgt.common.enums;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.ObjectUtils;

import java.util.Arrays;

public enum FieldOpEnum {
    IN("in", "在之内"),
    EQUAL("=", "等于"),
    NOT_EQUAL("!=", "不等于"),
    LESS_THAN("<", "小于"),
    GREATER_THAN(">", "大于"),
    LESS_THAN_OR_EQUAL("<=", "小于等于"),
    GREATER_THAN_OR_EQUAL(">=", "大于等于");

    private String name;
    private String desc;

    FieldOpEnum(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }

    public String getName() {
        return this.name;
    }

    public String getDesc() {
        return this.desc;
    }

    public static FieldOpEnum geFieldOpEnumByName(String name, String val) {
        if (StringUtils.isNotBlank(val)
                && StringUtils.isNotBlank(name)
                && "=".equals(name)
                && val.contains(",")) {
            return FieldOpEnum.IN;
        }
        return geFieldOpEnumByName(name);
    }

    public static FieldOpEnum geFieldOpEnumByName(String name) {
        if (ObjectUtils.isEmpty(name)) {
            throw new IllegalArgumentException("unknown FieldOperator  name: " + name);
        }
        return Arrays.stream(FieldOpEnum.values())
                .filter(x -> name.equals(x.getName()))
                .findAny()
                .orElseThrow(IllegalArgumentException::new);
    }
}
