package com.convertlab.macore.mamgt.misc.configure;

import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.macore.mamgt.misc.advice.I18nAspect;
import com.github.benmanes.caffeine.cache.Caffeine;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

@Configuration("cacheConfiguration")
@Slf4j
@EnableCaching
public class CacheConfiguration {
    public static final String SYSTEM_LEVEL_BIZ_CACHE = "SYS_BZ:META";
    public static final String BIZ_META = "biz:meta";
    public static final String TRANSIENT_BIZ_META_CACHE_MANAGER = "transientBizMetaCacheManager";

    public static final String BIZ_META_KEY_GENERATOR = "bizMetaCacheKeyGenerator";
    /**
     * 带语言的meta缓存key generator
     */
    public static final String I18N_META_KEY_GENERATOR = "i18nMetaCacheKeyGenerator";
    public static final String TENANT_IGNORE_META_CACHE_KEY_GENERATOR = "tenantIgnoreMetaCacheKeyGenerator";

    /**
     * 一个2分钟的内存缓存，不支持pub-sub同步，应用于需要少数短暂缓存的场景，支持缓存空值
     */
    static class MemoryCache extends ConcurrentMapCache{
        public MemoryCache(String name, boolean allowNullValues) {
            super(name, Caffeine.newBuilder()
                    .expireAfterWrite(2, TimeUnit.MINUTES)
                    .maximumSize(1000)
                    .build().asMap(), allowNullValues);
        }

        @Override
        public void evict(Object key) {
            if("*".equals(key)){
                super.getNativeCache().keySet().forEach(cacheKey -> {
                    if(isSameTenant(cacheKey)){
                        super.evict(cacheKey);
                    }
                });
            }else {
                super.evict(key);
            }
        }

        private boolean isSameTenant(Object key) {
            if (key == null) {
                return false;
            }
            Long tenantId = TenantContextHolder.getTenantIdExt();
            return key.toString().startsWith(tenantId.toString() + ":");
        }
    }
    /**
     * 只有1分钟有效期的短暂缓存, 用于保存BizMeta的缓存
     * @return
     */
    @Bean(TRANSIENT_BIZ_META_CACHE_MANAGER)
    public CacheManager transientBizMetaCacheManager() {
        return new ConcurrentMapCacheManager() {
            @Override
            protected Cache createConcurrentMapCache(final String name) {
                return new MemoryCache(name, true);
            }
        };
    }

    @Bean(BIZ_META_KEY_GENERATOR)
    public KeyGenerator keyGenerator() {
        return (target, method, params) -> {
            StringBuilder sb = new StringBuilder();
            sb.append(TenantContextHolder.getTenantId());
            sb.append(":");
            sb.append(target.getClass().getSimpleName());
            sb.append(".");
            sb.append(method.getName());
            sb.append(String.format("(%d)", params!=null ? params.length: 0));
            sb.append("[");
            sb.append(Arrays.deepHashCode(params));
            sb.append("]");
            return sb.toString();
        };
    }

    @Bean(I18N_META_KEY_GENERATOR)
    public KeyGenerator i18nKeyGenerator() {
        return (target, method, params) -> {
            StringBuilder sb = new StringBuilder();
            sb.append(TenantContextHolder.getTenantId());
            sb.append(":");
            sb.append(target.getClass().getSimpleName());
            sb.append(".");
            sb.append(method.getName());
            sb.append(String.format("(%d)", params!=null ? params.length: 0));
            sb.append("[");
            sb.append(Arrays.deepHashCode(params));
            sb.append("]");
            String lang = I18nAspect.getHeaderLanguage();
            return "i18nAspect:" + lang + "_" + sb.toString();
        };
    }

    @Bean(TENANT_IGNORE_META_CACHE_KEY_GENERATOR)
    public KeyGenerator tenantIgnoreMetaCacheKeyGenerator() {
        return (target, method, params) -> {
            StringBuilder sb = new StringBuilder();
            sb.append(target.getClass().getSimpleName());
            sb.append(".");
            sb.append(method.getName());
            sb.append("[");
            sb.append(Arrays.deepHashCode(params));
            sb.append("]");
            return sb.toString();
        };
    }

}
