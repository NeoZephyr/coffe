package com.convertlab.macore.mamgt.misc.service;

import com.convertlab.macore.mamgt.cdp.model.entity.LegacyUdoTableMeta;

import java.util.List;
import java.util.Map;

/**
 * All rights Reserved, Designed By ConvertLab
 * Author: johnny.chen
 * Date: 2024/2/24
 * Description: LegacyMetaLoader accessor with L2RedisBackendCache enabled
 * Copyright (C) 2024 www.convertlab.com
 */
public interface CachedLegacyMetaLoader {
    public List<Map<String, Object>> loadCustomizedEventGroup();
    public List<Map<String, Object>> loadCustomerPluginEventGroups();

    public List<Map<String, Object>> loadCustomerSourceMeta();
    public Map<String, Map<String, Object>> loadCustomerMetaLayout();
    public LegacyUdoTableMeta getLegacyUdoObjId(String tableName);
    public List<Map<String, Object>> loadCustomerPropsMeta();
}
