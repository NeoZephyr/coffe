package com.convertlab.macore.mamgt.misc.client;

import com.convertlab.data.job.core.biz.model.BizJobRunResult;
import com.convertlab.foundation.api.gdm.pattern.dto.DefineGdmModelRequest;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.macore.mamgt.cdp.meta.common.utils.ProfileMetaHelper;
import com.convertlab.macore.mamgt.cdp.meta.model.dto.foundation.ProfileDefPattern;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.Map;

@FeignClient(
        name = "gdmModelFeignClient",
        url = "${gdmMetaService.serverUrl}"
)
public interface GdmModelFeignClient {

    @PostMapping("/v1/gdm/def/models/{profileName}")
    GdmModelDto addProfileModel(@Nonnull @PathVariable("profileName") String profileName,
                                @Nonnull @RequestBody DefineGdmModelRequest request);

    @PutMapping("/v1/gdm/def/models/{profileName}")
    GdmModelDto updateProfileModel(@Nonnull @PathVariable("profileName") String profileName,
                                   @Nonnull @RequestBody DefineGdmModelRequest request);

    @DeleteMapping("/v1/gdm/def/models/{profileName}?bizInfo=DELETE_PROFILE_META&deleteData=true")
    BizJobRunResult deleteProfileModel(@Nonnull @PathVariable("profileName") String profileName);


    @PostMapping("/v1/gdm/def/models/{profileName}/events/{eventName}")
    GdmModelDto addEventToProfileModel(@Nonnull @PathVariable("profileName") String profileName,
                                       @Nonnull @PathVariable("eventName") String eventName,
                                       @Nonnull @RequestBody GdmModelDto.Field... fields);

    @DeleteMapping("/v1/gdm/def/models/{profileName}/events/{eventName}")
    boolean deleteEventOfProfileModel(@Nonnull @PathVariable("profileName") String profileName,
                                      @Nonnull @PathVariable("eventName") String eventName,
                                      @RequestParam("delete_data") boolean deleteData);

    @PostMapping("/v1/gdm/def/models/{profileName}/attributed-segment-families/{segmentFamilyEntityName}")
    GdmModelDto addAttributedSegmentsToProfileModel(@Nonnull @PathVariable("profileName") String profileName,
                                                    @Nonnull @PathVariable("segmentFamilyEntityName") String segmentFamilyEntityName,
                                                    @Nonnull @RequestBody GdmModelDto.Field... fields);

    @DeleteMapping("/v1/gdm/def/models/{profileName}/attributed-segment-families/{segmentFamilyEntityName}")
    boolean deleteAttributedSegmentsOfProfileModel(@Nonnull @PathVariable("profileName") String profileName,
                                                   @Nonnull @PathVariable("segmentFamilyEntityName") String segmentFamilyEntityName,
                                                   @RequestParam("delete_data") boolean deleteData);


    @PutMapping("/v1/gdm/def/entities/{entityName}")
    boolean upsertFieldsToEntity(@Nonnull @PathVariable("entityName") String entityName,
                                 @Nonnull @RequestBody Map<String, Object> request);

    @PostMapping("/v1/gdm/def/relationships")
    String addRelationshipsToEntity(@Nonnull @RequestBody ProfileMetaHelper.Relationships relationships);

    @DeleteMapping("/v1/gdm/def/relationships/{entityName}/{relationshipName}")
    boolean deleteRelationshipsFromEntity(@Nonnull @PathVariable("entityName") String entityName,
                                          @Nonnull @PathVariable("relationshipName") String relationshipName);

    @GetMapping("/v1/gdm/def/patterns")
    List<ProfileDefPattern> getProfileDefPattern();
}
