package com.convertlab.macore.mamgt.common.utils;

import com.convertlab.foundation.api.gdm.pattern.dto.DefineGdmModelRequest;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto;
import com.convertlab.foundation.library.model.GenericErrorInfo;
import com.convertlab.foundation.library.model.vo.GenericErrorResponse;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.mamgt.cdp.meta.model.dto.common.FieldWithOp;
import com.convertlab.macore.mamgt.cdp.BaseRetrievalData;
import com.convertlab.macore.mamgt.cdp.BaseRetrievalRequest;
import com.convertlab.macore.mamgt.common.enums.FieldOpEnum;
import com.fasterxml.jackson.core.type.TypeReference;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.util.CollectionUtils;

import java.io.Serializable;
import java.net.URLDecoder;
import java.text.NumberFormat;
import java.util.*;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.convertlab.foundation.library.constant.CommonErrors.GENERAL_ERROR;

@Slf4j
public class CommonHelper {
    private static final String LOG_PREFIX = "<ma-mgt> <CommonHelper>";
    public static final String QUERY_GDM_DEF_MODEL = "/v1/gdm/def/models";
    public static final String QUERY_GDM_DEF_PATTERNS = "/v1/gdm/def/patterns";
    public static final String EDIT_GDM_ENTITY_ATTR = "/v1/gdm/def/entities";
    public static final String EDIT_GDM_ENTITY_RELATION = "/v1/gdm/def/relationships";
    private static final Pattern UNDERLINE_COMPILE = Pattern.compile("_(\\w)");

    /**
     * 深拷贝
     *
     * @param object   要复制的对象
     * @param typeInfo 复制对象类型
     * @param <T>
     * @return
     */
    public static <T> T serializationClone(T object, TypeReference<T> typeInfo) {
        String json = JsonUtils.instanceOfDto().obj2Json(object);
        if (json == null) {
            return null;
        }
        try {
            return JsonUtils.dtoMapper().readValue(json, typeInfo);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 深拷贝
     *
     * @param object 要复制的对象
     * @param <T>
     * @return 拷贝对象
     */
    public static <T> T serializationClone(T object) {
        String json = JsonUtils.instanceOfDto().obj2Json(object);
        if (json == null) {
            return null;
        }
        try {
            return (T) JsonUtils.dtoMapper().readValue(json, object.getClass());
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 深拷贝(实现了Serializable接口的对象可以使用此拷贝)
     *
     * @param object 实现了Serializable接口的对象
     * @param <T>
     * @return 拷贝对象
     */
    public static <T extends Serializable> T serializableClone(T object) {
        return SerializationUtils.clone(object);
    }

    /**
     * 判断entity名称相等
     *
     * @param name1 字符串1
     * @param name2 字符串2
     * @return
     */
    public static Boolean checkNameEqual(String name1, String name2) {
        if (StringUtils.isBlank(name1) && StringUtils.isBlank(name2)) {
            return true;
        }
        if (StringUtils.isBlank(name1) || StringUtils.isBlank(name2)) {
            return false;
        }
        name1 = NamingUtils.toLowerUnderScoreCase(name1);
        name2 = NamingUtils.toLowerUnderScoreCase(name2);
        return name1.equals(name2);
    }

    /**
     * 判断字符串相等
     *
     * @param str1 字符串1
     * @param str2 字符串2
     * @return
     */
    public static Boolean checkStringEqual(String str1, String str2) {
        return checkStringEqual(str1, str2, false);
    }

    /**
     * 判断字符串相等
     *
     * @param str1       字符串1
     * @param str2       字符串2
     * @param ignoreCase 是否忽略大小写
     * @return
     */
    public static Boolean checkStringEqual(String str1, String str2, Boolean ignoreCase) {
        if (str1 == null && str2 == null) {
            return true;
        }
        if (str1 == null || str2 == null) {
            return false;
        }
        if (ignoreCase != null && ignoreCase) {
            return str1.equalsIgnoreCase(str2);
        }
        return str1.equals(str2);
    }

    /**
     * 如果字符串包含[],取[]前的字符串，eg: name[111] 取 name
     *
     * @param str 包含[]的字符串eg: name[111]
     * @return []前的字符串
     */
    public static String findNameFromFieldWithBracket(String str) {
        return findFirstFromStringByRegex(str, "(?<=(.?))(.+)(?=(\\[.*\\]))");
    }

    /**
     * 获取字符串中第一个括号内的内容
     *
     * @param str 字符串
     * @return 提取到的字符串
     */
    public static String findFirstFromBracket(String str) {
        return findFirstFromStringByRegex(str, "(?<=\\[)(.+?)(?=\\])");
    }

    /**
     * 获取字符串中所有括号内的内容
     *
     * @param str 字符串
     * @return 提取到的字符串列表
     */
    public static List<String> findAllFromBracket(String str) {
        return findAllFromStringByRegex(str, "(?<=\\[)(.+?)(?=\\])");
    }

    /**
     * 根据正则获取所有匹配正则表达式的字符串
     *
     * @param str   字符串
     * @param regex 正则表达式
     * @return 提取到的字符串列表
     */
    public static List<String> findAllFromStringByRegex(String str, String regex) {
        List<String> list = new ArrayList<>();
        if (StringUtils.isBlank(str)) {
            return list;
        }
        // 现在创建 matcher 对象
        Matcher matcher = Pattern.compile(regex).matcher(str);
        //获取括号里面的内容
        while (matcher.find()) {
            list.add(matcher.group());
        }
        return list;
    }

    /**
     * 根据正则获取第一个匹配正则表达式的字符串
     *
     * @param str   字符串
     * @param regex 正则表达式
     * @return 提取到的字符串
     */
    public static String findFirstFromStringByRegex(String str, String regex) {
        if (StringUtils.isBlank(str)) {
            return null;
        }
        // 现在创建 matcher 对象
        Matcher matcher = Pattern.compile(regex).matcher(str);
        //获取括号里面的内容
        if (matcher.find()) {
            return matcher.group();
        }
        return null;
    }

    /**
     * 当前对象和根对象关系对象
     */
    public static class BootRefMap {
        private int lastLevel = 0;
        private Map<String, Set<String>> curr_boot_level_map = new HashMap<>();

        /**
         * 获取当前层级的key对应的根key
         *
         * @param level      层级，从0开始 （每个层级方一类数据，不要混乱放）
         * @param currentKey 当前key
         * @return
         */
        public Set<String> getParentRef(int level, String currentKey) {
            return curr_boot_level_map.get(level + "#" + currentKey);
        }

        /**
         * 根据层级添加当前key和父key的关系
         *
         * @param level      层级，从0开始 （每个层级方一类数据，不要混乱放）
         * @param currentKey 当前key
         * @param parentKey  父key
         */
        public void addRef(int level, String currentKey, String parentKey) {
            //获取当前id对应的根id
            Set<String> parentKeys = getParentRef(level, currentKey);
            if (parentKeys == null) {
                parentKeys = new HashSet<>();
            }
            parentKeys.add(parentKey);
            curr_boot_level_map.put(level + "#" + currentKey, parentKeys);
            if (level > lastLevel) {
                lastLevel = level;
            }
        }

        /**
         * 从上级开始一级级向上取到根节点数据
         *
         * @param level      层级  （每个层级方一类数据，不要混乱放）
         * @param currentKey 需要找根节点的key
         * @return 找到的跟层级列表
         */
        public Set<String> getBootRefs(int level, String currentKey) {
            Set<String> parentRefs = new HashSet<>();
            parentRefs.add(currentKey);
            if (level > lastLevel) {
                level = lastLevel;
            }
            for (int index = level; index >= 0; index--) {
                Set<String> refSet = new HashSet<>();
                for (String parentRef : parentRefs) {
                    Set<String> pRefs = getParentRef(index, parentRef);
                    if (CollectionUtils.isEmpty(pRefs)) {
                        //如果父对象是空，说明本层关系不需要再往上找了，直接返回找到的最新的
                        return parentRefs;
                    }
                    refSet.addAll(pRefs);
                }
                parentRefs.clear();
                parentRefs = refSet;
            }
            return parentRefs;
        }
    }

    public static Map<String, Object> buildMessage(BaseRetrievalData baseRetrievalData, BaseRetrievalRequest batchRetrievalTaskRequest, String listId, String requestId) {
        Map<String, Object> message = new HashMap<>(16);
        message.put("profileName", baseRetrievalData.getProfileName());
        message.put("segmentId", Collections.singletonList(listId));
        message.put("taskId", requestId);
        message.put("transData", batchRetrievalTaskRequest.getTransData());
        message.put("dataTopic", batchRetrievalTaskRequest.getDataTopic());
        message.put("messageKey", batchRetrievalTaskRequest.getMessageKey());
        message.put("rows", baseRetrievalData.getRows());
        message.put("totalRecords", baseRetrievalData.getTotalRecords());
        message.put("batchSize", baseRetrievalData.getTotalRecords());
        return message;
    }

    /**
     * 判断map不是空
     *
     * @param map map对象
     * @return 是否有值
     */
    public static boolean checkMapIsNotEmpty(Map map) {
        return !checkMapIsEmpty(map);
    }

    /**
     * 判断map是否是空（包含null）
     *
     * @param map map对象
     * @return 是否为空
     */
    public static boolean checkMapIsEmpty(Map map) {
        return map == null || map.isEmpty();
    }

    /**
     * 判断字符串是否包含非法字符
     *
     * @param name 字符串
     * @return 是否包含非法字符
     */
    public static boolean hasInvalidCharacter(String name) {
        if (name.contains("--")) {
            return true;
        }
        if (name.startsWith(" ") || name.endsWith(" ")) {
            return true;
        }
        Pattern pattern = Pattern.compile("[^?:\"<>？：《》“”]+");
        Matcher matcher = pattern.matcher(name);
        if (!matcher.find()) {
            return true;
        }
        return false;
    }

    /**
     * 从map内取出Object类型的值
     *
     * @param map map对象
     * @param key key名称
     * @return 结果值
     */
    public static Object getObjectFromMap(Map<String, Object> map, String key) {
        return getObjectFromMap(map, key, null);
    }

    /**
     * 从map内取出Object类型的值
     *
     * @param map        map对象
     * @param key        key名称
     * @param defaultVal 默认值
     * @return 结果值
     */
    public static Object getObjectFromMap(Map<String, Object> map, String key, Object defaultVal) {
        if (map == null || map.isEmpty()) {
            return defaultVal;
        }
        Object o = map.get(key);
        if (o == null) {
            return defaultVal;
        }
        return o;
    }

    /**
     * 从map内取出String类型的值
     *
     * @param map map对象
     * @param key key名称
     * @return 结果值
     */
    public static String getStringFromMap(Map<String, Object> map, String key) {
        return getStringFromMap(map, key, null);
    }

    /**
     * 从map内取出String类型的值
     *
     * @param map        map对象
     * @param key        key名称
     * @param defaultVal 默认值
     * @return 结果值
     */
    public static String getStringFromMap(Map<String, Object> map, String key, String defaultVal) {
        Object obj = getObjectFromMap(map, key);
        if (obj == null) {
            return defaultVal;
        }
        return obj.toString();
    }


    /**
     * 从map内取出Int类型的值
     *
     * @param map map对象
     * @param key key名称
     * @return 结果值
     */
    public static Integer getIntegerFromMap(Map<String, Object> map, String key) {
        return getIntegerFromMap(map, key, null);
    }

    /**
     * 从map内取出Int类型的值
     *
     * @param map        map对象
     * @param key        key名称
     * @param defaultVal 默认值
     * @return 结果值
     */
    public static Integer getIntegerFromMap(Map<String, Object> map, String key, Integer defaultVal) {
        Object obj = getObjectFromMap(map, key);
        if (obj == null) {
            return defaultVal;
        }
        String valStr = obj.toString();
        if (valStr.contains(".")) {
            return new Double(valStr).intValue();
        }
        return Integer.parseInt(valStr);
    }

    /**
     * 从map内取出Long类型的值
     *
     * @param map map对象
     * @param key key名称
     * @return 结果值
     */
    public static Long getLongFromMap(Map<String, Object> map, String key) {
        return getLongFromMap(map, key, null);
    }

    /**
     * 从map内取出Long类型的值
     *
     * @param map        map对象
     * @param key        key名称
     * @param defaultVal 默认值
     * @return 结果值
     */
    public static Long getLongFromMap(Map<String, Object> map, String key, Long defaultVal) {
        Object obj = getObjectFromMap(map, key);
        if (obj == null) {
            return defaultVal;
        }
        return Long.parseLong(obj.toString());
    }

    /**
     * 从map内取出Double类型的值
     *
     * @param map map对象
     * @param key key名称
     * @return 结果值
     */
    public static Double getDoubleFromMap(Map<String, Object> map, String key) {
        return getDoubleFromMap(map, key, null);
    }

    /**
     * 从map内取出Double类型的值
     *
     * @param map        map对象
     * @param key        key名称
     * @param defaultVal 默认值
     * @return 结果值
     */
    public static Double getDoubleFromMap(Map<String, Object> map, String key, Double defaultVal) {
        Object obj = getObjectFromMap(map, key);
        if (obj == null) {
            return defaultVal;
        }
        return Double.parseDouble(obj.toString());
    }

    /**
     * 从map内取出Boolean类型的值
     *
     * @param map map对象
     * @param key key名称
     * @return 结果值
     */
    public static Boolean getBooleanFromMap(Map<String, Object> map, String key) {
        return getBooleanFromMap(map, key, null);
    }

    /**
     * 从map内取出Boolean类型的值
     *
     * @param map        map对象
     * @param key        key名称
     * @param defaultVal 默认值
     * @return 结果值
     */
    public static Boolean getBooleanFromMap(Map<String, Object> map, String key, Boolean defaultVal) {
        Object obj = getObjectFromMap(map, key);
        if (obj == null) {
            return defaultVal;
        }
        return Boolean.parseBoolean(obj.toString());
    }

    /**
     * 从map内取出List类型的值
     *
     * @param map map对象
     * @param key key名称
     * @return 结果值
     */
    public static <T> List<T> getListFromMap(Map<String, Object> map, String key) {
        return getListFromMap(map, key, null);
    }

    /**
     * 从map内取出List类型的值
     *
     * @param map        map对象
     * @param key        key名称
     * @param defaultVal 默认值
     * @return 结果值
     */
    public static <T> List<T> getListFromMap(Map<String, Object> map, String key, List<T> defaultVal) {
        Object obj = getObjectFromMap(map, key);
        if (obj == null) {
            return defaultVal;
        }
        return (List<T>) obj;
    }

    /**
     * 从map内取出map类型的值
     *
     * @param map map对象
     * @param key key名称
     * @return 结果值
     */
    public static Map<String, ?> getMapFromMap(Map<String, Object> map, String key) {
        return getMapFromMap(map, key, null);
    }

    /**
     * 从map内取出map类型的值
     *
     * @param map        map对象
     * @param key        key名称
     * @param defaultVal 默认值
     * @return 结果值
     */
    public static Map<String, ?> getMapFromMap(Map<String, Object> map, String key, Map<String, ?> defaultVal) {
        Object obj = getObjectFromMap(map, key);
        if (obj == null) {
            return defaultVal;
        }
        return (Map<String, ?>) obj;
    }

    /**
     * 获取非null值，为null取默认值
     *
     * @param val        值
     * @param defaultVal 默认值
     * @param <T>        数据类型
     * @return 非null值或者默认值
     */
    public static <T> T getNotNullVal(T val, T defaultVal) {
        if (val != null) {
            return val;
        }
        return defaultVal;
    }

    /**
     * 获取非null值，为null取默认值
     *
     * @param val        值
     * @param defaultVal 默认值
     * @return
     */
    public static String getNotNullStringVal(Object val, String defaultVal) {
        if (val != null) {
            return val.toString();
        }
        return defaultVal;
    }


    /**
     * 字符串下划线转驼峰
     *
     * @param str str
     * @return 驼峰类型的字符串
     * @author Mr.黄
     * @since 2023/8/31
     */
    public static String underlineToBump(String str) {
        Matcher matcher = UNDERLINE_COMPILE.matcher(str);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            matcher.appendReplacement(sb, matcher.group(1).toUpperCase());
        }
        matcher.appendTail(sb);
        return sb.toString();
    }

    /**
     * 从url查询参数内获取id筛选参数（eg:id[gt]=22 ; id[in]=22,33）
     *
     * @param queryString url查询参数(eg:name=aaa&id[gt]=22&sex=n)
     * @return id筛选参数
     */
    public static String getIdFilterFromQueryString(String queryString) {
        if (StringUtils.isBlank(queryString)) {
            return null;
        }
        if (queryString.contains("%")) {
            try {
                queryString = URLDecoder.decode(queryString, "UTF-8");
            } catch (Exception e) {
                log.error("{} getIdFilterFromQueryString URLDecoder fail .", LOG_PREFIX, e);
            }
        }
        String[] split = queryString.split("&");
        for (String param : split) {
            if (param.trim().startsWith("id[")) {
                return param.replaceAll(" ", "");
            }
        }
        return null;
    }

    /**
     * 解析 从url查询参数内获取id筛选参数
     *
     * @param idFilter id筛选参数
     * @return 解析后的对象
     */
    public static FieldWithOp<String> parseIdFilter(String idFilter) {
        if (StringUtils.isBlank(idFilter)) {
            return null;
        }
        String[] split = idFilter.split("=");
        String field = split[0];
        FieldOpEnum op = FieldOpEnum.EQUAL;
        if (field.contains("[in]")) {
            op = FieldOpEnum.IN;
        } else if (field.contains("[gt]")) {
            op = FieldOpEnum.GREATER_THAN;
        } else if (field.contains("[ge]")) {
            op = FieldOpEnum.GREATER_THAN_OR_EQUAL;
        } else if (field.contains("[lt]")) {
            op = FieldOpEnum.LESS_THAN;
        } else if (field.contains("[le]")) {
            op = FieldOpEnum.LESS_THAN_OR_EQUAL;
        }
        String val = split[1];
        if (op == FieldOpEnum.IN) {
            return new FieldWithOp<>("id", val.split(","));
        }
        return new FieldWithOp<>("id", op, val);
    }

    /**
     * 获取uuid
     *
     * @return uuid字符串
     */
    public static String getUUID() {
        return UUID.randomUUID().toString();
    }

    /**
     * 获取不带短杠的uuid
     *
     * @return uuid字符串
     */
    public static String getSimpleUUID() {
        return getUUID().replace("-", "");
    }

    /**
     * 获取requestId
     *
     * @return requestId
     */
    public static String getRequestId() {
        return MDC.get("x_request_id");
    }

    /**
     * 获取或创建requestId
     *
     * @return requestId
     */
    public static String getRequestIdWithCreate() {
        String requestId = getRequestId();
        if (StringUtils.isBlank(requestId)) {
            requestId = getSimpleUUID();
            MDC.put("x_request_id", requestId);
            log.info("{} getRequestIdWithCreate end . requestId is null , init requestId:{} .", LOG_PREFIX, requestId);
        }
        return requestId;
    }

    /**
     * 把字符串的值转为小写
     *
     * @param names
     */
    public static String[] stringToLowerCase(String... names) {
        if (names == null) {
            return null;
        }
        for (int index = 0; index < names.length; index++) {
            names[index] = NamingUtils.toLowerUnderScoreCase(names[index]);
        }
        return names;
    }

    /**
     * 把Field的值转为小写
     *
     * @param fields
     */
    public static void gdmFieldToLowerCase(List<GdmModelDto.Field> fields) {
        if (CollectionUtils.isEmpty(fields)) {
            return;
        }
        gdmFieldToLowerCase(fields.toArray(new GdmModelDto.Field[0]));
    }

    /**
     * 把Field的值转为小写
     *
     * @param fields
     */
    public static void gdmFieldToLowerCase(GdmModelDto.Field... fields) {
        if (fields == null) {
            return;
        }
        for (int index = 0; index < fields.length; index++) {
            String fieldName = fields[index].getFieldName();
            String newName = NamingUtils.toLowerUnderScoreCase(fieldName);
            fields[index].setFieldName(newName);
        }
    }

    public static void gdmModelRequestToLowerCase(DefineGdmModelRequest modelRequest) {
        if (modelRequest == null) {
            return;
        }
        modelRequest.setName(NamingUtils.toLowerUnderScoreCase(modelRequest.getName()));
        gdmFieldToLowerCase(modelRequest.getFields());
        GdmPatternDto.ProvisionProperties props = modelRequest.getProps();
        if (props == null) {
            return;
        }
        GdmPatternDto.ProfileEvent[] events = props.getEvents();
        if (events == null) {
            return;
        }
        for (GdmPatternDto.ProfileEvent event : events) {
            event.setEventId(NamingUtils.toLowerUnderScoreCase(event.getEventId()));
        }
    }


    /**
     * 执行和重试(默认重试间隔200毫秒)
     *
     * @param tryTimes    重试次数（不包含原本执行的一次，即如果为1，执行失败后再重试1次）
     * @param executeName 执行名称（用于区分执行的内容）
     * @param function    执行的方法（函数返回null或false或异常时会触发重试）
     * @param <T>         返回执行结果类型
     * @return 返回执行结果
     */
    public static <T> T executeAndReTry(Integer tryTimes, String executeName, Function<Integer, T> function) throws Exception {
        return executeAndReTry(200L, tryTimes, executeName, function);
    }

    /**
     * 执行和重试
     *
     * @param interval    重试间隔(毫秒)
     * @param tryTimes    重试次数（不包含原本执行的一次，即如果为1，执行失败后再重试1次）
     * @param executeName 执行名称（用于区分执行的内容）
     * @param function    执行的方法（函数返回null或false或异常时会触发重试）
     * @param <R>         返回执行结果类型
     * @return 返回执行结果
     */
    public static <R> R executeAndReTry(Long interval, Integer tryTimes, String executeName, Function<Integer, R> function) throws Exception {
        return executeAndReTry(interval, tryTimes, tryTimes + 1, executeName, function, null, null);
    }

    /**
     * 执行和重试
     *
     * @param interval       重试间隔(毫秒)
     * @param tryTimes       重试次数（不包含原本执行的一次，即如果为1，执行失败后再重试1次）
     * @param executeName    执行名称（用于区分执行的内容）
     * @param function       执行的方法
     * @param reTryCondition 判断需要重试的方法（返回true则需要重试）（默认：函数返回null或false或异常时会触发重试）
     * @param <R>            返回执行结果类型
     * @return 返回执行结果
     */
    public static <R> R executeAndReTry(Long interval, Integer tryTimes, String executeName, Function<Integer, R> function, Function<R, Boolean> reTryCondition) throws Exception {
        return executeAndReTry(interval, tryTimes, tryTimes + 1, executeName, function, reTryCondition, null);
    }

    private static <R> R executeAndReTry(Long interval, Integer totalTryTimes, Integer currentExecuteTimes, String executeName, Function<Integer, R> function, Function<R, Boolean> reTryCondition, Exception exception) throws Exception {
        int reTryTimes = 0;
        if (currentExecuteTimes != null) {
            reTryTimes = currentExecuteTimes;
        }
        reTryTimes--;
        if (reTryTimes < 0) {
            log.error("{} executeAndReTry stop . executeName:[{}] ,interval:{} ,totalTryTimes:{} ,currentTryTimes:{} end . ", LOG_PREFIX, executeName, interval, totalTryTimes, currentExecuteTimes, exception);
            if (exception != null) {
                throw exception;
            }
            return null;
        }
        R result = null;
        //剩余执行次数
        int remainingTimes = currentExecuteTimes - 1;
        try {
            result = function.apply(remainingTimes);
            if (reTryCondition == null) {
                //默认检验结果是否需要重试
                reTryCondition = resp -> resp == null || (resp instanceof Boolean && Boolean.FALSE == resp);
            }
            if (reTryCondition.apply(result)) {
                if (remainingTimes > 0) {
                    //最后一次
                    Thread.sleep(interval);
                }
                return executeAndReTry(interval, totalTryTimes, reTryTimes, executeName, function, reTryCondition, exception);
            } else {
                return result;
            }
        } catch (Exception e) {
            log.warn("{} executeAndReTry ing . have a error . executeName:[{}] ,interval:{} ,totalTryTimes:{} ,currentTryTimes:{} .", LOG_PREFIX, executeName, interval, totalTryTimes, currentExecuteTimes, e);
            if (remainingTimes > 0) {
                try {
                    Thread.sleep(interval);
                } catch (InterruptedException ex) {
                    log.error("{} executeAndReTry ing . have a error . executeName:[{}] ,interval:{} ,totalTryTimes:{} ,currentTryTimes:{} .", LOG_PREFIX, executeName, interval, totalTryTimes, currentExecuteTimes, ex);
                }
            }
            return executeAndReTry(interval, totalTryTimes, reTryTimes, executeName, function, reTryCondition, e);
        }
    }

    /**
     * 判断包含中文
     *
     * @param str 字符串
     * @return 是否包含中文
     */
    public static boolean checkContainsChinese(String str) {
        if (StringUtils.isBlank(str)) {
            return false;
        }
        String regex = "[\\u4e00-\\u9fa5]";
        return str.matches(".*" + regex + ".*");
    }

    /**
     * 带有Long属性转换为String
     *
     * @param obj       要转换的对象
     * @param typeClass 要转换属性类型列表
     * @return 转换后的对象
     */
    public static Object attrToString(Object obj, Class<?>... typeClass) {
        if (obj == null) {
            return null;
        }
        if (typeClass == null) {
            return obj;
        }
        if (BeanHelper.isBaseDataType(obj) && ArrayUtils.contains(typeClass, obj.getClass())) {
            return objectToString(obj);
        } else if (obj instanceof List) {
            listAttrValueToString((List) obj, typeClass);
            return obj;
        } else if (obj instanceof Map) {
            mapAttrValueToString((Map) obj, typeClass);
            return obj;
        }
        return obj;
    }

    public static void mapAttrValueToString(Map map, Class<?>... typeClass) {
        if (map == null || map.isEmpty()) {
            return;
        }
        for (Object mapKey : map.keySet()) {
            Object mapValue = map.get(mapKey);
            if (mapValue == null) {
                continue;
            }
            if (BeanHelper.isBaseDataType(mapValue) && ArrayUtils.contains(typeClass, mapValue.getClass())) {
                map.put(mapKey, objectToString(mapValue));
            } else if (mapValue instanceof List) {
                listAttrValueToString((List) mapValue, typeClass);
            } else if (mapValue instanceof Map) {
                mapAttrValueToString((Map) mapValue, typeClass);
            }
        }
    }

    public static void listAttrValueToString(List<?> list, Class<?>... typeClass) {
        if (CollectionUtils.isEmpty(list)) {
            return;
        }
        List newList = new ArrayList<>();
        for (Object listValue : list) {
            if (listValue == null) {
                newList.add(null);
                continue;
            }
            if (BeanHelper.isBaseDataType(listValue) && ArrayUtils.contains(typeClass, listValue.getClass())) {
                listValue = objectToString(listValue);
            } else if (listValue instanceof List) {
                listAttrValueToString((List) listValue, typeClass);
            } else if (listValue instanceof Map) {
                mapAttrValueToString((Map) listValue, typeClass);
            }
            newList.add(listValue);
        }
        list.clear();
        list.addAll(newList);
    }

    public static String objectToString(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Double) {
            //防止double变成科学计数法
            NumberFormat nf = NumberFormat.getInstance();
            nf.setGroupingUsed(false);
            return nf.format(value);
        }
        return value.toString();
    }

    /**
     * 构建错误响应对象
     *
     * @param code    错误码
     * @param message 错误信息
     * @return 错误响应对象
     */
    public static GenericErrorResponse buildErrorResponse(String code, String message) {
        String codeStr = code;
        String messageStr = message;
        if (StringUtils.isBlank(message)) {
            messageStr = "请求异常";
        }
        if (messageStr.length() > 100 && message.contains("description")) {
            String messageRegex = "(?<=(description\\\":\\\"))(.+?)(?=(\\\"))";
            messageStr = findFirstFromStringByRegex(message, messageRegex);
        }
        if (StringUtils.isBlank(code) && messageStr.length() > 100 && message.contains("\"code\"")) {
            String messageRegex = "(?<=(code\\\":\\\"))(.+?)(?=(\\\"))";
            messageStr = CommonHelper.findFirstFromStringByRegex(message, messageRegex);
        }
        if (StringUtils.isBlank(code)) {
            codeStr = GENERAL_ERROR.getCode();
        }
        GenericErrorResponse errorData = new GenericErrorResponse();
        GenericErrorInfo errorInfo = new GenericErrorInfo();
        errorInfo.setCode(codeStr);
        errorInfo.setMessage(messageStr);
        errorData.setError(errorInfo);
        return errorData;
    }
}
