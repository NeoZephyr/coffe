package com.convertlab.macore.channel.service;

import com.convertlab.macore.channel.mapping.ChannelInstanceMapping;
import com.convertlab.macore.channel.model.dto.ChannelInstanceDTO;
import com.convertlab.macore.channel.model.entity.ChannelInstance;
import com.convertlab.macore.channel.model.entity.ChannelInstanceExtField;
import com.convertlab.macore.channel.service.dao.ChannelInstanceExtFieldService;
import com.convertlab.macore.channel.service.dao.ChannelInstanceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author luck
 * @since 2023/4/28 10:19
 */
@Slf4j
@Service
public class CompositeChannelInstanceService {

    @Resource
    private ChannelInstanceExtFieldService channelInstanceExtFieldService;
    @Resource
    private ChannelInstanceService channelInstanceService;
    @Resource
    private ChannelInstanceMapping channelInstanceMapping;

    /**
     * 获取内容
     * <p>
     * 通过 ID
     *
     * @param channelType 渠道类型
     * @param id          内容 ID
     * @return {@link Optional<ChannelInstanceDTO>}
     * @author luck
     * @since 2022/10/19 18:45
     */
    public Optional<ChannelInstanceDTO> get(String channelType, Long id) {
        return batchWrap(
                channelInstanceService.lambdaQuery()
                        .eq(ChannelInstance::getChannelType, channelType)
                        .eq(ChannelInstance::getId, id)
                        .list()
        )
                .stream()
                .findFirst();
    }

    /**
     * 批量获取
     *
     * @param channelInstanceList 渠道例子集合
     * @return {@link List }<{@link ChannelInstanceDTO }>
     * @author luck
     * @apiNote 批量获取
     * @since 2023-05-16 15:04:45
     */
    public List<ChannelInstanceDTO> batchWrap(List<ChannelInstance> channelInstanceList) {
        channelInstanceList = Optional.ofNullable(channelInstanceList).orElse(new ArrayList<>());
        List<Long> uniqueIdList = channelInstanceList.stream().map(ChannelInstance::getUniqueId).collect(Collectors.toList());
        Map<Long, List<ChannelInstanceExtField>> channelInstanceExtFieldListMap = CollectionUtils.isEmpty(channelInstanceList)
                ? new HashMap<>()
                : channelInstanceExtFieldService.lambdaQuery()
                .in(ChannelInstanceExtField::getChannelInstanceUniqueId, uniqueIdList)
                .list()
                .stream()
                .collect(Collectors.groupingBy(ChannelInstanceExtField::getChannelInstanceUniqueId));

        return channelInstanceList
                .stream()
                .map(channelInstance ->
                        channelInstanceMapping.copyToDTO(
                                channelInstance,
                                channelInstanceExtFieldListMap.getOrDefault(channelInstance.getUniqueId(), new ArrayList<>()))
                ).collect(Collectors.toList());
    }

}
