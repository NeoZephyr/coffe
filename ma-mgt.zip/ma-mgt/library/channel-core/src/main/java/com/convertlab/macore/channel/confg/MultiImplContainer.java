package com.convertlab.macore.channel.confg;

import com.convertlab.foundation.library.spring.BaseMultiImplContainer;
import com.convertlab.macore.channel.service.meta.IChannelSendMetaService;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author luck
 * @since 2024/3/18 16:45
 */
@Slf4j
@Getter
@Component
public class MultiImplContainer extends BaseMultiImplContainer {

    private final Map<String, IChannelSendMetaService> sendMetaServiceMap = new ConcurrentHashMap<>();

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        initMultiImpl(event, IChannelSendMetaService.class, sendMetaServiceMap);
    }
}
