package com.convertlab.macore.channel.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.channel.model.entity.ChannelQuotaPool;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 租户虚拟池表 Mapper 接口
 * </p>
 *
 * @author wenping
 * @since 2022-11-07
 */
@Mapper
public interface ChannelQuotaPoolMapper extends BaseMapper<ChannelQuotaPool> {

}
