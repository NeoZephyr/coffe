package com.convertlab.macore.channel.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.channel.model.entity.ChannelTemplate;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface ChannelTemplateMapper extends BaseMapper<ChannelTemplate> {

}
