package com.convertlab.macore.channel.mapping;

import com.convertlab.channel.common.model.content.ChannelTemplateExtFieldDTO;
import com.convertlab.channel.common.model.content.CommonExtField;
import com.convertlab.macore.channel.model.entity.ChannelTemplateExtField;
import org.mapstruct.*;

import java.util.List;

/**
 * @author luck
 * @since 2023/4/20 11:18
 */
@Mapper(componentModel = "spring",
        collectionMappingStrategy = CollectionMappingStrategy.ADDER_PREFERRED,
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface ChannelExtFieldMapping {


    @Mapping(target = "templateUniqueId", expression = "java((Long)commonExtField.getFk())")
    ChannelTemplateExtFieldDTO getTemplateExtField(CommonExtField commonExtField);


}
