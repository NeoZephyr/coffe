package com.convertlab.macore.channel.mapping;

import com.convertlab.macore.channel.model.dto.ChannelPluginVersionWithMessagingTypeDTO;
import org.mapstruct.CollectionMappingStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.ReportingPolicy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author luck
 * @apiNote ChannelMessagingType 转换
 * @since 2022/11/22 16:06
 */
@Mapper(componentModel = "spring",
        collectionMappingStrategy = CollectionMappingStrategy.ADDER_PREFERRED,
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        unmappedTargetPolicy = ReportingPolicy.IGNORE,
        imports = {Optional.class, ArrayList.class, Collectors.class, HashMap.class,}
)
public interface ChannelMessagingTypeMapping {

    ChannelPluginVersionWithMessagingTypeDTO transformToDTO(com.convertlab.channel.model.dto.channeltype.ChannelPluginVersionWithMessagingTypeDTO channelPluginVersionWithMessagingTypeDTO);
}
