package com.convertlab.macore.channel.mapping;

import com.convertlab.macore.channel.model.dto.ChannelInstanceDTO;
import com.convertlab.macore.channel.model.entity.ChannelInstance;
import com.convertlab.macore.channel.model.entity.ChannelInstanceExtField;
import org.mapstruct.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author luck
 * @since 2022/11/22 16:06
 */
@Mapper(componentModel = "spring",
        collectionMappingStrategy = CollectionMappingStrategy.ADDER_PREFERRED,
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        unmappedTargetPolicy = ReportingPolicy.IGNORE,
        imports = {Optional.class, ArrayList.class, Collectors.class, HashMap.class}
)
public interface ChannelInstanceMapping {

    @Mapping(target = "extFieldList", source = "channelInstanceExtFieldList")
    ChannelInstanceDTO copyToDTO(ChannelInstance channelInstance, List<ChannelInstanceExtField> channelInstanceExtFieldList);
}
