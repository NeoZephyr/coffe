package com.convertlab.macore.channel.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.channel.model.entity.ChannelInstance;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author luck
 * @since 2023/4/20 13:58
 */
@Mapper
public interface ChannelInstanceMapper extends BaseMapper<ChannelInstance> {

}
