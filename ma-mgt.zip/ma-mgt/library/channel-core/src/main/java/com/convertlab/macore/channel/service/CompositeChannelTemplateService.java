package com.convertlab.macore.channel.service;

import com.convertlab.channel.common.model.content.ChannelTemplateDTO;
import com.convertlab.macore.channel.mapping.ChannelTemplateMapping;
import com.convertlab.macore.channel.model.entity.ChannelTemplate;
import com.convertlab.macore.channel.model.entity.ChannelTemplateExtField;
import com.convertlab.macore.channel.service.dao.ChannelTemplateExtFieldService;
import com.convertlab.macore.channel.service.dao.ChannelTemplateService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author luck
 * @apiNote 描述
 * @since 2024/3/18 15:38
 */
@Slf4j
@Service
public class CompositeChannelTemplateService {

    @Resource
    private ChannelTemplateExtFieldService channelTemplateExtFieldService;
    @Resource
    private ChannelTemplateService channelTemplateService;
    @Resource
    private ChannelTemplateMapping channelTemplateMapping;

    public List<ChannelTemplateDTO> batchGet(String channelType, List<Long> idList) {
        if (CollectionUtils.isEmpty(idList)) {
            return new ArrayList<>();
        }
        Map<Long, ChannelTemplate> channelTemplateMap = channelTemplateService.batchGetMap(channelType, idList);

        if (CollectionUtils.isEmpty(channelTemplateMap)) {
            return new ArrayList<>();
        }

        return batchWrap(idList.stream().map(channelTemplateMap::get).collect(Collectors.toList()));

    }

    /**
     * 批量获取
     *
     * @param channelTemplateList 渠道模板集合
     * @return {@link List }<{@link ChannelTemplateDTO }>
     * @author luck
     * @apiNote 批量获取
     * @since 2022-11-03 13:07:14
     */
    public List<ChannelTemplateDTO> batchWrap(List<ChannelTemplate> channelTemplateList) {
        channelTemplateList = Optional.ofNullable(channelTemplateList).orElse(new ArrayList<>());
        List<Long> uniqueIdList = channelTemplateList.stream().map(ChannelTemplate::getUniqueId).collect(Collectors.toList());
        Map<Long, List<ChannelTemplateExtField>> channelTemplateExtFieldListMap = CollectionUtils.isEmpty(channelTemplateList)
                ? new HashMap<>()
                : channelTemplateExtFieldService.lambdaQuery()
                .in(ChannelTemplateExtField::getTemplateUniqueId, uniqueIdList)
                .list()
                .stream()
                .collect(Collectors.groupingBy(ChannelTemplateExtField::getTemplateUniqueId));

        return channelTemplateList
                .stream()
                .map(channelTemplate ->
                        channelTemplateMapping.copyTemplateToDTO(
                                channelTemplate,
                                channelTemplateExtFieldListMap.getOrDefault(channelTemplate.getUniqueId(), new ArrayList<>()))
                ).collect(Collectors.toList());
    }
}
