package com.convertlab.macore.channel.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.channel.model.entity.ChannelTemplateExtField;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author huangtao
 */
@Mapper
public interface ChannelTemplateExtFieldMapper extends BaseMapper<ChannelTemplateExtField> {

}
