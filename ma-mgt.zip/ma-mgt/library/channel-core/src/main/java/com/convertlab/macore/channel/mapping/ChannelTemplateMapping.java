package com.convertlab.macore.channel.mapping;

import com.convertlab.channel.common.consts.enums.StatusEnum;
import com.convertlab.channel.common.model.content.ChannelTemplateDTO;
import com.convertlab.macore.channel.model.entity.ChannelTemplate;
import com.convertlab.macore.channel.model.entity.ChannelTemplateExtField;
import org.mapstruct.*;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring",
        collectionMappingStrategy = CollectionMappingStrategy.ADDER_PREFERRED,
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        unmappedTargetPolicy = ReportingPolicy.IGNORE,
        imports = {
                Optional.class,
                ArrayList.class,
                Collectors.class,
                HashMap.class,
                StatusEnum.class,
                Instant.class,
                Objects.class,
        }
)
public interface ChannelTemplateMapping {

    @Mapping(target = "extFieldList", source = "channelTemplateExtFieldList")
    ChannelTemplateDTO copyTemplateToDTO(ChannelTemplate channelTemplate, List<ChannelTemplateExtField> channelTemplateExtFieldList);
}