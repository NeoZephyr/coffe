package com.convertlab.macore.channel.service;

import com.convertlab.channel.client.ChannelPluginInstanceClient;
import com.convertlab.channel.common.utils.TryCatchHelper;
import com.convertlab.macore.channel.mapping.ChannelMessagingTypeMapping;
import com.convertlab.macore.channel.model.dto.ChannelPluginVersionWithMessagingTypeDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 渠道插件实例聚合逻辑
 *
 * @author luck
 * @apiNote 渠道插件实例聚合逻辑
 * @since 2024-04-19 14:20:32
 */
@Slf4j
@Service
public class CompositeChannelPluginInstanceService {

    @Resource
    private ChannelPluginInstanceClient channelPluginInstanceClient;
    @Resource
    private ChannelMessagingTypeMapping channelMessagingTypeMapping;

    /**
     * 获取租户可用的插件下 messagingType 列表
     *
     * @return {@link List }<{@link ChannelPluginVersionWithMessagingTypeDTO }>
     * @author luck
     * @apiNote 获取租户可用的插件下 messagingType 列表
     * @see List< ChannelPluginVersionWithMessagingTypeDTO >
     * @since 2024-04-19 14:20:45
     */
    public List<ChannelPluginVersionWithMessagingTypeDTO> getPluginVersionWithMessagingTypeList() {
        return TryCatchHelper.supplier(
                        () -> channelPluginInstanceClient.getChannelPluginVersionWithMessagingTypeDTOList(),
                        e -> {
                            log.error("CompositeChannelPluginInstanceService_getMessagingTypeList exception: ", e);
                            return new ArrayList<com.convertlab.channel.model.dto.channeltype.ChannelPluginVersionWithMessagingTypeDTO>();
                        }
                )
                .stream()
                .map(channelMessagingTypeMapping::transformToDTO)
                .collect(Collectors.toList());
    }

}
