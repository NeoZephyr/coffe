package com.convertlab.macore.channel.service;

import com.convertlab.macore.channel.model.entity.ChannelQuotaPool;
import com.convertlab.macore.channel.model.entity.ChannelQuotaPoolStat;
import com.convertlab.macore.channel.service.dao.ChannelQuotaPoolService;
import com.convertlab.macore.channel.service.dao.ChannelQuotaPoolStatService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Nonnull;
import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 租户下 quota 组合逻辑
 *
 * @author luck
 * @since 2023/7/19 12:32
 */
@Slf4j
@Service
public class CompositeChannelQuotaService {

    @Resource
    private ChannelQuotaPoolStatService channelQuotaPoolStatService;
    @Resource
    private ChannelQuotaPoolService channelQuotaPoolService;


    /**
     * 推断 poolId
     *
     * @param channelType 渠道类型
     * @param pluginId    插件 id
     * @param tunnelId    通道 ID
     * @return {@link Long }
     * @author luck
     * @apiNote 推断 poolId
     * @see String
     * @see Long
     * @see Long
     * @see Long
     * @since 2023-07-12 14:25:44
     */
    public Long deducePoolId(@Nonnull String channelType, @Nonnull Long pluginId, String vendorCode, Long tunnelId) {
        List<ChannelQuotaPool> list = channelQuotaPoolService.lambdaQuery()
                .eq(ChannelQuotaPool::getChannelType, channelType)
                .eq(ChannelQuotaPool::getPluginId, pluginId)
                .list();
        List<String> poolStrategyList = list.stream().map(ChannelQuotaPool::getStrategy).distinct().collect(Collectors.toList());
        if (org.springframework.util.CollectionUtils.isEmpty(poolStrategyList)) {
            log.warn("ChannelQuotaPoolService_deducePoolId not pool strategy, channelType: {}, pluginId: {}, tunnelId: {}", channelType, pluginId, tunnelId);
            return null;
        }
        if (poolStrategyList.size() > 1) {
            log.warn("ChannelQuotaPoolService_deducePoolId exist multiple pool strategy, size: {}, channelType: {}, pluginId: {}, tunnelId: {}", poolStrategyList.size(), channelType, pluginId, tunnelId);
        }
        String poolStrategy = poolStrategyList.get(0);
        log.info("ChannelQuotaPoolService_deducePoolId select poolStrategy: {}, channelType: {}, pluginId: {}, tunnelId: {}", poolStrategy, channelType, pluginId, tunnelId);
        List<Long> strategyPoolIdList = list.stream().filter(i -> Objects.equals(i.getStrategy(), poolStrategy)).map(ChannelQuotaPool::getId).collect(Collectors.toList());

        Map<Long, ChannelQuotaPoolStat> quotaPoolStatMap =
                CollectionUtils.isEmpty(strategyPoolIdList) ? new HashMap<>()
                        : channelQuotaPoolStatService.lambdaQuery().in(ChannelQuotaPoolStat::getPoolId, strategyPoolIdList)
                        .list()
                        .stream().collect(HashMap::new, (map, i) -> map.put(i.getPoolId(), i), HashMap::putAll);
        return list
                .stream()
                .filter(i -> Objects.nonNull(quotaPoolStatMap.get(i.getId())))
                .filter(i -> {
                    if (Objects.equals(poolStrategy, "by_tunnel")) {
                        return Objects.equals(i.getTunnelId(), tunnelId);

                    } else if (Objects.equals(poolStrategy, "by_vendor")) {
                        return Objects.equals(i.getVendorCode(), vendorCode);

                    } else {
                        return true;
                    }
                })
                .map(ChannelQuotaPool::getId)
                .findFirst()
                .orElse(null);
    }
}
