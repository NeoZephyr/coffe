package com.convertlab.macore.ad.controller.bff;

import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.macore.ad.service.biz.BizAdPlatformConfigService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Validated
// 不使用 @ViewController 的原因是 doc 生成
@RestController
@RequestMapping("/ad_mkt/callback")
@Tag(name = AdCallbackController.TAG)
@DataSourceLookup("main")
public class AdCallbackController {
    public static final String TAG = "广告营销 - 回调处理";

    @Resource
    private BizAdPlatformConfigService bizAdPlatformConfigService;

    @GetMapping("/authorized")
    @Operation(summary = "广告平台授权回调", description = "广告平台授权回调")
    public Map<String, String> authorizedCallback(HttpServletRequest httpServletRequest) throws IOException {
        log.info("authorizedCallback original url {}", httpServletRequest.getRequestURL().toString());
        Map<String, String> res = bizAdPlatformConfigService.authorizedCallback(httpServletRequest);
        log.info("<AdPlatformConfigController> redirect: {}" , res.get("url"));
        return res;
    }

}
