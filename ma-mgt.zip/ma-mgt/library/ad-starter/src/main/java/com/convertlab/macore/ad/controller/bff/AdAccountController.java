package com.convertlab.macore.ad.controller.bff;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.model.GenericPage;
import com.convertlab.foundation.library.model.vo.GenericListResponse;
import com.convertlab.foundation.library.model.vo.GenericPageResponse;
import com.convertlab.foundation.library.model.vo.GenericResponse;
import com.convertlab.macore.ad.model.dto.AdAccountDTO;
import com.convertlab.macore.ad.model.dto.AdAdvertiserAccountDTO;
import com.convertlab.macore.ad.service.biz.BizAdAccountService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 目前 account 信息来源于 广告主数据 + 授权账号数据的组合
 */
@Slf4j
@Validated
@RestController
@RequestMapping("/ad_mkt/accounts")
@Tag(name = AdAccountController.TAG)
@DataSourceLookup("main")
public class AdAccountController {
    public static final String TAG = "广告营销 - 广告（主）账号信息";

    @Resource
    private BizAdAccountService bizAdAccountService;

    @PostMapping("/batchGetAccounts")
    @Operation(summary = "批量获取广告平台账号", description = "批量获取广告平台账号")
    public GenericListResponse<AdAdvertiserAccountDTO> batchGetAccounts(@RequestParam("id") List<Long> idList) {
        return GenericListResponse.<AdAdvertiserAccountDTO>builder()
                .results(bizAdAccountService.batchGetAccounts(idList))
                .build();
    }

    @GetMapping
    @Operation(summary = "获取广告平台账号列表", description = "获取广告平台账号列表")
    public GenericPageResponse<AdAccountDTO> pageAccounts(@RequestParam(value = "key", required = false) String key,
                                                          @RequestParam(value = "status", required = false) List<String> statusList,
                                                          @RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum,
                                                          @RequestParam(value = "pageSize", required = false, defaultValue = "10") Integer pageSize) {

        Page<AdAccountDTO> page = bizAdAccountService.pageAccounts(key, statusList, pageNum, pageSize);

        return new GenericPageResponse<>(new GenericPage<>(
                Math.toIntExact(page.getTotal()),
                Math.toIntExact(page.getCurrent()),
                null,
                page.getRecords()
        ));
    }

    @PostMapping("/checkIsActiveAccount")
    @Operation(summary = "判断广告平台账号是否活跃", description = "判断广告平台账号是否活跃")
    public GenericResponse<Boolean> checkIsActiveAccount(@RequestParam("id") long id) {
        return GenericResponse.<Boolean>builder()
                .result(bizAdAccountService.checkIsActiveAccount(id))
                .build();
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "解绑删除指定广告平台账号", description = "解绑删除指定广告平台账号")
    public GenericResponse<Boolean> deleteAccount(@PathVariable("id") long id) {
        return GenericResponse.<Boolean>builder()
                .result(bizAdAccountService.deleteAccount(id))
                .build();
    }


}
