package com.convertlab.macore.ad.controller.bff;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.model.GenericPage;
import com.convertlab.foundation.library.model.vo.GenericPageResponse;
import com.convertlab.foundation.library.model.vo.GenericResponse;
import com.convertlab.macore.ad.common.utils.JacksonUtils;
import com.convertlab.macore.ad.model.dto.AdAudiencePushDTO;
import com.convertlab.macore.ad.model.dto.AdAudiencePushDetailIndexDTO;
import com.convertlab.macore.ad.model.dto.AdAudiencePushIndexDTO;
import com.convertlab.macore.ad.service.biz.BizAdAudiencePushService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@Slf4j
@Validated
@RestController
@RequestMapping("/ad_mkt/audience")
@Tag(name = AdAudienceController.TAG)
@DataSourceLookup("main")
public class AdAudienceController {
    public static final String TAG = "广告营销 - 人群管理";

    @Resource
    private BizAdAudiencePushService bizAdAudiencePushService;

    @PostMapping("/push/operate")
    @Operation(summary = "操作创建人群推包任务", description = "操作创建人群推包任务")
    public GenericResponse<AdAudiencePushDTO> operatePush(@RequestBody AdAudiencePushDTO adAudiencePushDTO) {
        log.info("AdAudienceController_operatePush req: {}", JacksonUtils.toJSONString(adAudiencePushDTO));
        AdAudiencePushDTO resAdAudiencePushDTO = bizAdAudiencePushService.operatePush(adAudiencePushDTO);
        log.info("AdAudienceController_operatePush res: {}", JacksonUtils.toJSONString(resAdAudiencePushDTO));
        return new GenericResponse<>(resAdAudiencePushDTO);
    }

    @PostMapping("/push/operate/{audiencePushId}")
    @Operation(summary = "对指定人群推包任务进行追加或减少操作", description = "对指定人群推包任务进行追加或减少操作")
    public GenericResponse<AdAudiencePushDTO> additionalOperatePushById(@PathVariable("audiencePushId") long audiencePushId,
                                                                        @RequestBody AdAudiencePushDTO adAudiencePushDTO) {
        log.info("AdAudienceController_operatePushById req: {}", JacksonUtils.toJSONString(adAudiencePushDTO));
        AdAudiencePushDTO resAdAudiencePushDTO = bizAdAudiencePushService.additionalOperatePushById(audiencePushId, adAudiencePushDTO);
        log.info("AdAudienceController_operatePushById res: {}", JacksonUtils.toJSONString(resAdAudiencePushDTO));
        return new GenericResponse<>(resAdAudiencePushDTO);
    }


    @PostMapping("/push/index")
    @Operation(summary = "人群推包任务列表", description = "人群推包任务列表")
    public GenericPageResponse<AdAudiencePushIndexDTO> pagePushIndex(@RequestParam(value = "segmentName", required = false) String segmentName,
                                                                     @RequestParam(value = "pushSegmentName", required = false) String pushSegmentName,
                                                                     @RequestParam(value = "pushSegmentId", required = false) String pushSegmentId,
                                                                     @RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum,
                                                                     @RequestParam(value = "pageSize", required = false, defaultValue = "10") Integer pageSize) {
        Page<AdAudiencePushIndexDTO> page = bizAdAudiencePushService.pagePushIndex(segmentName, pushSegmentName, pushSegmentId, pageNum, pageSize);
        return new GenericPageResponse<>(new GenericPage<>(
                Math.toIntExact(page.getTotal()),
                Math.toIntExact(page.getCurrent()),
                null,
                page.getRecords()
        ));
    }

    @GetMapping("/push/{audiencePushId}/index")
    @Operation(summary = "对应人群推包的明细列表", description = "对应人群推包的明细列表")
    public GenericPageResponse<AdAudiencePushDetailIndexDTO> pagePushDetailIndex(@PathVariable("audiencePushId") long audiencePushId,
                                                                                 @RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum,
                                                                                 @RequestParam(value = "pageSize", required = false, defaultValue = "10") Integer pageSize) {
        Page<AdAudiencePushDetailIndexDTO> page = bizAdAudiencePushService.pagePushDetailIndex(audiencePushId, pageNum, pageSize);
        return new GenericPageResponse<>(new GenericPage<>(
                Math.toIntExact(page.getTotal()),
                Math.toIntExact(page.getCurrent()),
                null,
                page.getRecords()
        ));
    }

    @DeleteMapping("/push/{audiencePushId}")
    @Operation(summary = "删除对应人群推包", description = "删除对应人群推包")
    public GenericResponse<Boolean> deletePush(@PathVariable("audiencePushId") Long audiencePushId) {
        return new GenericResponse<>(bizAdAudiencePushService.deletePush(audiencePushId));
    }

    @PostMapping("/push/{audiencePushId}/refresh")
    @Operation(summary = "刷新对应人群推包", description = "刷新对应人群推包")
    public GenericResponse<AdAudiencePushDTO> refreshPush(@PathVariable("audiencePushId") Long audiencePushId) {
        return new GenericResponse<>(bizAdAudiencePushService.refreshPush(audiencePushId));
    }

}
