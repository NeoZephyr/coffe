package com.convertlab.macore.ad.controller.bff;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.model.GenericPage;
import com.convertlab.foundation.library.model.vo.GenericPageResponse;
import com.convertlab.foundation.library.model.vo.GenericResponse;
import com.convertlab.macore.ad.model.dto.AdAppDeveloperInfoDTO;
import com.convertlab.macore.ad.service.biz.BizAdAppDeveloperInfoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * tms 配置广告平台
 *
 * @author zhile.chao
 * @version 1.0
 * @since 2024/9/11
 */
@Slf4j
@Validated
@RestController
@RequestMapping("/ad_mkt/developer")
@Tag(name = AdConfigController.TAG)
@DataSourceLookup("main")
public class AdAppDeveloperInfoController {

    @Resource
    private BizAdAppDeveloperInfoService bizAdAppDeveloperInfoService;

    @GetMapping
    @Operation(summary = "获取广告平台开发者列表", description = "获取广告平台开发者列表")
    public GenericPageResponse<AdAppDeveloperInfoDTO> pageDeveloperInfo(@RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum,
                                                                        @RequestParam(value = "pageSize", required = false, defaultValue = "10") Integer pageSize,
                                                                        @RequestParam(value = "adPlatformCode", required = false) String adPlatformCode) {
        Page<AdAppDeveloperInfoDTO> page = bizAdAppDeveloperInfoService.pageDeveloperInfo(pageNum, pageSize, adPlatformCode);
        return GenericPageResponse
                .<AdAppDeveloperInfoDTO>builder()
                .pagination(GenericPage
                        .<AdAppDeveloperInfoDTO>builder()
                        .total(Math.toIntExact(page.getTotal()))
                        .current(Math.toIntExact(page.getCurrent()))
                        .records(page.getRecords())
                        .build())
                .build();
    }

    @PostMapping
    @Operation(summary = "添加广告平台开发者", description = "添加广告平台开发者")
    public GenericResponse<AdAppDeveloperInfoDTO> create(@RequestBody AdAppDeveloperInfoDTO adAppDeveloperInfoDTO) {
        return GenericResponse.<AdAppDeveloperInfoDTO>builder().result(bizAdAppDeveloperInfoService.create(adAppDeveloperInfoDTO)).build();
    }

    @PutMapping("/{id}")
    @Operation(summary = "更新广告平台开发者", description = "更新广告平台开发者")
    public GenericResponse<AdAppDeveloperInfoDTO> update(@PathVariable("id") Long id,
                                                         @RequestBody AdAppDeveloperInfoDTO adAppDeveloperInfoDTO) {
        return GenericResponse.<AdAppDeveloperInfoDTO>builder().result(bizAdAppDeveloperInfoService.update(id, adAppDeveloperInfoDTO)).build();
    }

}
