package com.convertlab.macore.ad.controller.bff;

import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.model.vo.GenericResponse;
import com.convertlab.macore.ad.model.dto.AdPlatformRuntimeConfigDTO;
import com.convertlab.macore.ad.service.biz.BizAdPlatformConfigService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@Slf4j
@Validated
// 不使用 @ViewController 的原因是 doc 生成
@RestController
@RequestMapping("/ad_mkt/configs")
@Tag(name = AdConfigController.TAG)
@DataSourceLookup("main")
public class AdConfigController {
    public static final String TAG = "广告营销 - 配置信息";

    @Resource
    private BizAdPlatformConfigService bizAdPlatformConfigService;


    @GetMapping("/authorizedPlatformList")
    @Operation(summary = "获取支持授权的广告平台列表", description = "获取支持授权的广告平台列表")
    public GenericResponse<AdPlatformRuntimeConfigDTO> getRuntimeConfigs() {
        return new GenericResponse<>(bizAdPlatformConfigService.getRuntimeConfig());
    }
}
