package com.convertlab.macore.ad.autoconfigure;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


@Configuration
@ComponentScan("com.convertlab.macore.ad")
public class AdStarterAutoConfiguration {

}
