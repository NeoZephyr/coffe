package com.convertlab.macore.mamgt.misc.advice;

import com.convertlab.foundation.library.model.GenericPage;
import com.convertlab.foundation.library.model.vo.GenericListResponse;
import com.convertlab.foundation.library.model.vo.GenericPageResponse;
import com.convertlab.foundation.library.model.vo.GenericResponse;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.mamgt.misc.interceptor.UserLanguageInterceptor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.Charsets;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringSubstitutor;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.MDC;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.EncodedResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import java.io.*;
import java.util.*;

/**
 * ClassName: I18nAspect
 * Description: AspectJ 切面，拦截Meta数据，匹配其中以${占位符} 表示的字符串，根据MDC.get('x_user_lang')
 * 找到对应语言的i18n/message.property，替换为本地化字符串
 * date: 2023/12/15 1:37 PM
 *
 * @author zihan.chen
 */
@Aspect
@Slf4j
public class I18nAspect {
    private static Map<String, Map<String, String>> metaI18n = null;
    private static Map<String, Map<String, String>> errorI18n = null;
    private static String [] supportedLanguages = null;
    private static final int START_MESSAGE_PROPERTY_INDEX = 100;
    private static final int END_MESSAGE_PROPERTY_INDEX = 105;

    private static String defaultLanguage = "zh_CN";

    static {
        metaI18n = new LinkedHashMap<>();
        errorI18n = new LinkedHashMap<>();
        supportedLanguages = new String[]{
                "zh_CN", "zh_TW", "en_US"
        };
    }

    public I18nAspect(String supportedLangs, String systemDefaultLanguage) throws InstantiationException{
        initLanguagePackages(supportedLangs);
        defaultLanguage = systemDefaultLanguage;
    }

    // i18n接口切面
    @Pointcut("@annotation(com.convertlab.macore.mamgt.misc.annotation.I18nMeta)")
    public void bizMetaI18nPointCut() {
    }

    // 对加注了@I18nMeta 的meta接口返回数据进行AOP，进行国际化处理
    @AfterReturning(value="bizMetaI18nPointCut()", returning = "returnValue")
    public void beforeMetaReturn(JoinPoint joinPoint, Object returnValue) {
        try{
            localizeMessageInResponse(returnValue);
        }catch (Exception e){
            log.error("failed in i18n transform", e);
        }
    }

    @SuppressWarnings("java:S2696")
    private void initLanguagePackages(String supportedLangs) throws InstantiationException {
        if(StringUtils.isNotBlank(supportedLangs)){
            supportedLanguages = supportedLangs.split(",");
        }

        for(String _language: supportedLanguages){
            String language = _language.replace("-","_");
            try {
                if(metaI18n.get(language) == null) {
                    LinkedHashMap<String, String> languagePack = loadMetaLanguagePack("meta/i18n/messages_", language);
                    metaI18n.put(language, languagePack);
                }
                if(errorI18n.get(language) == null) {
                    LinkedHashMap<String, String> languagePack = loadErrorMessageProperties(language);
                    errorI18n.put(language, languagePack);
                }
            }catch (Exception e){
                log.error("failed to load language Package ", e);
                throw new InstantiationException(e.getMessage());
            }
        }
    }

    /**
     * 加载Meta语言包
     * @param path
     * @param language
     * @return
     * @throws IOException
     */
    private LinkedHashMap<String, String> loadMetaLanguagePack(String path, String language) throws IOException {
        LinkedHashMap<String, String> languagePack = new LinkedHashMap<>();
        String propertyFilePath = path + language + ".properties";
        EncodedResource resource = new EncodedResource( new ClassPathResource(propertyFilePath), Charsets.UTF_8);
        Properties loadedProperties = PropertiesLoaderUtils.loadProperties(resource);
        loadedProperties.forEach((key, value) -> languagePack.put(key.toString(), value.toString()));
        return languagePack;
    }

    /**
     * 加载所有的报错信息语言包, 参考: https://confluence.xiaoshu.biz/pages/viewpage.action?pageId=148321661
     * @param language
     * @return
     * @throws InstantiationException
     */
    @SuppressWarnings("java:S108")
    private LinkedHashMap<String, String> loadErrorMessageProperties(String language){
        LinkedHashMap<String, String> languagePack = new LinkedHashMap<>();
        for(int i=START_MESSAGE_PROPERTY_INDEX; i <= END_MESSAGE_PROPERTY_INDEX; i++){
            try{
                String lan =  language.equals("zh_CN") ? "" : ("_" + language);
                String propertyFilePath =String.format("%d-messages%s.properties", i, lan);
                ClassPathResource classPathResource = new ClassPathResource(propertyFilePath);
                EncodedResource resource = new EncodedResource(classPathResource, Charsets.UTF_8);
                Properties loadedProperties = PropertiesLoaderUtils.loadProperties(resource);
                loadedProperties.forEach((key, value) -> languagePack.put(key.toString(), value.toString()));
            }catch (Exception e){
            }
        }
        return languagePack;
    }

    public static String getHeaderLanguage() {
        String language = MDC.get(UserLanguageInterceptor.USER_LANG);
        if(StringUtils.isBlank(language)){
            language = defaultLanguage;
        }
        log.debug("load language properties of " + language);
        language = language.replace("-", "_");
        String matchedLanguage = null;
        for(String lang: supportedLanguages) {
            if(lang.equalsIgnoreCase(language) || lang.replace("-","_").equalsIgnoreCase(language.replace("-","_"))){
                matchedLanguage = language;
            }
        }
        return matchedLanguage;
    }

    /**
     * 加载当前MDC.x_user_lang 的语言字典
     * @return
     */
    private Map<String, String> loadMetaPropertiesSet() {
        String language = getHeaderLanguage();
        if(language == null || metaI18n == null){
            log.warn("can't find meta language properties of language" + language);
            return Collections.emptyMap();
        }
        return metaI18n.get(language);
    }

    /**
     * 加载错误消息
     * @param key
     * @return
     */
    public static String loadErrorMessage(String key) {
        String language = getHeaderLanguage();
        if(language == null || errorI18n == null){
            log.warn("can't find error language properties of language" + language);
            return null;
        }
        Map<String, String> languagePackage = errorI18n.get(language);
        if(languagePackage !=null){
            return languagePackage.get(key);
        }
        return null;
    }

    @SuppressWarnings("java:S3740")
    public Object localizeMessageInResponse(Object object){
        if(object ==null){
            return null;
        }

        if(object instanceof GenericResponse){
            Object result = ((GenericResponse)object).getResult();
            Object newResult = localizeMessageInResponse(result);
            ((GenericResponse)object).setResult(newResult);
        }else if(object instanceof GenericListResponse){
            List results = ((GenericListResponse<?>) object).getResults();
            List newResults = (List) localizeMessageInResponse(results);
            ((GenericListResponse<?>) object).setResults(newResults);
        }else if(object instanceof GenericPageResponse){
            GenericPage pagination = ((GenericPageResponse<?>) object).getPagination();
            List results = pagination.getRecords();
            List newResults = (List) localizeMessageInResponse(results);
            pagination.setRecords(newResults);
            ((GenericPageResponse<?>) object).setPagination(pagination);
        }else if(object instanceof List){
            List resultList = ((List)object);
            for(int i=0;i<resultList.size(); i++){
                resultList.set(i, localizeMessageInResponse(resultList.get(i)));
            }
            return object;
        }else if(object instanceof Serializable){
            return objI18n(object);
        }else{
            log.warn("unsupported object type : {}", object.getClass().getName());
            return object;
        }
        return null;
    }

    /**
     * 将对象中的${***} 变量，替换成对应语言包的label
     * @param t
     * @return
     * @param <T>
     */
    private <T> T objI18n(T t) {
        if(t ==null){
            return null;
        }
        Map<String, String> params =  loadMetaPropertiesSet();
        if(params == null || params.isEmpty()){
            return t;
        }
        try {
            String serializedContent = JsonUtils.instanceOfDto().obj2Json(t);
            if (StringUtils.isBlank(serializedContent)){
                return t;
            }
            String result = StringSubstitutor.replace(serializedContent, params, "${", "}");
            log.debug("objI18n language : {} from : {} to {}", MDC.get(UserLanguageInterceptor.USER_LANG),
                    serializedContent, result);
            return JsonUtils.instanceOfDto().json2Obj(result, (Class<T>) t.getClass());
        }catch (Exception e){
            log.error("failed to objI18n : {}", JsonUtils.instanceOfDto().obj2Json(t), e);
        }
        return t;
    }
}
