package com.convertlab.macore.mamgt.misc.interceptor;

import com.convertlab.foundation.library.webmvc.interceptor.CustomHandlerInterceptor;
import com.convertlab.foundation.library.webmvc.property.ExtraWebMvcMultiTenancyProperties;
import org.slf4j.MDC;
import org.springframework.util.ClassUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Nonnull;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Arrays;
import java.util.List;

/**
 * 将HTTP Header中的 x_user_lang 设置到 MDC,作为当前请求的语言
 */
public class UserLanguageInterceptor implements CustomHandlerInterceptor {
    public static final String USER_LANG = "x_user_lang";
    private static final List<String> compatibleHeaders = Arrays.asList(USER_LANG, "X_user_lang","x-user-lang","X-user-lang");
    private final ExtraWebMvcMultiTenancyProperties properties;

    private String defaultLanguage;
    private List<String> supportedLanguageList;

    public UserLanguageInterceptor(ExtraWebMvcMultiTenancyProperties properties, String defaultLang, String supportedLanguages) {
        super();
        this.properties = properties;
        this.defaultLanguage = defaultLang;
        this.supportedLanguageList = Arrays.asList(supportedLanguages.split(","));
    }

    @Nonnull
    @Override
    public List<String> getExcludePathPatterns() {
        return properties.getIgnoredPatterns();
    }

    private String getUserLanguageFromHeader(HttpServletRequest request) {
        for(int i=0; i<compatibleHeaders.size(); i++){
            String language = request.getHeader(compatibleHeaders.get(i));
            if(org.apache.commons.lang3.StringUtils.isNotBlank(language)
                    && ( supportedLanguageList.contains(language))) {
                return language.replace("-","_");
            }
        }
        return defaultLanguage;
    }

    @Override
    @SuppressWarnings("java:S3516")
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (!(handler instanceof HandlerMethod)) {
            return true;
        }

        HandlerMethod handlerMethod = (HandlerMethod) handler;

        if (!ClassUtils.getPackageName(handlerMethod.getBeanType()).startsWith("com.convertlab")) {
            return true;
        }

        String language = getUserLanguageFromHeader(request);
        MDC.put(USER_LANG, language);
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        clean();
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        clean();
    }

    private void clean() {
        MDC.remove(USER_LANG);
    }
}
