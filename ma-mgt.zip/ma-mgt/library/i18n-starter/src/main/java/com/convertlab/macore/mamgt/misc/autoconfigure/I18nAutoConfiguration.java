package com.convertlab.macore.mamgt.misc.autoconfigure;

import org.springframework.context.annotation.Configuration;

@Configuration
public class I18nAutoConfiguration {
}
