package com.convertlab.macore.mamgt.misc.annotation;
import java.lang.annotation.*;

/**
 * ClassName: I18nMeta
 * Description: 自定义注解 拦截BizMeta数据，匹配其中以${占位符} 表示的字符串，根据MDC.get('x_user_lang')
 * 找到对应语言的i18n/message.property，替换为本地化字符串
 * date: 2023/12/15 1:37 PM
 *
 * @author zihan.chen
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface I18nMeta {
}
