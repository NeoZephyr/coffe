package com.convertlab.macore.mamgt.common.service;

public interface FunctionP2<P1, P2, R> {
    R apply(P1 p1, P2 p2) throws Exception;
}
