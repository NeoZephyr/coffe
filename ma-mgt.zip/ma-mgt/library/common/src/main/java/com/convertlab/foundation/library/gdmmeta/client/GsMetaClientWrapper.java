package com.convertlab.foundation.library.gdmmeta.client;

import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.gdmmeta.model.general.BaseMetaSchema;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.ObjectRequest;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.ObjectResponse;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationship;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmSingularGdmRelationship;
import com.convertlab.macore.mamgt.common.utils.NamingUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import javax.annotation.Nullable;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

public class GsMetaClientWrapper {
    private final GsMetaClient gsMetaClient;

    public GsMetaClientWrapper(GsMetaClient gsMetaClient) {
        this.gsMetaClient = gsMetaClient;
    }

    /**
     * 覆写foundation的findByName方法，将modelName 转换为小写 或 snake_case
     *
     * @param entityName entity名称
     * @return gdm对象
     */
    @Nullable
    public GdmEntity getEntity(String entityName) {
        entityName = NamingUtils.toLowerUnderScoreCase(entityName);
        return gsMetaClient.getEntity(entityName);
    }

    public GdmEntity deleteEntity(String entityName) {
        entityName = NamingUtils.toLowerUnderScoreCase(entityName);
        return gsMetaClient.deleteEntity(entityName);
    }

    public List<GdmRelationship> getRelationships(String entityName, @Nullable String relationshipName) {
        entityName = NamingUtils.toLowerUnderScoreCase(entityName);
        return gsMetaClient.getRelationships(entityName, relationshipName);
    }

    public List<GdmSingularGdmRelationship> getBackRefProfileList(String entityName) {
        entityName = NamingUtils.toLowerUnderScoreCase(entityName);
        return gsMetaClient.getBackRefProfileList(entityName);
    }

    public Map<String, List<GdmSingularGdmRelationship>> getBackRefProfileList(List<String> inputProfileNames) {
        if (inputProfileNames != null) {
            List<String> entities = inputProfileNames.stream().map(NamingUtils::toLowerUnderScoreCase).collect(Collectors.toList());
            return gsMetaClient.getBackRefProfileList(entities);
        } else {
            return Collections.emptyMap();
        }
    }

    public Map<String, GdmEntity> getEntityMapByNames(List<String> entityNames) {
        if (!CollectionUtils.isEmpty(entityNames)) {
            entityNames = entityNames.stream().map(NamingUtils::toLowerUnderScoreCase).collect(Collectors.toList());
        }
        return gsMetaClient.getEntityMapByNames(entityNames);
    }

    public String getGsClientInfo() {
        return gsMetaClient.getGsClientInfo();
    }

    public boolean isEventEntity(GdmEntity entity) {
        return gsMetaClient.isEventEntity(entity);
    }

    public Map<GdmField, GdmRelationship> getFkRelationshipMap(String entityName) {
        entityName = NamingUtils.toLowerUnderScoreCase(entityName);
        return gsMetaClient.getFkRelationshipMap(entityName);
    }

    @Deprecated
    public List<GdmEntity> getEntityList() {
        return gsMetaClient.getEntityList();
    }

    /**
     * 获取一个易用的客户端，只能用于操作白名单中的元数据类型
     *
     * @param metaType
     * @return SimpleMetaClient
     */
    public SimpleMetaClient simpleClientOf(BaseMetaSchema.MetaType metaType) {
        return new SimpleMetaClientWrapper(gsMetaClient.simpleClientOf(metaType));
    }

    static class SimpleMetaClientWrapper implements SimpleMetaClient {

        private final SimpleMetaClient simpleMetaClient;

        public SimpleMetaClientWrapper(SimpleMetaClient simpleClient) {
            this.simpleMetaClient = simpleClient;
        }

        @Override
        public ObjectResponse createObject(ObjectRequest objectRequest) {
            objectRequest.setObjectName(NamingUtils.toLowerUnderScoreCase(objectRequest.getObjectName()));
            return simpleMetaClient.createObject(objectRequest);
        }

        @Override
        public List<ObjectResponse> queryObjects(Map<String, String> filter) {
            if (filter != null && !filter.isEmpty()) {
                String objectName = filter.get("objectName");
                if (StringUtils.isNotBlank(objectName)) {
                    filter.put("objectName", NamingUtils.toLowerUnderScoreCase(objectName));
                }
            }
            return simpleMetaClient.queryObjects(filter);
        }

        @Nullable
        @Override
        public ObjectResponse getObject(String objectName) {
            objectName = NamingUtils.toLowerUnderScoreCase(objectName);
            return simpleMetaClient.getObject(objectName);
        }

        @Override
        public ObjectResponse updateObject(ObjectRequest objectRequest) {
            objectRequest.setObjectName(NamingUtils.toLowerUnderScoreCase(objectRequest.getObjectName()));
            return simpleMetaClient.updateObject(objectRequest);
        }

        @Override
        public void deleteObject(String objectName) {
            objectName = NamingUtils.toLowerUnderScoreCase(objectName);
            simpleMetaClient.deleteObject(objectName);
        }

        @Override
        public <T> T createObject2(String objectName, T object) {
            objectName = NamingUtils.toLowerUnderScoreCase(objectName);
            return Objects.requireNonNull(simpleMetaClient.createObject2(objectName, object));
        }

        @Override
        public <T> List<T> queryObjects2(Map<String, String> filter, Class<T> clazz) {
            if (filter != null && !filter.isEmpty()) {
                String objectName = filter.get("objectName");
                if (StringUtils.isNotBlank(objectName)) {
                    filter.put("objectName", NamingUtils.toLowerUnderScoreCase(objectName));
                }
            }
            return simpleMetaClient.queryObjects2(filter, clazz);
        }

        @Nullable
        @Override
        public <T> T getObject2(String objectName, Class<T> clazz) {
            objectName = NamingUtils.toLowerUnderScoreCase(objectName);
            return simpleMetaClient.getObject2(objectName, clazz);
        }

        @Override
        public <T> T updateObject2(String objectName, T object) {
            objectName = NamingUtils.toLowerUnderScoreCase(objectName);
            return Objects.requireNonNull(simpleMetaClient.updateObject2(objectName, object));
        }
    }
}
