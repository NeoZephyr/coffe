package com.convertlab.macore.mamgt.common.cache;

public interface MemCache<V>  {

    /**
     * 获取缓存结果
     *
     * @param key
     * @return
     */
    V getIfPresent(String key);

    /**
     * 获取缓存结果
     *
     * @param key
     * @param loader
     * @return
     */
    V get(String key, MemCacheLoader<V> loader);

    /**
     * 放入缓存结果
     *
     * @param key
     * @param val
     */
    void put(String key, V val);

    /**
     * 使缓存失效
     *
     * @param key
     */
    void invalidate(String key);
}
