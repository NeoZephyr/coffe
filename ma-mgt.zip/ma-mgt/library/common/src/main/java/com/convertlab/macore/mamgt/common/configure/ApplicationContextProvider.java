package com.convertlab.macore.mamgt.common.configure;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import javax.annotation.Nonnull;
import java.util.Map;

/**
 * All rights Reserved, Designed By ConvertLab
 * Author: zhiping.cai
 * Date: 2023/6/12
 * Description:
 * Copyright (C) 2022 www.convertlab.com
 */
@Component
public class ApplicationContextProvider implements ApplicationContextAware {

    private static ApplicationContext context;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        context = applicationContext;
    }

    public static ApplicationContext getApplicationContext() {
        return context;
    }

    public static <T> T getBean(@Nonnull Class<T> clazz) {
        return context.getBean(clazz);
    }

    public static <T> T getBean(String name, Class<T> requiredType) throws BeansException{
        return context.getBean(name, requiredType);
    }

    public static Object getBeanByType(Class<?> clazz) {
        if (context == null) {
            throw new RuntimeException("ApplicationContext is not initialized");
        }
        Map<String, ?> beans = context.getBeansOfType(clazz);
        if (beans.isEmpty()) {
            throw new RuntimeException("No bean found for type: " + clazz.getName());
        } else if (beans.size() > 1) {
            throw new RuntimeException("Multiple beans found for type: " + clazz.getName());
        } else {
            return beans.values().iterator().next();
        }
    }
}
