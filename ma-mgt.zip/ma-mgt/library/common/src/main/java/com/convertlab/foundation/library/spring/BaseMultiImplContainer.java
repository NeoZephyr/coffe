package com.convertlab.foundation.library.spring;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.aop.support.AopUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.stereotype.Component;

import java.lang.annotation.Annotation;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;

@Slf4j
@Getter
@Component
public class BaseMultiImplContainer implements ApplicationListener<ContextRefreshedEvent> {

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
    }

    protected <T> void initMultiImpl(ContextRefreshedEvent event, Class<T> serviceClazz, Map<String, T> fillBeanMap) {
        initMultiImpl(
                event,
                serviceClazz,
                MultiImplAnno.class,
                (annotation, bean) -> {
                    MultiImplAnno anno = (MultiImplAnno) annotation;
                    fillBeanMap.put(genKey(anno.keys()), serviceClazz.cast(bean));
                }
        );
    }

    protected <T> void initMultiImpl(ContextRefreshedEvent event,
                                     Class<T> instanceClass,
                                     Class<? extends Annotation> annotationType,
                                     BiConsumer<Annotation, Object> consumer) {
        ApplicationContext context = event.getApplicationContext();
        Map<String, Object> beanMap = context.getBeansWithAnnotation(annotationType);
        beanMap.values().stream().filter(instanceClass::isInstance)
                .forEach(c -> {
                    if (AopUtils.isAopProxy(c)) {
                        // @Async注解会导致bean被代理
                        Annotation annotation = AnnotationUtils.findAnnotation(AopUtils.getTargetClass(c), annotationType);
                        if (Objects.nonNull(annotation)) {
                            consumer.accept(annotation, c);
                        }
                    } else {
                        Annotation annotation = AnnotationUtils.findAnnotation(c.getClass(), annotationType);
                        if (Objects.nonNull(annotation)) {
                            consumer.accept(annotation, c);
                        }
                    }
                });
    }


    public <S> S getService(String[] keys, Map<String, S> serviceMap, S defaultS) {
        if (Objects.isNull(keys) || keys.length == 0) {
            return null;
        }
        return Optional.ofNullable(serviceMap.get(genKey(keys))).orElse(defaultS);
    }

    public <S> S getService(String[] keys, Map<String, S> serviceMap) {
        return getService(keys, serviceMap, null);
    }


    public String genKey(String[] keys) {
        if (Objects.isNull(keys) || keys.length == 0) {
            return null;
        }
        return Arrays.stream(keys).map(String::toLowerCase).reduce((a, b) -> a + "," + b).orElse("");
    }


}