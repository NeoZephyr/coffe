package com.convertlab.macore.mamgt.common.service;

public interface FunctionP1<P1, R> {
    R apply(P1 p1);
}
