package com.convertlab.macore.mamgt.common.utils;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class BeanHelper {
    private static final String LOG_PREFIX = "<ma-mgt> <BeanHelper>";

    /**
     * 浏览bean的所有数据类型的属性
     *
     * @param config 配置
     * @param bean   对象
     * @param <T>
     */
    public static <T> void visitBean(VisitBeanConfig config, T bean) {
        visitBean(config, "$", bean, bean == null ? null : bean.getClass(), "", bean);
    }

    /**
     * 浏览list bean的所有数据类型的属性
     *
     * @param config   配置
     * @param beanList 对象list
     * @param <T>
     */
    public static <T> void visitBeanList(VisitBeanConfig config, Set<T> beanList) {
        visitBeanList(config, "$", "", beanList);
    }

    /**
     * 浏览list bean的所有数据类型的属性
     *
     * @param config   配置
     * @param beanList 对象list
     * @param <T>
     */
    public static <T> void visitBeanList(VisitBeanConfig config, List<T> beanList) {
        visitBeanList(config, "$", "", beanList);
    }

    /**
     * 浏览Map bean的所有数据类型的属性
     *
     * @param config  配置
     * @param beanMap 对象Map
     */
    public static void visitBeanMap(VisitBeanConfig config, Map<?, ?> beanMap) {
        visitBeanMap(config, "$", "", beanMap);
    }

    /**
     * 浏览bean的所有数据类型的属性
     *
     * @param config     配置
     * @param path       当前属性所在路径字符串
     * @param currObject 当前属性所属的对象
     * @param type       当前属性的数据类型
     * @param fieldName  当前属性的字段名称
     * @param bean       对象
     * @param <T>
     */
    private static <T> T visitBean(VisitBeanConfig config, String path, Object currObject, Class<?> type, String fieldName, T bean) {
        if (bean == null) {
            T newVal = null;
            if (config != null && config.getNullFieldHandle() != null) {
                newVal = (T) config.getNullFieldHandle().fieldVisit(path, currObject, type, fieldName);
                setBaseData(currObject, type, fieldName, null, newVal);
            }
            if (log.isDebugEnabled()) {
                log.debug("{} visitBean stop . bean is null . object class:{} ,fieldPath:{} ,fieldType:{} ,fieldName:{} ", LOG_PREFIX, currObject == null ? "null" : currObject.getClass(), path, type, fieldName);
            }
            return newVal;
        }
        if (isDataType(bean)) {
            return visitBeanData(config, path, currObject, type, fieldName, bean);
        }
        Class<?> clazz = bean.getClass();
        while (clazz != null) {
            if (log.isDebugEnabled()) {
                log.debug("{} visitBean ing . current class:{} ,fieldPath:{} ,fieldType:{} ,fieldName:{} ,value:{}", LOG_PREFIX, clazz.getSimpleName(), path, type, fieldName, bean);
            }
            Field[] fields = clazz.getDeclaredFields();
            for (Field field : fields) {
                field.setAccessible(true); // 设置可访问性，允许访问私有属性
                Class<?> currType = field.getType();
                String name = field.getName(); // 获取属性名称
                Object value = null; // 获取属性值
                try {
                    value = field.get(bean);
                } catch (IllegalAccessException e) {
                    log.error("{} visitBean have a error . class:{} ,path:{} ,fieldName:{}", clazz, path, fieldName, e);
                }
                if (log.isDebugEnabled()) {
                    log.debug("{} visitBean ing . class:{} ,fieldPath:{} ,fieldType:{} ,fieldName:{} ,value:{}", LOG_PREFIX, clazz.getSimpleName(), path, currType, name, value);
                }
                if (isDataType(value)) {
                    visitBeanData(config, path + "." + name, bean, currType, name, value);
                } else {
                    visitBean(config, path + "." + name, bean, currType, name, value);
                }
            }
            clazz = clazz.getSuperclass();
        }
        return bean;
    }

    /**
     * 浏览bean的所有数据类型的属性
     *
     * @param config     配置
     * @param path       当前属性所在路径字符串
     * @param currObject 当前属性所属的对象
     * @param type       当前属性的数据类型
     * @param fieldName  当前属性的字段名称
     * @param value      当前属性的值
     * @param <T>
     */
    private static <T> T visitBeanData(VisitBeanConfig config, String path, Object currObject, Class<?> type, String fieldName, T value) {
        T newVal = value;
        if (value == null) {
            if (config != null && config.getNullFieldHandle() != null) {
                newVal = (T) config.getNullFieldHandle().fieldVisit(path, currObject, type, fieldName);
                setBaseData(currObject, type, fieldName, null, newVal);
            }
            if (log.isDebugEnabled()) {
                log.debug("{} visitBeanData end . fieldName:{} is null . class:{} ,fieldPath:{} ,fieldType:{} ,value:null ,change value:{}", LOG_PREFIX, fieldName, currObject == null ? "null" : currObject.getClass(), path, type, value);
            }
            return newVal;
        }

        if (config != null && !CollectionUtils.isEmpty(config.getFieldVisits())) {
            FieldVisit<Object> objectFieldVisit = (FieldVisit<Object>) config.getFieldVisitByClass(Object.class);
            if (objectFieldVisit != null) {
                newVal = (T) objectFieldVisit.fieldVisit(path, currObject, type, fieldName, value);
            }
            FieldVisit<T> fieldVisit = (FieldVisit<T>) config.getFieldVisitByClass(type);
            if (fieldVisit != null) {
                newVal = fieldVisit.fieldVisit(path, currObject, type, fieldName, newVal);
            }
        }
        if (value.getClass().isArray()) {
            //数组类型的对象处理
            int length = Array.getLength(value);
            for (int i = 0; i < length; i++) {
                Object arrayVal = Array.get(value, i);
                Object newArrayVal;
                if (isDataType(arrayVal)) {
                    newArrayVal = visitBeanData(config, path + ".*", value, arrayVal.getClass(), fieldName, arrayVal);
                } else {
                    newArrayVal = visitBean(config, path + ".*", value, arrayVal == null ? null : arrayVal.getClass(), fieldName, arrayVal);
                }
                Array.set(value, i, newArrayVal);
            }
        } else if (value instanceof Set) {
            visitBeanList(config, path, fieldName, ((Set<?>) newVal));
        } else if (value instanceof List) {
            visitBeanList(config, path, fieldName, ((List<?>) newVal));
        } else if (value instanceof Map) {
            visitBeanMap(config, path, fieldName, ((Map<?, ?>) newVal));
        } else if (isBaseDataType(value) || value instanceof Enum) {
            setBaseData(currObject, type, fieldName, value, newVal);
            return newVal;
        }
        return newVal;
    }

    private static <T> void setBaseData(Object currObject, Class<?> type, String fieldName, T value, T newVal) {
        if (!isDataType(currObject) && ((type == String.class && newVal != null && !newVal.equals(value))
                || (!(type == String.class) && newVal != value))) {
            setBeanField(currObject, fieldName, newVal);
        }
    }

    /**
     * 设置bean的指定属性值
     *
     * @param object    对象
     * @param fieldName 字段名称
     * @param val       字段值
     */
    public static void setBeanField(Object object, String fieldName, Object val) {
        if (object == null) {
            log.warn("{} setBeanField stop . object is null . fieldName:{} ,val:{}", LOG_PREFIX, fieldName, val);
            return;
        }
        try {
            Class<?> clazz = object.getClass();
            Field field = null;
            while (clazz != null) {
                try {
                    field = clazz.getDeclaredField(fieldName);
                } catch (NoSuchFieldException e) {
                    clazz = clazz.getSuperclass();
                }
                if (field != null) {
                    break;
                }
            }
            if (field == null) {
                return;
            }
            int mod = field.getModifiers();
            if (Modifier.isStatic(mod) || Modifier.isFinal(mod)) {
                return;
            }
            field.setAccessible(true);
            field.set(object, val);
        } catch (IllegalAccessException e) {
            log.error("{} setBeanField have error . class:{} ,fieldName:{} ,val:{}", LOG_PREFIX, object.getClass(), fieldName, val, e);
        }

    }

    /**
     * 判断对象是不是数据类型
     *
     * @param object 对象
     * @return 是否是数据类型
     */
    public static boolean isDataType(Object object) {
        if (object == null) {
            return false;
        }
        if (object instanceof Collection
                || object instanceof Map
                || object instanceof Enum
                || object.getClass().isArray()) {
            return true;
        }
        return isBaseDataType(object);
    }

    /**
     * 判断对象是不是基础数据类型
     *
     * @param object 对象
     * @return 是否是基础数据类型
     */
    public static boolean isBaseDataType(Object object) {
        if (object == null) {
            return false;
        }
        if (object instanceof Boolean
                || object instanceof Short
                || object instanceof Integer
                || object instanceof Long
                || object instanceof Float
                || object instanceof Double
                || object instanceof BigDecimal
                || object instanceof BigInteger
                || object instanceof Character
                || object instanceof String) {
            return true;
        }
        return false;
    }

    /**
     * 浏览list bean的所有数据类型的属性
     *
     * @param config    配置
     * @param path      当前属性所在路径字符串
     * @param fieldName 当前属性的字段名称
     * @param beanList  对象list
     * @param <T>
     */
    private static <T> void visitBeanList(VisitBeanConfig config, String path, String fieldName, Set<T> beanList) {
        if (beanList == null) {
            if (log.isDebugEnabled()) {
                log.debug("{} visitBeanList stop . beanList is null . fieldPath:{} ,fieldName:{}", LOG_PREFIX, path, fieldName);
            }
            return;
        }
        Set<T> collect = beanList.stream().map(val -> {
            if (isDataType(val)) {
                return visitBeanData(config, path + ".*", beanList, val.getClass(), fieldName, val);
            } else {
                return visitBean(config, path + ".*", beanList, val == null ? null : val.getClass(), fieldName, val);
            }
        }).collect(Collectors.toSet());
        beanList.clear();
        beanList.addAll(collect);
    }

    /**
     * 浏览list bean的所有数据类型的属性
     *
     * @param config    配置
     * @param path      当前属性所在路径字符串
     * @param fieldName 当前属性的字段名称
     * @param beanList  对象list
     * @param <T>
     */
    private static <T> void visitBeanList(VisitBeanConfig config, String path, String fieldName, List<T> beanList) {
        if (beanList == null) {
            if (log.isDebugEnabled()) {
                log.debug("{} visitBeanList stop . beanList is null . fieldPath:{} ,fieldName:{}", LOG_PREFIX, path, fieldName);
            }
            return;
        }
        List<T> collect = beanList.stream().map(val -> {
            if (isDataType(val)) {
                return visitBeanData(config, path + ".*", beanList, val.getClass(), fieldName, val);
            } else {
                return visitBean(config, path + ".*", beanList, val == null ? null : val.getClass(), fieldName, val);
            }
        }).collect(Collectors.toList());
        beanList.clear();
        beanList.addAll(collect);
    }

    /**
     * 浏览Map bean的所有数据类型的属性
     *
     * @param config    配置
     * @param path      当前属性所在路径字符串
     * @param fieldName 当前属性的字段名称
     * @param beanMap   对象Map
     */
    private static void visitBeanMap(VisitBeanConfig config, String path, String fieldName, Map<?, ?> beanMap) {
        if (beanMap == null) {
            if (log.isDebugEnabled()) {
                log.debug("{} visitBeanMap stop . beanMap is null . fieldPath:{} ,fieldName:{}", LOG_PREFIX, path, fieldName);
            }
            return;
        }
        for (Map.Entry<?, ?> map : beanMap.entrySet()) {
            Object mKey = map.getKey();
            Object mVal = map.getValue();
            if (isDataType(mVal)) {
                Object o = visitBeanData(config, path + "." + mKey, beanMap, mVal.getClass(), mKey.toString(), mVal);
                ((Map<Object, Object>) beanMap).put(mKey, o);
            } else {
                Object o = visitBean(config, path + "." + mKey, beanMap, mVal == null ? null : mVal.getClass(), mKey.toString(), mVal);
                ((Map<Object, Object>) beanMap).put(mKey, o);
            }
        }
    }

    @Getter
    public static class VisitBeanConfig {

        private final List<FieldVisit<?>> fieldVisits = new ArrayList<>();
        private NullFieldHandle nullFieldHandle;
        private Map<Class<?>, FieldVisit<?>> fieldVisitMap;

        /**
         * 添加处理函数，不要使用lambda，会导致获取类型不正确
         *
         * @param fieldVisit
         */
        public void addFieldVisit(FieldVisit<?> fieldVisit) {
            this.fieldVisits.add(fieldVisit);
        }

        public void setNullFieldHandle(NullFieldHandle nullFieldHandle) {
            this.nullFieldHandle = nullFieldHandle;
        }

        public FieldVisit<?> getFieldVisitByClass(Class<?> clazz) {
            if (this.fieldVisitMap == null) {
                this.fieldVisitMap = fieldVisits.stream().collect(Collectors.toMap(FieldVisit::getHandleType, v -> v));
            }
            return this.fieldVisitMap.get(clazz);
        }
    }

    public interface FieldVisit<T> {

        default Class<?> getHandleType() {
            Method[] methods = this.getClass().getMethods();
            Class<?> type = null;
            for (Method method : methods) {
                String name = method.getName();
                if ("fieldVisit".equals(name)) {
                    Class<?> returnType = method.getReturnType();
                    if (returnType != Object.class) {
                        type = returnType;
                    } else if (type == null) {
                        type = returnType;
                    }
                }
            }
            return type;
        }

        T fieldVisit(String path, Object currObject, Class<?> type, String fieldName, T value);
    }

    public interface NullFieldHandle {
        Object fieldVisit(String path, Object currObject, Class<?> type, String fieldName);
    }

}
