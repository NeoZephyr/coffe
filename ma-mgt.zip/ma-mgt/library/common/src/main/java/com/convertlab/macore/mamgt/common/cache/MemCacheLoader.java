package com.convertlab.macore.mamgt.common.cache;

public interface MemCacheLoader<V> {

    V load(String key) throws Exception;

}