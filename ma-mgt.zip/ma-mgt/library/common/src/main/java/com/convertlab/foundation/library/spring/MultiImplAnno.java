package com.convertlab.foundation.library.spring;

import org.springframework.stereotype.Component;

import java.lang.annotation.*;

/**
 * @apiNote 多实现注解
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Component
@Documented
public @interface MultiImplAnno {
    String[] keys();
}
