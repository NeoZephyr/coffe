package com.convertlab.macore.mamgt.cdp.client;

import com.convertlab.foundation.api.gdm.pattern.GdmModelClient;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto;
import com.convertlab.foundation.api.gdm.pattern.facade.GdmProfileEventClient;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.macore.mamgt.common.utils.NamingUtils;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class GdmModelClientWrapper extends GdmModelClient {
    private GdmProfileEventClient gdmProfileEventClient;
    public GdmModelClientWrapper(GsMetaClient gsMetaClient, GdmProfileEventClient gdmProfileEventClient) {
        super(gsMetaClient, gdmProfileEventClient);
        this.gdmProfileEventClient = gdmProfileEventClient;
    }

    /**
     * 覆写foundation的findByName方法，将modelName 转换为小写 或 snake_case
     * @param modelName
     * @return
     */
    @Nullable
    @Override
    public GdmModelDto findByName(@Nonnull String modelName) {
        return super.findByName(NamingUtils.toLowerUnderScoreCase(modelName));
    }

    @Nullable
    public GdmPatternDto.ProfileEvent[] findProfileEvents(@Nonnull String profileName){
        return gdmProfileEventClient.findProfileEvents(profileName);
    }

    public GdmPatternDto.ProfileEvent[] findPatternSystemEvents(@Nonnull String[] patternNames){
        return gdmProfileEventClient.findPatternSystemEvents(patternNames);
    }
}
