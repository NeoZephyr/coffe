package com.convertlab.macore.mamgt.common.utils;

import com.convertlab.foundation.library.utils.JsonUtils;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.Nonnull;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

@Slf4j
public class GZIPCompressor {
    /**
     * 超过多少个字符，将被截断
     */
    private static final int MAXIMUM_LOG_OBJECT_LENGTH = 1048576;
    /**
     * 超过多少个字符，将被压缩
     */
    private static final int LOG_OBJECT_LENGTH_THRESHOLD = 2048;

    private GZIPCompressor() {
    }

    /**
     * 在日志中输出的JSON对象, 超过长度将被GZIP压缩
     * @param t 需要被输出的对象
     * @return 控制长度的JSON对象字符串
     * @param <T>
     * @throws IOException
     */
    public static <T> String getLogObj2Json(@Nonnull T t, boolean forceCompress) {
       String originalStringContent =  JsonUtils.instanceOfDto().obj2Json(t);
       if(forceCompress || originalStringContent.length() > LOG_OBJECT_LENGTH_THRESHOLD){
           try{
               String compressStringContent = compressString(originalStringContent);
               if(compressStringContent.length() > MAXIMUM_LOG_OBJECT_LENGTH) {
                    return compressString(originalStringContent.substring(0, MAXIMUM_LOG_OBJECT_LENGTH));
               }else{
                   return compressStringContent;
               }
           }catch (IOException e) {
               log.error("[GZIPCompressor] Failed to compressString", e);
               throw new IllegalStateException("Failed to compressString");
           }
       }else{
           return originalStringContent;
       }
    }

    /**
     * 自动对日志中的内容进行截断和压缩输出
     * @param t
     * @return
     * @param <T>
     * @throws IOException
     */
    public static <T> String getLogObj2Json(@Nonnull T t) {
        return getLogObj2Json(t, false);
    }

    /**
     * 在日志中对输出的JSON进行去标识化
     * @param t
     * @return
     * @param <T>
     * @throws IOException
     */
    public static <T> String deIdentificationLogObj2Json(@Nonnull T t) {
        return getLogObj2Json(t, true);
    }


    public static String compressString(String originalString) throws IOException {
        ByteArrayOutputStream obj=new ByteArrayOutputStream();
        GZIPOutputStream gzip = new GZIPOutputStream(obj);
        gzip.write(originalString.getBytes(StandardCharsets.UTF_8));
        gzip.close();
        String base64Encoded = Base64.getEncoder().encodeToString(obj.toByteArray());
        return base64Encoded;
    }

    public static String decompressToSting(String str) throws IOException {
        GZIPInputStream gis = new GZIPInputStream(new ByteArrayInputStream(Base64.getDecoder().decode(str)));
        BufferedReader bf = new BufferedReader(new InputStreamReader(gis, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line=bf.readLine())!=null) {
            sb.append(line);
        }
        return sb.toString();
    }
}
