package com.convertlab.macore.mamgt.common.service;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

public interface ImpalaService {
    /**
     * 刷新impala hive
     *
     * @param tableName  hive表名
     * @param partitions 分区信息
     */
    Boolean refreshHivePartitionWithColumnType(String tableName, List<HivePartition> partitions);

    Boolean refreshHivePartitionByFoundation(String tableName, List<RefreshColumn> partitions);

    Boolean invalidateMetaByFoundation(String tableName);

    @Setter
    @Getter
    public static class HivePartition {
        private String column;
        @JsonIgnore
        private String valType;
        private Object value;

        public HivePartition() {
        }

        public HivePartition(String column, String valType, Object value) {
            this.column = column;
            this.valType = valType;
            this.value = value;
        }
    }

    @Setter
    @Getter
    public static class RefreshColumn {
        private String column;
        private String type;
        private String value;

        public RefreshColumn(String column, String type, String value) {
            this.column = column;
            this.type = type;
            this.value = value;
        }
    }
}
