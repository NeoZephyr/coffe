package com.convertlab.macore.mamgt.common.cache;

import com.convertlab.foundation.library.multitenancy.exception.TenantNotFoundException;

public interface CacheKeyMapper {
    String getRealKey(String originalKey) throws IllegalArgumentException, TenantNotFoundException;
    String eliminateKeyFrom(String realKey) throws IllegalArgumentException, TenantNotFoundException;
}
