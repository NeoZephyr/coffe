package com.convertlab.foundation.library.queryengine.client;

import com.convertlab.foundation.api.queryengine.GdmCount;
import com.convertlab.foundation.api.queryengine.GdmQuery;
import com.convertlab.foundation.api.queryengine.SqlBuilder;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import javax.annotation.Nonnull;

/**
 * copy from ma-mgt/application, and rename to queryEngineClient
 * will replace the one in ma-mgt/application after ma-mgt does not change too much for 3.1
 *
 */
@FeignClient(
        name = "queryEngineClient",
        url = "${queryEngineServer.serverUrl}"
)
public interface QueryEngineClient {

    @PostMapping("/v1/query-engine/q")
    GdmQuery.Response queryEngineQuery(@Nonnull @RequestBody GdmQuery.Request request);

    @PostMapping("/v1/query-engine/c")
    GdmCount.Response queryEngineQueryCount(@Nonnull @RequestBody GdmCount.Request request);

    @PostMapping("/v1/query-engine/sql")
    SqlBuilder.Response queryEngineSql(@Nonnull @RequestBody SqlBuilder.Request request);

    @GetMapping("/ping")
    String ping();
}
