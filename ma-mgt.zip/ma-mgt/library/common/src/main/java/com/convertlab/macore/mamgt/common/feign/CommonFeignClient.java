package com.convertlab.macore.mamgt.common.feign;


import com.convertlab.macore.mamgt.common.feign.decoder.GenericsFeignResultDecoder;
import com.convertlab.macore.mamgt.common.feign.interceptor.FeignRequestInterceptor;
import com.fasterxml.jackson.core.type.TypeReference;
import feign.RequestInterceptor;
import feign.codec.Decoder;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.function.Supplier;

/**
 * feign通用调用接口
 *
 * @author zhiping.cai
 * @since 2023/03/24
 */
@FeignClient(
        name = "CommonFeignClient",
        url = "127.0.0.1:8080",
        configuration = {CommonFeignClient.CustomizedConfiguration.class}
)
public interface CommonFeignClient {

    @GetMapping
    <R> R getJsonObject(URI uri);

    @GetMapping
    <R> R getJsonObject(URI uri, Class<R> responseType);

    @PostMapping
    <T, R> R postJsonObject(URI uri, @RequestBody T requestBody);

    @PutMapping
    <T, R> R putJsonObject(URI uri, @RequestBody T requestBody);

    @DeleteMapping
    void deleteJsonObject(URI uri);

    @DeleteMapping
    <R> R deleteObjectWithResponse(URI uri);

    static <R> R withGeneric(TypeReference<?> typeReference, Supplier<R> supplier) {
        GenericsFeignResultDecoder.setReturnType(typeReference);
        return supplier.get();
    }


    class CustomizedConfiguration {
        @Bean
        public Decoder feignDecoder() {
            return new GenericsFeignResultDecoder();
        }

        @Bean
        public RequestInterceptor feignRequestInterceptor() {
            return new FeignRequestInterceptor();
        }

    }

}
