package com.convertlab.macore.mamgt.common.utils;

import com.google.common.base.CaseFormat;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Slf4j
public class NamingUtils {
    private static final String LOG_PREFIX = "<ma-mgt> <NamingUtils>";

    public static String toUnderScoreCase(String inputName) {
        String[] splitArray = StringUtils.split(inputName, ".");
        for (int i = 0; i < splitArray.length; i++) {
            String split = splitArray[i];
            if (!split.startsWith("c_") && !split.startsWith("cp_")) {
                String underScoreName = CaseFormat.LOWER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, split);
                if (!StringUtils.equals(split, underScoreName)) {
                    splitArray[i] = underScoreName;
                }
            }
        }
        String join = StringUtils.join(splitArray, ".");
        return join;
    }

    public static String convertInvalidBOToValidEntity(String inputName) {
        if (Objects.isNull(inputName) || inputName.isEmpty()) {
            return inputName;
        }

        String result = inputName.replaceAll("\\s+", "_")
                .replaceAll("-+", "_")
                .replaceAll("_+", "_")
                .replaceAll("_+$", "");
        return result;
    }

    public static String toLowerCamelCase(String inputName) {
        if (StringUtils.startsWithIgnoreCase(inputName, "c_") ||
                StringUtils.startsWithIgnoreCase(inputName, "cp_")) {
            return inputName;
        } else {
            return CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL, inputName);
        }
    }


    /**
     * 根据映射关系，转换map中的key
     *
     * @param record
     * @param projection
     * @return
     */
    public static Map<String, Object> projectKeysInMap(Map<String, Object> record, Map<String, String> projection) {
        Map<String, Object> result = new HashMap<>();
        record.entrySet().forEach(it -> {
            if (projection != null && projection.containsKey(it.getKey())) {
                result.put(projection.get(it.getKey()), it.getValue());
            } else {
                result.put(it.getKey(), it.getValue());
            }
        });
        return result;
    }

    public static String toLowerUnderScoreCase(String inputName) {
        if (StringUtils.isBlank(inputName)) {
            return inputName;
        }
        String legalName = convertInvalidBOToValidEntity(inputName);
        if (StringUtils.startsWithIgnoreCase(legalName, "c_") ||
                StringUtils.startsWithIgnoreCase(legalName, "cp_")) {
            return legalName.toLowerCase();
        } else {
            return CaseFormat.LOWER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, legalName);
        }
    }

//    /**
//     * 把bean内的所有String类型的值转为小写
//     *
//     * @param bean 要转换的对象
//     */
//    public static void beanStringValueToLowerCase(Object bean) {
//        BeanHelper.VisitBeanConfig config = new BeanHelper.VisitBeanConfig();
//        config.addFieldVisit(new BeanHelper.FieldVisit<String>() {
//            @Override
//            public String fieldVisit(String path, Object currObject, Class<?> type, String fieldName, String value) {
//                if (log.isDebugEnabled()) {
//                    log.debug("{} beanStringValueToLowerCase ing . class:{} ,fieldPath:{} ,fieldType:{} ,:fieldName:{} ,value:{}", LOG_PREFIX, currObject == null ? "null" : currObject.getClass().getName(), path, type, fieldName, value);
//                }
//                return value.toLowerCase();
//            }
//        });
//        BeanHelper.visitBean(config, bean);
//    }

    private static final int MAX_LENGTH_OF_GDM_NAME = 62;


    public static String underlineToHump(String name) {
        String[] segments = name.split("_");
        return IntStream.range(0, segments.length).mapToObj(i -> ((i==0)? segments[i] : StringUtils.capitalize(segments[i])))
                .collect(Collectors.joining(""));
    }

    public static String normalizeGdmName(String inputName) {
        if (StringUtils.isBlank(inputName)) {
            return inputName;
        }
        //处理特殊字符
        String normalizedName = inputName.trim().replaceAll("[\\s-]+", "_")
                .replaceAll("_+", "_").replaceAll("_+$", "");
        //转小写
        String lowercaseName = normalizedName.contains("_") ?
                normalizedName.toLowerCase()
                :
                CaseFormat.LOWER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, normalizedName);
        //处理长度
        return lowercaseName.length() > MAX_LENGTH_OF_GDM_NAME ? lowercaseName.substring(0, MAX_LENGTH_OF_GDM_NAME) : lowercaseName;
    }
}
