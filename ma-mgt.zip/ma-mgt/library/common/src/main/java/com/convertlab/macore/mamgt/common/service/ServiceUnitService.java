package com.convertlab.macore.mamgt.common.service;

import java.util.Set;

/**
 * All rights Reserved, Designed By ConvertLab
 * Author: zhiping.cai
 * Date: 2023/2/23
 * Description:
 * Copyright (C) 2022 www.convertlab.com
 */
public interface ServiceUnitService {

    public String getSuKey();

    public boolean isDefaultServiceUnit(String suKey);

    public boolean isSuService(String serviceName);

    public String resolveTopicPattern(String topic);

    public String[] resolveTopics(String topics);

    /**
     * 获取su的topic
     * @param topic topic
     * @return su topic
     * @author Mr.黄
     * @since 2023/7/19
    */
    String getSuTopic(String topic);

    /**
     * 获取全局所有的su
     * @return all su set
     * @author Mr.黄
     * @since 2024/3/25
    */
    Set<String> getAllServiceUnit();
}
