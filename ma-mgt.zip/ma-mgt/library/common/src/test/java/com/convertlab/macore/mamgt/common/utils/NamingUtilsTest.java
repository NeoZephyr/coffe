package com.convertlab.macore.mamgt.common.utils;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class NamingUtilsTest {
    @Test
    public void testNormalizeGdmName() {
        assertEquals("c_car", NamingUtils.normalizeGdmName("c_car"));
        assertEquals("c_car", NamingUtils.normalizeGdmName("C_CAR"));
        assertEquals("c_car", NamingUtils.normalizeGdmName("cCar"));
        assertEquals("c_car", NamingUtils.normalizeGdmName("c__car"));
        assertEquals("c_car", NamingUtils.normalizeGdmName("c_______car"));
        assertEquals("c_car", NamingUtils.normalizeGdmName("c car"));
        assertEquals("c_car", NamingUtils.normalizeGdmName("c       car"));
        assertEquals("c_car", NamingUtils.normalizeGdmName("c-car"));
        assertEquals("c_car", NamingUtils.normalizeGdmName("c- _ -car"));
        assertEquals("c_car", NamingUtils.normalizeGdmName("c_car_"));
        assertEquals("c_car", NamingUtils.normalizeGdmName("c_car__"));
        assertEquals("c_012345678901234567890123456789012345678901234567890123456789", NamingUtils.normalizeGdmName("c-0123456789012345678901234567890123456789012345678901234567891"));
    }
}
