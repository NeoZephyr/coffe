package com.convertlab.macore.mamgt.cdp.service;

import com.convertlab.foundation.api.gdmdata.GdmData;
import com.convertlab.foundation.api.gdmdata.GenericGdmModel;
import com.convertlab.foundation.library.gdmmeta.model.FieldType;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.macore.mamgt.cdp.mapper.GdmMetaDataMapper;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.convertlab.foundation.api.gdmdata.GenericGdmModel.DEFAULT_ID_FIELD;

@Service
@DataSourceLookup("main")
public class GdmMetaDataService {
    private final GdmMetaDataMapper gdmMetaDataMapper;
    private static final String SELECT_ALL = "*";

    public GdmMetaDataService(GdmMetaDataMapper gdmMetaDataMapper) {
        this.gdmMetaDataMapper = gdmMetaDataMapper;
    }

    @Nullable
    public GenericGdmModel selectById(@Nonnull GdmEntity gdmEntity, Object id, @Nonnull List<String> selectList) {
        GdmField pkColumn = GenericGdmModel.getPkColumn(gdmEntity);
        if (pkColumn == null) {
            throw new IllegalArgumentException("No primary key column found for entity: " + gdmEntity.getEntityName());
        }
        Object convertedId = convertTypeIfNecessary(pkColumn, id);
        if (convertedId != null) {
            id = convertedId;
        }
        List<String> newSelectList = ensurePkInSelectList(gdmEntity, pkColumn, selectList);
        Map<String, Object> result = gdmMetaDataMapper.selectById(gdmEntity.getEntityName(), newSelectList, pkColumn.getFieldName(), id);
        return result == null ? null : GenericGdmModel.buildFromMap(result, gdmEntity, GenericGdmModel.class);
    }


    @Nonnull
    public List<GenericGdmModel> selectByParams(@Nonnull GdmEntity gdmEntity, List<String> selectList, Map<String, Object> params, Integer offset, Integer limit) {
        GdmField pkColumn = GenericGdmModel.getPkColumn(gdmEntity);
        List<String> newSelectList = ensurePkInSelectList(gdmEntity, pkColumn, selectList);
        Map<String, Object> newParams = removeUnknownParams(gdmEntity, params);
        List<Map<String, Object>> result = gdmMetaDataMapper.selectByParams(gdmEntity.getEntityName(), newSelectList, newParams, offset, limit);
        return result.stream()
                .map(x -> GenericGdmModel.buildFromMap(x, gdmEntity, GenericGdmModel.class))
                .collect(Collectors.toList());
    }

    @Nonnull
    public void insert(@Nonnull GenericGdmModel entity) {
//        if (entity.getPk() == null) {
//            throw new IllegalArgumentException("TODO auto-generate id");
//        }
        GdmField pkColumn = entity.getPkColumn();
        List<String> columns = Lists.newArrayList();
        ArrayList values = new ArrayList();
        columns.add(pkColumn.getFieldName());
        values.add(entity.getPk());
        entity.getProps().forEach((k, v) -> {
            if (v != null) {
                columns.add(k);
                values.add(v);
            }
        });
        ArrayList<String> selectList = new ArrayList();
        selectList.add(SELECT_ALL);
        GdmEntity gdmEntity = entity.getGdmEntity();
        if (gdmEntity == null) {
            throw new IllegalArgumentException("No GdmEntity found for entity: " + entity.getClass().getName());
        }
        gdmMetaDataMapper.insert(gdmEntity.getEntityName(), columns, values);
    }


    public void deleteByIds(@Nonnull GdmEntity gdmEntity, List<Object> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return ;
        }
        GdmField pkField = GenericGdmModel.getPkColumn(gdmEntity);
        ids = ids.stream()
                .map(id -> {
                    Object convertedId  = convertTypeIfNecessary(pkField, id);
                    return convertedId != null ? convertedId : id;
                })
                .collect(Collectors.toList());
        gdmMetaDataMapper.deleteByIds(gdmEntity.getEntityName(), pkField.getFieldName(), ids);
    }

    public GdmData updateById(@Nonnull GenericGdmModel entity) {
        if (CollectionUtils.isEmpty(entity.getProps())) {
            return entity.toGdmData();
        }
        GdmField pkColumn = entity.getPkColumn();
        String entityName = entity.getGdmEntity().getEntityName();
        if (entityName == null) {
            throw new IllegalArgumentException("No GdmEntity found for entity: " + entity.getClass().getName());
        }
        Object pk = entity.getPk();
        if (pk == null) {
            throw new IllegalArgumentException("No primary key found for entity: " + entity.getClass().getName());
        }
        gdmMetaDataMapper.updateById(entityName, pkColumn.getFieldName(), pk, entity.getProps());
        GdmEntity gdmEntity = entity.getGdmEntity();
        List<String> selectAll = new ArrayList<>();
        selectAll.add(SELECT_ALL);
        if (gdmEntity == null) {
            throw new IllegalArgumentException("No GdmEntity found for entity: " + entity.getClass().getName());
        }
        if (pk == null) {
            throw new IllegalArgumentException("No primary key found for entity: " + entity.getClass().getName());
        }
        GenericGdmModel gdmModel = selectById(gdmEntity, pk, selectAll);
        if (gdmModel == null) {
            throw new IllegalStateException("No data found for entity: " + entity.getClass().getName());
        }
        return gdmModel.toGdmData();
    }

    @Nonnull
    private List<String> ensurePkInSelectList(@Nonnull GdmEntity gdmEntity, @Nonnull GdmField pkColumn, @Nonnull List<String> selectList) {
        List<String> list;
        GenericGdmModel gdmModel = new GenericGdmModel(gdmEntity);
        if (CollectionUtils.isEmpty(selectList)) {
            list = Lists.newArrayList();
        } else if (selectList.size() == 1 && selectList.get(0).equalsIgnoreCase(SELECT_ALL)) {
            list = gdmEntity.getFields().stream()
                    .filter(field -> !gdmModel.isPrimaryKey(field))
                    .map(x -> StringUtils.wrap(x.getFieldName(), "`"))
                    .collect(Collectors.toList());
        } else {
            list = selectList.stream()
                    .filter(x -> !DEFAULT_ID_FIELD.equalsIgnoreCase(x) && !pkColumn.getFieldName().equalsIgnoreCase(x))
                    .map(field -> StringUtils.wrap(gdmModel.getGdmField(field).getFieldName(), "`"))
                    .collect(Collectors.toList());
        }
        list.add(StringUtils.wrap(pkColumn.getFieldName(), "`") + " as " + DEFAULT_ID_FIELD);
        return list;
    }

    @Nonnull
    private Map<String, Object> removeUnknownParams(GdmEntity gdmEntity, Map<String, Object> params) {
        Map<String, Object> map = Maps.newHashMap();
        params.forEach((k, v) -> {
            GdmField gdmField = gdmEntity.getFieldsMap().get(k);
            if (gdmField != null) {
                Object converted = convertTypeIfNecessary(gdmField, v);
                map.put(k, converted == null ? v : converted);
            }
        });
        return map;
    }

    @Nullable
    private Object convertTypeIfNecessary(@Nonnull GdmField gdmField, Object value) {
        FieldType fieldType = gdmField.getFieldType();
        return GenericGdmModel.convertTypeIfNecessary(fieldType, value);
    }
}
