package com.convertlab.macore.mamgt.cdp.service;

import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.client.SimpleMetaClient;
import com.convertlab.foundation.library.gdmmeta.model.FieldType;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.gdmmeta.model.entity.GdmEntityRequest;
import com.convertlab.foundation.library.gdmmeta.model.general.BaseMetaSchema;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.BizObjectExtAttrMeta;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.base.BizObjectPropBizMeta;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Nullable;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;


@Slf4j
public class GdmBizObjectMetaService <S extends BizObjectPropBizMeta, T extends BizObjectExtAttrMeta<S>>{

    private final GsMetaClient gsMetaClient;

    public GdmBizObjectMetaService(GsMetaClient gsMetaClient) {
        this.gsMetaClient = gsMetaClient;
    }

    public static final Set<String> SYS_FIELDS_NAMES = Collections.unmodifiableSet(new HashSet<>(Arrays.asList("id",  "campaign_id", "engage_id")));

    @Nullable
    public T getGdmObjectMeta(String objectName, Class<T> clazz) {
        SimpleMetaClient objectMetaClient = gsMetaClient.simpleClientOf(BaseMetaSchema.MetaType.BIZ_OBJECTS);
        return objectMetaClient.getObject2(objectName, clazz);
    }


    /**
     * 需要根据当前 bizObjectMeta/entity/gdmTable ，来判断：
     * 当前有哪些字段已经使用了。 需要区分已经被使用的自定义字段，新添加的自定义字段，从而确定要分配的字段.
     *
     */
    public T addNewPropListToGdmObjectMeta(
            String objectName, T newObjectMeta, List<S> props) {

        //通过 bizObjMeta的 props 中元素的 enabled 来判断已经分配的和未分配的
        Map<FieldType, List<String>> newFieldIdMap = new EnumMap<>(FieldType.class);
        List<String> newFieldIds = props.stream().map(BizObjectPropBizMeta::getName).collect(Collectors.toList());
        newFieldIdMap.put(FieldType.String, newFieldIds);

        List<GdmField> newFieldList = newObjectMeta.allocatePropsAndCreateGdmFields(newFieldIdMap);
        updateAttrMeta(newObjectMeta, props);

        GdmEntity existedEntity = gsMetaClient.getEntity(objectName);
        if (existedEntity == null) {
            throw new IllegalStateException("entity not found: " + objectName);
        }
        GdmEntityRequest entityRequest = new GdmEntityRequest(existedEntity);
        entityRequest.setFields(newFieldList);

        GdmEntity gdmEntity = gsMetaClient.updateEntity(objectName, entityRequest);
        log.info("create tenant level entity {}", gdmEntity);
        SimpleMetaClient objectMetaClient = gsMetaClient.simpleClientOf(BaseMetaSchema.MetaType.BIZ_OBJECTS);
        T t = objectMetaClient.createObject2(objectName, newObjectMeta);
        log.info("create bizObjMeta {}", t);
        return t;
    }

    public Set<String> getAllocatedFieldNames(String objectName, Class<T> clazz) {
        T attrMeta = getGdmObjectMeta(objectName, clazz);
        if(attrMeta == null) {
            return SYS_FIELDS_NAMES;
        } else {
            return attrMeta.getProps().stream()
                    .filter(meta -> meta.getIsSystem() || meta.getHasOptions())
                    .map(BizObjectPropBizMeta::getName).collect(Collectors.toSet());
        }
    }

    private void updateAttrMeta(T bizObj, List<S> props) {
        List<S> currProps = bizObj.getProps();
        for (int i = 0; i < currProps.size(); i++) {
            S currProp = currProps.get(i);
            String propName = currProp.getName();
            props.stream().filter(newProp -> StringUtils.equals(propName, newProp.getName()))
                    .findFirst().ifPresent(newProp -> {
                        newProp.setHasOptions(true);
                        currProp.updateProp(newProp);
            });
        }
    }

    //update objectMeta
    public T updateGdmObjectMeta(
            String objectName, T existedBizObjMeta, List<S> props) {
        //对于已经存在 bizObjMeta 的情况，租户 level 的 entity 也已经存在，需要根据已经分配的字段情况决定如何分配新的column
        // bizObjMeta中应该已经包含了所有业务上可以使用的 props，这也就意味着，创建新的T类型的类时，需要初始化 props
        //通过 bizObjMeta的 props 中元素的 enabled 来判断已经分配的和未分配的
        List<String> newFieldIds = props.stream().map(BizObjectPropBizMeta::getName).collect(Collectors.toList());
        Map<FieldType, List<String>> newFieldNameMap = new EnumMap<>(FieldType.class);
        newFieldNameMap.put(FieldType.String, newFieldIds);
        List<GdmField> newFieldList = existedBizObjMeta.allocatePropsAndCreateGdmFields(newFieldNameMap);
        updateAttrMeta(existedBizObjMeta, props);

        GdmEntity existedEntity = gsMetaClient.getEntity(objectName);
        if (existedEntity == null) {
            throw new IllegalStateException("entity not found: " + objectName);
        }
        GdmEntityRequest updateEntityRequest = new GdmEntityRequest(existedEntity);
        updateEntityRequest.setFields(newFieldList);

        GdmEntity updatedEntity = gsMetaClient.updateEntity(objectName, updateEntityRequest);
        log.info("update entity {}", updatedEntity);
        SimpleMetaClient objectMetaClient = gsMetaClient.simpleClientOf(BaseMetaSchema.MetaType.BIZ_OBJECTS);
        T t = objectMetaClient.updateObject2(objectName, existedBizObjMeta);
        log.info("update bizObjMeta {}", t);

        return t;
    }

    //delete objectMeta
    public void deleteGdmObjectMeta(String objectName) {
        SimpleMetaClient objectMetaClient = gsMetaClient.simpleClientOf(BaseMetaSchema.MetaType.BIZ_OBJECTS);
        objectMetaClient.deleteObject(objectName);
    }


    public void addNewPropToCurrBizObject(String objectName, T currBizObject, S prop) {
        Map<FieldType, List<String>> newFieldIdMap = new EnumMap<>(FieldType.class);
        List<String> newFieldIds = Collections.singletonList(prop.getName());
        newFieldIdMap.put(FieldType.String, newFieldIds);
        List<GdmField> newFieldList = currBizObject.allocatePropsAndCreateGdmFields(newFieldIdMap);
        updateAttrMeta(currBizObject, Collections.singletonList(prop));

        GdmEntity existedEntity = gsMetaClient.getEntity(objectName);
        if (existedEntity == null) {
            throw new IllegalStateException("entity not found: " + objectName);
        }
        GdmEntityRequest entityRequest = new GdmEntityRequest(existedEntity);
        entityRequest.setFields(newFieldList);

        GdmEntity gdmEntity = gsMetaClient.updateEntity(objectName, entityRequest);
        log.info("update tenant level entity {}", gdmEntity);
        SimpleMetaClient objectMetaClient = gsMetaClient.simpleClientOf(BaseMetaSchema.MetaType.BIZ_OBJECTS);
        T t = objectMetaClient.updateObject2(objectName, currBizObject);
        log.info("update bizObjMeta {}", t);
    }

    public void createNewGdmObjectMetaWithProp(String objectName, T newBizObject, S prop) {
        Map<FieldType, List<String>> newFieldIdMap = new EnumMap<>(FieldType.class);
        List<String> newFieldIds = Collections.singletonList(prop.getName());
        newFieldIdMap.put(FieldType.String, newFieldIds);
        List<GdmField> newFieldList = newBizObject.allocatePropsAndCreateGdmFields(newFieldIdMap);
        updateAttrMeta(newBizObject, Collections.singletonList(prop));

        GdmEntity existedEntity = gsMetaClient.getEntity(objectName);
        if (existedEntity == null) {
            throw new IllegalStateException("entity not found: " + objectName);
        }
        GdmEntityRequest entityRequest = new GdmEntityRequest(existedEntity);
        entityRequest.setFields(newFieldList);

        GdmEntity gdmEntity = gsMetaClient.updateEntity(objectName, entityRequest);
        log.info("create tenant level entity {}", gdmEntity);
        SimpleMetaClient objectMetaClient = gsMetaClient.simpleClientOf(BaseMetaSchema.MetaType.BIZ_OBJECTS);
        T t = objectMetaClient.createObject2(objectName, newBizObject);
        log.info("create bizObjMeta {}", t);
    }


    //update objectMeta
    public T updateGdmObjectMetaWithUpdatedProp(
            String objectName, T existedBizObjMeta) {
        SimpleMetaClient objectMetaClient = gsMetaClient.simpleClientOf(BaseMetaSchema.MetaType.BIZ_OBJECTS);
        T t = objectMetaClient.updateObject2(objectName, existedBizObjMeta);
        log.info("updateGdmObjectMetaWithUpdatedProp: {}", t);
        return t;
    }

    public T updateGdmObjectMetaWithDeletedProp(String objectName, T currBizObject, String propName) {

        GdmEntity existedEntity = gsMetaClient.getEntity(objectName);
        if (existedEntity == null) {
            throw new IllegalStateException("entity not found: " + objectName);
        }
        GdmEntityRequest entityRequest = new GdmEntityRequest(existedEntity);
        List<GdmField> currFields = entityRequest.getFields();
        List<GdmField> fieldsAfterDeleted = currFields.stream()
                .filter(field -> !field.getFieldName().equals(propName)).collect(Collectors.toList());
        //剩余的fields里面还有系统field
        entityRequest.setFields(fieldsAfterDeleted);
        currBizObject.recycleAllocatedProps(Collections.singletonMap(FieldType.String, Collections.singletonList(propName)));
        //需要在request数据准备好之后，再更新 entity/object
        GdmEntity gdmEntity = gsMetaClient.updateEntity(objectName, entityRequest);
        log.info("updateGdmObjectMetaWithDeletedProp updateEntity: {}", gdmEntity);
        SimpleMetaClient objectMetaClient = gsMetaClient.simpleClientOf(BaseMetaSchema.MetaType.BIZ_OBJECTS);
        T t = objectMetaClient.updateObject2(objectName, currBizObject);
        log.info("updateGdmObjectMetaWithDeletedProp updateObject: {}", JsonUtils.instanceOfDto().obj2Json(currBizObject));
        return t;
    }
}
