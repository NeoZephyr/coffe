package com.convertlab.macore.mamgt.cdp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.cdp.model.entity.CustomerSearch;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface CustomerSearchMapper extends BaseMapper<CustomerSearch>{

    @Select({"<script>",
            "select name, criteria, id from customer_search",
            "</script>"})
    @ResultType(List.class)
    List<Map<String, String>> getCustomerSearchRuleList();
}
