package com.convertlab.macore.mamgt.cdp.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.cdp.model.entity.LegacyUdoFieldMeta;
import com.convertlab.macore.mamgt.cdp.model.entity.NUdoFieldMeta;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface LegacyUdoFieldMetaMapper extends BaseMapper<LegacyUdoFieldMeta> {

    @Select({"<script>",
            "SELECT * FROM udo_field_meta where type = 'BelongRef'",
            "</script>"})
    @ResultType(LegacyUdoFieldMeta.class)
    List<LegacyUdoFieldMeta> getAllBelongRefs();
}