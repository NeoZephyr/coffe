package com.convertlab.macore.mamgt.cdp.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.cdp.model.entity.Folder;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface GroupTypeMapper extends BaseMapper<Folder> {

    List<String> selectPageDtUUIDList(@Param("groupId") String groupId, @Param("operator") String operator);

    List<String> selectFormUUIDList(@Param("groupId") String groupId, @Param("operator") String operator);

    List<String> selectFileManagerUUIDList(@Param("groupId") String groupId, @Param("operator") String operator);

    List<String> selectOtherUUIDList(@Param("columnName") String columnName,@Param("groupId") String groupId, @Param("operator") String operator);

    List<String> selectQrCodeUUIDList(@Param("columnName") String columnName,@Param("groupId") String groupId, @Param("operator") String operator);

    List<String> selectWechatCardUUIDList(@Param("columnName") String columnName,@Param("groupId") String groupId, @Param("operator") String operator);

    List<String> selectSourceList(@Param("groupId") String groupId, @Param("operator") String operator);

    String selectFormFieldIdList(@Param("formUuid") String formUuid, @Param("name") String name);

    List<Map<String,String>> selectTagIdList(@Param("groupIdList") List<String> groupIdList);

    List<String> selectContentTagNameList(@Param("groupId") String groupId, @Param("operator") String operator);

    List<String> selectTagIdsByTagNames(@Param("tagNameList") List<String> tagNameList);

    List<String> selectEventsByGroup(@Param("groupNameList") List<String> groupNameList);



}