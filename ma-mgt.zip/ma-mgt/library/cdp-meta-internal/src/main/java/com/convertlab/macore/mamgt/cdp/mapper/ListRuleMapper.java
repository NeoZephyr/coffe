package com.convertlab.macore.mamgt.cdp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.cdp.model.entity.ListRule;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface ListRuleMapper extends BaseMapper<ListRule>{

    @Select({"<script>",
            "select filters, name , id from list " +
                    " where is_static = false and deleted = false " +
                    " and filters is not null and filters != '' " +
                    " and is_external = false " +
                    " and (consent_info is null or consent_info = '' ) " +
                    " and calculate_sql is null ",
            "</script>"})
    @ResultType(List.class)
    List<Map<String, String>> getValidListRuleList();

}
