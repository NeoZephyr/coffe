package com.convertlab.macore.mamgt.cdp.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.cdp.model.entity.NUdoFieldMeta;
import com.convertlab.macore.mamgt.cdp.model.entity.UdoTableMeta;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface NUdoFieldMetaMapper extends BaseMapper<NUdoFieldMeta> {

    @Select({"<script>",
            "SELECT * FROM nudo_field_meta WHERE ref_obj_id in ",
            " <foreach collection=\"refObjIds\" item=\"objId\" open=\"(\" separator=\",\" close=\")\">",
            "          #{refObjIds}",
            "  </foreach>",
            "  <if test='status!=null'>",
            "  and status = #{status}",
            "  </if>",
            "</script>"})
    @ResultType(NUdoFieldMeta.class)
    List<NUdoFieldMeta> listByRefObjId(@Param("refObjIds") List<String> refObjIds, @Param("status") String status);

    @Select({"<script>",
            "SELECT * FROM nudo_field_meta WHERE obj_id =#{objId} ",
            "  <if test='status!=null'>",
            "  and status = #{status}",
            "  </if>",
            "</script>"})
    @ResultType(NUdoFieldMeta.class)
    List<NUdoFieldMeta> listByObjId(@Param("objId") String objId, @Param("status") String status);
}