package com.convertlab.macore.mamgt.cdp.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.cdp.model.entity.UdoMeta;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface UdoMetaMapper extends BaseMapper<UdoMeta> {

    @Select({"<script>",
            "SELECT ",
            " id,type,meta",
            " FROM udo_meta WHERE type = #{type} order by version desc limit 1",
            "</script>"})
    @ResultType(UdoMeta.class)
    UdoMeta getUdoMetaByType(@Param("type") String type);

}