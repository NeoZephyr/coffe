package com.convertlab.macore.mamgt.cdp.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.cdp.model.entity.EventGroupMapping;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface EventGroupMappingMapper extends BaseMapper<EventGroupMapping> {
    @Select({"select event_name, group_name from event_group_mapping"})
    @ResultType(List.class)
    List<Map<String, String>> listEventGroupMappings();
}