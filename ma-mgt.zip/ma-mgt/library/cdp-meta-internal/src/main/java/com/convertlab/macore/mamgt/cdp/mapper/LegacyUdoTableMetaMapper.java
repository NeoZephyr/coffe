package com.convertlab.macore.mamgt.cdp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.cdp.model.entity.LegacyUdoTableMeta;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import javax.annotation.Nullable;

@Mapper
public interface LegacyUdoTableMetaMapper extends BaseMapper<LegacyUdoTableMeta> {
    @Select({"<script>",
            "SELECT * FROM udo_table_meta WHERE tbl_name =#{tblName}",
            "  <if test='status!=null'>",
            "  and status = #{status}",
            "  </if>",
            "</script>"})
    @ResultType(LegacyUdoTableMeta.class)
    LegacyUdoTableMeta getByTableName(@Param("tblName") String tblName, @Nullable @Param("status") String status);

    @Select({"<script>",
            "SELECT * FROM udo_table_meta WHERE obj_id =#{objId}",
            "  <if test='status!=null'>",
            "  and status = #{status}",
            "  </if>",
            "</script>"})
    @ResultType(LegacyUdoTableMeta.class)
    LegacyUdoTableMeta getByObjId(@Param("objId") String objId, @Param("status") String status);
}
