package com.convertlab.macore.mamgt.cdp.common;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.util.ObjectUtils;

import java.util.Arrays;

/**
 * All rights Reserved, Designed By ConvertLab
 * Author: zhiping.cai
 * Date: 2023/3/15
 * Description:
 * Copyright (C) 2022 www.convertlab.com
 */
@Getter
@RequiredArgsConstructor
public enum GroupTypeEnum {
    PAGE_DT("pageDt", "pageDt"),
    FORM("form", "form"),
    FILE("file", "file"),
    OTHER_FOLDER("otherFolder", "otherFolder"),
    QR_CODE("qrCode", "qrCode"),
    WECHAT_CARD("wechatCard", "wechatCard"),
    EVENT_GROUP("EventGroup", "EventGroup"),
    SOURCE_GROUP("sourceGroup", "sourceGroup"),
    FORM_FIELD("SubmitFormData", "SubmitFormData"),
    TAG_GROUP("TagGroup", "TagGroup"),
    CONTENT_TAG_GROUP("ContentTagGroup", "ContentTagGroup");

    private final String type;
    private final String desc;

    public static GroupTypeEnum getGroupConditionFunc(String type) {
        if (ObjectUtils.isEmpty(type)) {
            throw new IllegalArgumentException("unknown identifier type: " + type);
        }
        return Arrays.stream(GroupTypeEnum.values())
                .filter(x -> type.equals(x.getType()))
                .findAny()
                .orElseThrow(IllegalArgumentException::new);
    }
}
