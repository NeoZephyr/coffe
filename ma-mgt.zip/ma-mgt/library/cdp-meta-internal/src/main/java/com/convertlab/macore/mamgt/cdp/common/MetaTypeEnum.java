package com.convertlab.macore.mamgt.cdp.common;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Arrays;

/**
 * All rights Reserved, Designed By ConvertLab
 * Author: zhiping.cai
 * Date: 2023/3/15
 * Description:
 * Copyright (C) 2022 www.convertlab.com
 */
@Getter
@RequiredArgsConstructor
public enum MetaTypeEnum {
    CUSTOMER("customer", "customer"),
//    C_SYS_SALES_LEADS("c_sys_sales_leads", "c_sys_sales_leads"),
    UDO("udo", "udo");

    private final String type;
    private final String desc;

    public static String getMetaType(String metaName) {
        return Arrays.stream(MetaTypeEnum.values())
                .filter(metaTypeEnum -> metaTypeEnum.type.equalsIgnoreCase(metaName))
                .findFirst()
                .map(metaTypeEnum -> metaTypeEnum.type)
                .orElse("udo");
    }
}
