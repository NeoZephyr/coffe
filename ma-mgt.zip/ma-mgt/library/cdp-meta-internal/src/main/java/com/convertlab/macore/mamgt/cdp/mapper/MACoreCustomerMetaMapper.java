package com.convertlab.macore.mamgt.cdp.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.cdp.model.entity.CustomerMeta;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface MACoreCustomerMetaMapper extends BaseMapper<CustomerMeta> {

    @Select({"<script>",
            "SELECT ",
            " id,type,meta",
            " FROM customer_meta WHERE type = #{type} order by version desc limit 1",
            "</script>"})
    @ResultType(CustomerMeta.class)
    CustomerMeta getCustomerMetaByType(@Param("type") String type);

}