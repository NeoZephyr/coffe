package com.convertlab.macore.mamgt.cdp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.cdp.model.entity.DpDatapermissionRule;
import com.convertlab.macore.mamgt.cdp.model.entity.TagRule;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface DpDatapermissionRuleMapper extends BaseMapper<DpDatapermissionRule>{

    @Select({"<script>",
            "select name, filter, id from dp_datapermission_rule where resource_type = 'customer' ",
            "</script>"})
    @ResultType(List.class)
    List<Map<String, String>> getValidDpRuleList();

}
