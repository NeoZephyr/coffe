package com.convertlab.macore.mamgt.cdp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.cdp.model.entity.TagRule;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface TagRuleMapper extends BaseMapper<TagRule>{

    @Select({"<script>",
            "SELECT tr.definition, t.name, t.id FROM tag_rule tr left join tags t on tr.id = t.rule_id where tr.type='default' and t.category = 'rule_tag'",
            "</script>"})
    @ResultType(List.class)
    List<Map<String, String>> getValidTagRuleList();

}
