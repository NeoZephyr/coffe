package com.convertlab.macore.mamgt.cdp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.cdp.model.entity.CustomerStatisticsDefinition;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import java.util.List;

@Mapper
public interface CustomerStatisticsDefinitionMapper extends BaseMapper<CustomerStatisticsDefinition> {

    @Select("SELECT * FROM customer_statistics_definition WHERE type = #{type}")
    List<CustomerStatisticsDefinition> getCustomerStatisticsDefinitionByType(@Param("type") String type);

    @Select("SELECT * FROM customer_statistics_definition")
    List<CustomerStatisticsDefinition> getAllCustomerStatisticsDefinitions();
}
