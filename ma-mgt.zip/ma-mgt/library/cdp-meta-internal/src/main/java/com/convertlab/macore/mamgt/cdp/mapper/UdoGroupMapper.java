package com.convertlab.macore.mamgt.cdp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.cdp.model.entity.UdoGroup;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UdoGroupMapper  extends BaseMapper<UdoGroup> {
}
