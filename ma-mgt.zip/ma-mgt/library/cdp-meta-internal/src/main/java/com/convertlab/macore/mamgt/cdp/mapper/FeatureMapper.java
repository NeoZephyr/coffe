package com.convertlab.macore.mamgt.cdp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.cdp.model.entity.Feature;

public interface FeatureMapper extends BaseMapper<Feature> {
}
