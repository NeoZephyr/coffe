package com.convertlab.macore.mamgt.cdp.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.macore.mamgt.cdp.model.entity.UdoTableMeta;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface NUdoTableMetaMapper extends BaseMapper<UdoTableMeta> {

    @Select({"<script>",
            "SELECT * FROM nudo_table_meta WHERE obj_id =#{objId}",
            "  <if test='status!=null'>",
            "  and status = #{status}",
            "  </if>",
            "</script>"})
    @ResultType(UdoTableMeta.class)
    UdoTableMeta getByObjId(@Param("objId") String objId, @Param("status") String status);
}