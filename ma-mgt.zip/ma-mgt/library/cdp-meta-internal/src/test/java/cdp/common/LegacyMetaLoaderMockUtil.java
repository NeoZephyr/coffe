package cdp.common;

import com.convertlab.foundation.api.gdm.pattern.GdmModelClient;
import com.convertlab.macore.mamgt.cdp.mapper.*;
import com.convertlab.macore.mamgt.cdp.misc.loader.legacy.LegacyMetaLoader;
import com.convertlab.macore.mamgt.cdp.model.entity.UdoTableMeta;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;


@ExtendWith(MockitoExtension.class)
public class LegacyMetaLoaderMockUtil {
    public static LegacyMetaLoader mockLegacyMetaLoader() throws Exception {
        MACoreCustomerMetaMapper customerMetaMapper = MapperMockUtil.getMockMACoreCustomerMetaMapper();
        CustomerStatisticsDefinitionMapper customerStatisticsDefinitionMapper = MapperMockUtil.getMockCustomerStatisticsDefinitionMapper();
        UdoMetaMapper udoMetaMapper = MapperMockUtil.getMockUdoMetaMapper();
        NUdoFieldMetaMapper udoFieldMetaMapper = MapperMockUtil.getMockNUdoFieldMetaMapper();
        NUdoTableMetaMapper udoTableMetaMapper = MapperMockUtil.getMockNUdoTableMetaMapper();

        LegacyMetaLoader instance = new LegacyMetaLoader(customerMetaMapper,
                customerStatisticsDefinitionMapper,
                udoMetaMapper,
                udoFieldMetaMapper,
                udoTableMetaMapper,
                null);
        LegacyMetaLoader spy = Mockito.spy(instance);

        UdoTableMeta tableMeta = udoTableMetaMapper.getByObjId("c_car", "normal");
        Map<String, Object> map = new HashMap<>();
        map.put("id", tableMeta.getId());
        map.put("objId", tableMeta.getObjId());
        map.put("name", tableMeta.getName());
        map.put("tableName", tableMeta.getTblName());
        map.put("type", tableMeta.getType());

        Mockito.lenient().doReturn(Arrays.asList(map)).when(spy).getUdoTableMeta();
        return spy;
    }

}
