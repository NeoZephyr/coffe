package cdp.common;

import com.convertlab.foundation.library.gdmmeta.client.GsMetaClientWrapper;
import com.convertlab.foundation.library.gdmmeta.client.SimpleMetaClient;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.general.BaseMetaSchema;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.associated.ProfileEventBizMeta;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.mockito.ArgumentMatchers.any;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@ExtendWith(MockitoExtension.class)
public class GsMetaClientWrapperMockUtil {

    final static ConcurrentHashMap<String, ProfileEventBizMeta> tempEvents = new ConcurrentHashMap();

    public static GsMetaClientWrapper mockGsMetaClientWrapper(){
        GsMetaClientWrapper mockGsMetaClientWrapper = Mockito.mock(GsMetaClientWrapper.class);
        Mockito.lenient().when(mockGsMetaClientWrapper.getEntity(any(String.class))).thenAnswer(arg -> {
            String entityName = arg.getArgument(0);
            return getEntity(entityName);
        });

        Mockito.lenient().when(mockGsMetaClientWrapper.getEntityMapByNames(any(List.class))).thenAnswer(arg -> {
            List<String> entityNames = arg.getArgument(0);
            return getEntityMapByNames(entityNames);
        });

        Mockito.lenient().when(mockGsMetaClientWrapper.simpleClientOf(any(BaseMetaSchema.MetaType.class))).thenAnswer(arg -> {
            BaseMetaSchema.MetaType metaType = arg.getArgument(0);
            return simpleClientOf(metaType);
        });
        return mockGsMetaClientWrapper;
    }

    public static GdmEntity getEntity(String entityName) throws Exception{
        return JsonLoader.sharedJsonLoader().config2Obj(String.format("migration/entity/%s.json", entityName), GdmEntity.class);
    }

    public static Map<String, GdmEntity> getEntityMapByNames(List<String> entityNames)  throws Exception{
        Map<String, Map<String, Object>> response = JsonLoader.sharedJsonLoader().config2Obj("migration/entity/entitiy_map.json", Map.class);
        Map<String, GdmEntity> result = new LinkedHashMap();
        for(String key : response.keySet()){
            Map<String, Object> data = response.get(key);
            GdmEntity entity = JsonUtils.instanceOfDto().convertFromMap(data, GdmEntity.class);
            result.put(key, entity);
        }
        return result;
    }

    public static SimpleMetaClient simpleClientOf(BaseMetaSchema.MetaType metaType) {
        SimpleMetaClient mockSimpleClient = Mockito.mock(SimpleMetaClient.class);
        Mockito.lenient().when(mockSimpleClient.queryObjects2(any(Map.class), any())).thenAnswer(arg -> {
            Map query = arg.getArgument(0);
            Class clazz = arg.getArgument(1);
            String objectName = (String) query.get("objectName");
            if (objectName != null) {
                return JsonLoader.sharedJsonLoader().config2List(String.format("migration/%s/%s.json", metaType.getCollectionName(), objectName), clazz);
            } else {
                return Arrays.asList();
            }
        });

        Mockito.lenient().when(mockSimpleClient.createObject2(any(String.class), any(ProfileEventBizMeta.class)))
                .thenAnswer(arg -> {
                    String objectName = arg.getArgument(0);
                    ProfileEventBizMeta event = arg.getArgument(1);
                    tempEvents.put(objectName, event);
                    return event;
                });

        return mockSimpleClient;
    }

    public static void cleanTempEvents() {
        tempEvents.clear();
    }

    public static Map<String, ProfileEventBizMeta> getTempEvents() {
        return tempEvents;
    }
}
