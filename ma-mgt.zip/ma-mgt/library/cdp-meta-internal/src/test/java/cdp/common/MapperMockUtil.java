package cdp.common;

import com.convertlab.macore.mamgt.cdp.mapper.*;
import com.convertlab.macore.mamgt.cdp.model.entity.CustomerMeta;
import com.convertlab.macore.mamgt.cdp.model.entity.NUdoFieldMeta;
import com.convertlab.macore.mamgt.cdp.model.entity.UdoMeta;
import com.convertlab.macore.mamgt.cdp.model.entity.UdoTableMeta;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
public class MapperMockUtil {
    public static NUdoTableMetaMapper getMockNUdoTableMetaMapper(){
        NUdoTableMetaMapper mock = Mockito.mock(NUdoTableMetaMapper.class);
        Mockito.lenient().when(mock.getByObjId(any(String.class), any(String.class))).thenAnswer(arg -> {
            String objId = arg.getArgument(0);
            return JsonLoader.sharedJsonLoader().config2Obj(String.format("migration/mapper/udo_table_meta/%s.json", objId), UdoTableMeta.class);
        });
        return mock;
    }

    public static MACoreCustomerMetaMapper getMockMACoreCustomerMetaMapper() {
        MACoreCustomerMetaMapper mock = Mockito.mock(MACoreCustomerMetaMapper.class);
        Mockito.lenient().when(mock.getCustomerMetaByType(any(String.class)))
                .thenAnswer(arg -> {
                   String type = arg.getArgument(0);
                    CustomerMeta result = new CustomerMeta();
                    result.setType(type);
                    result.setMeta(JsonLoader.sharedJsonLoader().config2String(String.format("migration/legacy-meta/customer/%s.json", type)));
                    return result;
                });
        return mock;
    }

    public static CustomerStatisticsDefinitionMapper getMockCustomerStatisticsDefinitionMapper(){
        CustomerStatisticsDefinitionMapper mock = Mockito.mock(CustomerStatisticsDefinitionMapper.class);
        Mockito.lenient().when(mock.getCustomerStatisticsDefinitionByType(any(String.class)))
                .thenAnswer(arg -> {
                    String type = arg.getArgument(0);
                    CustomerMeta result = new CustomerMeta();
                    result.setType(type);
                    result.setMeta(JsonLoader.sharedJsonLoader().config2String("migration/mapper/customer_statistics_definition.json"));
                    return result;
                });
        return mock;
    }

    public static UdoMetaMapper getMockUdoMetaMapper() throws Exception {
        UdoMetaMapper mock = Mockito.mock(UdoMetaMapper.class);
        Mockito.lenient().when(mock.getUdoMetaByType(any(String.class)))
                .thenAnswer(arg -> {
                    String type = arg.getArgument(0);
                    UdoMeta result = new UdoMeta();
                    result.setType(type);
                    result.setMeta(JsonLoader.sharedJsonLoader().config2String(String.format("migration/legacy-meta/c_car/%s.json", type)));
                    return result;
                });
        return mock;
    }

    public static NUdoFieldMetaMapper getMockNUdoFieldMetaMapper() throws Exception {
        NUdoFieldMetaMapper mock = Mockito.mock(NUdoFieldMetaMapper.class);
        Mockito.lenient().when(mock.listByObjId(any(String.class), any(String.class)))
                .thenAnswer(arg -> {
                    return JsonLoader.sharedJsonLoader().config2List("migration/mapper/udo_field_meta/c_car.json", NUdoFieldMeta.class);
                });
        return mock;
    }
}
