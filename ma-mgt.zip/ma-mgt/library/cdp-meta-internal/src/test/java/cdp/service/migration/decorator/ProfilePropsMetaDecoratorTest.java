package cdp.service.migration.decorator;

import cdp.common.GdmModelClientMockUtil;
import cdp.common.GsMetaClientWrapperMockUtil;
import cdp.common.LegacyMetaLoaderMockUtil;
import cdp.common.MapperMockUtil;
import com.convertlab.foundation.api.gdm.pattern.GdmModelClient;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClientWrapper;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.mamgt.cdp.client.GdmModelClientWrapper;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.GeneralProfileBizMeta;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.PrimaryProfileBizMeta;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.associated.ProfilePropBizMeta;
import com.convertlab.macore.mamgt.cdp.mapper.NUdoTableMetaMapper;
import com.convertlab.macore.mamgt.cdp.misc.loader.legacy.LegacyMetaLoader;
import com.convertlab.macore.mamgt.cdp.service.migration.decorator.ProfilePropsMetaDecorator;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;

import static com.convertlab.macore.mamgt.cdp.common.constants.ProfileConstants.PROFILE_CUSTOMER;

@ExtendWith(MockitoExtension.class)
class ProfilePropsMetaDecoratorTest {

    private GsMetaClientWrapper mockGsMetaClient;
    private GdmModelClientWrapper mockGdmModelClient;
    private LegacyMetaLoader legacyMetaLoader;
    private NUdoTableMetaMapper mockUdoTableMetaMapper;

    private ProfilePropsMetaDecorator profilePropsMetaDecoratorUnderTest;

    @BeforeEach
    void setUp() throws Exception{
        mockGsMetaClient = GsMetaClientWrapperMockUtil.mockGsMetaClientWrapper();
        mockGdmModelClient = GdmModelClientMockUtil.mockGdmModelClient();
        mockUdoTableMetaMapper = MapperMockUtil.getMockNUdoTableMetaMapper();
        legacyMetaLoader = LegacyMetaLoaderMockUtil.mockLegacyMetaLoader();
        profilePropsMetaDecoratorUnderTest = new ProfilePropsMetaDecorator(mockGsMetaClient, mockGdmModelClient,
                legacyMetaLoader);
    }

    @Test
    void testDecoratePrimaryProfile() {
        PrimaryProfileBizMeta primaryProfileBizMeta = new PrimaryProfileBizMeta();
        primaryProfileBizMeta.setObjId(PROFILE_CUSTOMER);
        primaryProfileBizMeta.setName("客户");
        profilePropsMetaDecoratorUnderTest.decorateProfile(primaryProfileBizMeta);
        Assertions.assertTrue(primaryProfileBizMeta.getProps().size()>0);
        // 自定义属性,带codelist
        ProfilePropBizMeta attr1 = getProp("attr1", primaryProfileBizMeta.getProps());
        Assertions.assertNotNull(attr1);
        Assertions.assertTrue(attr1.getIsAttr());
        Assertions.assertFalse(attr1.getIsSystem());
        Assertions.assertTrue(attr1.getFilterable());
        Assertions.assertTrue(attr1.getInDetailView());
        Assertions.assertTrue(attr1.getInForm());
        Assertions.assertTrue(attr1.getIsDropdown());
        Assertions.assertTrue(attr1.getFrontendEditable());
        Assertions.assertTrue(attr1.getRegular());
        Assertions.assertTrue(attr1.getDimension());
        Assertions.assertTrue(attr1.getExportable());
        Assertions.assertTrue(attr1.getValuable());
        Assertions.assertFalse(attr1.getRequired());

        Assertions.assertNotNull(attr1.getMeta());
        Assertions.assertEquals("code_list", attr1.getMeta().getRefObjId());
        Assertions.assertEquals("customer.attr1", attr1.getMeta().getType());
        Assertions.assertEquals("Text", attr1.getType());
        Assertions.assertEquals("String", attr1.getInnerType());
        Assertions.assertEquals("车型偏好", attr1.getLabel());

        // 查找关系类型自定义属性，指向一个存在的udo
        ProfilePropBizMeta attr2 = getProp("attr2", primaryProfileBizMeta.getProps());
        Assertions.assertNotNull(attr2);
        Assertions.assertEquals("LookupRef", attr2.getType());
        Assertions.assertNotNull(attr2.getMeta());
        Assertions.assertEquals("c_car", attr2.getMeta().getRefObjId());
        Assertions.assertEquals("bk", attr2.getMeta().getRefFieldId());
        Assertions.assertEquals("司机", attr2.getBackwardName());
        Map<String, Object> responseJson = JsonUtils.instanceOfDto().convertToMap(attr2);
        Assertions.assertTrue(responseJson.containsKey("sensitive") && (Boolean) responseJson.get("sensitive") == false);


        // 字符串类型属性
        ProfilePropBizMeta attr7 = getProp("attr7", primaryProfileBizMeta.getProps());
        Assertions.assertNotNull(attr7);
        Assertions.assertEquals("Text", attr7.getType());
        Assertions.assertNotNull(attr7.getMeta());
        Assertions.assertEquals("String", attr7.getMeta().getType());
        Assertions.assertTrue(attr7.getFrontendEditable());
        Assertions.assertTrue(attr7.getFilterable());
        Map<String, Object> responseJson6 = JsonUtils.instanceOfDto().convertToMap(attr7);
        Assertions.assertTrue(responseJson6.containsKey("sensitive") && (Boolean) responseJson6.get("sensitive") == true);


        // 查找关系类型自定义属性，指向一个不存在的udo
        ProfilePropBizMeta attr3 = getProp("attr3", primaryProfileBizMeta.getProps());
        Assertions.assertNull(attr3);

        // used == false的属性
        ProfilePropBizMeta attr8 = getProp("attr8", primaryProfileBizMeta.getProps());
        Assertions.assertNull(attr8);

    }

    @Test
    void testDecorateGeneralProfile(){
        GeneralProfileBizMeta generalProfileBizMeta = new GeneralProfileBizMeta();
        generalProfileBizMeta.setObjId("c_car");
        generalProfileBizMeta.setName("汽车");
        profilePropsMetaDecoratorUnderTest.decorateProfile(generalProfileBizMeta);
        Assertions.assertTrue(generalProfileBizMeta.getProps().size()>0);

        // bk
        ProfilePropBizMeta bk = getProp("bk", generalProfileBizMeta.getProps());
        Assertions.assertNotNull(bk);
        Assertions.assertTrue(bk.getIsSystem());
        Assertions.assertTrue(bk.getFilterable());
        Assertions.assertFalse(bk.getIsAttr());
        Assertions.assertFalse(bk.getFrontendEditable());
        Assertions.assertTrue(bk.getInDetailView());
        Assertions.assertTrue(bk.getInForm());
        Assertions.assertFalse(bk.getIsDropdown());
        Assertions.assertTrue(bk.getRegular());
        Assertions.assertTrue(bk.getDimension());
        Assertions.assertTrue(bk.getExportable());
        Assertions.assertTrue(bk.getRequired());

        Assertions.assertNotNull(bk.getMeta());
        Assertions.assertEquals("Text", bk.getType());
        Assertions.assertEquals("String", bk.getInnerType());
        Assertions.assertEquals("ID", bk.getLabel());

        // c_vin
        ProfilePropBizMeta c_vin = getProp("c_vin", generalProfileBizMeta.getProps());
        Assertions.assertNotNull(c_vin);
        Assertions.assertFalse(c_vin.getIsSystem());
        Assertions.assertTrue(c_vin.getIsAttr());
        Assertions.assertEquals("Text", c_vin.getType());
        Assertions.assertTrue(c_vin.getRequired());
        Assertions.assertFalse(c_vin.getFilterable());
        Assertions.assertTrue(c_vin.getFrontendEditable());
        Assertions.assertFalse(c_vin.getHasOptions());
        Assertions.assertTrue(c_vin.getInDetailView());
        Assertions.assertTrue(c_vin.getInForm());
        Assertions.assertFalse(c_vin.getIsDropdown());
        Assertions.assertTrue(c_vin.getRegular());
        Assertions.assertTrue(c_vin.getDimension());
        Assertions.assertTrue(c_vin.getExportable());
        Assertions.assertTrue(c_vin.getRequired());
    }



    private ProfilePropBizMeta getProp(String propName, List<ProfilePropBizMeta> props){
        return props.stream().filter(it-> it.getName().equals(propName)).findFirst().orElse(null);
    }

}
