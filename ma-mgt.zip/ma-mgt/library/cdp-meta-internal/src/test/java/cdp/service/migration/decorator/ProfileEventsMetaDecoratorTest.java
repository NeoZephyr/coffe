//package cdp.service.migration.decorator;
//
//import cdp.common.GdmModelClientMockUtil;
//import cdp.common.GsMetaClientWrapperMockUtil;
//import cdp.common.JsonLoader;
//import cdp.common.LegacyMetaLoaderMockUtil;
//import com.convertlab.foundation.library.gdmmeta.client.GsMetaClientWrapper;
//import com.convertlab.macore.mamgt.cdp.client.GdmModelClientWrapper;
//import com.convertlab.macore.mamgt.cdp.dto.bizmeta.PrimaryProfileBizMeta;
//import com.convertlab.macore.mamgt.cdp.dto.bizmeta.associated.ProfileEventBizMeta;
//import com.convertlab.macore.mamgt.cdp.misc.loader.legacy.LegacyMetaLoader;
//import com.convertlab.macore.mamgt.cdp.service.migration.decorator.ProfileEventsMetaDecorator;
//import lombok.extern.slf4j.Slf4j;
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import java.lang.reflect.Field;
//import java.util.*;
//import java.util.stream.Collectors;
//import java.util.stream.Stream;
//
//import static com.convertlab.macore.mamgt.cdp.common.constants.ProfileConstants.PROFILE_CUSTOMER;
//
//@ExtendWith(MockitoExtension.class)
//@Slf4j
//class ProfileEventsMetaDecoratorTest {
//
//    private GsMetaClientWrapper mockGsMetaClient;
//    private GdmModelClientWrapper mockGdmModelClient;
//    private LegacyMetaLoader legacyMetaLoader;
//
//    private ProfileEventsMetaDecorator profileEventsMetaDecoratorUnderTest;
//
//    @BeforeEach
//    void setUp() throws Exception {
//        mockGsMetaClient = GsMetaClientWrapperMockUtil.mockGsMetaClientWrapper();
//        mockGdmModelClient = GdmModelClientMockUtil.mockGdmModelClient();
//        legacyMetaLoader = LegacyMetaLoaderMockUtil.mockLegacyMetaLoader();
//        profileEventsMetaDecoratorUnderTest = new ProfileEventsMetaDecorator(mockGsMetaClient, mockGdmModelClient,
//                legacyMetaLoader);
//    }
//
//    @Test
//    void testDecoratePrimaryProfile() throws Exception{
//        PrimaryProfileBizMeta primaryProfileBizMeta = new PrimaryProfileBizMeta();
//        primaryProfileBizMeta.setObjId(PROFILE_CUSTOMER);
//        primaryProfileBizMeta.setName("客户");
//        // 清空mock metaStore
//        GsMetaClientWrapperMockUtil.cleanTempEvents();
//        profileEventsMetaDecoratorUnderTest.decorateProfile(primaryProfileBizMeta);
//        // 读取mock metaStore待写入的事件 meta
//        Map<String, ProfileEventBizMeta> events = GsMetaClientWrapperMockUtil.getTempEvents();
//        // 事件的bizMeta不存储在primaryProfileBizMeta中
//        Assertions.assertNull(primaryProfileBizMeta.getEvents());
//        Assertions.assertTrue(events.size() >0);
//
//        // 事件数量跟foundation model 一致, 且事件名字一致
//        Set<String> modelEventNames = Arrays.stream(mockGdmModelClient.findByName(PROFILE_CUSTOMER).getProps().getEvents()).map(i->i.getEventId())
//                .collect(Collectors.toSet());
//        Set<String> migrationEventNames = events.keySet().stream().map(it -> it).collect(Collectors.toSet());
//        Set<String> migrationEventNames2 = migrationEventNames.stream().map(it ->it).collect(Collectors.toSet());
//        migrationEventNames.removeAll(modelEventNames);
//        Assertions.assertEquals(0, migrationEventNames.size());
//        modelEventNames.removeAll(migrationEventNames2);
//        // GDM的任意事件定义，BiMeta并没有用到，而是调用接口返回事件运行时插入了一个；此处不计入
//        modelEventNames.remove("customer_event");
//        Assertions.assertEquals(0, modelEventNames.size());
//
//        // 事件定义跟customer服务的 meta/customer 接口一致,
////        Map<String, Map<String, Object>> expectationCustomerEventMaps = loadExpectationCustomerEventMaps();
////        for(String eventName: events.keySet()){
////            ProfileEventBizMeta eventBizMeta = events.get(eventName);
////            Map<String, Object> matchedEventInLegacyApi = expectationCustomerEventMaps.get(eventName);
////            Assertions.assertNotNull(matchedEventInLegacyApi, eventName + " does not exist in meta/customer api");
////
////            compareEventFields(eventBizMeta, Stream.of("props").collect(Collectors.toSet()),
////                    matchedEventInLegacyApi, Stream.of("enLabel", "twLabel", "enTitle", "twTitle", "attr1").collect(Collectors.toSet()));
////        }
//    }
//
//    /**
//     * 数据取自master环境207042租户的 meta/customer 接口；共 129个事件
//     * 系统事件： 121个
//     * 插件事件： cp_webinar_event_submit，cp_webinar_event_watch，cp_webinar_event_survey， cp_webinar_event_chat，
//     * cp_webinar_event_sign， cp_webinar_event_lottery， cp_webinar_event_playback
//     * 自定义事件：c_graduate
//     * @return
//     * @throws Exception
//     */
//    private Map<String, Map<String, Object>> loadExpectationCustomerEventMaps() throws Exception {
//        return JsonLoader.sharedJsonLoader().config2Obj("migration/expectation/meta_customer_event.json", Map.class);
//    }
//
//    private <T> void compareEventFields (T dto,
//                                    Set<String> excludeFieldsFrom,
//                                    Map<String, Object> expectMapData,
//                                    Set<String> excludeFieldsExpected) throws Exception {
//        //  校验 Dto类的属性，Map里面都有
//        Field[] fields = dto.getClass().getDeclaredFields();
//        for(Field field : fields){
//            String fieldName = field.getName();
//            if(excludeFieldsFrom.contains(fieldName)){
//                continue;
//            }
//            if(!expectMapData.containsKey(fieldName)){
//                log.error(fieldName + " does not exist in meta/customer api");
//                continue;
//            }
//            field.setAccessible(true);
//            Object value = field.get(dto);
//            if(!value.equals(expectMapData.get(fieldName))) {
//                log.error(fieldName + "'s value is not equal to the value in meta/customer api", value, expectMapData.get(fieldName));
//            }
//        }
//
//        // 校验 Map里面的属性，排除掉已知不需要的，Dto 里面都有
//        for(String key : expectMapData.keySet()){
//            if(excludeFieldsExpected.contains(key)){
//                continue;
//            }
//            Field matchedField = Arrays.stream(fields).filter(field -> field.getName().equals(key)).findFirst().orElse(null);
//            if(matchedField == null){
//                log.error(key + " does not exist in ProfileEventBizMeta");
//                continue;
//            }
//            matchedField.setAccessible(true);
//            Object value = matchedField.get(dto);
//            if(!value.equals(expectMapData.get(key))) {
//                log.error(key + "'s value is not equal to the value in meta/customer api", value, expectMapData.get(key));
//            }
//        }
//    }
//
////    @Test
////    void testDecorateGeneralProfile(){
////        GeneralProfileBizMeta generalProfileBizMeta = new GeneralProfileBizMeta();
////        generalProfileBizMeta.setObjId("c_car");
////        generalProfileBizMeta.setName("汽车");
////    }
//}
