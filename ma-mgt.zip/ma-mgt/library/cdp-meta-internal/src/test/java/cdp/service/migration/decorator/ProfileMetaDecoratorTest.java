package cdp.service.migration.decorator;

import cdp.common.GdmModelClientMockUtil;
import cdp.common.GsMetaClientWrapperMockUtil;
import cdp.common.MapperMockUtil;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClientWrapper;
import com.convertlab.macore.mamgt.cdp.client.GdmModelClientWrapper;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.GeneralProfileBizMeta;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.PrimaryProfileBizMeta;
import com.convertlab.macore.mamgt.cdp.mapper.NUdoTableMetaMapper;
import com.convertlab.macore.mamgt.cdp.service.migration.decorator.ProfileMetaDecorator;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.convertlab.macore.mamgt.cdp.common.constants.ProfileConstants.PROFILE_CUSTOMER;

@ExtendWith(MockitoExtension.class)
class ProfileMetaDecoratorTest {

    private GsMetaClientWrapper mockGsMetaClient;
    private GdmModelClientWrapper mockGdmModelClient;
    private NUdoTableMetaMapper mockUdoTableMetaMapper;

    private ProfileMetaDecorator profileMetaDecoratorUnderTest;

    @BeforeEach
    void setUp() {
        mockGsMetaClient = GsMetaClientWrapperMockUtil.mockGsMetaClientWrapper();
        mockGdmModelClient = GdmModelClientMockUtil.mockGdmModelClient();
        mockUdoTableMetaMapper = MapperMockUtil.getMockNUdoTableMetaMapper();
        profileMetaDecoratorUnderTest = new ProfileMetaDecorator(mockGsMetaClient, mockGdmModelClient,
                mockUdoTableMetaMapper);
    }

    @Test
    void testDecoratePrimaryProfile() {
        PrimaryProfileBizMeta primaryProfileBizMeta = new PrimaryProfileBizMeta();
        primaryProfileBizMeta.setObjId(PROFILE_CUSTOMER);
        primaryProfileBizMeta.setName("客户");
        profileMetaDecoratorUnderTest.decorateProfile(primaryProfileBizMeta);
        Assertions.assertTrue( primaryProfileBizMeta.getPatterns().contains("primary-profile"));
        Assertions.assertEquals("客户", primaryProfileBizMeta.getDescription());
        Assertions.assertEquals("客户", primaryProfileBizMeta.getName());
        Assertions.assertEquals("/v1/meta/gdm/entities/customer", primaryProfileBizMeta.getEntity().get_ref());
        Assertions.assertEquals("/v1/meta/gdm/gdm-models/customer", primaryProfileBizMeta.getModel().get_ref());
        Assertions.assertEquals("customer", primaryProfileBizMeta.getBusinessId());
        Assertions.assertEquals("", primaryProfileBizMeta.getIcon());
        Assertions.assertEquals("normal", primaryProfileBizMeta.getStatus());
    }

    @Test
    void testDecorateGeneralProfile(){
        GeneralProfileBizMeta generalProfileBizMeta = new GeneralProfileBizMeta();
        generalProfileBizMeta.setObjId("c_car");
        generalProfileBizMeta.setName("汽车");
        profileMetaDecoratorUnderTest.decorateProfile(generalProfileBizMeta);
        Assertions.assertTrue( generalProfileBizMeta.getPatterns().contains("general-profile"));
        Assertions.assertEquals("汽车UDO", generalProfileBizMeta.getDescription());
        Assertions.assertEquals("汽车", generalProfileBizMeta.getName());
        Assertions.assertEquals("/v1/meta/gdm/entities/c_car", generalProfileBizMeta.getEntity().get_ref());
        Assertions.assertEquals("/v1/meta/gdm/gdm-models/c_car", generalProfileBizMeta.getModel().get_ref());
        Assertions.assertEquals("c_car", generalProfileBizMeta.getBusinessId());
        Assertions.assertEquals("cl:gongdan,#00a870", generalProfileBizMeta.getIcon());
        Assertions.assertEquals("normal", generalProfileBizMeta.getStatus());
    }
}
