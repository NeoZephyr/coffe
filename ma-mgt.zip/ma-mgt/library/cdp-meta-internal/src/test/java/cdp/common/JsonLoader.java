package cdp.common;

import com.convertlab.foundation.library.utils.JsonUtils;
import org.apache.commons.io.IOUtils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class JsonLoader {
    private static JsonLoader instance;
    private JsonLoader() {
    }
    private String normalPath(String configPath){
        if(configPath.startsWith("/")) {
            return configPath;
        }else{
            return "/" + configPath;
        }
    }
    public synchronized static JsonLoader sharedJsonLoader() {
        if(instance == null){
            instance = new JsonLoader();
        }
        return instance;
    }

    public <T> T config2Obj(String configPath, Class<T> clazz) throws Exception {
        InputStream is = this.getClass().getResourceAsStream(normalPath(configPath));
        if(is !=null) {
            return JsonUtils.instanceOfDto().json2Obj(IOUtils.toString(is, StandardCharsets.UTF_8), clazz);
        }else{
            throw new FileNotFoundException(normalPath(configPath) + " not found.");
        }
    }

    public <T> List<T> config2List(String configPath, Class<T> clazz) throws Exception {
        InputStream is = this.getClass().getResourceAsStream(normalPath(configPath));
        if(is !=null) {
            return JsonUtils.instanceOfDto().json2List(IOUtils.toString(is, StandardCharsets.UTF_8), clazz);
        }else{
            throw new FileNotFoundException(normalPath(configPath) + " not found.");
        }
    }

    public String config2String(String configPath) throws Exception {
        InputStream is = this.getClass().getResourceAsStream(normalPath((configPath)));
        if(is !=null) {
            return IOUtils.toString(is, StandardCharsets.UTF_8);
        }else{
            throw new FileNotFoundException(normalPath(configPath) + " not found.");
        }
    }
}
