package cdp.common;

import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.macore.mamgt.cdp.client.GdmModelClientWrapper;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
public class GdmModelClientMockUtil {
    public static GdmModelClientWrapper mockGdmModelClient() {
        GdmModelClientWrapper mockGdmModelClientMock = Mockito.mock(GdmModelClientWrapper.class);
        Mockito.lenient().when(mockGdmModelClientMock.findByName(any(String.class))).thenAnswer(arg -> {
            String modelName = arg.getArgument(0);
            return findByName(modelName);
        });
        return mockGdmModelClientMock;
    }

    public static GdmModelDto findByName(String modelName) throws Exception {
        return JsonLoader.sharedJsonLoader().config2Obj(String.format("migration/model/%s.json", modelName), GdmModelDto.class);
    }
}
