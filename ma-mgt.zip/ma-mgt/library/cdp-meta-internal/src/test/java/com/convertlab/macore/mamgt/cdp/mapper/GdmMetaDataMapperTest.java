package com.convertlab.macore.mamgt.cdp.mapper;

import com.convertlab.foundation.api.gdmdata.GenericGdmModel;
import com.convertlab.foundation.library.constant.DataProcessingMode;
import com.convertlab.foundation.library.gdmmeta.model.FieldType;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.gdmmeta.model.ImmutableGdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.ImmutableGdmField;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Disabled("临时跳过没有完成的测试")
@ExtendWith(MockitoExtension.class)
public class GdmMetaDataMapperTest {

    private static final String CAMPAIGN_ENGAGE_ATTRIBUTE = "campaign_engage_attribute";
    public static final String[] MOCK_FIELD_NAMES = {"id", "campaign_id", "engage_id", "c_channel", "c_group"};
    @InjectMocks
    private GdmMetaDataMapper gdmMetaDataMapper;

    @Mock
    private SqlSessionTemplate sqlSessionTemplate;

    @Test
    public void testSelectById() {
        // Arrange
        String entityName = "exampleEntity";
        List<String> selectList = Arrays.asList("column1", "column2");
        String pkColumn = "exampleId";
        Object id = 123;
        Map<String, Object> expectedResult = new HashMap<>();
        expectedResult.put("column1", "value1");
        expectedResult.put("column2", "value2");

        when(sqlSessionTemplate.selectOne(any(), any())).thenReturn(expectedResult);

        // Act
        Map<String, Object> result = gdmMetaDataMapper.selectById(entityName, selectList, pkColumn, id);

        // Assert
        assertEquals(expectedResult, result);
    }


    @Test
    void insert_and_findByUsername() {
        GdmEntity gdmEntity = newCampaignEngageAttributeEntity();
        SqlSessionFactory sqlSessionFactory = getSqlSessionFactory(GdmMetaDataMapper.class);
        try (SqlSession session = sqlSessionFactory.openSession()) {
            GdmMetaDataMapper dataMapper = session.getMapper(GdmMetaDataMapper.class);
            Map<String, Object> dataMap = getStringObjectMap();
            GenericGdmModel gdmDataModel = new GenericGdmModel(gdmEntity);
            gdmDataModel.setPk(null);
            gdmDataModel.props.putAll(dataMap);

            dataMapper.insert(CAMPAIGN_ENGAGE_ATTRIBUTE, Arrays.asList(MOCK_FIELD_NAMES), Arrays.asList(null, 1, 11, "sms", "VIP-A"));

        }
    }

    private static Map<String, Object> getStringObjectMap() {
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put("campaign_id", 17911);
        dataMap.put("engage_id", 1109);
        dataMap.put("c_channel", "sms");
        dataMap.put("c_group", "VIP-A");
        return dataMap;
    }


    private GdmEntity newCampaignEngageAttributeEntity() {
         List<GdmField> fields = Stream.of(MOCK_FIELD_NAMES)
                .map(fieldName -> ImmutableGdmField.builder()
                        .fieldName(fieldName)
                        .fieldType(Arrays.asList("id", "campaign_id", "engage_id")
                                .contains(fieldName) ? FieldType.Long : FieldType.String)
                        .build())
                .collect(Collectors.toList());
        return ImmutableGdmEntity.builder()
                .entityName(CAMPAIGN_ENGAGE_ATTRIBUTE).fields(fields)
                .primaryKeyField("id")
                .dataProcessingModes(Collections.singletonList(DataProcessingMode.OLTP))
                .isDbView(false)
                .dbTableName(CAMPAIGN_ENGAGE_ATTRIBUTE)
                .tablePartition(null)
                .isSystem(true)
                .deletable(true)
                .modifiable(true)
                .build();

    }


    private static SqlSessionFactory getSqlSessionFactory(Class<GdmMetaDataMapper> mapper) {
        EmbeddedDatabaseBuilder embeddedDatabaseBuilder = new EmbeddedDatabaseBuilder();
        embeddedDatabaseBuilder
                .setType(EmbeddedDatabaseType.H2)
                .setName("test")
                .addScript("classpath:schema.sql");

        Environment environment =
                new Environment("development", new JdbcTransactionFactory(), embeddedDatabaseBuilder.build());
        Configuration configuration = new Configuration(environment);
        configuration.addMapper(mapper);
        return new SqlSessionFactoryBuilder().build(configuration);
    }
}