package com.convertlab.macore.mamgt.misc.mongo;

import com.convertlab.foundation.library.mongodb.core.CustomMongoTemplate;
import org.checkerframework.checker.initialization.qual.Initialized;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.UnknownKeyFor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Nonnull;

/**
 * @author Mr.黄
 * @description 订单相关的mongoTemplate
 * @since 2023/09/11 15:06
 **/
@Component
@Primary
public class OrderMongoTemplate extends CustomMongoTemplate {
    public OrderMongoTemplate(@Qualifier("etlMongoDataBaseFactory") MongoDatabaseFactory mongoDbFactory) {
        super(mongoDbFactory, null, "");
    }

    @Override
    public @UnknownKeyFor @NonNull @Initialized String determineCollectionName(@Nonnull @Value("${convertlab.mongodb.etlMongo.general-order-collection}") String collectionName) {
        return collectionName;
    }
}
