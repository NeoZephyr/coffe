package com.convertlab.macore.mamgt.misc.client;

import com.convertlab.data.job.core.biz.model.ReturnT;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * @author Mr.黄
 * @description cl-job client
 * @since 2024/01/18 19:11
 **/
@FeignClient(
        name = "clJobFeignClient",
        url = "${clJob.serverUrl}"
)
public interface ClJobFeignClient {
    @GetMapping("clJobGroup/clJobGroups/{groupNo}")
    ReturnT getClJobGroupByGroupNo(@PathVariable("groupNo") String groupNo);
}
