package com.convertlab.macore.mamgt.misc.mongo;

import com.convertlab.foundation.library.mongodb.core.CustomMongoTemplate;
import org.checkerframework.checker.initialization.qual.Initialized;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.UnknownKeyFor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Nonnull;

@Component
public class EventMongoTemplate extends CustomMongoTemplate {
    public EventMongoTemplate(@Qualifier("etlMongoDataBaseFactory") MongoDatabaseFactory mongoDbFactory) {
        super(mongoDbFactory, null, "");
    }

    @Override
    public @UnknownKeyFor @NonNull @Initialized String determineCollectionName(@Nonnull @Value("${convertlab.mongodb.eventMongo.general-event-collection}") String collectionName) {
        return collectionName;
    }
}
