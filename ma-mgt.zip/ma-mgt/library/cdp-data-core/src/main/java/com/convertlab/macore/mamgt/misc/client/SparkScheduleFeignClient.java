package com.convertlab.macore.mamgt.misc.client;

import org.springframework.cloud.openfeign.FeignClient;

import javax.annotation.Nonnull;
import java.util.Map;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(
        name = "sparkScheduleFeignClient",
        url = "${eventJobServer.serverUrl}"
)
public interface SparkScheduleFeignClient {

    @PostMapping("/job/sendToJob")
    Map<String, Object> submitSparkJob(@Nonnull @RequestBody Map<String, Object> request);
}
