package com.convertlab.macore.mamgt.misc.client;

import com.convertlab.foundation.library.model.vo.GenericListResponse;
import com.convertlab.macore.mamgt.cdp.dto.KeyValuesPair;
import com.convertlab.macore.mamgt.cdp.profile.model.kv.KvStoreFetchRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import javax.annotation.Nonnull;

@FeignClient(
        name = "kvStoreFeignClient",
        url = "${kvStoreService.serverUrl}"
)
public interface KvStoreFeignClient {

    @PostMapping("/v1/kvstore/{entityName}/bulkGet")
    GenericListResponse<KeyValuesPair>  bulkGet(@Nonnull @PathVariable("entityName") String entityName,
                                               @Nonnull @RequestBody KvStoreFetchRequest request);
}
