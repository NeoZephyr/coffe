package com.convertlab.macore.mamgt.filter.loader;

import com.convertlab.foundation.library.business.feature.FeatureClient;
import lombok.RequiredArgsConstructor;

import java.util.List;

/**
 * All rights Reserved, Designed By ConvertLab
 * Author: zhiping.cai
 * Date: 2023/6/5
 * Description:
 * Copyright (C) 2022 www.convertlab.com
 */
@RequiredArgsConstructor
public abstract class AbstractMetaLoader {

    private final FeatureClient featureClient;

    public Boolean isEnabled(String featureName) {
        return featureClient.checkToggleStatus(featureName);
    }

    public List<String> getFeatureList() {
        return featureClient.listEnabledFeatures();
    }
}
