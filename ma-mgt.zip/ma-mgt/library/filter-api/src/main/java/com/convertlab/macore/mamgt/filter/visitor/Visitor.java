package com.convertlab.macore.mamgt.filter.visitor;


import com.convertlab.macore.mamgt.filter.model.filterV4.Where;

import java.util.ListIterator;
import java.util.Map;


public abstract class Visitor {

    public abstract void visit(String profileName, Where.CompareOperator compareOperator, Map<String,Object> compareOperatorMap, ListIterator conditionIterator);

    public abstract void visit(String profileName, Where.LogicalOperator logicalOperator, Map<String,Object> compareOperatorMap,ListIterator conditionIterator);

}