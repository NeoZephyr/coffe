package com.convertlab.macore.mamgt.filter.loader;

import java.util.List;
import java.util.Map;

/**
 * All rights Reserved, Designed By ConvertLab
 * Author: zhiping.cai
 * Date: 2023/3/29
 * Description:
 * Copyright (C) 2022 www.convertlab.com
 */
public class MetaTreeChainLoader {

    private final List<MetaLoaderInterface> loaders;

    public MetaTreeChainLoader(List<MetaLoaderInterface> loaders) {
        this.loaders = loaders;
    }

    public Map<String, Object> execute(Map<String, Object> input, List<String> featureList) {
        return new LoaderExecutor(loaders).executeLoaders(input, featureList);
    }
}
