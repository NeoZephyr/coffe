package com.convertlab.macore.mamgt.filter.enums;

import com.fasterxml.jackson.annotation.JsonValue;

public enum BizObjectType {
    PROFILE("profile", "客户主档案"),
    GENERAL_PROFILE("general_profile", "udo自定义通用档案"),
    DIMENSION("dimension", "udo维度表");

    public static BizObjectType getByType(String type) {
        for (BizObjectType value: values()) {
            if (value.type.equalsIgnoreCase(type)) {
                return value;
            }
        }
        return null;
    }

    BizObjectType(String type, String desc) {
        this.type = type;
        this.desc = desc;
    }

    public String getType() {
        return type;
    }

    public String getDesc() {
        return desc;
    }

    @JsonValue
    private String type;

    private String desc;
}
