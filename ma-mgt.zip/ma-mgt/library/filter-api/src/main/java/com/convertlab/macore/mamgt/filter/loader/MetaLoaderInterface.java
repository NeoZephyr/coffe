package com.convertlab.macore.mamgt.filter.loader;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;

/**
 * All rights Reserved, Designed By ConvertLab
 * Author: zhiping.cai
 * Date: 2023/3/24
 * Description:
 * Copyright (C) 2022 www.convertlab.com
 */
public interface MetaLoaderInterface {

    Function<Map<String, Object>, Map<String, Object>> loader();

    default void removeNullStringValues(List<Map<String, Object>> maps) {
        maps.forEach(map -> map.entrySet().removeIf(entry -> Objects.isNull(entry.getValue()) || entry.getValue().equals("null")));
    }
}
