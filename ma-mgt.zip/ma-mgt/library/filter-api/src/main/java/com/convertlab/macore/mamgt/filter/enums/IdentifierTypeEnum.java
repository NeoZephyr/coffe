package com.convertlab.macore.mamgt.filter.enums;

import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BusinessException;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.util.ObjectUtils;

import java.util.Arrays;

/**
 * All rights Reserved, Designed By ConvertLab
 * Author: zhiping.cai
 * Date: 2023/2/24
 * Description:
 * Copyright (C) 2022 www.convertlab.com
 */
@Getter
@RequiredArgsConstructor
public enum IdentifierTypeEnum {
    COLUMN("COLUMN", "列名", false, true),
    VALUE("VALUE", "数值", false, false),
    VALUES("VALUES", "数值数组", false, false),
    COUNT("COUNT", "count函数", true, true),
    MAX("MAX", "max函数", true, true),
    MIN("MIN", "min函数", true, true),
    AVG("AVG", "avg函数", true, true),
    SUM("SUM", "sum函数", true, true),
    FUNC("FUNCTION", "函数", false, true),
    TMP_VIEW("TMP_VIEW", "临时视图", false, false);

    private final String type;
    private final String desc;
    private final boolean aggregation;
    private final boolean relationCheck;

    public static IdentifierTypeEnum getIdentityType(String type) {
        if (ObjectUtils.isEmpty(type)) {
            return null;
        }
        return Arrays.stream(IdentifierTypeEnum.values())
                .filter(x -> type.equals(x.getType()))
                .findAny()
                .orElseThrow(() -> new BusinessException(CommonErrors.WRONG_TYPE,"MSG_100_000011",new String[]{"条件类型",type},0));
    }
}
