package com.convertlab.macore.mamgt.filter.loader;

import java.util.List;
import java.util.Map;

public class FilterConvertMappingChainLoader {
    private final List<MetaLoaderInterface> loaders;

    public FilterConvertMappingChainLoader(List<MetaLoaderInterface> loaders){
        this.loaders = loaders;
    }

    public Map<String, Object> execute(Map<String, Object> input, List<String> featureList) {
        return new LoaderExecutor(loaders).executeLoaders(input, featureList);
    }
}
