package com.convertlab.macore.mamgt.filter.constants;

import org.apache.commons.lang.StringUtils;

public class Constants {

    //date&time constant fields define
    public static final String DATE_SUB_OPERATOR = "-";
    public static final String DATE_ADD_OPERATOR = "+";
    public static final String DATE_TYPE_DATE = "Date";
    public static final String DATE_TYPE_DATETIME = "DateTime";
    public static final String STATIC_DATE_TYPE = "static";
    public static final String DYNAMIC_DATE_TYPE = "dynamic";
    public static final String START_ANY = "1400-01-02";
    public static final String TO_ANY = "3000-01-01";
    public static final String TIME_ZONE_SHANGHAI = StringUtils.isBlank(System.getProperty("defaultDateTimeZone")) ?  "Asia/Shanghai" : System.getProperty("defaultDateTimeZone");
    public static final String DATE_PATTERN_DEFAULT = "yyyy-MM-dd'T'HH:mm:ss'Z'";
    public static final String DATE_PATTERN_DATE = "yyyy-MM-dd";
    public static final String DATE_PATTERN_DATETIME = "yyyy-MM-dd HH:mm:ss";

    //biz constant fields define
    public static final int FILTER_VERSION = 4;
    public static final String ALIAS = "alias";
    public static final String UIDF = "FUNC";
    public static final String SINCEID = "sinceId";
    public static final String ID = "id";
    public static final String MAIN_TABLE = "table";
    public static final String[] IGNORE_EVENTS = {
            "join_list", "create_customer", "merge_customer", "leave_list", "session_stop_from",
            "session_start_from", "complete_task", "reopen_task", "downgrade_stage", "create_task",
            "email_invalid", "default", "web_hook", "mobile_app_notification_received"
    };
    public static final String[] UNDER_SCORE_CASE_TYPES = {
            "COLUMN", "COUNT", "MAX", "MIN", "AVG",
            "SUM"
    };

    //match And replace % constants
    public static final String MATCH_PERCENT_PATTERN = "%";
    public static final String REPLACE_PERCENT_PATTERN = "\\\\%";

    //split character define
    public static final String FIELD_MAPPING_SPLIT = "#@#";

    //get list id list request path
    public static final String CUSTOMER_LISTS = "/lists";
    public static final String PING = "/ping";
    public static final String PONG = "ACCEPTING_TRAFFIC";

    //the request path of foundation query-engine data list
    public static final String QUERY_ENGINE_Q = "/v1/query-engine/q";
    //the request path of foundation query-engine data count
    public static final String QUERY_ENGINE_C = "/v1/query-engine/c";
    //the request path of foundation query-engine GDQL or nativeSql
    public static final String QUERY_ENGINE_SQL = "/v1/query-engine/sql";

    public static final String IDENTITY_TABLE = "identity";


    public static final String V4_CURRENT_STEP = "xxx_v4_current_step"; // where, timeline
    public static final String V4_CURRENT_STEP_1 = "where";
    public static final String V4_CURRENT_STEP_2 = "timeline";
    public static final String V4_CONDITION_DEEP_LEVEL = "xxx_v4_condition_deep_level";
    public static final String V4_ROOT_NODE_INDEX = "xxx_v4_root_node_index";
    public static final String V4_ROOT_CURRENT_NODE_HAS_AGG = "xxx_v4_root_current_node_%d";

    public static final String V4_CONDITION_DEEP_LEVEL_FOR_ADDITIONAL_CONDITION = "xxx_v4_condition_deep_level_for_additional_condition";

}
