package com.convertlab.macore.mamgt.filter.enums;


import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.macore.mamgt.filter.model.filterV4.Where;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * All rights Reserved, Designed By ConvertLab
 * Author: zhiping.cai
 * Date: 2023/4/26
 * Description:
 * Copyright (C) 2022 www.convertlab.com
 */
@Getter
@RequiredArgsConstructor
public enum OperatorNameEnum {
    IN(Where.Operator.Constants.IN),
    NONEOF(Where.Operator.Constants.NONE_OF),
    ALLOF(Where.Operator.Constants.ALL_OF),
    LIKE(Where.Operator.Constants.LIKE),
    NOTLIKE(Where.Operator.Constants.NOT_LIKE),
    NOTEQUAL(Where.Operator.Constants.NOT_EQUAL),
    EQUAL(Where.Operator.Constants.EQUAL),
    NOTIN(Where.Operator.Constants.NOT_IN),
    BETWEEN(Where.Operator.Constants.BETWEEN),
    ISBLANK(Where.Operator.Constants.IS_BLANK),
    FALSEORNULL(Where.Operator.Constants.FALSE_OR_NULL),
    EQORNULL(Where.Operator.Constants.EQ_OR_NULL),
    ISNOTBLANK(Where.Operator.Constants.NOT_EQUAL),
    GREATEQUAL(Where.Operator.Constants.GREAT_EQUAL),
    GREATTHAN(Where.Operator.Constants.GREAT_THAN),
    ISNOTNULL(Where.Operator.Constants.NOT_NULL),
    ISNULL(Where.Operator.Constants.IS_NULL),
    LESSEQUAL(Where.Operator.Constants.LESS_EQUAL),
    LESSTHAN(Where.Operator.Constants.LESS_THAN);

    private final String name;

    public static String getCompareOperatorName(Where.CompareOperator compareOperator) {
        try {
            return OperatorNameEnum.valueOf(compareOperator.getClass().getSimpleName().toUpperCase()).getName();
        } catch (IllegalArgumentException e) {
            throw new BusinessException(CommonErrors.WRONG_TYPE,"MSG_100_000011",new String[]{"条件操作符类型",compareOperator.getClass().getSimpleName().toUpperCase()},0);
        }
    }
}
