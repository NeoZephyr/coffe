package com.convertlab.macore.mamgt.filter.loader;

import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;
import java.util.List;
import java.util.Map;


/**
 * All rights Reserved, Designed By ConvertLab
 * Author: zhiping.cai
 * Date: 2023/8/28
 * Description:
 * Copyright (C) 2022 www.convertlab.com
 */
@Slf4j
public class LoaderExecutor {
    //check feature enable
    public static final String[] CHECK_FEATURE_NAME = {
            "udo", "loyalty"
    };

    private final List<MetaLoaderInterface> loaders;

    public LoaderExecutor(List<MetaLoaderInterface> loaders) {
        this.loaders = loaders;
    }

    public Map<String, Object> executeLoaders(Map<String, Object> input, List<String> featureList) {
        for (MetaLoaderInterface loader : loaders) {
            if (checkIfLoaderIsEnabled(loader, featureList)) {
                input = loader.loader().apply(input);
            }
        }
        return input;
    }

    private boolean checkIfLoaderIsEnabled(MetaLoaderInterface loader, List<String> featureList) {
        String loaderClassName = loader.getClass().getSimpleName().toLowerCase();
        return Arrays.stream(CHECK_FEATURE_NAME)
                .filter(loaderName -> loaderClassName.startsWith(loaderName.toLowerCase()))
                .findFirst()
                .map(featureList::contains)
                .orElse(true);
    }
}
