package com.convertlab.macore.mamgt.filter.loader;

import cn.hutool.core.io.resource.ResourceUtil;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.mamgt.cdp.client.GdmModelClientWrapper;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;


/**
 * All rights Reserved, Designed By ConvertLab
 * Author: zhiping.cai
 * Date: 2023/6/14
 * Description:
 * Copyright (C) 2022 www.convertlab.com
 */
public abstract class AbstractRootMetaLoader implements MetaLoaderInterface {

    private final Map<String, Supplier<String>> metaTypeResourceSuppliers;
    private final String defaultResourcePath;
    private final String profileNamePlaceHolder = "\\$\\{profileName}";
    private final String orderEntityNamePlaceHolder = "\\$\\{orderEntityName}";
    private final GdmModelClientWrapper profileAssociation;

    public AbstractRootMetaLoader(Map<String, Supplier<String>> metaTypeResourceSuppliers, String defaultResourcePath, GdmModelClientWrapper profileAssociation) {
        this.metaTypeResourceSuppliers = metaTypeResourceSuppliers;
        this.defaultResourcePath = defaultResourcePath;
        this.profileAssociation = profileAssociation;
    }

    @Override
    public Function<Map<String, Object>, Map<String, Object>> loader() {
        return input -> {
            String metaName = (String)input.get("metaName");
            if(metaName !=null){
                String metaType = "customer".equals(metaName)?"customer":"udo";
                String resourcePath = getResourcePath(metaTypeResourceSuppliers, metaType, defaultResourcePath);
                String metaContentStr = ResourceUtil.readUtf8Str(resourcePath);
                Object metaObject = processProfileMetaContent(metaName, metaContentStr);
                if(metaObject!=null) {
                    input = Optional.ofNullable(input).orElse(new HashMap<>());
                    input.put(getMetaMapKey(), metaObject);
                }
            }
            return input;
        };
    }

    /**
     * 根据档案类型，处理模板中的变量
     * @param profileName
     * @param rawContent
     * @return
     */
    private @Nullable Object processProfileMetaContent(String profileName, String rawContent){
        // 替换档案entity名称
        String content = rawContent.replaceAll(profileNamePlaceHolder, profileName);
        GdmModelDto gdmModelDto = profileAssociation.findByName(profileName);
        if(gdmModelDto !=null){
            if(gdmModelDto.getFeatures().contains(GdmPatternDto.Feature.Order)){
                String orderEntityName = gdmModelDto.getProps().getOrderEntityName();
                // 替换事件entity名称
                content = content.replaceAll(orderEntityNamePlaceHolder, orderEntityName);
            }else{
                content = content.replaceAll(orderEntityNamePlaceHolder, "general_order");
            }
        }
        return JsonUtils.instance().json2Obj(content, Object.class);
    }

    private static String getResourcePath(Map<String, Supplier<String>> metaTypeResourceSuppliers, String metaType, String defaultResourcePath) {
        return Optional.ofNullable(metaTypeResourceSuppliers.get(metaType))
                .orElseGet(() -> () -> defaultResourcePath)
                .get();
    }

    protected abstract String getMetaMapKey();
}
