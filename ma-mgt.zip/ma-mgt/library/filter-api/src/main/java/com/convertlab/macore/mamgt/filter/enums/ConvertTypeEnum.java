package com.convertlab.macore.mamgt.filter.enums;

import org.springframework.util.ObjectUtils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;


public enum ConvertTypeEnum {
    /**
     *
     */
    EXPR("expr", "expr", "属性比较处理"),
    /**
     *
     */
    PAGE_DT("pageDt", "pageDt", "微页面相关的分组函数"),
    /**
     *
     */
    FORM("form", "form", "表单相关的分组函数"),
    /**
     *
     */
    FILE("file", "file", "表单相关的分组函数"),
    /**
     *
     */
    OTHERFOLDER("otherFolder", "otherFolder", "表单相关的分组函数"),
    /**
     *
     */
    WECHATCARD("wechatCard", "wechatCard", "表单相关的分组函数"),
    /**
     *
     */
    SOURCEGROUP("sourceGroup", "sourceGroup", "来源分组"),
    /**
     *
     */
    SUBSCRIBE("Subscribe", "Subscribe", "关注公众号特别处理"),
    /**
     *
     */
    FORM_FIELD("formField", "formField", "提交表单数据"),
    /**
     *
     */
    LIST("List", "List", "群组函数"),
    /**
     *
     */
    TAG("Tag", "Tag", "标签函数"),
    /**
     *
     */
    TAG_GROUP("TagGroup", "TagGroup", "标签组函数"),
    /**
     *
     */
    CONTENT_TAG_GROUP("ContentTagGroup", "ContentTagGroup", "内容标签组函数"),
    /**
     *
     */
    RANGE_DATE("RangeDate", "RangeDate", "区间"),
    /**
     *
     */
    SPECIFIC_DATE("SpecificDate", "SpecificDate", "指定具体日期时间"),
    /**
     *
     */
    CRON_DATE("CronDate", "CronDate", "周期时间"),
    /**
     *
     */
    EVENT_GROUP("EventGroup", "EventGroup", "事件分组"),
    /**
     *
     */
    SUBMIT_FORM_DATA("SubmitFormData", "SubmitFormData", "表单提交数据"),
    /**
     *
     */
    WECHAT_SCAN("qrCode", "qrCode", "二维码扫描"),
    /**
     *
     */
    MOBILE_HOME("mobileHome", "mobileHome", "手机号区域归属"),

    ORDER_REFUND_RATE("full_order.orderRefundRate", "OrderRefundRate", "订单退货率"),
    GOODS_REFUND_RATE("full_order.goodsRefundRate", "GoodsRefundRate", "商品退货率"),
    PURCHASING_RATE("full_order.purchasingRate", "PurchasingRate", "平均复购周期");


    private String code;
    private String value;
    private String desc;

    ConvertTypeEnum(String code, String value, String desc) {
        this.code = code;
        this.value = value;
        this.desc = desc;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    /**
     * 定义map用来存放转换类型及对象
     */
    public static final Map<String, ConvertTypeEnum> convertTypeEnumMap = new HashMap<>();

    /**
     * 获取所有的转换存入MAP
     */
    static {
        Arrays.stream(ConvertTypeEnum.values()).forEach(e -> convertTypeEnumMap.put(e.getValue(), e));
    }



    public static ConvertTypeEnum get(String convertType) {
        ConvertTypeEnum convertTypeEnum = ConvertTypeEnum.convertTypeEnumMap.get(convertType);
        if (ObjectUtils.isEmpty(convertTypeEnum)) {
            return null;
        }
        return convertTypeEnum;
    }


    public static final Map<String, ConvertTypeEnum> convertCodeEnumMap = new HashMap<>();
    static {
        Arrays.stream(ConvertTypeEnum.values()).forEach(e -> convertCodeEnumMap.put(e.getCode(), e));
    }

    public static ConvertTypeEnum getValueByCode(String convertCode) {
        ConvertTypeEnum convertTypeEnum = ConvertTypeEnum.convertCodeEnumMap.get(convertCode);
        if (ObjectUtils.isEmpty(convertTypeEnum)) {
            return null;
        }
        return convertTypeEnum;
    }
}
