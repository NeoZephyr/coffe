package com.convertlab.macore.mamgt.filter.enums;

import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BusinessException;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.util.ObjectUtils;

import java.util.Arrays;

/**
 * All rights Reserved, Designed By ConvertLab
 * Author: zhiping.cai
 * Date: 2023/2/24
 * Description:
 * Copyright (C) 2022 www.convertlab.com
 */
@Getter
@RequiredArgsConstructor
public enum DateTypeEnum {
    DAY("day", "日", "Day"),
    WEEK("week", "周", "Week"),
    MONTH("month", "月", "Month"),
    YEAR("year", "年", "Year"),
    MINUTES("minutes", "分钟", "Minutes"),
    HOUR("hour", "小时", "Hour"),
    SECONDS("seconds", "秒", "Seconds"),
    LAST_DAY("last-day", "过去第几天", "Last-Day"),
    AFTER_DAY("after-day", "未来第几天", "After-Day"),
    DATE("date", "日期", "Date"),
    DATE_TIME("dateTime", "日期到时分秒", "DateTime");

    private final String type;
    private final String desc;
    private final String value;

    public static DateTypeEnum getDateType(String type) {
        if (ObjectUtils.isEmpty(type)) {
            return null;
        }
        return Arrays.stream(DateTypeEnum.values())
                .filter(x -> type.equalsIgnoreCase(x.getType()))
                .findAny()
                .orElseThrow(() -> new BusinessException(CommonErrors.WRONG_TYPE,"MSG_100_000011",new String[]{"时间维度类型",type},0));
    }
}
