package com.convertlab.macore.mamgt.filter.loader;

import cn.hutool.core.io.resource.ResourceUtil;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.mamgt.common.configure.ApplicationContextProvider;
import org.springframework.beans.BeansException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * All rights Reserved, Designed By ConvertLab
 * Author: zhiping.cai
 * Date: 2023/6/12
 * Description:
 * Copyright (C) 2022 www.convertlab.com
 */
public class LoaderFactory {

    private static final String LOADER_CONFIG = "meta/loader-config.json";

    private static ConcurrentHashMap<String, Map<String, List<String>>> config = new ConcurrentHashMap();

    static {
        String configStr = ResourceUtil.readUtf8Str(LOADER_CONFIG);
        if(configStr !=null) {
            ConcurrentHashMap cf = JsonUtils.instanceOfDto().json2Obj(configStr, ConcurrentHashMap.class);
            if(cf !=null){
                config = cf;
            }
        }
    }

    private static final Map<String, String> PACKAGE_PATH_MAP = new HashMap<String, String>();
    static {
        // loader-config.json中的短key，转换为classpath
        PACKAGE_PATH_MAP.put("relation", "com.convertlab.macore.mamgt.filter.filters.misc.loader.meta.relation");
        PACKAGE_PATH_MAP.put("base", "com.convertlab.macore.mamgt.filter.filters.misc.loader.meta.base");
        PACKAGE_PATH_MAP.put("tree", "com.convertlab.macore.mamgt.filter.filters.misc.loader.meta.tree");
        PACKAGE_PATH_MAP.put("convertMapping", "com.convertlab.macore.mamgt.filter.filters.misc.convert.mapping");
    }

    public static MetaTreeChainLoader createMetaTreeChainLoader(String metaType) {
        if(config.get("udo")!=null){
            List<String> loaderNames = config.getOrDefault(metaType, config.get("udo")).get("metaTreeLoaders");
            if(loaderNames !=null){
                List<MetaLoaderInterface> loaders = loaderNames.stream()
                        .map(LoaderFactory::getLoaderInstance)
                        .collect(Collectors.toList());
                return new MetaTreeChainLoader(loaders);
            }
        }
        return null;
    }

    public static MetaRelationChainLoader createMetaRelationChainLoader(String metaType) {
        if(config.get("udo") !=null){
            List<String> loaderNames = config.getOrDefault(metaType, config.get("udo")).get("metaRelationLoaders");
            if(loaderNames !=null){
                List<MetaLoaderInterface> loaders = loaderNames.stream()
                        .map(LoaderFactory::getLoaderInstance)
                        .collect(Collectors.toList());
                return new MetaRelationChainLoader(loaders);
            }
        }
        throw new BusinessException(CommonErrors.GENERAL_ERROR,
                "MSG_100_000014", new String[]{metaType}, 0);
    }

    /**
     * 加载高级筛选转换mapping
     * @param profileName
     * @return
     */
    public static FilterConvertMappingChainLoader createFilterConvertMappingChainLoader(String profileName) {
        if(config.get("udo") != null){
            List<String> loaderNames = config.getOrDefault(profileName, config.get("udo")).get("convertMapping");
            if(loaderNames !=null){
                List<MetaLoaderInterface> loaders = loaderNames.stream()
                        .map(LoaderFactory::getLoaderInstance)
                        .collect(Collectors.toList());
                return new FilterConvertMappingChainLoader(loaders);
            }
        }
        throw new BusinessException(CommonErrors.GENERAL_ERROR,
                "MSG_100_000014", new String[]{profileName}, 0);
    }

    private static MetaLoaderInterface getLoaderInstance(String className) {
        String fullClassName = getFullClassName(className);
        try {
            Class<?> clazz = Class.forName(fullClassName);
            MetaLoaderInterface result = (MetaLoaderInterface) ApplicationContextProvider.getBean(clazz);
            if(result !=null){
                return result;
            }else{
                throw new BusinessException(CommonErrors.GENERAL_ERROR,
                        "MSG_100_000014", new String[]{fullClassName}, 0);
            }
        } catch (ClassNotFoundException | BeansException e) {
            throw new BusinessException(CommonErrors.GENERAL_ERROR,
                    "MSG_100_000014", new String[]{fullClassName}, 0);
        }
    }

    private static String getFullClassName(String className) {
        String fullClassName = PACKAGE_PATH_MAP.entrySet().stream()
                .filter(entry -> className.startsWith(entry.getKey() + "."))
                .findFirst()
                .map(entry -> className.replace(entry.getKey() + ".", entry.getValue() + "."))
                .orElse(className);
        return fullClassName;
    }
}
