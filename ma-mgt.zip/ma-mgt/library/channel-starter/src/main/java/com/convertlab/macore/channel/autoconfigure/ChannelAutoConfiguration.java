package com.convertlab.macore.channel.autoconfigure;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(
        {
                "com.convertlab.macore.channel",
                "com.convertlab.channel"}
)
public class ChannelAutoConfiguration {
}
