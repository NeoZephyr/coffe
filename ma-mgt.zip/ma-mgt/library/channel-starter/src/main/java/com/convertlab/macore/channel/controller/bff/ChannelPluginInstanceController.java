package com.convertlab.macore.channel.controller.bff;

import com.convertlab.foundation.library.webmvc.annotation.ViewController;
import com.convertlab.macore.channel.model.dto.ChannelPluginVersionWithMessagingTypeDTO;
import com.convertlab.macore.channel.service.CompositeChannelPluginInstanceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Validated
@Slf4j
@RequestMapping("/channels/plugin-instances")
@Tag(name = "租户已安装的渠道插件实例数据")
@RequiredArgsConstructor
@ViewController
public class ChannelPluginInstanceController {

    private final CompositeChannelPluginInstanceService compositeChannelPluginInstanceService;

    @GetMapping("/messaging-types")
    @Operation(summary = "获取可用的消息类型列表", description = "获取可用的消息类型列表")
    public List<ChannelPluginVersionWithMessagingTypeDTO> getMessagingTypeList() {
        return compositeChannelPluginInstanceService.getPluginVersionWithMessagingTypeList();
    }

}
