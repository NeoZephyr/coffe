package com.convertlab.macore.ipinfo.utils;

import org.apache.commons.lang3.StringUtils;

import java.util.regex.Pattern;

public class IPValidator {
    private static final Pattern ipV4Pattern = Pattern.compile( "((2(5[0-5]|[0-4]\\d))|[0-1]?\\d{1,2})(\\.((2(5[0-5]|[0-4]\\d))|[0-1]?\\d{1,2})){3}");

    public static boolean isIPv4(String ip) {
        if(StringUtils.isEmpty(ip)){
            return false;
        }
        return ipV4Pattern.matcher(ip).matches();
    }
}
