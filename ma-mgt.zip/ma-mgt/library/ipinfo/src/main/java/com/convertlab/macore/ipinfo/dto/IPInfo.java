package com.convertlab.macore.ipinfo.dto;


import lombok.*;
import org.apache.commons.lang3.StringUtils;

@Data
@ToString
@NoArgsConstructor
public class IPInfo {
    private static final String SEPERATOR = "\\|";
    public IPInfo(String ipInfoString){
        if(StringUtils.isNotBlank(ipInfoString)){
            String [] segments = ipInfoString.split(SEPERATOR);
            if(segments.length == 11){
                this.continent = segments[0];
                this.country = segments[1];
                this.province = segments[2];
                this.city = segments[3];
                this.district = segments[4];
                this.isp = segments[5];
                this.zipCode = segments[6];
                this.longitude = segments[9];
                this.latitude = segments[10];
            }
        }
    }

    private String continent;
    private String country;
    private String province;
    private String city;
    private String district;
    private String isp;
    private String zipCode;
    private String longitude;
    private String latitude;

}
