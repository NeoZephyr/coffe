package com.convertlab.macore.ipinfo.utils;

import com.convertlab.macore.ipinfo.dto.IPInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.Conversion;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.regex.Pattern;

@Slf4j
public class IPLocater {
    private static IPLocater instance = null;
    private byte[] data;
    // 索引区第一条流位置
    private long firstStartIpOffset;
    // 前缀区第一条的流位置
    private long prefixStartOffset = 0L;
    // 前缀区最后一条的流位置
    private long prefixEndOffset = 0L;
    // 前缀数量
    private long prefixCount = 0L;
    private HashMap<Integer, PrefixIndex> prefixMap;

    public class IpIndex {
        private long startIp;
        private long endIp;
        private int localOffset;
        private int localLength;

        public long getStartIp() {
            return startIp;
        }

        public void setStartIp(long startIp) {
            this.startIp = startIp;
        }

        public long getEndIp() {
            return endIp;
        }

        public void setEndIp(long endIp) {
            this.endIp = endIp;
        }

        public int getLocalOffset() {
            return localOffset;
        }

        public void setLocalOffset(int localOffset) {
            this.localOffset = localOffset;
        }

        public int getLocalLength() {
            return localLength;
        }

        public void setLocalLength(int localLength) {
            this.localLength = localLength;
        }
    }

    class PrefixIndex {
        private long startIndex;
        private long endIndex;

        public long getStartIndex() {
            return startIndex;
        }

        public void setStartIndex(long startIndex) {
            this.startIndex = startIndex;
        }

        public long getEndIndex() {
            return endIndex;
        }

        public void setEndIndex(long endIndex) {
            this.endIndex = endIndex;
        }
    }

    public IPLocater() {
        try {
            InputStream is = IPLocater.class.getClassLoader().getResourceAsStream("ipdb/ip-utf8.dat");
            int length = is.available();
            data = new byte[length];
            int offset = 0;
            while(offset < length){
                int size = is.read(data, offset, length - offset);
                if(size <=0) {
                    break;
                }
                offset += size;
            }
            log.info("load ip-utf8.dat total length: " + length + " readLength: " + offset);
            is.close();

            firstStartIpOffset = Conversion.byteArrayToLong(data, 0, 0, 0, 4);
            prefixStartOffset = Conversion.byteArrayToLong(data, 8, 0, 0, 4);
            prefixEndOffset = Conversion.byteArrayToLong(data, 12, 0, 0, 4);
            prefixCount = (prefixEndOffset - prefixStartOffset) / 9 + 1;

            // 初始化前缀对应索引区区间
            byte[] indexBuffer = Arrays.copyOfRange(data, (int) prefixStartOffset, (int) prefixEndOffset + 9);
            prefixMap = new HashMap<>();
            for (int k = 0; k < prefixCount; k++) {
                int i = k * 9;
                int prefix = (int) (indexBuffer[i] & 0xFFL);

                PrefixIndex pf = new PrefixIndex();
                pf.setStartIndex(Conversion.byteArrayToLong(indexBuffer, i+1, 0, 0, 4));
                pf.setEndIndex(Conversion.byteArrayToLong(indexBuffer, i+5, 0, 0, 4));
                prefixMap.put(prefix, pf);

            }
        }catch(IOException e){
            log.error("Failed to initialize IPLocater.", e);
        }
    }

    public static synchronized IPLocater getInstance() {
        if (null == instance) {
            instance = new IPLocater();
        }
        return instance;
    }

    public IPInfo getIpInfo(String ip) {
        if(IPValidator.isIPv4(ip)){
            try {
                String[] ips = ip.split("\\.");
                int prefix = Integer.parseInt(ips[0]);
                long intIP = ipToLong(ip);

                long high = 0;
                long low = 0;

                if (prefixMap.containsKey(prefix)) {
                    low = prefixMap.get(prefix).getStartIndex();
                    high = prefixMap.get(prefix).getEndIndex();
                } else {
                    return null;
                }

                long index = low == high ? low : binarySearch(low, high, intIP);

                IpIndex ipindex = new IpIndex();
                getIndex((int) index, ipindex);

                if ((ipindex.getStartIp() <= intIP) && (ipindex.getEndIp() >= intIP)) {
                    String addressStr = getLocal(ipindex.getLocalOffset(), ipindex.getLocalLength());
                    return new IPInfo(addressStr);
                } else {
                    return null;
                }
            }catch (Exception e){
                return null;
            }
        }else{
            return null;
        }
    }

    public long binarySearch(long low, long high, long k) {
        long pivot = 0;
        while (low <= high) {
            long mid = (low + high) / 2;

            long endipNum = getEndIp(mid);
            if (endipNum >= k) {
                pivot = mid;
                if (mid == 0) {
                    break; // 防止溢出
                }
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }
        return pivot;
    }

    /**
     * 在索引区解析
     * @param left ip第left个索引
     * @param ipindex
     */
    private void getIndex(int left, IpIndex ipindex) {
        int offset = (int) firstStartIpOffset + (left * 12);
        ipindex.setStartIp(Conversion.byteArrayToLong(data, offset, 0, 0, 4));
        ipindex.setEndIp(Conversion.byteArrayToLong(data, offset + 4, 0, 0, 4));
        ipindex.setLocalOffset((int) Conversion.byteArrayToLong(data, offset + 8, 0, 0, 3));
        ipindex.setLocalLength(data[11 + offset]);
    }

    /**
     * 只获取结束ip的数值
     * @param left 索引区第left个索引
     * @return 返回结束ip的数值
     */
    private long getEndIp(long left) {
        int offset = (int) firstStartIpOffset + (int) (left * 12);
        return Conversion.byteArrayToLong(data, offset + 4, 0, 0, 4);
    }

    // 返回地址信息
    private String getLocal(int offset, int length) {
        byte[] bytes = Arrays.copyOfRange(data, offset, offset + length);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    public long ipToLong(String ip) {
        String[] quads = ip.split("\\.");
        long result = 0;
        result += Integer.parseInt(quads[3]);
        result += Long.parseLong(quads[2]) << 8L;
        result += Long.parseLong(quads[1]) << 16L;
        result += Long.parseLong(quads[0]) << 24L;
        return result;
    }

}
