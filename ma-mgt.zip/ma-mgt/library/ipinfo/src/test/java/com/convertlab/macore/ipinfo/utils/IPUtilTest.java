package com.convertlab.macore.ipinfo.utils;

import com.convertlab.macore.ipinfo.dto.IPInfo;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Slf4j
class IPUtilTest {
    @Test
    void testGetIPV4() throws IOException {
        IPLocater ipLocater = IPLocater.getInstance();
        IPInfo result = ipLocater.getIpInfo("58.33.131.2");
        Assertions.assertNotNull(result);
        Assertions.assertEquals("中国", result.getCountry());
        Assertions.assertEquals("上海", result.getProvince());
        Assertions.assertEquals("上海", result.getCity());
        Assertions.assertEquals("浦东", result.getDistrict());
        Assertions.assertEquals("121.5447", result.getLongitude());
        Assertions.assertEquals("31.22249", result.getLatitude());

        IPInfo result2 = ipLocater.getIpInfo("106.15.235.204");
        Assertions.assertNotNull(result);
        Assertions.assertEquals("阿里云", result2.getIsp());
    }
}
