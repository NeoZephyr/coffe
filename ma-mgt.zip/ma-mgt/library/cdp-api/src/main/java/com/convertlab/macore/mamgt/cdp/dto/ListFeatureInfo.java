package com.convertlab.macore.mamgt.cdp.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

/**
 * @author Mr.黄
 * @description 特征群组的分组信息
 * @since 2023/07/18 19:58
 **/
@Getter
@Setter
@Schema(name = "特征群组的分组信息", description = "主档案群组，包括客户群组和UDO群组")
@ToString
public class ListFeatureInfo {
    private Long id;
    private Long tenantId;
    private Long listId;
    private String info;
    private Date lastUpdated;
    private Date dateCreated;
    private Long version;
}
