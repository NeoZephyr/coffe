package com.convertlab.macore.mamgt.cdp;

import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.associated.ProfileOrderPropBizMeta;
import com.fasterxml.jackson.annotation.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Mr.黄
 * @description order query body
 * @since 2023/08/30 14:08
 **/
@Setter
@Getter
@ToString
public class OrderQuery {
    @Setter
    @Getter
    @ToString
    public static class Order implements Serializable {
        /**
         * profileId
         */
        private String profileId;

        private String bk;
        private String customerId;
        /**
         * profileName
         */
        @JsonProperty(value = "objId")
        private String profileName = "customer";
        /**
         * 订单号
         */
        private String orderNo;
        /**
         * 订单总金额
         */
        private BigDecimal amountTotal;
        /**
         * 实际支付金额
         */
        private BigDecimal amountPaid;
        /**
         * 订单折扣金额
         */
        private BigDecimal amountDiscount;
        /**
         * 优惠类型
         */
        private String discountType;
        /**
         * 优惠券编码
         */
        private String couponCode;
        /**
         * 优惠券名称
         */
        private String couponName;
        /**
         * 团购id
         */
        private String groupId;
        /**
         * 现金、信用卡、微信支付、支付宝等支付方式
         */
        private String paymentTerm;
        /**
         * 支付号
         */
        private String paymentNo;
        /**
         * 线上、线下等订单类型
         */
        private String type;
        /**
         * 订单支付完成时间，采用UTC时间格式为:“2020-06-07T12:20:20Z” 如是北京时间，请减8小时
         */
        private String dateOrder;
        /**
         * 订单店铺（线下或线上的店铺名
         */
        private String store;
        /**
         * 订单渠道（如线下，天猫等）
         */
        private String salesChannel;
        /**
         * 收货人名称
         */
        private String contactName;
        /**
         * 收货人名称
         */
        private String contactTel;
        /**
         * 收货人名称
         */
        private String zipcode;
        /**
         * 货物的运送方式
         */
        private String shippingMethod;
        /**
         * 收货人省份
         */
        private String shippingProvince;
        /**
         * 收货人城市
         */
        private String shippingCity;
        /**
         * 收货人区县
         */
        private String shippingCounty;
        /**
         * 收货人街道
         */
        private String shippingStreet;
        /**
         * 收货人详细地址
         */
        private String shippingAddress;
        /**
         * 买家留言
         */
        private String buyerMessage;
        /**
         * 订单备注
         */
        private String remark;
        /**
         * 营销活动编码
         */
        private String campaign;
        /**
         * 订单积分
         */
        private Integer merchantPoint;
        /**
         * 币种,如￥,$等
         */
        private String currency;
        private Double totalRefund;
        private String dateRefund;
        private String stateRefund;
        private String reasonRefund;
        /**
         * 自定义字段-文本(至多20个)，数值(至多10个)，日期(至多10个)，关联对象(至多2个)。xxx可在设置中心>订单设置界面中设置对应的自定义字段名称
         */
        @JsonAnyGetter
        @JsonAnySetter
        @JsonIgnore
        private Map<String, Object> extraField = new HashMap<>();
        /**
         * 订单行
         */
        @JsonProperty(value = "lines")
        private List<OrderLine> orderLines;

        public void setBk(String bk) {
            this.profileId = bk;
            this.bk = bk;
        }

        public String getBk() {
            return this.bk;
        }

        public void setCustomerId(String customerId) {
            this.profileId = customerId;
            this.customerId = customerId;
        }

        public String getCustomerId() {
            return this.profileId;
        }
    }

    @Setter
    @Getter
    @ToString
    public static class OrderLine {
        // 别放开序列化的限制，否则下游hadoopdts存在orderId不能插入kudu
        @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
        private String orderNo;
        /**
         * 订单行在该订单中的唯一标识，可以传商品id或skuid，若没有订单行则不必填
         */
        private String lineId;
        /**
         * 商品ID
         */
        private String productId;
        /**
         * 商品名称
         */
        private String productName;
        /**
         * skuID
         */
        private String skuId;
        /**
         * 产品品牌
         */
        private String brandName;
        /**
         * 产品所属品类，比如啤酒
         */
        private String category;
        /**
         * 优惠类型
         */
        private String discountType;
        /**
         * 优惠券编码
         */
        private String couponCode;
        /**
         * 优惠券名称
         */
        private String couponName;
        /**
         * 订购数量
         */
        private Integer qty;
        /**
         * 单件商品价格
         */
        private BigDecimal priceUnit;
        /**
         * 该商品总价
         */
        private BigDecimal priceSubTotal;
        /**
         * 该商品实际支付金额
         */
        private BigDecimal priceSubPaid;
        private Integer qtyRefund;
        private Double totalRefund;

        /**
         * 自定义字段-文本(至多20个)，数值(至多10个)，日期(至多10个)，关联对象(至多2个)。xxx可在设置中心>订单设置界面中设置对应的自定义字段名称
         */
        @JsonAnyGetter
        @JsonAnySetter
        @JsonIgnore
        private Map<String, Object> extraField = new HashMap<>();
    }

    @Setter
    @Getter
    @ToString
    public static class OrderMeta {

        private List<OrderBizAndGdmMeta> orderHeaderMeta;
        private List<OrderBizAndGdmMeta> orderLineMeta;

        @Setter
        @Getter
        @ToString
        public static class OrderBizAndGdmMeta {
            private String bizFieldName;
            private String gdmFieldName;
            private String dbColumnName;
            private String dbColumnHumpName;
            private ProfileOrderPropBizMeta profileOrderPropBizMeta;
            private GdmField gdmField;
        }
    }

    @Setter
    @Getter
    @ToString
    public static class OrderListResp<T> {
        private List<T> data;

        public OrderListResp(List<T> data) {
            this.data = data;
        }
    }

    @Setter
    @Getter
    @ToString
    public static class OrderRefundCreate extends OrderRefund {
    }

    @Setter
    @Getter
    @ToString
    public static class OrderRefundCreateResp extends OrderRefund {
        private Integer qty;
    }

    @Setter
    @Getter
    @ToString
    public static class OrderRefund {
        List<RefundLine> refundLines;
        private Double refundTotal;
        private String orderNo;
        private String refundDate;
        private String state;
        private String reason;
        @JsonAnyGetter
        @JsonAnySetter
        @JsonIgnore
        private Map<String, Object> extraField = new HashMap<>();
    }

    @Setter
    @Getter
    @ToString
    public static class RefundLine {
        private String productName;
        private String lineId;
        private Integer qty;
        private Double priceSubTotal;
        @JsonAnyGetter
        @JsonAnySetter
        @JsonIgnore
        private Map<String, Object> extraField = new HashMap<>();
    }

    @Setter
    @Getter
    @ToString
    public static class DeleteDeal {
        private String bk;
        private String orderNo;
        private String objId;
        private String dateOrder;
        private BigDecimal amountPaid;

        public DeleteDeal() {
        }

        public DeleteDeal(Order order) {
            this.bk = order.getBk();
            this.orderNo = order.getOrderNo();
            this.objId = order.getProfileName();
            this.dateOrder = order.getDateOrder();
            this.amountPaid = order.getAmountPaid();
        }
    }

    @Setter
    @Getter
    @ToString
    public static class CancelDeal extends DeleteDeal {
        private String state;
        private String salesChannel;
        private String store;

        public CancelDeal() {
        }

        public CancelDeal(Order order) {
            super(order);
            this.salesChannel = order.getSalesChannel();
            this.store = order.getStore();
            String orderState = "已取消";
            Map<String, Object> extraField = order.getExtraField();
            if (extraField != null) {
                Object state = extraField.get("state");
                if (state != null) {
                    orderState = state.toString();
                }
            }
            this.state = orderState;
        }
    }
}
