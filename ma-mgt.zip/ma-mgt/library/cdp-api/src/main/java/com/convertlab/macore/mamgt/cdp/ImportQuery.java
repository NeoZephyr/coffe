package com.convertlab.macore.mamgt.cdp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;
import java.util.Map;

/**
 * @author Mr.黄
 * @description 原/apiv2/triggerUdoImport接口和/apiv2/triggerUdoTagImport的request
 * @since 2023/11/10 17:10
 **/
@Setter
@Getter
@ToString
public class ImportQuery {

    @Setter
    @Getter
    public static class ImportAccount {
        private String type;
        private String accessKey;
        private String accessSecret;
        private Map<String, Object> additionInfo;
    }
    @Setter
    @Getter
    @ToString
    public static class ProfileImportRequest {
        private DataType dataType;
        @JsonProperty(value = "objId")
        private String profileName;
        private List<Map<String, String>> sources;
        private List<Mapping> mappings;
        private Long taskId;
        private String sparkJobsTaskTopic;
        private ImportAccount account;
        // 新加入群组的UDO通知自动流, 默认为true
        private Boolean triggerJoinListEvent = true;
    }

    @Setter
    @Getter
    @ToString
    public static class TraitImportRequest {
        private DataType dataType;
        @JsonProperty(value = "objId")
        private String profileName;
        private Map<String, Object> settings;
        private List<Map<String, String>> sources;
        private List<Mapping> mappings;
        private List<TraitDefinition> traitDefinitions;
        private Integer taskId;
        private String sparkJobsTaskTopic;

        @Setter
        @Getter
        @ToString
        public static class TraitDefinition {
            private String name;
            private Type type;
            private ValueType valueType;
            @JsonProperty(value = "objId")
            private String profileName;
            private Long id;
            private String cdpId;
            private Long tagId;
            private String refObjId;
            private String refFieldId;
            private String errorMessage;

            public enum ValueType {
                Number, Text, Date, DateTime, LookupRef
            }

            public enum Type {
                multiValue, singleValue
            }
        }
    }

    @Setter
    @Getter
    @ToString
    public static class Mapping {
        private String sourceType;
        private String source;
        private String destination;
    }


    @Getter
    @Setter
    public static class SegmentImportRequest {
        private DataType dataType;
        private List<SegmentDefinition> segmentDefinitions;
        private Map<String, Object> settings;
        private List<Mapping> mappings;
        private String sparkJobsTaskTopic;
        private List<Map<String, String>> sources;
        @JsonProperty(value = "objId")
        private String profileName;
        private String triggerBy;
        private Integer taskId;

        @Setter
        @Getter
        @ToString
        public static class SegmentDefinition {
            private String name;
            //cdp的id 例如：segment_a5b5d102_1
            private String cdpId;
            //id dmhub中的id:1805124305856702464
            private Long id;
            private String errorMessage;

        }


    }

    public enum DataType {
        objects, objectsTrait, objectsSegment
    }
}
