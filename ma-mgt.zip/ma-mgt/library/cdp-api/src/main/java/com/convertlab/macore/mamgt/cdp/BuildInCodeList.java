package com.convertlab.macore.mamgt.cdp;

import com.convertlab.macore.mamgt.cdp.dto.CodeListDto;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.base.BizObjectMeta;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
public class BuildInCodeList extends BizObjectMeta {
    @JsonProperty("buildin_codelist")
    Map<String, List<CodeListDto>> buildInCodeList;
}
