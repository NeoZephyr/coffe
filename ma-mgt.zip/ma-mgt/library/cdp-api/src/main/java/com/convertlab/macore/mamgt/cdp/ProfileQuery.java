package com.convertlab.macore.mamgt.cdp;

import com.convertlab.macore.mamgt.cdp.dto.Profile;
import com.convertlab.macore.mamgt.filter.model.filterv2.Filters;
import com.fasterxml.jackson.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProfileQuery {
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkGetRequest {
        private List<String> ids;
        private List<String> select;

        /**
         * 是否通过数据库表中的列名来查询
         */
        private Boolean useColumnName;

        /**
         * 是否仅返回值不为空的对象
         */
        private Boolean valueNotNull;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkGetByIdentityRequest {
        private String identityType;
        private List<String> identityValues;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkGetResponse {
        private Map<String, String> meta;
        private List<Map<String, Object>> rows;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkAddRequest {

        private List<Map<String, Object>> rows;

        /*
         * 是否校验关联的对象是否存在
         */
        private Boolean checkRelatedIdExist;

    }


    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class ValidatedRow {
        public ValidatedRow(Map<String, Object> row, String errorMsg, List<Object> errorFields, Integer index) {
            this.errorMsg = errorMsg;
            this.errorFields = errorFields;
            this.index = index;
            if(StringUtils.isBlank(errorMsg)){
                this.row = row;
            }
        }

        private String errorMsg;
        private List<Object> errorFields;
        private Integer index;

        @Builder.Default
        @JsonIgnore
        private Map<String, Object> row = new HashMap();

        @JsonAnySetter
        public void put(final String key, final Object value) {
            if(key.equals("errorMsg") || key.equals("errorFields") || key.equals("index")) {
                throw new RuntimeException("can't use errorMsg、errorFields、index as profile field name.");
            }
            row.put(key, value);
        }

        @JsonAnyGetter
        public Map<String, Object> getProperties() {
            return row;
        }
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkAddResponse {
        private List<String> added;
        private List<String> updated;
        private List<ValidatedRow> invalidRows;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkDeleteRequest {
        private List<String> ids;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkDeleteResponse {
        // 成功删除的ids
        private List<String> deleted;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ProfileListResponseVo {
        private List<Map<String, Object>> records;
        private Long total;
        private int page;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ProfileResponseVo {
        private List<Profile> records;
        private Long total;
        private int page;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class IdentityVo {
        String type;
        String value;
        String name;
        Long customerId;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BatchOperateRequest {
        private String taskType;
        private BatchOperateTaskDef taskDef;
        private Filters criteria;
        private Long segmentId;
        private List<String> bkList;
        private String profileName;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BatchOperateTaskDef {
        private List<BatchOperateProperty> properties;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BatchOperateProperty {
        private String property;
        private String inputValue;
    }
}
