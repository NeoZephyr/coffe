package com.convertlab.macore.mamgt.cdp.dto;

import com.convertlab.foundation.api.gdmdata.GdmData;

import java.util.Map;

public class GdmBizObjectData extends GdmData {

    public GdmBizObjectData(Map<String, Object> props) {
        super(props);
    }
}
