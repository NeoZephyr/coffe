package com.convertlab.macore.mamgt.cdp.dto;

import com.convertlab.foundation.library.utils.JsonUtils;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.*;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@Slf4j
public class Event {
    // 系统预置字段开始
    private long id;
    // Todo: customer_id 和bk能否统一？
    private String customerId;
    private String bk;

    private String event;
    private String date;
    private String externalId;
    private String objId;
    private String appVersion;
    private String batchId;
    private String browser;
    private String browserVersion;
    private String campaign;
    private String campaignName;
    private String contentName;
    private String device;
    private String domain;
    private String duration;
    private String employee;
    private String eventGroup;
    private Long fieldDate;
    private String fieldLocation;
    private int flowId;
    private int flowVersion;
    private int fromCollector;

    private String identityType;
    private String identityValue;
    private String identityType2;
    private String identityValue2;
    private String identityType3;
    private String identityValue3;
    private int inbound;
    private String internalContentId;
    private String ip;
    private String ipCountry;
    private String ipCity;
    private String ipProvince;
    private String ipCounty;

    private int isFirstEngage;
    private int isFirstTry;
    private String lastForwarder;
    private long lastUpdated;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private String model;
    private String network;
    private String os;
    private String osVersion;
    private String pageOpenId;
    private String pageType;
    private String path;
    private String platform;
    private String profileId;
    private int refScore;
    private String referrer;
    private String referrerName;
    private int score;
    private String screenWidth;
    private String screenHeight;
    private String sessionId;
    private int stepId;
    private String tag;
    private String url;
    private String utm;
    private String utma;
    // 系统预置字段开始

    // 系统事件预置属性复用其他预置数据库字段
    private String targetId;
    private String targetName;
    private String summary;
    private String channelAccount;
    private String appName;
    private String pageId;
    private String channelType;

    @JsonIgnore
    @Builder.Default
    private Map<String, Object> properties = new HashMap();

    @JsonAnySetter
    public void put(final String key, final Object value) {
        boolean hasField = false;
        try {
            Field[] fields = Event.class.getDeclaredFields();
            List<String> excludeProperties = Arrays.asList("properties");
            for(Field field : fields){
                String fieldName = field.getName();
                if(!excludeProperties.contains(fieldName) && fieldName.equals(key)){
                    BeanUtils.setProperty(this, fieldName, value);
                    hasField = true;
                }
            }
        }catch (Exception e){
            log.warn("failed to set event field {} with value {}", key, value, e);
        }
        if(!hasField) {
            properties.put(key, value);
        }
    }

    @JsonAnyGetter
    public Map<String, Object> getProperties() {
        return properties;
    }

    public static Event from(Map<String, Object> map){
        Event instance = new Event();
        try {
            Field[] fields = Event.class.getDeclaredFields();
            List<String> excludeProperties = Arrays.asList("properties");
            List<String> addedFields = new ArrayList<>();
            for(Field field : fields){
                String fieldName = field.getName();
                if(!excludeProperties.contains(fieldName) && map.containsKey(fieldName)){
                    BeanUtils.setProperty(instance, fieldName, map.get(fieldName));
                    addedFields.add(fieldName);
                }
            }
            // 将非固定字段填入properties
            map.entrySet().forEach(it->{
                if(!addedFields.contains(it.getKey())){
                    instance.put(it.getKey(), it.getValue());
                }
            });
        } catch (Exception e) {
            log.error("failed to initialize a Event from map {}", JsonUtils.instanceOfDto().obj2Json(map),e);
        }
        return instance;
    }
}
