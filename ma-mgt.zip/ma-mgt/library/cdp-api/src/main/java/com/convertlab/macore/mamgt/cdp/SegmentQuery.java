package com.convertlab.macore.mamgt.cdp;

import com.convertlab.macore.mamgt.cdp.dto.Segment;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.associated.ProfileAttributedSegmentPropBizMeta;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class SegmentQuery {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkGetByIdsRequest {
        private List<String> ids;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkGetRequest {
        private List<String> ids;

        private List<Long> segments;

        private List<String> select;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkGetVo {
        private Map<String, String> meta;
        private Map<String, List<Map<String, Object>>> data;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class SegmentVo {
        @Schema(name = "群组名称", description = "群组名称(中文)")
        private String name;

        @Schema(name = "是否为静态群组", description = "群组类型: static- 静态群组; dynamic- 智能群组;")
        private Boolean isStatic;

        @Schema(name = "是否是外部群组", description = "是否是外部群组")
        private Boolean isExternal;

        @Schema(name = "群组条件")
        private String filters;

        @Schema(name = "类型 static-静态的 dynamic-动态的 external-外部的")
        private String type;

        @Schema(name = "描述")
        private String description;

        @Schema(name = "更新间隔类型", description = "间隔类型: day- 每天; week- 每周; month- 每月; year- 每年; manual- 手动更新；schedule- 定时更新")
        private String intervalType;

        @Schema(name = "更新间隔值")
        private String intervalValue;

        @Schema(name = "更新间隔描述")
        private String intervalDescription;

        @Schema(name = "所属分组id")
        private Long groupId;

        @Schema(name = "群组中对象数量")
        private Long count;

        @Schema(name = "群组中对象数量更新时间")
        private Date countUpdateTime;
        @Schema(name = "群组最后更新时间")
        private Date lastUpdated;

        @Schema(name = "群组状态", description = "群组状态：processing- 计算中; processed- 计算完成; failed- 计算失败")
        private String status;

        @Schema(name = "属性群组名称(entity名称)", description = "群组名称(entity名称)")
        private String segmentMetaRef;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class SegmentListResponseVo {
        private String segmentId;
        private Long count;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class SegmentPageVo {
        private List<Segment> records;
        private Long total;
        private int page;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class SegmentMemberTaskRequest {
        @Schema(name = "高级筛选类型，暂不支持分析，默认不填写")
        private String ruleType;
        @Schema(name = "任务类型：copy_to/move_to/add_to")
        private String taskType;
        @Schema(name = "目标群组内容")
        private SegmentMemberTaskDefRequest taskDef;
        @Schema(name = "高级筛选条件部分")
        private String rule;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class SegmentMemberTaskDefRequest {
        @Schema(name = "群组ID")
        private String segmentId;
        @Schema(name = "群组名称")
        private String segmentName;
    }
}
