package com.convertlab.macore.mamgt.cdp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

public class SecondaryProfileQuery {
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkGetByPrimaryProfilesRequest {
        private List<String> ids;
        private List<String> select;
        private List<String> primaryProfileIds;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkGetResponse {
        private Map<String, List<Map<String, Object>>> data;
    }
}
