package com.convertlab.macore.mamgt.cdp;

import com.convertlab.macore.mamgt.filter.model.filterv2.Filters;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Data
public class ProfileTask {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ExportDataRequest<T> {

        private String exportFileType;

        private String taskSource;

        private String taskType;

        private String remarks;
        private String listId;

        private Filters<T> criteria;

        private String select;

        @Builder.Default
        // 以脱敏的方式导出属性；当用户角色在设置数据脱敏时被设置成例外时，该字段可以为false
        private Boolean exportWithMask = true;

        /**
         * 导出时区
         */
        private String exportTimezoneId;

        public String getExportTimezoneId() {
            if (Objects.isNull(exportTimezoneId)) {
                return "UTC";
            }
            return exportTimezoneId;
        }
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ExportDataResponse<T> {

        private String failReason;

        private String remark;

        private String allCount;

        private String failedCount;

        private String successCount;

        private String taskType;

        private String taskSource;

        private String id;

        private String objId;
    }

    /**
     * 导入导出任务的Vo
     */
    @Data
    public static class BatchTaskVo {
        private Long id;
        private String objId;
        public BatchTaskVo(Map<String, Object> map) {
            if(map !=null){
                map.entrySet().forEach(it->{
                    if(it.getKey().equals("id")){
                        this.setId(Long.valueOf(it.getValue().toString()));
                    }else if(it.getKey().equals("objId")){
                        this.setObjId(it.getValue().toString());
                    }else{
                        this.put(it.getKey(),it.getValue());
                    }
                });
            }
        }

        @JsonIgnore
        private Map<String, Object> properties = new HashMap();

        @JsonAnySetter
        public void put(final String key, final Object value) {
            properties.put(key, value);
        }

        @JsonAnyGetter
        public Map<String, Object> getProperties() {
            return properties;
        }
    }
}
