package com.convertlab.macore.mamgt.cdp.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CodeListDto implements Serializable {
    public CodeListDto() {

    }

    private String type;
    private String code;
    private String value;
    private int position;
}
