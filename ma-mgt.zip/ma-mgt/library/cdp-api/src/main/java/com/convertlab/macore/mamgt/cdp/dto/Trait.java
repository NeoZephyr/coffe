package com.convertlab.macore.mamgt.cdp.dto;

import com.convertlab.macore.mamgt.cdp.dto.bizmeta.associated.CodeListOption;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.associated.RefFieldMeta;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.util.*;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "主档案标签", description = "主档案标签，包括客户标签和UDO标签")
public class Trait {

    public final static String CATEGORY_STATIC = "static_tag";
    public final static String CATEGORY_EXTERNAL = "external_tag";

    public final static String VALUE_TYPE_TEXT = "Text";
    public final static String VALUE_TYPE_NUM = "Number";
    public final static String VALUE_TYPE_DATE = "Date";
    public final static String VALUE_TYPE_DATETIME = "DateTime";
    public final static String VALUE_TYPE_LOOKUP_REF = "LookupRef";

    public final static Set<String> VALUE_TYPES = new HashSet<>(Arrays.asList(VALUE_TYPE_TEXT, VALUE_TYPE_NUM, VALUE_TYPE_DATE, VALUE_TYPE_DATETIME, VALUE_TYPE_LOOKUP_REF));

    @Schema(name = "id")
    private Long id;

    @JsonGetter(value = "idStr")
    public String getIdStr(){
        return id.toString();
    }

    @Schema(name = "标签名称", description = "标签名称")
    private String name;

    @Schema(name = "标签id", description = "标签id")
    private String labelId;

    @Schema(name = "标签种类", description = "标签种类：static_tag、rule_tag、model_tag、external_tag")
    private String category;

    @Schema(name = "是否为多值标签")
    private Boolean multiValue = false;

    @Schema(name = "值类型", description = "值类型：文本、数值、日期、查找关系（客户/udo）")
    private String valueType;

    @Schema(name = "主档案名称", description = "客户为customer, udo为objId")
    private String profileName;

    @Schema(name="标签标记的对象数量")
    private Long count;

    @Schema(name="标签标记对象数量更新时间")
    private Date countUpdateTime;

    @Schema(name="所有者id")
    private Integer ownerId;

    @Schema(name="所有者名称")
    private String ownerName;

    @Schema(name="创建者名称")
    private String creatorName;

    @Schema(name="创建来源")
    private String creatorFrom;

    @Schema(name="创建时间")
    private Date dateCreated;

    @Schema(name="最后更新时间")
    private Date lastUpdated;

    @Schema(name = "引用对象的id")
    private String refObjId;

    @Schema(name ="引用对象的字段id，引用对象为udo时为bk，customer为id")
    private String refFieldId;

    @Schema(name = "标签状态", description = "标签状态：processing- 计算中; processed- 计算完成; failed- 计算失败")
    private String status;

    @Schema(name = "更新间隔类型", description = "间隔类型: day- 每天; week- 每周; month- 每月; year- 每年; manual- 手动更新；schedule- 定时更新")
    private String intervalType;

    @Schema(name= "更新间隔值")
    private String intervalValue;

    @Schema(name= "更新间隔描述")
    private String intervalDescription;

    private Boolean hasOptions = false;
    
    private String type;

    private String dimension;

    // set default sequence value to 9999 to ensure new tag always add at end of tag list.
    @Schema(name= "标签顺序")
    private Integer sequence;

    private Long ruleId;

    @Schema(name = "更新规则", description = "更新规则(hand 手动更新,cycle 周期更新,scheduled 定时更新)")
    private String updateRule;

    @Schema(name = "值标签赋值规则")
    private String assignmentRule;

    @Schema(name = "是否可编辑")
    private Boolean editable;

    @Schema(name = "是否删除中")
    private Boolean deleting = false;

    private Integer externalIndex;

    private String externalId;

    @Schema(name="所有者部门编码")
    private String deptCode;

    private String path;

    @Schema(name = "定时更新的定时时间")
    private Date scheduledTime;

    @Schema(name = "定时重算开始时间", description = "定时重算开始时间，并用于标记定时重算是否已经执行")
    private Date startTime;

    @Schema(name = "标签重算启动时间")
    private Date triggerTime;

    @Schema(name ="客户同意配置")
    private String consentInfo;

    @Schema(name ="所属分组id")
    private Long groupId;

    @Schema(name="是否已删除")
    private Boolean deleted;

    /**
     * 可选项关联CodeList类型
     */
    RefFieldMeta meta;
    @Schema(name="物理库名")
    String olapDbName;
    @Schema(name="物理表名")
    String olapTableId;
    @Schema(name="suKey用于智能标签回调通知")
    String suKey;
}
