package com.convertlab.macore.mamgt.cdp.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PageDataDto<T> {
    private List<T> records;
    private Long total;
    private int page;
}
