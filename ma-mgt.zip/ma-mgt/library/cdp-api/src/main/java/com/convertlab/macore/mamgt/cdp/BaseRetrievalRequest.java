package com.convertlab.macore.mamgt.cdp;

import com.convertlab.foundation.api.queryengine.FilterV4Dto;
import com.convertlab.macore.mamgt.cdp.common.enums.OnlyTypeEnum;
import com.convertlab.macore.mamgt.cdp.dto.SegmentGroupStrategy;
import com.convertlab.macore.mamgt.cdp.dto.SelectField;
import com.convertlab.macore.mamgt.filter.model.filterV4.request.WhereVO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 基础取数请求对象
 */
@Setter
@Getter
@ToString
public class BaseRetrievalRequest implements Serializable {
    @Schema(title = "指定写入结果的topic", description = "指定写入结果的topic", example = "reactflow_from_list_flow-2360_1_false")
    private String dataTopic;
    @Schema(title = "kafka message key", description = "kafka message key", example = "xxx")
    private String messageKey;
    @Schema(title = "仅仅获取指定对象的数据（选填）", description = "仅仅获取指定对象的数据（选填）", example = "APP_NOTIFICATION_IDENTITY")
    private OnlyTypeEnum onlyType;

    @Schema(title = "异步分页大小", description = "异步取数返回的kafka消息分页大小，默认1000", example = "1000")
    private long batchSize = 1000;

    @Schema(title = "字段列表", description = "需要查询的字段列表", example = "[{\"fieldName\": \"c_car.id\"}]")
    private List<SelectField> select;
    @Schema(title = "群组策略", description = "群组策略")
    private SegmentGroupStrategy segmentGroupStrategy;
    @Schema(title = "关联查询非人群包的数据", description = "关联查询非人群包的数据(暂不实现)")
    private Map<String, Object> dataEnrich;
    @Schema(title = "透传的数据对象Map", description = "透传的数据对象Map", example = "{\"batchId\":\"flow-7667_0_false@@3\"}")
    private Map<String, Object> transData;
    @Schema(title = "查询的条件对象", description = "查询的条件对象", example = "" +
            "{\n" +
            "  \"or\": {\n" +
            "    \"conditions\": [\n" +
            "      {\n" +
            "        \"eq\": {\n" +
            "          \"left\": {\n" +
            "            \"type\": \"COLUMN\",\n" +
            "            \"value\": \"name\"\n" +
            "          },\n" +
            "          \"right\": {\n" +
            "            \"type\": \"VALUE\",\n" +
            "            \"value\": \"自动化测试\"\n" +
            "          }\n" +
            "        }\n" +
            "      },\n" +
            "      {\n" +
            "        \"eq\": {\n" +
            "          \"left\": {\n" +
            "            \"type\": \"COLUMN\",\n" +
            "            \"value\": \"name\"\n" +
            "          },\n" +
            "          \"right\": {\n" +
            "            \"type\": \"VALUE\",\n" +
            "            \"value\": \"Bob\"\n" +
            "          }\n" +
            "        }\n" +
            "      }\n" +
            "    ]\n" +
            "  }\n" +
            "}")
    /**
     * gdm条件对象（和 profileFilterCondition 二选一）
     */
    private FilterV4Dto.LogicalOperator profileCondition;
    /**
     * 前端v4条件对象（和 profileCondition 二选一）
     */
    private WhereVO.LogicalOperator profileFilterCondition;

    @Setter
    @Getter
    @ToString
    public static class DataEnrich implements Serializable {
    }
}

