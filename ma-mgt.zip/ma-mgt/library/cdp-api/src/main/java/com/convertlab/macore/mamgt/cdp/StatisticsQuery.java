package com.convertlab.macore.mamgt.cdp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

public class StatisticsQuery {
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkGetRequest {
        /**
         * 档案id
         */
        private List<String> ids;
        /**
         * 档案指标keys
         */
        private List<String> indexes;
    }
}
