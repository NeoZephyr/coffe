package com.convertlab.macore.mamgt.cdp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

public class IdentityQuery {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkGetRequest {
        private List<String> ids;
        private List<String> identities;
        private List<String> select;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkGetResponse {
        private Map<String, String> meta;
        private Map<String, List<Map<String, Object>>> data;
    }

}
