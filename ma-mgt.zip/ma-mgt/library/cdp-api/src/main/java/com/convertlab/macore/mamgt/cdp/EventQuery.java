package com.convertlab.macore.mamgt.cdp;

import com.convertlab.macore.mamgt.cdp.dto.Event;
import lombok.*;

import java.util.List;
import java.util.Map;

/**
 * 事件请求体
 */
public class EventQuery {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class PagedEventsVo {
        private List<Event> data;
    }

    @Data
    @AllArgsConstructor
    public static class AsyncResponse {
        private boolean success;
        private String traceId;
    }

    @Data
    public static class BulkAddRequest {
        private List<Event> events;
        private Map<String, String> commonProps;
    }

}
