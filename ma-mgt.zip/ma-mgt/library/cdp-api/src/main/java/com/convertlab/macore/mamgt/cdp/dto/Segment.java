package com.convertlab.macore.mamgt.cdp.dto;

import com.fasterxml.jackson.annotation.JsonGetter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Getter
@Setter
@Schema(name = "档案群组", description = "档案群组，包括客户群组和UDO群组")
@ToString
public class Segment {

    @Schema(name = "id")
    private Long id;

    @JsonGetter(value = "idStr")
    public String getIdStr() {
        return id.toString();
    }

    @Schema(name = "群组名称", description = "群组名称")
    private String name;

    @Schema(name = "档案名称", description = "客户为customer, udo为objId")
    private String profileName;

    @Schema(name = "是否为静态群组", description = "群组类型: static- 静态群组; dynamic- 智能群组; external- 外部群组")
    private Boolean isStatic = true;

    @Schema(name = "群组状态", description = "群组状态：processing- 计算中; processed- 计算完成; failed- 计算失败")
    private String status;

    @Schema(name = "更新间隔类型", description = "间隔类型: day- 每天; week- 每周; month- 每月; year- 每年; manual- 手动更新；schedule- 定时更新")
    private String intervalType;

    @Schema(name = "更新间隔值")
    private String intervalValue;

    @Schema(name = "更新间隔描述")
    private String intervalDescription;

    @Schema(name = "群组条件")
    private String filters;

    @Schema(name = "群组中对象数量")
    private Long count;

    @Schema(name = "群组中对象数量更新时间")
    private Date countUpdateTime;

    @Schema(name = "所有者id")
    private Integer ownerId;

    @Schema(name = "所有者名称")
    private String ownerName;

    @Schema(name = "所有者部门编码")
    private String deptCode;

    @Schema(name = "创建者id")
    private Integer creatorId;

    @Schema(name = "创建者名称")
    private String creatorName;

    @Schema(name = "描述")
    private String description;

    @Schema(name = "创建时间")
    private Date dateCreated;

    @Schema(name = "最后更新时间")
    private Date lastUpdated;

    @Schema(name = "是否允许自动更新")
    private boolean autoUpdate;

    @Schema(name = "是否为外部群组", description = "群组类型: static- 静态群组; dynamic- 智能群组; external- 外部群组")
    private boolean isExternal;

    @Schema(name = "是否特征值分组", description = "根据数值、日期特征（属性&值标签）对客户进行排序分组，原群组被拆分后将生成多个新的群组，在新群组上记录isFeature = 1 的标记")
    private boolean isFeature;

    @Schema(name = "用于计算的sql")
    private String calculateSql;

    @Schema(name = "定时启动")
    private Date scheduleTime;

    @Schema(name = "")
    private Date startTime;

    @Schema(name = "群组重算启动时间")
    private Date triggerTime;

    @Schema(name = "客户同意配置")
    private String consentInfo;

    @Schema(name = "是否已删除")
    private boolean deleted;

    @Schema(name = "所属分组id")
    private Long groupId;

    @Schema(name = "关联群组meta")
    private String segmentMetaRef;

}
