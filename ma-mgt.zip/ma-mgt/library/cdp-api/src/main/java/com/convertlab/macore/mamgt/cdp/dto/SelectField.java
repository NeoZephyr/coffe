package com.convertlab.macore.mamgt.cdp.dto;

import com.convertlab.macore.mamgt.cdp.dto.bizmeta.associated.RefFieldMeta;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.io.Serializable;

@Setter
@Getter
@ToString
@EqualsAndHashCode
public class SelectField implements Serializable {
    @Schema(title = "字段名称", description = "字段名称", example = "c_car.id")
    private String fieldName;
    @Schema(title = "字段的meta", description = "字段的meta", example = "{\"type\":\"String\"}")
    private RefFieldMeta meta;

    public SelectField() {
    }

    public SelectField(String fieldName) {
        this.fieldName = fieldName;
    }

    public SelectField(String fieldName, RefFieldMeta meta) {
        this.fieldName = fieldName;
        this.meta = meta;
    }
}
