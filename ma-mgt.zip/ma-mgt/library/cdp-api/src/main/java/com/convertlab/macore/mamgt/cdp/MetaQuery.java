package com.convertlab.macore.mamgt.cdp;

import com.convertlab.macore.mamgt.cdp.dto.bizmeta.associated.ProfileAttributedSegmentPropBizMeta;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

public class MetaQuery {
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class AttributedSegmentFamilyRequest {
        @Schema(title = "属性群组entity名称")
        String name;
        @Schema(title = "中文名称", description = "中文名称", example = "属性人群包001")
        String label;
        @Schema(title = "描述", description = "描述", example = "属性人群包001")
        private String description;
        @Schema(title = "创建人姓名", description = "创建人姓名", example = "张三")
        String creatorName;
        @Schema(title = "所属udo", description = "所属udo", example = "customer")
        String objId;
        @Builder.Default
        Boolean showInTimeline = false;
        @Builder.Default
        Boolean showInFilter = false;
        @Builder.Default
        Boolean showInDimension = false;
        @Builder.Default
        Boolean showInFlow = false;
        @Builder.Default
        Boolean showInConfig = true;
        @Builder.Default
        Boolean showInApi = true;
        @Builder.Default
        Boolean engaged = false;
        List<ProfileAttributedSegmentPropBizMeta> props;
    }

}
