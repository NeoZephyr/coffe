package com.convertlab.macore.mamgt.cdp.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

/**
 * 群组优先级
 */
@Getter
@Setter
@Schema(name = "群组优先级", description = "群组优先级")
@ToString
public class ListPriorityGroupContent {
    private Long id;
    private Long tenantId;
    private Long groupId;
    private Long listId;
    private Integer priority;
    private Date lastUpdated;
    private Date dateCreated;
    private Long version;
}
