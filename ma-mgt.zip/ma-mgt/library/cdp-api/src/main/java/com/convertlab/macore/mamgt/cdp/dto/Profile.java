package com.convertlab.macore.mamgt.cdp.dto;

import com.convertlab.foundation.api.gdmdata.GdmData;

import java.util.Map;

public class Profile extends GdmData {
    public Profile(Map<String, Object> props) {
        super(props);
    }
}