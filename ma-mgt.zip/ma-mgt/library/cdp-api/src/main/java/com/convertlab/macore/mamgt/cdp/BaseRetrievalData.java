package com.convertlab.macore.mamgt.cdp;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;
import java.util.Map;


@Setter
@Getter
@ToString
@Schema(title = "基本取数响应结果", description = "基本取数响应结果")
public class BaseRetrievalData implements Serializable {
    @Schema(title = "主档案名称", description = "主档案名称", example = "customer")
    private String profileName;
    @Schema(title = "总记录行数", description = "总记录行数", example = "1000")
    private Integer totalRecords = 0;
    @Schema(title = "取出的结果map", description = "取出的结果map", example = "[\n" +
            "  {\n" +
            "    \"id\": \"test0922\",\n" +
            "    \"c_car.ownerCustoemr.id\": 1337429989347299300\n" +
            "  },\n" +
            "  {\n" +
            "    \"id\": \"JP\",\n" +
            "    \"c_car.ownerCustoemr.id\": 1296409538798436400\n" +
            "  }\n" +
            "]")
    private List<Map<String, Object>> rows;

    //数据发送到topic时使用
    private String taskId;
}

