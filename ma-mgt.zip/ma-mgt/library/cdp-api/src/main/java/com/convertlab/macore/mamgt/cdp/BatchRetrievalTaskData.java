package com.convertlab.macore.mamgt.cdp;


import com.convertlab.macore.mamgt.cdp.BaseRetrievalData;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.Map;


@Setter
@Getter
@ToString
@Schema(title = "异步批量取数任务异步响应结果", description = "异步批量取数任务异步响应结果")
public class BatchRetrievalTaskData extends BaseRetrievalData implements Serializable {
    @Schema(title = "透传的数据对象Map", description = "透传的数据对象Map", example = "{\"batchId\":\"flow-7667_0_false@@3\"}")
    private Map<String, Object> transData;
    @Schema(title = "页面数据大小", description = "页面数据大小", example = "500")
    private Integer pageSize;
    @Schema(title = "当前任务的id", description = "当前任务的id", example = "123")
    private String taskId;
    @Schema(title = "总分页数", description = "总分页数", example = "20")
    private Integer totalPage;
    @Schema(title = "当前页数", description = "当前页数", example = "1")
    private Integer currentPage;
    @Schema(title = "群组id", description = "群组id", example = "456789")
    private String segmentId;
}

