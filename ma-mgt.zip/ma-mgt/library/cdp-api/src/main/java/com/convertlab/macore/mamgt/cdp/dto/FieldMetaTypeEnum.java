package com.convertlab.macore.mamgt.cdp.dto;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.ObjectUtils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * 属性字段类型枚举
 */
@Getter
@RequiredArgsConstructor
@Slf4j
public enum FieldMetaTypeEnum {
    LOOKUP_REF("lookup_ref", "查找关系"),
    CODE_LIST("code_list", "映射编码类型"),
    LONG("Long", "long数值类型"),
    STRING("String", "字符串类型"),
    GENDER("Gender","性别类型"),
    BOOLEAN("Boolean", "布尔类型"),
    DATE("Date", "日期类型"),
    DATETIME("DateTime", "日期时间类型"),
    CUSTOMER_STAGE("CustomerStage","用户阶段"),
    NUMBER("Number", "数值类型"), // 前端的Number类型，需要根据内容动态解析成Long或者Double类型
    USERS("Users", "用户类型");


    private final String val;
    private final String desc;

    /**
     * 将UI类型映射到字段枚举类型
     * [
     *     "Long", -> LONG
     *     "Text", -> STRING
     *     "Gender", -> GENDER
     *     "Phone", -> STRING
     *     "Boolean", -> BOOLEAN
     *     "EMail", -> STRING
     *     "Date", -> DATE
     *     "Country", -> STRING
     *     "Province", -> STRING
     *     "City", -> STRING
     *     "County", -> STRING
     *     "CustomerStage", -> refObj: customer_meta type: customer_stage
     *     "DateTime", -> DATE
     *     "CustomerSource", -> STRING
     *     "CustomerContentName", -> STRING
     *     "Number", ->  NUMBER
     *     "Money", ->
     *     "Users", -> USERS
     *     "LongText" -> STRING
     * ]
     */
    private static Map<String, FieldMetaTypeEnum> UI_TYPES_MAPPING = new HashMap(){{
        put("Long", LONG);
        put("Text", STRING);
        put("String", STRING);
        put("Gender", GENDER);
        put("Phone", STRING);
        put("Mobile", STRING); // TBD UDO的手机类型是Mobile，客户是Phone，此处兼容历史Meta数据
        put("Boolean", BOOLEAN);
        put("EMail", STRING);
        put("Email", STRING); // TBD UDO的邮箱类型的m是小写，此处兼容历史Meta数据
        put("Date", DATE);
        put("Country", STRING);
        put("Province", STRING);
        put("City", STRING);
        put("County", STRING);
        put("CustomerStage", CUSTOMER_STAGE);
        put("DateTime", DATETIME);
        put("CustomerSource", STRING);
        put("CustomerContentName", STRING);
        put("Number", NUMBER);
        put("Money", NUMBER);
        put("Decimal", NUMBER);
        put("Integer", NUMBER);
        put("Double", NUMBER);
        put("Users", USERS);
        put("LongText", STRING);
        put("LookupRef", LOOKUP_REF);
    }};


    /**
     * 根据属性的type字段，获取对应的枚举值; type字段是customer-meta的属性字段，或者event_types的属性字段
     * @param val
     * @return
     */
    public static FieldMetaTypeEnum getEnumByUIMetaType(String val) {
        if (ObjectUtils.isEmpty(val)) {
            throw new IllegalArgumentException("empty FieldMeta type: " + val);
        }
        if(UI_TYPES_MAPPING.get(val) != null){
            return UI_TYPES_MAPPING.get(val);
        }else{
            throw new IllegalArgumentException("unknown FieldMeta type: " + val);
        }
    }

    /**
     * 根据值获取枚举， e.g String -> STRING
     * @param val
     * @return
     */
    public static FieldMetaTypeEnum getFieldMetaTypeByVal(String val) {
        if (ObjectUtils.isEmpty(val)) {
            throw new IllegalArgumentException("unknown FieldMeta val: " + val);
        }
        if("Text".equals(val)){
            // 兼容值标签的value_type : Text类型
            val = "String";
        }
        final String _val = val;
        return Arrays.stream(FieldMetaTypeEnum.values())
                .filter(x -> _val.equals(x.getVal()))
                .findAny()
                .orElseThrow(() -> new IllegalArgumentException("unknown column type: " + _val));
    }
}
