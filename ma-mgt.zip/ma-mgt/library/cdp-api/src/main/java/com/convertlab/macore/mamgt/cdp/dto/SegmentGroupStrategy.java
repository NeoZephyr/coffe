package com.convertlab.macore.mamgt.cdp.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Setter
@Getter
@ToString
public class SegmentGroupStrategy implements Serializable {
    @Schema(title = "需要按优先级过滤的群组组id", description = "需要按优先级过滤的群组组id", example = "123456")
    private String filterByPriorityGroupId;
}
