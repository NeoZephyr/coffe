package com.convertlab.macore.mamgt.cdp.dto;

import lombok.ToString;

import javax.annotation.Nonnull;
import java.util.HashMap;
import java.util.Map;

@ToString
public class KvPair extends HashMap<String, Object> {
    public KvPair(){
        super();
    }
    public KvPair(@Nonnull Map<String, Object> props) {
        super(props);
    }

    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof Map)) {
            return false;
        }
        Map<?,?> m = (Map<?,?>) o;
        if (m.size() != size()) {
            return false;
        }
        try {
            for (Entry e : entrySet()) {
                Object key = e.getKey();
                Object value = e.getValue();
                if (value == null) {
                    if (!(m.get(key) == null && m.containsKey(key))) {
                        return false;
                    }
                } else {
                    if (!value.equals(m.get(key))) {
                        return false;
                    }
                }
            }
        } catch (ClassCastException unused) {
            return false;
        } catch (NullPointerException unused) {
            return false;
        }
        return true;
    }
}
