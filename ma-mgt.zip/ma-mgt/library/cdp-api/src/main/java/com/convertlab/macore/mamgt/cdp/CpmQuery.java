package com.convertlab.macore.mamgt.cdp;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

public class CpmQuery {
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Builder
    public static class CpmPurposeVo {
        String code;
        String name;
        String description;
        String column;
        String label;
        String type;
    }

    public static class CpmConsentVo {
        String purposeCode;
        String status;
        String collectionPointCode;
        String captureTime;
        String customerId;
        String personalId;
        boolean deleted;
        String effectiveToDate;
        String identityType;
        String identityValue;
        String dateCreated;
        String lasUpdated;
    }
}
