package com.convertlab.macore.mamgt.cdp;

import com.convertlab.macore.mamgt.cdp.dto.Trait;
import com.convertlab.macore.mamgt.cdp.dto.bizmeta.associated.CodeListOption;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSetter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.util.Date;
import java.util.List;
import java.util.Map;
public class TraitQuery {
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkGetRequest {
        private List<String> ids;

        private List<Long> traits;

        private List<String> select;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkGetVo {
        private Map<String, String> meta;
        private Map<String, List<Map<String, Object>>> data;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class GetByNamesRequest {
        private List<String> names;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkGetByIdsRequest {
        private List<String> ids;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class TraitListResponseVo {
        private String traitId;
        private Long count;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class TraitListPageResponseVo {
        private List<Map<String, Object>> records;
        private Long total;
        private int page;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class TraitResponseVo {
        private List<Trait> records;
        private Long total;
        private int page;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class TraitVo {

        /*
         * 标签名称
         */
        private String name;

        /*
         * 标签id
         */
        private String labelId;

        /*
         * 标签种类：static_tag、rule_tag、model_tag、external_tag
         */
        private String category;

        /*
         * 是否为多值标签
         */
        @Builder.Default
        private Boolean multiValue = false;

        /*
         * 值类型：文本、数值、日期、查找关系（客户/udo）
         */
        private String valueType;

        /*
         * 引用对象的id
         */
        private String refObjId;

        /*
         * 引用对象的字段id，引用对象为udo时为bk，customer为id
         */
        private String refFieldId;

        /*
         * 间隔类型: day- 每天; week- 每周; month- 每月; year- 每年; manual- 手动更新；schedule- 定时更新
         */
        private String intervalType;

        /*
         * 更新间隔值
         */
        private String intervalValue;

        /*
         * 更新间隔描述
         */
        private String intervalDescription;

        private Boolean hasOptions;

        private List<CodeListOption> options;

        private String type;

        private String dimension;

        /*
         * 标签顺序
         */
        private Integer sequence;

        private Long ruleId;

        /*
         * 更新规则(hand 手动更新,cycle 周期更新,scheduled 定时更新)
         */
        private String updateRule;

        /*
         * 值标签赋值规则
         */
        private String assignmentRule;

        private Integer externalIndex;

        private String externalId;

        private String deptCode;

        private String path;

        /*
         * 定时更新的定时时间
         */
        private Date scheduledTime;

        /*
         * 客户同意配置
         */
        private String consentInfo;

        /*
         * 所属分组id
         */
        private Long groupId;
        @Schema(name="标签标记的对象数量")
        private Long count;
        @Schema(name="标签标记对象数量更新时间")
        private Date countUpdateTime;
        private Date lastUpdated;
        @Schema(name = "标签状态", description = "标签状态：processing- 计算中; processed- 计算完成; failed- 计算失败")
        private String status;

    }


}
