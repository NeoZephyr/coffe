package com.convertlab.macore.noncopy.models;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Setter
@Getter
public class ExternalProfile {
    private String id;
    private String objId;
    private String name;
    private String profileName;
    private String description;
    private Boolean isSystem;
    private String status;
    private Date dateCreated;
    private Date lastUpdated;
    private String creatorName;

}
