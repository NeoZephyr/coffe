package com.convertlab.macore.noncopy.meta;

import com.convertlab.foundation.library.gdmmeta.model.general.dto.BaseMetaDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;
import java.util.List;

/**
 * 外部档案映射关系对象
 */
@Setter
@Getter
@ToString
public class ExternalProfileMapping extends BaseMetaDto {
    private List<ProfileMapping> profileMappings;

    @Setter
    @Getter
    public static class ProfileMapping {
        private String objId;
        private String name;
        private String profileName;
        private Date dateCreated;
        private Date lastUpdated;
    }
}
