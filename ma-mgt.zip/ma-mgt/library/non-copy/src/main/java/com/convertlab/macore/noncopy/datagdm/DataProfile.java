package com.convertlab.macore.noncopy.datagdm;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Mr.黄
 * @description data-gdm对应的DataTable domain
 * @since 2023/12/07 11:32
 **/
@Setter
@Getter
@ToString
public class DataProfile {
    public final static String PROFILE_PRIMARY_KEY = "_id";
    public final static String DATA_ZONE_ODS = "ODS";
    public final static String DATA_ZONE_DW = "DW";
    public final static String DATA_ZONE_DS = "DS";
    public final static String DATA_ZONE_PF = "PF";
    public final static String STORAGE_ENGINE_HIVE = "Hive";
    public final static String STORAGE_ENGINE_KUDU = "Kudu";
    public final static String STORAGE_ENGINE_HBASE = "Hbase";
    public final static String STORAGE_ENGINE_HUDI = "Hudi";
    public final static String STORAGE_ENGINE_DELTA = "Delta";
    public final static Integer DELTA_HISTORY_RETENTION_OFFSET = 10;

    private Long id;
    private Long version;
    private Integer projectId;
    @JsonProperty(value = "tableId")
    private String profileName;
    @JsonProperty(value = "tableName")
    private String title;
    private Map<String, Object> tableStructure;
    private Map<String, Object> pattern;
    private String entityType;
    private String storageEngine;
    private String storageTable;
    private String dataZone;
    private Boolean isSystem;
    private Date dateCreated;
    private Date lastUpdated;
    private Long ownerId;
    private Long creatorId;
    private String creatorName;
    private Boolean visible;
    private Boolean enableTrait;
    private Boolean enableSegment;
    private Date lastTableStatUpdated;
    private Long recordNum;
    private String tableStatData;
    private String requestId;
    private String status;
    private String errorMessage;
    private String belongTo;
    private String identity;
    private Boolean enableApi;
    private Boolean enableStreamingTrait;
    private String tablePath;
    private String storageDataSource;
    private String referrer;
    private String identityRule;
    private String identityRuleData;
    @JsonAnyGetter
    @JsonAnySetter
    @JsonIgnore
    private Map<String, Object> extraField = new HashMap<>();

}
