package com.convertlab.macore.noncopy.vo;

import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class ExternalProfileMappingVO {
    private String name;
    private String profileName;
}
