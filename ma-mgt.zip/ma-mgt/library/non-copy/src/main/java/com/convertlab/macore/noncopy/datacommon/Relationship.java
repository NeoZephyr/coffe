package com.convertlab.macore.noncopy.datacommon;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Mr.黄
 * @description data common Relationship
 * @since 2023/12/08 11:20
 **/
@Setter
@Getter
@ToString
public class Relationship {
    private String destinationStructure;
    private String sourceProperty;
    private String destinationProperty;
    private String relationType;
    private String backwardRelationId;
    private String backwardRelationName;
    @JsonAnyGetter
    @JsonAnySetter
    @JsonIgnore
    private Map<String, Object> extraField = new HashMap<>();
}
