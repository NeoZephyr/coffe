package com.convertlab.macore.noncopy.meta;

import com.convertlab.foundation.library.gdmmeta.model.general.dto.BaseMetaDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;
import java.util.Map;

/**
 * @author Mr.黄
 * @description non copy profile event model mapping
 * @since 2023/12/12 18:44
 **/
@Setter
@Getter
@ToString
public class ExternalProfileEventMapping extends BaseMetaDto {
    /**
     * profileName -> eventModels
     */
    private Map<String, List<EventModel>> eventMapping;
}
