package com.convertlab.macore.noncopy.common;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.util.ObjectUtils;

import java.util.Arrays;

/**
 * no copy 路由类型枚举
 */
@Getter
@RequiredArgsConstructor
public enum RouteTypeEnum {
    DATA_HUB("dataHub", "data hub 类型");

    private final String type;
    private final String desc;

    public static RouteTypeEnum getRouteTypeEnumByType(String type) {
        if (ObjectUtils.isEmpty(type)) {
            throw new IllegalArgumentException("unknown identifier type: " + type);
        }
        return Arrays.stream(RouteTypeEnum.values())
                .filter(x -> type.equals(x.getType()))
                .findAny()
                .orElseThrow(IllegalArgumentException::new);
    }
}
