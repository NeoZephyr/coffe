package com.convertlab.macore.noncopy.datagdm;

import com.convertlab.foundation.library.utils.JsonUtils;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.IOException;
import java.util.*;

/**
 * @author Mr.黄
 * @description 回流事件操作bean
 * @since 2023/12/20 16:05
 **/
@Setter
@Getter
@ToString
public class BackFlowEventQuery {

    public final static String PROFILE_RELATIONSHIP_FIELD = "_profile_id";

    @Setter
    @Getter
    @ToString
    public static class CreateEventTableBody {
        private List<Map<String, String>> allOf;
        private Definition definitions;
        @JsonProperty(value = "meta:belongTo")
        private Map<String, String> metaBelongTo;
        @JsonProperty(value = "meta:dataZone")
        private String metaDataZone;
        @JsonProperty(value = "meta:extends")
        private String metaExtends;
        @JsonProperty(value = "meta:extendsChain")
        private List<String> metaExtendsChain;
        @JsonProperty(value = "meta:extendsType")
        private String metaExtendsType;
        @JsonProperty(value = "meta:resourceId")
        private String metaResourceId;
        @JsonProperty(value = "meta:resourceType")
        private String metaResourceType;
        @JsonProperty(value = "meta:storageInfo")
        private Map<String, Object> metaStorageInfo;
        private String title;
        private String type;

        public CreateEventTableBody() throws IOException {
            // 初始化一些字段默认值
            Map<String, String> allOfMap1 = new HashMap<>();
            Map<String, String> allOfMap2 = new HashMap<>();
            allOfMap1.put("$ref", "#/definitions/Event");
            allOfMap2.put("$ref", "#/definitions/_self");
            allOf = new ArrayList<>(Arrays.asList(allOfMap1, allOfMap2));
            definitions = new Definition();
            metaDataZone = "DW";
            metaExtends = "https://data.convertlab.com/gdm/_global/Pattern/Event";
            metaExtendsChain = new ArrayList<>(Arrays.asList("https://data.convertlab.com/gdm/_global/Pattern/Event", "https://data.convertlab.com/gdm/_global/Pattern/TimeSeries"));
            metaExtendsType = "Pattern";
            metaResourceType = "TableStructure";
            type = "object";
        }

        @Setter
        @Getter
        @ToString
        public static class Definition {
            @JsonProperty(value = "Event")
            private Event event;
            @JsonProperty(value = "_self")
            private Map<String, Map<String, Object>> self;

            @Setter
            @Getter
            @ToString
            public static class Event {
                public final static List<String> PRIMARY_KEYS = Arrays.asList("_profile_id", "_event_type", "_date_happened", "_external_id");
                private String description;
                @JsonProperty(value = "meta:extends")
                private String metaExtends;
                @JsonProperty(value = "meta:extendsChain")
                private List<String> metaExtendsChain;
                @JsonProperty(value = "meta:extendsType")
                private String metaExtendsType;
                @JsonProperty(value = "meta:partitionColumns")
                private Object metaPartitionColumns;
                @JsonProperty(value = "meta:primaryKeys")
                private List<String> metaPrimaryKeys;
                @JsonProperty(value = "meta:public")
                private Boolean metaPublic;
                @JsonProperty(value = "meta:resourceId")
                private String metaResourceId;
                @JsonProperty(value = "meta:resourceType")
                private String metaResourceType;
                @JsonProperty(value = "meta:root")
                private Boolean metaRoot;
                @JsonProperty(value = "meta:visible")
                private Boolean metaVisible;
                private Map<String, Map<String, Object>> properties;
                private String title;
                private String type;

                public Event() throws IOException {
                    // 初始化一些字段
                    metaExtends = "https://data.convertlab.com/gdm/_global/Pattern/TimeSeries";
                    metaExtendsChain = new ArrayList<>(Collections.singletonList("https://data.convertlab.com/gdm/_global/Pattern/TimeSeries"));
                    metaExtendsType = "Pattern";
                    // todo 不知道是不是只有这几个
                    metaPrimaryKeys = PRIMARY_KEYS;
                    metaPublic = true;
                    metaResourceId = "Event";
                    metaResourceType = "Pattern";
                    metaRoot = false;
                    metaVisible = true;
                    // 事件pattern的默认字段初始化
                    properties = JsonUtils.dtoMapper().readValue(Event.class.getResourceAsStream("/meta/event/eventTableSystemFields.json"), new TypeReference<Map<String, Map<String, Object>>>() {
                    });
                    title = "行为事件";
                    type = "object";
                }
            }

            public Definition() throws IOException {
                event = new Event();
                Map<String, Map<String, Object>> selfMap = new HashMap<>();
                selfMap.put("properties", new HashMap<>());
                self = selfMap;
            }
        }
    }

    @Setter
    @Getter
    @ToString
    public static class CreateEventBody {
        private String eventTypeId;
        private String eventTypeName;
        private EventProperties eventProperties;

        @Setter
        @Getter
        @ToString
        public static class EventProperties {
            private Object metaLookup;
            private String name;
            private String title;
        }
    }
}
