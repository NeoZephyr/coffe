package com.convertlab.macore.noncopy.meta;

import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.macore.noncopy.datacommon.Relationship;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Mr.黄
 * @description datahub的事件模型；包含事件表ID、事件表名、事件表信息、事件信息、事件数据映射
 * @since 2023/12/07 18:08
 **/
@Setter
@Getter
@ToString
public class EventModel {
    @JsonProperty(value = "tableId")
    private String eventTableId;
    @JsonProperty(value = "title")
    private String eventTableName;

    private EventTableInfo eventTableInfo;
    private List<EventInfo> eventInfoList;
    /**
     * eventId -> eventName
     */
    private Map<String, String> eventDataMap;

    @Setter
    @Getter
    @ToString
    public static class EventTableInfo {
        private String managedIdentity;
        @JsonProperty(value = "title")
        private String eventTableName;
        private String icon;
        @JsonProperty(value = "tableId")
        private String eventTableId;
        private String pattern;
        private Integer recordNum;
        private String patternTitle;
        private List<EventTableProperties> properties;
        @JsonAnyGetter
        @JsonAnySetter
        @JsonIgnore
        private Map<String, Object> extraField = new HashMap<>();

        @Setter
        @Getter
        @ToString
        public static class EventTableProperties {
            private String field;
            private String gdmType;
            private String title;
            private Relationship relationship;
        }

    }

    /**
     * data gdm EventType
     *
     * @author Mr.黄
     * @since 2023/12/8
     */
    @Setter
    @Getter
    @ToString
    public static class EventInfo {
        private Integer projectId;
        @JsonProperty(value = "tableId")
        private String eventTableId;
        private String eventTypeId;
        private String eventTypeName;
        private String eventTypeDescription;
        private Boolean interactive = false;
        private String lookupTables;
        private Long ownerId;
        private Long creatorId;
        private String creatorName;
        private String referrer;
        private Date dateCreated;
        private Date lastUpdated;
        private Map<String, EventPropertiesInfo> eventProperties;
        @JsonAnyGetter
        @JsonAnySetter
        @JsonIgnore
        private Map<String, Object> extraField = new HashMap<>();

        @Setter
        @Getter
        @ToString
        public static class EventPropertiesInfo {
            private String name;
            private String title;
        }
    }
}
