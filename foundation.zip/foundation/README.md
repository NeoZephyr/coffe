# 参考链接
- application/README.md: application项目如何使用
- 其他的都还没有

## Foundation Library 使用帮助
* [gdm-meta-client](library/meta/gdm-meta-boot-starter/README.md)
* [webmvc](library/webmvc/README.md)
* [openfeign](library/openfeign/README.md)
* [redis](library/redis/README.md)
* [configurable-cache](library/redis/LOCALCACHE.md)* 
* [mongodb](library/mongodb/README.md)
* [mybatis-plus](library/mybatis-plus/README.md)
* [kafka](library/kafka/README.md)
* [jdbc](library/jdbc/README.md)
* [uid-generator](library/uid-generator/README.md)
* [business-commons](library/business-commons/README.md)
* [meta-health-check](library/meta/meta-health-check/README.md)*
* [foundation-daemon](library/foundation-daemon/README.md)*

# 特殊配置
记录特别配置项的功能和默认配置，及在开发和生产中的推荐做法
#### CONVERTLAB_WEBMVC_REQUEST_LOGGING_INCLUDE_CLIENT_INFO
##### 值
    true|false(默认值)
##### 作用
    在com.convertlab.foundation.library.webmvc.interceptor.RequestLoggingHandlerInterceptor的DEBUG日志中打印POST的PAYLOAD
##### 推荐
    在开发环境中的k8s configmap中配置成true



# 如何启动"第一推动力 First Push"
## CI环境中
设置正确的`Dcomponent_version`变量
```shell
./gradlew publish
```
## 开发者机器上如何使用
```shell
PUSH_TO_MAVEN=1 ./gradlew publish -Dcomponent_version=C-3.1-campaignv4.0000
```