#!/usr/bin/env bash
service=$(basename $(git remote get-url origin) .git)
echo Service: $service

func() {
    echo "Usage:"
    echo "$0 [-a] [-d] [-g]"
    echo "-a build all"
#    echo "-n build npm only"
    echo "-d build docker image only"
    echo "-g build gradle and docker image"
#    echo "-nd build npm and docker image"
    exit -1
}


cleanNpm(){
  echo Build bash for deverloper local env ONLY!!!
  echo === Clean UI app from src/main/resources ===
  rm -rf src/main/resources/public
}

runNpm(){
  cleanNpm
  echo === Run npm build ===
  npm --prefix ui install
  npm --prefix ui run build
  echo === Copy npm build to src/main/resources ===
  cp -r ui/build src/main/resources/public
}

dockerBuild(){
  echo === Docker build image: $service:local ===
  docker build . -t $service:local
}

runGradleAndDockerBuilder(){
  echo === Gradle package ===
  ../gradlew bootRepackage
  dockerBuild
}

runNpmAndDockerBuilder(){
  runNpm
  runGradleAndDockerBuilder
}

runAll(){
#  runNpm
  runGradleAndDockerBuilder
}

upload="false"

while getopts 'n d a nd g h' OPT; do
    case $OPT in
        g) runGradleAndDockerBuilder;;
        d) dockerBuild;;
#        n) runNpm;;
#        nd) runNpmAndDockerBuilder;;
        a) runAll;;
        h) func;;
        ?) func;;
    esac
done

if (( $OPTIND == 1 )); then
   runAll
fi