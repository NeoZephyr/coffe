package com.convertlab.foundation.gdmmeta.service.impl;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.convertlab.foundation.gdmmeta.model.Entity;
import com.convertlab.foundation.gdmmeta.mybatis.service.impl.CustomerMetaServiceImpl;
import com.convertlab.foundation.gdmmeta.service.LayerServiceCheck;
import com.convertlab.foundation.gdmmeta.service.impl.loader.TenantCustomerEventEntityLoader;
import com.convertlab.foundation.library.multitenancy.context.TenantContextMutable;

class TenantCustomerEventEntityLoaderTest implements TenantContextMutable, LayerServiceCheck {

    TenantCustomerEventEntityLoader service;

    @BeforeEach
    void setUp() {
        ConfigMetaProviderImpl configMetaProvider = new ConfigMetaProviderImpl();
        CustomerMetaServiceImpl customerMetaService = getLocalCustomerMetaService(configMetaProvider);
        service = new TenantCustomerEventEntityLoader(configMetaProvider, customerMetaService);
    }



    @Test
    void getEntityNames() {
        assertTrue(service.getEntityNames().size() > 0);
        assertTrue(service.getEntityNames().contains("c_evil_noprop"));
    }

    @Test
    void loadEntity() {
        Entity entity = service.loadEntity("c_evil_noprop");
        assertNotNull(entity);

        assertEquals("c_evil_noprop", entity.getEntityName());
        assertEquals("customer_event", entity.getDbTableName());
        assertEquals(false, entity.getDbView());
        assertNotNull(entity.getInheritance());
        assertTrue( entity.getInheritance().getIsSubtype());
        assertEquals("event", entity.getInheritance().getIdentifierField());
        assertEquals("c_evil_noprop", entity.getInheritance().getIdentifierValue());
        assertTrue(entity.getFields().size() == 0 );
//        assertTrue(entity.getFields().stream().filter(field -> field.getFieldName().equals("event_group")).findAny().isPresent());
    }

    @Test
    void getEntities() {
        Map<String, Entity> entities = service.getEntities();
        assertTrue(entities.size() > 0);
    }
}
