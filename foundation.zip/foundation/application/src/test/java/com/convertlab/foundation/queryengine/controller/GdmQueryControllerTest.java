package com.convertlab.foundation.queryengine.controller;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.convertlab.foundation.api.queryengine.GdmQuery;
import com.convertlab.foundation.library.gdmmeta.client.GdmMetaHelper;
import com.convertlab.foundation.library.jdbc.core.BaseJdbcTemplate;
import com.convertlab.foundation.library.webmvc.autoconfigure.ConvertlabHttpMessageConverterConfiguration;
import com.convertlab.foundation.queryengine.configure.AutoConfig;
import com.convertlab.foundation.queryengine.service.GdmQueryService;
import com.convertlab.foundation.queryengine.service.GdqlParseService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * @author xiaowei & chatgpt
 * 最小化测试启动范围： {@link WebMvcTest} 会启动整个spring容器，但是只会启动controller相关的bean，其他bean都会被mock掉。
 */
@WebMvcTest(value = GdmQueryController.class,
        properties = {
                "convertlab.webmvc.response-body.type-converters.long-to-string=true"
        },
        includeFilters = @ComponentScan.Filter(
                type = FilterType.ASSIGNABLE_TYPE, classes = {AutoConfig.class}
        )
)
@ImportAutoConfiguration(classes = {ConvertlabHttpMessageConverterConfiguration.class})
@ContextConfiguration(classes = {GdmQueryController.class})
class GdmQueryControllerTest {

    @Autowired
    private MockMvc mockMvc;

    /**
     * 构造Mock Beans，分为两大部分：
     * - A类mock，Test case需要的service，即：测试过程中影响测试结果的service
     * - B类mock，Test case不需要的service，即：测试过程中不影响测试结果的service，mock它们的目的是为了能够正常启动spring，同时避免启动整个spring容器。
     * <p>
     * 下面是A类mock：
     */
    @MockBean
    private GdmQueryService queryService;

    /**
     * 下面是B类mock：
     */
    @MockBean
    private GdmMetaHelper gdmMetaHelper;
    @MockBean
    private GdqlParseService gdqlParseService;
    @MockBean(name = "OlapJdbcTemplate")
    private BaseJdbcTemplate olapJdbcTemplate;

    @Test
    @DisplayName("JSON中Long型以String形式序列化，兼容浏览器JS")
    void testSerializationOfBigInt() throws Exception {
        GdmQuery.Request mockRequest = new GdmQuery.Request();
        mockRequest.setGdql("select * from table1");

        GdmQuery.Response mockResponse = new GdmQuery.Response();
        Map<String, Object> mockMap = new HashMap<String, Object>() {{
            put("Long", 1466098449865779211L);
        }};
        List<Map<String, Object>> mockResult = Collections.singletonList(mockMap);
        mockResponse.setRows(mockResult);
        when(queryService.query(mockRequest)).thenReturn(mockResponse);

        mockMvc
                .perform(
                        MockMvcRequestBuilders.post("/v1/query-engine/q")
                                .content("{\"gdql\":\"select * from table1\"}")
                                .contentType(MediaType.APPLICATION_JSON)
                                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().is2xxSuccessful())
                .andExpect(jsonPath("$.rows[0].Long").value("1466098449865779211"))
                .andExpect(jsonPath("$.rows[0].Long").isString());
    }
}