package com.convertlab.foundation.gdmpattern.service;

import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.gdm.migration.protocol.v1.SchemaChangeLogV1;
import com.convertlab.gdm.migration.utils.XmlUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.List;

import static com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto.UdoDomains.ATTRIBUTED_SEGMENT_FAMILY_PARTITION_BY_FIELDS;

@Slf4j
class TableProvisionServiceTest {
    private final TableProvisionService service = new TableProvisionService(null,null);

    @Test
    @DisplayName("测试生成的对象可以序列化成json，以保证通过FeignClient发送的时候可以正常解析")
    void testBuildCreateEntityChangeSet() throws Exception {
        // Use reflection to access the private method
        Method method = TableProvisionService.class.getDeclaredMethod("buildCreateEntityChangeSet", GdmEntity.class, List.class);
        method.setAccessible(true); // Make the method accessible

        List<GdmModelDto.Field> segmentFamilyFields = JsonUtils.instanceOfDto().json2List(IOUtils.resourceToString("/GdmModelService/tableProvision.json", StandardCharsets.UTF_8), GdmModelDto.Field.class);
        GdmEntity attributedSegmentFamilyEntity = service.buildGdmEntity("c_as1", segmentFamilyFields);

        // Invoke the method
        SchemaChangeLogV1.ChangeSet changeSet = (SchemaChangeLogV1.ChangeSet) method.invoke(service, attributedSegmentFamilyEntity, ATTRIBUTED_SEGMENT_FAMILY_PARTITION_BY_FIELDS);

        String json = JsonUtils.instanceOfDto().obj2Json(changeSet);
        log.info("json:\n{}", json);

        String xml = XmlUtils.obj2Xml(changeSet);
        log.info("xml:\n{}",xml);
    }
}