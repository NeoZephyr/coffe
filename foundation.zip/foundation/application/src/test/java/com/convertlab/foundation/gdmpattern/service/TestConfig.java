package com.convertlab.foundation.gdmpattern.service;

import com.convertlab.foundation.gdmmeta.configure.CustomeMongodConfiguration;
import com.convertlab.foundation.gdmmeta.service.impl.MetaEventPublisher;
import com.convertlab.foundation.gdmpattern.configure.GdmConfiguration;
import com.convertlab.foundation.library.business.autoconfigure.ConvertlabCommonComponentAutoConfiguration;
import com.convertlab.foundation.library.datapermission.service.ResourceMetaService;
import com.convertlab.foundation.library.datapermission.service.ResourceSettingService;
import com.convertlab.foundation.library.mongodb.autoconfigure.ConvertlabMongoAutoConfiguration;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.boot.autoconfigure.validation.ValidationAutoConfiguration;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Import;

/**
 * 测试的主体配置类
 */
@TestConfiguration
@Import({
        // 需要单独引入进来的配置类@Configuration，或者是单独的@Service
        MetaEventPublisher.class,
        ResourceSettingService.class,
        ResourceMetaService.class,
        MongoAutoConfiguration.class,
        MongoDataAutoConfiguration.class,
        ConvertlabCommonComponentAutoConfiguration.class,
        ConvertlabMongoAutoConfiguration.class,
        GdmConfiguration.class,
        GdmMetaLocalClientConfigurationForTest.class,
        ValidationAutoConfiguration.class,
        CustomeMongodConfiguration.class,
})

@ComponentScan(basePackages = {
        // Bean的主体 basePackage， 不要引入@Controller，没有必要。
        "com.convertlab.foundation.gdmmeta.client",
        "com.convertlab.foundation.gdmmeta.configure",
        "com.convertlab.foundation.gdmmeta.dao",
        "com.convertlab.foundation.gdmmeta.init",
        "com.convertlab.foundation.gdmmeta.model",
        "com.convertlab.foundation.gdmmeta.persistance",
        "com.convertlab.foundation.gdmmeta.repository",
        "com.convertlab.foundation.gdmmeta.service",
        "de.flapdoodle.embed.mongo",

        },
        excludeFilters = {
        // 排除掉那些和测试无关的，特别是访问数据库，Redis, Kafka.. 的Bean
                @ComponentScan.Filter(type = FilterType.REGEX, pattern = ".*Db.*Impl"),
                @ComponentScan.Filter(type = FilterType.REGEX, pattern = ".*MergeService.*"),
                @ComponentScan.Filter(type = FilterType.REGEX, pattern = "com.convertlab.foundation.gdmmeta.service.impl.*Loader"),
                @ComponentScan.Filter(type = FilterType.REGEX, pattern = ".*LoaderImpl"),
                @ComponentScan.Filter(type = FilterType.REGEX, pattern = ".*Validator"),
                @ComponentScan.Filter(type = FilterType.REGEX, pattern = ".*DataSourceConfigure"),
        }
)
public class TestConfig {
}
