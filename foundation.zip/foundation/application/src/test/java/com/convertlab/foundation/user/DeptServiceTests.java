package com.convertlab.foundation.user;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.convertlab.data.job.core.util.data.BizJobClient;
import com.convertlab.data.job.core.util.data.JobData;
import com.convertlab.foundation.datapermission.service.RuleService;
import com.convertlab.foundation.library.business.audit.AuditEvent;
import com.convertlab.foundation.library.business.audit.KafkaAuditTemplate;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.user.entity.Dept;
import com.convertlab.foundation.user.entity.UserDept;
import com.convertlab.foundation.user.mapper.DeptMapper;
import com.convertlab.foundation.user.mapper.UserDeptMapper;
import com.convertlab.foundation.user.model.DeptDTO;
import com.convertlab.foundation.user.service.DeptService;
import com.convertlab.foundation.user.service.UserDeptService;
import com.convertlab.foundation.user.utils.BuiltInDept;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class DeptServiceTests {

    @Mock
    private DeptMapper deptMapper;

    @InjectMocks
    private DeptService deptService;

    @Mock
    private UserDeptMapper userDeptMapper;

    @Mock
    private KafkaAuditTemplate kafkaAuditTemplate;

    @Mock
    private BizJobClient bizJobClient;

    @Captor
    private ArgumentCaptor<JobData> jobDataCaptor;

    @Captor
    private ArgumentCaptor<QueryWrapper<Dept>> queryWrapperCaptor;


    @Test
    //组织树只有一个根节点 "A0001"
    public void testGenerateSecondaryLevelDeptCode() {
        Dept parentDept = new Dept();
        parentDept.setPath("A00001");

        when(deptMapper.getDeptByCode(any())).thenReturn(null);

        String deptCode = deptService.generateDeptCode(parentDept);

        assertNotNull(deptCode);
        assertFalse(deptCode.isEmpty());
        assertFalse(deptCode.equals(BuiltInDept.RESERVED_DEPT_CODE));
        assertTrue(deptCode.startsWith("B") && deptCode.length()==6);
    }

    @Test
    //组织树的父节点为 "A0001-B00001"
    public void testGenerateThridLevelDeptCode() {
        Dept parentDept = new Dept();
        parentDept.setPath("A0001-B00001");

        when(deptMapper.getDeptByCode(any())).thenReturn(null);

        String deptCode = deptService.generateDeptCode(parentDept);
        assertNotNull(deptCode);
        assertFalse(deptCode.isEmpty());
        assertFalse(deptCode.equals(BuiltInDept.RESERVED_DEPT_CODE));
        assertTrue(deptCode.startsWith("C") && deptCode.length()==6);
    }

    @Test
    public void testGenerateDeptCodeWithExistingCode() {
        Dept parentDept = new Dept();
        parentDept.setPath("A00001");

        Dept existingDept = new Dept();
        when(deptMapper.getDeptByCode(any())).thenReturn(existingDept).thenReturn(null);

        String deptCode = deptService.generateDeptCode(parentDept);
        assertNotNull(deptCode);
        assertFalse(deptCode.isEmpty());
        assertFalse(deptCode.equals(BuiltInDept.RESERVED_DEPT_CODE));
        assertFalse(deptCode.equals(existingDept.getCode()));
    }

    @Test
    public void testGenerateDeptCodeFailed() {
        Dept parentDept = new Dept();
        parentDept.setPath("1-2-3");

        when(deptMapper.getDeptByCode(any())).thenReturn(new Dept());

        assertThrows(RuntimeException.class, () -> {
            deptService.generateDeptCode(parentDept);
        });
    }


    @Test
    void testSaveDept() {
        // Create test data
        DeptDTO dto = new DeptDTO();
        dto.setName("Test Department");
        dto.setParentOutCode("PARENT_OUT_CODE");
        dto.setOutCode("TEST_OUT_CODE");
        dto.setSequence(1);

        Dept parentDept = new Dept();
        parentDept.setCode("PARENT_CODE");
        parentDept.setOutCode("PARENT_OUT_CODE");
        parentDept.setPath("PARENT_PATH");

        // Mock behavior
        when(deptMapper.getDeptByOutCode(any())).thenReturn(parentDept);
        when(deptMapper.getDeptByCode(any())).thenReturn(null);
        when(deptMapper.insert(any(Dept.class))).then(invocation -> {
            Dept dept = invocation.getArgument(0);
            dept.setId(1);
            return 1;
        });
        doNothing().when(kafkaAuditTemplate).log(any(AuditEvent.class));

        // Call the method
        Dept result = deptService.saveDept(dto);

        // Verify behavior
        verify(deptMapper, times(1)).insert(any(Dept.class));

        // Assert result
        assertNotNull(result);
        assertEquals("Test Department", result.getName());
        assertNotNull(result.getCode());
        assertEquals("PARENT_CODE", result.getParent());
        assertNotNull( result.getPath());
        assertEquals("TEST_OUT_CODE", result.getOutCode());
        assertEquals(1, result.getSequence());
    }


    @Test
    void testUpdateDept() {
        String code = "TEST_CODE";
        DeptDTO dto = new DeptDTO();
        dto.setName("Updated Dept Name");
        dto.setParentOutCode("PARENT_OUT_CODE");
        dto.setOutCode("UPDATED_OUT_CODE");
        dto.setSequence(2);
        dto.setEnabled(true);

        Dept existingDept = new Dept();
        existingDept.setCode(code);
        existingDept.setName("Old Dept Name");

        Dept parentDept = new Dept();
        parentDept.setCode("PARENT_CODE");

        when(deptMapper.getDeptByCode(any())).thenReturn(existingDept);
        when(deptMapper.getDeptByOutCode(any())).thenReturn(null).thenReturn(parentDept);

        Dept updatedDept = deptService.updateDept(code, dto);

        assertEquals(dto.getName(), updatedDept.getName());
        assertEquals(parentDept.getCode(), updatedDept.getParent());
        assertEquals(dto.getOutCode(), updatedDept.getOutCode());
        assertEquals(dto.getSequence(), updatedDept.getSequence());
        assertEquals(dto.getEnabled(), updatedDept.getEnabled());
    }

    @Test
    void testDeleteDept() {
        // Prepare test data
        String deptCode = "A0001";
        Dept dept = new Dept();
        dept.setId(1);
        dept.setCode(deptCode);
        dept.setName("Test Department");

        List<Dept> childDepts = new ArrayList<>();
        List<UserDept> userDepts = new ArrayList<>();

        // Configure mocks
        when(deptMapper.getDeptByCode(deptCode)).thenReturn(dept);
        when(deptMapper.listDepts(deptCode, null)).thenReturn(childDepts);
        when(userDeptMapper.listUserDepts(deptCode)).thenReturn(userDepts);
        doNothing().when(kafkaAuditTemplate).log(any(AuditEvent.class));
        when(bizJobClient.createAndStartBizJob(any(JobData.class))).thenReturn(null);

        // Test the method
        Dept deletedDept = deptService.deleteDept(deptCode);

        // Assert results
        assertNotNull(deletedDept);
        assertEquals(deptCode, deletedDept.getCode());

        verify(bizJobClient, times(2)).createAndStartBizJob(jobDataCaptor.capture());
        List<JobData> jobDataList = jobDataCaptor.getAllValues();
        assertEquals(RuleService.SPARK_JOB_DATA_PERMISSION, jobDataList.get(0).getJobType());
        assertEquals("dp_delete_dept", jobDataList.get(0).getJobHandler());
        assertEquals(RuleService.SPARK_JOB_DATA_PERMISSION, jobDataList.get(1).getJobType());
        assertEquals("dp_delete_dept", jobDataList.get(1).getJobHandler());
    }

    @Test
    public void testDeleteDept_deptNotFound() {
        String code = "D001";

        when(deptMapper.getDeptByCode(code)).thenReturn(null);

        assertThrows(BusinessException.class, () -> deptService.deleteDept(code));

    }

    @Test
    void testDeleteDept_WithChildDepts() {
        // Prepare test data
        String deptCode = "A0001";
        Dept dept = new Dept();
        dept.setId(1);
        dept.setCode(deptCode);
        dept.setName("Test Department");

        List<Dept> childDepts = new ArrayList<>();
        childDepts.add(new Dept());

        // Configure mocks
        when(deptMapper.getDeptByCode(deptCode)).thenReturn(dept);
        when(deptMapper.listDepts(deptCode, null)).thenReturn(childDepts);

        // Test the method and assert exception
        assertThrows(BusinessException.class, () -> deptService.deleteDept(deptCode));
    }

    @Test
    void testDeleteDept_WithUsers() {
        // Prepare test data
        String deptCode = "A0001";
        Dept dept = new Dept();
        dept.setId(1);
        dept.setCode(deptCode);
        dept.setName("Test Department");

        List<Dept> childDepts = new ArrayList<>();
        List<UserDept> userDepts = new ArrayList<>();
        userDepts.add(new UserDept());

        // Configure mocks
        when(deptMapper.getDeptByCode(deptCode)).thenReturn(dept);
        when(deptMapper.listDepts(deptCode, null)).thenReturn(childDepts);
        when(userDeptMapper.listUserDepts(deptCode)).thenReturn(userDepts);

        // Test the method and assert exception
        assertThrows(BusinessException.class, () -> deptService.deleteDept(deptCode));
    }

    @Test
    void testDeleteDept_TopDept() {
        // Prepare test data
        String deptCode = BuiltInDept.TOP_DEPT_CODE;
        Dept dept = new Dept();
        dept.setId(1);
        dept.setCode(deptCode);
        dept.setName("Test Department");

        List<Dept> childDepts = new ArrayList<>();
        List<UserDept> userDepts = new ArrayList<>();

        // Configure mocks
        when(deptMapper.getDeptByCode(deptCode)).thenReturn(dept);
        when(deptMapper.listDepts(deptCode, null)).thenReturn(childDepts);

        // Test the method and assert exception
        assertThrows(BusinessException.class, () -> deptService.deleteDept(deptCode));
    }

    @Test
    public void testCheck() {
        // Prepare test data
        DeptDTO validDto = new DeptDTO();
        validDto.setName("Department");
        validDto.setOutCode("outcode123");
        validDto.setParentOutCode("parentOutcode123");

        DeptDTO invalidDto = new DeptDTO();
        invalidDto.setName("Department");
        invalidDto.setOutCode("outcode123");

        Dept parentDept = new Dept();
        parentDept.setPath("1-2-3-4-5-6-7-8-9");

        // Configure mocks
        when(deptMapper.getDeptByOutCode(validDto.getOutCode())).thenReturn(null);
        when(deptMapper.getDeptByOutCode(validDto.getParentOutCode())).thenReturn(parentDept);

        // Test the method
        assertDoesNotThrow(() -> deptService.check(validDto));
        assertThrows(BusinessException.class, () -> deptService.check(invalidDto));
    }

    @Test
    public void testCheck_blankName() {
        DeptDTO invalidDto = new DeptDTO();
        invalidDto.setName("");
        invalidDto.setOutCode("outcode123");
        invalidDto.setParentOutCode("parentOutcode123");

        assertThrows(BusinessException.class, () -> deptService.check(invalidDto));
    }

    @Test
    public void testCheck_blankOutCode() {
        DeptDTO invalidDto = new DeptDTO();
        invalidDto.setName("Department");
        invalidDto.setOutCode("");
        invalidDto.setParentOutCode("parentOutcode123");

        assertThrows(BusinessException.class, () -> deptService.check(invalidDto));
    }

    @Test
    public void testCheck_blankParentOutCode() {
        DeptDTO invalidDto = new DeptDTO();
        invalidDto.setName("Department");
        invalidDto.setOutCode("outcode123");
        invalidDto.setParentOutCode("");

        assertThrows(BusinessException.class, () -> deptService.check(invalidDto));
    }

    @Test
    public void testCheck_invalidOutCodeFormat() {
        DeptDTO invalidDto = new DeptDTO();
        invalidDto.setName("Department");
        invalidDto.setOutCode("out_code!@#");
        invalidDto.setParentOutCode("parentOutcode123");

        assertThrows(BusinessException.class, () -> deptService.check(invalidDto));
    }

    @Test
    public void testCheck_parentDeptNotFound() {
        DeptDTO invalidDto = new DeptDTO();
        invalidDto.setName("Department");
        invalidDto.setOutCode("outcode123");
        invalidDto.setParentOutCode("parentOutcode123");

        when(deptMapper.getDeptByOutCode(invalidDto.getOutCode())).thenReturn(null);
        when(deptMapper.getDeptByOutCode(invalidDto.getParentOutCode())).thenReturn(null);

        assertThrows(BusinessException.class, () -> deptService.check(invalidDto));
    }

    @Test
    public void testCheck_deptLevelExceeded() {
        DeptDTO invalidDto = new DeptDTO();
        invalidDto.setName("Department");
        invalidDto.setOutCode("outcode123");
        invalidDto.setParentOutCode("parentOutcode123");

        Dept parentDept = new Dept();
        parentDept.setPath("1-2-3-4-5-6-7-8-9-10");

        when(deptMapper.getDeptByOutCode(invalidDto.getOutCode())).thenReturn(null);
        when(deptMapper.getDeptByOutCode(invalidDto.getParentOutCode())).thenReturn(parentDept);

        assertThrows(BusinessException.class, () -> deptService.check(invalidDto));
    }

}
