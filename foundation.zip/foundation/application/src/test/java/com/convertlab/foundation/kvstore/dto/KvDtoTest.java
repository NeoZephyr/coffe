package com.convertlab.foundation.kvstore.dto;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.TreeMap;

@Slf4j
@Tag("UnitTest")
public class KvDtoTest {

    @Test
    void kvPairToStringTest(){
        KvPair kvPair = new KvPair();
        kvPair.put("1506469153928783872", "1");
        kvPair.put("1506468802957811712", 1);
        kvPair.put("1506469153928783873", null);
        String serialized = kvPair.toString();
        Assertions.assertEquals("{\"1506469153928783872\":\"1\", \"1506468802957811712\":1}", serialized);
    }

    @Test
    void keyValuesPairToStringTest(){
        KeyValuesPair kvPair = new KeyValuesPair("1506469036479883264", new TreeMap(){{
            put("1506469153928783872", "1");
            put("1506468802957811712", 1);
            put("1506469153928783873", null);
        }});
        String serialized = kvPair.toString();
        Assertions.assertEquals("{\"id\": \"1506469036479883264\", \"kvMapping\": [{\"1506469153928783872\":\"1\"}, {\"1506468802957811712\":1}]}", serialized);
    }

    @Test
    void kvQueryToStringTest() {
        KvQuery kvQuery = new KvQuery();
        kvQuery.setKeys(Arrays.asList("1506469036479883264", "1506469036479883265"));
        kvQuery.setColumns(Arrays.asList("1506469153928783872", "1506468802957811712"));
        Assertions.assertEquals("{\"keys\": [\"1506469036479883264\",\"1506469036479883265\"], \"columns\": [\"1506469153928783872\",\"1506468802957811712\"]}", kvQuery.toString());
    }
}
