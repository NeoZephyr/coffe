package com.convertlab.foundation.gdmmeta.service.impl;

import static org.junit.jupiter.api.Assertions.*;

import com.convertlab.foundation.gdmmeta.service.LayerServiceCheck;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@Tag("UnitTest")
@Tag("GdmMeta")
class DbMetaProviderImplTest implements LayerServiceCheck {
    private DbMetaProviderImpl service;
    @BeforeEach
    public void setUp() {
        service = getDefaultMockDbMetaService();
    }
    @Test
    void test_impala_jdbc_getDbMetaInfo() {
        final String dbName = "cdp_unittest";
        String impalaJdbc = String.format("jdbc:impala://host:21050/%s;SocketTimeout=300;LowerCaseResultSetColumnName=0;Timezone=UTC", dbName);
        DbMetaProviderImpl.DatasourceInfo impala = service.getDbMetaInfo("impala", DbMetaProviderImpl.DatasourceInfo.ConnType.IMPALA, impalaJdbc);
        assertEquals(dbName, impala.databaseName);
    }

    @Test
    void test_mysql_jdbc_getDbMetaInfo() {
        final String dbName = "db_unittest";
        String impalaJdbc = String.format("jdbc:mysql://127.0.0.1:3306/%s?useUnicode=yes&characterEncoding=UTF-8&useLegacyDatetimeCode=false&serverTimezone=UTC&zeroDateTimeBehavior=convertToNull", dbName);
        DbMetaProviderImpl.DatasourceInfo impala = service.getDbMetaInfo("impala", DbMetaProviderImpl.DatasourceInfo.ConnType.IMPALA, impalaJdbc);
        assertEquals(dbName, impala.databaseName);
    }
}
