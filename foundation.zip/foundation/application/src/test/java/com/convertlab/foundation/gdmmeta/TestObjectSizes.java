package com.convertlab.foundation.gdmmeta;

import javax.annotation.Nonnull;

import com.convertlab.foundation.gdmmeta.service.LayerServiceCheck;
import com.convertlab.foundation.gdmmeta.service.impl.DbMetaProviderImpl;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;

import com.google.common.base.CaseFormat;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.openjdk.jol.info.GraphLayout;
import org.openjdk.jol.vm.VM;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * all unit test under com.convertlab.foundation.gdmmeta package
 * should be tagged with "GdmMeta" tag.
 * This is to make sure that all unit tests under this package can be run together.
 *
 */
@Tag("UnitTest")
@Tag("GdmMeta")
@Disabled("Permanently disable this bloody test, because of its fragility and sensitivity to JDK versions")
public class TestObjectSizes implements LayerServiceCheck {
    @Test()
    public void testBaseMetaSize(){
        DbMetaProviderImpl dbMetaService = getDefaultMockDbMetaService();
        List<GdmEntity> baseMeta = dbMetaService.getEntitiesFromBase();

        checkStringSize();

        String strLen10 = "1234567890";
        checkMapSize(strLen10);

        System.out.println("The shallow size of base meta is: " + VM.current().sizeOf(baseMeta));
        System.out.println("The GraphLayout size of base meta is: \n" + GraphLayout.parseInstance(baseMeta).toFootprint());
    }

    private static void checkMapSize(@Nonnull String str) {
        Map<String, String> m = new HashMap<>();
        m.put(str,str);
        System.out.println("The size of the string:" + str.length());
        System.out.println("The GraphLayout size of string is: \n" + GraphLayout.parseInstance(str).toFootprint());
        System.out.println("The GraphLayout size of map<string,string> is: \n" + GraphLayout.parseInstance(m).toFootprint());
    }

    private static void checkStringSize() {
        String s = "";
        for (int i=0;i<10;i++) {
            System.out.println("The size of the string:" + s.length());
            System.out.println("The GraphLayout size of string is: \n" + GraphLayout.parseInstance(s).toPrintable());
            s = s + ".";
        }
    }

    @Test
    void testNullString() {
        String s = null;
        annotationTest(s);
    }
    private void annotationTest ( String s) {
        System.out.println("The size of the string:" + s.length());
    }
}
