package com.convertlab.foundation.gdmmeta.model;

import java.util.Map;

import org.junit.jupiter.api.Tag;

import com.google.common.collect.Maps;

@Tag("UnitTest")
@Tag("GdmMeta")
public class CustomMergeStrategiesForTest {

    public static Map.Entry FIELD = Maps.immutableEntry(Field.class, new GdmObjectMerger.MergeStrategies<>(
                    (base,overlay) -> base.getId().equals(overlay.getId()), // Field被Entity以List<Field>形式引用，所以需要定义查找方法
                    Field::unsetIfNotNull,
                    GdmObjectMerger.RecursiveStrategy.EXPAND_COLLECTION_NO_RECURSIVE
            )
    );
    public static Map.Entry ENTITY = Maps.immutableEntry(
            Entity.class, new GdmObjectMerger.MergeStrategies<>(
                    (base,overlay) -> base.getId().equals(overlay.getId()),
                    Entity::unsetIfNotNull,
                    GdmObjectMerger.RecursiveStrategy.RECURSIVE
            )
    );
    public static Map.Entry INHERITANCE = Maps.immutableEntry(Inheritance.class, new GdmObjectMerger.MergeStrategies<>(
                    (base,overlay) -> true,
                    Inheritance::replaceOrAddIfNotNull,
                    GdmObjectMerger.RecursiveStrategy.RECURSIVE
            )
    );
    public static Map.Entry INHERITANCE_CUSTOMER = Maps.immutableEntry(Inheritance.class, new GdmObjectMerger.MergeStrategies<>(
                    (base,overlay) -> true,
                    Inheritance::unsetIfNotNull,
                    GdmObjectMerger.RecursiveStrategy.RECURSIVE
            )
    );
}
