package com.convertlab.foundation.gdmpattern.job;

import com.convertlab.data.job.core.util.data.BizJobClient;
import com.convertlab.foundation.api.gdm.pattern.facade.GdmMetaFacade;
import com.convertlab.foundation.library.exception.business.BackendException;
import com.convertlab.foundation.library.gdmmeta.client.GdmStorageMetaRtClient;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;


class GdmModelJobClientTest {

    @Mock
    private BizJobClient bizJobClient;
    @Mock
    private  GdmMetaFacade gdmMetaFacade;
    @Mock
    private  GdmStorageMetaRtClient gdmStorageMetaClient;

    @Test
    void testStartTaskToDropGdmEntityWithValidEntity() {
        GdmModelJobClient gdmModelJobClient = new GdmModelJobClient(bizJobClient, gdmMetaFacade, gdmStorageMetaClient);
        // 如果项目里引用了不合适的Guava库，这里就会Throw MethodNotFoundException；默认只会Throw BackendException.
        Assertions.assertThrows(BackendException.class, ()->{gdmModelJobClient.startTaskToDropGdmEntity("test");});
    }

}
