package com.convertlab.foundation.gdmpattern;

import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.api.gdm.pattern.facade.GdmMetaFacade;
import com.convertlab.foundation.gdmpattern.custom.CustomizableTableFactory;
import com.convertlab.foundation.gdmpattern.custom.ColumnProvisionStrategy;
import com.convertlab.foundation.gdmpattern.service.GdmProvisionService;
import com.convertlab.foundation.library.gdmmeta.model.FieldType;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.table.GdmTable;
import com.google.common.collect.Maps;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.util.Assert;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GdmProvisionTest {

    @Test
    public void testUdoProvisionStraightForward() {
        GdmProvisionService provisionService = getProvisionService("nudo1", "c_driver", PatternTestHelper.getUdoTable(), PatternTestHelper.getDriverEntity());
        List<GdmModelDto.Field> fields = PatternTestHelper.getFields1();
        PatternTestHelper.addSystemField(fields, "credential_1", FieldType.String, "t1");
        PatternTestHelper.addSystemField(fields, "credential_2", FieldType.String, "t2");
        Map<String, String> fieldMapping = provisionService.resolveNewFieldMapping("nudo1", "bk", Maps.newHashMap(), fields);
        Assert.notEmpty(fieldMapping, "fields not provisioned properly");
        Assert.isTrue(fieldMapping.get("pk").equals("bk"), "pk not provisioned properly");
        Assert.isTrue(fieldMapping.get("driver_id").equals("fk11"), "fk not provisioned properly");
        Assert.isTrue(fieldMapping.get("credential_1").equals("t1"), "credential_1 not provisioned properly");
        Assert.isTrue(fieldMapping.get("credential_2").equals("t2"), "credential_2 not provisioned properly");
        Assert.isTrue(fieldMapping.get("brand").equals("t3"), "brand not provisioned properly");
        Assert.isTrue(fieldMapping.get("production_date").equals("d1"), "production_date not provisioned properly");
        Assert.isTrue(fieldMapping.get("type").equals("n1"), "type not provisioned properly");

        fields = PatternTestHelper.getFields2();
        Map<String, String> reMapping = provisionService.resolveNewFieldMapping("nudo1", "bk", fieldMapping, fields);
        Assert.isTrue(reMapping.get("company").equals("t5"), "company not provisioned properly");
        Assert.isTrue(reMapping.get("sale_date").equals("d2"), "sale_date not provisioned properly");
        Assert.isTrue(reMapping.get("engine_type").equals("n2"), "engine_type not provisioned properly");
    }

    @Test
    public void testUdoProvisionLookBack() {
        GdmProvisionService provisionService = getProvisionService("nudo1", "c_driver", PatternTestHelper.getUdoTable(), PatternTestHelper.getDriverEntity());
        List<GdmModelDto.Field> fields = PatternTestHelper.getFields1();
        PatternTestHelper.addSystemField(fields, "credential_1", FieldType.String, "t1");
        PatternTestHelper.addSystemField(fields, "credential_2", FieldType.String, "t2");
        HashMap<String, String> existingFieldMapping = Maps.newHashMap();
        existingFieldMapping.put("str1", "t79");
        Map<String, String> fieldMapping = provisionService.resolveNewFieldMapping("nudo1", "bk", existingFieldMapping, fields);
        Assert.notEmpty(fieldMapping, "fields not provisioned properly");
        Assert.isTrue(fieldMapping.get("pk").equals("bk"), "pk not provisioned properly");
        Assert.isTrue(fieldMapping.get("driver_id").equals("fk11"), "fk not provisioned properly");
        Assert.isTrue(fieldMapping.get("credential_1").equals("t1"), "credential_1 not provisioned properly");
        Assert.isTrue(fieldMapping.get("credential_2").equals("t2"), "credential_2 not provisioned properly");
        Assert.isTrue(fieldMapping.get("brand").equals("t80"), "brand not provisioned properly");
        Assert.isTrue(fieldMapping.get("owner_name").equals("t3"), "brand not provisioned properly");
        Assert.isTrue(fieldMapping.get("production_date").equals("d1"), "production_date not provisioned properly");
        Assert.isTrue(fieldMapping.get("type").equals("n1"), "type not provisioned properly");

        fields = PatternTestHelper.getFields2();
        Map<String, String> reMapping = provisionService.resolveNewFieldMapping("nudo1", "bk", fieldMapping, fields);
        Assert.isTrue(reMapping.get("company").equals("t4"), "company not provisioned properly");
        Assert.isTrue(reMapping.get("sale_date").equals("d2"), "sale_date not provisioned properly");
        Assert.isTrue(reMapping.get("engine_type").equals("n2"), "engine_type not provisioned properly");
    }

    @Test
    public void testUdoEventProvision() {
        GdmProvisionService provisionService = getProvisionService("general_event", "c_driver", PatternTestHelper.getUdoEventTable(), PatternTestHelper.getDriverEntity());
        List<GdmModelDto.Field> fields = PatternTestHelper.getFields1();
        PatternTestHelper.addSystemField(fields, "flowId", FieldType.Long, null);
        Map<String, String> fieldMapping = provisionService.resolveNewFieldMapping("general_event", "bk", Maps.newHashMap(), fields);
        Assert.notEmpty(fieldMapping, "fields not provisioned properly");
        Assert.isTrue(fieldMapping.get("pk").equals("bk"), "pk not provisioned properly");
        Assert.isTrue(fieldMapping.get("driver_id").equals("attr2"), "driver_id not provisioned properly");
        Assert.isTrue(fieldMapping.get("brand").equals("attr1"), "brand not provisioned properly");
        Assert.isTrue(fieldMapping.get("owner_name").equals("attr3"), "brand not provisioned properly");
        Assert.isTrue(fieldMapping.get("type").equals("amount1"), "type not provisioned properly");
        Assert.isTrue(fieldMapping.get("production_date").equals("date1"), "production_date not provisioned properly");
        Assert.isTrue(fieldMapping.get("flowId").equals("flow_id"), "flowId not provisioned properly");

        fields = PatternTestHelper.getFields2();
        Map<String, String> reMapping = provisionService.resolveNewFieldMapping("general_event", "bk", fieldMapping, fields);
        Assert.isTrue(reMapping.get("company").equals("attr4"), "company not provisioned properly");
        Assert.isTrue(reMapping.get("sale_date").equals("date2"), "sale_date not provisioned properly");
        Assert.isTrue(reMapping.get("engine_type").equals("amount2"), "engine_type not provisioned properly");
    }

    private GdmProvisionService getProvisionService(String tableName, String entityName, GdmTable table, GdmEntity entity) {
        GdmMetaFacade gdmMetaFacade = Mockito.mock(GdmMetaFacade.class);
        Mockito.when(gdmMetaFacade.getTable(tableName)).thenReturn(table);
        Mockito.when(gdmMetaFacade.getEntity(entityName)).thenReturn(entity);
        Mockito.when(gdmMetaFacade.getEntityPrimaryKey(entityName)).thenReturn(entity.getFieldsMap().get(entity.getPrimaryKeyField()));
        CustomizableTableFactory customizableTableFactory = new CustomizableTableFactory("meta/gdm-table/customizable-tables.json");
        return new GdmProvisionService(gdmMetaFacade, ColumnProvisionStrategy.STRAIGHT_FORWARD_AND_LOOK_BACK, customizableTableFactory);
    }
}
