package com.convertlab.foundation.gdmmeta.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.*;
import java.util.stream.Collectors;

import com.convertlab.foundation.gdmmeta.model.Entity;
import com.convertlab.foundation.gdmmeta.service.impl.loader.SystemMetaDefObject;
import com.convertlab.foundation.library.constant.DataProcessingMode;
import com.convertlab.foundation.library.multitenancy.context.TenantContextMutable;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.convertlab.foundation.gdmmeta.model.metaobject.SystemMetaCorrectionObject;
import com.convertlab.foundation.library.gdmmeta.model.*;
import com.convertlab.customer.meta.MetaLoader;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag("UnitTest")
@Tag("GdmMeta")
class ConfigMetaProviderTest implements TenantContextMutable {

    private ConfigMetaProviderImpl service;
    @BeforeEach
    public void setUp() {
        mutateTenantContext(10L);
        service = new ConfigMetaProviderImpl();
    }

    @Test
    void getDatabaseStructure() {
    }

    @Test
    void usage_getImmutableGdmEntityFromJsonDirectly() {
        ImmutableGdmEntity.Builder customerEntityBuilder =
                ImmutableGdmEntity.builder()
                        .entityName("Customer").isDbView(true).dbTableName("customer")
                        .addDataProcessingModes(DataProcessingMode.OLTP, DataProcessingMode.REALTIME_AP)
                        .inheritance(ImmutableGdmInheritance.builder().isSubtype(false).parentEntityName("")
                                .identifierField("idStr").identifierValue("String").build());

        Map<String, List<Map<String, String>>> sysMetas = MetaLoader.loadCustomerMeta();
        Set<Map.Entry<String, List<Map<String, String>>>> entries = sysMetas.entrySet();
        for (Map.Entry<String, List<Map<String, String>>> entry : entries) {
            System.out.println("meta key: " + entry.getKey());
            List<Map<String, String>> fieldsList = entry.getValue();
            for (Map<String, String> field : fieldsList) {
                ImmutableGdmField gdmField =
                        ImmutableGdmField.builder()
                                .fieldName(field.get("name"))
                                .fieldType(FieldType.valueOf(field.get("innerType")))
                                .dbColumnName(field.get("name"))
                                .build();
                customerEntityBuilder.addFields(gdmField);
            }
        }
        ImmutableGdmEntity gdmEntity = customerEntityBuilder.build();
    }

    @Test()
    void usage_useFieldType() {
        String integerTypeName = "Integer";
        String mobileTypeName = "Mobile";

        Set<String> typeNames = Arrays.stream(FieldType.values())
                .map(type -> type.name()).collect(Collectors.toSet());

        assertThrows(IllegalArgumentException.class,
                () -> { FieldType.valueOf(mobileTypeName); }
        );

        FieldType mobileType = FieldType.getTypeWithDefaultUndefined(mobileTypeName);
        assertEquals(mobileType, FieldType.Unknown,
                "mobile innerType should matched default UndefinedType type, mobile type: " + mobileType);

       log.info("MobileType: " + mobileType);

    }

    @Test
    void loadSystemMetaCorrection() {
        SystemMetaCorrectionObject correction = service.loadSystemMetaCorrectionObject();
        log.info("correction info : " + correction);
    }

    @Test
    void loadSystemEntityMetaDef() {
        SystemMetaDefObject systemRegisteredMetaObject = service.getSystemRegisteredMetaObject();
        log.info("systemRegisteredMetaObject info : " + systemRegisteredMetaObject);
        assertNotNull(systemRegisteredMetaObject);
    }

    @Test
    void test_loadTenantCustomerMetaString() {
        String s = service.loadTenantCustomerMetaString();
        assertNotNull(s);
    }

    @Test
    void test_getRegisteredSystemCustomerEventEntities() {
        List<Entity> events = service.getRegisteredSystemCustomerEventEntities(false);
        assertFalse(events.isEmpty());
    }

}
