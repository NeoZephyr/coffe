package com.convertlab.foundation.user;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.user.entity.Dept;
import com.convertlab.foundation.user.entity.UserDept;
import com.convertlab.foundation.user.entity.UserTenant;
import com.convertlab.foundation.user.mapper.DeptMapper;
import com.convertlab.foundation.user.mapper.UserDeptMapper;
import com.convertlab.foundation.user.mapper.UserMapper;
import com.convertlab.foundation.user.model.MoveDeptDTO;
import com.convertlab.foundation.user.service.UserDeptService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.util.Arrays;
import java.util.Collections;

public class UserDeptServiceTest {

    @InjectMocks
    private UserDeptService userDeptService;

    @Mock
    private DeptMapper deptMapper;

    @Mock
    private UserMapper userMapper;

    @Mock
    private UserDeptMapper userDeptMapper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testMove() {
        // Prepare test data
        MoveDeptDTO dto = new MoveDeptDTO();
        dto.setFromDeptCode("fromDeptCode");
        dto.setToDeptCodes(Arrays.asList("toDeptCode1", "toDeptCode2"));
        dto.setUserIds(Arrays.asList(1L, 2L, 3L));

        when(deptMapper.getDeptByCode(anyString())).thenReturn(new Dept());
        when(userMapper.getUserTenantByIdList(anyList())).thenReturn(Arrays.asList(1L, 2L, 3L) );

        UserDept userdept = new UserDept();
        userdept.setId(1L);
        when(userDeptMapper.getUserDeptByUserIdAndDeptCode(anyLong(), anyString()))
                .thenReturn(userdept)
                .thenReturn(userdept)
                .thenReturn(userdept)
                .thenReturn(null)
                .thenReturn(null)
                .thenReturn(null)
                .thenReturn(null)
                .thenReturn(null)
                .thenReturn(null)
        ;
        when(userMapper.getUserTenantByUserId(anyLong())).thenReturn(Collections.singletonList(1L));

        // Call the method being tested
        userDeptService.move(dto);

        // Verify if the methods are called with correct parameters
        verify(userDeptMapper, times(6)).insert(any(UserDept.class));
        verify(userDeptMapper, times(3)).deleteById(anyLong());
    }

    @Test
    void testSaveUserDept() {
        // Prepare test data
        String deptCode = "deptCode";
        Long userId = 1L;

        when(deptMapper.getDeptByCode(anyString())).thenReturn(new Dept());
        when(userMapper.getUserTenantByUserId(anyLong())).thenReturn(Collections.singletonList(1L));

        // Call the method being tested
        userDeptService.saveUserDept(deptCode, userId);

        // Verify if the methods are called with correct parameters
        verify(userDeptMapper).insert(any(UserDept.class));
    }

    @Test
    void testDeleteUserDept() {
        // Prepare test data
        String deptCode = "deptCode";
        Long userId = 1L;

        UserDept userdept = new UserDept();
        userdept.setId(1L);
        when(userDeptMapper.getUserDeptByUserIdAndDeptCode(anyLong(), anyString())).thenReturn(userdept);

        // Call the method being tested
        userDeptService.deleteUserDept(deptCode, userId);

        // Verify if the methods are called with correct parameters
        verify(userDeptMapper).deleteById(anyLong());
    }

    @Test
    void testMoveWithEmptyUserIds() {
        MoveDeptDTO dto = new MoveDeptDTO();
        dto.setFromDeptCode("fromDeptCode");
        dto.setToDeptCodes(Arrays.asList("toDeptCode1", "toDeptCode2"));
        dto.setUserIds(Collections.emptyList());

        assertThrows(BusinessException.class, () -> userDeptService.move(dto));
    }

    @Test
    void testMoveWithMissingFromDeptCodeAndToDeptCodes() {
        MoveDeptDTO dto = new MoveDeptDTO();
        dto.setUserIds(Arrays.asList(1L, 2L, 3L));

        assertThrows(BusinessException.class, () -> userDeptService.move(dto));
    }

    @Test
    void testMoveWithMismatchedUserIdsAndUserTenants() {
        MoveDeptDTO dto = new MoveDeptDTO();
        dto.setFromDeptCode("fromDeptCode");
        dto.setToDeptCodes(Arrays.asList("toDeptCode1", "toDeptCode2"));
        dto.setUserIds(Arrays.asList(1L, 2L, 3L));

        when(deptMapper.getDeptByCode(anyString())).thenReturn(new Dept());
        when(userMapper.getUserTenantByIdList(anyList())).thenReturn(Arrays.asList(1L, 2L));

        assertThrows(BusinessException.class, () -> userDeptService.move(dto));
    }
}