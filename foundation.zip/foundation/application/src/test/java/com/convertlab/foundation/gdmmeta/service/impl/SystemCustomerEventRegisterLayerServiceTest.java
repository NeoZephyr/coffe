package com.convertlab.foundation.gdmmeta.service.impl;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Map;

import com.convertlab.foundation.gdmmeta.service.ConfigMetaProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.convertlab.foundation.gdmmeta.model.Entity;
import com.convertlab.foundation.gdmmeta.service.LayerServiceCheck;
import com.convertlab.foundation.gdmmeta.service.impl.loader.SystemCustomerEventEntityLoader;

@Tag("UnitTest")
@Tag("GdmMeta")
class SystemCustomerEventRegisterLayerServiceTest implements LayerServiceCheck {

    SystemCustomerEventEntityLoader service;

    @BeforeEach
    void setUp() {
        ConfigMetaProvider configMetaProvider = new ConfigMetaProviderImpl();
        service = new SystemCustomerEventEntityLoader(configMetaProvider);
    }

    @Test
    void getEntityNames() {
        assertTrue(service.getEntityNames().size() > 0);
    }

    @Test
    void loadEntity() {
        //返回 null ，代表不存在
        final String NOT_EXISTED_ENTITY = "NOT_EXISTED_ENTITY";
        assertNull(service.loadEntity(NOT_EXISTED_ENTITY));

        final String existedEvent = "send_sms";
        assertNotNull(service.loadEntity(existedEvent));
    }

    @Test
    void getEntities() {
        Map<String, Entity> entities = service.getEntities();
        assertNotNull(entities);

        for (Entity entity : entities.values()) {
            checkRegisteredGdmEntity(entity);
        }
    }
}
