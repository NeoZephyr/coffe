package com.convertlab.foundation.user;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.convertlab.foundation.library.business.audit.AuditOperations;
import com.convertlab.foundation.user.mapper.UserGroupMapMapper;
import com.convertlab.foundation.user.mapper.UserGroupMapper;
import com.convertlab.foundation.user.service.UserGroupService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class UserGroupTest {


    @Mock
    private UserGroupMapper userGroupMapper;

    @Mock
    private UserGroupMapMapper userGroupMapMapper;

    @Mock
    private AuditOperations auditor;

    @InjectMocks
    UserGroupService userGroupService;

    @Test
    public void listTest() {
        // Call the index method
        userGroupService.index("test", Page.of(1, 10));

        // Verify that the selectPage method is called internally
        verify(userGroupMapper).selectPage(any(), any());
    }

}