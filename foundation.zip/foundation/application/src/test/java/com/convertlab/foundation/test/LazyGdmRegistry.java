package com.convertlab.foundation.test;

import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmMetaRegistry;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationship;
import com.convertlab.foundation.library.gdmmeta.model.table.GdmTable;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

/**
 * 例子：如何访问远端的meta服务来按需查询meta data
 */
public class LazyGdmRegistry implements GdmMetaRegistry {
    private final ObjectMapper objectMapper;
    private final DocumentContext jsonContext;

    public LazyGdmRegistry(String fileName) throws IOException, URISyntaxException {
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.registerModule(new Jdk8Module());

        URL resource = LazyGdmRegistry.class.getResource(fileName);
        assert resource != null;
        this.jsonContext = JsonPath.parse(Paths.get(resource.toURI()).toFile());
    }
    @Override
    public Map<String, GdmEntity> getEntities() {
        throw new IllegalStateException("Not implemented");
    }

    @Override
    public List<GdmRelationship> getRelationships() {
        throw new IllegalStateException("Not implemented");
    }

    @Override
    public Map<String, GdmTable> getTables() {
        throw new IllegalStateException("Not implemented");
    }

    private Map fakeRestCall(int type, String name) {
        String ENTITY_TEMPLATE = "$.entities.%s";
        String TABLE_TEMPLATE = "$.tables.%s";
        String EXT_TEMPLATE = "$.ext";
        String RELATIONSHIP_TEMPLATE = "$.relationships[?(@.name == '%s')]";
        switch (type) {
            case 1:
                String str = String.format(ENTITY_TEMPLATE, name);
                return jsonContext.read(str);
            case 2:
                str = String.format(RELATIONSHIP_TEMPLATE, name);
                Object relJson = jsonContext.read(str);
                return (Map) ((List<?>)relJson).get(0);
            case 3:
                return jsonContext.read(EXT_TEMPLATE);
            case 4:
                str = String.format(TABLE_TEMPLATE, name);
                return jsonContext.read(str);
        }
        return null;
    }

    @Override
    public GdmEntity getEntity(String entityName)  {
        Map entityJson = fakeRestCall(1, entityName);
        return objectMapper.convertValue(entityJson,GdmEntity.class);
    }

    public GdmRelationship getRelationship(String relationshipName) {
        Map entityJson2 = fakeRestCall(2, relationshipName);
        return objectMapper.convertValue(entityJson2,GdmRelationship.class);
    }

    @Override
    public Map getExt(){
        Map entityJson = fakeRestCall(3,"");
        return objectMapper.convertValue(entityJson,Map.class);
    }

    public GdmTable getTable(String tableName)  {
        Map entityJson = fakeRestCall(4, tableName);
        return objectMapper.convertValue(entityJson,GdmTable.class);
    }
}
