package com.convertlab.foundation.gdmmeta.model;

import java.util.*;

import com.convertlab.foundation.library.gdmmeta.model.ColumnType;
import com.convertlab.foundation.library.gdmmeta.model.FieldType;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.google.common.collect.Maps;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

@Slf4j
@Tag("UnitTest")
@Tag("GdmMeta")
class AttributeMergerTest {
    @Test
    @DisplayName("合并两个Field对象")
    public void testMerge() {
        log.info("field1: {}", formater(fieldDefinitionFromDb()));
        log.info("field2: {}", formater(fieldDefinitionFromExistingMeta()));

        GdmObjectMerger gdmObjectMerger = GdmObjectMerger.build(GdmObjectMerger.EntityMergeStrategies.ADD_NOT_EXISTED_FIELDS, GdmObjectMerger.FieldMergeStrategies.BY_ID);
        // CAR(UDO1) [c_ext_id(attr1):integer(varchar(20)) as extId]
        Field field = gdmObjectMerger.merge(fieldDefinitionFromDb(), fieldDefinitionFromExistingMeta());
        log.info("merged field: {}", formater(field));

        // 看看结果对不对
        assertEquals("c_ext_id",   field.getFieldName());
        assertEquals(FieldType.Integer,     field.getFieldType());
        assertEquals("extId",      field.getFieldAlias());

        assertEquals("attr1",       field.getDbColumnName());
        assertEquals(ColumnType.VARCHAR,    field.getDbColumnType());
    }

    @Test
    @DisplayName("合并两个Entity对象")
    public void testMergeEntity() {

        log.info("base entity: {}\n", formater(entityDefinitionFromDb()));
        log.info("overlay entity: {}\n", formater(entityDefinitionFromExistingMeta()));

        GdmObjectMerger gdmObjectMerger = GdmObjectMerger.build(GdmObjectMerger.EntityMergeStrategies.ADD_NOT_EXISTED_FIELDS, GdmObjectMerger.FieldMergeStrategies.BY_ID);
        // CAR(UDO1) [c_ext_id(attr1):integer(varchar(20)) as extId]
        Entity entity = gdmObjectMerger.merge(entityDefinitionFromDb(), entityDefinitionFromExistingMeta());
        log.info("merged entity: {}\n", formater(entity));

        // 看看结果对不对
        assertEquals("CAR",        entity.getEntityName());
        assertEquals(1,            entity.getId());

        assertEquals(1, entity.getFields().size());
        Field field = entity.getFields().get(0);
        assertEquals("c_ext_id",   field.getFieldName());
        assertEquals(FieldType.Integer,     field.getFieldType());
        assertEquals("extId",      field.getFieldAlias());

        assertEquals("attr1",      field.getDbColumnName());
        assertEquals(ColumnType.VARCHAR,    field.getDbColumnType());

    }

    @Test
    @DisplayName("两个Entity对象相减+GdmObjectMerger.build+使用设置MergeStrategy")
    public void testSubtract2() {
        GdmObjectMerger gdmObjectMerger = GdmObjectMerger.build(
                Maps.immutableEntry(Entity.class, new GdmObjectMerger.MergeStrategies<>(
                                (base, overlay) -> base.getId().equals(overlay.getId()),
                                Entity::unsetIfNotNull,
                                GdmObjectMerger.RecursiveStrategy.RECURSIVE)
                ),
                Maps.immutableEntry(Field.class, new GdmObjectMerger.MergeStrategies<>(
                                (base, overlay) -> base.getId().equals(overlay.getId()),
                                Field::unsetIfNotNull,
                                GdmObjectMerger.RecursiveStrategy.EXPAND_COLLECTION_NO_RECURSIVE)
                )
        );
        // 注意，这里必须按照下面的写法，不然编译器会找不到合适的实现类， 明确写 GdmObjectMerger.MergeStrategies<Entity>
//        GdmObjectMerger.MergeStrategies<Entity> entityMergeStrategies = gdmObjectMerger.getMergeStrategies(Entity.class);
//        entityMergeStrategies.setAssignValueStrategy(Entity::unsetIfNotNull);
//        gdmObjectMerger.getMergeStrategies(Entity.class).setAssignValueStrategy(Entity::unsetIfNotNull);

//        GdmObjectMerger.MergeStrategies<Field> fieldMergeStrategies = gdmObjectMerger.getMergeStrategies(Field.class);
//        fieldMergeStrategies.setAssignValueStrategy(Field::unsetIfNotNull);
//        GdmObjectMerger.MergeStrategies<AssignValueStrategy> m = gdmObjectMerger.getMergeStrategies(Field.class);
//        gdmObjectMerger.getMergeStrategies(Field.class).setAssignValueStrategy(Field::unsetIfNotNull);

        Entity entity = gdmObjectMerger.merge(entityDefinitionFromDb(), entityDefinitionFromExistingMeta());
        log.info("unset entity: {}\n", formater(entity));

        GdmObjectMerger customObjectMerger = GdmObjectMerger.build(CustomMergeStrategiesForTest.ENTITY, CustomMergeStrategiesForTest.FIELD);
        Entity entity2 = customObjectMerger.merge(entityDefinitionFromDb(), entityDefinitionFromExistingMeta());
        log.info("special entity: {}\n", formater(entity2));

        assertEquals(entity, entity2);
    }

    @Test
    @DisplayName("两个Entity对象相减+使用自定义Entity Merge Strategy定义Merger")
    public void testSubtract()  {
        log.info("base entity: {}\n", formater(entityDefinitionFromDb()));
        log.info("overlay entity: {}\n", formater(entityDefinitionFromExistingMeta()));


        Map.Entry<Class, GdmObjectMerger.MergeStrategies> entityStrategy = Maps.immutableEntry(Entity.class, new GdmObjectMerger.MergeStrategies<>(
                (b, o) -> b.getId().equals(o.getId()),
                Entity::unsetIfNotNull,
                GdmObjectMerger.RecursiveStrategy.NO_RECURSIVE
        ));
        GdmObjectMerger gdmObjectMerger = GdmObjectMerger.build(entityStrategy);

        // CAR(UDO1) [c_ext_id(attr1):integer(varchar(20)) as extId]
        Entity entity = gdmObjectMerger.merge(entityDefinitionFromDb(), entityDefinitionFromExistingMeta());
        log.info("merged entity: {}\n", formater(entity));
        assertEquals(1,entity.getId());
        assertEquals(false, entity.getDbView());
    }
    private String formater(Object toLog) {
        try {
            return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(toLog);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    Field fieldDefinitionFromDb() {
        // UDO1(UDO1) [attr1(attr1):string(varchar(20)) as attr1]
        Field field = Field.builder()
                .id(1)
                .dbColumnName("attr1")
                .fieldName("attr1")
                .dbColumnType(ColumnType.VARCHAR)
                .fieldType(FieldType.String)
                .build();
        return field;
    }

    Field fieldDefinitionFromExistingMeta() {
        // CAR(UDO1) [c_ext_id(attr1):integer(null) as extId]
        Field field = Field.builder()
                .id(1)
                .fieldName("c_ext_id")
                .fieldType(FieldType.Integer)
                .fieldAlias("extId")
                .build();
        return field;
    }

    Entity entityDefinitionFromDb() {
        // UDO1(UDO1) [attr1(attr1):string(varchar(20)) as null]
        Entity entity = Entity.builder()
                .id(1)
                .dbView(false)
                .entityName("UDO1")
                .fields(Arrays.asList(fieldDefinitionFromDb()))
                .build();
        return entity;
    }

    Entity entityDefinitionFromExistingMeta() {
        // CAR(UDO1) [c_ext_id(null):integer(null) as extId]
        Entity entity = Entity.builder()
                .entityName("CAR")
                .fields(Arrays.asList(fieldDefinitionFromExistingMeta()))
                .build();
        return entity;
    }

    ObjectMapper objectMapper = new ObjectMapper();
    {
        objectMapper.registerModule(new Jdk8Module());
    }
}
