package com.convertlab.foundation.gdmmeta.service.impl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.Collections;
import java.util.Map;

import com.convertlab.foundation.gdmmeta.service.ConfigMetaProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.convertlab.foundation.gdmmeta.model.Entity;
import com.convertlab.foundation.gdmmeta.service.LayerServiceCheck;
import com.convertlab.foundation.gdmmeta.service.impl.loader.SystemImpalaEntityFieldsLoader;

@Tag("UnitTest")
@Tag("GdmMeta")
class SystemImpalaEntityFieldsLayerServiceTest implements LayerServiceCheck {

    SystemImpalaEntityFieldsLoader service;

    @BeforeEach
    void setUp() {
        DbMetaProviderImpl dbMetaService = getDefaultMockDbMetaService();
        ConfigMetaProviderImpl configMetaProvider = new ConfigMetaProviderImpl();
        dbMetaService.setLoadFromLocal(true, Collections.emptyList(), configMetaProvider.loadImpalaDatabaseStructure());
        service = new SystemImpalaEntityFieldsLoader(configMetaProvider, dbMetaService);
    }

    @Test
    void getEntityNames() {
         assertNotNull(service.getEntityNames());
    }

    @Test
    void loadEntity() {
        assertNull(service.loadEntity("not_existed"));
        assertNotNull(service.loadEntity("customer_event"));
        assertNotNull(service.loadEntity("tag"));
    }

    @Test
    void getEntities() {
        Map<String, Entity> entities = service.getEntities();
        for (Entity dbEntity : entities.values()) {
            checkEntityDbFields(dbEntity);
        }
    }
}
