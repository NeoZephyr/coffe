package com.convertlab.foundation.gdmmeta.configure;

import de.flapdoodle.embed.mongo.config.Net;
import de.flapdoodle.embed.mongo.transitions.Mongod;
import de.flapdoodle.embed.mongo.types.DistributionBaseUrl;
import de.flapdoodle.reverse.transitions.Start;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CustomeMongodConfiguration {

    @Bean(name = "customizeMongod")
    Mongod customizeMongod(Net net, @Value("${convertlab.test.custom.mongo.downloadDomain}") String mongoDownloadUrl) {
        return
                Mongod.builder()
                        .net(Start.to(Net.class).initializedWith(net))
                        .distributionBaseUrl(
                                Start.to(DistributionBaseUrl.class)
                                        .initializedWith(DistributionBaseUrl.of(mongoDownloadUrl))

                        )
                        .build();

    }
}
