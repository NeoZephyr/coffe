package com.convertlab.foundation.gdmpattern;

import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.gdmpattern.model.GdmModel;
import com.convertlab.foundation.library.gdmmeta.model.FieldType;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.table.GdmTable;
import com.convertlab.foundation.library.utils.JsonUtils;

import java.util.List;

public class PatternTestHelper {
    public static List<GdmModelDto.Field> getFields1() {
        String fieldJson = "[\n" +
                "        {\n" +
                "          \"ext\": {},\n" +
                "          \"fieldName\": \"pk\",\n" +
                "          \"fieldType\": \"Long\",\n" +
                "          \"isPrimaryKey\": \"true\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"ext\": {},\n" +
                "          \"fieldName\": \"brand\",\n" +
                "          \"fieldType\": \"String\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"ext\": {},\n" +
                "          \"fieldName\": \"type\",\n" +
                "          \"fieldType\": \"Short\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"ext\": {},\n" +
                "          \"fieldName\": \"owner_name\",\n" +
                "          \"fieldType\": \"String\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"ext\": {},\n" +
                "          \"fieldName\": \"driver_id\",\n" +
                "          \"fieldType\": \"Long\",\n" +
                "          \"isForeignKey\": true,\n" +
                "          \"refEntityName\": \"c_driver\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"ext\": {},\n" +
                "          \"fieldName\": \"production_date\",\n" +
                "          \"fieldType\": \"Date\"\n" +
                "        }\n" +
                "      ]";
        return JsonUtils.instance().json2List(fieldJson, GdmModelDto.Field.class);
    }

    public static List<GdmModelDto.Field> getFields2() {
        String fieldJson = "[\n" +
                "        {\n" +
                "          \"ext\": {},\n" +
                "          \"fieldName\": \"company\",\n" +
                "          \"fieldType\": \"String\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"ext\": {},\n" +
                "          \"fieldName\": \"seller\",\n" +
                "          \"fieldType\": \"String\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"ext\": {},\n" +
                "          \"fieldName\": \"engine_type\",\n" +
                "          \"fieldType\": \"Short\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"ext\": {},\n" +
                "          \"fieldName\": \"sale_date\",\n" +
                "          \"fieldType\": \"Date\"\n" +
                "        }\n" +
                "      ]";
        return JsonUtils.instance().json2List(fieldJson, GdmModelDto.Field.class);
    }

    public static void addSystemField(List<GdmModelDto.Field> fields, String fieldName, FieldType fieldType, String dbColumnName) {
        GdmModelDto.Field field = new GdmModelDto.Field(fieldName, fieldType, dbColumnName, false, false, false,
                null, null, null, null, null);
        fields.add(field);
    }

    public static GdmTable getUdoTable() {
        String jsonTable = "{\n" +
                "  \"tableName\": \"nudo1\",\n" +
                "  \"columns\": [\n" +
                "    {\n" +
                "      \"columnName\": \"tenant_id\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"INTEGER\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"INTEGER\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"obj_id\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"bk\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"date_created\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"last_updated\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"id\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"owner_id\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"creator_id\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"creator_name\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"name\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t1\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t2\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t3\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t4\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t5\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t6\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t7\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t8\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t9\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t10\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t11\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t12\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t13\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t14\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t15\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t16\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t17\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t18\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t19\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t20\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t21\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t22\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t23\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t24\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t25\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t26\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t27\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t28\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t29\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t30\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t31\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t32\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t33\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t34\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t35\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t36\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t37\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t38\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t39\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t40\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t41\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t42\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t43\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t44\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t45\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t46\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t47\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t48\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t49\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t50\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t51\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t52\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t53\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t54\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t55\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t56\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t57\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t58\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t59\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t60\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t61\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t62\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t63\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t64\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t65\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t66\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t67\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t68\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t69\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t70\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t71\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t72\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t73\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t74\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t75\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t76\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t77\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t78\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t79\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t80\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t81\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t82\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t83\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t84\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t85\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t86\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t87\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t88\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t89\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t90\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t91\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t92\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t93\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t94\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t95\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t96\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t97\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t98\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t99\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t100\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t101\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t102\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t103\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t104\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t105\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t106\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t107\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t108\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t109\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t110\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t111\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t112\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t113\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t114\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t115\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t116\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t117\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t118\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t119\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t120\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t121\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t122\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t123\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t124\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t125\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t126\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t127\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t128\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t129\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t130\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t131\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t132\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t133\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t134\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t135\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t136\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t137\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t138\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t139\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t140\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t141\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t142\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t143\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t144\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t145\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t146\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t147\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t148\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t149\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t150\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t151\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t152\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t153\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t154\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t155\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t156\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t157\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t158\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t159\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"t160\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d1\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d2\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d3\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d4\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d5\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d6\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d7\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d8\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d9\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d10\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d11\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d12\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d13\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d14\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d15\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d16\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d17\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d18\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d19\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d20\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DATETIME\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d21\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d22\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d23\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d24\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d25\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d26\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d27\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d28\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d29\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d30\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d31\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d32\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d33\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d34\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d35\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d36\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d37\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d38\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d39\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"d40\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n1\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n2\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n3\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n4\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n5\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n6\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n7\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n8\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n9\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n10\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n11\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n12\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n13\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n14\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n15\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n16\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n17\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n18\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n19\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n20\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"DECIMAL\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n21\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n22\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n23\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n24\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n25\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n26\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n27\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n28\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n29\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n30\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n31\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n32\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n33\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n34\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n35\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n36\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n37\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n38\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n39\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"n40\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"fk1\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"fk2\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"fk3\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"fk4\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"fk5\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"fk6\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"fk7\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"fk8\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"fk9\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"fk10\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"MYSQL\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        },\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    }\n" +
                "  ],\n" +
                "  \"storages\": [\n" +
                "    {\n" +
                "      \"dbType\": \"KUDU\",\n" +
                "      \"ext\": {},\n" +
                "      \"primaryKeyColumns\": [\n" +
                "        \"tenant_id\"\n" +
                "      ],\n" +
                "      \"hashPartitionColumns\": [\n" +
                "        \"tenant_id\"\n" +
                "      ]\n" +
                "    },\n" +
                "    {\n" +
                "      \"dbType\": \"MYSQL\",\n" +
                "      \"ext\": {}\n" +
                "    }\n" +
                "  ],\n" +
                "  \"$version\": \"20\",\n" +
                "  \"$self\": \"/v1/meta/gdm/tables/nudo1\",\n" +
                "  \"$basePath\": \"/v1/meta/gdm/tables\",\n" +
                "  \"dateCreated\": \"2023-07-07T08:07:57.055Z\",\n" +
                "  \"lastUpdated\": \"2023-07-12T07:32:52.374Z\",\n" +
                "  \"isDbView\": false\n" +
                "}";
        return JsonUtils.instanceOfDto().json2Obj(jsonTable, GdmTable.class);
    }

    public static GdmTable getUdoEventTable() {
        String jsonStr = "{\n" +
                "  \"tableName\": \"general_event\",\n" +
                "  \"columns\": [\n" +
                "    {\n" +
                "      \"columnName\": \"tenant_id\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"INTEGER\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"bk\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"event\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"field_date\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"external_id\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"obj_id\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"rt1\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"rt2\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"rn2\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"id\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr1\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr2\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr3\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr4\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr5\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"channel_account\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"channel_type\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"device\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"employee\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"inbound\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"INTEGER\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"field_location\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"referrer\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"referrer_name\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"tag\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"target_id\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"target_name\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"campaign\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"campaign_name\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"content_name\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"source\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"summary\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"internal_content_id\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"last_forwarder\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"score\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"INTEGER\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"last_updated\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"ref_score\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"INTEGER\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"page_id\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"event_group\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"batch_id\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"from_collector\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"INTEGER\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"app_name\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"app_version\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"quantity1\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"quantity2\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"amount1\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"amount2\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"identity_value\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"identity_type\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"identity_value2\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"identity_type2\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"identity_value3\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"identity_type3\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"is_first_try\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"INTEGER\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"is_first_engage\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"INTEGER\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"duration\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"INTEGER\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"utma\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"utm\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"quantity3\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"date1\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"date2\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"platform\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"os\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"os_version\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"browser\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"browser_version\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"model\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"network\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"ip\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"ip_county\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"ip_city\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"ip_province\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"ip_country\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"screen_width\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"screen_height\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"domain\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"path\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr6\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr7\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr8\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr9\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr10\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"amount3\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"date3\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"page_type\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"session_id\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"url\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr11\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr12\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr13\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr14\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr15\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr16\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr17\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr18\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr19\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr20\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr21\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr22\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr23\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr24\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr25\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr26\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr27\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr28\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr29\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr30\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr31\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr32\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr33\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr34\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr35\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr36\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr37\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr38\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr39\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"attr40\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"date4\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"date5\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"date6\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"date7\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"date8\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"date9\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"date10\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"BIGINT\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"amount4\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"amount5\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"amount6\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"amount7\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"amount8\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"amount9\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"amount10\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"longitude\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"latitude\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"DOUBLE\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"source1\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"source2\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"source3\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"source4\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"source5\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"source6\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"source7\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"source8\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"VARCHAR\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"flow_id\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"INTEGER\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"flow_version\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"INTEGER\"\n" +
                "        }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"columnName\": \"step_id\",\n" +
                "      \"columnDefs\": {\n" +
                "        \"KUDU\": {\n" +
                "          \"columnType\": \"INTEGER\"\n" +
                "        }\n" +
                "      }\n" +
                "    }\n" +
                "  ],\n" +
                "  \"storages\": [\n" +
                "    {\n" +
                "      \"dbType\": \"KUDU\",\n" +
                "      \"ext\": {},\n" +
                "      \"primaryKeyColumns\": [],\n" +
                "      \"hashPartitionColumns\": []\n" +
                "    },\n" +
                "    {\n" +
                "      \"dbType\": \"PARQUET\",\n" +
                "      \"ext\": {},\n" +
                "      \"partitionBy\": []\n" +
                "    }\n" +
                "  ],\n" +
                "  \"$version\": \"253\",\n" +
                "  \"$self\": \"/v1/meta/gdm/tables/general_event\",\n" +
                "  \"$basePath\": \"/v1/meta/gdm/tables\",\n" +
                "  \"dateCreated\": \"2023-07-07T08:07:52.100Z\",\n" +
                "  \"lastUpdated\": \"2023-07-12T07:32:53.317Z\",\n" +
                "  \"isDbView\": false\n" +
                "}";
        return JsonUtils.instanceOfDto().json2Obj(jsonStr, GdmTable.class);
    }

    public static GdmEntity getDriverEntity() {
        String entityJson = "{\n" +
                "  \"ext\": {},\n" +
                "  \"entityName\": \"c_driver\",\n" +
                "  \"fields\": [\n" +
                "    {\n" +
                "      \"ext\": {},\n" +
                "      \"fieldName\": \"id\",\n" +
                "      \"fieldType\": \"Long\",\n" +
                "      \"dbColumnName\": \"id\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"ext\": {},\n" +
                "      \"fieldName\": \"owner_id\",\n" +
                "      \"fieldType\": \"Integer\",\n" +
                "      \"dbColumnName\": \"owner_id\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"ext\": {},\n" +
                "      \"fieldName\": \"creator_id\",\n" +
                "      \"fieldType\": \"Integer\",\n" +
                "      \"dbColumnName\": \"creator_id\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"ext\": {},\n" +
                "      \"fieldName\": \"creator_name\",\n" +
                "      \"fieldType\": \"String\",\n" +
                "      \"dbColumnName\": \"creator_name\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"ext\": {},\n" +
                "      \"fieldName\": \"date_created\",\n" +
                "      \"fieldType\": \"DateTime\",\n" +
                "      \"dbColumnName\": \"date_created\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"ext\": {},\n" +
                "      \"fieldName\": \"last_updated\",\n" +
                "      \"fieldType\": \"DateTime\",\n" +
                "      \"dbColumnName\": \"last_updated\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"ext\": {},\n" +
                "      \"fieldName\": \"dept_code\",\n" +
                "      \"fieldType\": \"String\",\n" +
                "      \"dbColumnName\": \"dept_code\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"ext\": {},\n" +
                "      \"fieldName\": \"pk\",\n" +
                "      \"fieldType\": \"Long\",\n" +
                "      \"dbColumnName\": \"bk\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"ext\": {},\n" +
                "      \"fieldName\": \"name\",\n" +
                "      \"fieldType\": \"String\",\n" +
                "      \"dbColumnName\": \"t1\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"ext\": {},\n" +
                "      \"fieldName\": \"customer_id\",\n" +
                "      \"fieldType\": \"Long\",\n" +
                "      \"dbColumnName\": \"fk1\"\n" +
                "    }\n" +
                "  ],\n" +
                "  \"dbTableName\": \"nudo1\",\n" +
                "  \"tablePartition\": {\n" +
                "    \"identifierType\": \"String\",\n" +
                "    \"identifierField\": \"obj_id\",\n" +
                "    \"identifierValue\": \"c_driver\"\n" +
                "  },\n" +
                "  \"primaryKeyField\": \"pk\",\n" +
                "  \"dataProcessingModes\": [\n" +
                "    \"OLTP\",\n" +
                "    \"REALTIME_AP\"\n" +
                "  ],\n" +
                "  \"$version\": \"0\",\n" +
                "  \"$self\": \"/v1/meta/gdm/entities/c_driver\",\n" +
                "  \"$basePath\": \"/v1/meta/gdm/entities\",\n" +
                "  \"dateCreated\": \"2023-08-09T08:02:26.386Z\",\n" +
                "  \"lastUpdated\": \"2023-08-09T08:02:26.386Z\",\n" +
                "  \"isDbView\": false\n" +
                "}";
        return JsonUtils.instanceOfDto().json2Obj(entityJson, GdmEntity.class);
    }
}
