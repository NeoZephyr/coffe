package com.convertlab.foundation.misc.service.impl;

import com.convertlab.foundation.misc.service.dao.HomeDao;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;

import static org.junit.jupiter.api.Assertions.*;

@Slf4j
@Tag("UnitTest")
class HomeServiceImplTest {

    @Test
    void greeting() {
        HomeDao homeDao = new HomeDao(new JdbcTemplate(), null, null) {
            @Override
            public String getDate() {
                return "2020-01-01";
            }
            @Override
            public String getCurrentDB() {
                return "testDB";
            }
        };
        HomeServiceImpl homeService = new HomeServiceImpl(homeDao, null, null);
        assertTrue( homeService.greeting().startsWith("Hello DB:testDB! Now is:2020-01-01"));
        log.info("Hello from homeService: {}", homeService.greeting());
    }
}