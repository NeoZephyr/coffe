package com.convertlab.foundation.gdmpattern.service;

import com.convertlab.data.job.core.biz.model.BizJob;
import com.convertlab.data.job.core.biz.model.BizJobRunResult;
import com.convertlab.data.job.core.biz.model.BizJobStatus;
import com.convertlab.data.job.core.biz.model.ReturnT;
import com.convertlab.data.job.core.constants.DataJobConstants;
import com.convertlab.data.job.core.context.ClJobContext;
import com.convertlab.data.job.core.util.data.AsyncBizJobService;
import com.convertlab.data.job.core.util.data.BizJobClient;
import com.convertlab.data.job.core.util.data.BizJobService;
import com.convertlab.data.job.core.util.data.JobData;
import com.convertlab.data.job.core.util.data.model.UpdateJobStatusRequest;
import com.convertlab.foundation.api.gdm.pattern.dto.DefineGdmModelRequest;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.api.gdm.pattern.facade.GdmMetaFacade;
import com.convertlab.foundation.gdmdata.mapper.GdmDataMapper;
import com.convertlab.foundation.gdmmeta.mybatis.service.UdoMetaService;
import com.convertlab.foundation.gdmpattern.job.GdmModelJob;
import com.convertlab.foundation.gdmpattern.job.GdmModelJobClient;
import com.convertlab.foundation.gdmpattern.model.GdmModel;
import com.convertlab.foundation.gdmpattern.service.feign.MigrationServiceFeignClient;
import com.convertlab.foundation.libaray.meta.health.Issue;
import com.convertlab.foundation.libaray.meta.health.TenantRepository;
import com.convertlab.foundation.libaray.meta.health.config.EnableMetaHealthCheck;
import com.convertlab.foundation.libaray.meta.health.controller.MetaHealthCheckController;
import com.convertlab.foundation.library.business.audit.AuditOperations;
import com.convertlab.foundation.library.business.autoconfigure.SpringBeans;
import com.convertlab.foundation.library.business.feature.FeatureClient;
import com.convertlab.foundation.library.business.feature.QueryToggleTenantsResponse;
import com.convertlab.foundation.library.business.property.EventBrokerProperties;
import com.convertlab.foundation.library.business.property.ExtraAuditProperties;
import com.convertlab.foundation.library.business.property.GdmMetaClientProperties;
import com.convertlab.foundation.library.business.property.ServiceApiProperties;
import com.convertlab.foundation.library.gdmmeta.client.GdmStorageMetaRtClient;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.client.SimpleMetaClient;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.general.BaseMetaSchema;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.GdmEntityExt;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.ObjectResponse;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationship;
import com.convertlab.foundation.library.gdmmeta.model.table.GdmTable;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.metahealth.controller.GdmMetaHealthCheckController;
import com.google.common.graph.MutableGraph;
import com.mongodb.client.MongoCollection;
import de.flapdoodle.embed.mongo.transitions.Mongod;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONException;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.core.MongoTemplate;

import javax.annotation.Nonnull;
import javax.annotation.Resource;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

import static com.convertlab.foundation.library.gdmmeta.model.general.BaseMetaSchema.MetaType.*;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(
        classes = {ModelIntegrationTestBase.TestContext.class}, // the component classes used to load the application context
        properties = {
                "spring.main.allow-bean-definition-overriding=true", // 虽然不想用这个，但的确很不好搞。先这样对付了。
                "de.flapdoodle.mongodb.embedded.version=6.0.6",
                "convertlab.product.name=dmhub",
                "convertlab.test.custom.mongo.downloadDomain=${MONGO_DOWNLOAD_DOMAIN:https://fastdl.mongodb.org}",
                "spring.application.name=dmhub",
                "convertlab.eventbroker.enabled=false",
                "convertlab.metaclient.design-time-mode=true",
                "logging.level.com.convertlab.foundation.library.utils.Try=DEBUG",
                "logging.level.root=INFO"
        }) // the properties used to configure the application context, the same as application.yaml

@Slf4j
@TestInstance(TestInstance.Lifecycle.PER_CLASS) // 不强制@BeforeAll是static！！！
public abstract class ModelIntegrationTestBase {
    //--------- Test Case Context类 ----------//
    @Configuration
    @Import({
            TestConfig.class, // 测试的主体配置类，大部分bean都是在这里引入的。
            GdmMetaHealthCheckController.class,
    })
    @EnableMetaHealthCheck(scanPackages = {
            "com.convertlab.foundation.metahealth.loader",
    })
    @EnableConfigurationProperties({ExtraAuditProperties.class, EventBrokerProperties.class,
            GdmMetaClientProperties.class, ServiceApiProperties.class})
    static class TestContext {
        //--------- Test Case里需要使用的 Stub Bean ----------//
        // 用featureClient举例子，做一个Stub，与测试用例无关，则可以在这里集中写它的调用返回值。
        @Bean
        public FeatureClient getFeatureClientStub() {
            return new FeatureClientStub();
        }
        @Bean(name = "tenantRepository")
        @Primary
        public TenantRepository getTenantRepositoryStub() {
            return new TenantRepositoryStub();
        }
        @Primary
        @Bean
        public GdmModelJobClient getGdmModelJobClientStub(BizJobClient bizJobClient,
                                                          GdmMetaFacade gdmMetaFacade,
                                                          GdmStorageMetaRtClient gdmStorageMetaClient
                                                          ) {
            return new GdmModelJobClientStub(bizJobClient, gdmMetaFacade, gdmStorageMetaClient);
        }

        @Bean
        @Primary
        public BizJobClient getBizJobClientMock() {
            return new BizJobClientStub(null, null);
        }

    }

    //--------- Test Case里需要使用的Stub Bean的实例引用 ----------//
    @Resource
    protected FeatureClient featureClientStub;
    @Resource
    protected GdmModelJobClient gdmModelJobClientStub;

    //--------- Test Case里需要使用的Bean的实例引用 ----------//
    @Resource
    protected GdmModelService gdmModelService;
    @Resource
    protected GsMetaClient gsMetaClient;
    @Qualifier("tenantIgnoredMongoTemplate")
    @Resource
    protected MongoTemplate tenantIgnoredMongoTemplate;
    @Resource(name = "customizeMongod")
    protected Mongod mongod;
    @Resource
    protected GdmMetaHealthCheckController healthCheckController;
    @Resource
    protected MetaHealthCheckController metaHealthCheckController;

    //--------- Test Case里的MockBean ----------//
    @MockBean
    protected UdoMetaService udoMetaService;
    @MockBean
    protected AuditOperations auditOperations;
    @Resource
    protected BizJobClient bizJobClientMock;

    @MockBean
    protected GdmDataMapper gdmDataMapper;

    @MockBean
    protected MigrationServiceFeignClient migrationServiceFeignClient;


    protected static long TENANT_A = 999L;
    protected static long TENANT_B = 998L;
    protected static long TENANT_C = 998L;
    protected static long SYSTEM_TENANT = -1L;

    private static transient boolean initialized = false;

    @BeforeAll
    void setup() {
        // 系统租户内的数据，普通租户里都是空的。
        // 下面的这些json文件必须使用Canonical Extended JSON格式导出，否则无法正确导入！
        // See also: https://www.mongodb.com/docs/compass/current/import-export/
        // 手工做，没必要自动化。
        if (!initialized) {
            init();
            initialized = true;

        }
    }
    synchronized void init() {
        log.info("Start import... [{}]", this.getClass().getSimpleName());
        loadIntoMongo("/mongo/gdm_schema_tables.json", "dmhub:gdm_schema_tables");
        loadIntoMongo("/mongo/gdm_schema_entities.json", "dmhub:gdm_schema_entities");
        log.info("Finished import... [{}]", this.getClass().getSimpleName());
    }


    /**
     * 检查Model和Entity
     * @param modelName 模型名
     */
    protected void doCheckModel(String modelName) {
        long tenantId = TenantContextHolder.getTenantIdExt();
        // 检查Model
        List<Issue> issues = healthCheckController.checkModel(tenantId, modelName);
        assertTrue(issues.isEmpty());
        // 检查Entity
        issues = healthCheckController.checkEntity(tenantId, modelName);
        assertTrue(issues.isEmpty());
        // 检查Relationship
        issues = healthCheckController.checkRelationship(tenantId, modelName, null);
        assertTrue(issues.isEmpty());
    }

    /**
     * 检查整个 Meta Store
     */
    protected void doFullCheck() {
        List<Issue> issues = metaHealthCheckController.check(-2L);
        assertTrue(issues.isEmpty());
    }

    /**
     * Meta data 按照 MetaType 的花名册
     */
    public static class Roster extends HashMap<BaseMetaSchema.MetaType, Set<String>>{
        @Override
        public  String toString() {
            StringBuilder result = new StringBuilder();

            for (Map.Entry<BaseMetaSchema.MetaType, Set<String>> entry : entrySet()) {
                BaseMetaSchema.MetaType type = entry.getKey();
                Set<String> values = entry.getValue();

                result.append(type).append(":\n"); // Append type with a newline

                for (String value : values) {
                    result.append("\t").append(value).append("\n"); // Indent each value
                }
            }

            return result.toString();
        }

        /**
         * Compare the current roster to before, the output is a new roster of the diff
         * @param before
         * @return
         */
        public Roster diff(Roster before) {
            Roster diffMap = new Roster();

            for (BaseMetaSchema.MetaType type : BaseMetaSchema.MetaType.values()) {
                Set<String> beforeSet = before.getOrDefault(type, new HashSet<>());
                Set<String> afterSet = this.getOrDefault(type, new HashSet<>());

                Set<String> added = new HashSet<>(afterSet);
                added.removeAll(beforeSet);

                Set<String> removed = new HashSet<>(beforeSet);
                removed.removeAll(afterSet);

                if (!added.isEmpty() || !removed.isEmpty()) {
                    Set<String> diffSet = new HashSet<>();
                    diffSet.addAll(added);
                    diffSet.addAll(removed);
                    diffMap.put(type, diffSet);
                }
            }

            return diffMap;
        }
    }
    protected Roster getObjectRoster() {
        Roster roster = new Roster();
        Arrays.stream(BaseMetaSchema.MetaType.values()).forEach(type->{
            Set<String> objectNames = getObjectNames(type);
            roster.put(type, objectNames);
        });
        return roster;
    }
    

    @Nonnull
    private Set<String> getObjectNames(@Nonnull BaseMetaSchema.MetaType type) {
        switch (type) {
            case GDM_ENTITIES:
                List<GdmEntity> allEntities = gsMetaClient.getEntityListByFilter(new HashMap<>());
                return allEntities.stream().map(GdmEntity::getEntityName).collect(Collectors.toSet());
            case GDM_TABLES:
                List<GdmTable> allTables = gsMetaClient.getTableList();
                return allTables.stream().map(GdmTable::tableName).collect(Collectors.toSet());
            case GDM_RELATIONSHIPS:
                List<GdmEntity> entities = gsMetaClient.getEntityListByFilter(new HashMap<>());
                Set<String> entityRelationSet = entities.stream().map(entity -> {
                    List<GdmRelationship> relationships = gsMetaClient.getRelationships(entity.getEntityName(), null);
                    return relationships.stream().map(gdmRelationship -> {
                        return entity.getEntityName() + "." + gdmRelationship.getName() +
                                "(" + gdmRelationship.getCardinality().toString() +
                                ") -> " + gdmRelationship.getRightEntityName();
                    }).collect(Collectors.toSet());
                }).collect(Collectors.toSet()).stream().flatMap(Set::stream).collect(Collectors.toSet());
                return entityRelationSet;
            default:
                List<ObjectResponse> allObjects = gsMetaClient.queryObjects(type.getNamespace(), type, new HashMap<>());
                return allObjects.stream().map(ObjectResponse::getObjectName).collect(Collectors.toSet());
        }
    }





    /**
     * 检查 entity及其field 是否有meaningful的ext属性。
     *
     * @param entityName    entity的名称
     * @param entityHasExt  是否检查entity自身的ext是否存在
     * @param fieldNames    需要检查的entity的field names
     */
    protected void doCheckEntityHasExt(String entityName, boolean entityHasExt, String ... fieldNames) {
        SimpleMetaClient extClient = gsMetaClient.simpleClientOf(GDM_ENTITY_EXT);
        GdmEntityExt entityExt = extClient.getObject2(entityName, GdmEntityExt.class);
        assertNotNull(entityExt);
        if (entityHasExt) assertTrue(entityExt.hasMeaningfulAttributes());

        Map<String, GdmEntityExt.Props> fieldMap = entityExt.getFieldPropsMap();
        assertFalse(fieldMap.isEmpty());
        for (String fieldName : fieldNames) {
            assertTrue(fieldMap.get(fieldName).hasMeaningfulData());
        }
    }

    /**
     * 将一个json文件导入到mongodb中
     * @param filename          文件名
     * @param collectionName    MongoDB 集合名
     * @throws IOException      读取文件失败
     * @throws JSONException    Json解析失败
     */
    private void loadIntoMongo(String filename, String collectionName) {
        try {
            String tableJson = JsonUtils.loadJsonAs(filename, String.class);
            // Parse JSON array
            JSONArray jsonArray = new JSONArray(tableJson);
            MongoCollection<Document> collection = tenantIgnoredMongoTemplate.getCollection(collectionName);
            // Insert each document in the array into MongoDB
            for (int i = 0; i < jsonArray.length(); i++) {
                Document document = Document.parse(jsonArray.getJSONObject(i).toString());
                collection.insertOne(document);
            }
        } catch (Exception e) {
            log.error("导入出错", e);
        }
    }

    protected GdmModelDto createModelFromFile(String fileName, String modelName) {
        DefineGdmModelRequest modelRequest =
                JsonUtils.loadJsonAs(fileName,DefineGdmModelRequest.class);
        return createModelFromRequest(modelRequest, modelName);
    }

    protected GdmModelDto createModelFromRequest(DefineGdmModelRequest modelRequest, String modelName) {
        gdmModelService.defineGdmModel(modelRequest);
        GdmModelDto modelDto = gdmModelService.findByName(modelName);
        return modelDto;
    }



    static class TenantRepositoryStub implements TenantRepository {
        @Override
        public List<Long> getAllTenants() {
            return Arrays.asList(999L, 998L, 997L);
        }
    }
    static class FeatureClientStub implements FeatureClient {

        @Override
        public boolean checkToggleStatus(String feature) {
            return feature.equalsIgnoreCase("abc");
        }

        @Override
        public List<String> listEnabledFeatures() {
            return null;
        }

        @Override
        public String getLimit(@Nonnull String feature) {
            return null;
        }

        @Override
        public QueryToggleTenantsResponse getToggleTenants(@Nonnull String feature, int pageSize, int startTenantId) {
            return null;
        }
    }

    static class GdmModelJobClientStub extends GdmModelJobClient {
        private GsMetaClient gsMetaClient;
        private GdmModelJob gdmModelJob;
        public GdmModelJobClientStub(BizJobClient bizJobClient, GdmMetaFacade gdmMetaFacade, GdmStorageMetaRtClient gdmStorageMetaClient) {
            super(bizJobClient,gdmMetaFacade,gdmStorageMetaClient);
            log.info("GdmModelJobClientStub created");
        }

        @Override
        public BizJobRunResult startTaskToDropGdmEntity(String entityName) {
            throw new UnsupportedOperationException("Not implemented");
        }

        @Override
        public BizJobRunResult startTaskToDropGdmModel(GdmModel gdmModel, String bizInfo) {
            gdmModelJob = SpringBeans.getBean(GdmModelJob.class);
            // Ignore the CL Job scheduling stuff, just go directly to the callback
            ClJobContext previousContext = ClJobContext.getClJobContext();
            HashMap<String, Object> map = new HashMap<String, Object>();
            map.put("modelName", gdmModel.getName());
            String jobParam = JsonUtils.instanceOfDto().obj2Json(map);
            ClJobContext clJobContext = new ClJobContext("B001", "J001", TenantContextHolder.getTenantIdExt(), jobParam, "jobLogFile", 1,1,1L);
            ClJobContext.setClJobContext(clJobContext);
            gdmModelJob.dropGdmModelDef();
            ClJobContext.setClJobContext(previousContext);
            return new BizJobRunResult();
        }

        @Override
        public BizJobRunResult startTaskToDropGdmFields(GdmEntity entity, List<String> fieldsToBeRemoved) {
            throw new UnsupportedOperationException("Not implemented");
        }
    }

    static class BizJobClientStub extends BizJobClient {
        public BizJobClientStub(BizJobService bizJobService, AsyncBizJobService asyncBizJobService) {
            super(bizJobService, asyncBizJobService);
        }

        @Override
        public String getBizJobNo(String jobType, String bizUuid) {
            throw new UnsupportedOperationException("Not implemented");
        }

        @Override
        public ReturnT<BizJob> createBizJob(JobData jobData) {
            throw new UnsupportedOperationException("Not implemented");
        }

        @Override
        public ReturnT<BizJobRunResult> createAndStartBizJob(JobData jobData) {
            throw new UnsupportedOperationException("Not implemented");
        }

        @Override
        public ReturnT<BizJobStatus> getLatestBizJobStatus(String jobNo) {
            throw new UnsupportedOperationException("Not implemented");
        }

        @Override
        public void updateBizJobStatus(ClJobContext clJobContext, String jobStatus) {
            if (jobStatus.equalsIgnoreCase(DataJobConstants.STATUS_FAIL))
                throw new RuntimeException("CL-JOB failed");
        }

        @Override
        public void updateBizJobStatus(ClJobContext clJobContext, UpdateJobStatusRequest request) {
            throw new UnsupportedOperationException("Not implemented");
        }

        @Override
        public void updateBizJobStatus(ClJobContext clJobContext, UpdateJobStatusRequest request, String jobStatus) {
            throw new UnsupportedOperationException("Not implemented");
        }

        @Override
        public void updateLatestBizJobStatus(String jobNo, String jobStatus) {
            throw new UnsupportedOperationException("Not implemented");
        }

        @Override
        public void updateLatestBizJobStatus(String jobNo, UpdateJobStatusRequest request) {
            throw new UnsupportedOperationException("Not implemented");
        }

        @Override
        public void updateLatestBizJobStatus(String jobNo, UpdateJobStatusRequest request, String jobStatus) {
            throw new UnsupportedOperationException("Not implemented");
        }

        @Override
        public ReturnT deleteJobAndDefaultJobGroup(String jobNo) {
            throw new UnsupportedOperationException("Not implemented");
        }

        @Override
        public ReturnT<String> submitSparkJob(String jobName, String jarName, Map<String, Object> data) {
            throw new UnsupportedOperationException("Not implemented");
        }

        @Override
        public ReturnT<String> submitSparkJob(String jobName, String jarName, Map<String, Object> data, String driverMemory, Integer driverCores, Integer replica) {
            throw new UnsupportedOperationException("Not implemented");
        }

        @Override
        public ReturnT<BizJobRunResult> createAndStartBizJobGroup(String groupType, MutableGraph<JobData> jobDataGraph) {
            throw new UnsupportedOperationException("Not implemented");
        }

        @Override
        public ReturnT<BizJobStatus> getLatestBizJobGroupStatus(String groupNo) {
            throw new UnsupportedOperationException("Not implemented");
        }
    }
}
