package com.convertlab.foundation.gdmmeta.service.impl;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Collections;
import java.util.Map;

import com.convertlab.foundation.gdmmeta.service.ConfigMetaProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.convertlab.foundation.gdmmeta.model.Entity;
import com.convertlab.foundation.gdmmeta.service.LayerServiceCheck;
import com.convertlab.foundation.gdmmeta.service.impl.loader.SystemMySQLEntityFieldsLoader;

@Tag("UnitTest")
@Tag("GdmMeta")
class SystemMySQLEntityFieldsLayerServiceTest implements LayerServiceCheck {

    SystemMySQLEntityFieldsLoader service;

    @BeforeEach
    void setUp() {
        DbMetaProviderImpl dbMetaService = getDefaultMockDbMetaService();
        ConfigMetaProviderImpl configMetaProvider = new ConfigMetaProviderImpl();
        dbMetaService.setLoadFromLocal(true, configMetaProvider.loadMySqlDatabaseStructure(), Collections.emptyList());
        service = new SystemMySQLEntityFieldsLoader(configMetaProvider, dbMetaService);
    }

    @Test
    void getEntityNames() {
         assertNotNull(service.getEntityNames());
    }

    @Test
    void loadEntity() {
        assertNull(service.loadEntity("not_existed"));
        assertNotNull(service.loadEntity("customer"));
        assertNotNull(service.loadEntity("tag"));
    }

    @Test
    void getEntities() {
        Map<String, Entity> entities = service.getEntities();
        for (Entity dbEntity : entities.values()) {
            checkEntityDbFields(dbEntity);
        }
    }
}
