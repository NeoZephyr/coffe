package com.convertlab.foundation.gdmmeta.service.impl;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Optional;
import java.util.function.BiPredicate;
import java.util.function.Function;

import com.convertlab.foundation.gdmmeta.model.metaobject.TenantExtendedEntityDef;
import org.junit.jupiter.api.Test;
import org.openjdk.jmh.annotations.Setup;

import com.convertlab.foundation.gdmmeta.model.Entity;
import com.convertlab.foundation.gdmmeta.model.Field;
import com.convertlab.foundation.gdmmeta.mybatis.service.impl.CustomerMetaServiceImpl;
import com.convertlab.foundation.gdmmeta.service.LayerServiceCheck;
import com.convertlab.foundation.gdmmeta.service.impl.loader.TenantCustomerFieldsLoader;
import com.convertlab.foundation.library.gdmmeta.model.ColumnType;
import com.convertlab.foundation.library.gdmmeta.model.FieldType;
import com.convertlab.foundation.library.multitenancy.context.TenantContextMutable;

class TenantCustomerEntityFieldsLayerServiceTest  implements TenantContextMutable, LayerServiceCheck {

    TenantCustomerFieldsLoader service;

    public TenantCustomerEntityFieldsLayerServiceTest() {
        ConfigMetaProviderImpl configMetaProvider = new ConfigMetaProviderImpl();
        CustomerMetaServiceImpl customerMetaService = this.getLocalCustomerMetaService(configMetaProvider);
        service = new TenantCustomerFieldsLoader(customerMetaService, configMetaProvider);
    }

    @Setup
    public void setup() {
        this.mutateTenantContext(1L);
    }
    @Test
    void getEntityNames() {
        assertTrue(service.getEntityNames().contains(TenantExtendedEntityDef.CUSTOMER.entityName));
        assertEquals(1, service.getEntityNames().size());
    }

    @Test
    void test_loadEntity() {
        Entity entity = service.loadEntity(TenantExtendedEntityDef.CUSTOMER.entityName);
        assertNotNull(entity);

        List<Field> fields = entity.getFields();
        BiPredicate<Field, String> fieldFilterByFieldName = (field, fieldName) -> field.getFieldName().equals(fieldName);
        Function<String, Field> getFieldByName = fieldName -> fields.stream().filter(
                field -> fieldFilterByFieldName.test(field, fieldName)).findAny().orElse(null);

        Field attr1Field = getFieldByName.apply("attr1");
        checkFieldInfo(false, "attr1", "attr1", FieldType.String, ColumnType.UNKNOWN, Optional.empty(), attr1Field);

        Field attr7Field = getFieldByName.apply("attr7");
        checkFieldInfo(false, "attr7", "attr7", FieldType.Date, ColumnType.UNKNOWN, Optional.empty(), attr7Field);

        Field attr15Field =  getFieldByName.apply("attr15");
        checkFieldInfo(false, "attr15", "attr15", FieldType.DateTime, ColumnType.UNKNOWN, Optional.empty(), attr15Field);

        Field attr16Field =  getFieldByName.apply("attr16");
        checkFieldInfo(false, "attr16", "attr16", FieldType.String, ColumnType.UNKNOWN, Optional.empty(), attr16Field);

        Field attr20Field =  getFieldByName.apply("attr20");
        checkFieldInfo(false, "attr20", "attr20", FieldType.Decimal, ColumnType.UNKNOWN, Optional.empty(), attr20Field);
    }
}
