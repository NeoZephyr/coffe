package com.convertlab.foundation.gdmmeta.microbenchmark;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.junit.jupiter.api.Disabled;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.results.RunResult;
import org.openjdk.jmh.runner.Runner;
import org.openjdk.jmh.runner.RunnerException;
import org.openjdk.jmh.runner.options.Options;
import org.openjdk.jmh.runner.options.OptionsBuilder;

import com.convertlab.foundation.gdmmeta.model.Entity;

/**
 * meta service 中遍历 ArrayList 查找 Item 的操作较多，对比从
 * ArrayList 中遍历查找 Item 和构造 HashMap 查找的性能.
 * 特别是随着元素数量的增加，性能的表现。
 *
 Benchmark                                         (ENTITY_SIZE)   Mode  Cnt    Score     Error   Units
 FindingItemBenchmarkTest.findEntityInListForeach             50  thrpt    4   10.315 ±   1.834  ops/us
 FindingItemBenchmarkTest.findEntityInListForeach            100  thrpt    4    4.990 ±   1.133  ops/us
 FindingItemBenchmarkTest.findEntityInListForeach           1000  thrpt    4    0.422 ±   0.090  ops/us
 FindingItemBenchmarkTest.findEntityInListForeach          10000  thrpt    4    0.054 ±   0.004  ops/us
 FindingItemBenchmarkTest.findEntityInListStream              50  thrpt    4    7.775 ±   0.647  ops/us
 FindingItemBenchmarkTest.findEntityInListStream             100  thrpt    4    3.908 ±   1.741  ops/us
 FindingItemBenchmarkTest.findEntityInListStream            1000  thrpt    4    0.365 ±   0.432  ops/us
 FindingItemBenchmarkTest.findEntityInListStream           10000  thrpt    4    0.050 ±   0.047  ops/us
 FindingItemBenchmarkTest.findEntityInMap                     50  thrpt    4  353.423 ± 415.157  ops/us
 FindingItemBenchmarkTest.findEntityInMap                    100  thrpt    4  313.039 ± 250.955  ops/us
 FindingItemBenchmarkTest.findEntityInMap                   1000  thrpt    4  323.119 ± 183.150  ops/us
 FindingItemBenchmarkTest.findEntityInMap                  10000  thrpt    4  318.326 ± 349.247  ops/us
 FindingItemBenchmarkTest.findEntityInListForeach             50   avgt    4    0.932 ±   0.690   us/op
 FindingItemBenchmarkTest.findEntityInListForeach            100   avgt    4    1.756 ±   0.320   us/op
 FindingItemBenchmarkTest.findEntityInListForeach           1000   avgt    4   19.974 ±   3.261   us/op
 FindingItemBenchmarkTest.findEntityInListForeach          10000   avgt    4  163.199 ±  93.815   us/op
 FindingItemBenchmarkTest.findEntityInListStream              50   avgt    4    1.101 ±   0.527   us/op
 FindingItemBenchmarkTest.findEntityInListStream             100   avgt    4    2.725 ±   5.336   us/op
 FindingItemBenchmarkTest.findEntityInListStream            1000   avgt    4   21.097 ±   4.883   us/op
 FindingItemBenchmarkTest.findEntityInListStream           10000   avgt    4  166.257 ±  13.288   us/op
 FindingItemBenchmarkTest.findEntityInMap                     50   avgt    4    0.023 ±   0.021   us/op
 FindingItemBenchmarkTest.findEntityInMap                    100   avgt    4    0.024 ±   0.021   us/op
 FindingItemBenchmarkTest.findEntityInMap                   1000   avgt    4    0.026 ±   0.002   us/op
 FindingItemBenchmarkTest.findEntityInMap                  10000   avgt    4    0.029 ±   0.036   us/op
 *
 * 设计 ArrayList item 的数量在 50/100/1000/10000 总量的情况下，
 * 查找 ArrayList 最后一个元素(也就是完全遍历 ArrayList)和对比 HashMap查找的性能对比。
 *
 */

@BenchmarkMode({Mode.AverageTime, Mode.Throughput})
@Warmup(iterations = 1)
@Measurement(iterations = 2, time = 1)
@OutputTimeUnit(TimeUnit.MICROSECONDS)
@Fork(value = 2)
@Threads(8)
@State(Scope.Benchmark)
@OperationsPerInvocation
@Disabled("Benchmark test, not a unit test.")
public class FindingItemBenchmarkTest {

    List<Entity> genEntityList(int entitySize) {
        return IntStream.range(0, entitySize).mapToObj(idx ->
                Entity.builder().
                        entityName("entityName" + idx).
                        dbTableName("dbTableName" + idx).
                        fields(Collections.emptyList()).dbView(false).build()
        ).collect(Collectors.toList());
    }

    Map<String, Entity> genEntityMap(int entitySize) {
        List<Entity> entities = genEntityList(entitySize);
        return entities.stream().collect(Collectors.toMap(Entity::getEntityName, Function.identity()));
    }

    private List<Entity> entities;
    private Map<String, Entity> entityMap;
    private String entityName ;

    @Param({"50", "100", "1000", "10000"})
    private int ENTITY_SIZE;

    @Setup
    public void setup() {
        entities = genEntityList(ENTITY_SIZE);
        entityMap = genEntityMap(ENTITY_SIZE);
        entityName = "entityName" + (ENTITY_SIZE - 1);
    }

    @Benchmark
    public Entity findEntityInListForeach() {
        for(Entity entity: entities) {
            if(entity.getEntityName().equals(entityName)) {
                return entity;
            }

        }
        return null;
    }

    @Benchmark
    public Entity findEntityInListStream() {
        Optional<Entity> any = entities.stream().filter(entity -> entity.getEntityName().equals(entityName)).findAny();
        return any.orElse(null);
    }

    @Benchmark
    public Entity findEntityInMap() {
        return entityMap.getOrDefault(entityName, null);
    }

   public static void __main(String[] args) {
       Options opt = new OptionsBuilder()
                .include(FindingItemBenchmarkTest.class.getSimpleName())
                .build();
       try{
           Collection<RunResult> run = new Runner(opt).run();
       } catch (RunnerException exception) {

       }
    }

}
