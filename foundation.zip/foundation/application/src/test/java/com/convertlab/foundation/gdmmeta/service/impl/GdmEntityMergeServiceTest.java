package com.convertlab.foundation.gdmmeta.service.impl;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.*;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.convertlab.foundation.gdmmeta.model.metaobject.TenantExtendedEntityDef;
import com.convertlab.foundation.gdmmeta.mybatis.service.UdoMetaService;
import com.convertlab.foundation.gdmmeta.service.GdmEntityMetaService;
import com.convertlab.foundation.gdmmeta.service.GdmTableMetaService;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.collect.ImmutableSet;
import org.junit.jupiter.api.*;

import com.convertlab.foundation.gdmmeta.model.Entity;
import com.convertlab.foundation.gdmmeta.model.Field;
import com.convertlab.foundation.gdmmeta.mybatis.service.impl.CustomerMetaServiceImpl;
import com.convertlab.foundation.gdmmeta.mybatis.service.impl.MembershipMetaServiceImpl;
import com.convertlab.foundation.gdmmeta.mybatis.service.impl.UdoMetaServiceImpl;
import com.convertlab.foundation.gdmmeta.service.LayerServiceCheck;
import com.convertlab.foundation.gdmmeta.service.impl.loader.*;
import com.convertlab.foundation.library.gdmmeta.client.GdmMetaApi;

import lombok.extern.slf4j.Slf4j;
import org.mockito.Mockito;
import org.springframework.util.CollectionUtils;

@Slf4j
@Tag("UnitTest")
@Tag("GdmMeta")
class GdmEntityMergeServiceTest implements LayerServiceCheck {

    TenantUdoEntityLoader tenantUdoEntityLoader;
    GdmEntityMergeService mergeService;
    UdoMetaService udoMetaService;
    InitialRegisterEntityLoader initialRegisterEntityLoader;
    TenantCustomerEventEntityLoader tenantCustomerEventEntityLoader;

    @BeforeEach
    public void setUp() {
        DbMetaProviderImpl dbMetaService = getDefaultMockDbMetaService();
        ConfigMetaProviderImpl configMetaProvider = new ConfigMetaProviderImpl();
        List<Entity> oltpEntities = configMetaProvider.loadMySqlDatabaseStructure();
        List<Entity> olapEntities = configMetaProvider.loadImpalaDatabaseStructure();
        dbMetaService.setLoadFromLocal(true, oltpEntities, olapEntities);

        initialRegisterEntityLoader = new InitialRegisterEntityLoader(configMetaProvider);
        SystemCustomerEventEntityLoader systemCustomerEventEntityLoader = new SystemCustomerEventEntityLoader(configMetaProvider);

        CustomerMetaServiceImpl customerMetaService = getLocalCustomerMetaService(configMetaProvider);
        tenantCustomerEventEntityLoader = new TenantCustomerEventEntityLoader(configMetaProvider, customerMetaService);

        udoMetaService = Mockito.mock(UdoMetaService.class);
        tenantUdoEntityLoader = new TenantUdoEntityLoader(udoMetaService);
        TenantUdoEventEntityLoader tenantUdoEventEntityLoader = new TenantUdoEventEntityLoader(udoMetaService, configMetaProvider);

        SystemMySQLEntityFieldsLoader systemMySQLEntityFieldsLoader = new SystemMySQLEntityFieldsLoader(configMetaProvider, dbMetaService);
        SystemImpalaEntityFieldsLoader systemImpalaEntityFieldsLoader = new SystemImpalaEntityFieldsLoader(configMetaProvider, dbMetaService);
        SystemCustomerEntityLoader systemCustomerEntityLoader = new SystemCustomerEntityLoader(configMetaProvider);

        TenantMysqlEntityFieldsLoader tenantMysqlEntityFieldsLoader = new TenantMysqlEntityFieldsLoader(configMetaProvider, dbMetaService, udoMetaService);
        TenantImpalaEntityFieldsLoader tenantImpalaEntityFieldsLoader = new TenantImpalaEntityFieldsLoader(configMetaProvider, dbMetaService, udoMetaService);


        TenantCustomerFieldsLoader tenantCustomerFieldsLoader = new TenantCustomerFieldsLoader(customerMetaService, configMetaProvider);

        SystemCustomerEventFieldsLoader systemCustomerEventFieldsLoader = new SystemCustomerEventFieldsLoader(configMetaProvider);
        TenantCustomerEventFieldsLoader tenantCustomerEventFieldsLoader = new TenantCustomerEventFieldsLoader(customerMetaService, configMetaProvider);
        TenantUdoFieldsLoader tenantUdoFieldsLoader = new TenantUdoFieldsLoader(udoMetaService);
        TenantUdoEventFieldsLoader tenantUdoEventFieldsLoader = new TenantUdoEventFieldsLoader(udoMetaService, configMetaProvider);
        SystemParentCustomerEventFieldsLoader systemParentCustomerEventFieldsLoader = new SystemParentCustomerEventFieldsLoader(customerMetaService, configMetaProvider);

        MembershipMetaServiceImpl membershipMetaService = getLocalMembershipMetaService(configMetaProvider);
        SystemMembershipFieldsLoader systemMembershipFieldsLoader = new SystemMembershipFieldsLoader(configMetaProvider);
        TenantMembershipFieldsLoader tenantMembershipFieldsLoader = new TenantMembershipFieldsLoader(configMetaProvider, membershipMetaService);

        SystemFullOrderFieldsLoader systemFullOrderFieldsLoader = new SystemFullOrderFieldsLoader(configMetaProvider);
        TenantFullOrderFieldsLoader tenantFullOrderFieldsLoader = new TenantFullOrderFieldsLoader(configMetaProvider, customerMetaService);
        SystemCustomerStatisticsFieldsLoader systemCustomerStatisticsFieldsLoader = new SystemCustomerStatisticsFieldsLoader(configMetaProvider);
        GdmEntityMetaService gdmEntityMetaService = new GdmEntityMetaServiceImpl(null, null, null);
        GdmTableMetaService gdmTableMetaService = new GdmTableMetaServiceImpl(null, null);


        mergeService = new GdmEntityMergeService(configMetaProvider, initialRegisterEntityLoader,
                systemCustomerEventEntityLoader, tenantCustomerEventEntityLoader,
                tenantUdoEntityLoader, tenantUdoEventEntityLoader,
                systemMySQLEntityFieldsLoader, systemImpalaEntityFieldsLoader,
                tenantMysqlEntityFieldsLoader, tenantImpalaEntityFieldsLoader,
                systemCustomerEntityLoader, tenantCustomerFieldsLoader,
                systemCustomerEventFieldsLoader, tenantCustomerEventFieldsLoader,
                tenantUdoFieldsLoader, tenantUdoEventFieldsLoader, systemParentCustomerEventFieldsLoader,
                systemMembershipFieldsLoader, tenantMembershipFieldsLoader,
                systemFullOrderFieldsLoader, tenantFullOrderFieldsLoader,
                systemCustomerStatisticsFieldsLoader,
                gdmEntityMetaService, gdmTableMetaService);
    }


    @Test
    void test_loadSystemEventEntityAndMerge() {
        String customerEntityName = "customer";
        // load customer register entity and check
        Entity entity = initialRegisterEntityLoader.loadEntity(customerEntityName);
        log.info("initial, base entity: {}", entity);
        registeredCustomerEntityCheck(entity);
        assertEquals(0,  entity.getFields().size());

        //load customer event register entity and check
        String customerEventEntityName = "customer_event";
        Entity eventEntity = initialRegisterEntityLoader.loadEntity(customerEventEntityName);
        log.info("initial, base event entity: {}", eventEntity);
        registeredCustomerEventEntityCheck(eventEntity);
        assertEquals(0,  entity.getFields().size());

        //load system customer event entity(openPage) and check
        String openPageEventEntity = "open_page";
        Entity openPageRegisterEntity = initialRegisterEntityLoader.loadEntity(openPageEventEntity);
        log.info("initial, base openPage event entity: {}", openPageRegisterEntity);
        if (openPageRegisterEntity == null) {
            openPageRegisterEntity = Entity.builder().entityName(openPageEventEntity).fields(new ArrayList<>()).build();
        }
        mergeService.loadSystemEventEntityAndMerge(openPageEventEntity, openPageRegisterEntity);
        registeredOpenPageEventEntityCheck(openPageRegisterEntity);
        assertEquals(0,  entity.getFields().size());

        String tenantDefinedEvent = "c_evil_noprop";
        Entity tenantDefinedEventEntity = Entity.builder().entityName(tenantDefinedEvent).fields(new ArrayList<>()).build();
        mergeService.loadSystemEventEntityAndMerge(tenantDefinedEvent, tenantDefinedEventEntity);
        assertNotNull(tenantDefinedEventEntity);

    }

    // below test GdmEntityMergeService.loadTenantEventEntityAndMerge
    @Test
    void test_loadTenantEventEntityAndMerge() {
        //load tenant customer event entity(openPage) and check
        String tenantDefinedEvent = "c_evil_noprop";
        Entity tenantOpenPageRegisterEntity = initialRegisterEntityLoader.loadEntity(tenantDefinedEvent);
        log.info("initial, base tenantDefinedEvent event entity: {}", tenantOpenPageRegisterEntity);
        if (tenantOpenPageRegisterEntity == null) {
            tenantOpenPageRegisterEntity = Entity.builder().entityName(tenantDefinedEvent).fields(Collections.emptyList()).build();
        }
        mergeService.loadSystemEventEntityAndMerge(tenantDefinedEvent, tenantOpenPageRegisterEntity);
        log.info("initial, base tenantDefinedEvent event entity: {}", tenantOpenPageRegisterEntity);

        mergeService.loadTenantEventEntityAndMerge(tenantDefinedEvent, tenantOpenPageRegisterEntity);
        registeredTenantDefinedEventEntityCheck(tenantOpenPageRegisterEntity);
        assertEquals(0,  tenantOpenPageRegisterEntity.getFields().size());
//        assertTrue(tenantOpenPageRegisterEntity.getFields().stream().filter(field -> field.getFieldName().equals("eventGroup")).findAny().isPresent());
    }

    @Test
    void test_loadMySqlEntityFieldsAndMerge() {
        String customerEntityName = "customer";
        // load customer register customerEntity and check
        Entity customerEntity = initialRegisterEntityLoader.loadEntity(customerEntityName);
        log.info("initial, base customerEntity: {}", customerEntity);
        registeredCustomerEntityCheck(customerEntity);
        List<Field> fields = customerEntity.getFields();
        assertEquals(0,  fields.size());
        mergeService.loadSystemCustomerFieldsAndMerge(customerEntityName, customerEntity);
        //load mysql customer customerEntity fields and check
        mergeService.loadMySqlEntityFieldsAndMerge(customerEntityName, customerEntity);
        log.info("after load mysql customer customerEntity, customerEntity: {}", customerEntity);
        fields = customerEntity.getFields();
        assertTrue( fields.size() > 0);

        //load customerEvent register customerEntity and check
        String customerEventEntityName = "customer_event";
        Entity eventEntity = initialRegisterEntityLoader.loadEntity(customerEventEntityName);
        log.info("initial, base event customerEntity: {}", eventEntity);
        registeredCustomerEventEntityCheck(eventEntity);
        assertEquals(0,  eventEntity.getFields().size());

        //load mysql customerEvent customerEntity fields and check
        mergeService.loadMySqlEntityFieldsAndMerge(customerEventEntityName, eventEntity);
        log.info("after load mysql customerEvent customerEntity, customerEntity: {}", eventEntity);
        assertEquals(0, eventEntity.getFields().size());
    }

    @Test
    void test_loadImpalaEntityFieldsAndMerge_customer() {
        String customerEntityName = "customer";
        // load customer register customerEntity and check
        Entity customerEntity = initialRegisterEntityLoader.loadEntity(customerEntityName);
        log.info("initial, base customerEntity: {}", customerEntity);
        registeredCustomerEntityCheck(customerEntity);
        assertEquals(0,  customerEntity.getFields().size());

        mergeService.loadSystemCustomerFieldsAndMerge(customerEntityName, customerEntity);
        mergeService.loadTenantCustomerFieldsAndMerge(customerEntityName, customerEntity);

        //load impala customer customerEntity fields and check
        mergeService.loadImpalaEntityFieldsAndMerge(customerEntityName, customerEntity);
        log.info("after load impala customerEntity, customerEntity: {}", customerEntity);
        int impalaFieldSize = customerEntity.getFields().size();
        List<Field> fields = customerEntity.getFields();
        checkImpalaCustomerEntityFieldsAfterMetaLayer(fields);

        mergeService.loadMySqlEntityFieldsAndMerge(customerEntityName, customerEntity);
        log.info("after load mysql customerEntity, customerEntity: {}", customerEntity);
        registeredCustomerEntityCheck(customerEntity);
        int mysqlFieldSize = customerEntity.getFields().size();
        assertTrue ( mysqlFieldSize > 1);

//        assertEquals(mysqlFieldSize, impalaFieldSize);
        fields = customerEntity.getFields();
        checkMysqlSystemCustomerEntityFields(fields);
    }

    private void checkImpalaCustomerEntityFieldsAfterMetaLayer(List<Field> fields) {
        BiPredicate<Field, String> fieldFilterByColumnName = (field, columnName) -> field.getDbColumnName().equals(columnName);

        getFieldAndCheck(fields, fieldFilterByColumnName,"id", this::impalaCustomerIdFieldCheck);
        getFieldAndCheck(fields, fieldFilterByColumnName,"attr1", this::impalaCustomerAttr1FieldCheck);
        getFieldAndCheck(fields, fieldFilterByColumnName,"birthday", this::impalaCustomerBirthdayFieldCheck);
        getFieldAndCheck(fields, fieldFilterByColumnName,"gender", this::impalaCustomerGenderFieldCheck);
        getFieldAndCheck(fields, fieldFilterByColumnName,"is_member", this::impalaCustomerIsMemberFieldCheck);
        getFieldAndCheck(fields, fieldFilterByColumnName,"date_created", this::impalaCustomerDateCreatedFieldCheck);
    }

    private void checkMysqlSystemCustomerEntityFields(List<Field> fields) {
        BiPredicate<Field, String> fieldFilterByColumnName = (field, columnName) -> field.getDbColumnName().equals(columnName);
        getFieldAndCheck(fields, fieldFilterByColumnName,"id", this::mysqlCustomerIdFieldCheck);
        getFieldAndCheck(fields, fieldFilterByColumnName,"birthday", this::mysqlCustomerBirthdayFieldCheck);
        getFieldAndCheck(fields, fieldFilterByColumnName,"gender", this::mysqlCustomerGenderFieldCheck);
        getFieldAndCheck(fields, fieldFilterByColumnName,"is_member", this::mysqlCustomerIsMemberFieldCheck);
        getFieldAndCheck(fields, fieldFilterByColumnName,"date_created", this::mysqlCustomerDateCreatedFieldCheck);

        Optional<Field> version = fields.stream().filter(field -> fieldFilterByColumnName.test(field, "version")).findFirst();
        assertFalse(version.isPresent());
    }

    private void checkMysqlTenantCustomerEntityFields(List<Field> fields) {
        BiPredicate<Field, String> fieldFilterByColumnName = (field, columnName) -> field.getDbColumnName().equals(columnName);
        getFieldAndCheck(fields, fieldFilterByColumnName,"id", this::mysqlCustomerIdFieldCheck);
        getFieldAndCheck(fields, fieldFilterByColumnName,"attr1", this::mysqlCustomerAttr1FieldCheck);
        getFieldAndCheck(fields, fieldFilterByColumnName,"birthday", this::mysqlCustomerBirthdayFieldCheck);
        getFieldAndCheck(fields, fieldFilterByColumnName,"gender", this::mysqlCustomerGenderFieldCheck);
        getFieldAndCheck(fields, fieldFilterByColumnName,"is_member", this::mysqlCustomerIsMemberFieldCheck);
        getFieldAndCheck(fields, fieldFilterByColumnName,"date_created", this::mysqlCustomerDateCreatedFieldCheck);

        Optional<Field> version = fields.stream().filter(field -> fieldFilterByColumnName.test(field, "version")).findFirst();
        assertFalse(version.isPresent());
    }


    @Test
    void test_loadImpalaEntityFieldsAndMerge_customerEvent() {
        String customerEntityName = "customer_event";
        // load customer register customerEventEntity and check
        Entity customerEventEntity = initialRegisterEntityLoader.loadEntity(customerEntityName);
        log.info("initial, base customerEventEntity: {}", customerEventEntity);
        registeredCustomerEventEntityCheck(customerEventEntity);
        assertEquals(0,  customerEventEntity.getFields().size());

        //load mysql customer customerEventEntity fields and check
        mergeService.loadImpalaEntityFieldsAndMerge(customerEntityName, customerEventEntity);
        log.info("after load impala customerEventEntity, customerEventEntity: {}", customerEventEntity);
        assertTrue( customerEventEntity.getFields().size() > 1);
//        Optional<Field> eventFieldOpt = getFieldOptByColumnName(customerEventEntity.getFields(), "event");

        mergeService.loadMySqlEntityFieldsAndMerge(customerEntityName, customerEventEntity);
        log.info("after load mysql customerEventEntity, customerEventEntity: {}", customerEventEntity);
        registeredCustomerEventEntityCheck(customerEventEntity);
        assertTrue( customerEventEntity.getFields().size() > 1);
    }

    @Test
    void test_loadImpalaEntityFieldsAndMerge_openPage() {
        String customerEntityName = "open_page";
        // load customer register customerEventEntity and check
        Entity openPageEntity = initialRegisterEntityLoader.loadEntity(customerEntityName);
        assertNull(openPageEntity);

        openPageEntity = Entity.builder().entityName(customerEntityName).fields(new ArrayList<>()).build();
        mergeService.loadSystemEventEntityAndMerge(customerEntityName, openPageEntity);
        checkRegisteredGdmEntity(openPageEntity);

        //load mysql customer customerEventEntity fields and check
        mergeService.loadImpalaEntityFieldsAndMerge(customerEntityName, openPageEntity);
        log.info("after load impala openPageEntity, openPageEntity: {}", openPageEntity);
        assertTrue( openPageEntity.getFields().size() > 1);
        assertEquals(customerEntityName, openPageEntity.getEntityName());

    }


    @Test
    void test_loadSystemCustomerFieldsAndMerge() {
        String customerEntityName = "customer";
        // load customer register customerEntity and check
        Entity customerEntity = initialRegisterEntityLoader.loadEntity(customerEntityName);
        log.info("initial, base customerEntity: {}", customerEntity);
        registeredCustomerEntityCheck(customerEntity);
        assertEquals(0,  customerEntity.getFields().size());

        mergeService.loadSystemCustomerFieldsAndMerge(customerEntityName, customerEntity);
        log.info("after load mysql customerEntity, customerEntity: {}", customerEntity);

        List<Field> systemCustomerFields = customerEntity.getFields();
        int systemEntityFieldSize = systemCustomerFields.size();

        //load mysql customer customerEntity fields and check
        mergeService.loadMySqlEntityFieldsAndMerge(customerEntityName, customerEntity);
        log.info("after load mysql customerEntity, customerEntity: {}", customerEntity);
        List<Field> fields = customerEntity.getFields();
        int mysqlEntityFieldSize = fields.size();
        checkMysqlSystemCustomerEntityFields(fields);
        List<Field> mysqlFields = fields.stream().map(Field::new).collect(Collectors.toList());

        assertEquals(mysqlEntityFieldSize, systemEntityFieldSize);
        checkMysqlSystemCustomerEntityFields(systemCustomerFields);

        compareTenantCustomerFields(mysqlFields, systemCustomerFields);

    }

    @Test
    void test_loadTenantCustomerFieldsAndMerge() {
        String customerEntityName = "customer";
        // load customer register customerEntity and check
        Entity customerEntity = initialRegisterEntityLoader.loadEntity(customerEntityName);
        log.info("initial, base customerEntity: {}", customerEntity);
        registeredCustomerEntityCheck(customerEntity);
        assertEquals(0,  customerEntity.getFields().size());

        mergeService.loadSystemCustomerFieldsAndMerge(customerEntityName, customerEntity);
        log.info("after load mysql customerEntity, customerEntity: {}", customerEntity);
        int systemEntityFieldSize = customerEntity.getFields().size();

        mergeService.loadTenantCustomerFieldsAndMerge(customerEntityName, customerEntity);
        int tenantEntityFieldSize = customerEntity.getFields().size();

        assertTrue(tenantEntityFieldSize > systemEntityFieldSize);

        //load mysql customer customerEntity fields and check
        mergeService.loadMySqlEntityFieldsAndMerge(customerEntityName, customerEntity);
        log.info("after load mysql customerEntity, customerEntity: {}", customerEntity);
        List<Field> fields = customerEntity.getFields();
        int mysqlEntityFieldSize = fields.size();
        checkMysqlTenantCustomerEntityFields(fields);

        assertEquals(mysqlEntityFieldSize, tenantEntityFieldSize);

    }

        private void compareTenantCustomerFields(List<Field> mysqlFields, List<Field> systemCustomerFields) {
        BiPredicate<Field, String> fieldFilterByFieldName = (field, fieldName) -> field.getFieldName().equals(fieldName);
        Function<Field, Optional<Field>> getSystemFieldOpt = mysqlField ->
                systemCustomerFields.stream().filter(
                        systemField -> systemField.getFieldName().equals(mysqlField.getFieldName())).findAny();

        for (Field mysqlField : mysqlFields) {
            Optional<Field> systemFieldOpt = getSystemFieldOpt.apply(mysqlField);
            assertTrue(systemFieldOpt.isPresent());
            Field systemField = systemFieldOpt.get();
            assertEquals(mysqlField.getDbColumnName(), systemField.getDbColumnName());
            assertEquals(mysqlField.getDbColumnType(), systemField.getDbColumnType());
            assertEquals(mysqlField.getFieldType(), systemField.getFieldType(), "field: " + systemField);
            assertEquals(mysqlField.getFieldAlias(), systemField.getFieldAlias());
        }
    }


    @Tag("UnitTest")
    @Tag("GdmMeta")
    @Test
    void test_mergeAndGetEntity_customer() {
        Entity entity = mergeService.getEntity("customer", GdmMetaApi.META_TYPE.MYSQL);

        registeredCustomerEntityCheck(entity);

        List<Field> fields = entity.getFields();

        BiPredicate<Field, String> fieldChecker = (field, columnName) -> field.getDbColumnName().equals(columnName);

        getFieldAndCheck(fields, fieldChecker, "id", this::finalCustomerIdFieldCheck);
        getFieldAndCheck(fields, fieldChecker, "attr1", this::finalCustomerAttr1FieldCheck);
    }

    @Tag("UnitTest")
    @Tag("GdmMeta")
    @Test
    void test_getAllEntitiesWithFields_no_duplicated_fields() {
        List<Entity> entities = mergeService.getAllEntitiesWithFields(GdmMetaApi.META_TYPE.IMPALA);
        entities.forEach( entity -> {
            List<Field> fields = entity.getFields();
            fields.stream().collect(Collectors.groupingBy(Field::getFieldName)).forEach((fieldName, fieldList) -> {
                if (fieldList.size() > 1) {
                    List<String> columns = fieldList.stream().map(Field::getDbColumnName).collect(Collectors.toList());
                    String errorMessage = String.format("duplicated fields in entity: %s, field: %s, columns: %s", entity.getEntityName(), fieldName, columns);
                    log.warn(errorMessage);
                    fail(errorMessage);
                }
            });
        });
    }

    public Entity getExpectedEntity(String entityName) {
        Entity entity = loadSystemEntities().get(entityName);
        //log.debug("the entity" + entityName + " is " + entity);
        assertNotNull(entity);
        return entity;
    }

    /**
     * 系统注册Entity对比基准数据文件 /gdm/gdm-meta/src/test/resources/system_entities.json
     *
     */
    @Tag("UnitTest")
    @Tag("GdmMeta")
    @Test
    void test_all_entities() {
        Set<String> entityNames = loadSystemEntities().keySet();
        checkEntitiesAndFields(entityNames);
    }

    private void checkEntitiesAndFields(Set<String> entityNames) {
        List<Entity> expectedList = new ArrayList<>();
        List<Entity> actualList = new ArrayList<>();
        entityNames.forEach(entityName -> {
            preCompareSingleEntity(expectedList, actualList, entityName);
        });

        for (int i = 0; i < expectedList.size(); i++) {
            assertEquals(expectedList.get(i), actualList.get(i));
        }
    }


    private void preCompareSingleEntity(List<Entity> expectedList, List<Entity> actualList, String entityName) {
        Entity expectedEntity = getExpectedEntity(entityName);
        Entity actualEntity = mergeService.getEntity(entityName);

        if (ImmutableSet.of("not_exist").contains(entityName)) {
            List<Field> filtedFields = actualEntity.getFields().stream().filter(e -> !e.gdmField().getFieldName().equals("version")).collect(Collectors.toList());
            actualEntity.setFields(filtedFields);
        }

        // 避开因为field顺序不同导致的不一致，先排序
        if (!CollectionUtils.isEmpty(expectedEntity.getFields()) && !CollectionUtils.isEmpty(actualEntity.getFields())) {
            Map<String, Field> actualFieldMap = actualEntity.getFields().stream().collect(Collectors.toMap(Field::getFieldName, f -> f, (f1, f2) -> {
                log.error("duplicate field name: {} in actual entity {}", f1.getFieldName(), entityName);
                return f1;}));
            Map<String, Field> expectedFieldMap = expectedEntity.getFields().stream().collect(Collectors.toMap(Field::getFieldName, f -> f, (f1, f2) -> {
                log.error("duplicate field name: {} in expected entity {}", f1.getFieldName(), entityName);
                return f1;}));

            List<Field> newAdded = actualEntity.getFields().stream().filter(af -> !expectedFieldMap.containsKey(af.getFieldName())).collect(Collectors.toList());
            String as = JsonUtils.instance().obj2Json(newAdded);

            List<Field> toBeDeleted = expectedEntity.getFields().stream().filter(ef -> !actualFieldMap.containsKey(ef.getFieldName())).collect(Collectors.toList());
            String ds = JsonUtils.instance().obj2Json(toBeDeleted);
            if (newAdded.size() > 0 || toBeDeleted.size() > 0) {
                log.info("For {} new Added Fields: \n {}", entityName, as);
                log.info("For {} to be deleted Fields: \n {}", entityName, ds);
            }

            Comparator<Field> byName = Comparator.comparing(Field::getFieldName);
            expectedEntity.getFields().sort(byName);
            actualEntity.getFields().sort(byName);
        }
        expectedList.add(expectedEntity);
        actualList.add(actualEntity);
    }

    Map<String, Entity> loadSystemEntities() {
        ConfigMetaProviderImpl configMetaProvider = new ConfigMetaProviderImpl();
        final String entityFile = "/meta/expected/system_entities.json5";
        URL resource = getClass().getResource(entityFile);
        if (resource != null) {
            try(InputStream is = resource.openStream()) {
                TypeReference<List<Entity>> valueTypeRef = new TypeReference<List<Entity>>() {};
                List<Entity> entities = configMetaProvider.loadLocalMetaObject(entityFile, valueTypeRef);
                entities.forEach(entity -> {
                            entity.setIsSystem(true);
                            entity.setDeletable(false);
                            entity.setModifiable(TenantExtendedEntityDef.getEntityNames().contains(entity.getEntityName()));
                        }
                );
                Map<String, Entity> collect = entities.stream().collect(Collectors.toMap(Entity::getEntityName, Function.identity()));
                return collect;
            } catch (IOException e) {
                throw new IllegalStateException("Failed to load system entities from " + entityFile, e);
            }
        } else {
            throw new IllegalStateException("Failed to load system entities from " + entityFile);
        }
    }

}
