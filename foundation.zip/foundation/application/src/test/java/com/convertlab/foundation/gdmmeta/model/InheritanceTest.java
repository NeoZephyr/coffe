package com.convertlab.foundation.gdmmeta.model;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

@Tag("UnitTest")
@Tag("GdmMeta")
class InheritanceTest {

    @Test
    void replaceOrAddIfNotNull() {
        Inheritance base = Inheritance.builder().isSubtype(true).identifierField("id").identifierValue("1").build();
        Inheritance overlay = Inheritance.builder().isSubtype(false).identifierField("id").identifierValue("2").build();

        GdmObjectMerger gdmObjectMerger = GdmObjectMerger.build(GdmObjectMerger.EntityMergeStrategies.ADD_NOT_EXISTED_FIELDS,
                GdmObjectMerger.FieldMergeStrategies.BY_ID, CustomMergeStrategiesForTest.INHERITANCE);

        Inheritance merged = gdmObjectMerger.merge(base, overlay);
        assertEquals(false, merged.getIsSubtype());
        assertEquals("id", merged.getIdentifierField());
        assertEquals("2", merged.getIdentifierValue());
    }

    @Test
    void unsetIfNotNull() {
        Inheritance base = Inheritance.builder().isSubtype(true).identifierField("id").identifierValue("1").build();
        Inheritance overlay = Inheritance.builder().isSubtype(false).identifierField("id").identifierValue("2").build();
        GdmObjectMerger gdmObjectMerger = GdmObjectMerger.build(GdmObjectMerger.EntityMergeStrategies.ADD_NOT_EXISTED_FIELDS,
                GdmObjectMerger.FieldMergeStrategies.BY_ID, CustomMergeStrategiesForTest.INHERITANCE_CUSTOMER);
        Inheritance merged = gdmObjectMerger.merge(base, overlay);
        assertEquals(null, merged.getIsSubtype());
        assertEquals(null, merged.getIdentifierField());
        assertEquals(null, merged.getIdentifierValue());
    }
}
