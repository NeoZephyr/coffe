package com.convertlab.foundation.gdmmeta.service.impl;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Optional;
import java.util.function.BiPredicate;
import java.util.function.Function;

import com.convertlab.foundation.gdmmeta.model.metaobject.TenantExtendedEntityDef;
import com.convertlab.foundation.gdmmeta.service.ConfigMetaProvider;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.convertlab.foundation.gdmmeta.model.Entity;
import com.convertlab.foundation.gdmmeta.model.Field;
import com.convertlab.foundation.gdmmeta.service.LayerServiceCheck;
import com.convertlab.foundation.gdmmeta.service.impl.loader.SystemCustomerEntityLoader;
import com.convertlab.foundation.library.gdmmeta.model.ColumnType;
import com.convertlab.foundation.library.gdmmeta.model.FieldType;

@Tag("UnitTest")
@Tag("GdmMeta")
class SystemCustomerEntityLayerServiceTest implements LayerServiceCheck {

    SystemCustomerEntityLoader service;

    public SystemCustomerEntityLayerServiceTest() {
        ConfigMetaProvider configMetaProvider = new ConfigMetaProviderImpl();
        service = new SystemCustomerEntityLoader(configMetaProvider);
    }

    @Test
    void getEntityNames() {
        assertTrue(service.getEntityNames().contains(TenantExtendedEntityDef.CUSTOMER.entityName));
        assertEquals(1, service.getEntityNames().size());
    }

    @Test
    void test_loadEntity() {
        Entity entity = service.loadEntity(TenantExtendedEntityDef.CUSTOMER.entityName);
        assertNotNull(entity);
        List<Field> fields = entity.getFields();
        BiPredicate<Field, String> fieldFilterByFieldName = (field, fieldName) -> field.getFieldName().equals(fieldName);
        Function<String, Field> fieldGetterByFieldName = fieldName -> fields.stream().filter(
                field -> fieldFilterByFieldName.test(field, fieldName)).findAny().orElse(null);

        Field idStrField = fieldGetterByFieldName.apply("idStr");
        assertNull(idStrField);

        Field displayField = fieldGetterByFieldName.apply("displayName");
        assertNull(displayField);

        Field idField = fieldGetterByFieldName.apply("id");
        checkFieldInfo(true, "id", "id", FieldType.Long, ColumnType.UNKNOWN, Optional.empty(), idField);

        Field attr1Field = fieldGetterByFieldName.apply("attr1");
        assertNull(attr1Field);

        Field genderField = fieldGetterByFieldName.apply("gender");
        checkFieldInfo(false, "gender", "gender", FieldType.Byte, ColumnType.UNKNOWN, Optional.empty(), genderField);

        Field birthDayField = fieldGetterByFieldName.apply("birthday");
        checkFieldInfo(false, "birthday", "birthday", FieldType.Date, ColumnType.UNKNOWN, Optional.empty(), birthDayField);

        Field dateCreatedField = fieldGetterByFieldName.apply("date_created");
        checkFieldInfo(false, "date_created", "date_created", FieldType.DateTime, ColumnType.UNKNOWN, Optional.empty(), dateCreatedField);
    }
}
