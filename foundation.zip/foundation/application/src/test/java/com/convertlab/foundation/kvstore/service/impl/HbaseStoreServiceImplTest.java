package com.convertlab.foundation.kvstore.service.impl;

import com.convertlab.foundation.kvstore.dto.KeyValuesPair;
import com.convertlab.foundation.kvstore.dto.KvPair;
import com.convertlab.foundation.kvstore.misc.AdHocMetasUtil;
import com.convertlab.foundation.kvstore.misc.AdHocTableMeta;
import com.convertlab.foundation.library.constant.DataProcessingMode;
import com.convertlab.foundation.library.gdmmeta.client.GdmStorageMetaRtClient;
import com.convertlab.foundation.library.gdmmeta.model.table.GdmTable;
import com.convertlab.foundation.library.hbase.core.HbaseColumnSchema;
import com.convertlab.foundation.library.hbase.core.TenantIsolationHbaseTemplate;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.test.LazyGdmRegistry;
import lombok.extern.slf4j.Slf4j;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.kerby.util.Hex;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@Slf4j
public class HbaseStoreServiceImplTest {
    private static LazyGdmRegistry lazyGdmRegistry;
    @Mock
    private GdmStorageMetaRtClient mockGdmMetaClient;

    @Mock(lenient=true)
    private static Connection mockConnection;
    @Mock(lenient=true)
    private Table mockTable;

    private static AdHocTableMeta customerStatisticsMeta;

    @Spy
    private TenantIsolationHbaseTemplate mockTenantIsolationHbaseTemplate =
            new TenantIsolationHbaseTemplate(new Configuration(), null, "test");

    private HbaseStoreServiceImpl hbaseStoreService;

    static MockedStatic<ConnectionFactory> utilities;
    @BeforeAll
    static void beforeAll() throws IOException, URISyntaxException {
        lazyGdmRegistry = new LazyGdmRegistry("/meta/gdm/tenant_1.json");
        utilities = Mockito.mockStatic(ConnectionFactory.class);
        utilities.when(() -> ConnectionFactory.createConnection(any(Configuration.class))).thenReturn(mockConnection);
        customerStatisticsMeta = AdHocMetasUtil.getAdHocTableMetaByName("customer_statistics");
    }

    @AfterAll
    static void afterAll() throws IOException {
        utilities.close();
        log.info("afterAll, utilities.isClosed: {}",utilities.isClosed());
    }

    public HbaseStoreServiceImplTest() throws IOException {

    }

    @BeforeEach
    public void setUp() throws Exception{
        hbaseStoreService = new HbaseStoreServiceImpl(mockGdmMetaClient, mockTenantIsolationHbaseTemplate);
        when(mockConnection.getTable(any(TableName.class))).thenReturn(mockTable);
        Mockito.lenient().when(mockTenantIsolationHbaseTemplate.getConnection()).thenReturn(mockConnection);
    }

    @Test
    public void testBatchSelect() throws Exception {
        // Setup
        final List<HbaseColumnSchema> columnSchemas = Arrays.asList(new HbaseColumnSchema("*", "String"));
        String profile1Id = "1506469036479883264";
        String profile2Id = "1506468777599051776";
        String list1Id = "1506468802957811712";
        String list2Id = "1506469153928783872";
        try(TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(1L, "客户A")){
            // mock hbase table.get()
            Result result1 = generateMockResultWithString("list_member",profile1Id, Arrays.asList(list1Id), Arrays.asList("1"));
            Result result2 = generateMockResultWithString("list_member", profile2Id, Arrays.asList(list2Id,list1Id), Arrays.asList("1","1"));
            when(mockTable.get(any(List.class))).thenReturn(new Result[]{result1, result2});

            // Run the test
            final List<KeyValuesPair> result = hbaseStoreService.batchSelect("list_member", "list_member",
                    Arrays.asList("1506469036479883264", "1506468777599051776"), Arrays.asList("1506469153928783872", "1506468802957811712"), columnSchemas);

            // Verify the results
            assertEquals(result.size(), 2);
            assertEquals("1506469036479883264", result.get(0).getId());
            assertTrue(result.get(0).getKvMapping()instanceof Map );
            Map record1Columns = (Map) result.get(0).getKvMapping();
            assertEquals("1", record1Columns.get("1506468802957811712"));
        }
    }


    @Test
    @DisplayName("测试Hbase column包含长短名的case")
    public void testSelectWithShortToLongConvertion() throws Exception {
        // Setup
        final List<HbaseColumnSchema> columnSchemas = customerStatisticsMeta.getDbStorageTypes().get("KV")
                .getColumnFamilies().get(0).getColumns();

        String profile1Id = "1362982327403403264";
        String index1 = "latest7daysScore";
        String index2 = "attrScore";

        try(TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(1L, "客户A")){
            // mock hbase table.get()
            Result result1 = generateMockResultWithBytes("stat",profile1Id,
                    Arrays.asList("l7s", "as"), Arrays.asList(Hex.decode("0000000000000000"), Hex.decode("404E000000000000")));
            when(mockTable.get(any(List.class))).thenReturn(new Result[]{result1});

            // Run the test
            final List<KeyValuesPair> result = hbaseStoreService.batchSelect("customer_statistics", "stat",
                    Arrays.asList(profile1Id), Arrays.asList(index1, index2), columnSchemas);

            // Verify the results
            assertEquals(result.size(), 1);
            assertEquals(result.get(0).getId(), profile1Id);
            KvPair kvValues =  result.get(0).getKvMapping();
            assertEquals(kvValues.get(index1), Long.valueOf(0));
            assertEquals(kvValues.get(index2), Double.valueOf(60));
        }
    }

    @Test
    public void testBatchSelect_TenantIsolationHbaseTemplateThrowsException() throws Exception {
        // Setup
        final List<HbaseColumnSchema> columnSchemas = Arrays.asList(new HbaseColumnSchema("*", "String"));
        String profile1Id = "1506469036479883264";
        String list1Id = "1506468802957811712";
        try(TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(1L, "客户A")){
            // mock hbase table.get()
            when(mockTable.get(any(List.class))).thenThrow(new IOException());

            // Run the test
            Assertions.assertThrows(IOException.class, ()->{
                hbaseStoreService.batchSelect("list_member", "list_member",
                        Arrays.asList(profile1Id),
                        Arrays.asList(list1Id), columnSchemas);
            });
        }

        try(TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(1L, "客户A")){
            // mock hbase table.get()
            when(mockConnection.getTable(any(TableName.class))).thenReturn(null);

            // Run the test
            Assertions.assertThrows(Exception.class, ()->{
                hbaseStoreService.batchSelect("list_member", "list_member",
                        Arrays.asList(profile1Id),
                        Arrays.asList(list1Id), columnSchemas);
            });
        }

    }

    @Test
    public void testBatchInsertOrUpdate() throws Exception {
        // Setup
        final List<KeyValuesPair> kvPairs = Arrays.asList(new KeyValuesPair("001", new HashMap(){{
            put("10010", "1");
        }}));
        final List<HbaseColumnSchema> columnSchemas = Arrays.asList(new HbaseColumnSchema("*", "String"));
        try(TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(1L, "客户A")) {
            // Run the test
            hbaseStoreService.batchInsertOrUpdate("list_member", "list_member", kvPairs, columnSchemas);

            // Verify the results
            verify(mockTable).put(any(List.class));
        }
    }

    @Test
    public void testBatchInsertOrUpdate_TenantIsolationHbaseTemplateThrowsException() throws Exception {
        // Setup
        final List<KeyValuesPair> kvPairs = Arrays.asList(new KeyValuesPair("key", new HashMap<>()));
        final List<HbaseColumnSchema> columnSchemas = Arrays.asList(new HbaseColumnSchema("name", "type"));
        try(TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(1L, "客户A")) {
            // mock hbase table.get()
            when(mockConnection.getTable(any(TableName.class))).thenReturn(null);
            // Run the test
            Assertions.assertThrows(Exception.class, () -> hbaseStoreService.batchInsertOrUpdate("list_member",
                    "list_member", kvPairs, columnSchemas));
        }
    }

    @Test
    public void testBatchDelete() throws Exception {
        // Setup
        final List<HbaseColumnSchema> columnSchemas = Arrays.asList(new HbaseColumnSchema("*", "String"));
        final List<KeyValuesPair> kvPairs = Arrays.asList(new KeyValuesPair("001", new HashMap(){{
            put("10010", "1");
        }}));
        try(TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(1L, "客户A")) {
            // Run the test
            hbaseStoreService.batchDelete("list_member", "list_member", kvPairs, columnSchemas);

            // Verify the results
            verify(mockTable).delete(any(List.class));
        }
    }

    @Test
    public void testBatchDelete_TenantIsolationHbaseTemplateThrowsException() throws Exception {
        // Setup
        final List<HbaseColumnSchema> columnSchemas = Arrays.asList(new HbaseColumnSchema("*", "String"));
        final List<KeyValuesPair> kvPairs = Arrays.asList(new KeyValuesPair("001", new HashMap(){{
            put("10010", "1");
        }}));
        try(TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(1L, "客户A")) {
            // mock hbase table.get()
            when(mockConnection.getTable(any(TableName.class))).thenReturn(null);
            // Run the test
            Assertions.assertThrows(Exception.class, () -> hbaseStoreService.batchDelete("list_member", "list_member", kvPairs, columnSchemas));
        }
    }

    @Test
    public void testBatchIncrement() throws Exception {
        // Setup
        final List<HbaseColumnSchema> columnSchemas = Arrays.asList(new HbaseColumnSchema("*", "String"));
        final List<KeyValuesPair> kvPairs = Arrays.asList(new KeyValuesPair("001", new HashMap(){{
            put("10010", new HashMap(){{
                put("amount", 1);
                put("ttl", 10000);
            }});
        }}));
        try(TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(1L, "客户A")) {
            // Run the test
            hbaseStoreService.batchIncrement("list_member", "list_member", kvPairs, columnSchemas);

            // Verify the results
            verify(mockTable).increment(any(Increment.class));
        }
    }

    @Test
    public void testBatchIncrement_TenantIsolationHbaseTemplateThrowsException() throws Exception {
        // Setup
        final List<HbaseColumnSchema> columnSchemas = Arrays.asList(new HbaseColumnSchema("*", "String"));
        final List<KeyValuesPair> kvPairs = Arrays.asList(new KeyValuesPair("001", new HashMap(){{
            put("10010", "1");
        }}));
        try(TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(1L, "客户A")) {
            // mock hbase table.get()
            when(mockConnection.getTable(any(TableName.class))).thenReturn(null);
            // Run the test
            Assertions.assertThrows(Exception.class, () -> hbaseStoreService.batchIncrement("list_member",
                    "list_member", kvPairs, columnSchemas));
        }
    }

    @Test
    public void testGetHbaseTableName() throws Exception {
        try(TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(1L, "客户A")) {
            // Setup
            GdmTable listMemberEntity = lazyGdmRegistry.getTable("list_member");
            when(mockGdmMetaClient.getTableStorageOfMode("list_member", DataProcessingMode.KV)).thenReturn(listMemberEntity.storages().stream().filter(s -> s.getDbType().equals("HBASE")).findFirst().get());
            GdmTable dynamicListMemberEntity = lazyGdmRegistry.getTable("dynamic_list_member");
            when(mockGdmMetaClient.getTableStorageOfMode("dynamic_list_member", DataProcessingMode.KV)).thenReturn(dynamicListMemberEntity.storages().stream().filter(s -> s.getDbType().equals("HBASE")).findFirst().get());

            // Run the test
            final String hbaseTableNameOfListMemberEntity = hbaseStoreService.getHbaseTableName("list_member");

            // Verify the results
            assertEquals("list_member", hbaseTableNameOfListMemberEntity);

            // Run the test
            final String hbaseTableNameOfDynamicListMemberEntity = hbaseStoreService.getHbaseTableName("dynamic_list_member");

            // Verify the results
            assertEquals("list_member", hbaseTableNameOfDynamicListMemberEntity);
        }
    }

    @Test
    public void testGetHbaseColumnSchemas() throws Exception {
        try(TemporaryTenantContext temporaryTenantContext = new TemporaryTenantContext(1L, "客户A")) {
            // Setup
            GdmTable listMemberTable = lazyGdmRegistry.getTable("list_member");
            when(mockGdmMetaClient.getTableStorageOfMode("list_member", DataProcessingMode.KV))
                    .thenReturn(listMemberTable.storages().stream().filter(s -> s.getDbType().equals("HBASE")).findFirst().get());

            // Run the test
            final List<HbaseColumnSchema> result = hbaseStoreService.getHbaseColumnSchemas("list_member");
            assertTrue(result.size() == 1);
            assertEquals(result.get(0).getName(), "*");
            assertEquals(result.get(0).getType(), "String");
        }

    }

    /**
     * 生成Hbase查询的结果Result Mock
     * @param columnFamily
     * @param rowKey
     * @param columns
     * @param values
     * @return
     */
    private Result generateMockResultWithString(String columnFamily, String rowKey, List<String> columns, List<String> values){
        Result row = Mockito.mock(Result.class);
        when(row.getRow()).thenReturn(rowKey.getBytes());
        NavigableMap familyMap = new TreeMap((new Comparator<byte[]>() {
            public int compare(byte[] p1, byte[] p2) {
                String left = new String(p1);
                String right = new String(p2);
                return left.compareTo(right);
            }
        }));
        for(int i =0; i<columns.size(); i++){
            familyMap.put(columns.get(i).getBytes(), values.get(i).getBytes());
        }
        when(row.getFamilyMap(columnFamily.getBytes())).thenReturn(familyMap);
        when(row.isEmpty()).thenReturn(false);
        return row;
    }

    private Result generateMockResultWithBytes(String columnFamily, String rowKey, List<String> columns, List<byte[]> values){
        Result row = Mockito.mock(Result.class);
        when(row.getRow()).thenReturn(rowKey.getBytes());
        NavigableMap familyMap = new TreeMap((new Comparator<byte[]>() {
            public int compare(byte[] p1, byte[] p2) {
                String left = new String(p1);
                String right = new String(p2);
                return left.compareTo(right);
            }
        }));
        for(int i =0; i<columns.size(); i++){
            familyMap.put(columns.get(i).getBytes(), values.get(i));
        }
        when(row.getFamilyMap(columnFamily.getBytes())).thenReturn(familyMap);
        when(row.isEmpty()).thenReturn(false);
        return row;
    }
}
