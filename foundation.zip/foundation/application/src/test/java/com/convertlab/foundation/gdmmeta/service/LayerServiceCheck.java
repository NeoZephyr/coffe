package com.convertlab.foundation.gdmmeta.service;

import com.convertlab.foundation.gdmmeta.model.Entity;
import com.convertlab.foundation.gdmmeta.model.Field;
import com.convertlab.foundation.gdmmeta.mybatis.service.impl.CustomerMetaServiceImpl;
import com.convertlab.foundation.gdmmeta.mybatis.service.impl.MembershipMetaServiceImpl;
import com.convertlab.foundation.gdmmeta.mybatis.service.impl.UdoMetaServiceImpl;
import com.convertlab.foundation.gdmmeta.service.impl.ConfigMetaProviderImpl;
import com.convertlab.foundation.gdmmeta.service.impl.DbMetaProviderImpl;
import com.convertlab.foundation.library.gdmmeta.model.ColumnType;
import com.convertlab.foundation.library.gdmmeta.model.FieldType;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.storage.Storage;
import com.convertlab.foundation.library.jdbc.datasource.DynamicDataSource;
import com.convertlab.foundation.library.jdbc.property.ExtraDataSourceProperties;
import com.convertlab.foundation.library.jdbc.property.ExtraDataSourceProperties.DataSourcesConfig;
import org.jetbrains.annotations.NotNull;
import org.mockito.Mockito;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.BiPredicate;
import java.util.function.Consumer;

import static com.convertlab.foundation.gdmmeta.model.metaobject.TenantExtendedEntityDef.CUSTOMER;
import static com.convertlab.foundation.gdmmeta.model.metaobject.TenantDefinedEntityDef.CUSTOMER_EVENT;
import static org.junit.jupiter.api.Assertions.*;

public interface LayerServiceCheck {
    @NotNull
    default DbMetaProviderImpl getDefaultMockDbMetaService() {
        ExtraDataSourceProperties dataSourceProperties = new ExtraDataSourceProperties();
        Map<String, ExtraDataSourceProperties.DataSourceConfig> dataSourceConfigHashMap = new HashMap<>();
        dataSourceConfigHashMap.put("su1", new ExtraDataSourceProperties.DataSourceConfig());
        DataSourcesConfig config = new DataSourcesConfig();
        config.setDatasources(dataSourceConfigHashMap);
        dataSourceProperties.setOltp(config);

//        ExtraDynamicDataSourceProperties dynamicDSProps = new ExtraDynamicDataSourceProperties();
//        dynamicDSProps.setEnabled(true);
//        dynamicDSProps.setPrimary("su1");
//        dynamicDSProps.setDatasources(new HashMap<>());
        DynamicDataSource dds = new DynamicDataSource(dataSourceProperties, () -> "su1");
        dds.afterPropertiesSet();

        DbMetaProviderImpl dbMetaService = new DbMetaProviderImpl(dds);
        return dbMetaService;
    }

    @NotNull
    default CustomerMetaServiceImpl getLocalCustomerMetaService(ConfigMetaProviderImpl configMetaProvider) {
        Map<String, String> tenantMeta = configMetaProvider.loadTenantCustomerMeta();
        DataSource dataSource = Mockito.mock(DataSource.class);
        CustomerMetaServiceImpl customerMetaService = new CustomerMetaServiceImpl(dataSource);
        customerMetaService.setLoadFromLocal(true, tenantMeta);
        return customerMetaService;
    }

    @NotNull
    default MembershipMetaServiceImpl getLocalMembershipMetaService(ConfigMetaProviderImpl configMetaProvider) {
        Map<String, String> tenantMeta = configMetaProvider.loadTenantMembershipMeta();
        DataSource dataSource = Mockito.mock(DataSource.class);
        MembershipMetaServiceImpl membershipMetaService = new MembershipMetaServiceImpl(dataSource);
        membershipMetaService.setLoadFromLocal(true, tenantMeta);
        return membershipMetaService;
    }


    /**
     * 检查 Entity 的基本信息， 适用于所有的 Register Entity Layer 的输出。<br/>
     * 检查除了 Field 之外的所有信息。<br/>
     * 目前看，一个 Entity Register Layer 就决定了一个 Entity 的基本信息，后续的层次不会再修改这些信息。<br/>
     *
     * @param entity
     */
    default void checkRegisteredGdmEntity(Entity entity) {
        // 基本信息需要存在
        assertNotNull(entity.getEntityName());
        assertNotNull(entity.getDbTableName());
        assertNotNull(entity.getDbView());

        // 判断 dbStorageType 信息
        Map<GdmEntity.RequiredStorageType, Storage> dbStorageTypes = entity.getDbStorageTypes();
        assertTrue(dbStorageTypes.size() > 0);
        for (Map.Entry<GdmEntity.RequiredStorageType, Storage> storageEntry : dbStorageTypes.entrySet()) {
            assertNotNull(storageEntry.getKey());
            assertNotNull(storageEntry.getValue());
        }

        //目前没有 Field 信息
        assertTrue(entity.getFields().size() >= 0);

    }

    default void checkEntityDbFields(Entity entity) {
        List<Field> fieldsFromDb = entity.getFields();
        assertTrue(fieldsFromDb.size() > 0);

        for (Field dbField : fieldsFromDb) {

            assertNotNull(dbField.getFieldName());
            assertNotNull(dbField.getFieldType());
            assertNotNull(dbField.getDbColumnName());
            assertNotNull(dbField.getDbColumnType());
        }
        ;
    }

    default void finalCustomerAttr1FieldCheck(Field attr1Field) {
        checkFieldInfo(false, "attr1", "attr1", FieldType.String, ColumnType.VARCHAR,
                Optional.empty(), attr1Field);
    }

    default void finalCustomerIdFieldCheck(Field idField) {
        checkFieldInfo(true, "id", "id", FieldType.Long, ColumnType.BIGINT,
                Optional.empty(), idField);
    }

    default void mysqlCustomerIdFieldCheck(Field idField) {
        finalCustomerIdFieldCheck(idField);
    }

    default void mysqlCustomerAttr1FieldCheck(Field attr1Field) {
        finalCustomerAttr1FieldCheck(attr1Field);
    }

    default void mysqlCustomerBirthdayFieldCheck(Field birthdayField) {
        checkFieldInfo(false, "birthday", "birthday", FieldType.Date, ColumnType.DATE,
                Optional.empty(), birthdayField);
    }

    default void mysqlCustomerGenderFieldCheck(Field genderField) {
        checkFieldInfo(false, "gender", "gender", FieldType.Byte, ColumnType.TINYINT,
                Optional.empty(), genderField);
    }

    default void mysqlCustomerDateCreatedFieldCheck(Field dateCreatedField) {
        checkFieldInfo(false, "date_created", "date_created", FieldType.DateTime, ColumnType.TIMESTAMP,
                Optional.empty(), dateCreatedField);
    }

    default void mysqlCustomerIsMemberFieldCheck(Field isMemberField) {
        checkFieldInfo(false, "is_member", "is_member", FieldType.Boolean, ColumnType.BIT,
                Optional.empty(), isMemberField);
    }

    default void impalaCustomerIdFieldCheck(Field idField) {
        checkFieldInfo(true, "id", "id", FieldType.Long, ColumnType.VARCHAR,
                Optional.empty(), idField);
    }

    default void impalaCustomerAttr1FieldCheck(Field attr1Field) {
        checkFieldInfo(false, "attr1", "attr1", FieldType.String, ColumnType.VARCHAR,
                Optional.empty(), attr1Field);
    }

    default void impalaCustomerBirthdayFieldCheck(Field birthdayField) {
        checkFieldInfo(false, "birthday", "birthday", FieldType.Date, ColumnType.BIGINT,
                Optional.empty(), birthdayField);
    }

    default void impalaCustomerGenderFieldCheck(Field genderField) {
        checkFieldInfo(false, "gender", "gender", FieldType.Byte, ColumnType.INTEGER,
                Optional.empty(), genderField);
    }

    default void impalaCustomerDateCreatedFieldCheck(Field dateCreatedField) {
        checkFieldInfo(false, "date_created", "date_created", FieldType.DateTime, ColumnType.BIGINT,
                Optional.empty(), dateCreatedField);
    }

    default void impalaCustomerIsMemberFieldCheck(Field isMemberField) {
        checkFieldInfo(false, "is_member", "is_member", FieldType.Boolean, ColumnType.INTEGER,
                Optional.empty(), isMemberField);
    }


    default void getFieldAndCheck(List<Field> fieldList, BiPredicate<Field, String> fieldPredicate, String testName, Consumer<Field> fieldChecker) {
        Optional<Field> fieldOpt = fieldList.stream().filter(field -> fieldPredicate.test(field, testName)).findAny();
        assertTrue(fieldOpt.isPresent());
        fieldChecker.accept(fieldOpt.get());
    }

    default Optional<Field> getFieldOptByFieldName(List<Field> customerEntity, String fieldName) {
        return customerEntity.stream().filter(field -> field.getFieldName().equals(fieldName)).findAny();
    }

    default void checkFieldInfo(Boolean expectPk, String expectFieldName, String expectDbColumnName,
                                FieldType expectFieldType, ColumnType expectColumnType,
                                Optional<Integer> expectColumnPrecision, Field field) {
        assertNotNull(field);

        assertEquals(expectFieldName, field.getFieldName());
        assertEquals(expectDbColumnName, field.getDbColumnName());

        assertEquals(expectFieldType, field.getFieldType());
//        assertEquals(expectColumnType, field.getDbColumnType());
    }


    default void registeredCustomerEntityCheck(Entity customerEntity) {
        assertEquals(CUSTOMER.entityName, customerEntity.getEntityName());
        assertEquals(CUSTOMER.tableName, customerEntity.getDbTableName());
        assertTrue(customerEntity.getDbView());
        assertNull(customerEntity.getInheritance());
        assertNotNull(Storage.MYSQL, customerEntity.getDbStorageTypes().get(GdmEntity.RequiredStorageType.OLTP).getDbType());
        assertNotNull(Storage.KUDU, customerEntity.getDbStorageTypes().get(GdmEntity.RequiredStorageType.REALTIME_AP).getDbType());
    }

    default void registeredCustomerEventEntityCheck(Entity customerEventEntity) {
        assertEquals(CUSTOMER_EVENT.entityName, customerEventEntity.getEntityName());
        assertEquals(CUSTOMER_EVENT.tableName, customerEventEntity.getDbTableName());
        assertFalse(customerEventEntity.getDbView());
        assertNull(customerEventEntity.getInheritance());
        assertNotNull(Storage.KUDU, customerEventEntity.getDbStorageTypes().get(GdmEntity.RequiredStorageType.REALTIME_AP).getDbType());
//        assertNotNull(Storage.PARQUET, customerEventEntity.getDbStorageTypes().get(GdmEntity.RequiredStorageType.BATCH_AP).getDbType());
    }

    default void registeredOpenPageEventEntityCheck(Entity openPageRegisterEntity) {
        assertEquals("open_page", openPageRegisterEntity.getEntityName());
        assertEquals("customer_event", openPageRegisterEntity.getDbTableName());
        assertFalse(openPageRegisterEntity.getDbView());
        assertNotNull(openPageRegisterEntity.getInheritance());
        assertTrue(openPageRegisterEntity.getInheritance().getIsSubtype());
        assertEquals("event", openPageRegisterEntity.getInheritance().getIdentifierField());
        assertNotNull(Storage.KUDU, openPageRegisterEntity.getDbStorageTypes().get(GdmEntity.RequiredStorageType.REALTIME_AP).getDbType());
//        assertNotNull(Storage.PARQUET, openPageRegisterEntity.getDbStorageTypes().get(GdmEntity.RequiredStorageType.BATCH_AP).getDbType());
    }

    default void registeredTenantDefinedEventEntityCheck(Entity tenantDefinedEntity) {
        assertEquals("c_evil_noprop", tenantDefinedEntity.getEntityName());
        assertEquals("customer_event", tenantDefinedEntity.getDbTableName());
        assertFalse(tenantDefinedEntity.getDbView());
        assertNotNull(tenantDefinedEntity.getInheritance());
        assertTrue(tenantDefinedEntity.getInheritance().getIsSubtype());
        assertEquals("event", tenantDefinedEntity.getInheritance().getIdentifierField());
        assertNotNull(Storage.KUDU, tenantDefinedEntity.getDbStorageTypes().get(GdmEntity.RequiredStorageType.REALTIME_AP).getDbType());
//        assertNotNull(Storage.PARQUET, tenantDefinedEntity.getDbStorageTypes().get(GdmEntity.RequiredStorageType.BATCH_AP).getDbType());
    }


}
