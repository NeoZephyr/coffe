package com.convertlab.foundation.gdmpattern;

import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto;
import com.convertlab.foundation.gdmpattern.provisioner.FeatureProvisioner;
import com.convertlab.foundation.gdmpattern.provisioner.UdoProvisionerFactory;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.ObjectResponse;
import com.convertlab.foundation.library.utils.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Slf4j
public class GdmPatternDtoTest {
    @Test
    void testDto() {
        GdmPatternDto.ProvisionProperties props = new GdmPatternDto.ProvisionProperties();
        props.setTraitsDefEntityName("traits");
        log.info("props to json: {}", JsonUtils.instance().obj2Json(props));
        String json = JsonUtils.instance().obj2Json(props);
        GdmPatternDto.ProvisionProperties props1 = JsonUtils.instance().json2Obj(json, GdmPatternDto.ProvisionProperties.class);
        log.info("props1: {}", props1);
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        log.info("validator: {}", validator);
        Set<ConstraintViolation<GdmPatternDto.ProvisionProperties>> result = validator.validate(props1);
        result.forEach(violation -> log.error(" ======== violation: {} {}.", violation.getPropertyPath(), violation.getMessage()));


        ObjectResponse response = JsonUtils.instance().json2Obj("{\n" +
                "  \"objectName\": \"c_car\",\n" +
                "  \"data\": {\n" +
                "    \"patterns\": [\"general-profile\"],\n" +
                "    \"name\": \"c_car\",\n" +
                "    \"props\": {\n" +
                "      \"traitsDefEntityName\": \"abc\"\n" +
                "    },\n" +
                "    \"provisionStatus\": \"PROVISIONED\"\n" +
                "  },\n" +
                "  \"$version\": \"1685350076387\",\n" +
                "  \"$self\": \"/v1/meta/gdm/gdm-models/c_car\",\n" +
                "  \"$basePath\": \"/v1/meta/gdm/gdm-models\"\n" +
                "}", ObjectResponse.class);
        GdmModelDto dto = JsonUtils.instance().convert(response.getData(), GdmModelDto.class);
        result = validator.validate(dto.getProps());
        result.forEach(violation -> log.error(" ======== violation: {} {}.", violation.getPropertyPath(), violation.getMessage()));

    }
}
