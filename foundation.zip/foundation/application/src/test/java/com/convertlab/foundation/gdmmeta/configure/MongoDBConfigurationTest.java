package com.convertlab.foundation.gdmmeta.configure;

import java.util.List;
import java.util.Map;

import com.convertlab.foundation.gdmmeta.persistance.entity.GdmEntityModel;
import com.convertlab.foundation.gdmmeta.persistance.general.GeneralMetaObject;
import com.convertlab.foundation.gdmmeta.persistance.relationship.GdmRelationshipModel;
import com.convertlab.foundation.gdmmeta.persistance.table.GdmTableModel;
import com.convertlab.foundation.library.gdmmeta.model.general.BaseMetaSchema;
import com.convertlab.foundation.library.mongodb.autoconfigure.ConvertlabMongoAutoConfiguration;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.context.annotation.Import;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.test.context.ContextConfiguration;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

@Slf4j
//@Tag("SlowTest") // 默认不要跑，因为要下载mongo db
//@AutoConfigureDataMongo() // 这个没有必要，已经在@DataMongoTest里面包含了
@DataMongoTest( properties = { // 用来补充test下面application.yaml没有的配置项
        "de.flapdoodle.mongodb.embedded.version=6.0.6",
        "convertlab.product.name=dmhub",
//        "logging.level.org.springframework=TRACE",
        "logging.level.com.convertlab.foundation.gdmmeta.configure=TRACE",
    })
//@EnableAutoConfiguration没有必要

// 这几个极其重要，是Spring Context需要的configuration，最小集的configuration
@Import({
        CustomeMongodConfiguration.class,
        MongoDBInitConfiguration.MongoDBTenantIgnoreInitConfiguration.class,
        MongoDBInitConfiguration.MongoDBTenantIsolationSharedInitConfiguration.class
})
@ContextConfiguration(classes = {
        MongoAutoConfiguration.class,
        MongoDataAutoConfiguration.class,
        ConvertlabMongoAutoConfiguration.class})

class MongoDBConfigurationTest {
    @Autowired
    @Qualifier("tenantIsolationSharedMongoTemplate")
    MongoTemplate tenantIsolationMongoTemplate;

    @Autowired
    @Qualifier("tenantIgnoredMongoTemplate")
    MongoTemplate tenantIgnoredMongoTemplate;

    @Test
    void initIndicesOfTenantIsolationCollectionAfterStartup_GeneralMetaObject() {
        // pickup MetaType.GDM_MODELS and get its collectionName
        BaseMetaSchema.MetaType metaType = BaseMetaSchema.MetaType.GDM_MODELS;
        String collectionName = metaType.getCollectionName();

        // insert a dummy data into the collection, using GeneralMetaObject.class
        Map<String, Object> dataMap = Maps.newHashMap();
        dataMap.put("a", "b");
        GeneralMetaObject data = GeneralMetaObject.buildForCreate(metaType, "testName", dataMap);
        try (TemporaryTenantContext ignore = new TemporaryTenantContext(1L)) {
            tenantIsolationMongoTemplate.insert(data, collectionName);
            tenantIsolationMongoTemplate.find(query(where("data.a").is("b")), GeneralMetaObject.class, collectionName)
                    .forEach(it -> log.info("Query result: {}", it));
            Assertions.assertEquals(1,
                    tenantIsolationMongoTemplate.find(query(where("data.a").is("b")), GeneralMetaObject.class, collectionName).size(),
                    "现如今，应该能看到1条数据");

            tenantIsolationMongoTemplate.indexOps(collectionName).getIndexInfo().forEach(it -> {
                log.info("Index info of {}: {}, {}", collectionName, it.getName(), it.getIndexFields());
            });
            Assertions.assertEquals(2, tenantIsolationMongoTemplate.indexOps(collectionName).getIndexInfo().size(), "现如今，需要2个索引");
        }
    }

    @Test
    void initIndicesOfTenantIsolationCollectionAfterStartup_GdmEntityModel() {
        // pickup MetaType.GDM_ENTITIES and get its collectionName
        BaseMetaSchema.MetaType metaType = BaseMetaSchema.MetaType.GDM_ENTITIES;
        String collectionName = metaType.getCollectionName();

        // insert a dummy entityModel into the collection
        GdmEntityModel entityModel = new GdmEntityModel();
        String entityName = "test_entity_name_1";
        entityModel.setEntityName(entityName);
        try (TemporaryTenantContext ignore = new TemporaryTenantContext(1L)) {
            tenantIsolationMongoTemplate.insert(entityModel, collectionName);
            Query query = query(where("entityName").is(entityName));
            tenantIsolationMongoTemplate.find(query, GdmEntityModel.class, collectionName)
                    .forEach(it -> log.info("Query result: {}", it));
            Assertions.assertEquals(1,
                    tenantIsolationMongoTemplate.find(query, GdmEntityModel.class, collectionName).size(), "");

            tenantIsolationMongoTemplate.indexOps(collectionName).getIndexInfo().forEach(it -> {
                log.info("Index info of {}: {}, {}", collectionName, it.getName(), it.getIndexFields());
            });
            Assertions.assertEquals(3, tenantIsolationMongoTemplate.indexOps(collectionName).getIndexInfo().size(), "现如今，需要3个索引");
        }
    }

    @Test
    void initIndicesOfTenantIsolationCollectionAfterStartup_GdmEntityModel_tenant_isolation() {
        // pickup MetaType.GDM_ENTITIES and get its collectionName
        BaseMetaSchema.MetaType metaType = BaseMetaSchema.MetaType.GDM_ENTITIES;
        String collectionName = metaType.getCollectionName();
        String entityNameValue = "test_entity_name_2";
        String entityNameField = "entityName";
        GdmEntityModel otherEntityModel = new GdmEntityModel();
        otherEntityModel.setEntityName(entityNameValue);
        try (TemporaryTenantContext ignore = new TemporaryTenantContext(2L)) {
            tenantIsolationMongoTemplate.insert(otherEntityModel, collectionName);
            Query query = query(where(entityNameField).is(entityNameValue));
            tenantIsolationMongoTemplate.find(query, GdmEntityModel.class, collectionName)
                    .forEach(it -> log.info("Query result: {}", it));
            Assertions.assertEquals(1,
                    tenantIsolationMongoTemplate.find(query, GdmEntityModel.class, collectionName).size(), "");
        }

        // insert a dummy entityModel into the collection
        GdmEntityModel entityModel = new GdmEntityModel();

        entityModel.setEntityName(entityNameValue);
        try (TemporaryTenantContext ignore = new TemporaryTenantContext(1L)) {
            tenantIsolationMongoTemplate.insert(entityModel, collectionName);
            Query query = query(where(entityNameField).is(entityNameValue));
            tenantIsolationMongoTemplate.find(query, GdmEntityModel.class, collectionName)
                    .forEach(it -> log.info("Query result: {}", it));
            Assertions.assertEquals(1,
                    tenantIsolationMongoTemplate.find(query, GdmEntityModel.class, collectionName).size(), "");

            tenantIsolationMongoTemplate.indexOps(collectionName).getIndexInfo().forEach(it -> {
                log.info("Index info of {}: {}, {}", collectionName, it.getName(), it.getIndexFields());
            });
            Assertions.assertEquals(3, tenantIsolationMongoTemplate.indexOps(collectionName).getIndexInfo().size(), "现如今，需要3个索引");
        }
    }

    @Test
    void initIndicesOfTenantIsolationCollectionAfterStartup_GdmRelationshipModel() {
        // pickup MetaType.GDM_RELATIONSHIPS and get its collectionName
        BaseMetaSchema.MetaType metaType = BaseMetaSchema.MetaType.GDM_RELATIONSHIPS;
        String collectionName = metaType.getCollectionName();

        // insert a dummy GdmRelationshipModel into the collection
        GdmRelationshipModel relationshipModel= new GdmRelationshipModel();
        String leftEntityName = "test_left_entity_name";
        relationshipModel.setLeftEntityName(leftEntityName);
        try (TemporaryTenantContext ignore = new TemporaryTenantContext(1L)) {
            tenantIsolationMongoTemplate.insert(relationshipModel, collectionName);
            Query query = query(where("leftEntityName").is(leftEntityName));
            tenantIsolationMongoTemplate.find(query, GdmRelationshipModel.class, collectionName)
                    .forEach(it -> log.info("Query result: {}", it));
            Assertions.assertEquals(1,
                    tenantIsolationMongoTemplate.find(query, GdmRelationshipModel.class, collectionName).size(), "");

            tenantIsolationMongoTemplate.indexOps(collectionName).getIndexInfo().forEach(it -> {
                log.info("Index info of {}: {}, {}", collectionName, it.getName(), it.getIndexFields());
            });
            Assertions.assertEquals(3, tenantIsolationMongoTemplate.indexOps(collectionName).getIndexInfo().size(), "现如今，需要3个索引");
        }
    }

    @Test
    void test_partial_index_of_GdmRelationshipModel() {
        BaseMetaSchema.MetaType metaType = BaseMetaSchema.MetaType.GDM_RELATIONSHIPS;
        String collectionName = metaType.getCollectionName();

        GdmRelationshipModel modelWithNullRevertName = new GdmRelationshipModel();
        modelWithNullRevertName.setLeftEntityName("full_order");
        modelWithNullRevertName.setName("rel_to_customer1");
        modelWithNullRevertName.setRightEntityName("customer");
        modelWithNullRevertName.setReverseName(null);
        modelWithNullRevertName.setForeignKeyOwningSide("full_order");
        modelWithNullRevertName.setMappedBy("rel_to_customer1");

        GdmRelationshipModel modelWithNullRevertName2 = new GdmRelationshipModel();
        modelWithNullRevertName2.setLeftEntityName("full_order");
        modelWithNullRevertName2.setName("rel_to_customer2");
        modelWithNullRevertName2.setRightEntityName("customer");
        modelWithNullRevertName2.setReverseName(null);
        modelWithNullRevertName2.setForeignKeyOwningSide("full_order");
        modelWithNullRevertName2.setMappedBy("rel_to_customer2");

        try (TemporaryTenantContext ignore = new TemporaryTenantContext(1L)) {
            tenantIsolationMongoTemplate.insert(modelWithNullRevertName, collectionName);
            tenantIsolationMongoTemplate.insert(modelWithNullRevertName2, collectionName);

            Query query = query(where("rightEntityName").is("customer"));
            List<GdmRelationshipModel> gdmRelationshipModels = tenantIsolationMongoTemplate.find(query, GdmRelationshipModel.class, collectionName);
            Assertions.assertEquals(2, gdmRelationshipModels.size());
        }
    }


    @Test
    void initIndicesOfTenantIgnoredCollectionAfterStartup() {
        // pickup MetaType.GDM_TABLES and get its collectionName
        BaseMetaSchema.MetaType metaType = BaseMetaSchema.MetaType.GDM_TABLES;
        String collectionName = metaType.getCollectionName();

        // insert a dummy tableModel into the collection
        GdmTableModel tableModel = new GdmTableModel();
        tableModel.setTableName("test_table_name");
        tenantIgnoredMongoTemplate.insert(tableModel, collectionName);
        Query query = query(where("tableName").is("test_table_name"));
        tenantIgnoredMongoTemplate.find(query, GdmTableModel.class, collectionName)
                .forEach(it -> log.info("Query result: {}", it));
        Assertions.assertEquals(1,
                tenantIgnoredMongoTemplate.find(query, GdmTableModel.class, collectionName).size(), "");

        tenantIgnoredMongoTemplate.indexOps(collectionName).getIndexInfo().forEach(it -> {
            log.info("Index info of {}: {}, {}", collectionName, it.getName(), it.getIndexFields());
        });
        Assertions.assertEquals(2, tenantIgnoredMongoTemplate.indexOps(collectionName).getIndexInfo().size(), "现如今，需要2个索引");
    }

}