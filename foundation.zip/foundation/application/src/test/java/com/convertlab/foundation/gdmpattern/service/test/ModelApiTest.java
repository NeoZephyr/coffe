package com.convertlab.foundation.gdmpattern.service.test;

import com.convertlab.data.job.core.biz.model.BizJobRunResult;
import com.convertlab.foundation.api.gdm.pattern.dto.DefineGdmModelRequest;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto;
import com.convertlab.foundation.gdmpattern.model.GdmModel;
import com.convertlab.foundation.gdmpattern.service.ModelIntegrationTestBase;
import com.convertlab.foundation.library.constant.DataProcessingMode;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.gdmmeta.client.SimpleMetaClient;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.ImmutableGdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.entity.GdmEntityRequest;
import com.convertlab.foundation.library.gdmmeta.model.general.BaseMetaSchema;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.GdmEntityExt;
import com.convertlab.foundation.library.gdmmeta.model.table.GdmTable;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.fasterxml.jackson.core.type.TypeReference;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.Nullable;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static com.convertlab.foundation.library.business.autoconfigure.SpringBeans.printSpringBeans;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@Slf4j
public class ModelApiTest extends ModelIntegrationTestBase {
    @Test
    @DisplayName("演示如何使用此测试类，一些工具。基础测试,保证导入的数据和一般性的功能")
    void testJustTest() {
        // 打印测试Context里面的所有Spring Bean。
        printSpringBeans();

        // 演示 Stub Class
        assertTrue(featureClientStub.checkToggleStatus("abc"));
        assertFalse(featureClientStub.checkToggleStatus("xyz"));

        try (TemporaryTenantContext ignore=new TemporaryTenantContext(999L)) {
            @Nullable GdmTable table = gsMetaClient.getTable("nudo1");
            assertNotNull(table);

            // 基于nudo1创建一个entity
            GdmEntity entity = ImmutableGdmEntity.builder().entityName("c_evil").dbTableName("nudo1").build();
            GdmEntityRequest gdmEntityRequest = new GdmEntityRequest(entity);
            entity = gsMetaClient.createEntity(gdmEntityRequest);
            log.info("created entity:{}", entity);
            assertNotNull(entity);

            // 看看是否能够查询出来
            entity = gsMetaClient.getEntity("c_evil");
            log.info("queried entity:{}", entity);
            assertNotNull(entity);
        }
        // repeat the same test for tenant b
        try (TemporaryTenantContext ignore=new TemporaryTenantContext(TENANT_B)) {
            // 基于nudo1创建一个entity
            GdmEntity entity = ImmutableGdmEntity.builder().entityName("c_evil").dbTableName("nudo1").build();
            GdmEntityRequest gdmEntityRequest = new GdmEntityRequest(entity);
            entity = gsMetaClient.createEntity(gdmEntityRequest);
            log.info("created entity:{}", entity);
            assertNotNull(entity);
        }

        // 检查所有租户里的所有东西
        doFullCheck();
    }

    @Test
    @DisplayName("创建一个带Props的Model")
    void testCreateModelWithProps() {
        // See also: com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto.Field
        String cSuperCar = "c_super_car";
        try (TemporaryTenantContext ignore=new TemporaryTenantContext(TENANT_A)) {
            String fileName = "/GdmModelService/ModelRequestWithProps.json5";
            GdmModelDto modelDto = createModelFromFile(fileName, cSuperCar);

            // Check it's created
            assertNotNull(modelDto);
            log.info("model c_super_car: {}",JsonUtils.instanceOfDto().obj2Json(modelDto));

            // Check entity-ext is created accordingly.
            doCheckEntityHasExt(cSuperCar, false, "bk","c_khab");

            doCheckModel(cSuperCar);
        }
    }

    @Test
    @DisplayName("创建一个京东会员")
    void testCreateJdMember() {
        String jdMember = "c_jd_member";
        try (TemporaryTenantContext ignore=new TemporaryTenantContext(TENANT_A)) {
            GdmModelDto modelDto = createModelFromRequest(composeJdMemberModelRequest(), jdMember);

            // Check it's created
            assertNotNull(modelDto);

            // Check the values
            doCheckModel(jdMember);
        }
        doFullCheck();
    }

    @Test
    @DisplayName("创建一个Omni会员")
    void testCreateOmniember() {
        String memberModelName = "c_omni_member";


        Roster rosterBefore;
        Roster rosterAfterCreation;
        Roster rosterAfterDeletion;

        try (TemporaryTenantContext ignore=new TemporaryTenantContext(TENANT_A)) {
            rosterBefore = getObjectRoster();
            log.info("Before. Roster: \n{}", rosterBefore);
            GdmModelDto modelDto = createModelFromRequest(composeOmniMemberModelRequest(memberModelName), memberModelName);
            // Check it's created
            assertNotNull(modelDto);
            // Check the values
            doCheckModel(memberModelName);
            rosterAfterCreation = getObjectRoster();
            log.info("After Creation. Roster: \n{}", rosterAfterCreation);
            doFullCheck();

            bizJobClientMock.getClass();
            // 没有设置ext的值，就应该是空
            SimpleMetaClient extClient = gsMetaClient.simpleClientOf(BaseMetaSchema.MetaType.GDM_ENTITY_EXT);
            List<GdmEntityExt> entityExts = extClient.queryObjects2(new HashMap<>(), GdmEntityExt.class);
            assertTrue(entityExts.isEmpty());

            BizJobRunResult value = new BizJobRunResult();
            value.setBatchNo("B001");
            value.setJobNo("J001");
            value.setErrorMsg("");
            value.setRunStatus("success");

            // Delete the model
            gdmModelService.dropGdmModel(memberModelName,"",true);
            rosterAfterDeletion = getObjectRoster();
            log.info("After Drop. Roster: \n{}", rosterAfterDeletion);
            assertThrows(BusinessException.class,()->{gdmModelService.findByName(memberModelName);});
        }
        doFullCheck();

        Roster diffAfterCreation = rosterAfterCreation.diff(rosterBefore);
        Roster diffAfterDeletion = rosterAfterDeletion.diff(rosterBefore);
        log.info("diffAfterCreation: \n{}", diffAfterCreation);
        log.info("diffAfterDeletion, which should be empty: \n{}", diffAfterDeletion);
        assertTrue(diffAfterDeletion.isEmpty());
    }

    private DefineGdmModelRequest composeOmniMemberModelRequest(String name) {
        // 重用 JD会员request 的属性
        DefineGdmModelRequest request = composeJdMemberModelRequest();

        // 改名字
        request.setName(name);

        // 魔改成Omni
        request.setPatterns(new String[]{GdmPatternDto.PATTERN_GENERAL_PROFILE.getName(), GdmPatternDto.PATTERN_OMNI_MEMBER.getName()});
        List<GdmModelDto.Field> fields = JsonUtils.loadJsonAs("/GdmModelService/omniMemberFields.json5", new TypeReference<List<GdmModelDto.Field>>() {});
        request.setFields(fields);
        return request;
    }

    private DefineGdmModelRequest composeJdMemberModelRequest() {
        DefineGdmModelRequest request = new DefineGdmModelRequest();
        request.setName("c_jd_member");
        request.setPatterns(new String[]{GdmPatternDto.PATTERN_GENERAL_PROFILE.getName(), GdmPatternDto.PATTERN_PLATFORM_MEMBER.getName()});

        List<GdmPatternDto.Feature> features = new ArrayList<>();
        features.add(GdmPatternDto.Feature.MemberDeal);
        features.addAll(GdmPatternDto.PATTERN_GENERAL_PROFILE.getFeatures());
        request.setFeatures(features);

        GdmPatternDto.ProvisionProperties provisionProperties = new GdmPatternDto.ProvisionProperties();
        provisionProperties.setProvisionType(GdmPatternDto.ProvisionType.PLATFORM_MEMBER_UDO);
        provisionProperties.setDataProcessingModes(new DataProcessingMode[]{DataProcessingMode.OLTP,DataProcessingMode.REALTIME_AP});
        request.setProps(provisionProperties);

        request.setSystemEventIds(Arrays.asList("create_membership",
                "delete_membership",
                "loyalty_dispatch_coupon",
                "membership_draw_coupon",
                "membership_exp_decr",
                "membership_exp_incr",
                "membership_level_down",
                "membership_level_up",
                "membership_point_decr",
                "membership_point_incr",
                "membership_redeem_coupon",
                "membership_submit_form"));

        List<GdmModelDto.Field> fields = JsonUtils.loadJsonAs("/GdmModelService/jdMemberFields.json5", new TypeReference<List<GdmModelDto.Field>>() {});
        request.setFields(fields);

        return request;
    }

    @Test
    @DisplayName("一个简单的创建Model的测试")
    void defineModelTest() {
        String cTest2 = "c_test_2";
        try (TemporaryTenantContext ignore=new TemporaryTenantContext(998L)) {
            // 定义一个名字叫c_test_2的general-profile 的 model！！
            GdmModelDto modelDto = createModelFromFile("/GdmModelService/simpleUdoModelRequest.json5", cTest2);
            assertNotNull(modelDto);
            // 除此之外，需要用 Health Check来检查完整性
            doCheckModel(cTest2);
        }


        // 然后换一个租户，就会报错。
        assertThrows(IllegalArgumentException.class, () -> {
            healthCheckController.checkEntity(997L, cTest2);
        }, "c_test_2 is not found");
    }
}
