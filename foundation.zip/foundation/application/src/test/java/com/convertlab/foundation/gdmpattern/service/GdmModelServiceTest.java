package com.convertlab.foundation.gdmpattern.service;

import com.convertlab.foundation.api.gdm.pattern.dto.DefineGdmModelRequest;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.api.gdm.pattern.facade.GdmMetaFacade;
import com.convertlab.foundation.gdmdata.mapper.GdmDataMapper;
import com.convertlab.foundation.gdmpattern.custom.CustomizableTableFactory;
import com.convertlab.foundation.gdmpattern.job.GdmModelJobClient;
import com.convertlab.foundation.gdmpattern.model.GdmModel;
import com.convertlab.foundation.gdmpattern.model.UdoProvision;
import com.convertlab.foundation.library.business.audit.AuditOperations;
import com.convertlab.foundation.library.business.autoconfigure.SpringBeans;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.utils.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collections;

import static com.convertlab.foundation.gdmpattern.provisioner.SystemEventProvisioner.UDO_EVENT_PREFIX;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@Slf4j
class GdmModelServiceTest {
    @InjectMocks
    private GdmModelService gdmModelService;

    @Mock
    private GdmMetaFacade gdmMetaFacade;

    @Mock
    private GdmProvisionService gdmProvisionService;

    @Mock
    private GdmDataMapper gdmDataMapper;

    @Mock
    private GdmModelJobClient gdmModelJobClient;

    @Mock
    private CustomizableTableFactory customizableTableFactory;
    @Mock
    private AuditOperations auditOperations;
    @Mock
    private TableProvisionService tableProvisionService;

    private AutoCloseable closeable;
    private GdmModel mockModel;

    @BeforeEach
    public void setUp() {
        closeable = MockitoAnnotations.openMocks(this);

        when(gdmProvisionService.doProvision(any(UdoProvision.class))).thenReturn(true);
        when(gdmMetaFacade.saveModel(any())).thenReturn(true);

        GdmEntity eventA = JsonUtils.loadJsonAs("/GdmModelService/eventA.json5", GdmEntity.class);
        when(gdmMetaFacade.getEntity(UDO_EVENT_PREFIX + "event_a")).thenReturn(eventA);
        when(gdmMetaFacade.getEntity(UDO_EVENT_PREFIX + "event_b")).thenReturn(null);
        mockModel = JsonUtils.loadJsonAs("/GdmModelService/testModel.json5", GdmModel.class);
        when(gdmMetaFacade.findModelByNameAndLoadSystemEvents("c_test_model")).thenReturn(mockModel.toDto());
    }

    @AfterEach
    public void tearDown() throws Exception {
        closeable.close();
    }

    @Test
    @DisplayName("测试新建 gdm model 的API")
    void testDefineGdmModel() {
        // 创建测试用的DefineGdmModelRequest对象
        DefineGdmModelRequest modelRequest = new DefineGdmModelRequest();
        modelRequest.setName("c_test_model");
        modelRequest.setSystemEventIds(Arrays.asList("event_a", "event_not_exist"));
        modelRequest.setProps(mockModel.getProps());
        modelRequest.setPatterns(new String[]{"pattern1", "pattern2"});

        // 测试包含不存在的事件ID时是否抛出异常
        assertThrows(BusinessException.class, () -> gdmModelService.defineGdmModel(modelRequest));
        clearInvocations(gdmMetaFacade);

        // 修改请求，只包含存在的事件ID
        modelRequest.setSystemEventIds(Collections.singletonList("event_a"));

        // 创建并配置mock的GdmProvisionService
        GdmProvisionService mockProvisionService = mock(GdmProvisionService.class);
        when(mockProvisionService.doProvision(any())).thenReturn(true);

        try (MockedStatic<SpringBeans> mockedSpringBeans = mockStatic(SpringBeans.class)) {
            // 配置SpringBeans以返回mock的GdmProvisionService
            mockedSpringBeans.when(() -> SpringBeans.getBean(GdmProvisionService.class))
                    .thenReturn(mockProvisionService);

            // 执行被测试的方法
            GdmModelDto result = gdmModelService.defineGdmModel(modelRequest);
            
            // 验证结果
            assertNotNull(result);
            verify(gdmMetaFacade, times(1)).saveModel(any());
            verify(gdmMetaFacade, times(1)).findModelByNameAndLoadSystemEvents("c_test_model");
        }
    }

    
}