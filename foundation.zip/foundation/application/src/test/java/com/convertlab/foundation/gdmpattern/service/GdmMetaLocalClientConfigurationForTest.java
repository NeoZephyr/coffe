package com.convertlab.foundation.gdmpattern.service;

import com.convertlab.foundation.gdmmeta.client.GdmEntityMetaLocalClient;
import com.convertlab.foundation.gdmmeta.client.GdmRelationshipMetaLocalClient;
import com.convertlab.foundation.gdmmeta.client.GdmTableMetaLocalClient;
import com.convertlab.foundation.gdmmeta.client.GeneralMetaLocalClient;
import com.convertlab.foundation.gdmmeta.service.GdmEntityMetaService;
import com.convertlab.foundation.gdmmeta.service.GdmRelationshipMetaService;
import com.convertlab.foundation.gdmmeta.service.GdmTableMetaService;
import com.convertlab.foundation.gdmmeta.service.GeneralMetaService;
import com.convertlab.foundation.library.gdmmeta.client.GdmStorageMetaRtClient;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.config.EnableMongoAuditing;

import javax.annotation.Nonnull;

@Configuration
@EnableMongoAuditing
@ComponentScan(basePackages = {
        "com.convertlab.foundation.gdmpattern.service"})
public class GdmMetaLocalClientConfigurationForTest {
    @Bean("localGsMetaClient")
    @Primary
    @ConditionalOnMissingBean(name = "localGsMetaClient")
    public GsMetaClient gsMetaClient(GeneralMetaService generalMetaService,
                                     GdmEntityMetaService gdmEntityMetaService,
                                     GdmRelationshipMetaService gdmRelationshipMetaService,
                                     GdmTableMetaService gdmTableMetaService) {
        GeneralMetaLocalClient localMetaClient = new GeneralMetaLocalClient(generalMetaService);
        GdmEntityMetaLocalClient localEntityClient = new GdmEntityMetaLocalClient(gdmEntityMetaService);
        GdmRelationshipMetaLocalClient localRelationshipClient = new GdmRelationshipMetaLocalClient(gdmRelationshipMetaService);
        GdmTableMetaLocalClient localTableClient = new GdmTableMetaLocalClient(gdmTableMetaService);
        return new GsMetaClient(localMetaClient, localEntityClient, localRelationshipClient, localTableClient);
    }

    @Nonnull
    @Primary
    @Bean("localGdmStorageMetaRtClient")
    @ConditionalOnMissingBean(name = "localGdmStorageMetaRtClient")
    public GdmStorageMetaRtClient gdmStorageRtMetaClient(GdmEntityMetaService gdmEntityMetaService, GdmTableMetaService gdmTableMetaService,
                                                         GsMetaClient gsMetaClient) {
        GdmEntityMetaLocalClient localEntityClient = new GdmEntityMetaLocalClient(gdmEntityMetaService);
        GdmTableMetaLocalClient localTableClient = new GdmTableMetaLocalClient(gdmTableMetaService);
//        GdmRelationshipMetaLocalClient localRelationshipClient = new GdmRelationshipMetaLocalClient(gdmRelationshipMetaService);
        return new GdmStorageMetaRtClient(localEntityClient, localTableClient,gsMetaClient);
    }
}
