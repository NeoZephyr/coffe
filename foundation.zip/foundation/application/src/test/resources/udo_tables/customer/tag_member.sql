create table cdp_ngdm.customer_tag
(
    tenant_id    INT(10),
    customer_id  STRING(32767),
    tag_id       BIGINT(19),
    date_created BIGINT(19),
    value_text   STRING(32767),
    value_num    DOUBLE(15
                     ) ,
    value_date BIGINT(19)
);