create table cdp_ngdm.list
(
    tenant_id    INT(10),
    id           BIGINT(19),
    version      BIGINT(19),
    auto_update  INT(10),
    is_static    INT(10),
    date_created BIGINT(19),
    last_updated BIGINT(19),
    name         STRING(32767),
    sort_by      STRING(32767),
    total        BIGINT(19),
    is_system    INT(10),
    deleted      INT(10),
    status       STRING(32767)
);