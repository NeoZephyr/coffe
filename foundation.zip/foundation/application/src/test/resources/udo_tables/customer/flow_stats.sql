create table cdp_ngdm.flow_stats
(
    tenant_id    INT(10),
    customer_id  STRING(32767),
    id           STRING(32767),
    field_date   BIGINT(19),
    flow_id      BIGINT(19),
    flow_version BIGINT(19),
    from_id      STRING(32767),
    to_id        STRING(32767),
    flow_inst_id STRING(32767)
);