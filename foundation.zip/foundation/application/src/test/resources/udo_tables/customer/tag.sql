create table cdp_ngdm.tags
(
    tenant_id    INT(10),
    id           BIGINT(19),
    version      BIGINT(19),
    name         STRING(32767),
    type         STRING(32767),
    dimension    STRING(32767),
    date_created BIGINT(19),
    last_updated BIGINT(19),
    sequence     INT(10),
    rule_id      BIGINT(19),
    status       STRING(32767),
    category     STRING(32767),
    value_able   INT(10),
    value_type   STRING(32767),
    ref_obj_id   STRING(32767),
    label_id     STRING(32767)
);