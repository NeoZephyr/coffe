create table cdp_ngdm.list_member
(
    tenant_id    INT(10),
    customer_id  STRING(32767),
    list_id      BIGINT(19),
    date_created BIGINT(19),
    last_updated BIGINT(19)
);