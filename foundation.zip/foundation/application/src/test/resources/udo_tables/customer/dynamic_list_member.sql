create table cdp_ngdm.dynamic_list_member
(
    customer_id STRING(32767),
    tenant_id   INT(10),
    list_id     BIGINT(19)
);