create table cdp_ngdm.general_dynamic_list_member
(
    bk        STRING(32767),
    obj_id    STRING(32767),
    tenant_id INT(10),
    list_id   BIGINT(19)
);