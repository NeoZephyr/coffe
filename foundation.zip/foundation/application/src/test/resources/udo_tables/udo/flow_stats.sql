create table cdp_ngdm.general_flow_stats
(
    tenant_id    INT(10),
    bk           STRING(32767),
    obj_id       STRING(32767),
    id           STRING(32767),
    field_date   BIGINT(19),
    flow_id      BIGINT(19),
    flow_version BIGINT(19),
    from_id      STRING(32767),
    to_id        STRING(32767),
    flow_inst_id STRING(32767)
);