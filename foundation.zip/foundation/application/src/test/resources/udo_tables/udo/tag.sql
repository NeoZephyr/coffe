create table cdp_ngdm.udo_tag
(
    tenant_id     INT(10),
    id            BIGINT(19),
    version       BIGINT(19),
    label_id      STRING(32767),
    label_name    STRING(32767),
    group_id      BIGINT(19),
    category      STRING(32767),
    multi_value   INT(10),
    value_type    STRING(32767),
    obj_id        STRING(32767),
    `count`       BIGINT(19),
    owner_id      INT(10),
    creator_id    INT(10),
    creator_name  STRING(32767),
    ref_obj_id    STRING(32767),
    ref_field_id  STRING(32767),
    status        STRING(32767),
    interval_type STRING(32767),
    has_options   INT(10),
    date_created  BIGINT(19),
    last_updated  BIGINT(19)
);