create table cdp_ngdm.udo_statistics
(
    tenant_id          INT(10),
    bk                 STRING(32767),
    obj_id             STRING(32767),
    attr_score         INT(10),
    event_score        INT(10),
    grade              STRING(32767),
    event_statistics   STRING(32767),
    event_accumulation STRING(32767),
    last_updated       BIGINT(19),
    date_created       BIGINT(19),
    active_score       INT(10)
);