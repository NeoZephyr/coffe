create table cdp_ngdm.general_list_member
(
    tenant_id    INT(10),
    bk           STRING(32767),
    list_id      BIGINT(19),
    obj_id       STRING(32767),
    date_created BIGINT(19),
    last_updated BIGINT(19)
);