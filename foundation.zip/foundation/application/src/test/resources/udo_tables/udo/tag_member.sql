create table cdp_ngdm.general_tag_member
(
    tenant_id  INT(10),
    bk         STRING(32767),
    tag_id     BIGINT(19),
    value_text STRING(32767),
    value_num  DOUBLE(15
                   ) ,
    value_date BIGINT(19),
    obj_id STRING(32767),
    date_created BIGINT(19),
    last_updated BIGINT(19),
    value_ref STRING(32767)
);