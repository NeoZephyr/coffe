package com.convertlab.foundation.misc.service.dao;

import com.convertlab.foundation.misc.service.HomeService;
import com.convertlab.foundation.misc.service.dao.HomeDao;
import com.convertlab.foundation.test.BaseTest;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;

@SpringBootTest
@Slf4j
@Tag("IntegrationTest")
class HomeDaoTest extends BaseTest {

    @Resource
    HomeDao homeDao;

    @Resource
    HomeService homeService;

    @Test
    void getDate() {
        log.info("Hello from homeDao: {}", homeDao.getDate());
        log.info("Hello from homeService: {}", homeService.greeting());
    }
}