package com.convertlab.foundation.gdmmeta.model.metaobject;


import javax.annotation.Nonnull;

public interface CustomerEventMetaObject extends ProfileEventMetaObject{

    String CUSTOMER_EVENT_TABLE_NAME = "customer_event";
    String EVENT_GROUP_FIELD_NAME = "event_group";
    String EVENT_GROUP_COLUMN_NAME = "event_group";

    @Nonnull
    @Override
    default String getTableName() {
        return CUSTOMER_EVENT_TABLE_NAME;
    }
}
