package com.convertlab.foundation.user.model;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.List;

@Data
public class JoinLeaveUserGroupRequest {
    public @NotEmpty List<Long> userList;
}
