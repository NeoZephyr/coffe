package com.convertlab.foundation.user.model;

import com.convertlab.foundation.user.entity.User;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import javax.validation.constraints.Size;

public final class UserDeptRoleComposite {
    public final Long id;
    @Size(max = 255)
    public String email;
    @Size(max = 512)
    public String loginName;
    @Size(max = 255)
    public String name;
    @Size(max = 255)
    public String phone;
    public String dept;
    public String role;

    public UserDeptRoleComposite(Long id, String email, String loginName, String name, String phone, String dept, String role) {
        this.id = id;
        this.email = email;
        this.loginName = loginName;
        this.name = name;
        this.phone = phone;
        this.dept = dept;
        this.role = role;
    }

    public void fillInUserData(User user) {
        this.email = user.getEmail();
        this.loginName = user.getLoginName();
        this.name = user.getName();
        this.phone = user.getPhone();
    }

    @Contract("_, _ -> param1")
    static public @NotNull UserDeptRoleComposite combineDeptAndRole(@NotNull UserDeptRoleComposite lhs, @NotNull UserDeptRoleComposite rhs) {
        // FIXME bad performance
        if (!lhs.dept.contains(rhs.dept)) {
            lhs.dept = lhs.dept + "," + rhs.dept;
        }
        if (!lhs.role.contains(rhs.role)) {
            lhs.role = lhs.role + "," + rhs.role;
        }
        return lhs;
    }
}
