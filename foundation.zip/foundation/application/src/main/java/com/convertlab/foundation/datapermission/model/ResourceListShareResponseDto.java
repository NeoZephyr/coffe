package com.convertlab.foundation.datapermission.model;

import javax.annotation.Nonnull;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Data
public class ResourceListShareResponseDto {

        private boolean shareToAllDept;

        private boolean shareToAllUserGroup;

        private boolean shareToAllUser;

        private boolean highSeas;

        @Nonnull
        private List<Map> users = new ArrayList<Map>();

        @Nonnull
        private List<Map> userGroups = new ArrayList<Map>();

        @Nonnull
        private List<Map> depts = new ArrayList<Map>();

}
