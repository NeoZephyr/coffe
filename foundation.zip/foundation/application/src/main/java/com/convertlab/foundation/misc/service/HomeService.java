package com.convertlab.foundation.misc.service;


import com.convertlab.foundation.misc.service.dao.HomeDao;

import java.time.Instant;

public interface HomeService {
    String greeting();

    boolean checkDesignTime();

    String benchmarkDbOperations(int count, long startId, HomeDao.BenchmarkMode mode);
    Long deleteMetaHistoryBefore(Instant from);
}
