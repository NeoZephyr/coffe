package com.convertlab.foundation.datapermission.controller.apiv2;

import lombok.Data;

import java.util.List;

@Data
public class Apiv2ResourceShareRequestDto {
    String resourceType;
    String resourceCode;
    List<String> deptCodes;
    List<String> groupCodes;
    Apiv2ResourceShareUserRequestDto users;
}
