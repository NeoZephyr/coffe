package com.convertlab.foundation.misc.service;

import com.convertlab.foundation.library.business.autoconfigure.SpringBeans;
import com.convertlab.foundation.library.support.Immutable;
import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Map;
import java.util.UUID;

import static com.convertlab.foundation.library.gdmmeta.model.general.BaseMetaSchema.CacheNames.GDM_META;

@RequiredArgsConstructor
@Service
public class LocalCacheTestService {
    @Cacheable(cacheNames = GDM_META, key = "#key", condition = "#key!=null", unless = "#result==null")
//    @Cacheable(cacheNames = "gdm:meta", key = "#key", cacheManager = "redisCacheManager")
    public ImmutableSampleDto getImmutable(String key) {
//        return key + ":" + UUID.randomUUID();
        Long id = 1L;
        String name = key + ":" + UUID.randomUUID();
        Date date = new Date();
        Map ext = Maps.newConcurrentMap();
        ext.put(String.valueOf(id), name);
        return new ImmutableSampleDto(id, name, date, true, ext);
    }

    @Cacheable(cacheNames = GDM_META, key = "#key", condition = "#key!=null", unless = "#result==null")
//    @Cacheable(cacheNames = "gdm:meta", key = "#key", cacheManager = "redisCacheManager")
    public MutableSampleDto getMutable(String key) {
//        return key + ":" + UUID.randomUUID();
        Long id = 1L;
        String name = key + ":" + UUID.randomUUID();
        Date date = new Date();
        Map ext = Maps.newConcurrentMap();
        ext.put(String.valueOf(id), name);
        return new MutableSampleDto(id, name, date, true, ext);
    }

    @Cacheable(cacheNames = "l2:demo", key = "#key", condition = "#key!=null", unless = "#result==null")
    public ImmutableSampleDto getL2(String key) {
        Long id = 1L;
        String name = key + ":" + UUID.randomUUID();
        Date date = new Date();
        Map ext = Maps.newConcurrentMap();
        ext.put(String.valueOf(id), name);
        return new ImmutableSampleDto(id, name, date, true, ext);
    }

    @Cacheable(cacheNames = "notifiable:demo", key = "#key", condition = "#key!=null", unless = "#result==null")
    public ImmutableSampleDto getNotifiableLocal(String key) {
        Long id = 1L;
        String name = key + ":" + UUID.randomUUID();
        Date date = new Date();
        Map ext = Maps.newConcurrentMap();
        ext.put(String.valueOf(id), name);
        return new ImmutableSampleDto(id, name, date, true, ext);
    }

    @CacheEvict(cacheNames = GDM_META, key = "#key", condition = "#key!=null")
    public void evict(String key) {

    }

    @CacheEvict(cacheNames = "l2:demo", key = "#key", condition = "#key!=null")
    public void l2Evict(String key) {

    }

    @CacheEvict(cacheNames = "notifiable:demo", key ="#key")
    public void notifiableEvict(String key) {

    }

    public long bulkPutCache(int size) {
        return timeElapsed(() -> {
            CacheManager cacheManager = SpringBeans.getBean(CacheManager.class);
            Cache cache = cacheManager.getCache(GDM_META);
            for (int i = 0; i < size; i++) {
                cache.put("key" + i, System.currentTimeMillis());
            }
        });
    }

    public long bulkDeleteCache() {
        return timeElapsed(() -> {
            CacheManager cacheManager = SpringBeans.getBean(CacheManager.class);
            Cache cache = cacheManager.getCache(GDM_META);
            cache.evict("*");
        });
    }

    @AllArgsConstructor
    @Getter
    public static final class ImmutableSampleDto implements Immutable {
        private Long id;
        private String name;
        private Date date;
        private Boolean isSuperMan;
        private Map<String, Object> ext;
    }

    @AllArgsConstructor
    @Data
    public static class MutableSampleDto {
        private Long id;
        private String name;
        private Date date;
        private Boolean isSuperMan;
        private Map<String, Object> ext;
    }

    public long timeElapsed(Runnable runnable) {
        long start = System.currentTimeMillis();
        runnable.run();
        return (System.currentTimeMillis() - start) / 1000;
    }
}
