package com.convertlab.foundation.gdmmeta.model.metaobject;

import javax.annotation.Nonnull;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.util.CollectionUtils;

import com.convertlab.foundation.gdmmeta.model.Field;

import lombok.*;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class SystemMetaCorrectionObject {
    List<EntityOps> entityOpsList;

    @Data
    static class EntityOps {

        String entityName;
        ColumnListOps dbStruct;
        FieldListOps legacyMeta;
    }

    @Data
    public static class ColumnListOps {
        FilterColumnsOps  filterColumns;

    }

    @Data
    public static class FilterColumnsOps {
        List<String> excludedList;
        List<String> includedList;
    }

    @Data
    public static class FieldListOps {

        FilterFieldsOps filterFields;
        List<FieldOps> correctFields;
        List<Field> appendFields;
    }

    @Data
    @Getter
    public static class FilterFieldsOps {
        List<String> excludedList;
        List<String> includedList;
    }

    @Data
    @Getter
    public static class FieldOps {
        String fieldName;
        String fieldAttrName;
        String oldValue;
        String newValue;
    }


   @Nonnull
   public Optional<EntityOps> getEntityOpsOpt(String entityName) {
       Optional<EntityOps> entityOpsOpt;
       entityOpsOpt = entityOpsList.stream().filter(
               entityOps -> entityOps.getEntityName().equals(entityName)).findAny();
       return entityOpsOpt;
   }

   @Nonnull
   public List<String> getGlobalIgnoreDdColumns() {
       Optional<EntityOps> global = getEntityOpsOpt("_global");
       if (global.isPresent()
               && global.get().getDbStruct() != null
               && global.get().getDbStruct().getFilterColumns() != null) {
           List<String> excludedList = global.get().getDbStruct().getFilterColumns().getExcludedList();
           boolean excludedFieldsIsNotExists = CollectionUtils.isEmpty(excludedList);
           if(!excludedFieldsIsNotExists) {
               return excludedList;
           }
       }
       return Collections.emptyList();
   }

    @Nonnull
    public List<Field> filterAndCorrectFields(String entityName, @Nonnull final List<Field> dbFields) {
        List<Field> result = new ArrayList<>(dbFields);
        //do not change original Field list
        Optional<EntityOps> entityOpsOpt = getEntityOpsOpt(entityName);
        if (!entityOpsOpt.isPresent() || entityOpsOpt.get().getLegacyMeta() == null) {
            return result;
        }
        FieldListOps fieldListOps = entityOpsOpt.get().getLegacyMeta();
        FilterFieldsOps filterFields = fieldListOps.getFilterFields();
        List<FieldOps> correctFields = fieldListOps.getCorrectFields();
        List<Field> appendFields = fieldListOps.getAppendFields();
        if (filterFields == null && correctFields == null) {
            return result;
        }

        List<Field> retRef = new ArrayList<>(result);
        if (filterFields != null) {
            List<String> excludedList = filterFields.getExcludedList();
            List<String> includedList = filterFields.getIncludedList();

            if (!CollectionUtils.isEmpty(includedList)) {
                retRef = retRef.stream().filter(
                        field -> includedList.contains(field.getFieldName())).collect(Collectors.toList());
            } else if (!CollectionUtils.isEmpty(excludedList)) {
                retRef = retRef.stream().filter(
                        field -> !excludedList.contains(field.getFieldName())).collect(Collectors.toList());
            }
        }

        if (!CollectionUtils.isEmpty(correctFields)) {
            Map<String, List<FieldOps>> fieldOpsMap = correctFields.stream()
                    .collect(Collectors.groupingBy(FieldOps::getFieldName));

            List<Field> finalRetRef = retRef;
            int retLen = finalRetRef.size();
            fieldOpsMap.forEach((fieldName, fieldOpsList) -> {
                OptionalInt idxOpt = IntStream.range(0, retLen).filter(
                        idx -> finalRetRef.get(idx).getFieldName().equals(fieldName)).findAny();
                if (idxOpt.isPresent()) {
                    int idx = idxOpt.getAsInt();
                    Field newField = new Field(finalRetRef.get(idx));
                    newField.updateAttrs(entityName, fieldOpsList);
                    finalRetRef.set(idx, newField);
                }
            });
        }

        if (!CollectionUtils.isEmpty(appendFields)) {
            Set<String> existedFields = retRef.stream().map(Field::getFieldName).collect(Collectors.toSet());
            for (Field field: appendFields) {
                if (existedFields.contains(field.getFieldName())) {
                    log.warn("Ignore append field as it exists, the existed field {}", field.getFieldName());
                } else  {
                    retRef.add(field);
                }
            }
        }

        return retRef;
   }

    @Nonnull
    public List<Field> filterColumns(String entityName, @Nonnull final List<Field> dbFields) {
        //do not change original Field list
        List<Field> retRef = new ArrayList<>(dbFields);
        Optional<EntityOps> entityOpsOpt = getEntityOpsOpt(entityName);
        if (!entityOpsOpt.isPresent() || entityOpsOpt.get().getDbStruct() == null) {
            return retRef;
        }
        ColumnListOps columnListOps = entityOpsOpt.get().getDbStruct();
        FilterColumnsOps filterColumns = columnListOps.getFilterColumns();
        if (filterColumns == null) {
            return retRef;
        }

        List<String> excludedList = filterColumns.getExcludedList();
        List<String> includedList = filterColumns.getIncludedList();

        if (!CollectionUtils.isEmpty(includedList)) {
            retRef = retRef.stream().filter(
                    field -> includedList.contains(field.getDbColumnName())).collect(Collectors.toList());
        } else if (!CollectionUtils.isEmpty(excludedList)) {
            retRef = retRef.stream().filter(
                    field -> !excludedList.contains(field.getDbColumnName())).collect(Collectors.toList());
        }

        return retRef;
    }

    String semanticVersion;
}
