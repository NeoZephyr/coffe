package com.convertlab.foundation.datapermission.controller.apiv2;

import com.convertlab.foundation.datapermission.entity.ResourceEntity;
import com.convertlab.foundation.datapermission.model.DeleteShareRequestDto;
import com.convertlab.foundation.datapermission.model.ResourceShareRequestDto;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.datapermission.model.ResourceMeta;
import com.convertlab.foundation.library.datapermission.service.ResourceMetaService;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.webmvc.annotation.OpenApiController;
import com.convertlab.foundation.library.webmvc.annotation.SkipRequestBodyAdvice;
import com.convertlab.foundation.user.entity.Dept;
import com.convertlab.foundation.user.entity.User;
import com.convertlab.foundation.user.entity.UserGroup;
import com.convertlab.foundation.user.service.DeptService;
import com.convertlab.foundation.user.service.UserGroupService;
import com.convertlab.foundation.user.service.UserService;
import com.convertlab.foundation.user.utils.BuiltInDept;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.convertlab.foundation.datapermission.service.ResourceService;

@OpenApiController
@SkipRequestBodyAdvice
public class ResourceApiv2RequestController {

    final ResourceService resourceService;
    final DeptService deptService;
    final UserGroupService userGroupService;
    final UserService userService;
    final ResourceMetaService resourceMetaService;


    public ResourceApiv2RequestController(ResourceService resourceService, DeptService deptService, UserGroupService userGroupService, UserService userService, ResourceMetaService resourceMetaService) {
        this.resourceService = resourceService;
        this.deptService = deptService;
        this.userGroupService = userGroupService;
        this.userService = userService;
        this.resourceMetaService = resourceMetaService;
    }

    //save方法

    @Nonnull
    @PostMapping("/apiv2/dp/resource/share")
    public Apiv2ResourceShareResponseDto share(@Nonnull @RequestBody Apiv2ResourceShareRequestDto dto) {

        validateOutCodes(dto.getDeptCodes());
        validateGroupCodes(dto.getGroupCodes());
        validateUserInfo(dto.getUsers());
        validateResourceInfo(dto.getResourceType(), dto.getResourceCode());

        List<String> deptCodes = convertToInternalCodes(dto.getDeptCodes());
        List<String> groupCodes = dto.getGroupCodes();
        List<Integer> userIds = convertToInternalUserIds(dto.getUsers());

        ResourceShareRequestDto shareRequestDto = new ResourceShareRequestDto();
        shareRequestDto.setResourceType(dto.getResourceType());
        shareRequestDto.setResourceCode(dto.getResourceCode());
        shareRequestDto.setAccessLevel("all");
        shareRequestDto.setUserIds(userIds);
        shareRequestDto.setGroupCodes(groupCodes);
        shareRequestDto.setDeptCodes(deptCodes);

        resourceService.internal_share(shareRequestDto);

        Apiv2ResourceShareResponseDto responseDto = new Apiv2ResourceShareResponseDto();
        responseDto.setResourceType(dto.getResourceType());
        responseDto.setResourceCode(dto.getResourceCode());
        return responseDto;
    }


    private void validateResourceInfo(String resourceType, String resourceCode){
        //如果resourceType或者resourceCode为空，则返回错误信息。
        if (StringUtils.isBlank(resourceType) || StringUtils.isBlank(resourceCode)) {
            throw new BusinessException(CommonErrors.MISSING_FIELD, "MSG_005_000001", "resourceType is empty or resourceCode is empty.", new String[]{});
        }

        //根据resourceType获取metadata
        ResourceMeta resourceMeta = resourceMetaService.getResourceMeta(resourceType);

        //如果resource meta为空， 返回错误信息。
        if (resourceMeta == null) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_005_000002", String.format("resource type %s not support", resourceType), new String[]{resourceType});
        }

        //找到数据
        ResourceEntity entity = resourceService.findEntity(resourceMeta, resourceCode);
        //如果entity 为空， 返回错误信息
        if (entity == null) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_005_000005", String.format("resource %s, %s not exist", resourceType, resourceCode), new String[]{resourceType, resourceCode});
        }
    }

    private void validateOutCodes(List<String> outDeptCodes){

        //如果输入的outDeptCodes为空，直接返回
        if(CollectionUtils.isEmpty(outDeptCodes)){
            return;
        }

        List<Dept> depts = deptService.getDeptsByOutCodeList(outDeptCodes);

        //判断是否存在无效的dept code
        if (depts.size() != outDeptCodes.size()) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_005_000015", "exists invalid dept code.", new String[]{});
        }

        //判断dept是否存在最上级别的部门，如果存在，抛出异常
        for (Dept dept : depts) {
            if (dept.getCode().equals(BuiltInDept.TOP_DEPT_CODE)) {
                throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_005_000016", "do not support share to top dept.", new String[]{});
            }
        }
    }

    private void validateGroupCodes(List<String> groupCodes){

        //如果输入的groupCodes为空，直接返回
        if(CollectionUtils.isEmpty(groupCodes)){
            return;
        }

        List<UserGroup> groups = userGroupService.getUserGroupByCodeList(groupCodes);

        //判断是否存在无效的group code
        if (groups.size() != groupCodes.size()) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_005_000017", "exists invalid group code.", new String[]{});
        }
    }

    private void validateUserInfo(Apiv2ResourceShareUserRequestDto users){

        //如果users为空，直接返回
        if (users == null) {
            return;
        }

        String identityType = users.getIdentityType();
        List<String> identityValues = users.getIdentityValues();

        //如果users不为空，则检查identityType和identityValues是否为空，如果为空，抛出异常
        if (StringUtils.isBlank(identityType) || CollectionUtils.isEmpty(identityValues)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_005_000018", "parameter identityType, identityValues invalid", new String[]{});
        }

        List<User> userList = null;
        if ("email".equals(users.getIdentityType())) {
            userList = userService.findAllByEmailInList(identityValues);
        } else if ("phone".equals(users.getIdentityType())) {
            userList = userService.findAllByPhoneInList(identityValues);
        } else {
            //如果identityType不是email或者phone，抛出异常
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_005_000019", String.format("identityType %s is invalid", identityType), new String[]{identityType});
        }

        //如果userList为空，抛出异常
        if (CollectionUtils.isEmpty(userList)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_005_000020", "not exists invalid users", new String[]{});
        }

        if (userList.size() != identityValues.size()) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_005_000021", "exists invalid users", new String[]{});
        }

    }

    private List<String> convertToInternalCodes(List<String> outDeptCodes) {

        if (CollectionUtils.isEmpty(outDeptCodes)) {
            return new ArrayList<>();
        }

        List<Dept> depts = deptService.getDeptsByOutCodeList(outDeptCodes);
        List<String> internalCodes = new ArrayList<>();
        depts.forEach(dept -> {
            internalCodes.add(dept.getCode());
        });
        return internalCodes;
    }

    private List<Integer> convertToInternalUserIds(Apiv2ResourceShareUserRequestDto users) {
        List<Integer> userIds = new ArrayList<>();
        if (users == null) {
            return userIds;
        }

        List<String> identityValues = users.getIdentityValues();

        List<User> userList = null;
        if ("email".equals(users.getIdentityType())) {
            userList = userService.findAllByEmailInList(identityValues);
        } else if ("phone".equals(users.getIdentityType())) {
            userList = userService.findAllByPhoneInList(identityValues);
        }

        if (CollectionUtils.isEmpty(userList)) {
            return userIds;
        }

        userList.forEach(user -> {
            userIds.add(Integer.valueOf(user.getId().toString()));
        });

        return userIds;
    }


    @Nullable
    @DeleteMapping("/apiv2/dp/resource/deleteShare")
    public Map<String, String> deleteShare(@Nonnull @RequestBody DeleteShareRequestDto dto) {
        //add logic to compatible for v1 api.
        if("userGroup".equals(dto.getAccessScope())){
            dto.setAccessScope("group");
        }
        return resourceService.deleteShareInternal(dto);
    }

}
