package com.convertlab.foundation.user.mapper;


import com.baomidou.mybatisplus.annotation.InterceptorIgnore;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.foundation.user.entity.User;
import com.convertlab.foundation.user.entity.UserInfo;
import com.convertlab.foundation.user.entity.UserTenant;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface UserMapper extends BaseMapper<UserTenant> {

    @Select("<script>select u.user_id FROM (SELECT user_id FROM user_tenant UNION SELECT id AS user_id FROM user) u where u.user_id = #{userId}</script>")
    List<Long> getUserTenantByUserId(long userId);

    @Select("<script>select u.user_id FROM (SELECT user_id FROM user_tenant UNION SELECT id AS user_id FROM user) u where u.user_id in <foreach item='item' index='index' collection='userIds' open='(' separator=',' close=')'>#{item}</foreach></script>")
    List<Long> getUserTenantByIdList(List<Long> userIds);

    @InterceptorIgnore(tenantLine = "true")
    @Select("<script>SELECT * FROM user WHERE id IN <foreach item='item' index='index' collection='idList' open='(' separator=',' close=')'>#{item}</foreach><if test='name!=null and name!=\"\"'> and name LIKE CONCAT(CONCAT('%',#{name}),'%')</if></script>")
    List<User> getUserByIdList( @Param("idList") List<Long> idList, @Param("name") String name);

//    @InterceptorIgnore(tenantLine = "true")
//    @Select("SELECT * FROM user WHERE id = #{userId}")
//    UserInfo getUserInfo(@Param("userId") Integer userId);

}

