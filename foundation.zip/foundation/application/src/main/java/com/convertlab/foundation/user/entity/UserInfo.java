package com.convertlab.foundation.user.entity;

import lombok.Data;

@Data
public class UserInfo {

    private Long id;

    private String email;

    private String img;

    private String loginName;

    private String name;

    private String phone;

    private String status;

    private Boolean firstLogin;

    private Boolean emailVerified;

    private Boolean phoneVerified;

    private Boolean eulaAccepted;

}
