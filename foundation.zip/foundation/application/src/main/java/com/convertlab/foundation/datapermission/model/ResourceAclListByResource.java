package com.convertlab.foundation.datapermission.model;

public class ResourceAclListByResource {
}
