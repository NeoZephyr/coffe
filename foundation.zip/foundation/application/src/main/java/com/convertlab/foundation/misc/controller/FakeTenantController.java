package com.convertlab.foundation.misc.controller;

import com.convertlab.foundation.library.gdmmeta.validation.ValidationException;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.multitenancy.exception.IllegalTenantIdException;
import com.convertlab.foundation.library.tenantlifecycle.exception.LifecycleErrors;
import com.convertlab.foundation.library.tenantlifecycle.exception.TenantNotFoundException;
import com.convertlab.foundation.library.tenantlifecycle.model.CreateTenantRequest;
import com.convertlab.foundation.library.tenantlifecycle.model.LifecycleResponse;
import com.convertlab.foundation.library.tenantlifecycle.model.SuspendTenantRequest;
import com.convertlab.foundation.library.tenantlifecycle.model.TenantDto;
import com.convertlab.foundation.library.tenantlifecycle.spi.TenantLifecycleSpi;
import com.convertlab.foundation.library.utils.ErrorUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Objects;

@RestController
@Tag(name = "API Specs")
@RequestMapping("/specs/v1/lifecycle")
public class FakeTenantController implements TenantLifecycleSpi {
    private static final String MODULE_NAME = "fake-tenant-lifecycle";

    @Override
    @Operation(summary = "模拟创建租户", description = "创建租户(检查header里的租户是否和tenantDto里面的一致)，成功返回.")
    public LifecycleResponse createTenant(CreateTenantRequest request) {
        validate(request);

        LifecycleResponse lifecycleResponse = new LifecycleResponse(TenantContextHolder.getTenantIdExt(), "001",
                "Success");
        return lifecycleResponse;
    }

    @Override
    @Operation(summary = "模拟暂停租户", description = "暂停租户(检查header里的租户是否和tenantDto里面的一致). " +
            "如果租户=1，为了演示如何通过错误码找到错误原因，返回的message" +
            "是使用ErrorUtils.findErrorByCode()的结果; 如果租户=2，演示如果租户不存在，抛出异常，")
    public LifecycleResponse suspendTenant(SuspendTenantRequest request) {
        validate(request);
        switch (TenantContextHolder.getTenantIdExt().intValue()) {
            case 1:
                LifecycleResponse lifecycleResponse = new LifecycleResponse(TenantContextHolder.getTenantIdExt(),
                        "001", "ErrorUtils.findErrorByCode(\"0100001\", LifecycleErrors.class).toString()=" +
                        ErrorUtils.findErrorByCode("0100001", LifecycleErrors.class).toString());
                return lifecycleResponse;
            case 2:
                TenantNotFoundException exception = new TenantNotFoundException();
                exception.setMessageArguments(new String[]{"查了这里，没找到", "查了那里，也没找到"});
                throw exception;
            default:
                LifecycleResponse lifecycleResponse1 = new LifecycleResponse(TenantContextHolder.getTenantIdExt(),
                        "001", "Success");
                return lifecycleResponse1;
        }
    }

    private void validate(TenantDto tenantDto) {
        if (!Objects.equals(TenantContextHolder.getTenantIdExt(), tenantDto.getTenantId())) {
            throw new IllegalTenantIdException();
        }
        if (!tenantDto.getModule().equalsIgnoreCase(MODULE_NAME)) {
            throw new ValidationException("Module name does not match. My name is " + MODULE_NAME + " but you said " +
                    tenantDto.getModule() + ".");
        }
    }
}
