package com.convertlab.foundation.gdmpattern.service;

import java.util.*;
import java.util.stream.Collectors;

import static com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto.*;

/**
 * 这里放的是面向业务的约束条件，不是 GDM 框架本身的约束，例如：对于会员，虽然也算是 Profile，但是只能使用 MEMBER_UDO 的Provision Type，即使用ly_member1来创建
 */
public class Constraints {
    private Constraints(){}
    /**
     * 获取指定 GDM 模式的首选 Provision Type。<br/>
     * 从GDM的设计原则上讲，这里需要判断的是ProvisionType背后的物理表是否包含Pattern搜需要的所有字段，例如<br/>
     * Profile的要求是物理表上有id字段和可定制字段(着实是一个很宽松的需求)，那么把一个Profile对象provision到member表完全是可以的。<br/>
     * 以下的代码主要目的是：让其他开发、实施人员更容易理解表的内容，甚至脱离GDM框架操作物理表(允许，但是不鼓励！)<br/>
     * 内部逻辑：
     *      pattern.contains(platform_member) -> platform_member_udo
     *      pattern.contains(omni_member) -> omni_member_udo
     *      pattern.contains(member_card) -> member_card_udo
     *      GivenType = null -> udo
     *      pattern.contains(profile/adhoc) -> GivenType(给啥就返回啥,可能有udo/nudo几种)
     *      Other -> ndo
     *
     * @param patterns  patterns
     * @param givenType 请求的 ProvisionType
     * @return Provision Type (UDO/PLATFORM_MEMBER_UDO/...)
     */
    public static ProvisionType getPreferredProvisionType(String[] patterns, ProvisionType givenType) {
        Set<String> patterSet = Arrays.stream(patterns).map(String::toLowerCase).map(String::trim).collect(Collectors.toSet());
        if (patterSet.contains(PATTERN_PLATFORM_MEMBER.getName()))
            return ProvisionType.PLATFORM_MEMBER_UDO;
        if (patterSet.contains(PATTERN_OMNI_MEMBER.getName()))
            return ProvisionType.OMNI_MEMBER_UDO;
        if (patterSet.contains(PATTERN_MEMBER_CARD.getName()))
            return ProvisionType.MEMBER_CARD_UDO;
        if (givenType == null)
            return ProvisionType.UDO;
        if (patterSet.contains(PATTERN_PRIMARY_PROFILE.getName()) ||
                patterSet.contains(PATTERN_GENERAL_PROFILE.getName()) ||
                patterSet.contains(PATTERN_AD_HOC.getName()))
            return givenType;
        return ProvisionType.UDO;
    }
}
