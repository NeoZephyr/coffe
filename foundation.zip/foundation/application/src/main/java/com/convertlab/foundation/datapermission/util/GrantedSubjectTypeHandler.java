package com.convertlab.foundation.datapermission.util;

import com.convertlab.foundation.library.datapermission.GrantedSubjectType;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.TypeHandler;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GrantedSubjectTypeHandler extends BaseTypeHandler<GrantedSubjectType> {
    @Override
    public void setNonNullParameter(PreparedStatement ps, int i, GrantedSubjectType parameter, JdbcType jdbcType) throws SQLException {
        ps.setString(i, parameter.getValue());
    }

    @Override
    public GrantedSubjectType getNullableResult(ResultSet rs, String columnName) throws SQLException {
        String value = rs.getString(columnName);
        return GrantedSubjectType.fromValue(value);
    }

    @Override
    public GrantedSubjectType getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
        String value = rs.getString(columnIndex);
        return GrantedSubjectType.fromValue(value);
    }

    @Override
    public GrantedSubjectType getNullableResult(CallableStatement cs, int columnIndex) throws SQLException {
        String value = cs.getString(columnIndex);
        return GrantedSubjectType.fromValue(value);
    }
}
