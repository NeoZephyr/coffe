package com.convertlab.foundation.gdmmeta.model;

import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.storage.Storage;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Map;


/**
 * 从 Entity 中分离出读取 register 文件的用途。
 * 避免 {@link Storage} 影响全链路.
 *
 * 是对文件结构的映射。不会在处理链路中被使用。
 *
 * 这个类不会用到 {@link com.convertlab.foundation.library.constant.DataProcessingMode}
 *
 */
public class RegisteredEntity extends Entity {


}
