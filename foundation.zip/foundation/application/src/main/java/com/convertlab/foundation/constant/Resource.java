package com.convertlab.foundation.constant;


import lombok.Getter;

@Getter
public enum Resource {

    CUSTOMER("customer", "客户", "客戶"),
    LIST("list", "群组", "群組"),
    TAGS("tags", "客户标签", "客戶標籤"),

    WECHAT_PUB_ACCOUNT("wechat_pub_account", "微信公众号", "微信公眾號"),
    WECHAT_APP_ACCOUNT("wechat_app_account", "微信小程序", "微信小程序"),
    WECHAT_PAY_ACCOUNT("wechat_pay_account", "商户号", "商戶號"),
    QRCODE("wechat_qrcode", "公众号二维码", "公眾號QR Code"),
    WECHAT_TEMPLATE("wechat_template", "公众号模板消息", "公眾號模板消息"),
    WECHAT_CARD("wechat_card", "微信卡券", "微信卡券"),
    WECHAT_REDPACK("wechat_redpack", "微信红包", "微信紅包"),

    PAGE("page", "微页面", "微頁面"),
    FORM("form", "表单", "表單"),

    EMAIL("email", "电子邮件", "電子郵件"),
    SMS_SIGNATURE("sms_signature", "短信签名", "簡訊簽名"),
    SMS_CHANNEL("sms_channel", "短信通道", "簡訊通道"),
    SMS_ACCOUNT("sms_account", "短信账户", "簡訊帳戶"),
    SMS("sms", "短消息", "簡訊"),
//    SMS_ChANNEL_GROUP("sms_channel_group","短信通道组",new Table[]{Table.SMS_CHANNEL_GROUP}),

    APP_PUSH("app push", "App Push", "App Push"),

    FILE("file", "文件", "文件"),

    WEBHOOK("webhook", "Webhook", "Webhook"),

    PROMO_INFO("promo_info", "权益码", "權益碼"),
    LUCKY_DRAW("lucky_draw", "抽奖活动", "抽獎活動"),

    MARKETING_CAMPAIGN("marketing_campaign", "营销活动", "營銷活動"),

    FLOW("workflow", "自动流程", "自動流程"),

    DASHBOARD("dashboard", "数据看板", "數據看板"),

    FOLDER("folder", "分组"),
    TAG_DIMENSION("tag_dimension", "标签分组"),
    CUSTOMER_SEARCH("customer_search", "客户筛选"),
    MEDIA_RESOURCE("media_resource", "素材资源"),
    URL_TRACKER_URL("url_tracker_url", "网页可跟踪URL"),
    URL_TRACKER_WECHAT_APP("url_tracker_wechat_app", "小程序可跟踪URL"),
    VMS_TEMPLATE("vms_template", "视频短信"),
    MMS_TEMPLATE("mms_template", "彩信"),
    WECHAT_MINI_PROGRAM_TEMPLATE("wechat_mini_program_template", "微信小程序订阅通知");

    Resource(String resourceCategory, String resourceLabel) {
        this.resourceLabel = resourceLabel;
        this.resourceCategory = resourceCategory;
    }

    Resource(String resourceCategory, String resourceLabel, String resourceEnLabel, String resourceTwLabel) {
        this.resourceLabel = resourceLabel;
        this.resourceEnLabel = resourceEnLabel;
        this.resourceTwLabel = resourceTwLabel;
        this.resourceCategory = resourceCategory;
    }

    Resource(String resourceCategory, String resourceLabel, String resourceTwLabel) {
        this(resourceCategory, resourceLabel, "", resourceTwLabel);
    }

    final String resourceLabel;
    String resourceEnLabel;
    String resourceTwLabel;
    final String resourceCategory;

}