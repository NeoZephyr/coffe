package com.convertlab.foundation.kvstore.dto;

import javax.annotation.Nonnull;

import lombok.Data;
import lombok.ToString;

import java.util.List;
import java.util.Map;

@Data
public class KvQuery {
    List<String> keys;

    // 需要查询的列，如果为空，或者null，就是读取所有的列
    List<String> columns;

    @Nonnull
    @Override
    public String toString() {
        StringBuilder stringBuffer = new StringBuilder();
        stringBuffer.append("{\"keys\": [\"" + String.join( "\",\"", keys) + "\"], ");
        stringBuffer.append("\"columns\": [\"" + String.join( "\",\"", columns) + "\"]}");
        return stringBuffer.toString();
    }
}
