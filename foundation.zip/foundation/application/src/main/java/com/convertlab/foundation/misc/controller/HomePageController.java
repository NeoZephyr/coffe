package com.convertlab.foundation.misc.controller;

import com.convertlab.foundation.library.business.eventbroker.NotificationEvent;
import com.convertlab.foundation.library.business.eventbroker.RemoteNotificationEvent;
import com.convertlab.foundation.library.constant.ComponentNames;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.webmvc.swagger.DeptAuthentication;
import com.convertlab.foundation.library.webmvc.swagger.TenantAuthentication;
import com.convertlab.foundation.library.webmvc.swagger.UserAuthentication;
import com.convertlab.foundation.misc.dto.DiaryTemplate;
import com.convertlab.foundation.misc.service.*;
import com.convertlab.foundation.misc.service.dao.HomeDao;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.slf4j.MDC;
import org.springframework.boot.info.BuildProperties;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.ws.rs.QueryParam;
import java.time.Instant;

/**
 * HomePageController用来存放不属于业务Controller的杂项配置
 * 1. 开发时的api主页，提供工具链接，例如swagger-ui
 * 2. Swager-ui的配置, 通过@OpenAPIDefinition定义, 通过@SecurityRequirement引用;在HomePage上挂载TenantID和UserID的验证。
 */

// @OpenAPIDefinition是一个全局的swagger配置，可以在这里配置所有的swagger基本信息。
@RestController
@OpenAPIDefinition(
        info = @io.swagger.v3.oas.annotations.info.Info(
                title = "Foundation API", version = "1.0", description = "A collection of APIs for Foundation."
        ),
        security = {
                @SecurityRequirement(name = "tenantId"),
                @SecurityRequirement(name = "userDept"),
                @SecurityRequirement(name = "userId")
        }
)
// 虽然这里没有使用到TenantAuthentication和UserAuthentication，但是这里的@SecurityRequirement(name = "tenantId")
// 和@SecurityRequirement(name = "userId")会被swagger-ui读取到。 并且在swagger-ui的页面上会显示出来。
// 其他的API也会从此获益，因为这里的配置是全局的。
@RequiredArgsConstructor
public class HomePageController implements TenantAuthentication, UserAuthentication, DeptAuthentication {
    private final HomeService homeService;
    private final SomeService someService;
    private final LocalCacheTestService localCacheTestService;
    private final RedisLockTestService redisLockTestService;
    private final DiaryTemplateService diaryTemplateService;
    private final GsMetaClient metaClient;
    private final BuildProperties buildProperties;

    @GetMapping("/")
    @Operation(summary = "首页", description = "首页")
    public String greeting() {
        return homeService.greeting();
    }

    @GetMapping(value = "/peek", produces = "text/plain")
    @Operation(summary = "查看处理过的消息", description = "SomeService会接收NotificationEvent，处理后把消息放在了某处，" +
            "这里可以查看处理过的消息。首页是系统消息，大家都能看；创建meta是租户消息，只能是同一个租户才能看。试试看在租户1创建" +
            "一个对象，然后用租户2的身份来peek一下。😜")
    public String peek() {
        return someService.peek();
    }

    @PostMapping("/sendAnyNotification")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            content = @io.swagger.v3.oas.annotations.media.Content(
                    mediaType = "application/json",
                    examples = {@ExampleObject(
                            name = "完整版",
                            value = "{\n" +
                                    "  \"dto\": {\n" +
                                    "    \"name\": \"随便你\"\n" +
                                    "   },\n" +
                                    "  \"messageId\": \"DEFAULT_UUID_001\",\n" +
                                    "  \"type\": \"DEMO_EVENT\",\n" +
                                    "  \"subType\": \"DEFAULT_EVENT_SUBTYPE\",\n" +
                                    "  \"publisher\": \""+ ComponentNames.DEMO_ONLY +"\",\n" +
                                    "  \"subscriber\": \""+ NotificationEvent.ANY_SUBSCRIBER +"\",\n" +
                                    "  \"propagationStrategy\": \"PER_SERVICE\",\n" +
                                    "  \"loggableContent\": \"Just a demo event\",\n" +
                                    "  \"classType\": \"com.convertlab.foundation.library.business.eventbroker.DemoEvent\"" +
                                    "}"
                    ),
                            @ExampleObject(
                                    name = "简洁版多参数",
                                    value = "{\n" +
                                            "   \"dto\": {\n" +
                                            "   \"name\": \"随便你\"\n" +
                                            "   },\n" +
                                            "  \"classType\": \"com.convertlab.foundation.library.business.eventbroker.DemoEvent\"" +
                                            "}"
                            )
                    }
            )
    )
    @Operation(summary = "演示发送任意消息", description = "注意，仅仅只是演示用，不要开放API来专门发消息，没有意义！！！")
    public void sendAny(@RequestBody @Valid RemoteNotificationEvent event,
                        @RequestParam(required = false, defaultValue = "1")
                        @io.swagger.v3.oas.annotations.Parameter(description = "重复发送次数,", example = "1")
                        int repeat) {
        if (repeat > 0)
            someService.sendAnyEvent(event);
        if (repeat > 1) {
            for (int i = 0; i < repeat - 1; i++) {
                RemoteNotificationEvent dupEvent = event.toBuilder().messageId(null).build();
                someService.sendAnyEvent(dupEvent);
            }
        }
    }
/*
    @PostMapping("/caches")
    public long bulkPutCache(@RequestParam(required = false, defaultValue = "1000000") int size) {
        return localCacheTestService.bulkPutCache(size);
    }

    @DeleteMapping("/caches")
    public long bulkDeleteCache() {
        return localCacheTestService.bulkDeleteCache();
    }

    @GetMapping("/caches/immutable/{key}")
    public LocalCacheTestService.ImmutableSampleDto getImmutableFromCache(@PathVariable("key") String key) {
        return localCacheTestService.getImmutable(key);
    }

    @GetMapping("/caches/mutable/{key}")
    public LocalCacheTestService.MutableSampleDto getMutableFromCache(@PathVariable("key") String key) {
        return localCacheTestService.getMutable(key);
    }

    @GetMapping("/caches/l2/{key}")
    public LocalCacheTestService.ImmutableSampleDto getL2Cache(@PathVariable("key") String key) {
        return localCacheTestService.getL2(key);
    }

    @GetMapping("/caches/notifiable/{key}")
    public LocalCacheTestService.ImmutableSampleDto getNotifiableCache(@PathVariable("key") String key) {
        return localCacheTestService.getNotifiableLocal(key);
    }

    @Operation(summary = "根据KEY删除gdm:meta下的缓存", description = "根据KEY删除gdm:meta下缓存")
    @DeleteMapping("/caches/{key}")
    public void evict(@PathVariable("key")  @io.swagger.v3.oas.annotations.Parameter(description = "meta的key，具体的名称需要查看@Cacheable标注的代码中key的定义方式。", example = "table:customer") String key) {
        localCacheTestService.evict(key);
    }

    @DeleteMapping("/caches/l2/{key}")
    public void l2Evict(@PathVariable("key") String key) {
        localCacheTestService.l2Evict(key);
    }

    @DeleteMapping("/caches/notifiable/{key}")
    public void notifiableEvict(@PathVariable("key") String key) {
        localCacheTestService.notifiableEvict(key);
    }


    @GetMapping("/lock/{key}")
    public boolean testLock(@PathVariable("key") String key) {
        return redisLockTestService.testLock(key);
    }

    @GetMapping("/lock_annotation/{key}")
    public boolean testLockWithAnnotation(@PathVariable("key") String key) {
        return redisLockTestService.testLockWithAnnotation(key);
    }
*/
    @PostMapping("/diaryTemplates")
    public DiaryTemplate createDiaryTemplate(@RequestBody DiaryTemplate diaryTemplate) {
        return diaryTemplateService.createTemplate(diaryTemplate);
    }

    @GetMapping("/diaryTemplates/{name}")
    public DiaryTemplate getDiaryTemplate(@PathVariable("name") String name) {
        return diaryTemplateService.getTemplateByName(name);
    }

    @PostMapping("/diaryTemplates/{name}")
    public DiaryTemplate updateDiaryTemplate(@PathVariable("name") String name, @RequestBody DiaryTemplate diaryTemplate) {
        if (!name.equals(diaryTemplate.getName())) {
            throw new IllegalArgumentException("name不一致");
        }
        return diaryTemplateService.updateTemplate(diaryTemplate);
    }

    @GetMapping("/misc/entities/{name}")
    public GdmEntity getEntity(@PathVariable("name") String name) {
        return metaClient.getEntity(name);
    }

    @GetMapping("/misc-event")
    @Operation(summary = "测试发送事件", description = "extraMessage可以填meta(MetaEvent), schema(SchemaEvent虽然没用)，feature" +
            "(FeatureEvent)， 或者其他随意字符")
    public String sendEvent(@QueryParam("extra") String extrMessage) {
        String message = "有人于" + Instant.now() + "访问了misc-event";
        MDC.put("test_id", "110");
        if (StringUtils.hasText(extrMessage))
            message = extrMessage;
        return someService.sendMiscEvent(message);
    }

    @GetMapping("/gsclientinfo")
    @Operation(summary = "获取gsclient信息", description = "获取gsclient信息")
    public String getGsClientInfo() {
        return metaClient.getGsClientInfo();
    }

    @GetMapping("/checkDesignTime")
    @Operation(summary = "检查MetaClient是否处于设计时", description = "检查是否处于设计时")
    public boolean checkDesignTime() {
        return homeService.checkDesignTime();
    }

    @GetMapping("/version")
    @Operation(summary = "获取版本信息", description = "获取版本信息")
    public BuildProperties getVersion() {
        return buildProperties;
    }

    @GetMapping("/_/benchmark")
    @Operation(summary = "测试性能", description = "使用 dashboard entity 来测试性能, 事务#1: 插入n条数据(如果存在先删掉再插入); 事务#2: " +
            "然后删掉n-1条。穿透：GenericGdmModelService->MyBatis->SqlProcessors->MysqlDB" )
    public String benchmark(@RequestParam (name = "count", defaultValue = "10") int count,
                            @RequestParam (name = "startId", defaultValue = "900000000") long startId,
                            @RequestParam (name = "mode", defaultValue = "GENERIC_GDM_MODEL") HomeDao.BenchmarkMode mode) {
        return homeService.benchmarkDbOperations(count, startId, mode);
    }

    @DeleteMapping("/_/meta-history")
    @Operation(summary = "删除metaHistory", description = "删除metaHistory, 默认删7天前的。")
    public Long deleteMetaHistoryFrom(@RequestParam (name = "from", defaultValue = "#{T(java.time.Instant).now()" +
            ".minus(7, T(java.time.temporal.ChronoUnit).DAYS)}") Instant from) {
        return homeService.deleteMetaHistoryBefore(from);
    }
}
