package com.convertlab.foundation.gdmpattern.job;

import com.convertlab.data.job.core.biz.model.BizJobRunResult;
import com.convertlab.data.job.core.biz.model.ReturnT;
import com.convertlab.data.job.core.enums.ClFailStrategyEnum;
import com.convertlab.data.job.core.util.data.BizJobClient;
import com.convertlab.data.job.core.util.data.JobData;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto;
import com.convertlab.foundation.api.gdm.pattern.facade.GdmMetaFacade;
import com.convertlab.foundation.gdmpattern.dto.DeleteGdmEntityDataParams;
import com.convertlab.foundation.gdmpattern.model.GdmModel;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BackendException;
import com.convertlab.foundation.library.gdmmeta.client.GdmStorageMetaRtClient;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.google.common.graph.ElementOrder;
import com.google.common.graph.GraphBuilder;
import com.google.common.graph.Graphs;
import com.google.common.graph.MutableGraph;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.Assert;

import java.util.*;
import java.util.stream.Collectors;

import static com.convertlab.foundation.gdmpattern.job.GdmModelJob.*;

@Slf4j
@RequiredArgsConstructor
public class GdmModelJobClient {
    private static final String LOG_PREFIX = "<foundation> <GdmModelJobClient> ";
    private final BizJobClient bizJobClient;
    private final GdmMetaFacade gdmMetaFacade;
    private final GdmStorageMetaRtClient gdmStorageMetaClient;

    @Value("${spring.application.name}")
    private String appName;
    public static final String JOB_TYPE_DROP_GDM_ENTITY_DEF = "JOB_003_DROP_GDM_ENTITY_DEF";
    public static final String JOB_TYPE_DROP_GDM_MODEL_DEF = "JOB_003_DROP_GDM_MODEL_DEF";
    public static final String JOB_TYPE_DROP_GDM_ENTITY_DATA = "JOB_003_DROP_GDM_ENTITY_DATA";
    public static final String GROUP_TYPE_DROP_GDM_ENTITY = "JOB_GROUP_003_DROP_GDM_ENTITY";
    public static final String GROUP_TYPE_DROP_GDM_MODEL = "JOB_GROUP_003_DROP_GDM_MODEL";
    public static final String GROUP_TYPE_DROP_GDM_ENTITY_FIELDS = "JOB_GROUP_003_DROP_GDM_ENTITY_FIELDS";
    // job超时时长，单位毫秒
    private static final Long JOB_TIMEOUT = 36000L;

    /*
     * 通过任务框架启动异步任务删除Gdm entity的数据和meta
     */
    public BizJobRunResult startTaskToDropGdmEntity(String entityName) {
        try {
            log.info("Start task to drop gdm entity data {}", entityName);
            // 构建删除entity DAG - 先删除entity data，后删除gdm meta
            MutableGraph<JobData> jobDataMutableGraph = initDag();
            JobData dropEntityDataTask = buildDropEntityDataTask(entityName);
            JobData dropEntityDefTask = buildDropEntityMetaTask(entityName);
            jobDataMutableGraph.putEdge(dropEntityDataTask, dropEntityDefTask);

            ReturnT<BizJobRunResult> res = bizJobClient.createAndStartBizJobGroup(GROUP_TYPE_DROP_GDM_ENTITY, jobDataMutableGraph);
            if (res == null || res.getCode() != ReturnT.SUCCESS.getCode() || res.getData() == null) {
                throw new BackendException(CommonErrors.GENERAL_ERROR, "dropGdmEntityData failed to create and start biz job");
            }
            log.info("Start task to drop gdm entity {} data successfully, task info: {}", entityName, JsonUtils.instanceOfDto().obj2Json(res.getData()));

            return res.getData();
        } catch (Exception e) {
            log.error("Failed to drop gdm entity " + entityName, e);
            throw new BackendException(CommonErrors.GENERAL_ERROR, "Failed to drop gdm entity " + entityName + ", error:" + e.getMessage());
        }
    }

    /*
     * 通过任务框架启动异步任务删除GdmModel的主表、周边表数据
     */
    public BizJobRunResult startTaskToDropGdmModel(GdmModel gdmModel, String bizInfo) {
        log.info("Start task to drop gdm model {}", gdmModel.getName());
        GdmPatternDto.ProvisionProperties props = gdmModel.getProps();
        try {
            // 构建删除model DAG
            MutableGraph<JobData> jobDataMutableGraph = initDag();

            if (entityExist(props.getIdentityEntityName())) {
                jobDataMutableGraph.addNode(buildDropEntityDataTask(props.getIdentityEntityName()));
            }

            // 删除标签数据, 顺序: def -> static -> dynamic
            JobData dropTraitDataTask = null;
            if (entityExist(props.getTraitsDefEntityName())) {
                dropTraitDataTask = buildDropEntityDataTask(props.getTraitsDefEntityName());
                if (entityExist(props.getStaticTraitsEntityName())) {
                    JobData dropStaticTrait = buildDropEntityDataTask(props.getStaticTraitsEntityName());
                    jobDataMutableGraph.putEdge(dropTraitDataTask, dropStaticTrait);
                    dropTraitDataTask = dropStaticTrait;
                }
                if (entityExist(props.getDynamicTraitsEntityName())) {
                    JobData dropDynamicTrait = buildDropEntityDataTask(props.getDynamicTraitsEntityName());
                    jobDataMutableGraph.putEdge(dropTraitDataTask, dropDynamicTrait);
                    dropTraitDataTask = dropDynamicTrait;
                }
            }
            // 删除群组数据, 顺序: def -> static -> dynamic
            JobData dropSegmentDataTask = null;
            if (entityExist(props.getSegmentDefEntityName())) {
                dropSegmentDataTask = buildDropEntityDataTask(props.getSegmentDefEntityName());
                if (entityExist(props.getStaticSegmentEntityName())) {
                    JobData dropStaticSegment = buildDropEntityDataTask(props.getStaticSegmentEntityName());
                    jobDataMutableGraph.putEdge(dropSegmentDataTask, dropStaticSegment);
                    dropSegmentDataTask = dropStaticSegment;
                }
                if (entityExist(props.getDynamicSegmentEntityName())) {
                    JobData dropDynamicSegment = buildDropEntityDataTask(props.getDynamicSegmentEntityName());
                    jobDataMutableGraph.putEdge(dropSegmentDataTask, dropDynamicSegment);
                    dropSegmentDataTask = dropDynamicSegment;
                }
            }
            // 删除事件数据， 事件entity的数据都存储在一个表中，取任意一个触发删除
            List<String> events = new ArrayList<>();
            JobData dropEventDataTask = null;
            if (props.getEvents() != null && props.getEvents().length > 0) {
                String eventEntityName = props.getEvents()[0].getEventEntityName();
                dropEventDataTask = buildDropEntityDataTask(eventEntityName);
                // 事件entityName用于后续事件定义的删除
                Arrays.stream(props.getEvents()).forEach(profileEvent -> events.add(profileEvent.getEventEntityName()));
            }
            // 删除订单数据
            JobData dropOrderDataTask = null;
            if (entityExist(props.getOrderEntityName())) {
                dropOrderDataTask = buildDropEntityDataTask(props.getOrderEntityName());
            }
            // 删除指标数据
            if (entityExist(props.getIndicatorEntityName())) {
                jobDataMutableGraph.addNode(buildDropEntityDataTask(props.getIndicatorEntityName()));
            }
            // 删除主表数据
            JobData dropEntityDataTask = buildDropEntityDataTask(gdmModel.getName());
            // 删除model meta
            JobData dropGdmModelDefTask = buildDropModelMetaTask(gdmModel.getName(), events, bizInfo);

            // 删除数据后再删除meta
            if (dropSegmentDataTask != null) {
                jobDataMutableGraph.putEdge(dropSegmentDataTask, dropGdmModelDefTask);
            }
            if (dropTraitDataTask != null) {
                jobDataMutableGraph.putEdge(dropTraitDataTask, dropGdmModelDefTask);
            }
            if (dropEventDataTask != null) {
                jobDataMutableGraph.putEdge(dropEventDataTask, dropGdmModelDefTask);
            }
            if (dropOrderDataTask != null) {
                jobDataMutableGraph.putEdge(dropOrderDataTask, dropGdmModelDefTask);
            }
            // 删除完主表数据后再删除meta信息
            jobDataMutableGraph.putEdge(dropEntityDataTask, dropGdmModelDefTask);
            log.info("{} drop gdm model jobs is: {}", LOG_PREFIX, JsonUtils.instanceOfDto().obj2Json(jobDataMutableGraph.nodes()));
            log.info("{} drop gdm model DAG is: {}", LOG_PREFIX, JsonUtils.instanceOfDto().obj2Json(jobDataMutableGraph.edges()));
            if (Graphs.hasCycle(jobDataMutableGraph)) {
                log.error("{} drop gdm model DGA has cycle. bizInfo is: {} gmdModel is: {}", LOG_PREFIX, bizInfo, JsonUtils.instanceOfDto().obj2Json(gdmModel));
                throw new BackendException(CommonErrors.GENERAL_ERROR, "drop gdm model DGA has cycle.");
            }

            // 创建并启动任务组
            ReturnT<BizJobRunResult> res = bizJobClient.createAndStartBizJobGroup(GROUP_TYPE_DROP_GDM_MODEL + "-" + gdmModel.getName(), jobDataMutableGraph);
            if (res == null || res.getCode() != ReturnT.SUCCESS.getCode() || res.getData() == null) {
                throw new BackendException(CommonErrors.GENERAL_ERROR, "Failed to create and start biz job group");
            }
            log.info("Start task to drop gdm model {} successfully, task info: {}", gdmModel.getName(), JsonUtils.instanceOfDto().obj2Json(res.getData()));
            return res.getData();
        } catch (Exception e) {
            log.error("Failed to drop gdm model " + gdmModel.getName(), e);
            throw new BackendException(CommonErrors.GENERAL_ERROR, "Failed to drop gdm model data " + gdmModel.getName() + ", error:" + e.getMessage());
        }
    }

    /*
     * 通过任务框架启动异步任务删除GdmEntity中被删除Fields的数据
     */
    public BizJobRunResult startTaskToDropGdmFields(GdmEntity entity, List<String> fieldsToBeRemoved) {
        if (fieldsToBeRemoved.isEmpty()) {
            return null;
        }
        String gdmEntityName = entity.getEntityName();
        log.info("Start task to drop gdm entity {} fields {}", gdmEntityName, StringUtils.join(fieldsToBeRemoved, ","));
        try {
            // 构建删除字段数据任务的DAG
            MutableGraph<JobData> jobDataMutableGraph = initDag();
            List<String> dbColumnsToBeRemoved = entity.getFields().stream()
                    .filter(x -> fieldsToBeRemoved.contains(x.getFieldName()))
                    .map(GdmField::getDbColumnName)
                    .collect(Collectors.toList());
            JobData dropEntityFieldsDataTask = buildDropEntityDataTask(gdmEntityName, DeleteGdmEntityDataParams.DELETE_TYPE_FIELDS, fieldsToBeRemoved, dbColumnsToBeRemoved);
            // 删除meta信息
            JobData dropEntityFieldsDefTask = buildDropEntityFieldsTask(gdmEntityName, fieldsToBeRemoved);
            jobDataMutableGraph.putEdge(dropEntityFieldsDataTask, dropEntityFieldsDefTask);

            ReturnT<BizJobRunResult> res = bizJobClient.createAndStartBizJobGroup(GROUP_TYPE_DROP_GDM_ENTITY_FIELDS, jobDataMutableGraph);
            if (res == null || res.getCode() != ReturnT.SUCCESS.getCode() || res.getData() == null) {
                throw new BackendException(CommonErrors.GENERAL_ERROR, "dropGdmEntityFieldsData failed to create and start biz job");
            }
            log.info("Start task to drop gdm fields successfully, task info: {}", JsonUtils.instanceOfDto().obj2Json(res.getData()));

            return res.getData();
        } catch (Exception e) {
            throw new BackendException(CommonErrors.GENERAL_ERROR, "dropGdmEntityFieldsData failed to drop gdm model fields data " + gdmEntityName + ", error:" + e.getMessage());
        }
    }

    private MutableGraph<JobData> initDag() {
        return GraphBuilder.directed()  // 指定为有向图
                .nodeOrder(ElementOrder.<JobData>insertion()) // 节点按插入顺序输出
                .allowsSelfLoops(false) // 不允许自环
                .build();
    }

    /*
     * 根据entity的信息构建删除数据任务的JobData
     */
    private JobData buildDropEntityDataTask(String entityName) throws Exception {
        return buildDropEntityDataTask(entityName, DeleteGdmEntityDataParams.DELETE_TYPE_ENTITY, null, null);
    }

    /*
     * 根据entity的信息构建删除数据任务的JobData
     */
    private JobData buildDropEntityDataTask(String entityName, String
            deleteType, List<String> fieldsToBeRemoved, List<String> dbColumnsToBeRemoved) throws Exception {
        GdmEntity entity = gdmMetaFacade.getEntity(entityName);
        Assert.notNull(entity, "Gdm entity not found " + entityName);

        DeleteGdmEntityDataParams jobParams = new DeleteGdmEntityDataParams();
        jobParams.setTenantId(TenantContextHolder.getTenantId());
        jobParams.setGdmEntityName(entityName);
        jobParams.setDbTableName(entity.getDbTableName());
        if (entity.getTablePartition() != null) {
            jobParams.setTablePartitionIdentifierType(entity.getTablePartition().getIdentifierType());
            jobParams.setTablePartitionIdentifierValue(entity.getTablePartition().getIdentifierValue());
            jobParams.setTablePartitionIdentifierField(entity.getTablePartition().getIdentifierField());
        }
        jobParams.setPrimaryKeyField(entity.getPrimaryKeyField());
        jobParams.setDbTypes(entity.dataProcessingModes().stream().map(mode -> gdmStorageMetaClient.getTableStorageOfMode(entityName, mode).getDbType()).collect(Collectors.toList()));
        jobParams.setDeleteType(deleteType);
        if (DeleteGdmEntityDataParams.DELETE_TYPE_FIELDS.equals(deleteType)) {
            jobParams.setFieldsToBeRemoved(fieldsToBeRemoved);
            jobParams.setDbColumnsToBeRemoved(dbColumnsToBeRemoved);
        }

        String bizUuid = UUID.randomUUID().toString();
        JobData.JobDataBuilder jobDataBuilder = JobData.builder()
                .jobType(JOB_TYPE_DROP_GDM_ENTITY_DATA)
                .bizUuid(bizUuid)
                .jobNo(bizJobClient.getBizJobNo(JOB_TYPE_DROP_GDM_ENTITY_DATA, bizUuid))
                .appName(appName)
                .jobHandler(JOB_HANDLER_DROP_GDM_ENTITY_DATA)
                .failStrategy(ClFailStrategyEnum.CONTINUE)
                .timeout(JOB_TIMEOUT)
                .jobParameters(JsonUtils.instance().obj2Json(jobParams, false));
        return jobDataBuilder.build();
    }

    private JobData buildDropEntityMetaTask(String entityName) {
        Map<String, Object> params = new HashMap<>();
        params.put("entityName", entityName);
        String bizUuid = UUID.randomUUID().toString();
        return JobData.builder()
                .jobType(JOB_TYPE_DROP_GDM_ENTITY_DEF)
                .bizUuid(bizUuid)
                .jobNo(bizJobClient.getBizJobNo(JOB_TYPE_DROP_GDM_ENTITY_DEF, bizUuid))
                .appName(appName)
                .jobHandler(JOB_HANDLER_DROP_GDM_ENTITY_DEF)
                .failStrategy(ClFailStrategyEnum.CONTINUE)
                .timeout(JOB_TIMEOUT)
                .needNotification(true)  // GdmEntity的删除需要通知
                .jobParameters(JsonUtils.instance().obj2Json(params, false)).build();
    }

    private JobData buildDropEntityFieldsTask(String entityName, List<String> fieldsToBeRemoved) {
        // 删除meta信息
        Map<String, Object> params = new HashMap<>();
        params.put("entityName", entityName);
        params.put("fieldsToBeRemoved", fieldsToBeRemoved);
        String bizUuid = UUID.randomUUID().toString();
        return JobData.builder()
                .jobType(JOB_TYPE_DROP_GDM_MODEL_DEF)
                .bizUuid(bizUuid)
                .jobNo(bizJobClient.getBizJobNo(JOB_TYPE_DROP_GDM_MODEL_DEF, bizUuid))
                .appName(appName)
                .jobHandler(JOB_HANDLER_DROP_GDM_ENTITY_FIELDS)
                .failStrategy(ClFailStrategyEnum.CONTINUE)
                .timeout(JOB_TIMEOUT)
                .needNotification(true)  // GdmModel的删除需要通知
                .jobParameters(JsonUtils.instance().obj2Json(params, false)).build();
    }

    private JobData buildDropModelMetaTask(String modelName, List<String> events, String bizInfo) {
        String bizUuid = UUID.randomUUID().toString();
        Map<String, Object> params = new HashMap<>();
        params.put("modelName", modelName);
        params.put("events", events);
        return JobData.builder()
                .jobType(JOB_TYPE_DROP_GDM_MODEL_DEF)
                .bizUuid(bizUuid)
                .jobNo(bizJobClient.getBizJobNo(JOB_TYPE_DROP_GDM_MODEL_DEF, bizUuid))
                .appName(appName)
                .jobHandler(JOB_HANDLER_DROP_GDM_MODEL_DEF)
                .jobSubType(bizInfo)
                .failStrategy(ClFailStrategyEnum.CONTINUE)
                .timeout(JOB_TIMEOUT)
                .needNotification(true)  // GdmModel的删除需要通知
                .jobParameters(JsonUtils.instance().obj2Json(params, false)).build();
    }

    private boolean entityExist(String entityName) {
        return StringUtils.isNotBlank(entityName) && gdmMetaFacade.entityExist(entityName);
    }
}
