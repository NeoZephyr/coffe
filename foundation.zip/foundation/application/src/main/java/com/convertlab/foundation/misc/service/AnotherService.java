package com.convertlab.foundation.misc.service;

import com.convertlab.foundation.library.business.cache.CacheEvent;
import com.convertlab.foundation.library.business.constants.CommonEventTypes;
import com.convertlab.foundation.library.business.eventbroker.DemoEvent;
import com.convertlab.foundation.library.business.eventbroker.NotificationEvent;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BackendException;
import com.convertlab.foundation.library.gdmmeta.constants.MetaEvent;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.utils.Try;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.scheduling.annotation.Async;

import javax.annotation.Nonnull;

import static com.convertlab.foundation.library.business.eventbroker.EventListenerHelper.LISTENER_EXECUTION_THRESHOLD;
import static com.convertlab.foundation.library.business.eventbroker.EventListenerHelper.NOTIFICATION_BROKER_EXECUTOR;

@Slf4j
public class AnotherService {
    @EventListener
    @Order(1)
    @Async(NOTIFICATION_BROKER_EXECUTOR)
    public void receiveAllNotification(@Nonnull NotificationEvent<?> event) {
        Try.logAndIgnoreException(() -> {
            log.info("[Another消息监听者NotificationEvent]@Order(1)什么都听的: {}", event);
            event.getDto();
        });
    }

    @EventListener
    @Order(1)
    @Async(NOTIFICATION_BROKER_EXECUTOR)
    public void receiveAllMetaEvent(@Nonnull MetaEvent event) {
        Try.logAndIgnoreException(() -> {
            log.info("[Another消息监听者MetaEvent]@Order(1)什么MetaEvent都听的: {}", event);
            MetaEvent.Dto dto = event.getDto();
        });
    }

    @EventListener
    @Order(1000)
    @Async(NOTIFICATION_BROKER_EXECUTOR)
    public void receiveAllDemoEvent(@Nonnull DemoEvent event) {
        log.info("[Another消息监听者DemoEvent]-异步：最后一个什么都听的: {}", event);
        log.info("[Another消息监听者DemoEvent]-异步：租户上下文等ThreadLocal数据应该保留：消息租户:{}， 线程租户:{}", event.getTenantId(),
                TenantContextHolder.getTenantId());
        log.info("[Another消息监听者DemoEvent]-异步: 小睡1000ms，模拟业务处理耗时");
        try {
            Thread.sleep(LISTENER_EXECUTION_THRESHOLD);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        log.info("[Another消息监听者DemoEvent]-异步: 小睡1000ms，模拟业务处理耗时结束");
    }

    @EventListener(condition = "#event.subscriber == 'ANOTHER_SERVICE'")
    @Order(2)
    @Async(NOTIFICATION_BROKER_EXECUTOR)
    public void receiver1(@Nonnull DemoEvent event) {
        Try.logAndIgnoreException(() -> log.info("[Another消息监听者DemoEvent]只听发给我的的: {}", event));
    }

    @EventListener(condition = "#event.publisher == 'SOME_SERVICE'")
    @Order(3)
    public void receiver2(@Nonnull DemoEvent event) {
        Try.logAndIgnoreException(() ->
        log.info("[Another消息监听者DemoEvent]只听SomeService发的: {}", event));
    }

    @EventListener(condition = "#event.publisher == 'SOME_SERVICE' " +
            "and #event.propagationStrategy == T(com.convertlab.foundation.library.business.eventbroker.NotificationEvent$PropagationStrategy).PER_INSTANCE")
    @Order(4)
    public void receiver3(@Nonnull DemoEvent event) {
        Try.logAndIgnoreException(() ->
        log.info("[Another消息监听者DemoEvent]只听SomeService发的Instance级别的: {}", event));
    }

    @EventListener(condition = "#event.type == T(com.convertlab.foundation.library.business.constants.CommonEventTypes).DIARY_WRITE")
    @Order(5)
    public void receiveSelected(@Nonnull DemoEvent event) {
        Try.logAndIgnoreException(() ->
        log.info("[Another消息监听者DemoEvent]只听写日记的: {}, {}",CommonEventTypes.DIARY_WRITE, event.getDto()));
    }

    @EventListener(condition = "#event.type == 'THROW_ERROR'")
    @Order(1)
    public void receiverAndThrow(@Nonnull DemoEvent event) {
        Try.logAndIgnoreException(() -> {
            log.info("[Another消息监听者DemoEvent]只听THROW_ERROR, 然后抛错的: {}, {}",CommonEventTypes.DIARY_WRITE, event.getDto());
            throw new BackendException(CommonErrors.GENERAL_ERROR, "我是故意的");
        });
    }

    /**
     * 每个cache manager如果没有用REDIS BACKEND的方式，必须监听这个事件，清空自己的缓存
     * @param event CacheEvent
     */
    @EventListener
    @Order(1)
    public void clearCache(@Nonnull CacheEvent event) {
        log.info("[Another消息监听者CacheEvent]@Order(1): {}", event);
        log.info("event.dto: {}", event.getDto());
        CacheEvent.Dto dto = event.getDto();
        log.info("dto.getCacheName(): {}", dto.getCacheName());
        String cacheName = dto.getCacheName().trim();
        if (event.getType().equals(CacheEvent.CacheEventType.CLEAR_ALL_CACHE_IN_TENANT.getValue())) {
            log.info("发生大事了 -- 清空所有缓存");
            // 清空自己的缓存
        } else if (event.getType().equals(CacheEvent.CacheEventType.CLEAR_CACHE_IN_TENANT.getValue())) {
            log.info("清空指定缓存: {}", cacheName);
            // 如果cache name就是自己，那么就清空缓存
        }
    }
}
