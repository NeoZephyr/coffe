package com.convertlab.foundation.kvstore.controller;

import com.convertlab.foundation.kvstore.dto.KeyValuesPair;
import com.convertlab.foundation.kvstore.dto.KvDtsMessage;
import com.convertlab.foundation.kvstore.dto.KvPair;
import com.convertlab.foundation.kvstore.dto.KvQuery;
import com.convertlab.foundation.kvstore.service.KvStorageFascadeService;
import com.convertlab.foundation.kvstore.utils.CollectionUtils;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.model.vo.GenericListResponse;
import com.convertlab.foundation.library.model.vo.GenericResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import java.util.*;
import java.util.stream.Collectors;

import static com.convertlab.foundation.library.constant.CommonErrors.*;

@Slf4j
@RestController
@Tag(name = "KV Store接口")
@RequestMapping("/v1/kvstore/{entityName}")
public class KvStoreController {
    private static final int MAX_BATCH_SIZE = 1000;

    @Value("${kafka.kvStoreDataDts.topic}")
    protected String kvStoreDataDtsTopic;

    private KvStorageFascadeService kvStorageFascade;

    private KafkaTemplate<String, KvDtsMessage> kafkaTemplate;

    public KvStoreController(KvStorageFascadeService kvStorageFascadeService, KafkaTemplate<String, KvDtsMessage> kafkaTemplate) {
        this.kvStorageFascade = kvStorageFascadeService;
        this.kafkaTemplate = kafkaTemplate;
    }

    @GetMapping("/get")
    @Operation(summary = "单条读取", description = "根据GDMEntity 和 key，以及选择字段，单条查询KV Store")
    public GenericResponse<KeyValuesPair> get(@PathVariable @Parameter(name="entityName", description = "GDM实体名称", example = "list_member")
                                           String entityName,
                                              @NotNull  @RequestParam(value="key")
                                       String key,
                                              @Nullable @RequestParam(value="select") @Parameter(name = "select", description = "字段选择",example = "id,name,age")
                                       String select) {
        if(StringUtils.isNotEmpty(select)){
            String [] columns = select.split(",");
            for(String column: columns){
                if(StringUtils.isBlank(column) || StringUtils.isWhitespace(column)){
                    throw new BusinessException(VALIDATION_ERROR, "MSG_006_000009", "Invalid column name", new String[]{column});
                }
            }
        }
        try{
            KvQuery query = new KvQuery();
            query.setKeys(Arrays.asList(key));
            if(StringUtils.isNotEmpty(select)) {
                query.setColumns(Arrays.asList(select.split(",")));
            }
            List<KeyValuesPair> list = kvStorageFascade.batchGet(entityName, query);
            if(list.size() > 1){
                throw new BusinessException(DUPLICATED_KEY, "MSG_006_000010", "More than one result queried from kv store", new String[]{String.valueOf(list.size())});
            }else if(list.size() == 1 ){
                return GenericResponse.<KeyValuesPair>builder().result(list.get(0)).build();
            }else{
                return GenericResponse.<KeyValuesPair>builder().result(null).build();
            }
        }catch (Exception e){
            log.error("Failed to get kv store", e);
            throw new BusinessException(GENERAL_ERROR, "MSG_006_000006", "Failed to get kv store", new String[]{e.getMessage()});
        }
    }

    @PostMapping("/bulkGet")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            content = @Content(mediaType = "application/json",
                    examples = {@ExampleObject(name = "客户群组", value = "@examples/kvstore/bulk_get_req.json"),
                            @ExampleObject(name = "客户指标", value = "@examples/kvstore/bulk_get_with_full_name_req.json"),
                            @ExampleObject(name = "查询全部column", value = "@examples/kvstore/bulk_get_with_no_column_req.json")})
    )
    @ApiResponse(content = @Content(
            mediaType = "application/json",
            examples = {@ExampleObject(name = "客户群组", value = "@examples/kvstore/bulk_get_res.json"),
                    @ExampleObject(name = "客户指标", value = "@examples/kvstore/bulk_get_with_full_name_res.json"),
                    @ExampleObject(name = "查询全部column", value = "@examples/kvstore/bulk_get_with_no_column_res.json")}
    ))
    @Operation(summary = "多条读取", description = "根据GDMEntity 和kv pairs，查询KV Store")
    public GenericListResponse<KeyValuesPair> bulkGet(@PathVariable @Parameter(name="entityName", description = "GDM实体名称", example = "list_member")
                                           String entityName,
                                                      @RequestBody
                                           KvQuery kvQuery) {
        try{
            List<KeyValuesPair> list = kvStorageFascade.batchGet(entityName, kvQuery);
            return GenericListResponse.<KeyValuesPair>builder().results(list).build();
        }catch(BusinessException e){
            log.error("Failed to get kv store", e);
            throw e;
        }catch (Exception e){
            log.error("Unexpected exception when getting kv store", e);
            throw new BusinessException(GENERAL_ERROR, "MSG_006_000006", "Failed to get kv store", new String[]{e.getMessage()});
        }
    }


    @PostMapping("/put")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            content = @Content(mediaType = "application/json",
                    examples = {@ExampleObject(name = "request", value = "@examples/kvstore/put_req.json")})
    )
    @Operation(summary = "单条插入或更新", description = "写入或者更新单条kv pair记录")
    public GenericResponse<Boolean> put(@PathVariable @Parameter(name="entityName", description = "GDM实体名称", example = "list_member")
                                              String entityName,
                                              @RequestBody
                                        KeyValuesPair kvPairs){
        try{
            kvStorageFascade.batchUpsert(entityName, Arrays.asList(kvPairs));
            return GenericResponse.<Boolean>builder().result(true).build();
        }catch(BusinessException e){
            log.error("Failed to upsert kv store", e);
            throw e;
        }catch (Exception e){
            log.error("Unexpected exception when upsertting kv store", e);
            throw new BusinessException(GENERAL_ERROR, "MSG_006_000012", "Failed to upsert kv store", new String[]{e.getMessage()});
        }
    }

    @PostMapping("/bulkUpsert")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            content = @Content(mediaType = "application/json",
                    examples = {@ExampleObject(name = "request", value = "@examples/kvstore/bulk_upsert_req.json")})
    )
    @Operation(summary = "多条插入或更新", description = "异步写入或者更新多条kv pair记录")
    public GenericResponse<Boolean> bulkUpsert(@PathVariable @Parameter(name="entityName", description = "GDM实体名称", example = "list_member")
                                     String entityName,
                                               @Nonnull @RequestBody
                                     List<KeyValuesPair> kvPairs){
        try{
            List<String> keys = kvPairs.stream().map(KeyValuesPair::getId).collect(Collectors.toList());
            List<String> duplicateKeys = CollectionUtils.findRepeat(keys);
            if(duplicateKeys.size() >0){
                throw new BusinessException(GENERAL_ERROR, "MSG_006_000008", "Duplicate keys found", new String[]{String.join(",", duplicateKeys)});
            }
            if(kvPairs.size() > MAX_BATCH_SIZE){
                throw new BusinessException(GENERAL_ERROR, "MSG_006_000001", "Max size of kvpairs excceeds 1000", new String[]{ String.valueOf(MAX_BATCH_SIZE), String.valueOf(kvPairs.size())});
            }
            KvDtsMessage kvDtsMessage =new KvDtsMessage();
            KvDtsMessage.DtsMeta _meta = new KvDtsMessage.DtsMeta();
            _meta.setName(entityName);
            kvDtsMessage.set_meta(_meta);
            kvDtsMessage.set_data(kvPairs);
            kafkaTemplate.send(kvStoreDataDtsTopic, kvDtsMessage);
            return GenericResponse.<Boolean>builder().result(true).build();
        }catch(BusinessException e){
            log.error("Failed to upsert kv store", e);
            throw e;
        }catch (Exception e){
            log.error("Failed to get kv store", e);
            throw new BusinessException(GENERAL_ERROR, "MSG_006_000012", "Failed to upsert kv store", new String[]{e.getMessage()});
        }
    }

    @PostMapping("/bulkDelete")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            content = @Content(mediaType = "application/json",
                    examples = {@ExampleObject(name = "request", value = "@examples/kvstore/bulk_get_req.json")})
    )
    @Operation(summary = "删除多条记录", description = "批量删除多条kv pair记录")
    public GenericResponse<Boolean> bulkDelete(@PathVariable @Parameter(name="entityName", description = "GDM实体名称", example = "list_member")
                                                   String entityName,
                                               @Nonnull @RequestBody
                                               KvQuery kvQuery) {
        try{
            List duplicateKeys = CollectionUtils.findRepeat(kvQuery.getKeys());
            if(duplicateKeys.size() > 0){
                throw new BusinessException(GENERAL_ERROR, "MSG_006_000008", "Duplicate keys found", new String[]{String.join(",", duplicateKeys)});
            }
            List duplicateColumns = CollectionUtils.findRepeat(kvQuery.getColumns());
            if(duplicateColumns.size() > 0){
                throw new BusinessException(GENERAL_ERROR, "MSG_006_000013", "Duplicate columns found", new String[]{String.join(",", duplicateColumns)});
            }
            List<KeyValuesPair> deleteEntries = new ArrayList<>();
            kvQuery.getKeys().forEach(key->{
                KeyValuesPair kvPair = new KeyValuesPair();
                kvPair.setId(key);
                Map<String, Object> value = new HashMap<>();
                kvQuery.getColumns().forEach(column ->{
                    // 表示column字段存在值的话，需要删除
                    value.put(column, 1);
                });
                kvPair.setKvMapping(new KvPair(value));
                deleteEntries.add(kvPair);
            });

            kvStorageFascade.batchDelete(entityName, deleteEntries);
            return GenericResponse.<Boolean>builder().result(true).build();
        }catch (BusinessException e){
            log.error("Failed to delete kv store", e);
            throw e;
        }catch (Exception e){
            log.error("Unexpected exception when deleting kv store", e);
            throw new BusinessException(GENERAL_ERROR, "MSG_006_000014", "Failed to delete kv store", new String[]{e.getMessage()});
        }
    }

    @PostMapping("/bulkIncrementWithTtl")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            content = @Content(mediaType = "application/json",
                    examples = {@ExampleObject(name = "request", value = "@examples/kvstore/bulk_increment_req.json")})
    )
    @ApiResponse(content = @Content(
            mediaType = "application/json",
            examples = {@ExampleObject(name = "response", value = "@examples/kvstore/bulk_increment_res.json")}
    ))
    @Operation(summary = "批量局部增", description = "批量increase记录，并设置TTL")
    public GenericResponse<Map<String, Map<String, Long>>> bulkIncrementWithTtl(@PathVariable @Parameter(name="entityName", description = "表名", example = "audience_limit")
                                                                         String entityName,
                                                                         @RequestBody
                                                                         List<KeyValuesPair> kvPairs) {
        try{
            Map<String, Map<String, Long>> result = kvStorageFascade.batchIncrement(entityName, kvPairs);
            if(result != null){
                return GenericResponse.<Map<String, Map<String, Long>>>builder().result(result).build();
            }else{
                throw new BusinessException(GENERAL_ERROR, "MSG_006_000016", "Failed to call batchIncrementWithTtl", new String[]{"null"});
            }
        }catch (BusinessException e){
            log.error("Failed to increment kv store", e);
            throw e;
        }catch (Exception e){
            log.error("Unexpected exception when increment kv store", e);
            throw new BusinessException(GENERAL_ERROR, "MSG_006_000016", "Failed to increment kv store", new String[]{e.getMessage()});
        }
    }
}
