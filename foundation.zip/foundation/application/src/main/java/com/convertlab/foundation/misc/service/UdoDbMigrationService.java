package com.convertlab.foundation.misc.service;

import javax.annotation.Nonnull;

import com.google.common.collect.Maps;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Deprecated
public class UdoDbMigrationService {
    @Nonnull
    private final DynamicJdbcTemplate jdbcTemplate;
    private static final String SU = "su";
    private static final String SQL_FK = "SELECT meta.tenant_id as tenantId, meta.obj_id as objId, meta.tbl_name as tblName, meta.column_name as columnName from " +
            "( " +
            "SELECT t.tenant_id, t.obj_id, t.tbl_name, f.column_name " +
            " FROM udo_table_meta t " +
            " JOIN udo_field_meta f ON t.obj_id = f.obj_id AND t.tenant_id = f.tenant_id" +
            " WHERE t.STATUS = 'normal' AND f.STATUS = 'normal' AND f.ref_obj_id IS NOT NULL " +
            ") meta " +
            "ORDER BY meta.tenant_id, meta.obj_id, meta.column_name";

    private static final String SQL_UPDATE_FK = "UPDATE nudo1 /*+_maxwell_ignore_*/ SET fk%index% = %udo_fk% WHERE tenant_id = %tenant_id% AND obj_id = '%obj_id%'";

    private static final String SQL_UDO_FIELD_META_MIGRATION = "UPDATE `nudo_field_meta` set `column_name` = 'fk%index%' WHERE `tenant_id` = %tenant_id% AND `obj_id` = '%obj_id%' AND `column_name` = '%column_name%'";

    private static final String SQL_TABLE_META = "SELECT `tenant_id`, `obj_id`, `tbl_name` FROM `udo_table_meta`";
    private static final String SQL_COPY_DATA = "INSERT INTO nudo_table_meta (`tenant_id`, `obj_id`, `tbl_name`) VALUES (%tenant_id%, '%obj_id%', '%tbl_name%')";

    @Nonnull
    public Map<String, List<String>> getAllFkMigrationSqls() {
        Map<String, List<UdoFk>> fks = jdbcTemplate.queryAllForList(SU, SQL_FK, UdoFk.class);
        Map<String, List<String>> result = Maps.newHashMap();
        fks.forEach((su, fkList) -> {
            List<String> sql = udoFksToFkMigrationSqls(fkList).stream()
                    .map(this::removeMaxwellHint)
                    .collect(Collectors.toList());
            result.put(su, sql);
        });
        return result;
    }

    @Nonnull
    public Map<String, List<String>> getFkMigrationSqls(String su) {
        List<UdoFk> fks = jdbcTemplate.queryForList(su, SQL_FK, UdoFk.class);
        Map<String, List<String>> result = Maps.newHashMap();
        result.put(su, udoFksToFkMigrationSqls(fks));
        return result;
    }

    @Nonnull
    public Map<String, List<String>> getMetaMigrationSqls(String su) {
        Map<String, List<String>> result = Maps.newHashMap();
        List<UdoFk> fks = jdbcTemplate.queryForList(su, SQL_FK, UdoFk.class);
        result.put(su + ": migrating udo field meta", udoFksToFieldMetaMigrationSqls(fks));
        return result;
    }

    @Nonnull
    public Map<String, List<String>> getCopyTableMetasSqls() {
        Map<String, List<UdoTableMeta>> tableMetas = jdbcTemplate.queryAllForList(SU, SQL_TABLE_META, UdoTableMeta.class);
        Map<String, List<String>> result = Maps.newHashMap();
        tableMetas.forEach((su, metList) -> result.put(su, udoTableMetasToCopySqls(metList)));
        return result;
    }

    @Nonnull
    protected List<String> udoFksToFkMigrationSqls(@Nonnull List<UdoFk> fks) {
        Map<String, List<UdoFk>> fkMap = fks.stream().collect(Collectors.groupingBy(UdoFk::getGroupKey));
        return fkMap.keySet().stream()
                .map(fkMap::get)
                .peek(list -> {
                    for (int i = 0; i < list.size(); i++) {
                        list.get(i).buildFkMigrationSql(i + 1);
                    }
                })
                .flatMap(Collection::stream)
                .sorted(Comparator.comparing(UdoFk::getTenantId).thenComparing(UdoFk::getObjId))
                .map(UdoFk::getFkMigrationSql)
                .collect(Collectors.toList());
    }

    @Nonnull
    protected List<String> udoFksToFieldMetaMigrationSqls(@Nonnull List<UdoFk> fks) {
        Map<String, List<UdoFk>> fkMap = fks.stream().collect(Collectors.groupingBy(UdoFk::getGroupKey));
        return fkMap.keySet().stream()
                .map(fkMap::get)
                .peek(list -> {
                    for (int i = 0; i < list.size(); i++) {
                        list.get(i).buildFieldMetaMigrationSql( i + 1);
                    }
                })
                .flatMap(Collection::stream)
                .sorted(Comparator.comparing(UdoFk::getTenantId).thenComparing(UdoFk::getObjId))
                .map(UdoFk::getFieldMetaMigrationSql)
                .collect(Collectors.toList());
    }

    @Nonnull
    protected List<String> udoTableMetasToCopySqls(@Nonnull List<UdoTableMeta> udoTableMetaList) {
        return udoTableMetaList.stream()
                .sorted(Comparator.comparing(UdoTableMeta::getTenantId).thenComparing(UdoTableMeta::getObjId))
                .map(UdoTableMeta::buildCopyTableMetaToKuduSql)
                .collect(Collectors.toList());
    }

    @Nonnull
    protected String removeMaxwellHint(@Nonnull String sql) {
        return sql.replaceAll("\\/\\*\\+_maxwell_ignore_\\*\\/", "");
    }

    @Data
    public static final class UdoFk {
        private Long tenantId;
        private String objId;
        private String tblName;
        private String columnName;
        private String fkMigrationSql;
        private String fieldMetaMigrationSql;

        public String getGroupKey() {
            return String.format("%s:%s", tenantId, objId);
        }

        public void buildFkMigrationSql(int index) {
            this.fkMigrationSql = SQL_UPDATE_FK.replaceAll("%index%", String.valueOf(index))
                    .replaceAll("%udo_fk%", columnName)
                    .replaceAll("%tenant_id%", String.valueOf(tenantId))
                    .replaceAll("%obj_id%", objId);
        }

        public void buildFieldMetaMigrationSql(int index) {
            this.fieldMetaMigrationSql = SQL_UDO_FIELD_META_MIGRATION.replaceAll("%index%", String.valueOf(index))
                    .replaceAll("%udo_fk%", columnName)
                    .replaceAll("%tenant_id%", String.valueOf(tenantId))
                    .replaceAll("%obj_id%", objId)
                    .replaceAll("%column_name%", columnName);
        }
    }

    @Data
    public static final class UdoTableMeta {
        private Long tenantId;
        private String objId;
        private String tblName;

        @Nonnull
        public String buildCopyTableMetaToKuduSql() {
            return SQL_COPY_DATA.replaceAll("%tenant_id%", String.valueOf(tenantId))
                    .replaceAll("%obj_id%", objId)
                    .replaceAll("%tbl_name%", tblName);
        }
    }
}
