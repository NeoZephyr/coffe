package com.convertlab.foundation.user.utils;

public enum DpTaskType {

    import_from_excel, export_to_excel
}
