package com.convertlab.foundation.gdmmeta.controller;

import com.convertlab.foundation.gdmmeta.client.GeneralMetaLocalClient;
import com.convertlab.foundation.gdmmeta.service.GeneralMetaService;
import com.convertlab.foundation.gdmmeta.service.validator.GdmAclMetaValidator;
import com.convertlab.foundation.gdmmeta.service.validator.GdmPatternValidator;
import com.convertlab.foundation.gdmmeta.service.validator.GdmResourceValidator;
import com.convertlab.foundation.gdmpattern.controller.GdmModelController;
import com.convertlab.foundation.library.business.autoconfigure.SpringBeans;
import com.convertlab.foundation.library.gdmmeta.api.GeneralMetaApi;
import com.convertlab.foundation.library.gdmmeta.model.general.BaseMetaSchema;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.ObjectRequest;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.ObjectResponse;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.Ref;
import com.convertlab.foundation.library.gdmmeta.validation.Issue;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.Explode;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

@RestController("generalMetaController")
@RequestMapping("/v1/meta")
@Tag(name = "Meta Store接口")
@Slf4j
public class GeneralMetaController implements GeneralMetaApi {
    public static final String PARAM_NAMESPACE_DESC = "命名空间";
    public static final String PARAM_RESOURCES_DESC = "Meta数据的类型";
    protected final GeneralMetaLocalClient generalMetaLocal;
    private final GdmPatternValidator gdmPatternValidator;
    private final GdmAclMetaValidator gdmAclMetaValidator;
    private final GdmResourceValidator gdmResourceValidator;

    public GeneralMetaController(GeneralMetaService generalMetaService, GdmPatternValidator gdmPatternValidator, GdmAclMetaValidator gdmAclMetaValidator, GdmResourceValidator gdmResourceValidator) {
        this.generalMetaLocal = new GeneralMetaLocalClient(generalMetaService);
        this.gdmPatternValidator = gdmPatternValidator;
        this.gdmAclMetaValidator = gdmAclMetaValidator;
        this.gdmResourceValidator = gdmResourceValidator;
    }

    @Nonnull
    @Override
    @Operation(summary = "创建通用meta对象", description = "创建由客户端定义的meta对象")
    public ObjectResponse createObject(
            @Parameter(required = true, description = PARAM_NAMESPACE_DESC) BaseMetaSchema.Namespace namespace,
            @Parameter(required = true, description = PARAM_RESOURCES_DESC) BaseMetaSchema.MetaType resource,
            ObjectRequest objectRequest) {

        return generalMetaLocal.createObject(namespace, resource, objectRequest);
    }

    @Nonnull
    @ApiResponse(content = @Content(
            mediaType = "application/json",
            examples = {@ExampleObject(name = "response", value = "[\n" +
                    "  {\n" +
                    "    \"objectName\": \"c_evil3\",\n" +
                    "    \"dateCreated\": \"2023-06-08T13:15:38.328Z\",\n" +
                    "    \"lastUpdated\": \"2023-06-08T13:15:38.328Z\",\n" +
                    "    \"data\": {\n" +
                    "      \"resourceType\": \"c_evil3\",\n" +
                    "      \"gdmEntityRef\": {\n" +
                    "        \"_ref\": \"/v1/meta/gdm/entity/test002\"\n" +
                    "      },\n" +
                    "      \"dataPermission\": {\n" +
                    "        \"a\": \"2\",\n" +
                    "        \"b\": \"3\"\n" +
                    "      }\n" +
                    "    },\n" +
                    "    \"refs\": [\n" +
                    "      {\n" +
                    "        \"_ref\": \"/v1/meta/gdm/entity/test002\"\n" +
                    "      }\n" +
                    "    ],\n" +
                    "    \"$version\": \"2\",\n" +
                    "    \"$self\": \"/v1/meta/gdm/resources/c_evil3\",\n" +
                    "    \"$basePath\": \"/v1/meta/gdm/resources\"\n" +
                    "  }\n" +
                    "]")}
    ))
    @Operation(summary = "查询通用meta对象列表", description = "根据查询条件查询特定类别meta对象的列表")
    @Override
    @Hidden
    public List<ObjectResponse> queryObjects(
            @Parameter(required = true, description = PARAM_NAMESPACE_DESC) BaseMetaSchema.Namespace namespace,
            @Parameter(required = true, description = PARAM_RESOURCES_DESC) BaseMetaSchema.MetaType resource,
            @Parameter(explode = Explode.FALSE, description = "过滤条件", example = "{\n" +
                    "  \"objectName\": \"c_car,c_driver\",\n" +
                    "  \"data.resourceType\": \"flow\"\n" +
                    "}") Map<String, String> filter) {
        return  generalMetaLocal.queryObjects(namespace, resource, filter);
    }

    @Nonnull
    @ApiResponse(content = @Content(
            mediaType = "application/json",
            examples = {@ExampleObject(name = "response", value = "[\n" +
                    "  {\n" +
                    "    \"objectName\": \"c_evil3\",\n" +
                    "    \"dateCreated\": \"2023-06-08T13:15:38.328Z\",\n" +
                    "    \"lastUpdated\": \"2023-06-08T13:15:38.328Z\",\n" +
                    "    \"data\": {\n" +
                    "      \"resourceType\": \"c_evil3\",\n" +
                    "      \"gdmEntityRef\": {\n" +
                    "        \"_ref\": \"/v1/meta/gdm/entity/test002\"\n" +
                    "      },\n" +
                    "      \"dataPermission\": {\n" +
                    "        \"a\": \"2\",\n" +
                    "        \"b\": \"3\"\n" +
                    "      }\n" +
                    "    },\n" +
                    "    \"refs\": [\n" +
                    "      {\n" +
                    "        \"_ref\": \"/v1/meta/gdm/entity/test002\"\n" +
                    "      }\n" +
                    "    ],\n" +
                    "    \"$version\": \"2\",\n" +
                    "    \"$self\": \"/v1/meta/gdm/resources/c_evil3\",\n" +
                    "    \"$basePath\": \"/v1/meta/gdm/resources\"\n" +
                    "  }\n" +
                    "]")}
    ))
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "过滤条件",
            content = @Content(
                    mediaType = "application/json",
                    examples = {@ExampleObject(name = "request", value = "{\n" +
                            "  \"objectName\": \"c_car,c_driver\",\n" +
                            "  \"data.resourceType\": \"flow\"\n" +
                            "}")}))
    @Operation(summary = "查询通用meta对象列表", description = "根据查询条件查询特定类别meta对象的列表")
    @Override
    public List<ObjectResponse> queryObjectsPost(
            @Parameter(required = true, description = PARAM_NAMESPACE_DESC) BaseMetaSchema.Namespace namespace,
            @Parameter(required = true, description = PARAM_RESOURCES_DESC) BaseMetaSchema.MetaType metaType,
            Map<String, String> filter) {
        return generalMetaLocal.queryObjectsPost(namespace, metaType, filter);
    }



    @Nullable
    @Operation(summary = "获取单个meta对象", description = "根据名称查找特定类别meta的单个对象，并返回")
    @Override
    public ObjectResponse getObject(
            @Parameter(required = true, description = PARAM_NAMESPACE_DESC) BaseMetaSchema.Namespace namespace,
            @Parameter(required = true, description = PARAM_RESOURCES_DESC) BaseMetaSchema.MetaType resource,
            String objectName) {
        return generalMetaLocal.getObject(namespace, resource, objectName);
    }

    @Nonnull
    @Operation(summary = "更新单个meta对象", description = "根据名称查找到特定类别meta的单个对象，更新")
    @Override
    public ObjectResponse updateObject(
            @Parameter(required = true, description = PARAM_NAMESPACE_DESC) BaseMetaSchema.Namespace namespace,
            @Parameter(required = true, description = PARAM_RESOURCES_DESC) BaseMetaSchema.MetaType resource,
            String objectName,
            ObjectRequest objectRequest) {
        return generalMetaLocal.updateObject(namespace, resource, objectName, objectRequest);

    }

    @Operation(summary = "删除单个meta对象", description = "根据名称查找到特定类别meta的单个对象，删除")
    @Override
    public void deleteObject(
            @Parameter(required = true, description = PARAM_NAMESPACE_DESC) BaseMetaSchema.Namespace namespace,
            @Parameter(required = true, description = PARAM_RESOURCES_DESC) BaseMetaSchema.MetaType resource,
            String objectName) {
        generalMetaLocal.deleteObject(namespace, resource, objectName);
    }

    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "根据一个ref来搜索引用了此ref的所有对象",
            content = @Content(
                    mediaType = "application/json",
                    examples = {@ExampleObject(
                            name = "REF",
                            value = "{\n" +
                                    "  \"_ref\": \"/v1/meta/gdm/gdm-models/customer\"\n" +
                                    "}"
                    )}
            )
    )
    @ApiResponse(
            description = "返回所有引用了此ref的对象的ref列表",
            content = @Content(
                    mediaType = "application/json",
                    examples = {@ExampleObject(
                            name = "REF",
                            value = "[\n" +
                                    "  {\n" +
                                    "    \"_ref\": \"/v1/meta/gdm/resources/c_evil3\"\n" +
                                    "  }\n" +
                                    "]"
                    )}
            )
    )
    @PostMapping({"/_ref/query"})
    @Operation(summary = "根据Ref查找引用了的对象", description = "在所有的一般对象中搜索引用了此Ref的所有对象的Ref，暂时不能在GDM核心schema" +
            "里面搜索，不过，可以在其他的meta里搜引用核心schema的meta")
    public Set<Ref> queryRefs(@Parameter(required = true, description = "需要查询的Ref") @RequestBody @Valid Ref ref) {
        return generalMetaLocal.queryRefs(ref);
    }

    @Operation(summary = "检查meta的完整性", description = "检查meta的完整性")
    @PostMapping({"/{namespace}/{metaType}/_health-check"})
    @Tag(name = "health-check-endpoint")
    public List<Issue> checkGeneralMeta(
            @Parameter(required = true, description = PARAM_NAMESPACE_DESC) @PathVariable(name = "namespace") BaseMetaSchema.Namespace namespace,
            @Parameter(required = true, description = PARAM_RESOURCES_DESC) @PathVariable(name = "metaType") BaseMetaSchema.MetaType metaType) {
        if (namespace == BaseMetaSchema.Namespace.GDM && metaType == BaseMetaSchema.MetaType.GDM_MODELS) {
            return gdmPatternValidator.validate();
        }
        if (namespace == BaseMetaSchema.Namespace.BIZ && metaType == BaseMetaSchema.MetaType.GDM_ACLS) {
            return gdmAclMetaValidator.validate();
        }
        if (namespace == BaseMetaSchema.Namespace.GDM && metaType == BaseMetaSchema.MetaType.GDM_RESOURCES) {
            return gdmResourceValidator.validate();
        }
        ArrayList<Issue> notSupported = new ArrayList<>();
        notSupported.add(new Issue(Issue.IssueType.UNKNOWN, metaType.getName(), "UNKNOWN", "这个接口不支持此类型的meta校验，请联系开发人员获得相应的校验接口"));
        return notSupported;
    }
}
