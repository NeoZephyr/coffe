package com.convertlab.foundation.user.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.user.entity.UserDept;
import com.convertlab.foundation.user.mapper.UserDeptMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@DataSourceLookup("main")
@Transactional
@Slf4j
public class DeptImportExportService {

    private final DeptService deptService;
    public DeptImportExportService(DeptService deptService) {
        this.deptService = deptService;
    }

    //Implement import dept, based on the assumption dept count is small

    //Implement export dept, based on the assumption dept count is small

}
