package com.convertlab.foundation.configure;

import com.convertlab.foundation.api.queryengine.GdmQuery;
import com.convertlab.foundation.gdmmeta.dao.mongodb.DaoConfig;
import com.convertlab.foundation.gdmmeta.service.GdmEntityMetaService;
import com.convertlab.foundation.gdmmeta.service.GdmTableMetaService;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.jdbc.datasource.DynamicDataSource;
import com.convertlab.foundation.library.jdbc.property.ExtraDataSourceProperties;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.sqlprocessor.ProcessingMode;
import com.convertlab.foundation.library.support.DatabaseGateKeeper;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.queryengine.service.GdmQueryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.info.BuildProperties;

import javax.annotation.Nonnull;
import javax.sql.DataSource;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.Objects;

import static com.convertlab.foundation.library.business.autoconfigure.SpringBeans.exitOnError;

/**
 * A pretty simple tenantWarmup class to warm up the system.
 * Besides, it should check necessities and fail-fast if they are not met!!!
 */
@Slf4j
public class SystemWarmup implements CommandLineRunner {
    public static final int PRE_CHECK_FAILURE = 10;
    private static final int META_DAO_CHECK_FAILURE = 11;

    @Value("${convertlab.warmup.exit-on-error-demo:false}")
    private boolean EXIT_ON_ERROR_DEMO;
    @Value("${convertlab.warmup.tenants:1}")
    private Long[] TENANT_LIST;
    @Value("${convertlab.warmup.skip-pre-check:false}")
    private Boolean SKIP_PRE_CHECK;
    @Autowired
    GdmTableMetaService gdmTableMetaService;

    @Autowired
    GdmEntityMetaService gdmEntityMetaService;

    @Autowired
    GdmQueryService gdmQueryService;

    @Autowired
    BuildProperties buildProperties;

    @Autowired
    ExtraDataSourceProperties dataSourceProperties;

    @Autowired
    DataSource dynamicDataSource;

    @Override
    public void run(String... args) throws Exception {
        try {
            if (!SKIP_PRE_CHECK)
                systemPreCheck();
            systemWarmup();
            for (Long tenant : TENANT_LIST) {
                try (TemporaryTenantContext ignored = new TemporaryTenantContext(tenant)) {
                    log.info("Warming up tenant {}...", tenant);
                    tenantWarmup();
                }
            }
        } catch (Exception e) {
            log.error("System warmup failed.", e);
        }
    }

    /**
     * Do the fail fast!!!
     */
    private void systemPreCheck() {
        checkExitOnErrorDemo();
        checkMysqlCollation();
        checkMetaDaoConfig();
    }

    private void checkExitOnErrorDemo() {
        try {
            if (EXIT_ON_ERROR_DEMO) throw new IllegalStateException("Demo模式下，退出程序。");
        } catch (IllegalStateException e) {
            String reason = "配置中启用了测试FAIL ON ERROR。";
            exitOnError(PRE_CHECK_FAILURE, reason, e);
        }
    }

    private void checkMetaDaoConfig() {
        try {
            DaoConfig.ensureAllRegistered();
        } catch (DaoConfig.NotRegisteredException e) {
            String reason = "Developer添加了新的MetaType，但是没有注册到DaoConfig中，将会导致不能正常存取数据。肯定是代码写错了！EXIT APPLICATION.";
            exitOnError(META_DAO_CHECK_FAILURE, reason, e);
        }
    }

    private void checkMysqlCollation() {
        dataSourceProperties.getOltp().getDatasources().forEach((key, value) -> {
            if (value == null || value.getHikari() == null)
                return;
            String jdbcUrl = value.getHikari().getJdbcUrl();
            String username = value.getHikari().getUsername();
            String password = value.getHikari().getPassword();
            DataSource ds = null;
            if (dynamicDataSource instanceof DynamicDataSource) {
                ds = (DataSource) ((DynamicDataSource) dynamicDataSource).getDataSourceMap().get(key);
            }
            if (jdbcUrl.contains("jdbc:mysql")) {
                DatabaseGateKeeper databaseGateKeeper = getDatabaseGateKeeper(ds, jdbcUrl, username, password);
                try {
                    databaseGateKeeper.checkDatabaseTimezone();
                    if (key.contains("su"))
                        databaseGateKeeper.checkCollationSettings("customer_meta");
                    else
                        databaseGateKeeper.checkCollationSettings("dept");
                } catch (Exception e) {
                    String reason = "数据库CollationSettings配置不正确, 退出程序。请检查 " + key + " jdbcUrl里的connectionCollation配置.\n" +
                            "  DatabaseGateKeeper checkCollationSettings failed. EXIT APPLICATION.";
                    exitOnError(PRE_CHECK_FAILURE, reason, e);
                }
            }
        });
    }

    @Nonnull
    private static DatabaseGateKeeper getDatabaseGateKeeper(DataSource ds, String jdbcUrl, String username, String password) {
        if (ds!=null)
            return new DatabaseGateKeeper(ds, jdbcUrl);
        return new DatabaseGateKeeper(jdbcUrl, username, password);
    }

    private void systemWarmup() {
        log.info("Warming up system...");
        log.info("BuildProperties( build version ): {}", JsonUtils.instanceOfDto().obj2Json(buildProperties));
    }

    private void tenantWarmup() {
        log.info("Warming up gdmStorageMetaRtClient...");
        gdmTableMetaService.getTableList().forEach(table -> gdmTableMetaService.getGdmTableByName(table.getTableName()));
        log.info("Warming up gsMetaClient...");
        GdmEntity customer = Objects.requireNonNull(gdmEntityMetaService.getGdmEntityByName("customer")).newGdmEntityInstance();
        GdmQuery.@NotNull Request request = new GdmQuery.Request("select * from customer limit 2",
                new ArrayList<>(),null, false, ProcessingMode.OLAP.toString());
        gdmQueryService.query(request);
        log.info("Warming up gsMetaClient for entity {}...", customer);
    }
}
