package com.convertlab.foundation.user.model;
import lombok.Data;

import java.util.List;

@Data
public class MoveDeptDTO {

    private String fromDeptCode;
    private List<String> toDeptCodes;
    private List<Long> userIds;

}