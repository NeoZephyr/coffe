package com.convertlab.foundation.user.controller.bff;

import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.library.webmvc.annotation.ViewController;
import com.convertlab.foundation.user.entity.DpTask;
import com.convertlab.foundation.user.model.CreateDpTaskReq;
import com.convertlab.foundation.user.service.DeptTaskService;
import com.convertlab.foundation.user.utils.DpTaskStatus;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import javax.annotation.Nonnull;
import java.util.HashMap;
import java.util.Map;

@ViewController
public class DeptTaskController {

    private final DeptTaskService deptTaskService;

    public DeptTaskController(DeptTaskService deptTaskService) {
        this.deptTaskService = deptTaskService;
    }

    @Nonnull
    @PostMapping("/deptTask/create")
    public DpTask create(@RequestBody CreateDpTaskReq req) {
        return deptTaskService.create(req);
    }

    @Nonnull
    @PostMapping("/deptTask/start/{id}")
    public DpTask start(@PathVariable Long id) {
        return deptTaskService.start(id);
    }

    @Nonnull
    @GetMapping("/deptTask/show/{id}")
    public Map<String, Object> show(@PathVariable Long id) {
        DpTask task = deptTaskService.show(id);
        Map<String, Object> result = new HashMap<>();
        result.put("id", task.getId());
        result.put("type", task.getType());
        result.put("status", task.getStatus());
        result.put("taskDef", task.getTaskDef());
        result.put("attachmentId", task.getAttachmentId());
        result.put("failedAttachmentId", task.getFailedAttachmentId());

        if (StringUtils.equals(task.getStatus(), DpTaskStatus.failed.toString())) {
            Map error = JsonUtils.instance().json2Obj(task.getFailReason(), Map.class);

            if (error == null) {
                result.put("failReason", task.getFailReason());
            } else {
                result.put("error", error);
            }
        }

        return result;
    }
}
