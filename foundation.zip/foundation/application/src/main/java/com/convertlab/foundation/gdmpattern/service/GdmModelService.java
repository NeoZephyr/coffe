package com.convertlab.foundation.gdmpattern.service;

import com.convertlab.data.job.core.biz.model.BizJobRunResult;
import com.convertlab.foundation.api.gdm.pattern.dto.*;
import com.convertlab.foundation.api.gdm.pattern.facade.GdmMetaFacade;
import com.convertlab.foundation.gdmdata.mapper.GdmDataMapper;
import com.convertlab.foundation.gdmmeta.utils.GdmNamingUtils;
import com.convertlab.foundation.gdmpattern.custom.CustomizableTable;
import com.convertlab.foundation.gdmpattern.custom.CustomizableTableFactory;
import com.convertlab.foundation.gdmpattern.job.GdmModelJobClient;
import com.convertlab.foundation.gdmpattern.model.GdmEntityProvision;
import com.convertlab.foundation.gdmpattern.model.GdmModel;
import com.convertlab.foundation.gdmpattern.model.ModelUtils;
import com.convertlab.foundation.gdmpattern.model.UdoProvision;
import com.convertlab.foundation.gdmpattern.provisioner.AttributedSegmentFamilyProvisioner;
import com.convertlab.foundation.gdmpattern.provisioner.CustomizedEventProvisioner;
import com.convertlab.foundation.gdmpattern.provisioner.SystemEventProvisioner;
import com.convertlab.foundation.gdmpattern.provisioner.UdoProvisionerFactory;
import com.convertlab.foundation.library.business.audit.AuditEvent;
import com.convertlab.foundation.library.business.audit.AuditEventType;
import com.convertlab.foundation.library.business.audit.AuditOperations;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BackendException;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.gdmmeta.model.entity.GdmEntityRequest;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.GdmEntityExt;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.Ref;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationship;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationshipRequest;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmSingularGdmRelationship;
import com.convertlab.foundation.library.redis.annotation.RedisLock;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.library.utils.Try;
import com.google.common.collect.Lists;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import javax.annotation.Nonnull;
import javax.validation.constraints.NotNull;
import java.util.*;
import java.util.stream.Collectors;

import static com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto.ProvisionStatus.PROVISIONED;
import static com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto.anyFeatureOn;
import static com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto.featureOn;
import static com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto.Feature.*;
import static com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto.PROVISIONABLES;
import static com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto.ProvisionType;
import static com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto.ProvisionType.isUdoBased;
import static com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto.UdoDomains.*;
import static com.convertlab.foundation.gdmpattern.provisioner.CustomizedEventProvisioner.buildEventName;
import static com.convertlab.foundation.gdmpattern.provisioner.SystemEventProvisioner.UDO_EVENT_PREFIX;
import static com.convertlab.foundation.gdmpattern.service.Constraints.getPreferredProvisionType;
import static com.convertlab.foundation.gdmpattern.service.PojoUtils.validatePojo;
import static com.convertlab.foundation.library.gdmmeta.model.general.BaseMetaSchema.CacheNames.GDM_META;
import static com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationship.Cardinality.MANY_TO_ONE;

@RequiredArgsConstructor
@Slf4j
@SuppressWarnings({"rawtypes", "unchecked"})
public class GdmModelService {
    @Nonnull
    private final GdmMetaFacade gdmMetaFacade;
    @Nonnull
    private final GdmProvisionService gdmProvisionService;
    @Nonnull
    private final GdmDataMapper gdmDataMapper;
    @Nonnull
    private final GdmModelJobClient gdmModelJobClient;
    @Nonnull
    private final CustomizableTableFactory customizableTableFactory;
    @Nonnull
    private final AuditOperations auditOperations;
    @Nonnull
    private final TableProvisionService tableProvisionService;

    public GdmModelDto findByName(String modelName) {
        GdmModelDto gdmModelDto = gdmMetaFacade.findModelByNameAndLoadSystemEvents(modelName);
        if (gdmModelDto == null) {
            throw new BackendException(CommonErrors.DATA_NOT_FOUND, "Model " + modelName + " is not found");
        }
        return gdmModelDto;
    }

    @Nonnull
    @RedisLock(key = "#{'defineGdmModel.'+#modelRequest.name}")
    public GdmModelDto defineGdmModel(@Nonnull @NotNull DefineGdmModelRequest modelRequest) {
        validatePojo(modelRequest);
        String modelName = modelRequest.getName();
        // todo: Clearly split the code into three sections: 1: Pre-Check, 2: Do-it, 3: Error-handling
        // Check model
        shouldNotExist(modelName);
        // Check Provision Type vs Patterns, and Correct it!
        modelRequest.getProps().setProvisionType(checkAndCorrectProvisionType(modelRequest.getProps().getProvisionType(), modelRequest.getPatterns()));

        GdmModel model = JsonUtils.instanceOfDto().convert(modelRequest, GdmModel.class);
        List<String> systemEventIds = modelRequest.getSystemEventIds();
        if (!CollectionUtils.isEmpty(systemEventIds)) {
            List<String> notExistSystemEventIds = systemEventIds.stream()
                    .filter(x -> !udoSystemEventExist(x))
                    .collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(notExistSystemEventIds)) {
                throw new BackendException(CommonErrors.VALIDATION_ERROR, "System event id(s) " + StringUtils.join(notExistSystemEventIds, ",") + " not found.");
            }
        }
        UdoProvision masterProvision = model.buildMasterProvision(systemEventIds, modelRequest.getFeatures());
        assertRelationshipsAvailable(modelName, modelRequest.getFields());

        if (!gdmProvisionService.doProvision(masterProvision)) {
            throw new BackendException(CommonErrors.GENERAL_ERROR, "Failed to doProvision master entity " + modelName);
        }
        model.provisionFeatures(masterProvision);
        model.setProvisionStatus(PROVISIONED);
        createFkRelationships(modelName, modelRequest.getFields());
        boolean saved = gdmMetaFacade.saveModel(model.toPo());
        if (!saved) {
            throw new BackendException(CommonErrors.GENERAL_ERROR, "Save gdm model failed" + modelName);
        }
        log.info("Save gdm model {} successfully.", modelName);
        Try.logAndIgnoreException(() -> auditOperations.log(new AuditEvent(AuditEventType.CREATE_ENTITY, "gdm-models", modelName, modelName, null, model.toDto())));
        return findByName(modelName);
    }


    private ProvisionType checkAndCorrectProvisionType(ProvisionType provisionType, String[] patterns) {
        ProvisionType preferredProvisionType = getPreferredProvisionType(patterns, provisionType);
        if (preferredProvisionType != provisionType) {
            log.warn("Patterns和Provision不匹配,期望的是: {}", preferredProvisionType);
            return preferredProvisionType;
        }
        return provisionType;
    }

    @Nonnull
    @CacheEvict(cacheNames = GDM_META, key = "('model:').concat(#modelName)", condition = "#modelName!=null")
    @RedisLock(key = "#{'updateGdmModelDef.'+#modelName}")
    public GdmModelDto updateGdmModelDef(@Nonnull String modelName, @NotNull ModifyGdmModelRequest modifyRequest) {
        GdmModel model = mustExist(modelName);
        if (!featureOn(model.getFeatures(), Event)) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "No such feature " + Event + " supported in model " + modelName);
        }
        List<String> eventsToBeAdded = modifyRequest.getEventsToBeAdded();
        if (!CollectionUtils.isEmpty(eventsToBeAdded)) {
            List<String> existedEventIds = eventsToBeAdded.stream()
                    .filter(x -> gdmMetaFacade.entityExist(model.getEventEntityNameById(x).getEventEntityName()))
                    .collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(existedEventIds)) {
                throw new BackendException(CommonErrors.VALIDATION_ERROR, "Below events " + StringUtils.join(existedEventIds, ",") + " already existed  in model " + modelName);
            }
        }
        List<String> eventsToBeRemoved = modifyRequest.getEventsToBeRemoved();
        if (!CollectionUtils.isEmpty(eventsToBeRemoved)) {
            List<String> notExistSystemEventIds = eventsToBeRemoved.stream()
                    .filter(x -> !udoSystemEventExist(x))
                    .collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(notExistSystemEventIds)) {
                throw new BackendException(CommonErrors.VALIDATION_ERROR, "Below events " + StringUtils.join(notExistSystemEventIds, ",") + " are not found in model " + modelName);
            }
            List<String> nonEmptyEventIds = eventsToBeRemoved.stream()
                    .filter(x -> gdmDataMapper.statsByEntity(model.getEventEntityNameById(x).getEventEntityName()) > 0)
                    .collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(nonEmptyEventIds)) {
                throw new BackendException(CommonErrors.VALIDATION_ERROR, "Can not drop non-empty entities " + StringUtils.join(nonEmptyEventIds, ","));
            }
        }
        if (modifyRequest.getFeatures() != null) {
            model.reProvisionFeatures(modifyRequest.getFeatures());
        }
        if (!CollectionUtils.isEmpty(modifyRequest.getEventsToBeAdded()) || !CollectionUtils.isEmpty(modifyRequest.getEventsToBeRemoved())) {
            SystemEventProvisioner eventProvisioner = (SystemEventProvisioner) UdoProvisionerFactory.findByFeatureGroup(GdmPatternDto.FeatureGroup.Event);
            eventProvisioner.updateSystemEvents(model, modifyRequest.getEventsToBeAdded(), modifyRequest.getEventsToBeRemoved());
        }
        boolean updated = gdmMetaFacade.updateModel(model.toPo());
        if (!updated) {
            throw new BackendException(CommonErrors.GENERAL_ERROR, "Update gdm model failed " + modelName);
        }
        log.info("Update gdm model {} successfully.", modelName);
        return findByName(modelName);
    }

    public BizJobRunResult dropGdmModel(@Nonnull String modelName, String bizInfo, boolean deleteData) {
        GdmModel gdmModel = mustExist(modelName);
        if (gdmModel.getProps() == null || ! isUdoBased(gdmModel.getProps().getProvisionType())) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Can not drop non-udo provisioned model " + modelName);
        }
        log.info("Start to drop gdm model {}.", modelName);
        if (!deleteData) {
            dropGdmModelDef(modelName);
            BizJobRunResult bizJobRunResult = new BizJobRunResult();
            bizJobRunResult.setRunStatus("FINISHED");
            return bizJobRunResult;
        }
        return gdmModelJobClient.startTaskToDropGdmModel(gdmModel, bizInfo);
    }

    @CacheEvict(cacheNames = GDM_META, key = "('model:').concat(#modelName)", condition = "#modelName!=null")
    @RedisLock(key = "#{'dropGdmModelDef.'+#modelName}")
    public void dropGdmModelDef(String modelName) {
        GdmModelDto modelDto = gdmMetaFacade.findModelByNameAndLoadSystemEvents(modelName);
        Assert.notNull(modelDto, "Gdm model not found " + modelName);
        GdmModel gdmModel = GdmModel.fromDto(modelDto);
        if (gdmModel.getProps() == null || ! isUdoBased(gdmModel.getProps().getProvisionType())) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Can not drop non-udo provisioned model " + modelName);
        }
        gdmModel.reProvisionFeatures(Lists.newArrayList());

        List<GdmRelationship> relationships = gdmMetaFacade.getRelationship(modelName);
        if (!CollectionUtils.isEmpty(relationships)) {
            relationships.forEach(rel -> Try.logAndIgnoreException(() -> deleteGdmRelationship(rel.getLeftEntityName(), rel.getName())));
        }

        //删除反向且单向的关系
        List<GdmRelationship> backUnidirectionalRelationships = gdmMetaFacade.getBackUnidirectionalRelationships(modelName);
        if (!CollectionUtils.isEmpty(backUnidirectionalRelationships)) {
            backUnidirectionalRelationships.forEach(rel -> Try.logAndIgnoreException(() -> deleteGdmRelationship(rel.getLeftEntityName(), rel.getName())));
        }
        gdmMetaFacade.deleteEntity(modelName);

        Try.logAndIgnoreException(() -> gdmMetaFacade.deleteModel(modelName));
        Try.logAndIgnoreException(() -> auditOperations.log(new AuditEvent(AuditEventType.DELETE_ENTITY, "gdm-models", modelName, modelName, gdmModel.toDto(), null)));

        log.info("dropGdmModelDef : gdm-models/{}", modelName);
    }

    public void dropGdmEntityDef(String entityName) {
        GdmEntity entity = gdmMetaFacade.getEntity(entityName);
        List<GdmRelationship> relationships = gdmMetaFacade.getRelationship(entityName);
        if (!CollectionUtils.isEmpty(relationships)) {
            relationships.forEach(rel -> Try.logAndIgnoreException(() -> deleteGdmRelationship(rel.getLeftEntityName(), rel.getName())));
        }
        gdmMetaFacade.deleteEntity(entityName);
        log.info("dropGdmEntityDef : gdm-entities/{}", entityName);
        Try.logAndIgnoreException(() -> auditOperations.log(new AuditEvent(AuditEventType.DELETE_ENTITY, "gdm-models", entityName, entityName, entity, null)));
    }

    @CacheEvict(cacheNames = GDM_META, key = "('model:').concat(#modelName)", condition = "#modelName!=null")
    @RedisLock(key = "#{'defineGdmModelEvent.'+#modelName}")
    public GdmModelDto defineGdmModelEvent(@Nonnull String modelName, String eventId, List<GdmModelDto.Field> eventFields) {
        GdmModel gdmModel = mustExist(modelName);
        if (gdmModel.eventExist(eventId)) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Event " + eventId + " already defined in model " + modelName);
        }
        if (!featureOn(gdmModel.getFeatures(), Event)) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Customized event is not supported in model " + modelName);
        }
        if (CollectionUtils.isEmpty(eventFields)) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "No fields definition found for the customized event " + modelName + "." + eventId);
        }
        List<GdmModelDto.Field> fks = eventFields.stream()
                .filter(GdmModelDto.Field::isForeignKey)
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(fks)) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "No foreign key found for the customized event " + modelName + "." + eventId);
        }
        List<String> noRefEntityFks = fks.stream()
                .filter(x -> {
                    if (StringUtils.isBlank(x.getRefEntityName())) {
                        return true;
                    }
                    GdmEntity refEntity = gdmMetaFacade.getEntity(x.getRefEntityName());
                    return refEntity == null;
                })
                .map(GdmModelDto.Field::getFieldName)
                .collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(noRefEntityFks)) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "No ref entity found for below fk column(s) " + StringUtils.join(noRefEntityFks, ","));
        }

        List<String> typeMismatchedFks = fks.stream()
                .filter(x -> {
                    GdmField primaryKey = gdmMetaFacade.getEntityPrimaryKey(x.getRefEntityName());
                    return primaryKey == null || !x.getFieldType().equals(primaryKey.getFieldType());
                })
                .map(GdmModelDto.Field::getFieldName)
                .collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(typeMismatchedFks)) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Type mismatched with ref-entity's primary key for below fk column(s) " + StringUtils.join(typeMismatchedFks, ","));
        }
        String refToMaster = fks.stream()
                .filter(x -> x.getRefEntityName().equalsIgnoreCase(modelName))
                .map(GdmModelDto.Field::getFieldName)
                .findAny().orElse(null);
        if (StringUtils.isBlank(refToMaster)) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "No foreign key ref to master entity from customized event " + modelName + "." + eventId);
        }

        UdoProvision masterProvision = gdmModel.getMasterProvision();
        assertRelationshipsAvailable(buildEventName(modelName, eventId), eventFields);

        GdmEntityProvision eventProvision = masterProvision.provisionCustomizedEvent(masterProvision, eventId, eventFields);
        if (eventProvision == null) {
            throw new BackendException(CommonErrors.GENERAL_ERROR, "Failed to provisionCustomizedEvent event " + eventId + " in model " + modelName);
        }
        List<GdmModelDto.Field> otherFks = eventFields.stream()
                .filter(GdmModelDto.Field::isForeignKey)
                .collect(Collectors.toList());
        createFkRelationships(eventProvision.getEntityName(), otherFks);

        gdmModel.addEvent(eventId, eventProvision.getEntityName(), true);
        boolean saved = gdmMetaFacade.updateModel(gdmModel.toPo());
        if (!saved) {
            throw new BackendException(CommonErrors.GENERAL_ERROR, "Define customized event failed " + modelName + "." + eventId);
        }

        Try.logAndIgnoreException(() -> auditOperations.log(new AuditEvent(AuditEventType.CREATE_ENTITY, "gdm-models.event", modelName, eventId, null, null)));
        log.info("Define gdm model {} event {} successfully", modelName, eventId);

        return findByName(modelName);
    }

    @CacheEvict(cacheNames = GDM_META, key = "('model:').concat(#modelName)", condition = "#modelName!=null")
    @RedisLock(key = "#{'dropGdmModelEvent.'+#modelName}")
    public boolean dropGdmModelEvent(@Nonnull String modelName, @Nonnull String eventId, boolean deleteData) {
        GdmModel gdmModel = mustExist(modelName);
        GdmPatternDto.ProfileEvent profileEvent = gdmModel.getEventEntityNameById(eventId);
        if (profileEvent == null || !profileEvent.isCustomized()) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "No such customized event " + eventId + " in model " + modelName);
        }

        Long count = gdmDataMapper.statsByEntity(profileEvent.getEventEntityName());
        if (deleteData && count > 0) {
            gdmModelJobClient.startTaskToDropGdmEntity(profileEvent.getEventEntityName());
        } else {
            CustomizedEventProvisioner eventProvisioner = new CustomizedEventProvisioner();
            eventProvisioner.unProvision(gdmModel.getMasterProvision(), eventId);
            Try.logAndIgnoreException(() -> auditOperations.log(new AuditEvent(AuditEventType.DELETE_ENTITY, "gdm-models.event", modelName, eventId, null, null)));
        }
        gdmModel.dropEvent(eventId);
        boolean updated = gdmMetaFacade.updateModel(gdmModel.toPo());
        if (updated) {
            log.info("Drop gdm model {} event {} successfully", modelName, eventId);
        }
        return updated;
    }

    @CacheEvict(cacheNames = GDM_META, key = "('model:').concat(#modelName)", condition = "#modelName!=null")
    @RedisLock(key = "#{'defineGdmModelAttributedSegmentFamily.'+#modelName}")
    public GdmModelDto defineGdmModelAttributedSegmentFamily(@Nonnull String modelName, String segmentFamilyEntityName, List<GdmModelDto.Field> segmentFamilyFields) {
        GdmModel gdmModel = mustExist(modelName);
        String shortName = ModelUtils.getShortName(modelName);
        log.info("Extracted model name: {}", shortName);
        // segmentFamilyEntityName should begin with "cf_<shortName>"
        // todo: known issue: 对于customer， 如果客户创建了一个c_customer这种UDO， 则系统不可能支持！！！
        if (!segmentFamilyEntityName.startsWith("cf_" + shortName.toLowerCase())) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Segment family entity name " + segmentFamilyEntityName + " should begin with 'cf_" + shortName.toLowerCase() + "'");
        }

        if (gdmModel.attributedSegmentFamilyExist(segmentFamilyEntityName)) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Attributed segment family " + segmentFamilyEntityName + " already defined in model " + modelName);
        }
        if(!GdmNamingUtils.isValidTenantEntityName(segmentFamilyEntityName)) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Attributed segment family "+ segmentFamilyEntityName+ " is invalid, must started with c_/cf_");
        }
        if (!anyFeatureOn(gdmModel.getFeatures(), StaticSegment, DynamicSegment)) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Attributed segment family is not supported in model " + modelName);
        }
        if (CollectionUtils.isEmpty(segmentFamilyFields)) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "No fields definition found for the attributed segment family, Model Name:[ " + modelName + "] Segment Family:[" + segmentFamilyEntityName + "]");
        }
        List<GdmModelDto.Field> fks = segmentFamilyFields.stream()
                .filter(GdmModelDto.Field::isForeignKey)
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(fks)) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "No foreign key found for the attributed segment family " + modelName + "." + segmentFamilyEntityName);
        }
        List<String> noRefEntityFks = fks.stream()
                .filter(x -> {
                    if (StringUtils.isBlank(x.getRefEntityName())) {
                        return true;
                    }
                    GdmEntity refEntity = gdmMetaFacade.getEntity(x.getRefEntityName());
                    return refEntity == null;
                })
                .map(GdmModelDto.Field::getFieldName)
                .collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(noRefEntityFks)) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "No ref entity found for below fk column(s) " + StringUtils.join(noRefEntityFks, ","));
        }

        List<String> typeMismatchedFks = fks.stream()
                .filter(x -> {
                    GdmField primaryKey = gdmMetaFacade.getEntityPrimaryKey(x.getRefEntityName());
                    return primaryKey == null || !x.getFieldType().equals(primaryKey.getFieldType());
                })
                .map(GdmModelDto.Field::getFieldName)
                .collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(typeMismatchedFks)) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Type mismatched with ref-entity's primary key for below fk column(s) " + StringUtils.join(typeMismatchedFks, ","));
        }
        String refToMaster = fks.stream()
                .filter(x -> x.getRefEntityName().equalsIgnoreCase(modelName))
                .map(GdmModelDto.Field::getFieldName)
                .findAny().orElse(null);
        if (StringUtils.isBlank(refToMaster)) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "No foreign key ref to master entity from attributed segment family " + modelName + "." + segmentFamilyEntityName);
        }

        UdoProvision masterProvision = gdmModel.getMasterProvision();
        assertRelationshipsAvailable(segmentFamilyEntityName, segmentFamilyFields);

        GdmEntity attributedSegmentFamilyEntity = tableProvisionService.buildGdmEntity(segmentFamilyEntityName, segmentFamilyFields);
        boolean tableProvisioned = tableProvisionService.provision(attributedSegmentFamilyEntity, ATTRIBUTED_SEGMENT_FAMILY_PARTITION_BY_FIELDS);
        if(!tableProvisioned) {
            throw new BackendException(CommonErrors.BACKEND_EXCEPTION, "Failed to create table "+segmentFamilyEntityName);
        }
        GdmEntityProvision segmentFamilyProvision = masterProvision.provisionAttributedSegmentFamily(masterProvision, segmentFamilyEntityName, segmentFamilyFields);
        if (segmentFamilyProvision == null) {
            throw new BackendException(CommonErrors.GENERAL_ERROR, "Failed to doProvision attributed segment family " + segmentFamilyEntityName + " in model " + modelName);
        }
        List<GdmModelDto.Field> otherFks = segmentFamilyFields.stream()
                .filter(GdmModelDto.Field::isForeignKey)
                .collect(Collectors.toList());
        createFkRelationships(segmentFamilyProvision.getEntityName(), otherFks);

        gdmModel.addAttributedSegmentFamily(segmentFamilyEntityName);
        boolean saved = gdmMetaFacade.updateModel(gdmModel.toPo());
        if (!saved) {
            throw new BackendException(CommonErrors.GENERAL_ERROR, "Define attributed segment family failed " + modelName + "." + segmentFamilyEntityName);
        }

        Try.logAndIgnoreException(() -> auditOperations.log(new AuditEvent(AuditEventType.CREATE_ENTITY, "gdm-models.attributedSegmentFamily", modelName, segmentFamilyEntityName, null, null)));
        log.info("Define gdm model {} attributed segment family {} successfully", modelName, segmentFamilyProvision);

        return findByName(modelName);
    }

    @CacheEvict(cacheNames = GDM_META, key = "('model:').concat(#modelName)", condition = "#modelName!=null")
    @RedisLock(key = "#{'dropGdmModelAttributedSegmentFamily.'+#modelName}")
    public boolean dropGdmModelAttributedSegmentFamily(@Nonnull String modelName, @Nonnull String segmentFamilyEntityName, boolean deleteData) {
        GdmModel gdmModel = mustExist(modelName);
        if(!gdmModel.attributedSegmentFamilyExist(segmentFamilyEntityName)) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Attributed segment family "+segmentFamilyEntityName+ " is not found in model "+modelName);
        }

        if (deleteData) {
            GdmEntity attributedSegmentFamilyEntity = gdmMetaFacade.getEntity(segmentFamilyEntityName);
            if(attributedSegmentFamilyEntity != null) {
                tableProvisionService.unProvision(attributedSegmentFamilyEntity);
            }
        }
        AttributedSegmentFamilyProvisioner provisioner = new AttributedSegmentFamilyProvisioner();
        provisioner.unProvision(gdmModel.getMasterProvision(), segmentFamilyEntityName);
        Try.logAndIgnoreException(() -> auditOperations.log(new AuditEvent(AuditEventType.DELETE_ENTITY, "gdm-models.attributedSegmentFamily", modelName, segmentFamilyEntityName, null, null)));

        gdmModel.dropAttributedSegmentFamily(segmentFamilyEntityName);
        boolean updated = gdmMetaFacade.updateModel(gdmModel.toPo());
        if (updated) {
            log.info("Drop gdm model {} attributedSegment {} successfully", modelName, segmentFamilyEntityName);
        }
        return updated;
    }

    @RedisLock(key = "#{'updateGdmEntity.'+#entityName}")
    public boolean updateGdmEntity(@Nonnull String entityName, @Nonnull ModifyGdmEntityRequest modifyRequest) {
        GdmEntity entity = gdmMetaFacade.getEntity(entityName);
        GdmEntityExt entityExt = gdmMetaFacade.getEntityExt(entityName);

        Assert.notNull(entity, "Gdm entity not found " + entityName);
        if (CollectionUtils.isEmpty(modifyRequest.getFieldsToBeAdded()) && CollectionUtils.isEmpty(modifyRequest.getFieldsToBeRemoved())) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Nothing to be updated");
        }
        CustomizableTable customizableTable = customizableTableFactory.get(entity.getDbTableName());
        if (customizableTable == null) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Entity " + entityName + " is not customizable");
        }
        GdmEntityRequest gdmEntityRequest = new GdmEntityRequest(entity);
        List<GdmField> finalFields = Lists.newArrayList(gdmEntityRequest.getFields());
        List<GdmEntityExt.Props> finalProps = entityExt==null || entityExt.getProps()==null ? new ArrayList<>() : Lists.newArrayList(entityExt.getProps());

        if (!CollectionUtils.isEmpty(modifyRequest.getFieldsToBeAdded())) {
            assertRelationshipsAvailable(entityName, modifyRequest.getFieldsToBeAdded());

            List<String> existedFields = modifyRequest.getFieldsToBeAdded().stream()
                    .map(GdmModelDto.Field::getFieldName)
                    .filter(x -> entity.getFieldsMap().get(x) != null)
                    .collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(existedFields)) {
                throw new BackendException(CommonErrors.VALIDATION_ERROR, "Below fields " + StringUtils.join(existedFields, ",") + " already existed in entity " + entityName);
            }
            List<GdmField> newFields = gdmProvisionService.buildGdmField(entity, modifyRequest.getFieldsToBeAdded());
            List<GdmEntityExt.Props> newProps = gdmProvisionService.buildExtProps(entityExt, modifyRequest.getFieldsToBeAdded());

            finalFields.addAll(newFields);
            if (finalProps!=null) finalProps.addAll(newProps);
        }
        List<String> fieldsToBeRemoved = modifyRequest.getFieldsToBeRemoved();
        if (!CollectionUtils.isEmpty(fieldsToBeRemoved)) {
            List<String> noExistFields = fieldsToBeRemoved.stream()
                    .filter(field -> entity.getFieldsMap().get(field) == null)
                    .collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(noExistFields)) {
                throw new BackendException(CommonErrors.VALIDATION_ERROR, "Can not drop non-exist fields " + StringUtils.join(noExistFields, ",") + " in entity " + entityName);
            }
            List<String> systemFields = fieldsToBeRemoved.stream()
                    .map(field -> entity.getFieldsMap().get(field))
                    .filter(Objects::nonNull)
                    .filter(x -> !customizableTable.isCustomizedColumn(x))
                    .map(GdmField::getFieldName)
                    .collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(systemFields)) {
                throw new BackendException(CommonErrors.VALIDATION_ERROR, "Can not drop system fields " + StringUtils.join(systemFields, ",") + " in entity " + entityName);
            }
            List<String> emptyFieldsToBeRemoved;
            if (modifyRequest.getDeleteData()) {
                Map<String, Long> fieldsStats = gdmDataMapper.statsByFields(entityName, fieldsToBeRemoved);
                List<String> nonEmptyFields = fieldsToBeRemoved.stream()
                        .filter(x -> fieldsStats.get(x) > 0)
                        .collect(Collectors.toList());
                emptyFieldsToBeRemoved = fieldsToBeRemoved.stream()
                        .filter(x -> fieldsStats.get(x) == 0)
                        .collect(Collectors.toList());
                if (!CollectionUtils.isEmpty(nonEmptyFields)) {
                    // 异步删除有值的属性及其数据
                    gdmModelJobClient.startTaskToDropGdmFields(entity, nonEmptyFields);
                }
                fieldsToBeRemoved = emptyFieldsToBeRemoved;
            } else {
                emptyFieldsToBeRemoved = fieldsToBeRemoved;
            }
            // 先删除emptyFields，有值的异步删除
            finalFields = finalFields.stream()
                    .filter(x -> !emptyFieldsToBeRemoved.contains(x.getFieldName()))
                    .collect(Collectors.toList());
            if (finalProps != null)
                finalProps = finalProps.stream()
                    .filter(x -> !emptyFieldsToBeRemoved.contains(x.getFieldName()))
                    .collect(Collectors.toList());
        }
        gdmEntityRequest.setFields(finalFields);

        boolean updated = gdmMetaFacade.updateEntity(gdmEntityRequest);
        List<GdmEntityExt.Props> props = finalProps;

        if (entityExt==null) {
            GdmEntityExt updatedEntityExt = GdmEntityExt.builder().entityRef(new Ref.EntityRef(gdmEntityRequest.getEntityName()))
                    .displayLabel(modifyRequest.getDisplayLabel())
                    .description(modifyRequest.getDescription())
                    .ext(modifyRequest.getExt())
                    .props(props)
                    .build();
            gdmMetaFacade.createEntityExt(updatedEntityExt);
        } else {
            entityExt.setProps(props);
            if (modifyRequest.getDisplayLabel() != null) entityExt.setDisplayLabel(modifyRequest.getDisplayLabel());
            if (modifyRequest.getDescription() != null ) entityExt.setDescription(modifyRequest.getDescription());
            if (modifyRequest.getExt() != null) entityExt.setExt(modifyRequest.getExt());
            gdmMetaFacade.updateEntityExt(entityExt);
        }
        if (updated) {
            createFkRelationships(entityName, modifyRequest.getFieldsToBeAdded());
            deleteFkRelationships(entityName, fieldsToBeRemoved);
        }
        log.info("Update gdm entity {} successfully", entityName);
        return updated;
    }

    @RedisLock(key = "#{'dropGdmEntityFields.'+#entityName}")
    public boolean dropGdmEntityFields(String entityName, List<String> fieldsToBeRemoved) {
        GdmEntity entity = gdmMetaFacade.getEntity(entityName);
        GdmEntityExt entityExt = gdmMetaFacade.getEntityExt(entityName);

        Assert.notNull(entity, "Gdm entity not found " + entityName);
        if (CollectionUtils.isEmpty(fieldsToBeRemoved)) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Nothing to be updated");
        }
        CustomizableTable customizableTable = customizableTableFactory.get(entity.getDbTableName());
        if (customizableTable == null) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Entity " + entityName + " is not customizable");
        }
        GdmEntityRequest gdmEntityRequest = new GdmEntityRequest(entity);
        List<GdmField> finalFields = Lists.newArrayList(gdmEntityRequest.getFields());
        List<GdmEntityExt.Props> props = entityExt==null ? null : Lists.newArrayList(entityExt.getProps());
        finalFields = finalFields.stream().filter(x -> !fieldsToBeRemoved.contains(x.getFieldName())).collect(Collectors.toList());
        if (props != null) props = props.stream().filter(x -> !fieldsToBeRemoved.contains(x.getFieldName())).collect(Collectors.toList());
        gdmEntityRequest.setFields(finalFields);

        boolean updated = gdmMetaFacade.updateEntity(gdmEntityRequest);

        if (updated) {
            deleteFkRelationships(entityName, fieldsToBeRemoved);
            if (entityExt!=null) {
                entityExt.setProps(props);
                gdmMetaFacade.updateEntityExt(entityExt);
            }
        }
        log.info("dropGdmEntityFieldsDef : gdm-entity/{}", entityName);
        return updated;
    }

    protected void assertRelationshipAvailable(@Nonnull GdmRelationshipRequest relationshipRequest) {
        String leftEntityName = relationshipRequest.getLeftEntityName();
        String rightEntityName = relationshipRequest.getRightEntityName();
        String relationName = relationshipRequest.getName();
        String reverseName = relationshipRequest.getReverseName();
        GdmRelationship relationship = gdmMetaFacade.getRelationship(leftEntityName, relationName);
        Assert.isNull(relationship, "Relation already exist " + leftEntityName + "." + relationName);
        relationship = gdmMetaFacade.getRelationship(rightEntityName, reverseName);
        Assert.isNull(relationship, "Relation already exist " + rightEntityName + "." + reverseName);
    }


    public boolean createGdmRelationship(@Nonnull GdmRelationshipRequest relationshipRequest) {
        String leftEntityName = relationshipRequest.getLeftEntityName();
        String rightEntityName = relationshipRequest.getRightEntityName();
        String relationName = relationshipRequest.getName();
        String reverseName = relationshipRequest.getReverseName();
        String foreignKeyOwningSide = relationshipRequest.getForeignKeyOwningSide();
        String mappedBy = relationshipRequest.getMappedBy();

        Assert.isTrue(StringUtils.isNoneBlank(leftEntityName,
                        rightEntityName,
                        relationName,
                        reverseName,
                        foreignKeyOwningSide,
                        mappedBy),
                "Invalid create relationship request");
        GdmEntity leftEntity = gdmMetaFacade.getEntity(leftEntityName);
        Assert.notNull(leftEntity, "Entity not found " + leftEntityName);
        GdmEntity rightEntity = gdmMetaFacade.getEntity(rightEntityName);
        assertRelationshipAvailable(relationshipRequest);

        Assert.isTrue(foreignKeyOwningSide.equalsIgnoreCase(leftEntityName) ||
                        foreignKeyOwningSide.equalsIgnoreCase(rightEntityName),
                "foreign key owning side must be eight left or right entity");
        GdmEntity fkEntity = foreignKeyOwningSide.equalsIgnoreCase(leftEntityName) ? leftEntity : rightEntity;
        boolean fkColumnExists = fkEntity.getFields().stream().anyMatch(x -> x.getFieldName().equalsIgnoreCase(mappedBy));
        Assert.isTrue(fkColumnExists, "Fk column is not found " + fkEntity.getEntityName() + "." + mappedBy);
        boolean result = gdmMetaFacade.createRelationship(relationshipRequest);
        log.info("Create gdm relationship {} successfully", relationName);
        return result;
    }

    public boolean deleteGdmRelationship(String leftEntityName, String relationName) {
        GdmRelationship relationship = gdmMetaFacade.getRelationship(leftEntityName, relationName);
        Assert.notNull(relationship, "Relationship not found " + leftEntityName + "." + relationName);

        GdmEntity leftEntity = gdmMetaFacade.getEntity(relationship.getLeftEntityName());
        Assert.notNull(leftEntity, "Entity not found " + relationship.getLeftEntityName());
        GdmEntity rightEntity = gdmMetaFacade.getEntity(relationship.getRightEntityName());
        Assert.notNull(rightEntity, "Entity not found " + relationship.getRightEntityName());

        Assert.isTrue(isFromExtendableTable(leftEntity)
                        || isFromExtendableTable(rightEntity),
                "Relationship is not for UDO-based entity");
        boolean result = gdmMetaFacade.deleteRelationship(leftEntityName, relationName);
        log.info("Delete gdm relationship {} successfully", relationName);
        return result;
    }

    /**
     * 简单实现，只判断entity是否是由可Provision的Table创造出来的。
     * @param gdmEntity entity
     * @return true/false
     */
    private static boolean isFromExtendableTable(@Nonnull GdmEntity gdmEntity) {
        return Arrays.stream(PROVISIONABLES).anyMatch(provisionable -> provisionable.getUDO_TABLE().equalsIgnoreCase(gdmEntity.getDbTableName()));
//        return UDO_TABLE.equalsIgnoreCase(rightEntity.getDbTableName());
    }

    protected GdmModel mustExist(@Nonnull String modelName) {
        GdmModelDto gdmModel = gdmMetaFacade.findModelByName(modelName);
        Assert.notNull(gdmModel, "Gdm model not found " + modelName);
        return GdmModel.fromDto(gdmModel);
    }

    protected void assertRelationshipsAvailable(String entityName, List<GdmModelDto.Field> fieldsToBeAdded) {
        if (!CollectionUtils.isEmpty(fieldsToBeAdded)) {
            List<GdmModelDto.Field> fkFields = fieldsToBeAdded.stream()
                    .filter(GdmModelDto.Field::isForeignKey)
                    .collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(fkFields)) {
                fkFields.stream()
                        .map(x -> toRelationRequest(entityName, x))
                        .forEach(this::assertRelationshipAvailable);
            }
        }
    }

    protected void createFkRelationships(String entityName, List<GdmModelDto.Field> fieldsToBeAdded) {
        if (!CollectionUtils.isEmpty(fieldsToBeAdded)) {
            List<GdmModelDto.Field> fkFields = fieldsToBeAdded.stream()
                    .filter(GdmModelDto.Field::isForeignKey)
                    .collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(fkFields)) {
                fkFields.stream()
                        .map(x -> toRelationRequest(entityName, x))
                        .forEach(x -> Try.logAndIgnoreException(() -> createGdmRelationship(x)));
            }
        }
        log.debug("createFkRelationships : gdm-entity/{}", entityName);
    }

    @Nonnull
    private GdmRelationshipRequest toRelationRequest(String entityName, GdmModelDto.Field fkField) {
        GdmRelationshipRequest request = new GdmRelationshipRequest();
        GdmRelationship.Cardinality cardinality = fkField.getCardinality() == null ? MANY_TO_ONE : fkField.getCardinality();
        request.setCardinality(cardinality);
        request.setLeftEntityName(entityName);
        request.setRightEntityName(fkField.getRefEntityName());
        String relationName = StringUtils.isBlank(fkField.getRelationName()) ? fkField.getRefEntityName() : fkField.getRelationName();
        request.setName(relationName);
        String reverseRelationName = StringUtils.isBlank(fkField.getReverseRelationName()) ? entityName + "_" + fkField.getFieldName() : fkField.getReverseRelationName();
        request.setReverseName(reverseRelationName);
        request.setIsBidirectional(true);
        request.setMappedBy(fkField.getFieldName());
        request.setForeignKeyOwningSide(entityName);
        return request;
    }

    protected void deleteFkRelationships(String entityName, List<String> fieldsToBeRemoved) {
        List<GdmRelationship> relationships = gdmMetaFacade.getRelationship(entityName);
        if (!CollectionUtils.isEmpty(fieldsToBeRemoved) && !CollectionUtils.isEmpty(relationships)) {
            for (String fieldName : fieldsToBeRemoved) {
                GdmRelationship relationship = findRelationshipByField(relationships, entityName, fieldName);
                if (relationship != null) {
                    deleteGdmRelationship(relationship.getLeftEntityName(), relationship.getName());
                }
            }
        }
        log.debug("deleteFkRelationships : gdm-entity/{}", entityName);
    }

    protected GdmRelationship findRelationshipByField(@Nonnull List<GdmRelationship> relationships, String
            entityName, String fieldName) {
        return relationships.stream()
                .map(x -> (GdmSingularGdmRelationship) x)
                .filter(x -> entityName.equals(x.getForeignKeyOwningSide()) && fieldName.equals(x.getMappedBy()))
                .findAny()
                .orElse(null);
    }

    protected void shouldNotExist(@Nonnull String modelName) {
        GdmModelDto gdmModel = Try.ignoreException(() -> gdmMetaFacade.findModelByName(modelName));
        Assert.isNull(gdmModel, "Gdm model already existed " + modelName);
    }

    private boolean udoSystemEventExist(String systemEventId) {
        String udoSystemEventEntityName = PARENT_EVENT_ID.equalsIgnoreCase(systemEventId) ?
                EVENT
                :
                UDO_EVENT_PREFIX + systemEventId;
        GdmEntity entity = gdmMetaFacade.getEntity(udoSystemEventEntityName);
        return entity != null;
    }

}
