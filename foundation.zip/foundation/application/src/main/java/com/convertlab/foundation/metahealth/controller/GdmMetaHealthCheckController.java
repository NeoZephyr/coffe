package com.convertlab.foundation.metahealth.controller;

import com.convertlab.foundation.api.gdm.pattern.GdmModelClient;
import com.convertlab.foundation.libaray.meta.health.Issue;
import com.convertlab.foundation.libaray.meta.health.MetaCheckerFactory;
import com.convertlab.foundation.libaray.meta.health.MetaLoader;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationship;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.metahealth.loader.GdmEntityLoader;
import com.convertlab.foundation.metahealth.loader.GdmModelLoader;
import com.convertlab.foundation.metahealth.loader.GdmRelationshipLoader;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/v1/meta/health")
@RequiredArgsConstructor
public class GdmMetaHealthCheckController {
    private final GsMetaClient gsMetaClient;
    private final GdmModelClient gdmModelClient;
    private final MetaCheckerFactory metaCheckerFactory;

    private final GdmEntityLoader entityLoader;
    private final GdmRelationshipLoader relationshipLoader;
    private final GdmModelLoader modelLoader;

    @GetMapping(value = {"/entities", "/entities/{entityName}"})
    public List<Issue> checkEntity(@RequestHeader(name = "x-tenant-id", defaultValue = "-1") long tenantId,
                                   @PathVariable(required = false) String entityName) {
        try (TemporaryTenantContext ignored = new TemporaryTenantContext(tenantId)) {
            return checkOneOrAll(entityName, gsMetaClient::getEntity, entityLoader);
        }
    }

    @GetMapping(value = {"/relationships", "/relationships/{leftEntity}", "/relationships/{leftEntity}/{relationName}"})
    public List<Issue> checkRelationship(@RequestHeader(name = "x-tenant-id", defaultValue = "-1") long tenantId,
                                  @PathVariable(required = false) String leftEntity,
                                  @PathVariable(required = false) String relationName) {
        try (TemporaryTenantContext ignored = new TemporaryTenantContext(tenantId)) {
            if (StringUtils.isNotBlank(leftEntity)) {
                List<GdmRelationship> relationships = gsMetaClient.getRelationships(leftEntity, relationName);
                return relationships.stream()
                        .map(metaCheckerFactory::check)
                        .flatMap(List::stream)
                        .collect(Collectors.toList());
            }

            return relationshipLoader.loadAll().stream()
                    .map(metaCheckerFactory::check)
                    .flatMap(List::stream)
                    .collect(Collectors.toList());

        }
    }

    @GetMapping(value = {"/models", "/models/{modelName}"})
    public List<Issue> checkModel(@RequestHeader(name = "x-tenant-id", defaultValue = "-1") long tenantId,
                                  @PathVariable(required = false) String modelName) {
        try (TemporaryTenantContext ignored = new TemporaryTenantContext(tenantId)) {
            return checkOneOrAll(modelName, gdmModelClient::findByName, modelLoader);
        }
    }

    protected <T> List<Issue> checkOneOrAll(String name, Function<String, T> findOne, MetaLoader<T> metaLoader) {
        if (StringUtils.isNotBlank(name)) {
            T t = findOne.apply(name);
            if (t == null) {
                throw new IllegalArgumentException(name + " is not found");
            }
            return metaCheckerFactory.check(t);
        }

        return metaLoader.loadAll().stream()
                .map(metaCheckerFactory::check)
                .flatMap(List::stream)
                .collect(Collectors.toList());
    }
}
