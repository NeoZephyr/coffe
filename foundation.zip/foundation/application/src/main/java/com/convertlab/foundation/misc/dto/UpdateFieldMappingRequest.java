package com.convertlab.foundation.misc.dto;

import lombok.Data;

@Data
public class UpdateFieldMappingRequest {
    private String entityName;
    private String fieldName;
    private String fromColumn;
    private String toColumn;
}
