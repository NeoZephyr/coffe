package com.convertlab.foundation.metahealth.checker;

import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto;
import com.convertlab.foundation.libaray.meta.health.Issue;
import com.convertlab.foundation.libaray.meta.health.MetaChecker;
import com.convertlab.foundation.libaray.meta.health.annotation.MetaCheckerAnnotation;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationship;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmSingularGdmRelationship;
import com.convertlab.foundation.library.utils.Try;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto.anyFeatureOn;
import static com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto.featureOn;
import static com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto.Feature.*;
import static com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto.FeatureGroup.Segment;
import static com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto.FeatureGroup.Traits;
import static com.convertlab.foundation.libaray.meta.health.BasicMetaValidationRule.*;

@MetaCheckerAnnotation
@RequiredArgsConstructor
public class GdmModelChecker implements MetaChecker<GdmModelDto> {
    private final GsMetaClient gsMetaClient;

    @Override
    public List<Issue> check(@Nonnull GdmModelDto model) {
        List<Issue> issues = new ArrayList<>();
        String modelName = model.getName();
        GdmEntity entity = gsMetaClient.getEntity(modelName);
        if (entity == null) {
            issues.add(RULE_02_001.toIssue(modelName));
        } else {
            if (model.isProfilePattern()) {
                String primaryKeyField = entity.getPrimaryKeyField();
                if (StringUtils.isBlank(primaryKeyField) || entity.getFieldsMap().get(primaryKeyField) == null) {
                    issues.add(RULE_01_003.toIssue(modelName));
                }

                validateTraits(model, issues);
                validateSegments(model, issues);
                validateEvents(model, issues);
                validateOrder(model, issues);
                validateIndicator(model, issues);
            }
        }

        return issues;
    }

    protected void validateTraits(GdmModelDto model, List<Issue> issues) {
        String modelName = model.getName();
        List<GdmPatternDto.Feature> features = model.getFeatures();
        String traitsDefEntityName;
        if (anyFeatureOn(features, StaticTraits, DynamicTraits)) {
            traitsDefEntityName = model.getProps().getTraitsDefEntityName();
            if (StringUtils.isBlank(traitsDefEntityName)) {
                issues.add(RULE_02_004.toIssue(modelName, Traits.name()));
            } else {
                GdmEntity traitsDefEntity = gsMetaClient.getEntity(traitsDefEntityName);
                if (traitsDefEntity == null) {
                    issues.add(RULE_02_002.toIssue(modelName, Traits.name(), traitsDefEntityName));
                }
                if (featureOn(features, StaticTraits)) {
                    String staticTraitsEntityName = model.getProps().getStaticTraitsEntityName();
                    validateAffiliatedEntity(modelName, StaticTraits.name(), staticTraitsEntityName, issues);
                    List<GdmRelationship> relationships = getRelationships(staticTraitsEntityName, traitsDefEntityName, staticTraitsEntityName);
                    if (CollectionUtils.isEmpty(relationships)) {
                        issues.add(RULE_04_004.toIssue(staticTraitsEntityName, traitsDefEntityName, staticTraitsEntityName));
                    }
                }

                if (featureOn(features, DynamicTraits)) {
                    String dynamicTraitsEntityName = model.getProps().getDynamicTraitsEntityName();
                    validateAffiliatedEntity(modelName, DynamicTraits.name(), dynamicTraitsEntityName, issues);
                    List<GdmRelationship> relationships = getRelationships(dynamicTraitsEntityName, traitsDefEntityName, dynamicTraitsEntityName);
                    if (CollectionUtils.isEmpty(relationships)) {
                        issues.add(RULE_04_004.toIssue(dynamicTraitsEntityName, traitsDefEntityName, dynamicTraitsEntityName));
                    }
                }
            }
        }
    }

    protected void validateSegments(GdmModelDto model, List<Issue> issues) {
        String modelName = model.getName();
        List<GdmPatternDto.Feature> features = model.getFeatures();
        String segmentDefEntityName;
        if (anyFeatureOn(features, StaticSegment, DynamicSegment)) {
            segmentDefEntityName = model.getProps().getSegmentDefEntityName();
            if (StringUtils.isBlank(segmentDefEntityName)) {
                issues.add(RULE_02_004.toIssue(modelName, Segment.name()));
            } else {
                GdmEntity segmentDefEntity = gsMetaClient.getEntity(segmentDefEntityName);
                if (segmentDefEntity == null) {
                    issues.add(RULE_02_002.toIssue(modelName, Segment.name(), segmentDefEntityName));
                }

                if (featureOn(features, StaticSegment)) {
                    String staticSegmentEntityName = model.getProps().getStaticSegmentEntityName();
                    validateAffiliatedEntity(modelName, StaticSegment.name(), staticSegmentEntityName, issues);
                    List<GdmRelationship> relationships = getRelationships(staticSegmentEntityName, segmentDefEntityName, staticSegmentEntityName);
                    if (CollectionUtils.isEmpty(relationships)) {
                        issues.add(RULE_04_004.toIssue(staticSegmentEntityName, segmentDefEntityName, staticSegmentEntityName));
                    }
                }

                if (featureOn(features, DynamicSegment)) {
                    String dynamicSegmentEntityName = model.getProps().getDynamicSegmentEntityName();
                    validateAffiliatedEntity(modelName, DynamicSegment.name(), dynamicSegmentEntityName, issues);
                    List<GdmRelationship> relationships = getRelationships(dynamicSegmentEntityName, segmentDefEntityName, dynamicSegmentEntityName);
                    if (CollectionUtils.isEmpty(relationships)) {
                        issues.add(RULE_04_004.toIssue(dynamicSegmentEntityName, segmentDefEntityName, dynamicSegmentEntityName));
                    }
                }
            }
        }
    }

    protected void validateEvents(GdmModelDto model, List<Issue> issues) {
        String modelName = model.getName();
        List<GdmPatternDto.Feature> features = model.getFeatures();

        if (featureOn(features, Event)) {
            GdmPatternDto.ProfileEvent[] events = model.getProps().getEvents();
            if (events == null || events.length == 0) {
                issues.add(RULE_02_004.toIssue(modelName, Event.name()));
            } else {
                for(GdmPatternDto.ProfileEvent event: events) {
                    String eventEntityName = event.getEventEntityName();
                    validateAffiliatedEntity(modelName, Event.name(), eventEntityName, issues);
                }
            }
        }
    }

    protected void validateIndicator(GdmModelDto model, List<Issue> issues) {
        String modelName = model.getName();
        List<GdmPatternDto.Feature> features = model.getFeatures();

        if(featureOn(features, Indicator)) {
            String indicatorEntityName = model.getProps().getIndicatorEntityName();
            validateAffiliatedEntity(modelName, Indicator.name(), indicatorEntityName, issues);
        }
    }

    protected void validateOrder(GdmModelDto model, List<Issue> issues) {
        String modelName = model.getName();
        List<GdmPatternDto.Feature> features = model.getFeatures();

        if(featureOn(features, Order)) {
            String orderEntityName = model.getProps().getOrderEntityName();
            validateAffiliatedEntity(modelName, Order.name(), orderEntityName, issues);
        }
    }

    protected void validateAffiliatedEntity(String modelName, String feature, String affiliatedEntityName, List<Issue> issues) {
        if(StringUtils.isBlank(affiliatedEntityName)) {
            issues.add(RULE_02_004.toIssue(modelName, feature));
        } else {
            GdmEntity eventEntity = gsMetaClient.getEntity(affiliatedEntityName);
            if(eventEntity == null) {
                issues.add(RULE_02_002.toIssue(modelName, feature, affiliatedEntityName));
            } else {
                List<GdmRelationship> relationships = getRelationships(modelName, affiliatedEntityName, affiliatedEntityName);
                if (CollectionUtils.isEmpty(relationships)) {
                    issues.add(RULE_02_003.toIssue(modelName, affiliatedEntityName));
                }
            }
        }
    }

    protected List<GdmRelationship> getRelationships(@Nonnull String leftEntityName, @Nonnull String rightEntityName, @Nonnull String fkOwningSide) {
        return Try.ignoreException(() -> {
            List<GdmRelationship> relationships = gsMetaClient.getRelationships(leftEntityName, null);
            if (CollectionUtils.isEmpty(relationships)) {
                return new ArrayList<>();
            }
            return relationships.stream()
                    .filter(x -> x.getRightEntityName().equals(rightEntityName))
                    .filter(r -> r instanceof GdmSingularGdmRelationship)
                    .map(relationship -> (GdmSingularGdmRelationship) relationship)
                    .filter(r -> r.getForeignKeyOwningSide().equalsIgnoreCase(fkOwningSide))
                    .collect(Collectors.toList());
        }, new ArrayList<>());
    }
}
