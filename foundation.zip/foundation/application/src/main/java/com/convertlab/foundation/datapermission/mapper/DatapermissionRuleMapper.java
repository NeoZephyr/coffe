package com.convertlab.foundation.datapermission.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.foundation.datapermission.entity.DpDatapermissionRule;
import org.springframework.stereotype.Component;

@Component
public interface DatapermissionRuleMapper extends BaseMapper<DpDatapermissionRule> {
}
