package com.convertlab.foundation.datapermission.service;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.convertlab.foundation.datapermission.entity.BaseResourceAccessEntity;
import com.convertlab.foundation.datapermission.entity.BaseResourceAccessEntityInternal;
import com.convertlab.foundation.library.datapermission.ResourceAccessDto;
import com.convertlab.foundation.library.bigtable.core.TenantIsolationBigtableTemplate;
import com.convertlab.foundation.library.datapermission.GrantedSubjectType;
import com.convertlab.foundation.library.jdbc.core.OLAPJdbcTemplate;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@Slf4j
public class ResourceAccessOLAPService implements BaseResourceAccessService{

    final TenantIsolationBigtableTemplate bigtableTemplate;
    final OLAPJdbcTemplate olapJdbcTemplate;

    public ResourceAccessOLAPService(TenantIsolationBigtableTemplate bigtableTemplate, OLAPJdbcTemplate olapJdbcTemplate) {
        this.bigtableTemplate = bigtableTemplate;
        this.olapJdbcTemplate = olapJdbcTemplate;
    }

    @Nullable
    @Override
    public BaseResourceAccessEntity save(@Nonnull String tableName, @Nonnull ResourceAccessDto dto) {
        Map data = dto.toMap();
        bigtableTemplate.asyncUpsert(tableName, data);

        BaseResourceAccessEntity entity = new BaseResourceAccessEntity();
        entity.setUuid((String) data.get("uuid"));
        return entity;
    }

    @Override
    public void batchSave(String tableName, List<ResourceAccessDto> dtos) {
        List<Map<String, Object>> dataList = getBatchDataList(dtos);
        bigtableTemplate.asyncBatchUpsert(tableName, dataList);
    }

    @NotNull
    private static List<Map<String, Object>> getBatchDataList(List<ResourceAccessDto> dtos) {
        List<Map<String, Object>> dataList = new ArrayList<>();
        dtos.forEach(dto -> {
            Map<String, Object> map = dto.toMap();
            dataList.add(map);
        });
        return dataList;
    }

    @Override
    public void update(@Nonnull String tableName, String uuid, @Nonnull ResourceAccessDto dto) {
        Map data = dto.toMap();
        bigtableTemplate.asyncUpsert(tableName, data);    }

    @Override
    public void batchUpdate(String tableName, List<ResourceAccessDto> dtos) {
        List<Map<String, Object>> dataList = getBatchDataList(dtos);
        bigtableTemplate.asyncBatchUpsert(tableName, dataList);
    }

    @Override
    public void upsert(String tableName, ResourceAccessDto dto) {
        Map data = dto.toMap();
        bigtableTemplate.asyncUpsert(tableName, data);
    }

    @Override
    public void batchUpsert(String tableName, List<ResourceAccessDto> dtos) {
        List<Map<String, Object>> dataList = getBatchDataList(dtos);
        bigtableTemplate.asyncBatchUpsert(tableName, dataList);
    }

    @Nullable
    @Override
    public BaseResourceAccessEntity getById(String tableName, String uuid) {
        List<BaseResourceAccessEntityInternal> entityList =  olapJdbcTemplate.query(String.format("select * from %s where uuid = ? ", tableName), new BeanPropertyRowMapper<>(BaseResourceAccessEntityInternal.class), new Object[]{uuid});
        if(entityList.size() > 0){
            return BaseResourceAccessEntity.fromInternalEntity(entityList.get(0));
        }
        return null;
    }

    @Override
    public void deleteById(String tableName, String uuid) {
        olapJdbcTemplate.update(String.format("delete from %s where uuid = ? ", tableName), new Object[]{uuid});
    }

    @Override
    public void batchDelete(@NotNull String tableName, List<BaseResourceAccessEntity> entities) {


        //delete from %s where uuid in
        List<String> uuidList = new ArrayList<>();
        entities.forEach(entity -> {
            //get by key according to entity data.
            BaseResourceAccessEntity loadByKey = this.getByKey(tableName, entity.getResourceType(), entity.getResourceCode(), entity.getGrantedSubjectType(), entity.getGrantedSubjectCode(), entity.getGrantedReason());
            if(loadByKey != null){
                uuidList.add(loadByKey.getUuid());
            }
        });


        if(uuidList.size() > 0){
            StringBuilder builder = new StringBuilder("delete from %s where uuid in (");
            for (int i = 0; i < uuidList.size(); i++) {
                builder.append("?,");
            }
            builder.deleteCharAt(builder.length() - 1);
            builder.append(")");

            olapJdbcTemplate.update(String.format(builder.toString(), tableName), uuidList.toArray());
        }
    }

    @Override
    public void delete(String tableName, String resourceType, String resourceCode) {
        olapJdbcTemplate.update(String.format("delete from %s where resource_type = ? and resource_code = ?", tableName), resourceType, resourceCode);
    }

    @Override
    public void delete(String tableName, String resourceType, String resourceCode, GrantedSubjectType grantedSubjectType, String grantedSubjectCode) {
        olapJdbcTemplate.update(String.format("delete from %s where resource_type = ? and resource_code = ? and granted_subject_type = ? and granted_subject_code = ?", tableName), resourceType, resourceCode, grantedSubjectType.getValue(), grantedSubjectCode);
    }

    @Override
    public void delete(String tableName, String resourceType, GrantedSubjectType grantedSubjectType, String grantedSubjectCode) {
        olapJdbcTemplate.update(String.format("delete from %s where resource_type = ? and granted_subject_type = ? and granted_subject_code = ?", tableName), resourceType, grantedSubjectType.getValue(), grantedSubjectCode);
    }

    @Override
    public void delete(String tableName, GrantedSubjectType grantedSubjectType, String grantedSubjectCode) {
        throw new UnsupportedOperationException("OLAP service doesn't support this operation");
    }

    @Nullable
    @Override
    public List<BaseResourceAccessEntity> list(String tableName, String resourceType, String resourceCode, GrantedSubjectType grantedSubjectType, String grantedSubjectCode) {
        List<BaseResourceAccessEntityInternal> entityList =
                olapJdbcTemplate.query(String.format("select * from %s where resource_type = ? and resource_code = ? and granted_subject_type = ? and granted_subject_code = ? ", tableName),
                        new BeanPropertyRowMapper<>(BaseResourceAccessEntityInternal.class), new Object[]{resourceType, resourceCode, grantedSubjectType.getValue(), grantedSubjectCode});

        return getBaseResourceAccessEntities(entityList);
    }

    @NotNull
    private static List<BaseResourceAccessEntity> getBaseResourceAccessEntities(List<BaseResourceAccessEntityInternal> entityList) {
        List<BaseResourceAccessEntity> resultsList = new ArrayList<>();
        entityList.forEach(entity -> {
            resultsList.add(BaseResourceAccessEntity.fromInternalEntity(entity));
        });
        return resultsList;
    }

    @Nullable
    @Override
    public List<BaseResourceAccessEntity> list(String tableName, String resourceType, String resourceCode) {
        List<BaseResourceAccessEntityInternal> entityList =
                olapJdbcTemplate.query(String.format("select * from %s where resource_type = ? and resource_code = ? ", tableName),
                        new BeanPropertyRowMapper<>(BaseResourceAccessEntityInternal.class), new Object[]{resourceType, resourceCode});

        return getBaseResourceAccessEntities(entityList);
    }

    @org.jetbrains.annotations.Nullable
    @Override
    public List<BaseResourceAccessEntity> list(String tableName, String resourceType, List<String> resourceCodeList) {

        List<BaseResourceAccessEntityInternal> entityList = new ArrayList<>();
        if(resourceCodeList.size() > 0){

            List<Object> parameters = new ArrayList<>();
            parameters.add(resourceType);
            StringBuilder builder = new StringBuilder("select * from %s where resource_type = ? and resource_code in (");
            for (int i = 0; i < resourceCodeList.size(); i++) {
                builder.append("?,");
                parameters.add(resourceCodeList.get(i));
            }
            builder.deleteCharAt(builder.length() - 1);
            builder.append(")");

            entityList = olapJdbcTemplate.query(String.format(builder.toString(), tableName),
                    new BeanPropertyRowMapper<>(BaseResourceAccessEntityInternal.class), parameters.toArray());
        }

        return getBaseResourceAccessEntities(entityList);
    }

    @org.jetbrains.annotations.Nullable
    @Override
    public List<BaseResourceAccessEntity> list(String tableName, String resourceType, Map<GrantedSubjectType, List<String>> grantedSubjectTypeListMap) {

        if(grantedSubjectTypeListMap.isEmpty()){
            return Collections.emptyList();
        }

        StringJoiner sj = new StringJoiner(" or ", "select * from " + tableName + " where resource_type = ? and (", ")");
        List<Object> parameters = new ArrayList<>();
        parameters.add(resourceType);

        for (Map.Entry<GrantedSubjectType, List<String>> entry : grantedSubjectTypeListMap.entrySet()) {

            StringJoiner sjInner = new StringJoiner(",", " (granted_subject_type = ? and granted_subject_code in (", ")) ");
            parameters.add(entry.getKey().getValue());

            for (int i = 0; i < entry.getValue().size(); i++) {
                sjInner.add("?");
                parameters.add(entry.getValue().get(i));
            }

            sj.add(sjInner.toString());
        }


        List<BaseResourceAccessEntityInternal> entityList = olapJdbcTemplate.query(sj.toString(),
                new BeanPropertyRowMapper<>(BaseResourceAccessEntityInternal.class), parameters.toArray());

        return getBaseResourceAccessEntities(entityList);
    }

    @Nullable
    @Override
    public List<BaseResourceAccessEntity> list(String tableName, String resourceType, GrantedSubjectType grantedSubjectType, List<String> grantedSubjectCodeList) {

        if(grantedSubjectCodeList.isEmpty()){
            return Collections.emptyList();
        }

        StringJoiner sj = new StringJoiner(",", "select * from " + tableName + " where resource_type = ? and granted_subject_type = ? and granted_subject_code in (", ")");
        for (int i = 0; i < grantedSubjectCodeList.size(); i++) {
            sj.add("?");
        }

        List<Object> parameters = new ArrayList<>();
        parameters.add(resourceType);
        parameters.add(grantedSubjectType.getValue());
        for (int i = 0; i < grantedSubjectCodeList.size(); i++) {
            parameters.add(grantedSubjectCodeList.get(i));
        }
        List<BaseResourceAccessEntityInternal> entityList = olapJdbcTemplate.query(String.format(sj.toString(), tableName),
                new BeanPropertyRowMapper<>(BaseResourceAccessEntityInternal.class), parameters.toArray());

        return getBaseResourceAccessEntities(entityList);
    }

    @Override
    public BaseResourceAccessEntity getByKey(String tableName, String resourceType, String resourceCode, GrantedSubjectType grantedSubjectType, String grantedSubjectCode, String grantedReason) {
        List<BaseResourceAccessEntityInternal> entityList =  olapJdbcTemplate.query(String.format("select * from %s where resource_type = ? and resource_code = ? and granted_subject_type = ? and granted_subject_code = ? and granted_reason = ?", tableName), new BeanPropertyRowMapper<>(BaseResourceAccessEntityInternal.class), new Object[]{resourceType, resourceCode, grantedSubjectType.getValue(), grantedSubjectCode, grantedReason});
        if(entityList.size() > 0){
            return BaseResourceAccessEntity.fromInternalEntity(entityList.get(0));
        }
        return null;
    }
}
