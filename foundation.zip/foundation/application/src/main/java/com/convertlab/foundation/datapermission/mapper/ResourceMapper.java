package com.convertlab.foundation.datapermission.mapper;

import com.convertlab.foundation.datapermission.entity.BaseResourceAccessEntity;
import com.convertlab.foundation.datapermission.util.GrantedPermissionTypeHandler;
import com.convertlab.foundation.datapermission.util.GrantedSubjectTypeHandler;
import com.convertlab.foundation.library.datapermission.GrantedSubjectType;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

public interface ResourceMapper {

    @Select("/*+DATA_VISIBILITY_IGNORE_TABLES(${tableName})*/SELECT ${idColumn}, ${deptAttr}, dept_code, owner_id FROM ${tableName} WHERE ${idColumn} = #{idValue} ")
    Map<String, Object> getEntity(@Param("tableName") String tableName, @Param("idColumn") String idColumn, @Param("deptAttr") String deptAttr, @Param("idValue") String idValue);

}