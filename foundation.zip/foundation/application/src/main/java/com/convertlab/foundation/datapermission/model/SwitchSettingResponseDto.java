package com.convertlab.foundation.datapermission.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SwitchSettingResponseDto {
    private String switchKey;
    private Boolean switchValue;
}
