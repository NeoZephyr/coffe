package com.convertlab.foundation.datapermission.model;

import lombok.Data;

@Data
public class ResourceSettingDto {

    public final static String permission_public = "public";
    public final static String permission_public_readonly = "public-readonly";
    public final static String permission_private = "private";

    private String resourceType;
    private String permission;

}
