package com.convertlab.foundation.misc.service.dao;

import javax.annotation.Nullable;

import com.convertlab.foundation.api.gdmdata.GenericGdmModel;
import com.convertlab.foundation.gdmdata.service.GenericGdmModelService;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.jdbc.core.OLTPJdbcTemplate;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
@Slf4j
public class HomeDao {
    private final JdbcTemplate jdbcTemplate;
    private final OLTPJdbcTemplate oltpJdbcTemplate;
    private final GenericGdmModelService genericGdmModelService;
    public HomeDao(@Qualifier("homeJdbcTemplate") JdbcTemplate jdbcTemplate, OLTPJdbcTemplate oltpJdbcTemplate,
                   GenericGdmModelService genericGdmModelService) {
        this.jdbcTemplate = jdbcTemplate;
        this.oltpJdbcTemplate = oltpJdbcTemplate;
        this.genericGdmModelService = genericGdmModelService;
    }
//    @Resource

    @Nullable
    public String getDate() {
        return jdbcTemplate.queryForObject("select now()", String.class);
    }

    @Nullable
    public String getCurrentDB() {
        return jdbcTemplate.queryForObject("select database()", String.class);
    }

    @Transactional
    @DataSourceLookup("main")
    public void insertDashboards(GdmEntity entity, long startId, long endId) {
        for (long i = startId; i < endId; i++) {
            List<GenericGdmModel> queryResult = genericGdmModelService.selectByParams(entity, ImmutableList.of("id"),
                    ImmutableMap.of("id",
                            String.valueOf(i)), 0, 1);
            if (!queryResult.isEmpty()) {
                log.warn("id {} already exists, delete it first", i);
                genericGdmModelService.deleteById(entity, i);
            }
            Map<String, Object> dataMap = ImmutableMap.of("id", i, "name",
                    "就让我胡言乱语:"+ RandomStringUtils.randomAlphabetic(10));
            GenericGdmModel testData = GenericGdmModel.buildFromMap(dataMap, Objects.requireNonNull(entity),
                    GenericGdmModel.class);
            genericGdmModelService.insert(testData);
            log.debug("inserted id {}", i);
        }
    }

    @Transactional
    @DataSourceLookup("main")
    public void removeDashboards(GdmEntity entity, long startId, long endId) {
        for (long i = startId; i < endId; i++) {
            List<GenericGdmModel> queryResult = genericGdmModelService.selectByParams(entity, ImmutableList.of("id"),
                    ImmutableMap.of("id",
                            String.valueOf(i)), 0, 1);
            if (queryResult.isEmpty()) {
                log.warn("id {} not exists, skip", i);
                continue;
            }
            genericGdmModelService.deleteById(entity, i);
            log.debug("deleted id {}", i);
        }
    }

    @Transactional
    @DataSourceLookup("main")
    public void insertDashboardsByOltpJdbcTemplate(long startId, long endId) {
        for (long i = startId; i < endId; i++) {
            List<Map<String, Object>> queryResult = oltpJdbcTemplate.queryForList("select 1 from dashboard where id = ?",
                    i);
            if (!queryResult.isEmpty()) {
                log.warn("id {} already exists, delete it first", i);
                oltpJdbcTemplate.update("delete from dashboard where id = ?", i);
            }
            oltpJdbcTemplate.update("insert into dashboard(id, name, version, date_created, last_updated) values (?, ?, " +
                            "?,?,?)", i,
                    "就让我胡言乱语:"+ RandomStringUtils.randomAlphabetic(10),1, Instant.now(), Instant.now());
            log.debug("inserted id {}", i);
        }
    }

    @Transactional
    @DataSourceLookup("main")
    public void removeDashboardsByOltpJdbcTemplate(long startId, long endId) {
        for (long i = startId; i < endId; i++) {
            List<Map<String, Object>> queryResult = oltpJdbcTemplate.queryForList("select 1 from dashboard where id = ?",
                    i);
            if (queryResult.isEmpty()) {
                log.warn("id {} not exists, skip", i);
                continue;
            }
            oltpJdbcTemplate.update("delete from dashboard where id = ?", i);
            log.debug("deleted id {}", i);
        }
    }

    @Transactional
    public void insertDashboardsByJdbcTemplate(long startId, long endId) {
        for (long i = startId; i < endId; i++) {
            List<Map<String, Object>> queryResult = jdbcTemplate.queryForList("select 1 from dashboard where id = ?",
                    i);
            if (!queryResult.isEmpty()) {
                log.warn("id {} already exists, delete it first", i);
                jdbcTemplate.update("delete from dashboard where id = ?", i);
            }
            jdbcTemplate.update("insert into dashboard(id, tenant_id,name, version, date_created, last_updated) " +
                            "values (?, ?, ?," +
                            "?,?,?)", i, TenantContextHolder.getTenantIdExt(),
                    "就让我胡言乱语:"+ RandomStringUtils.randomAlphabetic(10),1, Instant.now(), Instant.now());
            log.debug("inserted id {}", i);
        }
    }

    @Transactional
    public void removeDashboardsByJdbcTemplate(long startId, long endId) {
        for (long i = startId; i < endId; i++) {
            List<Map<String, Object>> queryResult = jdbcTemplate.queryForList("select 1 from dashboard where id = ?",
                    i);
            if (queryResult.isEmpty()) {
                log.warn("id {} not exists, skip", i);
                continue;
            }
            jdbcTemplate.update("delete from dashboard where id = ?", i);
            log.debug("deleted id {}", i);
        }
    }

    public enum BenchmarkMode {
        GENERIC_GDM_MODEL,
        OLTP_JDBC_TEMPLATE,
        JDBC_TEMPLATE
    }
}
