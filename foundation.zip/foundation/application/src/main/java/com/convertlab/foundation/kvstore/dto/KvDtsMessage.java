package com.convertlab.foundation.kvstore.dto;

import lombok.Data;
import lombok.ToString;

import java.util.List;

@Data
@ToString
public class KvDtsMessage {
    @Data
    public static class DtsMeta{
        private String name;
    }

    public DtsMeta _meta;
    public List<KeyValuesPair> _data;
}
