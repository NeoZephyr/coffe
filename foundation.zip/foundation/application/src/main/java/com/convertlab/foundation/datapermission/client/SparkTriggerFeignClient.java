package com.convertlab.foundation.datapermission.client;

import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(
        name = "SparkTriggerFeignClient",
        url = "${eventJobServer.serverUrl}",
        decode404 = true
)
public interface SparkTriggerFeignClient extends SparkTriggerApi {
}
