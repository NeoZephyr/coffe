package com.convertlab.foundation.datapermission.model;

import lombok.Data;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.List;

@Data
public class ResourceBatchShareResponseDto {

        private String resourceType;

        @Nonnull
        private List<String> resourceCodes = new ArrayList<>();

}
