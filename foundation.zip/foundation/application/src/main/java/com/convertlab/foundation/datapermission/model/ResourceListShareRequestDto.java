package com.convertlab.foundation.datapermission.model;

import lombok.Data;

@Data
public class ResourceListShareRequestDto {

        private String resourceType;

        private String resourceCode;


}
