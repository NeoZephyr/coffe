package com.convertlab.foundation.misc.dto;

import lombok.Data;

@Data
public class CastAndCopyColumnRequest {
    private String entityName;
    private String objId;
    private String tableName;
    private String pkColumnName = "id";
    private String extraConditions;
    private String fromColumn;
    private String toColumn;
    private CastFunction castFunction = CastFunction.CharToBigInt;
    private int batchSize = 1000;
    private int batchInterval = 10; //in millis


    public enum CastFunction {
        CharToBigInt, BigIntToChar
    }
}
