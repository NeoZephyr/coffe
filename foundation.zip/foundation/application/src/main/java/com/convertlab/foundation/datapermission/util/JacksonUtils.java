package com.convertlab.foundation.datapermission.util;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

public final class JacksonUtils {

    private static final ObjectMapper mapper = new ObjectMapper();

    static {
        mapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        JavaTimeModule javaTimeModule = new JavaTimeModule();
        mapper.registerModule(javaTimeModule);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.findAndRegisterModules();
    }

    public static String toJSONString(Object value) {
        if (value == null) {
            return null;
        } else {
            try {
                return mapper.writeValueAsString(value);
            } catch (JsonProcessingException var2) {
                throw new RuntimeException(var2);
            }
        }
    }

    public static byte[] toJSONBytes(Object value) {
        if (value == null) {
            return null;
        } else {
            try {
                return mapper.writeValueAsBytes(value);
            } catch (JsonProcessingException var2) {
                throw new RuntimeException(var2);
            }
        }
    }

    public static <T> List<T> parseArray(String content, Class<T> clazz) {
        if (!StringUtils.hasLength(content)) {
            return Collections.emptyList();
        } else {
            try {
                return mapper.readValue(content, mapper.getTypeFactory().constructCollectionType(List.class, clazz));
            } catch (IOException var3) {
                throw new RuntimeException(var3);
            }
        }
    }

    public static <T> T parseObject(String json, Class<T> clazz) {
        if (json == null) {
            return null;
        } else {
            try {
                return mapper.readValue(json, clazz);
            } catch (IOException var3) {
                throw new RuntimeException(var3);
            }
        }
    }

    public static <T> T parseObject(InputStream inputStream, Class<T> clazz) {
        if (inputStream == null) {
            return null;
        } else {
            try {
                return mapper.readValue(inputStream, clazz);
            } catch (IOException var3) {
                throw new RuntimeException(var3);
            }
        }
    }

    public static <T> T parseObject(InputStream inputStream, TypeReference<T> typeInfo) {
        if (inputStream == null) {
            return null;
        } else {
            try {
                return mapper.readValue(inputStream, typeInfo);
            } catch (IOException var3) {
                throw new RuntimeException(var3);
            }
        }
    }

    public static <T> T parseObject(String json, TypeReference<T> typeInfo) {
        if (json == null) {
            return null;
        } else {
            try {
                return mapper.readValue(json, typeInfo);
            } catch (IOException var3) {
                throw new RuntimeException(var3);
            }
        }
    }
}