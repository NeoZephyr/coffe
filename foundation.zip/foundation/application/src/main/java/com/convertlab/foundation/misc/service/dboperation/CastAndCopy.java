package com.convertlab.foundation.misc.service.dboperation;

import com.convertlab.foundation.library.sqlprocessor.SQLDialect;
import com.convertlab.foundation.misc.dto.CastAndCopyColumnRequest;

import java.sql.Connection;

public class CastAndCopy extends AbstractDbOperation{
    public CastAndCopy(CastAndCopyColumnRequest args, Connection connection, SQLDialect sqlDialect) {
        super(args, connection, sqlDialect);
    }

    @Override
    protected String buildSql() {
        String sql = "update `" + args.getTableName() + "` set `" + args.getToColumn() + "` = " + castFunctionToSql(args.getCastFunction(), args.getFromColumn(), sqlDialect);
        sql += buildWhere(args);
        return sql;
    }
}
