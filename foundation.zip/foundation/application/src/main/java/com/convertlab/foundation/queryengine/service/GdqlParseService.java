package com.convertlab.foundation.queryengine.service;

import com.convertlab.common.crypto.client.CryptoClient;
import com.convertlab.foundation.api.queryengine.FilterV4Dto;
import com.convertlab.foundation.api.queryengine.SqlBuilder;
import com.convertlab.foundation.library.business.feature.FeatureClient;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BackendException;
import com.convertlab.foundation.library.filter.FilterJsonParser;
import com.convertlab.foundation.library.filter.GdmParseResult;
import com.convertlab.foundation.library.filter.v4.timeline.GdmFilterV4WithTimeline;
import com.convertlab.foundation.library.gdmmeta.client.GdmStorageMetaRtClient;
import com.convertlab.foundation.library.sqlprocessor.SQLDialect;
import com.convertlab.foundation.library.sqlprocessor.chain.ProcessorChain;
import com.convertlab.foundation.library.sqlprocessor.context.ProcessorContext;
import com.convertlab.foundation.library.sqlprocessor.processor.SQLProcessor;
import com.convertlab.foundation.library.sqlprocessor.processor.visibility.client.ACLInformationClient;
import com.convertlab.foundation.library.sqlprocessor.processor.visibility.client.ResourceInformationClient;
import com.convertlab.foundation.library.sqlprocessor.processor.visibility.client.UserInformationClient;
import com.convertlab.foundation.library.sqlprocessor.support.SQLProcessUtils;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.google.common.collect.ImmutableSet;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Service;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Map;

@Service
@Slf4j
public class GdqlParseService {
    private final FilterJsonParser<GdmFilterV4WithTimeline> filterJsonParser;
    private final FeatureClient featureClient;
    private final GdmStorageMetaRtClient storageMetaClient;
    private final UserInformationClient userInformationClient;
    private final ResourceInformationClient resourceInformationClient;
    private final ACLInformationClient aclInformationClient;
    private final JsonUtils jsonUtils;

    @Autowired
    protected CryptoClient cryptoClient;

    public GdqlParseService(@Qualifier("FilterJsonParser") final FilterJsonParser<GdmFilterV4WithTimeline> filterJsonParser,
                            final GdmStorageMetaRtClient storageMetaClient,
                            @Autowired(required = false) UserInformationClient userInformationClient,
                            @Autowired(required = false) ResourceInformationClient resourceInformationClient,
                            @Autowired(required = false) ACLInformationClient aclInformationClient,
                            @Autowired(required = false) FeatureClient featureClient,
                            final JsonUtils jsonUtils,
                            @Autowired(required = false) final ConversionService conversionService) {
        this.filterJsonParser = filterJsonParser;
        this.storageMetaClient = storageMetaClient;
        this.userInformationClient = userInformationClient;
        this.resourceInformationClient = resourceInformationClient;
        this.aclInformationClient = aclInformationClient;
        this.featureClient = featureClient;
        this.jsonUtils = jsonUtils;
    }

    @Nonnull
    public SqlBuilder.Response buildSql(@Nonnull SqlBuilder.Request request, @Nonnull SQLProcessor processor, boolean aclOnly) {
        ProcessorContext processorContext = SQLProcessUtils.initProcessorContext();
        if (request.getImpersonate() != null) {
            SqlBuilder.Impersonate impersonate = request.getImpersonate();
            processorContext.setUserId(impersonate.getUserId());
            processorContext.setDeptCode(impersonate.getDeptCode());
        }

        processorContext.setAclOnly(aclOnly);

        //Gdql to Native SQL
        if (StringUtils.isNotBlank(request.getGdql())) {
            String nativeSql = processor.processSql(request.getGdql(), processorContext);
            return new SqlBuilder.Response(null, sqlTrim(nativeSql));
        }

        FilterV4Dto filter = request.getFilter();
        if (filter == null) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "filter json参数必须提供");
        }
        GdmFilterV4WithTimeline filterV4 = jsonUtils.convert(filter, GdmFilterV4WithTimeline.class);
        GdmParseResult query = filterJsonParser.toGdql(filterV4);
        if (query == null) {
            throw new BackendException(CommonErrors.GENERAL_ERROR, "parse filter json failed");
        }
        String gdql = query.getGdql();
        //Filter Json to Gdql
        switch (request.getOutputFormat()) {
            case GDQL:
                return new SqlBuilder.Response(sqlTrim(gdql), null);
            case SQL:
                String nativeSql = processor.processSql(gdql, processorContext);
                log.info("Transformed from GDQL to Native SQL.\nGDQL:\n{}\nNative SQL:\n{}", gdql, nativeSql);

                return new SqlBuilder.Response(null, sqlTrim(nativeSql));
            default:
                throw new BackendException(CommonErrors.VALIDATION_ERROR, "Unknown output format " + request.getOutputFormat());
        }
    }

    public SqlBuilder.Response buildSql(Map<String, Object> filter, @Nonnull SQLProcessor processor) {
        GdmFilterV4WithTimeline filterV4 = jsonUtils.convert(filter, GdmFilterV4WithTimeline.class);
        GdmParseResult query = filterJsonParser.toGdql(filterV4);
        if (query == null) {
            throw new BackendException(CommonErrors.GENERAL_ERROR, "parse filter json failed");
        }
        String gdql = query.getGdql();
        String nativeSql = processor.processSql(gdql);
        return new SqlBuilder.Response(null, sqlTrim(nativeSql));
    }

    @Nullable
    private String sqlTrim(@Nonnull String sql) {
        if (StringUtils.isBlank(sql)) {
            return sql;
        }
        return sql.replaceAll("\\s+", " ");
    }

    private static final ImmutableSet<String> weirdTables = ImmutableSet.<String>builder()
            .add("media_image")
            .add("media_video")
            .build();

    @Nonnull
    public SQLProcessor aclOnlyProcessor(SQLDialect dialect) {
        return ProcessorChain.builder()
                .targetDialect(dialect)
                .storageMetaClient(storageMetaClient)
                .processingMode(dialect.getProcessingMode())
//                .gdmTransformation()
                .dataVisibility(configurer -> configurer
                        .userInformationClient(userInformationClient)
                        .resourceInformationClient(resourceInformationClient)
                        .aclInformationClient(aclInformationClient))
                .multiTenancy(configurer -> configurer.ignoreTable(weirdTables::contains))
                .build();
    }

    @Nonnull
    public SQLProcessor sqlProcessor(SQLDialect dialect) {
        return ProcessorChain.builder()
                .targetDialect(dialect)
                .processingMode(dialect.getProcessingMode())
                .storageMetaClient(storageMetaClient)
                .featureClient(featureClient)
                .asteriskConversion()
                .gdmTransformation()
                .crypto(configurer -> configurer.cryptoClient(this.cryptoClient))
                .dataVisibility(configurer -> configurer
                        .userInformationClient(userInformationClient)
                        .resourceInformationClient(resourceInformationClient)
                        .aclInformationClient(aclInformationClient))
                .multiTenancy()
                .indexUsingCheck()
                .joinColdData()
                .build();
    }
}
