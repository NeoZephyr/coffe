package com.convertlab.foundation.datapermission.model;

import com.convertlab.foundation.library.datapermission.model.HighSeasSetting;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class HighSeaSettingRequestDto {

    public static final String PUBLIC_TYPE = "ALL";
    public static final String PRIVATE_TYPE = "PRIVATE";

    private String type = PRIVATE_TYPE;
    private List<String> deptCodes = new ArrayList<>();

    public List<HighSeasSetting> buildHighSeasSettings(){
        ArrayList<HighSeasSetting> settings = new ArrayList<>();
        if(PUBLIC_TYPE.equals(type)){
            HighSeasSetting setting = new HighSeasSetting();
            setting.setGrantedSubjectCode(PUBLIC_TYPE);
            setting.setGrantedSubjectType(HighSeasSetting.DEPT_ACCESS_SCOPE);
            settings.add(setting);
        }else if(PRIVATE_TYPE.equals(type)){
            deptCodes.forEach(deptCode -> {
                HighSeasSetting setting = new HighSeasSetting();
                setting.setGrantedSubjectCode(deptCode);
                setting.setGrantedSubjectType(HighSeasSetting.DEPT_ACCESS_SCOPE);
                settings.add(setting);
            });
        }
        return settings;
    }

}
