package com.convertlab.foundation.gdmmeta.controller;

import com.convertlab.foundation.gdmmeta.persistance.relationship.GdmRelationshipModel;
import com.convertlab.foundation.gdmmeta.service.GdmRelationshipMetaService;
import com.convertlab.foundation.gdmmeta.service.validator.GdmRelationshipValidator;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.gdmmeta.api.GdmRelationshipApiRoot;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationship;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationshipRequest;
import com.convertlab.foundation.library.gdmmeta.validation.Issue;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.principal.context.PrincipalContextHolder;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Nullable;
import java.util.List;
import java.util.stream.Collectors;

import static com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationshipRequest.RELATIONSHIP_IS_EXISTED;


@RestController("gdmRelationshipMetaController")
@RequestMapping("/v1/meta/gdm")
@Tag(name = "Meta Store接口")
@Slf4j
public class GdmRelationshipMetaController implements GdmRelationshipApiRoot {

    GdmRelationshipMetaService gdmRelationshipMetaService;
    private final GdmRelationshipValidator gdmRelationshipValidator;

    public GdmRelationshipMetaController(GdmRelationshipMetaService gdmRelationshipMetaService, GdmRelationshipValidator gdmRelationshipValidator) {
        this.gdmRelationshipMetaService = gdmRelationshipMetaService;
        this.gdmRelationshipValidator = gdmRelationshipValidator;
    }

    @Operation(summary = "列出Entity的所有Relationship", description = "列出Entity的所有Relationship")
    @Override
    public List<GdmRelationship> getRelationships(String entityName, @Nullable String relationshipName) {
        List<GdmRelationshipModel> relationships = gdmRelationshipMetaService.getRelationships(entityName, relationshipName);
        return relationships.stream().map(model -> model.relationshipBasedOnInputEntityName(entityName)).collect(Collectors.toList());
    }

    @Operation(summary = "列出entityName被指向的、单向Relationship", description = "列出entityName被指向的单向Relationship，和其他relationship API不同的是，这些关系中，entityName都是rightEntityName而不是leftEntityName，reverseName为null；这个API是其他查询Relationship的API的补充。")
    @Override
    public List<GdmRelationship> getBackUnidirectionalRelationships(String entityName) {
        List<GdmRelationshipModel> relationships = gdmRelationshipMetaService.getBackUnidirectionalRelationships(entityName);
        return relationships.stream().map(model -> model.relationshipBasedOnInputEntityName(entityName)).collect(Collectors.toList());
    }

    @Operation(summary = "创建Relationship", description = "创建Relationship")
    @Override
    public GdmRelationship createRelationship(GdmRelationshipRequest gdmRelationshipRequest) {

        gdmRelationshipMetaService.checkRequestData(gdmRelationshipRequest);
        GdmRelationshipModel gdmRelationshipModel = GdmRelationshipModel.newInstance(gdmRelationshipRequest);
        GdmRelationshipModel relationship;
        try {
            relationship = gdmRelationshipMetaService.createRelationship(gdmRelationshipModel);
        } catch (org.springframework.dao.DuplicateKeyException e) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, RELATIONSHIP_IS_EXISTED);
        }
        return relationship.relationshipBasedOnInputEntityName(gdmRelationshipRequest.getLeftEntityName());
    }

    @Operation(summary = "删除Relationship", description = "删除Relationship")
    @Override
    public GdmRelationship deleteRelationship(String entityName, String relationshipName) {
        GdmRelationshipModel gdmRelationshipModel = gdmRelationshipMetaService.deleteRelationship(entityName, relationshipName);
        GdmRelationship relationship = gdmRelationshipModel.relationshipBasedOnInputEntityName(entityName);
        return relationship;
    }

    @PostMapping("/relationships/_health-check")
    @Operation(summary = "校验 Relationship meta信息完整性", description = "校验 Relationship meta信息完整性")
    @Tag(name = "health-check-endpoint")
    public List<Issue> checkGdmRelationship() {
        log.info("checkGdmRelationship - tenantId: {}, userId: {}", TenantContextHolder.getTenantId(), PrincipalContextHolder.getUserId());
        return gdmRelationshipValidator.validate();
    }
}
