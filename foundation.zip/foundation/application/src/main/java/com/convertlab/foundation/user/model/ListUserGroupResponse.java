package com.convertlab.foundation.user.model;


import javax.annotation.Nonnull;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.convertlab.foundation.user.entity.UserGroup;
import lombok.Value;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import java.util.List;

@Value
public class ListUserGroupResponse {
    @Nonnull
    List<UserGroup> data;
    @Nonnull
    Long count;

    @Contract("_ -> new")
    public static @NotNull ListUserGroupResponse fromPage(@NotNull Page<UserGroup> page) {
        return new ListUserGroupResponse(page.getRecords(), page.getTotal());
    }
}
