package com.convertlab.foundation.gdmmeta.service;

import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.NotImplementedException;
import org.jetbrains.annotations.Nullable;

import com.convertlab.foundation.gdmmeta.model.Entity;

/**
 *   GdmEntity Meta的生成需要多个步骤的处理，整合多样的外部数据源：<br/>
 *   数据库结构、DM Hub的meta、额外补充的信息等。<br/>
 *   尤其对于 customer, customerEvent 这些 Entity，需要单独的处理逻辑。<br/>
 *
 *   把每一部分外部数据源和对应 Entity Meta 的生成逻辑，抽取到独立的层次类中，<br/>
 *   然后在外部策略整合逻辑，把所有的层次生成的 Entity Layer Meta 一层层叠加整合起来，<br/>
 *   生成最终的 Entity Meta. 通过「层次」+「策略」的形式，把处理逻辑分拆到独立的类层次中 <br/>
 *   方便维护和扩展。 <br/>
 *
 *   <code>GdmEntityLoader</code> 是每一层的处理逻辑封装，<br/>
 *   通常会包含一个外部数据源，返回通过解析这个数据源可以拿到的 EntityMeta 定义。 <br/>
 *
 *   需要注意的是，每一层的处理逻辑要尽量独立和简单，可以只是一个 Entity 的一层 Meta 的处理。<br/>
 *   方便维护和测试。<br/>
 *
 *   Entity Meta 的处理层次之间大部分可能是有依赖关系的，这个虽然最终由外部策略整合逻辑保证，
 *   为了方便调测，可以考虑使用 <code>Assert</code>，验证契约。<br/>
 *
 * Notes: 考虑为 GdmEntityLoader 的实现类添加：
 * 1. Group
 * 2. order or dependency(维护层次的顺序和依赖）
 *
 */
public interface GdmEntityLoader {

    /**
     * @return 返回当前层次(layer)定义的所有entityName的集合。
     *
     */
    Set<String> getEntityNames();

    /**
     * 返回当前层次(layer)定义的 GdmEntity.<br/>
     * 如果<code>entityName</code>对应 Entity的Meta没有定义，返回 null.
     * @param entityName
     * @return
     */
    @javax.annotation.Nullable
    @Nullable Entity loadEntity(String entityName);

    default Map<String, Entity> getEntities(){
        throw new NotImplementedException("");
    };
}
