package com.convertlab.foundation.user.utils;

public class DeptFileHeader {

    // 编码
    public static final String CODE_TEXT = "\u7f16\u7801";

    // 名称
    public static final String NAME_TEXT = "\u540d\u79f0";

    // 上级编码
    public static final String PARENT_CODE_TEXT = "\u4e0a\u7ea7\u7f16\u7801";

    // 内部编码
    public static final String INNER_CODE_TEXT = "\u5185\u90e8\u7f16\u7801";

    // 上级内部编码
    public static final String PARENT_INNER_CODE_TEXT = "\u4e0a\u7ea7\u5185\u90e8\u7f16\u7801";
}