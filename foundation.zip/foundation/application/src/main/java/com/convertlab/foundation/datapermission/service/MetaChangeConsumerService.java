package com.convertlab.foundation.datapermission.service;

import com.convertlab.foundation.library.datapermission.model.DeptAttrSetting;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.constants.MetaEvent;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

import javax.annotation.Nonnull;

import static com.convertlab.foundation.library.gdmmeta.model.general.BaseMetaSchema.MetaType.GDM_ENTITIES;


@Service
@Slf4j
@DataSourceLookup("main")
public class MetaChangeConsumerService {

    private final GsMetaClient gsMetaClient;

    private final SettingService settingService;
    public MetaChangeConsumerService(GsMetaClient gsMetaClient, SettingService settingService){
        this.gsMetaClient = gsMetaClient;
        this.settingService = settingService;
    }

    @EventListener
    // 顺序越小越先执行
    @Order(1)
    public void receiveAll(@Nonnull MetaEvent event) {

        //监听GDM Entity Updated事件.
        if(MetaEvent.MetaEventType.GDM_ENTITY_UPDATED.getValue().equals(event.getType())){
            //如果metaType等于GDM_ENTITIES
            if(GDM_ENTITIES.equals(event.getDto().getMetaType())){
                String objectName = event.getDto().getObjectName();

                //如果无法找到entity meta, log error
                GdmEntity entity = gsMetaClient.getEntity(objectName);
                if(entity == null){
                    //记录错误日志
                    log.error("[ D&P ] entity is not found " + objectName);
                    return;
                }

                //TODO,此处做一个假设，针对于涉及到outer dept的档案，entity name等于resource name。
                DeptAttrSetting deptAttrSetting = settingService.getDeptAttr(objectName);
                if(deptAttrSetting == null){
                    log.info("[ D&P ] dept attr setting is not found " + objectName);
                    return;
                }

                //检查deptAttrSetting是否在meta中存在
                String column = deptAttrSetting.getColumn();
                if(StringUtils.isEmpty(column)){
                    log.info("[ D&P ] dept attr setting column is empty " + objectName);
                    return;
                }

                GdmField field = entity.getFieldsMap().get(column);
                if(field == null){
                    //如果字段不存在，被删除或者更新了，则需要相应的删除data permission规则。
                    log.warn("[ D&P ] clean dept attr setting for object {} due to dept attr column is not exist in profile meta.", objectName);
                    settingService.cleanDeptAttr(objectName);
                }

            }

        }
    }

}
