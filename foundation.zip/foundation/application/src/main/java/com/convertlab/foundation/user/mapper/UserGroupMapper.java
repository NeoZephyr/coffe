package com.convertlab.foundation.user.mapper;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.foundation.user.entity.UserGroup;
import org.springframework.stereotype.Component;

import java.util.List;


@Component
public interface UserGroupMapper extends BaseMapper<UserGroup> {

    default UserGroup getUserGroupByCode(String code){
        QueryWrapper<UserGroup> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("code", code);
        return selectOne(queryWrapper);
    }

    default List<UserGroup> getUserGroupByCodeList(List codeList){
        QueryWrapper<UserGroup> queryWrapper = new QueryWrapper<>();
        queryWrapper.in("code", codeList);
        return selectList(queryWrapper);
    }

    default List<UserGroup> getUserGroupByIdList(List idList){
        QueryWrapper<UserGroup> queryWrapper = new QueryWrapper<>();
        queryWrapper.in("id", idList);
        return selectList(queryWrapper);
    }


}
