package com.convertlab.foundation.datapermission.model;

import lombok.Getter;

import javax.validation.constraints.NotBlank;

@Getter
public class SetDeptAttrRequest {
    @NotBlank String deptAttrColumn;
    @NotBlank String objectName;

    public SetDeptAttrRequest(String deptAttrColumn, String objectName) {
        this.deptAttrColumn = deptAttrColumn;
        this.objectName = objectName;
    }

    public void setDeptAttrColumn(String deptAttrColumn) {
        this.deptAttrColumn = deptAttrColumn;
    }

    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }
}
