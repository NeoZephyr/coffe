package com.convertlab.foundation.gdmmeta.model.metaobject;


import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.List;

import com.convertlab.foundation.gdmmeta.model.Field;
import com.convertlab.foundation.gdmmeta.utils.GdmNamingUtils;
import com.convertlab.foundation.library.gdmmeta.model.FieldType;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class SystemMembershipMetaObject {

    private List<Prop> props;


    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Prop {
        String name;
        PropType innerType;
    }

    /**
     * 会员使用 innerType 确定类型, 目前只有一个 balance 数据库类型 decimal，其他的数值类型都是 Integer。
     * 后续可能需要扩展，比如浮点类型。 可能继续使用 decimal，也可能使用 double。
     *
     * */
    public enum PropType {
        @JsonProperty("String")
        STRING(FieldType.String),
        @JsonProperty("Byte")
        BYTE(FieldType.Integer),
        //dirty legacy
        @JsonProperty("Integer")
        INTEGER(FieldType.Integer),
        @JsonProperty("Long")
        LONG(FieldType.Long),
        @JsonProperty("Decimal")
        DECIMAL(FieldType.Decimal),
        @JsonProperty("Date")
        DATE(FieldType.Date),
        @JsonProperty("DateTime")
        DATE_TIME(FieldType.DateTime);

        private FieldType fieldType;

        PropType(FieldType fieldType) {
            this.fieldType = fieldType;
        }

        public FieldType fieldType() {
            return this.fieldType;
        }

        }

    @Nonnull
    public List<Field> getFieldList() {
        List<Field> result = new ArrayList<>();
        for (Prop prop : props) {
            String fieldName = GdmNamingUtils.toUnderScoreCase(prop.getName());
            String columnName = fieldName;
            Field field = Field.builder()
                    .fieldName(fieldName)
                    .fieldType(prop.getInnerType().fieldType())
                    .dbColumnName(columnName)
                    .build();
            result.add(field);
        }
        return result;
    }

}
