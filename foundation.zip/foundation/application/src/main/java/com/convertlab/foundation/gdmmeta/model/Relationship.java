package com.convertlab.foundation.gdmmeta.model;

import javax.annotation.Nonnull;
import java.util.EnumMap;


import com.convertlab.foundation.gdmmeta.service.impl.loader.SystemMetaDefObject;
import com.convertlab.foundation.gdmmeta.utils.GdmNamingUtils;
import com.convertlab.foundation.library.gdmmeta.model.MetaProperty;
import com.convertlab.foundation.library.gdmmeta.model.relationship.*;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class Relationship extends MetaProperty {
    private String name;
    private GdmRelationship.Cardinality cardinality;
    private String reverseName;
    private String leftEntityName;
    private String rightEntityName;
    private String foreignKeyOwningSide;
    private String mappedBy;
    private Boolean isBidirectional;


    GdmRelationship.Cardinality reverseCardinality() {
        EnumMap<GdmRelationship.Cardinality, GdmRelationship.Cardinality> m = new EnumMap<>(GdmRelationship.Cardinality.class);
        m.put(GdmRelationship.Cardinality.MANY_TO_MANY, GdmRelationship.Cardinality.MANY_TO_MANY);
        m.put(GdmRelationship.Cardinality.ONE_TO_MANY, GdmRelationship.Cardinality.MANY_TO_ONE);
        m.put(GdmRelationship.Cardinality.MANY_TO_ONE, GdmRelationship.Cardinality.ONE_TO_MANY);
        m.put(GdmRelationship.Cardinality.ONE_TO_ONE, GdmRelationship.Cardinality.ONE_TO_ONE);
        return m.get(this.cardinality);
    }

    public Relationship(@Nonnull Relationship ora) {
        name = ora.name;
        cardinality = ora.cardinality;
        reverseName = ora.reverseName;
        leftEntityName = ora.leftEntityName;
        rightEntityName = ora.rightEntityName;
        foreignKeyOwningSide = ora.foreignKeyOwningSide;
        mappedBy = ora.mappedBy;
        isBidirectional = ora.isBidirectional;
        isSystem = ora.isSystem;
        modifiable = ora.modifiable;
        deletable = ora.deletable;
    }

    public Relationship(@Nonnull SystemMetaDefObject.GdmRelationshipDef ora) {
        name = ora.getName();
        cardinality = ora.getCardinality();
        reverseName = ora.getReverseName();
        leftEntityName = ora.getLeftEntityName();
        rightEntityName = ora.getRightEntityName();
        foreignKeyOwningSide = ora.getForeignKeyOwningSide();
        mappedBy = ora.getMappedBy();
        isBidirectional = ora.getIsBidirectional();
        isSystem = ora.getIsSystem();
        deletable = ora.getDeletable();
        modifiable = ora.getModifiable();
    }

    public Relationship(@Nonnull GdmSingularGdmRelationship ora) {
        name = ora.getName();
        cardinality = ora.getCardinality();
        reverseName = ora.getReverseName();
        leftEntityName = ora.getLeftEntityName();
        rightEntityName = ora.getRightEntityName();
        foreignKeyOwningSide = ora.getForeignKeyOwningSide();
        mappedBy = ora.getMappedBy();
        isBidirectional = ora.isBidirectional();
        isSystem = ora.getIsSystem();
        deletable = ora.getDeletable();
        modifiable = ora.getModifiable();
    }



    public Relationship reverseRelationship() {
        if (!this.isBidirectional) {
            throw new UnsupportedOperationException("only bidirectional relationship supported.");
        }

        Relationship ret = Relationship.builder().name(this.reverseName)
                .reverseName(this.name).cardinality(reverseCardinality())
                .isBidirectional(true)
                // foreignKeyOwningSide, mappedBy 一致
                .foreignKeyOwningSide(this.foreignKeyOwningSide).mappedBy(this.mappedBy)
                .leftEntityName(this.rightEntityName).rightEntityName(this.leftEntityName)
                .build();
        ret.isSystem = this.isSystem;
        ret.deletable = this.deletable;
        ret.modifiable = this.modifiable;
        return ret;
    }

    @Nonnull
    public GdmRelationship gdmRelationship() {
        GdmRelationship gdmRelationship ;
        if (this.getCardinality().equals(GdmRelationship.Cardinality.ONE_TO_ONE)) {
            gdmRelationship = ImmutableGdmOneToOneGdmRelationship.builder().name(name).reverseName(reverseName)
                    .leftEntityName(leftEntityName).rightEntityName(rightEntityName)
                    .foreignKeyOwningSide(foreignKeyOwningSide).mappedBy(mappedBy).isBidirectional(isBidirectional)
                    .isSystem(isSystem).deletable(deletable).modifiable(modifiable)
                    .build();
        } else if (this.getCardinality().equals(GdmRelationship.Cardinality.ONE_TO_MANY)) {
            gdmRelationship = ImmutableGdmOneToManyGdmRelationship.builder().name(name).reverseName(reverseName)
                    .leftEntityName(leftEntityName).rightEntityName(rightEntityName)
                    .foreignKeyOwningSide(foreignKeyOwningSide).mappedBy(mappedBy).isBidirectional(isBidirectional)
                    .isSystem(isSystem).deletable(deletable).modifiable(modifiable)
                    .build();
        } else if (this.getCardinality().equals(GdmRelationship.Cardinality.MANY_TO_ONE)) {
            gdmRelationship = ImmutableGdmManyToOneGdmRelationship.builder().name(name).reverseName(reverseName)
                    .leftEntityName(leftEntityName).rightEntityName(rightEntityName)
                    .foreignKeyOwningSide(foreignKeyOwningSide).mappedBy(mappedBy).isBidirectional(isBidirectional)
                    .isSystem(isSystem).deletable(deletable).modifiable(modifiable)
                    .build();
        } else {
            throw new UnsupportedOperationException(this.getCardinality() + " is not supported");
        }

       return gdmRelationship;
    }

    @Nonnull
    public Relationship toUnderScoreName() {
        name = GdmNamingUtils.toUnderScoreCase(name);
        reverseName = GdmNamingUtils.toUnderScoreCase(reverseName);
        leftEntityName = GdmNamingUtils.toUnderScoreCase(leftEntityName);
        rightEntityName = GdmNamingUtils.toUnderScoreCase(rightEntityName);
        foreignKeyOwningSide = GdmNamingUtils.toUnderScoreCase(foreignKeyOwningSide);
        mappedBy = GdmNamingUtils.toUnderScoreCase(mappedBy);
        return this;
    }

}
