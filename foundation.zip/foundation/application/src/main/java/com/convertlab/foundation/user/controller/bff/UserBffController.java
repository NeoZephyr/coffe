package com.convertlab.foundation.user.controller.bff;

import com.convertlab.foundation.user.service.UserService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.convertlab.foundation.user.entity.UserInfo;

import javax.validation.constraints.NotBlank;


@Qualifier("UserBffController")
@RestController
public class UserBffController {
    private final UserService userService;
    public UserBffController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/user/getUserInfo")
    public UserInfo show(@RequestParam @NotBlank Long userId) {
        UserInfo info =  userService.getUserInfo(userId);
        return info;
    }


}
