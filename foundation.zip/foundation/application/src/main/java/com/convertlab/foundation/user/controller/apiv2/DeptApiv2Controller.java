package com.convertlab.foundation.user.controller.apiv2;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.webmvc.annotation.OpenApiController;
import com.convertlab.foundation.library.webmvc.annotation.SkipRequestBodyAdvice;
import com.convertlab.foundation.user.entity.Dept;
import com.convertlab.foundation.user.model.DeptDTO;
import com.convertlab.foundation.user.service.DeptService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.HashMap;
import java.util.Map;

@OpenApiController
@SkipRequestBodyAdvice
@Slf4j
public class DeptApiv2Controller {

    private final DeptService deptService;

    public DeptApiv2Controller(DeptService deptService) {
        this.deptService = deptService;
    }

    //save方法
    @Nullable
    @PostMapping("/apiv2/depts")
    public Map<String, Object> save(@Nonnull @RequestBody DeptDTO dto) {
        boolean checkResult = deptService.check(dto);
        if (checkResult) {
            Dept dept = deptService.saveDept(dto);
            if(dept == null){
                log.error("create dept failed");
            }
            Map<String, Object> result = new HashMap<>();
            result.put("code", dept.getCode());
            result.put("name", dept.getName());
            result.put("parent", dept.getParent());
            result.put("outCode", dept.getOutCode());
            result.put("enabled", dept.getEnabled());
            result.put("dateCreated", dept.getDateCreated());
            result.put("lastUpdated", dept.getLastUpdated());
            result.put("sequence", dept.getSequence());
            result.put("path", dept.getPath());
            result.put("parentOutCode", dto.getParentOutCode());
            return result;
        }
        return null;
    }
}
