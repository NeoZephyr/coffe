package com.convertlab.foundation.misc.service.dboperation;

import com.convertlab.foundation.library.sqlprocessor.SQLDialect;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.misc.dto.CastAndCopyColumnRequest;
import lombok.extern.slf4j.Slf4j;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.concurrent.TimeUnit;

@Slf4j
public abstract class AbstractBatchDbOperation extends AbstractDbOperation {
    public AbstractBatchDbOperation(CastAndCopyColumnRequest args, Connection connection, SQLDialect sqlDialect) {
        super(args, connection, sqlDialect);
    }

    public void run() {
        long startId = 0;
        long start = System.currentTimeMillis();
        while (startId >= 0) {
            startId = runBatch(startId);
            if (args.getBatchInterval() > 0) {
                try {
                    TimeUnit.MILLISECONDS.sleep(args.getBatchInterval());
                } catch (Throwable t) {
                    //ignored
                }
            }
        }
        log.info("Batch db operation " + this.getClass().getSimpleName() + " is done, took " + (System.currentTimeMillis() - start) + "ms, args: " + JsonUtils.instanceOfDto().obj2Json(args));
    }

    private long runBatch(long startId) {
        long endId = maxIdInBatch(args, startId, connection);
        if (endId <= startId) {
            return -1;
        }
        String sql = buildBatchSql(args, startId, endId);
        log.info(sql);
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            int rows = pstmt.executeUpdate();
            log.info("run batch  [" + startId + ", " + endId + "] done, "+ rows + " rows affected");
        } catch (Exception e) {
            log.error("failed to run batch [" + startId + ", " + endId + "] " + JsonUtils.instanceOfDto().obj2Json(args), e);
        }
        return endId;
    }

    protected abstract String buildBatchSql(CastAndCopyColumnRequest args, long startId, long endId);

    private long maxIdInBatch(CastAndCopyColumnRequest args, long startId, Connection connection) {
        String sql = "select max(t.id) as maxId from (select " + args.getPkColumnName() + " as id from " + args.getTableName() + buildWhere(args);
        sql += " and id > " + startId;
        sql += " order by " + args.getPkColumnName();
        sql += " limit " + args.getBatchSize();
        sql += ") t";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getLong("maxId");
                } else {
                    return 0;
                }
            }
        } catch (Exception e) {
            throw new IllegalStateException("Failed to get maxId in the batch", e);
        }
    }

    @Override
    protected String buildSql() {
        return null;
    }
}
