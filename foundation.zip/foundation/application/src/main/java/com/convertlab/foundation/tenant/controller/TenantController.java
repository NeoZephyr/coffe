package com.convertlab.foundation.tenant.controller;

import com.convertlab.foundation.datapermission.model.SetGlobalAccessRequest;
import com.convertlab.foundation.datapermission.service.SettingService;
import com.convertlab.foundation.gdmpattern.service.GdmModelInitiator;
import com.convertlab.foundation.library.constant.ComponentNames;
import com.convertlab.foundation.library.datapermission.service.ResourceMetaService;
import com.convertlab.foundation.library.datapermission.service.ResourceSettingService;
import com.convertlab.foundation.library.gdmmeta.validation.ValidationException;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.multitenancy.exception.IllegalTenantIdException;
import com.convertlab.foundation.library.tenantlifecycle.exception.TenantCreationException;
import com.convertlab.foundation.library.tenantlifecycle.model.CreateTenantRequest;
import com.convertlab.foundation.library.tenantlifecycle.model.LifecycleResponse;
import com.convertlab.foundation.library.tenantlifecycle.model.TenantDto;
import com.convertlab.foundation.library.tenantlifecycle.spi.TenantLifecycleSpi;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.Objects;

@RestController
@Tag(name = "Tenant Lifecycle API", description = "租户生命周期API")
@RequestMapping("/v1/lifecycle")
@RequiredArgsConstructor
@Slf4j
public class TenantController implements TenantLifecycleSpi {
    private static final String MODULE_NAME = ComponentNames.FOUNDATION_SERVICE;
    private static final String SUCCESS = "SUCCESS";
    private static final String LOG_PREFIX = "[TenantLifecycle] ";

    private final ResourceMetaService resourceMetaService;
    private final ResourceSettingService resourceSettingService;
    private final SettingService settingService;

    @Override
    @Operation(summary = "创建租户", description = "创建租户,要求可以反复调用，效果幂等。")
    public LifecycleResponse createTenant(CreateTenantRequest request) {
        validate(request);
        log.info(LOG_PREFIX + "Start to create tenant {}.", request.getTenantId());
        //初始化resource metadata.
        step("Init resource metadata", resourceMetaService::initData);
        //初始化data permission settings.
        step("Init resource settings", resourceSettingService::initSettings);
        //默认需要将folder设置为private.
        step("Set global access", () -> {
            SetGlobalAccessRequest setGlobalAccessRequest = new SetGlobalAccessRequest();
            setGlobalAccessRequest.setResourceType("folder");
            setGlobalAccessRequest.setAccessPermission("private");

            ArrayList<SetGlobalAccessRequest> al = new ArrayList<>();
            al.add(setGlobalAccessRequest);
            settingService.setGlobalAccess(al);
            throw new ValidationException("test");
        });
        log.info(LOG_PREFIX + "Tenant {} created successfully.", request.getTenantId());
        LifecycleResponse lifecycleResponse = new LifecycleResponse(TenantContextHolder.getTenantIdExt(), "",
                SUCCESS);
        return lifecycleResponse;
    }

    private void step(String stepName, Runnable stepMethod) {
        try {
            log.info(LOG_PREFIX + "Start step: [{}]", stepName);
            long start = System.currentTimeMillis();
            stepMethod.run();
            log.info(LOG_PREFIX + "End step: [{}], cost {} ms", stepName, System.currentTimeMillis() - start);
        } catch (Exception e) {
            log.error(LOG_PREFIX + "Step [{}] failed", stepName, e);
            TenantCreationException exception = new TenantCreationException("Step [" + stepName + "] failed",
                    new String[]{e.getMessage()});
            throw exception;
        }
    }


    private void validate(@Nonnull TenantDto tenantDto) {
        if (!Objects.equals(TenantContextHolder.getTenantIdExt(), tenantDto.getTenantId())) {
            throw new IllegalTenantIdException();
        }
        if (!tenantDto.getModule().equalsIgnoreCase(MODULE_NAME)) {
            throw new ValidationException("Module name does not match. My name is " + MODULE_NAME + " but you " +
                    "requested " + tenantDto.getModule() + ".");
        }
    }
}
