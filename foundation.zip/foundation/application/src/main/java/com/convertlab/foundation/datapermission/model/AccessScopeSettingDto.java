package com.convertlab.foundation.datapermission.model;

import lombok.Getter;

import java.util.List;

@Getter
public class AccessScopeSettingDto {
    Integer mask;

    List<String> scopes;

    public AccessScopeSettingDto(Integer mask, List<String> scopes) {
        this.mask = mask;
        this.scopes = scopes;
    }

    public void setMask(Integer mask) {
        this.mask = mask;
    }

    public void setScopes(List<String> scopes) {
        this.scopes = scopes;
    }

}
