package com.convertlab.foundation.datapermission.service;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.convertlab.foundation.datapermission.entity.BaseResourceAccessEntity;
import com.convertlab.foundation.datapermission.mapper.BaseResourceAccessMapper;
import com.convertlab.foundation.library.datapermission.ResourceAccessDto;
import com.convertlab.foundation.datapermission.util.ResourceAccessDtoConverter;
import com.convertlab.foundation.library.datapermission.GrantedSubjectType;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class ResourceAccessOLTPService implements BaseResourceAccessService {

    final BaseResourceAccessMapper mapper;

    public ResourceAccessOLTPService(BaseResourceAccessMapper mapper) {
        this.mapper = mapper;
    }

    @Transactional
    @Nonnull
    @Override
    public BaseResourceAccessEntity save(String tableName, @Nonnull ResourceAccessDto dto) {
        BaseResourceAccessEntity entity = ResourceAccessDtoConverter.convertToEntity(dto);
        //set current date to entity date created and last update
        entity.setDateCreated(java.time.Instant.now());
        entity.setLastUpdated(java.time.Instant.now());
        mapper.insert(tableName, entity);
        return entity;
    }

    @Transactional
    @Override
    public void batchSave(String tableName, List<ResourceAccessDto> dtos) {
        dtos.forEach(dto -> {
            BaseResourceAccessEntity entity = ResourceAccessDtoConverter.convertToEntity(dto);
            //set current date to entity date created and last update
            entity.setDateCreated(java.time.Instant.now());
            entity.setLastUpdated(java.time.Instant.now());
            mapper.insert(tableName, entity);
        });
    }

    @Transactional
    @Override
    public void update(String tableName, String uuid, @Nonnull ResourceAccessDto dto) {
        BaseResourceAccessEntity entity = ResourceAccessDtoConverter.convertToEntity(dto);
        //set current date to entity last update
        entity.setLastUpdated(java.time.Instant.now());
        //set entity uuid
        entity.setUuid(uuid);
        mapper.update(tableName, entity);
    }

    @Transactional
    @Override
    public void batchUpdate(String tableName, List<ResourceAccessDto> dtos) {
        dtos.forEach(dto -> {
            BaseResourceAccessEntity entity = ResourceAccessDtoConverter.convertToEntity(dto);
            //set current date to entity last update
            entity.setLastUpdated(java.time.Instant.now());
            mapper.update(tableName, entity);
        });

    }

    @Transactional
    @Override
    public void upsert(String tableName, ResourceAccessDto dto) {
        //TODO 暂时先不实现
    }

    @Transactional
    @Override
    public void batchUpsert(String tableName, List<ResourceAccessDto> dtos) {
        //TODO暂时先不实现
    }

    @Transactional
    @Override
    public BaseResourceAccessEntity getById(String tableName, String uuid) {
        //mapper getby uuid
        return mapper.getByUuid(tableName, uuid);
    }

    @Transactional
    @Override
    public void deleteById(String tableName, String uuid) {
        mapper.delete(tableName, uuid);
    }

    @Transactional
    @Override
    public void batchDelete(@NotNull String tableName, List<BaseResourceAccessEntity> entities) {
        entities.forEach(
                entity ->
                {
                    BaseResourceAccessEntity loadedEntity =
                            this.getByKey(tableName, entity.getResourceType(),
                                    entity.getResourceCode(), entity.getGrantedSubjectType(),
                                    entity.getGrantedSubjectCode(), entity.getGrantedReason());
                    if (loadedEntity != null) {
                        this.mapper.delete(tableName, loadedEntity.getUuid());
                    }
                }
        );
    }


    @Transactional
    @Override
    public void delete(String tableName, String resourceType, String resourceCode) {
        mapper.deleteByResourceTypeAndResourceCode(tableName, resourceType, resourceCode);
    }

    @Transactional
    @Override
    public void delete(String tableName, String resourceType, String resourceCode, GrantedSubjectType grantedSubjectType, String grantedSubjectCode) {
        mapper.deleteByResourceTypeAndResourceCodeAndGrantedSubjectTypeAndGrantedSubjectCode(tableName, resourceType, resourceCode, grantedSubjectType, grantedSubjectCode);
    }

    @Transactional
    @Override
    public void delete(String tableName, String resourceType, GrantedSubjectType grantedSubjectType, String grantedSubjectCode) {
        throw new UnsupportedOperationException("This operation is not supported.");
    }

    @Override
    public void delete(String tableName, GrantedSubjectType grantedSubjectType, String grantedSubjectCode) {
        mapper.deleteByGrantedSubjectTypeAndGrantedSubjectCode(tableName, grantedSubjectType.getValue(), grantedSubjectCode);
    }

    @Nullable
    @Override
    public List<BaseResourceAccessEntity> list(String tableName, String resourceType, String resourceCode, GrantedSubjectType grantedSubjectType, String grantedSubjectCode) {
        return mapper.listByResourceTypeAndResourceCodeAndGrantedSubjectTypeAndGrantedSubjectCode(tableName, resourceType, resourceCode, grantedSubjectType, grantedSubjectCode);
    }

    @Nullable
    @Override
    public List<BaseResourceAccessEntity> list(String tableName, String resourceType, String resourceCode) {
        return mapper.listByResourceTypeAndResourceCode(tableName, resourceType, resourceCode);
    }

    @org.jetbrains.annotations.Nullable
    @Override
    public List<BaseResourceAccessEntity> list(String tableName, String resourceType, List<String> resourceCodeList) {
        return mapper.listByResourceTypeAndResourceCodeList(tableName, resourceType, resourceCodeList);
    }

    @org.jetbrains.annotations.Nullable
    @Override
    public List<BaseResourceAccessEntity> list(String tableName, String resourceType, Map<GrantedSubjectType, List<String>> grantedSubjectTypeListMap) {
        return mapper.listByResourceTypeAndGrantedSubjectTypeListMap(tableName, resourceType, grantedSubjectTypeListMap);
    }

    @Nullable
    @Override
    public List<BaseResourceAccessEntity> list(String tableName, String resourceType, GrantedSubjectType grantedSubjectType, List<String> grantedSubjectCodeList) {
        return mapper.listByResourceTypeAndGrantedSubjectTypeAndGrantedSubjectCodeList(tableName, resourceType, grantedSubjectType, grantedSubjectCodeList);
    }

    @Override
    public BaseResourceAccessEntity getByKey(String tableName, String resourceType, String resourceCode, GrantedSubjectType grantedSubjectType, String grantedSubjectCode, String grantedReason) {
        return mapper.getByKey(tableName, resourceType, resourceCode, grantedSubjectType, grantedSubjectCode, grantedReason);
    }
}
