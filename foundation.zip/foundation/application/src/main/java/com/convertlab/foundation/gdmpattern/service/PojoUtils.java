package com.convertlab.foundation.gdmpattern.service;

import javax.validation.*;
import java.util.Set;

/**
 * Pojo 相关的操作，例如验证。
 * 放在Application下面是因为Validator依赖javax/EL/...等，这些一般也是被Tomcat等容器加载的。
 */
public class PojoUtils {
    static Validator validator;
    static {
        try (ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory()) {
            validator = validatorFactory.getValidator();
        }
    }
    public static <T> void validatePojo(T request) {
        Set<ConstraintViolation<T>> violations = validator.validate(request);
        if (!violations.isEmpty()) {
            throw new ConstraintViolationException(violations);
        }
    }
}
