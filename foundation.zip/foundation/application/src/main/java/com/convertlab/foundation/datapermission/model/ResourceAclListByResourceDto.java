package com.convertlab.foundation.datapermission.model;

import lombok.Data;

@Data
public class ResourceAclListByResourceDto {
    String resourceType;
    String resourceCode;
}
