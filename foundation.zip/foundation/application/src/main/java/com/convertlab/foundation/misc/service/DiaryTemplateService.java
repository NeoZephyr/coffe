package com.convertlab.foundation.misc.service;

import com.convertlab.foundation.misc.dto.DiaryTemplate;

import javax.annotation.Nullable;
import java.time.Instant;
import java.util.List;

public interface DiaryTemplateService {
    List<DiaryTemplate> getAllTemplates();
    List<DiaryTemplate> getTemplatesNewerThan(Instant date);

    @Nullable
    DiaryTemplate getTemplateByName(String name);
    @Nullable
    DiaryTemplate getTemplateById(String id);

    DiaryTemplate createTemplate( DiaryTemplate template);
    DiaryTemplate updateTemplate(DiaryTemplate template);

}
