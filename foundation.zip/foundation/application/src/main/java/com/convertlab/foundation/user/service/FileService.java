package com.convertlab.foundation.user.service;

import com.convertlab.common.crypto.model.LogConstants;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.poi.ss.usermodel.*;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class FileService {

    @Value("${fileService.serverUrl}")
    private String fileServiceUrl;

    private List<Map<String, Object>> readCells(InputStream inputStream) throws Exception {
        Workbook workbook=null;
        try {
            workbook = WorkbookFactory.create(inputStream);
            Sheet sheet = workbook.getSheetAt(0);

            Row headerRow = sheet.getRow(0);
            if (headerRow != null) {
                List<String> headers = Lists.newArrayList(headerRow.cellIterator()).stream().map(Cell::getStringCellValue).collect(Collectors.toList());

                return Lists.newArrayList(sheet.rowIterator()).stream()
                        .filter(row -> row.getRowNum() > 0)
                        .map(row -> {
                            Map<String, Object> cells = new HashMap<>();
                            for (int i = 0; i < row.getPhysicalNumberOfCells(); i++) {
                                String header = headers.get(i);
                                if (!Strings.isNullOrEmpty(header)) {
                                    cells.put(header, getCellValue(row.getCell(i)));
                                }
                            }
                            return cells;
                        }).collect(Collectors.toList());
            } else {
                return Lists.newArrayList();
            }
        }finally {
            if (Objects.nonNull(workbook)) {
                workbook.close();
            }
        }

    }

    private Object getCellValue(Cell cell) {
        if (cell == null) {
            return null;
        }

        switch (cell.getCellType()) {
            case NUMERIC: // CELL_TYPE_NUMERIC
                if (DateUtil.isCellDateFormatted(cell)) {
                    int format = cell.getCellStyle().getDataFormat();
                    if (format == 14 || format == 31 || format == 57 || format == 58) {
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                        return sdf.format(cell.getDateCellValue());
                    } else if (format == 20 || format == 32) {
                        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
                        return sdf.format(cell.getDateCellValue());
                    } else {
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
                        return sdf.format(cell.getDateCellValue());
                    }
                } else {
                    DecimalFormat df = new DecimalFormat("0");
                    return df.format(cell.getNumericCellValue());
                }
            case STRING: // CELL_TYPE_STRING
            case FORMULA: // CELL_TYPE_FORMULA
                return cell.getStringCellValue();
            case BLANK: // CELL_TYPE_BLANK
                return "";
            case BOOLEAN: // CELL_TYPE_BOOLEAN
                return cell.getBooleanCellValue();
            case ERROR: // CELL_TYPE_ERROR
                return "";
            default:
                return "";
        }
    }

    public List<Map<String, Object>> downloadAndReadCells(Long attachmentId) {
        HttpGet httpGet = new HttpGet(fileServiceUrl + "/file/download/" + attachmentId);
        httpGet.setHeader(LogConstants.X_TENANT_ID, TenantContextHolder.getTenantId().toString());
        httpGet.setHeader(LogConstants.X_REQUEST_ID, MDC.get(LogConstants.X_REQUEST_ID));

        try (CloseableHttpClient client = HttpClients.createDefault();
             CloseableHttpResponse out = client.execute(httpGet)){
            if (Objects.isNull(out)) {
                throw new RuntimeException("下载文件失败");
            }

            if (out.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
                throw new RuntimeException("下载文件失败, responseCode: " + out.getStatusLine().getStatusCode());
            }

            try (InputStream inputStream = out.getEntity().getContent()) {
                return readCells(inputStream);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public Map<String, Object> upload(String fileName, InputStream inputStream, String fileContentType, long size, Integer usage) {
        Map<String, Object> result = Collections.emptyMap();
        try (CloseableHttpClient client = HttpClients.createDefault()) {

            log.info("=== begin to upload file to oss, size: {}", size);

            HttpPost httpPost = new HttpPost(fileServiceUrl + "/file/upload");
            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.setCharset(StandardCharsets.UTF_8);
            builder.addBinaryBody("file",
                    inputStream, ContentType.MULTIPART_FORM_DATA, fileName);
            ContentType contentType = ContentType.create(
                    ContentType.TEXT_PLAIN.getMimeType(), StandardCharsets.UTF_8);

            builder.addPart("name", new StringBody(fileName, contentType));
            builder.addPart("contentType", new StringBody(fileContentType, contentType));
            builder.addPart("size", new StringBody(String.valueOf(size), contentType));
            builder.addPart("usage", new StringBody(String.valueOf(usage), contentType));

            HttpEntity entity = builder.build();
            httpPost.setEntity(entity);
            httpPost.setHeader(LogConstants.X_TENANT_ID, TenantContextHolder.getTenantId().toString());
            httpPost.setHeader(LogConstants.X_REQUEST_ID, MDC.get(LogConstants.X_REQUEST_ID));

            try (CloseableHttpResponse response = client.execute(httpPost)) {
                if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                    String resp = EntityUtils.toString(response.getEntity());
                    log.info("Upload result {}", resp);
                    result = JsonUtils.instanceOfDto().convertToMap(resp);
                }

                if (result.get("errorCode") == "0") {
                    return (Map<String, Object>) result.get("message");
                } else {
                    return null;
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return result;
    }
}
