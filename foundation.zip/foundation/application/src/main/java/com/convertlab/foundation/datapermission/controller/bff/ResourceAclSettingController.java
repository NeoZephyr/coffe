package com.convertlab.foundation.datapermission.controller.bff;


import com.convertlab.foundation.datapermission.entity.DpDatapermissionRule;
import com.convertlab.foundation.datapermission.model.*;
import com.convertlab.foundation.datapermission.service.RuleService;
import com.convertlab.foundation.library.datapermission.model.*;
import com.convertlab.foundation.datapermission.service.SettingService;
import com.convertlab.foundation.library.model.vo.GenericResponse;
import com.convertlab.foundation.user.entity.Dept;
import com.convertlab.foundation.user.service.DeptService;
import org.jetbrains.annotations.NotNull;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/dp/acl/setting")
public class ResourceAclSettingController {

    final SettingService settingService;

    final RuleService ruleService;

    final DeptService deptService;

    public ResourceAclSettingController(SettingService settingService,
                                        RuleService ruleService,
                                        DeptService deptService) {
        this.settingService = settingService;
        this.ruleService = ruleService;
        this.deptService = deptService;
    }


    @GetMapping("/getGlobalAccess")
    public List<GlobalAccessSetting> getGlobalAccessSettings() {
        return settingService.listGlobalAccess();
    }

    @PostMapping("/setGlobalAccess")
    public List<GlobalAccessSetting> setGlobalAccessSettings(@RequestBody List<SetGlobalAccessRequest> requests) {
        return settingService.setGlobalAccess(requests);
    }

    @GetMapping("/getHighsea")
    public HighSeaSettingResponseDto getHighseaSetting() {
        return getHighSeaSettingDto();
    }

    @PostMapping("/setHighsea")
    public HighSeaSettingResponseDto setHighseaSetting(@RequestBody HighSeaSettingRequestDto request) {
        settingService.setHighSeaSettings(request.buildHighSeasSettings());
        return getHighSeaSettingDto();
    }

    private HighSeaSettingResponseDto getHighSeaSettingDto() {
        @NotNull List<HighSeasSetting> rows = settingService.getHighSeaSettings();
        if (rows.isEmpty()) {
            return new HighSeaSettingResponseDto(HighSeaSettingResponseDto.PUBLIC_TYPE, Collections.emptyList());
        } else if (rows.stream().anyMatch(s -> Objects.equals(s.getGrantedSubjectCode(), HighSeasSetting.PUBLIC_CODE))) {
            return new HighSeaSettingResponseDto(HighSeaSettingResponseDto.PUBLIC_TYPE, new ArrayList<>());
        } else {
            List<String> codes = rows.stream().map(HighSeasSetting::getGrantedSubjectCode).collect(Collectors.toList());
            List<Dept> depts = deptService.listDepts(null, codes);
            return new HighSeaSettingResponseDto(HighSeaSettingResponseDto.PRIVATE_TYPE, depts);
        }
    }

    @GetMapping("/getSwitchHomeDataOrganization")
    public SwitchSettingResponseDto getHomeDataOrganizationSwitchSetting() {
        SwitchSetting oneSwitchSetting = settingService.getOneSwitchSetting(SwitchSetting.HOME_DATA_SUBJECT_KEY, true);
        return new SwitchSettingResponseDto(oneSwitchSetting.getGrantedSubjectKey(), oneSwitchSetting.getGrantedSubjectValue());
    }

    @PostMapping("/setSwitchHomeDataOrganization")
    public SwitchSettingResponseDto setHomeDataOrganizationSwitchSetting(@RequestBody HomeDataSwitchSettingRequestDto request) {
        boolean switchValue = false;
        if (request.getSwitchValue() != null) {
            switchValue = request.getSwitchValue();
        }
        settingService.setOneSwitchSetting(SwitchSetting.HOME_DATA_SUBJECT_KEY, switchValue);
        return getHomeDataOrganizationSwitchSetting();
    }

    @GetMapping("/getDeptAttr")
    public DeptAttrSetting getDeptAttr(@NotBlank @RequestParam String objectName) {
        return settingService.getDeptAttr(objectName);
    }

    @PostMapping("/setDeptAttr")
    public DeptAttrSetting setDeptAttr(@RequestBody SetDeptAttrRequest request) {
        return settingService.setDeptAttr(request.getDeptAttrColumn(), request.getObjectName());
    }

    @GetMapping("/getAccessScope")
    public AccessScopeSettingDto getAccessScope() {
        return getAccessScopeSettingDto();
    }

    @PostMapping("/setAccessScope")
    public AccessScopeSettingDto setAccessScope(@RequestBody AccessScopeSettingDto request) {
        return setAccessScopeSetting(request);
    }

    private AccessScopeSettingDto setAccessScopeSetting(AccessScopeSettingDto accessScopeSettingDto) {
        int newMask = AccessScopeSetting.masking(accessScopeSettingDto.getScopes());
        AccessScopeSetting newSetting = new AccessScopeSetting(newMask);
        settingService.setAccessScopeSetting(newSetting);
        return new AccessScopeSettingDto(newSetting.getScopeMask(), accessScopeSettingDto.getScopes());
    }

    private AccessScopeSettingDto getAccessScopeSettingDto() {
        AccessScopeSetting accessScopeSetting = settingService.getAccessScopeSetting();
        if (accessScopeSetting != null) {
            List<String> scopes = AccessScopeSetting.unmasking(accessScopeSetting.getScopeMask());
            return new AccessScopeSettingDto(accessScopeSetting.getScopeMask(), scopes);
        }

        return null;
    }


    @PostMapping("/rule")
    public DpDatapermissionRuleDto saveRule(@RequestBody DpDatapermissionRuleDto dpDatapermissionRuleDto) {
        return ruleService.saveDatapermissionRule(dpDatapermissionRuleDto);
    }

    @PutMapping("/rule/{ruleId}")
    public DpDatapermissionRuleDto updateRule(@PathVariable Long ruleId, @RequestBody DpDatapermissionRuleDto dpDatapermissionRuleDto) {
        return ruleService.updateDatapermissionRule(ruleId, dpDatapermissionRuleDto);
    }

    @PutMapping("/rule/{ruleId}/status")
    public GenericResponse<Boolean> updateRule(@PathVariable Long ruleId, @RequestBody DpRuleSparkResult result) {
        String status = (Objects.equals(
                result.getResult().getStatus(),
                RuleService.SPARK_JOB_DATA_PERMISSION_SUCCESS)) ?
                DpDatapermissionRule.STATUS_FINISHED :
                DpDatapermissionRule.STATUS_FAILED;
        ruleService.updateDpStatus(ruleId, status);
        return GenericResponse.<Boolean>builder().result(true).build();
    }

    @DeleteMapping("/rule/{ruleId}")
    public DpDatapermissionRuleDto deleteRule(@PathVariable Long ruleId) {
        return ruleService.deleteDatapermissionRule(ruleId);
    }

    @GetMapping("/rules")
    public List<DpDatapermissionRuleDto> listRule(@RequestParam(name = "profile", defaultValue = "") String profile,
                                                  @RequestParam(name = "pageNum", defaultValue = "1") @Min(1) Integer pageNum,
                                                  @RequestParam(name = "pageSize", defaultValue = "50") @Min(1) @Max(100) Integer pageSize) {
        return ruleService.listDatapermissionRule(profile, pageNum, pageSize);
    }
}
