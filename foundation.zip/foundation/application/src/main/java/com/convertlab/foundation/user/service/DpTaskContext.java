package com.convertlab.foundation.user.service;

import com.convertlab.foundation.user.model.DpTaskDTO;
import com.convertlab.foundation.user.utils.DpTaskType;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class DpTaskContext {

    private final ImportFromExcelTaskExecutorService importFromExcelTaskExecutorService;

    private final ExportToExcelTaskExecutorService exportToExcelTaskExecutorService;

    private final Map<String, TaskExecutorService> taskStrategyMap = new ConcurrentHashMap<>();

    @PostConstruct
    public void init() {
        taskStrategyMap.put(DpTaskType.import_from_excel.name(), importFromExcelTaskExecutorService);
        taskStrategyMap.put(DpTaskType.export_to_excel.name(), exportToExcelTaskExecutorService);
    }

    public DpTaskContext(ImportFromExcelTaskExecutorService importFromExcelTaskExecutorService,
                         ExportToExcelTaskExecutorService exportToExcelTaskExecutorService) {
        this.importFromExcelTaskExecutorService = importFromExcelTaskExecutorService;
        this.exportToExcelTaskExecutorService = exportToExcelTaskExecutorService;
    }

    public void executeTaskStrategy(String type, DpTaskDTO dto) {
        taskStrategyMap.get(type).execute(dto);
    }
}
