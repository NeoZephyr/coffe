package com.convertlab.foundation.misc.service;

import com.convertlab.foundation.library.redis.annotation.RedisLock;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.integration.redis.util.RedisLockRegistry;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;

@Slf4j
@RequiredArgsConstructor
@Service
public class RedisLockTestService {
    private final RedisLockRegistry lockRegistry;

    @RedisLock(key = "#{'lock.'+#key}", waitTime = 1, isTenantIsolation = false)
    public boolean testLockWithAnnotation(String key) {
        log.info("lock acquired");
        try {
            TimeUnit.SECONDS.sleep(30);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return true;
    }

    public boolean testLock(String key) {
        Lock lock = lockRegistry.obtain(key);
        try {
            boolean locked = lock.tryLock(1, TimeUnit.SECONDS);
            if (locked) {
                try {
                    testReentrantLock1(key);
                    log.info("lock acquired");
                    TimeUnit.SECONDS.sleep(30);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                } finally {
                    lock.unlock();
                }
            } else {
                log.warn("failed to acquire lock");
            }
            return locked;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return false;
        }
    }

    public void testReentrantLock1(String key) {
        Lock lock = lockRegistry.obtain(key);
        try {
            if (lock.tryLock(1, TimeUnit.SECONDS)) {
                try {
                    testReentrantLock2(key);
                    log.info("lock acquired");
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                } finally {
                    lock.unlock();
                }
            } else {
                log.warn("failed to acquire lock");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public void testReentrantLock2(String key) {
        Lock lock = lockRegistry.obtain(key);
        try {
            if (lock.tryLock(1, TimeUnit.SECONDS)) {
                try {
                    log.info("lock acquired");
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                } finally {
                    lock.unlock();
                }
            } else {
                log.warn("failed to acquire lock");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
