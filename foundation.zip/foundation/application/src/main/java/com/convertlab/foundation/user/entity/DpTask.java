package com.convertlab.foundation.user.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DpTask {

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

//    private Long tenantId;

    @TableField(fill = FieldFill.INSERT, update = "%s+1", updateStrategy = FieldStrategy.IGNORED)
    private Integer version;

    private String type;

    private String status;

    private String taskDef;

    private String failReason;

    private Boolean recoverable = false;

    private Long attachmentId = 0L;

    private Long failedAttachmentId = 0L;

    private Instant dateCreated;

    private Instant lastUpdated;
}