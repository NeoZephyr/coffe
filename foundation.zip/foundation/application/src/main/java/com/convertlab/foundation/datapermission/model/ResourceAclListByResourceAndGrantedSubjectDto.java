package com.convertlab.foundation.datapermission.model;

import com.convertlab.foundation.library.datapermission.GrantedSubjectType;
import lombok.Data;

@Data
public class ResourceAclListByResourceAndGrantedSubjectDto {
    String resourceType;
    String resourceCode;
    GrantedSubjectType grantedSubjectType;
    String grantedSubjectCode;
}
