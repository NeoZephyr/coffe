package com.convertlab.foundation.metahealth.checker;

import com.convertlab.foundation.libaray.meta.health.Issue;
import com.convertlab.foundation.libaray.meta.health.MetaChecker;
import com.convertlab.foundation.libaray.meta.health.annotation.MetaCheckerAnnotation;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationship;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmSingularGdmRelationship;
import lombok.RequiredArgsConstructor;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.List;

import static com.convertlab.foundation.libaray.meta.health.BasicMetaValidationRule.*;

@MetaCheckerAnnotation
@RequiredArgsConstructor
public class GdmRelationshipChecker implements MetaChecker<GdmRelationship> {
    private final GsMetaClient gsMetaClient;

    @Override
    public List<Issue> check(@Nonnull GdmRelationship relationship) {
        List<Issue> issues = new ArrayList<>();
        String leftEntityName = relationship.getLeftEntityName();
        String rightEntityName = relationship.getRightEntityName();
        GdmEntity leftEntity = gsMetaClient.getEntity(relationship.getLeftEntityName());
        GdmEntity rightEntity = gsMetaClient.getEntity(relationship.getRightEntityName());

        if (leftEntity == null) {
            issues.add(RULE_04_001.toIssue(leftEntityName, relationship.getName(), "left", leftEntityName));
        }
        if (rightEntity == null) {
            issues.add(RULE_04_001.toIssue(leftEntityName, relationship.getName(), "right", rightEntityName));
        }

        if (relationship instanceof GdmSingularGdmRelationship) {
            GdmSingularGdmRelationship singularGdmRelationship = (GdmSingularGdmRelationship) relationship;
            String owningSide = singularGdmRelationship.getForeignKeyOwningSide();
            if (!leftEntityName.equalsIgnoreCase(owningSide) && !rightEntityName.equalsIgnoreCase(owningSide)) {
                issues.add(RULE_04_002.toIssue(leftEntityName, relationship.getName(), owningSide));
            } else {
                String mappedBy = singularGdmRelationship.getMappedBy();
                GdmEntity entity = owningSide.equalsIgnoreCase(leftEntityName) ? leftEntity : rightEntity;
                if (entity != null) {
                    GdmField field = entity.getFieldsMap().get(mappedBy);
                    if (field == null) {
                        issues.add(RULE_04_003.toIssue(leftEntityName, relationship.getName(), mappedBy, owningSide));
                    }
                }
            }
        }
        return issues;
    }
}
