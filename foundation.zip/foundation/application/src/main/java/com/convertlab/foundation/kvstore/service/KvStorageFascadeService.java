package com.convertlab.foundation.kvstore.service;

import com.convertlab.foundation.kvstore.dto.KeyValuesPair;
import com.convertlab.foundation.kvstore.dto.KvQuery;

import java.util.List;
import java.util.Map;

public interface KvStorageFascadeService {
    /**
     * 根据条件查询KVStore
     * @param kvQuery
     * @return
     */
    public List<KeyValuesPair> batchGet(String entityName, KvQuery kvQuery) throws Exception;

    /**
     * 批量更新kvStore
     * @param entityName
     * @param kvPairs
     * @return
     */
    public void batchUpsert(String entityName, List<KeyValuesPair> kvPairs) throws Exception;

    /**
     * 批量删除kvStore
     * @param entityName
     * @param kvPairs
     */
    public void batchDelete(String entityName, List<KeyValuesPair> kvPairs) throws Exception;

    /**
     * 批量增加值
     * @param entityName
     * @param kvPairs
     * @return
     */
    public Map<String, Map<String, Long>> batchIncrement(String entityName, List<KeyValuesPair> kvPairs) throws Exception;
}
