package com.convertlab.foundation.gdmmeta.configure;

import com.convertlab.foundation.gdmmeta.service.impl.MetaEventPublisher;
import com.convertlab.foundation.library.business.property.EventBrokerProperties;
import com.convertlab.foundation.library.property.DataProcessingModeProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration("gdmMetaAutoConfig")
@Slf4j
public class AutoConfig {
//    @Nonnull
//    @Bean(name = "oltpJdbcTemplateWithoutMetaClient")
//    OLTPJdbcTemplate getOLTPJdbcTemplate(@Nonnull DataSource dataSource, UserInfoClient userInfoFeignClient, GeneralMetaClient generalMetaClient,
//                                         @Autowired(required = false) ConversionService conversionService,
//                                         @Autowired(required = false) CryptoClient cryptoClient) {
//        GdmStorageMetaRtClient dummyMetaClient = MockMetaClientBuilder.dummyStorageMetaClient();
//        return new OLTPJdbcTemplate(dataSource, userInfoFeignClient, true, dummyMetaClient, generalMetaClient, conversionService, cryptoClient);
//    }

//    @Nonnull
//    @Primary
//    @Bean("localCacheManager")
//    public CacheManager localCacheManager() {
//        com.github.benmanes.caffeine.cache.Cache<String, Object> cache = Caffeine.newBuilder()
//                .maximumSize(10000)
//                .expireAfterWrite(Duration.ofMinutes(10))
//                .removalListener((key, value, cause) ->
//                        log.debug("Key {} was removed", key))
//                .build();
//        LocalCache<String, Object> localCache = LocalCache.buildFromCaffeine(cache);
//        return new LocalCacheManager(localCache);
//    }

    @Bean
    protected MetaEventPublisher diaryService(ApplicationEventPublisher appEventPublisher,
                                           EventBrokerProperties eventBrokerProperties) {
        return new MetaEventPublisher(appEventPublisher, eventBrokerProperties );
    }

    @Bean
    public DataProcessingModeProperties dataProcessingModeProperties() {
        return new DataProcessingModeProperties();
    }

}
