package com.convertlab.foundation.datapermission.model;

import lombok.Data;

import javax.annotation.Nonnull;
import java.util.List;

@Data
public class ResourceBatchDeleteShareRequestDto {

        public ResourceBatchDeleteShareRequestDto(){
        }

        private String resourceType;

        @Nonnull
        private List<String> resourceCodes;

}
