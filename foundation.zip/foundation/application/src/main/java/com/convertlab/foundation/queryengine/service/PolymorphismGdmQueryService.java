package com.convertlab.foundation.queryengine.service;

import com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto;
import com.convertlab.foundation.gdmpattern.provisioner.UdoFeatureProvisioner;
import com.convertlab.foundation.library.filter.FilterJsonParser;
import com.convertlab.foundation.library.filter.v4.timeline.GdmFilterV4WithTimeline;
import com.convertlab.foundation.library.gdmmeta.client.GdmMetaHelper;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.gdmmeta.model.GdmInheritance;
import com.convertlab.foundation.library.gdmmeta.model.GdmTablePartition;
import com.convertlab.foundation.library.jdbc.core.BaseJdbcTemplate;
import com.convertlab.foundation.library.sqlprocessor.ProcessingMode;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.*;
import java.util.stream.Collectors;

import static com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto.UdoDomains.EVENT_PATTERN;

@Slf4j
public class PolymorphismGdmQueryService extends GdmQueryService {
    private final GdmMetaHelper gdmMetaHelper;

    // 历史上为了避免事件的entity跟档案名称连接之后过长，缩减了事件entity的长度，比如c_sys_sales_leads_update事件的entity也叫 c_sys_sales_leads_update
    private final List<String> exceptionalProfileNamesWithShortEventEntities = Arrays.asList("c_sys_sales_leads", "c_sys_sales_leads2");

    public PolymorphismGdmQueryService(BaseJdbcTemplate olapJdbcTemplate,
                                       BaseJdbcTemplate oltpJdbcTemplate,
                                       FilterJsonParser<GdmFilterV4WithTimeline> bindingVarsParser,
                                       JsonUtils jsonUtils,
                                       GdmMetaHelper gdmMetaHelper) {
        super(olapJdbcTemplate,oltpJdbcTemplate, bindingVarsParser, jsonUtils);
        this.gdmMetaHelper = gdmMetaHelper;
    }

    @Override
    protected List<Map<String, Object>> queryForList(String masterTable, String gdql, @Nullable Object[] args, @Nonnull int[] argTypes,ProcessingMode processingMode) {
        List<Map<String, Object>> result = super.queryForList(masterTable, gdql, args, argTypes,  processingMode);
        if (CollectionUtils.isEmpty(result)) {
            return result;
        }

        GdmEntity masterEntity = masterTable == null ?
                masterEntity(gdql)
                :
                gdmMetaHelper.getEntity(masterTable);
        if (masterEntity == null || !shouldDownCast(masterEntity)) {
            return result;
        }
        return result.stream()
                .map(map -> downCast(masterEntity, map))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    //TODO Hard-coded! Re-implement me!
    protected boolean shouldDownCast(GdmEntity entity) {
        String tableName = entity.getDbTableName();
        return (GdmPatternDto.CustomerDomains.EVENT.equals(tableName)
                || GdmPatternDto.UdoDomains.EVENT.equals(tableName))
                &&
                (entity.getInheritance() == null
                || (entity.getInheritance() != null && !entity.getInheritance().isSubtype()));
    }

    protected Map<String, Object> downCast(GdmEntity entity, Map<String, Object> map) {
        String identifierField = getInheritanceIdentifierField(entity);
        String subEntityName = Optional.ofNullable(map.get(identifierField))
                .map(Object::toString)
                .orElse(null);
        if(subEntityName == null) {
            //partition column is not in select list, return directly.
            return map;
        }
        String originalSubEntityName = subEntityName;
        String masterEntity = entity.getTablePartition().getIdentifierValue();
        if (entity.getTablePartition() != null) {
            subEntityName = UdoFeatureProvisioner.buildFeatureName(masterEntity, subEntityName, EVENT_PATTERN);
            subEntityName = subEntityName == null?null:subEntityName.toLowerCase();
        }
        GdmEntity subEntity = gdmMetaHelper.getEntity(subEntityName);
        if(subEntity == null && exceptionalProfileNamesWithShortEventEntities.contains(masterEntity)){
            log.warn("Fallback to subEntity without prefix cf_* {}", originalSubEntityName);
            subEntity = gdmMetaHelper.getEntity(originalSubEntityName);
        }
        if (subEntity == null) {
            log.warn("Sub-entity -{} not found for master entity - {}", subEntityName, masterEntity);
            return null;
        }
        GdmInheritance inheritance = subEntity.getInheritance();
        if (inheritance == null) {
            log.warn("Sub-entity -{} is not inherited from master", subEntityName);
            return null;
        }
        Map<String, Object> result = Maps.newHashMap();
        result.put(inheritance.getIdentifierField(), inheritance.getIdentifierValue());
        GdmTablePartition tablePartition = subEntity.getTablePartition();
        if (tablePartition != null) {
            result.put(tablePartition.getIdentifierField(), tablePartition.getIdentifierValue());
        }
        for (GdmField field : subEntity.getFields()) {
            Object value = map.remove(field.getDbColumnName());
            if (value != null) {
                result.put(field.getFieldName(), value);
            }
        }
        Map<String, Object> remainedValues = map.keySet().stream()
                .filter(x -> map.get(x) != null)
                .collect(Collectors.toMap(x -> x, x -> map.get(x)));
        result.putAll(remainedValues);

        return result;
    }

    //TODO Hard-coded! Re-implement me!
    private String getInheritanceIdentifierField(GdmEntity entity) {
        return GdmPatternDto.CustomerDomains.EVENT_INHERITANCE_KEY;
    }

    protected GdmEntity masterEntity(String gdql) {
        if(StringUtils.isBlank(gdql)) {
            return null;
        }
        int index = gdql.toLowerCase().indexOf(" from ") + 6;
        String subString = gdql.substring(index);
        String table = subString.substring(0, subString.indexOf(" "));
        return gdmMetaHelper.getEntity(table);
    }
}
