package com.convertlab.foundation.user.utils;

import com.google.common.graph.Traverser;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;

public class Tree<T> {
    public T node;
    public Tree<T>[] children;

    public Tree(T node, Tree<T>[] children) {
        this.node = node;
        this.children = children;
    }

    public static <T> Tree<T> unfold(
            Function<T, Map.Entry<T, T[]>> builder,
            T node
    ) {
        Map.Entry<T, T[]> entry = builder.apply(node);
        T[] subData = entry.getValue();
        T data = entry.getKey();

        return new Tree<>(data, unfoldForest(builder, subData));
    }

    public static <T> Tree<T>[] unfoldForest(
            Function<T, Map.Entry<T, T[]>> builder,
            T[] nodes
    ) {
        //noinspection unchecked
        return Arrays.stream(nodes).map(node -> unfold(builder, node)).toArray(Tree[]::new);
    }

    @Contract(" -> new")
    public static <T> @NotNull Traverser<Tree<T>> traverser() {
        return Traverser.forTree(tree -> Arrays.asList(tree.children));
    }
}
