package com.convertlab.foundation.gdmmeta.configure;

import com.convertlab.foundation.library.jdbc.datasource.DynamicDataSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.util.Map;

@Configuration
@Slf4j
public class DataSourceConfigure {

    @Bean(name = "impalaDataSource")
    public DataSource impalaDataSource(@Qualifier("dynamicDataSource") DataSource dynamicDataSource) {
        return getNamedDatasource(dynamicDataSource, "olap::impala");
    }

    public DataSource getNamedDatasource(DataSource dynamicDataSource, String name) {

        DynamicDataSource dataSource = (DynamicDataSource) dynamicDataSource;
        Map<Object, DataSource> resolvedDataSources = dataSource.getResolvedDataSources();
        log.info("resolvedDataSources: {}", resolvedDataSources);

        return resolvedDataSources.get(name);
    }

}
