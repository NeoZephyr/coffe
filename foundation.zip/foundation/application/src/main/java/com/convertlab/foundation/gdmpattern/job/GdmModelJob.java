package com.convertlab.foundation.gdmpattern.job;

import com.convertlab.data.job.core.constants.DataJobConstants;
import com.convertlab.data.job.core.context.ClJobContext;
import com.convertlab.data.job.core.handler.annotation.ClJob;
import com.convertlab.data.job.core.util.data.BizJobClient;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.gdmdata.mapper.GdmDataMapper;
import com.convertlab.foundation.gdmpattern.dto.DeleteGdmEntityDataParams;
import com.convertlab.foundation.gdmpattern.service.GdmModelService;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.constant.DbStorageType;
import com.convertlab.foundation.library.exception.business.BackendException;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.library.utils.Try;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto.CustomerDomains.ATTRIBUTE;
import static com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto.CustomerDomains.CUSTOMER;

@Slf4j
@RequiredArgsConstructor
public class GdmModelJob {

    private static final String LOG_PREFIX = "<foundation> <GdmModelJob> ";

    private final GdmDataMapper gdmDataMapper;
    private final BizJobClient bizJobClient;
    private final GdmModelService gdmModelService;

    public static final String JOB_HANDLER_DROP_GDM_ENTITY_DEF = "dropGdmEntityDef";
    public static final String JOB_HANDLER_DROP_GDM_MODEL_DEF = "dropGdmModelDef";
    public static final String JOB_HANDLER_DROP_GDM_ENTITY_DATA = "dropGdmEntityData";
    public static final String JOB_HANDLER_DROP_GDM_ENTITY_FIELDS = "dropGdmEntityFieldsDef";
    public static final String SPARK_JOB_GDM_MODEL_DELETE = "spark-job-gdm-model-delete";
    public static final String SPARK_JOB_JAR_NAME = "spark-jobs";
    public static final int DELETE_BATCH = 2000;

    // 根据storage类型从mysql或者启动spark任务删除表数据，依赖于db type
    @ClJob(value = JOB_HANDLER_DROP_GDM_ENTITY_DATA)
    public void dropGdmEntityData() {
        log.info("{} dropGdmEntityData handler start.", LOG_PREFIX);
        ClJobContext clJobContext = ClJobContext.getClJobContext();
        try (TemporaryTenantContext ignored = new TemporaryTenantContext(clJobContext.getTenantId())) {
            try {
                log.info("dropGdmEntityData tenantId:{}, batchNo: {}, jobNo: {}, jobParam:{}", clJobContext.getTenantId(), clJobContext.getBatchNo(), clJobContext.getJobNo(), clJobContext.getJobParam());
                DeleteGdmEntityDataParams jobParams = JsonUtils.instance().json2Obj(clJobContext.getJobParam(), DeleteGdmEntityDataParams.class);
                if (jobParams == null) {
                    throw new BackendException(CommonErrors.GENERAL_ERROR, "Can not parse job param");
                }

                String entityName = jobParams.getGdmEntityName();
                List<String> dbTypes = jobParams.getDbTypes();
                if (StringUtils.isEmpty(entityName) || dbTypes == null || dbTypes.isEmpty()) {
                    throw new BackendException(CommonErrors.GENERAL_ERROR, "Invalid job param");
                }

                if (dbTypes.contains(DbStorageType.MYSQL.getStorageName())) {
                    // 从OLTP数据源中删除数据
                    if (DeleteGdmEntityDataParams.DELETE_TYPE_ENTITY.equals(jobParams.getDeleteType())) {
                        if (StringUtils.isEmpty(jobParams.getPrimaryKeyField())) {
                            throw new BackendException(CommonErrors.GENERAL_ERROR, "Invalid primary key field in jobParams");
                        }
                        batchDeleteById(entityName, jobParams.getPrimaryKeyField(), DELETE_BATCH);
                    } else if (DeleteGdmEntityDataParams.DELETE_TYPE_FIELDS.equals(jobParams.getDeleteType())) {
                        List<String> fieldsToBeRemoved = jobParams.getFieldsToBeRemoved();
                        if (!CollectionUtils.isEmpty(fieldsToBeRemoved)) {
                            batchUnsetFields(entityName, fieldsToBeRemoved);
                        }
                    }
                }
                if (dbTypes.contains(DbStorageType.HBASE.getStorageName()) || dbTypes.contains(DbStorageType.KUDU.getStorageName()) || dbTypes.contains(DbStorageType.PARQUET.getStorageName())) {
                    log.info("submit spark job to delete data for entity {}", entityName);
                    bizJobClient.submitSparkJob(SPARK_JOB_GDM_MODEL_DELETE, SPARK_JOB_JAR_NAME, JsonUtils.instance().convertToMap(jobParams));
                } else {
                    bizJobClient.updateBizJobStatus(clJobContext, DataJobConstants.STATUS_FINISHED);
                }
            } catch (Exception e) {
                log.error("{} dropGdmEntityData handler failed. clJobContext: {}", LOG_PREFIX, JsonUtils.instanceOfDto().obj2Json(clJobContext), e);
                bizJobClient.updateBizJobStatus(clJobContext, DataJobConstants.STATUS_FAIL);
            }
        }
    }

    // 删除gdm entity定义
    @ClJob(value = JOB_HANDLER_DROP_GDM_ENTITY_DEF)
    public void dropGdmEntityDef() {
        log.info("{} dropGdmEntityDef handle start.", LOG_PREFIX);
        ClJobContext clJobContext = ClJobContext.getClJobContext();
        log.info("dropGdmEntityDef tenantId: {}, batchNo: {}, jobNo: {}, jobParam:{}", clJobContext.getTenantId(), clJobContext.getBatchNo(), clJobContext.getJobNo(), clJobContext.getJobParam());
        try (TemporaryTenantContext ignored = new TemporaryTenantContext(clJobContext.getTenantId())) {
            try {
                Map<String, Object> jobParams = JsonUtils.instance().json2Obj(clJobContext.getJobParam(), Map.class);
                String entityName = (String) jobParams.get("entityName");
                gdmModelService.dropGdmEntityDef(entityName);
                bizJobClient.updateBizJobStatus(clJobContext, DataJobConstants.STATUS_FINISHED);
            } catch (Exception e) {
                log.error("{} dropGdmEntityDef handle failed. clJobContext: {}", LOG_PREFIX, JsonUtils.instanceOfDto().obj2Json(clJobContext), e);
                bizJobClient.updateBizJobStatus(clJobContext, DataJobConstants.STATUS_FAIL);
            }
        }
    }

    // 删除gdm model的定义
    @ClJob(value = JOB_HANDLER_DROP_GDM_MODEL_DEF)
    public void dropGdmModelDef() {
        log.info("{} dropGdmModelDef handle start.", LOG_PREFIX);
        ClJobContext clJobContext = ClJobContext.getClJobContext();
        log.info("dropGdmModelDef tenantId: {}, batchNo: {}, jobNo: {}, jobParam:{}", clJobContext.getTenantId(), clJobContext.getBatchNo(), clJobContext.getJobNo(), clJobContext.getJobParam());
        try (TemporaryTenantContext ignored = new TemporaryTenantContext(clJobContext.getTenantId())) {
            try {
                Map<String, Object> jobParams = JsonUtils.instance().json2Obj(clJobContext.getJobParam(), Map.class);
                String modelName = (String) jobParams.get("modelName");
                GdmModelDto model = Try.ignoreException(() -> gdmModelService.findByName(modelName), null);
                if(model == null) {
                    log.debug("model - {} already been dropped", modelName);
                    return;
                }
                gdmModelService.dropGdmModelDef(modelName);
                bizJobClient.updateBizJobStatus(clJobContext, DataJobConstants.STATUS_FINISHED);
            } catch (Exception e) {
                log.error("{} dropGdmModelDef handle failed. clJobContext: {}", LOG_PREFIX, JsonUtils.instanceOfDto().obj2Json(clJobContext), e);
                bizJobClient.updateBizJobStatus(clJobContext, DataJobConstants.STATUS_FAIL);
            }
        }
    }

    // 删除gdm entity中字段
    @ClJob(value = JOB_HANDLER_DROP_GDM_ENTITY_FIELDS)
    public void dropGdmEntityFieldsDef() {
        log.info("{} dropGdmEntityFieldsDef handle start.", LOG_PREFIX);
        ClJobContext clJobContext = ClJobContext.getClJobContext();
        log.info("dropGdmEntityFieldsDef tenantId: {}, batchNo: {}, jobNo: {}, jobParam:{}", clJobContext.getTenantId(), clJobContext.getBatchNo(), clJobContext.getJobNo(), clJobContext.getJobParam());

        try (TemporaryTenantContext ignored = new TemporaryTenantContext(clJobContext.getTenantId())) {
            try {
                Map<String, Object> jobParams = JsonUtils.instance().json2Obj(clJobContext.getJobParam(), Map.class);
                String entityName = (String) jobParams.get("entityName");
                List<String> fieldsToBeRemoved = (List<String>) jobParams.get("fieldsToBeRemoved");

                boolean updated = gdmModelService.dropGdmEntityFields(entityName, fieldsToBeRemoved);
                String jobStatus = updated ? DataJobConstants.STATUS_FINISHED : DataJobConstants.STATUS_FAIL;
                bizJobClient.updateBizJobStatus(clJobContext, jobStatus);
                log.info("dropGdmEntityFieldsDef : gdm-entity/{}:{}", entityName);
            } catch (Exception e) {
                log.error("{} dropGdmEntityFieldsDef handle failed. clJobContext: {}", LOG_PREFIX, JsonUtils.instanceOfDto().obj2Json(clJobContext), e);
                bizJobClient.updateBizJobStatus(clJobContext, DataJobConstants.STATUS_FAIL);
            }
        }
    }

    private void batchDeleteById(String entityName, String pkColumn, int batchSize) {
        log.info("start to delete from {}", entityName);
        long l = System.currentTimeMillis();
        Long totalCount = gdmDataMapper.statsByEntity(entityName);
        if (totalCount != null) {
            for (long count = totalCount; count > 0; count -= batchSize) {
                List<Object> ids = gdmDataMapper.selectPksWithLimit(entityName, pkColumn, batchSize);
                if (ids == null || ids.isEmpty()) {
                    break;
                }
                gdmDataMapper.deleteByIdsWithMaxwellIgnore(entityName, pkColumn, ids);
            }
        }
        log.info("delete from {} done, took {}ms", entityName, System.currentTimeMillis() - l);
    }

    private void batchUnsetFields(String entityName, List<String> fields) {
        String tableName = CUSTOMER.equalsIgnoreCase(entityName) ? ATTRIBUTE : entityName;
        log.info("start to unset entity {}, fields:{}", entityName, StringUtils.join(fields, ","));
        long l = System.currentTimeMillis();
        if (!CollectionUtils.isEmpty(fields)) {
            Map<String, Object> fieldsMap = new HashMap<>();
            fields.forEach(field -> {
                fieldsMap.put(field, null);
            });
            List<Map<String, Long>> batches = toUnsetBatch(tableName, DELETE_BATCH);
            batches.forEach(batch -> {
                gdmDataMapper.updateByIdIntervalWithMaxwellIgnore(tableName, fieldsMap, batch.get("fromId"), batch.get("toId"));
            });
        }
        log.info("unset entity {}, fields:{} done, took {}ms", entityName, StringUtils.join(fields, ","), System.currentTimeMillis() - l);
    }

    private List<Map<String, Long>> toUnsetBatch(String entityName, int batchSize) {
        long fromId = 0L;
        List<Map<String, Long>> batches = new ArrayList<>();
        while (true) {
            Long toId = gdmDataMapper.getToId(entityName, fromId, batchSize);
            if (toId == null) break;
            Map<String, Long> batch = new HashMap<>();
            batch.put("fromId", fromId + 1);
            batch.put("toId", toId);
            batches.add(batch);
            fromId = toId;
        }
        return batches;
    }
}
