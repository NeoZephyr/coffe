package com.convertlab.foundation.datapermission.controller.apiv2;

import lombok.Data;

import java.util.List;

@Data
public class Apiv2ResourceShareResponseDto {
    String resourceType;
    String resourceCode;
}
