package com.convertlab.foundation.misc.configure;

import com.convertlab.foundation.gdmmeta.service.impl.MetaEventPublisher;
import com.convertlab.foundation.library.business.property.EventBrokerProperties;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.jdbc.property.ExtraDataSourceProperties;
import com.convertlab.foundation.library.redis.core.TenantIsolationRedisTemplate;
import com.convertlab.foundation.misc.service.AnotherService;
import com.convertlab.foundation.misc.service.DiaryTemplateService;
import com.convertlab.foundation.misc.service.DynamicJdbcTemplate;
import com.convertlab.foundation.misc.service.SomeService;
import com.convertlab.foundation.misc.service.impl.DiaryTemplateServiceImpl;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.ApplicationEventMulticaster;
import org.springframework.context.event.SimpleApplicationEventMulticaster;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.support.TaskUtils;

import javax.annotation.Nonnull;
import javax.sql.DataSource;

@Configuration("MiscConfiguration")
@Qualifier("MiscConfiguration")
public class AutoConfig {
    @Nonnull
    @Bean
    public DynamicJdbcTemplate dynamicJdbcTemplate(@Nonnull ExtraDataSourceProperties properties) {
        return new DynamicJdbcTemplate(properties);
    }

    @Bean("homeDataSourceProperties")
    @ConfigurationProperties(prefix = "convertlab.datasource.oltp.datasources.main")
    public DataSourceProperties dataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean("homeDataSource")
    @ConfigurationProperties(prefix = "convertlab.datasource.oltp.datasources.main")
    public HikariDataSource dataSource(@Qualifier("homeDataSourceProperties") DataSourceProperties properties) {
        return properties.initializeDataSourceBuilder().type(HikariDataSource.class)
                .build();
    }


//    @ConfigurationProperties(prefix = "convertlab.datasource.oltp.datasources.main")
//    public DataSource dataSource( ) {
//        return DataSourceBuilder.create().build();
//    }
    @Nonnull
    @Bean("homeJdbcTemplate")
    public JdbcTemplate jdbcTemplate(@Qualifier("homeDataSource") @Nonnull DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean
    public SomeService someService(ApplicationEventPublisher applicationEventPublisher,
                                   EventBrokerProperties eventBrokerProperties,
                                   TenantIsolationRedisTemplate redisTemplate) {
        return new SomeService(applicationEventPublisher, eventBrokerProperties, redisTemplate);
    }


    @Bean
    public AnotherService anotherService() {
        return new AnotherService();
    }

    @Bean
    public DiaryTemplateService diaryTemplateService(GsMetaClient gsMetaClient) {
        return new DiaryTemplateServiceImpl(gsMetaClient);
    }

    @Bean
    public ApplicationEventMulticaster applicationEventMulticaster() {
        // todo: Will the new Error Handler will break Spring native functions?
        SimpleApplicationEventMulticaster multicaster = new SimpleApplicationEventMulticaster();
        multicaster.setErrorHandler(TaskUtils.LOG_AND_SUPPRESS_ERROR_HANDLER);
        return multicaster;
    }
}
