package com.convertlab.foundation.datapermission.model;

import com.convertlab.foundation.user.entity.Dept;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class HighSeaSettingResponseDto {

    public static final String PUBLIC_TYPE = "ALL";
    public static final String PRIVATE_TYPE = "PRIVATE";

    private String type = PRIVATE_TYPE;
    List<Dept> depts;


}
