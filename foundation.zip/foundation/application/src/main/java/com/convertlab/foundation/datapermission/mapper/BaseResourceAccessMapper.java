package com.convertlab.foundation.datapermission.mapper;

import com.convertlab.foundation.datapermission.entity.BaseResourceAccessEntity;
import com.convertlab.foundation.datapermission.util.GrantedPermissionTypeHandler;
import com.convertlab.foundation.datapermission.util.GrantedSubjectTypeHandler;
import com.convertlab.foundation.library.datapermission.GrantedSubjectType;
import org.apache.ibatis.annotations.*;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Map;

public interface BaseResourceAccessMapper {

    @Insert("INSERT INTO ${tableName} (uuid, resource_code, resource_type, granted_subject_type, granted_subject_code, granted_permission, granted_reason, additional_info, date_created, last_updated) " +
            "VALUES (#{entity.uuid}, #{entity.resourceCode}, #{entity.resourceType}, #{entity.grantedSubjectType.value}, #{entity.grantedSubjectCode}, #{entity.grantedPermission.value}, #{entity.grantedReason}, #{entity.additionalInfo}, #{entity.dateCreated}, #{entity.lastUpdated})")
    @Options(useGeneratedKeys = true, keyProperty = "entity.uuid")
    int insert(@Param("tableName") String tableName, @Param("entity") BaseResourceAccessEntity entity);

    @Select("SELECT * FROM ${tableName} WHERE uuid = #{uuid}")
    @Results(id = "getByUuid", value = {
            @Result(property = "grantedSubjectType", column = "granted_subject_type", typeHandler = GrantedSubjectTypeHandler.class),
            @Result(property = "grantedPermission", column = "granted_permission", typeHandler = GrantedPermissionTypeHandler.class)
    })
    BaseResourceAccessEntity getByUuid(@Param("tableName") String tableName, @Param("uuid") String uuid);

    @Select("SELECT * FROM ${tableName} WHERE resource_type = #{resourceType} AND resource_code = #{resourceCode} AND granted_subject_type = #{grantedSubjectType.value} AND granted_subject_code = #{grantedSubjectCode} AND granted_reason = #{grantedReason}")
    @Results(id = "getByKey", value = {
            @Result(property = "grantedSubjectType", column = "granted_subject_type", typeHandler = GrantedSubjectTypeHandler.class),
            @Result(property = "grantedPermission", column = "granted_permission", typeHandler = GrantedPermissionTypeHandler.class)
    })
    BaseResourceAccessEntity getByKey(@Param("tableName") String tableName, @Param("resourceType") String resourceType, @Param("resourceCode") String resourceCode, @Param("grantedSubjectType") GrantedSubjectType grantedSubjectType, @Param("grantedSubjectCode") String grantedSubjectCode, @Param("grantedReason") String grantedReason);

    @Update("UPDATE ${tableName} SET  resource_code = #{entity.resourceCode}, resource_type = #{entity.resourceType}, granted_subject_type = #{entity.grantedSubjectType.value}, granted_subject_code = #{entity.grantedSubjectCode}, granted_permission = #{entity.grantedPermission.value}, granted_reason = #{entity.grantedReason}, additional_info = #{entity.additionalInfo} WHERE uuid = #{entity.uuid}")
    int update(@Param("tableName") String tableName, @Param("entity") BaseResourceAccessEntity entity);

    @Delete("DELETE FROM ${tableName} WHERE uuid = #{uuid}")
    int delete(@Param("tableName") String tableName, @Param("uuid") String uuid);

    //delete entity by resource type and resource code
    @Delete("DELETE FROM ${tableName} WHERE resource_type = #{resourceType} AND resource_code = #{resourceCode}")
    int deleteByResourceTypeAndResourceCode(@Param("tableName") String tableName, @Param("resourceType") String resourceType, @Param("resourceCode") String resourceCode);


    //delete entity by resource type and resource code and granted subject type and granted subject code
    @Delete("DELETE FROM ${tableName} WHERE resource_type = #{resourceType} AND resource_code = #{resourceCode} AND granted_subject_type = #{grantedSubjectType.value} AND granted_subject_code = #{grantedSubjectCode}")
    int deleteByResourceTypeAndResourceCodeAndGrantedSubjectTypeAndGrantedSubjectCode(@Param("tableName") String tableName, @Param("resourceType") String resourceType, @Param("resourceCode") String resourceCode, @Param("grantedSubjectType") GrantedSubjectType grantedSubjectType, @Param("grantedSubjectCode") String grantedSubjectCode);


    //delete entity by granted subject type and granted subject code
    @Delete("DELETE FROM ${tableName} WHERE granted_subject_type = #{grantedSubjectType} AND granted_subject_code = #{grantedSubjectCode}")
    int deleteByGrantedSubjectTypeAndGrantedSubjectCode(@Param("tableName") String tableName, @Param("grantedSubjectType") String grantedSubjectType, @Param("grantedSubjectCode") String grantedSubjectCode);


    //query entity by resource type and resource code
    @Select("SELECT * FROM ${tableName} WHERE resource_type = #{resourceType} AND resource_code = #{resourceCode}")
    @Results(id = "listByResourceTypeAndResourceCode", value = {
            @Result(property = "grantedSubjectType", column = "granted_subject_type", typeHandler = GrantedSubjectTypeHandler.class),
            @Result(property = "grantedPermission", column = "granted_permission", typeHandler = GrantedPermissionTypeHandler.class)
    })
    List<BaseResourceAccessEntity> listByResourceTypeAndResourceCode(@Param("tableName") String tableName, @Param("resourceType") String resourceType, @Param("resourceCode") String resourceCode);

    //query entity by resource type and resource code list
    @Select("<script>SELECT * FROM ${tableName} WHERE resource_type = #{resourceType} AND resource_code IN <foreach item='item' index='index' collection='resourceCodeList' open='(' separator=',' close=')'>#{item}</foreach></script>")
    @Results(id = "listByResourceTypeAndResourceCodeList", value = {
            @Result(property = "grantedSubjectType", column = "granted_subject_type", typeHandler = GrantedSubjectTypeHandler.class),
            @Result(property = "grantedPermission", column = "granted_permission", typeHandler = GrantedPermissionTypeHandler.class)
    })
    List<BaseResourceAccessEntity> listByResourceTypeAndResourceCodeList(@Param("tableName") String tableName, @Param("resourceType") String resourceType, @Param("resourceCodeList") List<String> resourceCodeList);

    //query entity by resource type and resource code and grantedSubjectType and grantedSubjectCode
    @Select("SELECT * FROM ${tableName} WHERE resource_type = #{resourceType} AND resource_code = #{resourceCode} AND granted_subject_type = #{grantedSubjectType.value} AND granted_subject_code = #{grantedSubjectCode}")
    @Results(id = "listByResourceTypeAndResourceCodeAndGrantedSubjectTypeAndGrantedSubjectCode", value = {
            @Result(property = "grantedSubjectType", column = "granted_subject_type", typeHandler = GrantedSubjectTypeHandler.class),
            @Result(property = "grantedPermission", column = "granted_permission", typeHandler = GrantedPermissionTypeHandler.class)
    })
    List<BaseResourceAccessEntity> listByResourceTypeAndResourceCodeAndGrantedSubjectTypeAndGrantedSubjectCode(@Param("tableName") String tableName, @Param("resourceType") String resourceType, @Param("resourceCode") String resourceCode, @Param("grantedSubjectType") GrantedSubjectType grantedSubjectType, @Param("grantedSubjectCode") String grantedSubjectCode);

    //query entity by granted subject type and granted subject code
    @Select("SELECT * FROM ${tableName} WHERE granted_subject_type = #{grantedSubjectType} AND granted_subject_code = #{grantedSubjectCode}")
    @Results(id = "listByGrantedSubjectTypeAndGrantedSubjectCode", value = {
            @Result(property = "grantedSubjectType", column = "granted_subject_type", typeHandler = GrantedSubjectTypeHandler.class),
            @Result(property = "grantedPermission", column = "granted_permission", typeHandler = GrantedPermissionTypeHandler.class)
    })
   List<BaseResourceAccessEntity> listByGrantedSubjectTypeAndGrantedSubjectCode(@Param("tableName") String tableName, @Param("grantedSubjectType") String grantedSubjectType, @Param("grantedSubjectCode") String grantedSubjectCode);

    //query entity by resourceType, grantedSubjectType and grantedSubjectCodeList
    @Select("<script>SELECT * FROM ${tableName} WHERE resource_type = #{resourceType} AND granted_subject_type = #{grantedSubjectType.value} AND granted_subject_code IN <foreach item='item' index='index' collection='grantedSubjectCodeList' open='(' separator=',' close=')'>#{item}</foreach></script>")
    @Results(id = "listByResourceTypeAndGrantedSubjectTypeAndGrantedSubjectCodeList", value = {
            @Result(property = "grantedSubjectType", column = "granted_subject_type", typeHandler = GrantedSubjectTypeHandler.class),
            @Result(property = "grantedPermission", column = "granted_permission", typeHandler = GrantedPermissionTypeHandler.class)
    })
    List<BaseResourceAccessEntity> listByResourceTypeAndGrantedSubjectTypeAndGrantedSubjectCodeList(@Param("tableName") String tableName, @Param("resourceType") String resourceType, @Param("grantedSubjectType") GrantedSubjectType grantedSubjectType, @Param("grantedSubjectCodeList") List<String> grantedSubjectCodeList);

    //query entity by resourceType and map of grantedSubjectType and grantedSubjectCodeList
    @Select("<script>"
            + "SELECT * FROM ${tableName} "
            + "WHERE resource_type = #{resourceType} "
            + "AND ("
            + "<foreach item='key' index='key' collection='grantedSubjectTypeListMap.keys' separator=' OR '>"
            + "(granted_subject_type = #{key.value} AND granted_subject_code IN "
            + "<foreach item='item' index='index' collection='grantedSubjectTypeListMap[key]' open='(' separator=',' close=')'>"
            + "#{item}"
            + "</foreach>)"
            + "</foreach>"
            + ")</script>")
            @Results(id = "listByResourceTypeAndGrantedSubjectTypeListMap", value = {
            @Result(property = "grantedSubjectType", column = "granted_subject_type", typeHandler = GrantedSubjectTypeHandler.class),
            @Result(property = "grantedPermission", column = "granted_permission", typeHandler = GrantedPermissionTypeHandler.class)
    })
    List<BaseResourceAccessEntity> listByResourceTypeAndGrantedSubjectTypeListMap(@Param("tableName") String tableName, @Param("resourceType") String resourceType, @Param("grantedSubjectTypeListMap") Map<GrantedSubjectType, List<String>> grantedSubjectTypeListMap);



}