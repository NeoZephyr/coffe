package com.convertlab.foundation.gdmmeta.utils;

import com.convertlab.foundation.gdmmeta.service.impl.loader.META_FILES;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.gdmmeta.model.entity.GdmEntityRequest;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationshipRequest;
import com.convertlab.foundation.library.gdmmeta.model.table.GdmColumn;
import com.convertlab.foundation.library.gdmmeta.model.table.GdmTableRequest;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.google.common.collect.ImmutableList;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Slf4j
public class GdmMetaDefinedFileUtils {

    private GdmMetaDefinedFileUtils() {}

    public static void writeToPredefinedFile(String metaContent, String fileName) {
        final String defaultFilePath = "/tmp/gdmmeta/";
        final String localFilePath = "library/meta/gdm-meta-internal/src/main/resources/meta/init/predefined/";
        writeStringToFile(metaContent, fileName, defaultFilePath, localFilePath);
    }

    private static void writeStringToFile(String metaContent, String fileName, String defaultFilePath, String localFilePath) {
        File metaDir = new File(defaultFilePath);
        boolean exists = metaDir.exists() && metaDir.isDirectory();
        File file = exists ? new File(defaultFilePath + fileName) : new File(localFilePath + fileName);
        try {
            log.info("write meta to file: {}", file.getAbsolutePath());
            FileUtils.writeStringToFile(file, metaContent, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    public static void writeToSnapshotFile(String metaContent, String fileName) {
        final String defaultFilePath = "/tmp/gdmmeta/";
        final String localFilePath = "library/meta/gdm-meta-internal/src/main/resources";
        writeStringToFile(metaContent, fileName, defaultFilePath, localFilePath);
    }

    public static void saveEntityRequestToFile(List<GdmEntityRequest> requestList, String fileName) {
        //对entity列表，按照entityName排序，方便文件比对
        requestList.sort(Comparator.comparing(GdmEntityRequest::getEntityName));
        for(GdmEntityRequest request: requestList) {
            //对单个entity的所有fields按照fieldName排序，方便文件比对
            request.getFields().sort(Comparator.comparing(GdmField::getFieldName));
        }
        String s = JsonUtils.instance().obj2Json(requestList, true);
        writeToSnapshotFile(s, fileName);
    }


    public static void saveTableRequestToFile(List<GdmTableRequest> requestList, String fileName) {
        //对table列表，按照tableName排序，方便文件比对
        requestList.sort(Comparator.comparing(GdmTableRequest::getTableName));
        for(GdmTableRequest request: requestList) {
            //对单个table的所有column按照columnName排序，方便文件比对
            request.getColumns().sort(Comparator.comparing(GdmColumn::columnName));
        }
        String s = JsonUtils.instance().obj2Json(requestList, true);
        writeToSnapshotFile(s, fileName);
    }

    public static void saveSnapshotGdmMetaRelationships(List<GdmRelationshipRequest> requestList, String fileName) {

        Comparator<GdmRelationshipRequest> byFk =
                Comparator.comparing(GdmRelationshipRequest::getForeignKeyOwningSide)
                        .thenComparing(GdmRelationshipRequest::getMappedBy);
        requestList.sort(byFk);
        String metaContent = JsonUtils.instance().obj2Json(requestList, true);
        writeToSnapshotFile(metaContent, fileName);
    }

    public static List<GdmEntityRequest> loadSystemEntityRequests() {

        List<META_FILES> files = ImmutableList.of(
                META_FILES.SYSTEM_CUSTOMER_BIZ_EVENT_ENTITIES_SNAPSHOT_PATH,
                META_FILES.SYSTEM_PROFILE_BIZ_EVENT_ENTITIES_SNAPSHOT_PATH,
                META_FILES.SYSTEM_MA_BIZ_EVENT_ENTITIES_SNAPSHOT_PATH,
                META_FILES.SYSTEM_MA_PROTO_ENTITIES_SNAPSHOT_PATH,
                META_FILES.SYSTEM_ADHOC_ENTITIES_SNAPSHOT_PATH
        );

        List<GdmEntityRequest> result = new ArrayList<>();
        for (META_FILES file : files) {
            result.addAll(file.loadAsList(GdmEntityRequest.class));
        }

        return result;
    }
}
