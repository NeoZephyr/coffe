package com.convertlab.foundation.datapermission.service;

import com.convertlab.foundation.datapermission.client.SparkTriggerFeignClient;
import com.convertlab.foundation.datapermission.entity.DpDatapermissionRule;
import com.convertlab.foundation.datapermission.mapper.DatapermissionRuleMapper;
import com.convertlab.foundation.datapermission.model.DpDatapermissionRuleDto;
import com.convertlab.foundation.datapermission.util.JacksonUtils;
import com.convertlab.foundation.library.business.quota.QuotaClient;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.converter.LocalDateTimeToInstantConverter;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.jdbc.core.OLTPJdbcTemplate;
import com.convertlab.foundation.queryengine.service.GdqlParseService;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.convert.support.DefaultConversionService;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@Transactional
@DataSourceLookup("main")
public class RuleService {

    private static final int DEFAULT_RULE_LIMIT = 50;
    private static final int DEFAULT_RULE_CONDITION_LIMIT = 8;

    private static final String FEATURE_DATAPERMISSION_RULE_SIZE = "rule_size";
    public static final String SPARK_JOB_DATA_PERMISSION = "spark-job-datapermission";
    public static final String SPARK_JOB_DATA_PERMISSION_SUCCESS = "success";

    private final OLTPJdbcTemplate jdbcTemplate;
    private final QuotaClient quotaClient;

    private final DatapermissionRuleMapper datapermissionRuleMapper;

    private DefaultConversionService conversionService;

    private ObjectMapper objectMapper;



    public RuleService(OLTPJdbcTemplate jdbcTemplate,
                       QuotaClient quotaClient,
                       DatapermissionRuleMapper datapermissionRuleMapper
                       ) {
        this.jdbcTemplate = jdbcTemplate;
        this.quotaClient = quotaClient;
        this.datapermissionRuleMapper = datapermissionRuleMapper;
        conversionService = new DefaultConversionService();
        conversionService.addConverter(new LocalDateTimeToInstantConverter());
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    }


    public DpDatapermissionRuleDto saveDatapermissionRule(DpDatapermissionRuleDto dpDatapermissionRuleDto) {
        if (Boolean.TRUE.equals(isRuleQuotaExceed(dpDatapermissionRuleDto.getProfileName()))) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_005_000011", "规则数量超过限制", new String[]{});
        }

//        先由前端控制
//        if (Boolean.TRUE.equals(isRuleConditionQuotaExceed(dpDatapermissionRuleDto.getFilter()))) {
//            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_005_000012", "规则条件数量超过限制", new String[]{});
//        }

        dpDatapermissionRuleDto.setStatus(DpDatapermissionRule.STATUS_PROCESSING);
        DpDatapermissionRule dpDatapermissionRule = convertToEntity(dpDatapermissionRuleDto);
        datapermissionRuleMapper.insert(dpDatapermissionRule);
        dpDatapermissionRuleDto = convertToDto(dpDatapermissionRule);
        return dpDatapermissionRuleDto;
    }

    public Long getTotal(String profileName){
        String sql = "select count(*) as count from dp_datapermission_rule";
        if (StringUtils.isNotBlank(profileName)) {
            sql += " where resource_type='" + profileName + "'";
        }
        Map<String, Object> result = jdbcTemplate.queryForMap(sql);
        Long count = 0L;
        if (result!=null){
            count = (Long) result.getOrDefault("count", 0L);
        }
        return count;
    }

    @Transactional(readOnly = true)
    public Boolean isRuleQuotaExceed(String profileName) {
        Long limit = quotaClient.queryQuotaByFeature(FEATURE_DATAPERMISSION_RULE_SIZE);
        limit = (null == limit || limit.longValue() == 0)?DEFAULT_RULE_LIMIT:limit;
        Long total = getTotal(profileName);

        log.info("{} rule count: {}, limit: {}", profileName, total, limit);

        return total >= limit;
    }

    @Transactional(readOnly = true)
    public Boolean isRuleConditionQuotaExceed(Map<String, Object> filter) {
        //todo 处理filterv2/filterv4中的condition条件,暂时不处理

        return false;
    }

    public DpDatapermissionRuleDto updateDatapermissionRule(Long id, DpDatapermissionRuleDto dpDatapermissionRuleDto) {
        Boolean needTrigger = true;

        DpDatapermissionRule dpDatapermissionRule = datapermissionRuleMapper.selectById(id);
        if (Objects.isNull(dpDatapermissionRule)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_005_000013", "规则不存在", new String[]{});
        }
        if (Objects.equals(dpDatapermissionRule.getStatus(), DpDatapermissionRule.STATUS_PROCESSING)){
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_005_000014", "规则正在处理中", new String[]{});
        }

        dpDatapermissionRuleDto.setId(id);
        if (dpDatapermissionRuleDto.getFilter()!=null
                && !dpDatapermissionRuleDto.getFilter().isEmpty()) {
            dpDatapermissionRuleDto.setStatus(DpDatapermissionRule.STATUS_PROCESSING);
        }

        datapermissionRuleMapper.updateById(convertToEntity(dpDatapermissionRuleDto, dpDatapermissionRule));
        dpDatapermissionRuleDto = convertToDto(dpDatapermissionRule);
        return dpDatapermissionRuleDto;
    }

    public DpDatapermissionRuleDto deleteDatapermissionRule(Long id) {
        DpDatapermissionRule dpDatapermissionRule = datapermissionRuleMapper.selectById(id);
        if (Objects.isNull(dpDatapermissionRule)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_005_000013", "规则不存在", new String[]{});
        }
//        if (Objects.equals(dpDatapermissionRule.getStatus(), DpDatapermissionRule.STATUS_PROCESSING)){
//            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_005_000014", "规则正在处理中", new String[]{});
//        }

        datapermissionRuleMapper.deleteById(dpDatapermissionRule);

        return convertToDto(dpDatapermissionRule);
    }

    @Transactional(readOnly = true)
    public List<DpDatapermissionRuleDto> listDatapermissionRule(String profileName, Integer pageNum, Integer pageSize) {
        String sql = "select * from dp_datapermission_rule ";
        if (StringUtils.isNotBlank(profileName)) {
            sql += " where resource_type='" + profileName + "'";
        }
        sql += " order by id desc limit ?,?";

        List<DpDatapermissionRule> datapermissionRules = jdbcTemplate.query(
                sql,
                BeanPropertyRowMapper.newInstance(DpDatapermissionRule.class, conversionService),
                (pageNum - 1) * pageSize, pageSize);
        if (Objects.nonNull(datapermissionRules) && !datapermissionRules.isEmpty()){
            return datapermissionRules.stream().map(this::convertToDto).collect(Collectors.toList());
        }else {
            return Collections.emptyList();
        }
    }

    public void updateDpStatus(Long ruleId, String status){
        DpDatapermissionRule dpDatapermissionRule = datapermissionRuleMapper.selectById(ruleId);
        if (Objects.isNull(dpDatapermissionRule)) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_005_000013", "规则不存在", new String[]{});
        }
        dpDatapermissionRule.setStatus(status);
        datapermissionRuleMapper.updateById(dpDatapermissionRule);
    }

    private DpDatapermissionRuleDto convertToDto(DpDatapermissionRule dpDatapermissionRule) {
        DpDatapermissionRuleDto dpDatapermissionRuleDto = new DpDatapermissionRuleDto();
        BeanUtils.copyProperties(dpDatapermissionRule, dpDatapermissionRuleDto);
        if (StringUtils.isNotBlank(dpDatapermissionRule.getFilter())) {
            dpDatapermissionRuleDto.setFilter(JacksonUtils.parseObject(dpDatapermissionRule.getFilter(), Map.class));
        }
        if (StringUtils.isNotBlank(dpDatapermissionRule.getIgnoredBusinessInfo())) {
            dpDatapermissionRuleDto.setIgnoredBusinessInfo(
                    JacksonUtils.parseObject(dpDatapermissionRule.getIgnoredBusinessInfo(), Map.class));
        }
        if (StringUtils.isNotBlank(dpDatapermissionRule.getGrantedSubjectCode())) {
            dpDatapermissionRuleDto.setDeptCodes(Arrays.asList(dpDatapermissionRule.getGrantedSubjectCode().split(",")));
        }
        dpDatapermissionRuleDto.setProfileName(dpDatapermissionRule.getResourceType());
        return dpDatapermissionRuleDto;
    }

    private DpDatapermissionRule convertToEntity(
            DpDatapermissionRuleDto dpDatapermissionRuleDto, DpDatapermissionRule dpDatapermissionRule){
        BeanUtils.copyProperties(dpDatapermissionRuleDto, dpDatapermissionRule);
        if (dpDatapermissionRuleDto.getFilter()!=null
                && !dpDatapermissionRuleDto.getFilter().isEmpty()) {
            dpDatapermissionRule.setFilter(JacksonUtils.toJSONString(dpDatapermissionRuleDto.getFilter()));
        }
        if (dpDatapermissionRuleDto.getIgnoredBusinessInfo()!=null
                && !dpDatapermissionRuleDto.getIgnoredBusinessInfo().isEmpty()) {
            dpDatapermissionRule.setIgnoredBusinessInfo(
                    JacksonUtils.toJSONString(dpDatapermissionRuleDto.getIgnoredBusinessInfo()));
        }
        if (dpDatapermissionRuleDto.getDeptCodes()!=null
                && !dpDatapermissionRuleDto.getDeptCodes().isEmpty()) {
            dpDatapermissionRule.setGrantedSubjectCode(String.join(",", dpDatapermissionRuleDto.getDeptCodes()));
        }
        if (StringUtils.isNotBlank(dpDatapermissionRuleDto.getProfileName())) {
            dpDatapermissionRule.setResourceType(dpDatapermissionRuleDto.getProfileName());
        }
        return dpDatapermissionRule;
    }

    private DpDatapermissionRule convertToEntity(DpDatapermissionRuleDto dpDatapermissionRuleDto) {
        return convertToEntity(dpDatapermissionRuleDto, new DpDatapermissionRule());
    }

}
