package com.convertlab.foundation.gdmdata.mapper;

import com.baomidou.mybatisplus.annotation.InterceptorIgnore;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.foundation.api.gdmdata.GdmData;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

public interface GdmDataMapper extends BaseMapper<GdmData> {
    @Select({"<script>",
            "SELECT ",
            " <foreach item=\"column\" collection=\"selectList\" separator=\",\">",
            "          ${column}",
            "  </foreach>",
            " FROM ${entityName} WHERE ${pkColumn} = #{id}",
            "</script>"})
    @ResultType(Map.class)
    Map<String, Object> selectById(String entityName, List<String> selectList, String pkColumn, Object id);

    @Select({"<script>",
            "SELECT ${pkColumn} FROM ${entityName} limit #{limit}",
            "</script>"})
    List<Object> selectPksWithLimit(String entityName, String pkColumn, int limit);

    @Select({"<script>",
            "SELECT ",
            " <foreach item=\"column\" collection=\"selectList\" separator=\",\">",
            "          ${column}",
            "  </foreach>",
            " FROM ${entityName} WHERE ${pkColumn} in ",
            " <foreach collection=\"ids\" item=\"id\" open=\"(\" separator=\",\" close=\")\">",
            "          #{id}",
            "  </foreach>",
            "</script>"})
    @ResultType(Map.class)
    List<Map<String, Object>> selectByIds(String entityName, List<String> selectList, String pkColumn, @Param("ids") List<Object> ids);

    @Select({"<script>",
            "SELECT ",
            " <foreach item=\"column\" collection=\"selectList\" separator=\",\">",
            "          ${column}",
            "  </foreach>",
            " FROM ${entityName} ",
            " <foreach collection=\"params\" index=\"key\" item=\"value\" open=\"WHERE \" separator=\"AND\">",
            "         ${key} = #{value}",
            "  </foreach>",
            " LIMIT ${offset}, ${limit}",
            "</script>"})
    @ResultType(Map.class)
    List<Map<String, Object>> selectByParams(String entityName, List<String> selectList,  @Param("params") Map<String, Object> params, Integer offset, Integer limit);


    @Insert({"<script>",
            "INSERT INTO ${entityName} ",
            " <foreach item=\"column\" collection=\"columns\"",
            "    open=\"(\" separator=\",\" close=\")\">",
            "          ${column}",
            "  </foreach>",
            " VALUES ",
            " <foreach item=\"value\" collection=\"values\"",
            "    open=\"(\" separator=\",\" close=\")\" nullable=\"true\">",
            "          #{value}",
            "  </foreach>",
            "</script>"})
    int insert(String entityName, @Param("columns") List<String> columns, @Param("values") List<Object> values);

    @Delete("DELETE FROM ${entityName} WHERE ${pkColumn} = #{id}")
    int deleteById(String entityName, String pkColumn, Object id);

    @Select({"<script>",
            "DELETE FROM ${entityName} WHERE ${pkColumn} in ",
            " <foreach collection=\"ids\" item=\"id\" open=\"(\" separator=\",\" close=\")\">",
            "          #{id}",
            "  </foreach>",
            "</script>"})
    int deleteByIds(String entityName, String pkColumn, @Param("ids") List<Object> ids);

    @Select({"<script>",
            "/*+_maxwell_ignore_*/DELETE FROM ${entityName} WHERE ${pkColumn} in ",
            " <foreach collection=\"ids\" item=\"id\" open=\"(\" separator=\",\" close=\")\">",
            "          #{id}",
            "  </foreach>",
            "</script>"})
    void deleteByIdsWithMaxwellIgnore(String entityName, String pkColumn, @Param("ids") List<Object> ids);

    @Update({"<script>",
            "UPDATE ${entityName} SET ",
            " <foreach collection=\"props\" index=\"key\" item=\"value\" separator=\"AND\">",
            "         ${key} = #{value}",
            "  </foreach>",
            " WHERE ${pkColumn} = #{id}",
            "</script>"})
    int updateById(String entityName, String pkColumn, Object id, @Param("props") Map<String, Object> props);

    @Select("SELECT count(1) FROM ${entityName}")
    Long statsByEntity(String entityName);

    @Select({"<script>",
            "SELECT ",
            " <foreach item=\"column\" collection=\"fields\" separator=\",\">",
            "          count(${column}) as ${column}",
            "  </foreach>",
            " FROM ${entityName} ",
            "</script>"})
    Map<String, Long> statsByFields(String entityName, List<String> fields);

    @Select("SELECT max(id) FROM (SELECT id FROM ${entityName} WHERE id > #{fromId} LIMIT #{batchSize} ) x")
    Long getToId(String entityName, Long fromId, Integer batchSize);

    @Update({"<script>",
            "/*+_maxwell_ignore_*/UPDATE ${entityName} SET ",
            " <foreach collection=\"props\" index=\"key\" item=\"value\" separator=\"AND\">",
            "         ${key} = #{value}",
            "  </foreach>",
            " WHERE id between #{fromId} and #{toId}",
            "</script>"})
    @InterceptorIgnore(others = {"autoFill@true"})
    int updateByIdIntervalWithMaxwellIgnore(String entityName, @Param("props") Map<String, Object> props, Long fromId, Long toId);

}
