package com.convertlab.foundation.datapermission.entity;

import lombok.Data;

@Data
public class ResourceEntity {

    private String resourceCode;
    private String resourceType;
    private Long ownerId;
    private String deptCode;

}
