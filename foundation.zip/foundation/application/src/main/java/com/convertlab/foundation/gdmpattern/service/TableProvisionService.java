package com.convertlab.foundation.gdmpattern.service;

import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.gdmmeta.service.GdmTableMetaService;
import com.convertlab.foundation.gdmpattern.service.feign.MigrationServiceFeignClient;
import com.convertlab.foundation.library.constant.DataProcessingMode;
import com.convertlab.foundation.library.constant.LoggingConstants;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.gdmmeta.model.ImmutableGdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.ImmutableGdmField;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.gdm.migration.protocol.Ddl;
import com.convertlab.gdm.migration.protocol.Preconditions;
import com.convertlab.gdm.migration.protocol.Storages;
import com.convertlab.gdm.migration.protocol.v1.CreateGdmEntity;
import com.convertlab.gdm.migration.protocol.v1.GdmEntityChange;
import com.convertlab.gdm.migration.protocol.v1.SchemaChangeLogV1;
import com.google.common.collect.Lists;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Only hive(parquet) table supported for now.
 */
@Slf4j
@RequiredArgsConstructor
public class TableProvisionService {
//    private final String gdmMigrationServerUrl;
    private final MigrationServiceFeignClient migrationServiceFeignClient;
    private final GdmTableMetaService gdmTableMetaService;


    public GdmEntity buildGdmEntity(String entityName, List<GdmModelDto.Field> fields) {
        List<GdmField> gdmFields = fields.stream()
                .map(this::toGdmField)
                .collect(Collectors.toList());
        List<DataProcessingMode> processingModes = Lists.newArrayList(DataProcessingMode.BATCH_AP, DataProcessingMode.KV);
        String tableName = entityName + "_" + TenantContextHolder.getTenantIdExt() + "_" + RandomStringUtils.randomNumeric(3);
        return ImmutableGdmEntity.builder().entityName(entityName)
                .dbTableName(tableName)
                .fields(gdmFields)
                .dataProcessingModes(processingModes)
                .build();
    }

    public boolean provision(GdmEntity entity, List<GdmModelDto.Field> partitionByFields) {
        SchemaChangeLogV1.ChangeSet changeSet = buildCreateEntityChangeSet(entity, partitionByFields);
//        ResultDto createTableResult = migrationServiceFeignClient.postForObject(gdmMigrationServerUrl + "/v1/gdm/migration/run", changeSet, ResultDto.class);
        ResultDto createTableResult = migrationServiceFeignClient.run(changeSet);
        return ResultDto.OK.equals(createTableResult);
    }

    public boolean unProvision(GdmEntity entity) {
        String tableName = entity.getDbTableName();
        SchemaChangeLogV1.ChangeSet changeSet = buildDropTableChangeSet(tableName);
//        ResultDto createTableResult = migrationServiceFeignClient.postForObject(gdmMigrationServerUrl + "/v1/gdm/migration/run", changeSet, ResultDto.class);
        ResultDto dropTableResult = migrationServiceFeignClient.run(changeSet);
        if (!ResultDto.OK.equals(dropTableResult)) {
            throw new IllegalStateException("Failed to unProvision entity " + entity.getEntityName());
        }
        return gdmTableMetaService.deleteGdmTable(tableName) != null;
    }

    private GdmField toGdmField(GdmModelDto.Field field) {
        String fieldName = field.getFieldName();
        String columnName = StringUtils.isBlank(field.getColumnName()) ? fieldName : field.getColumnName();
        return ImmutableGdmField.builder()
                .fieldName(fieldName)
                .fieldType(field.getFieldType())
                .dbColumnName(columnName)
                .olapDbColumnName(field.getOlapDbColumnName())
                .build();
    }

    private SchemaChangeLogV1.ChangeSet buildCreateEntityChangeSet(GdmEntity entity, List<GdmModelDto.Field> partitionByFields) {
        String entityName = entity.getEntityName();
        String tableName = entity.getDbTableName();
        SchemaChangeLogV1.ChangeSet changeSet = new SchemaChangeLogV1.ChangeSet();
        changeSet.setId("create gdm entity " + entityName + "-" + MDC.get(LoggingConstants.REQUEST_ID));
        changeSet.setAuthor("foundation");

        CreateGdmEntity createGdmEntity = new CreateGdmEntity();
        changeSet.setSchemaChange(createGdmEntity);
        createGdmEntity.setTenantId(TenantContextHolder.getTenantIdExt());
        createGdmEntity.setName(entityName);
        createGdmEntity.setTable(tableName);

        Preconditions preconditions = new Preconditions();
        Preconditions.EntityNotExist entityNotExist = new Preconditions.EntityNotExist();
        entityNotExist.setEntityName(entityName);
        preconditions.setPreconditions(Lists.newArrayList(entityNotExist));
        createGdmEntity.setPreconditions(preconditions);

        GdmEntityChange.Fields fields = new GdmEntityChange.Fields();
        createGdmEntity.setFields(fields);
        List<GdmEntityChange.Field> fieldList = entity.getFields().stream()
                .map(this::mapField)
                .collect(Collectors.toList());
        Map<String, GdmField> fieldsMap = entity.getFieldsMap();
        List<GdmEntityChange.Field> missingPartitionByFields = partitionByFields.stream()
                .filter(x -> !fieldsMap.containsKey(x.getFieldName()))
                .map(x -> this.mapField(this.toGdmField(x)))
                .collect(Collectors.toList());
        fieldList.addAll(missingPartitionByFields);

        fields.setFieldList(fieldList);

        GdmEntityChange.DataProcessingModes dataProcessingModes = new GdmEntityChange.DataProcessingModes();
        createGdmEntity.setDataProcessingModes(dataProcessingModes);

        List<GdmEntityChange.DataProcessingMode> modeList = convertProcessingMode(entity.dataProcessingModes(), partitionByFields);
        dataProcessingModes.setDataProcessingModeList(modeList);

        return changeSet;
    }

    private List<GdmEntityChange.DataProcessingMode> convertProcessingMode(List<DataProcessingMode> dataProcessingModes, List<GdmModelDto.Field> partitionByFields) {
        return dataProcessingModes.stream()
                .map(x -> convertProcessingMode(x, partitionByFields))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    private GdmEntityChange.DataProcessingMode convertProcessingMode(DataProcessingMode mode, List<GdmModelDto.Field> partitionByFields) {
        switch (mode) {
            case BATCH_AP:
                GdmEntityChange.DataProcessingMode batchAP = new GdmEntityChange.DataProcessingMode();
                batchAP.setName("BATCH_AP");
                List<GdmEntityChange.GdmStorage> storages = new ArrayList<>();
                batchAP.setGdmStorages(storages);
                GdmEntityChange.ParquetStorage parquetStorage = new GdmEntityChange.ParquetStorage();
                parquetStorage.setName("impala");
                GdmEntityChange.ParquetStorage.PartitionedBy partitionedBy = new GdmEntityChange.ParquetStorage.PartitionedBy();
                parquetStorage.setPartitionedBy(partitionedBy);
                List<GdmEntityChange.GdmStorage.Column> partitionByKeys = partitionByFields.stream().map(this::mapField).collect(Collectors.toList());
                partitionedBy.setColumns(partitionByKeys);
                storages.add(parquetStorage);
                return batchAP;
            case REALTIME_AP:
                //TODO Implement me!
                return null;
            case OLTP:
                //TODO Implement me!
                return null;
            default:
                return null;
        }
    }

    private SchemaChangeLogV1.ChangeSet buildDropTableChangeSet(String tableName) {
        SchemaChangeLogV1.ChangeSet changeSet = new SchemaChangeLogV1.ChangeSet();
        changeSet.setId("drop table " + tableName + "-" + MDC.get(LoggingConstants.REQUEST_ID));
        changeSet.setAuthor("foundation");

        Ddl.DropTable dropTable = new Ddl.DropTable();
        changeSet.setSchemaChange(dropTable);
        dropTable.setName(tableName);

        Preconditions preconditions = new Preconditions();
        Preconditions.TableExist tableExist = new Preconditions.TableExist();
        tableExist.setTableName(tableName);
        preconditions.setPreconditions(Lists.newArrayList(tableExist));
        dropTable.setPreconditions(preconditions);

        Storages storages = new Storages();
        List<Storages.Storage> storageList = new ArrayList<>();
        Storages.Storage batchAp = new Storages.Storage();
        batchAp.setMode("BATCH_AP");
        storageList.add(batchAp);
        storages.setStorages(storageList);
        dropTable.setStorages(storages);
        return changeSet;
    }

    private GdmEntityChange.Field mapField(GdmField field) {
        GdmEntityChange.Field f = new GdmEntityChange.Field();
        f.setName(field.getFieldName());
        f.setColumn(field.getDbColumnName());
        f.setType(field.getFieldType().name());
        return f;
    }

    private GdmEntityChange.GdmStorage.Column mapField(GdmModelDto.Field field) {
        String fieldName = field.getFieldName();
        String columnName = StringUtils.isBlank(field.getColumnName()) ? fieldName : field.getColumnName();

        GdmEntityChange.GdmStorage.Column column = new GdmEntityChange.GdmStorage.Column();
        column.setName(columnName);
        return column;
    }

/*
    private boolean createGdmEntity(GdmEntity entity) {
        GdmEntityProvision entityProvision = UdoProvision.createFeatureProvision(entity);
        GdmPatternDto.ProvisionProperties props = new GdmPatternDto.ProvisionProperties();
        props.setDataProcessingModes(entity.dataProcessingModes().toArray(new DataProcessingMode[0]));
        entityProvision.setProps(props);
        GdmEntityRequest gdmEntityRequest = entityProvision.buildGdm();
        return gdmMetaFacade.createEntity(gdmEntityRequest);
    }

    private String entityToDdl(GdmEntity entity, List<GdmModelDto.Field> partitionByFields) {
        SQLCreateTableStatement statement = new SQLCreateTableStatement();
        statement.setTableName(entity.getDbTableName());
        statement.setIfNotExiists(true);
        entity.getFields().forEach(field -> statement.addColumn(field.getDbColumnName(), DataType.ofType(field.getFieldType()).getMysqlType()));
        Map<String, GdmField> fieldsMap = entity.getFieldsMap();
        List<GdmModelDto.Field> missingPartitionByFields = partitionByFields.stream().filter(x -> !fieldsMap.containsKey(x.getFieldName())).collect(Collectors.toList());
        missingPartitionByFields.forEach(field -> statement.addColumn(field.getColumnName(), DataType.ofType(field.getFieldType()).getMysqlType()));
        return SQLUtils.toMySqlString(statement);
    }

    private SchemaChangeLogV1.ChangeSet buildCreateTableChangeSet(String tableName, String createTableDdl, List<GdmModelDto.Field> partitionByFields) {
        SchemaChangeLogV1.ChangeSet changeSet = new SchemaChangeLogV1.ChangeSet();
        changeSet.setId("create table " + tableName);
        changeSet.setAuthor("foundation-" + MDC.get(LoggingConstants.REQUEST_ID));
        Ddl.CreateTable createTable = new Ddl.CreateTable();
        Storages.Partition partition = new Storages.Partition();
        String partitionKey = partitionByFields.stream()
                .map(GdmModelDto.Field::getColumnName)
                .reduce((t1, t2) -> StringUtils.joinWith(",", t1, t2)).orElse("");
        partition.setKey(partitionKey);
        partition.setPartitions(4);
        createTable.setPartition(partition);
        createTable.setExternal(true);
        createTable.setSql(createTableDdl);
        changeSet.setSchemaChange(createTable);


        Storages storages = new Storages();
        List<Storages.Storage> storageList = new ArrayList<>();
        Storages.Storage batchAp = new Storages.Storage();
        batchAp.setMode("BATCH_AP");
        storageList.add(batchAp);
        storages.setStorages(storageList);
        createTable.setStorages(storages);
        return changeSet;
    }
   */

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @EqualsAndHashCode
    public static class ResultDto {
        public static final ResultDto OK = new ResultDto("success");
        public static final ResultDto SKIPPED = new ResultDto("skipped");
        private String result;
    }
}
