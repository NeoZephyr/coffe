package com.convertlab.foundation.datapermission.model;

import com.convertlab.foundation.library.datapermission.GrantedSubjectType;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class ResourceAclListByResourceTypeAndGrantedSubjectMapDto {
    String resourceType;
    Map<GrantedSubjectType, List<String>> grantedSubjectMap;
}
