package com.convertlab.foundation.user.model;

import lombok.Value;


@Value
public class UserGroupCount {
    String groupCode;
    Long count;

    public UserGroupCount(String groupCode, Long count) {
        this.groupCode = groupCode;
        this.count = count;
    }
}
