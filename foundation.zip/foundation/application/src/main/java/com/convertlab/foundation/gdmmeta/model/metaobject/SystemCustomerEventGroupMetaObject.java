package com.convertlab.foundation.gdmmeta.model.metaobject;

import javax.annotation.Nonnull;
import java.util.*;
import java.util.stream.Collectors;

import org.jetbrains.annotations.NotNull;
import org.springframework.util.Assert;

import com.convertlab.foundation.gdmmeta.model.Entity;
import com.convertlab.foundation.gdmmeta.model.Field;
import com.convertlab.foundation.gdmmeta.model.Inheritance;
import com.convertlab.foundation.gdmmeta.utils.GdmNamingUtils;
import com.convertlab.foundation.library.gdmmeta.model.ColumnType;
import com.convertlab.foundation.library.gdmmeta.model.FieldType;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.CaseFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Slf4j
public class SystemCustomerEventGroupMetaObject implements CustomerEventMetaObject {
        String groupName;
        List<Event> events;

    @Data
    public static class Event {
        String name;
        public String getName() {
            return GdmNamingUtils.toUnderScoreCase(name);
        }
        boolean engaged = false;

        List<Prop> props;

    }

    @Data
    public static class Prop {
        String name;
        public String getName() {
            return GdmNamingUtils.toUnderScoreCase(name);
        }
        String column;
        PropType type;
        boolean isAttr = false;
    }

    enum PropType {
        @JsonProperty("Text") TEXT,
        @JsonProperty("String") STRING,
        @JsonProperty("Number") NUMBER,
        @JsonProperty("Decimal") DECIMAL,
        @JsonProperty("DateTime") DATE_TIME,
        @JsonProperty("Date") DATE;
    }


    private FieldType getFieldTypeByPropType(PropType propType) {
        EnumMap<PropType, FieldType> map = new EnumMap<>(PropType.class);
        map.put(PropType.TEXT, FieldType.String);
        map.put(PropType.STRING, FieldType.String);
        map.put(PropType.NUMBER, FieldType.Integer);
        map.put(PropType.DECIMAL, FieldType.Double);
        map.put(PropType.DATE, FieldType.Date);
        map.put(PropType.DATE_TIME, FieldType.DateTime);
        return map.get(propType);
    }

    @Nonnull
    public List<Entity> getEventGroupEntityList(boolean withEventFields) {
        List<Entity> entityList = new ArrayList<>(events.size());

        for (Event event: events) {
            String eventKey = event.getName();
            List<Field> fieldList = withEventFields ? getEventFields(event, eventKey) : new ArrayList<>() ;
            Inheritance inheritance = Inheritance.newCustomerEventInheritance(true, eventKey);
            Entity entity = newEventEntity(eventKey, fieldList, inheritance);
            entityList.add(entity);
        }
        return entityList;
    }

    /**
     *  TODO add to excluded list pattern ? excluded duplicated field
     *        !(eventKey.equals("wechat_leave_message") && prop.getName().equals("messageContent") && prop.getColumn().equals("summary"))
     *                 //TODO to be confirmed
     *                 && !(eventKey.equals("wechat_leave_message") && prop.getName().equals("wechatAccountId") && prop.getColumn().equals("channelAccount"))
     *                 && !(eventKey.equals("wechat_receive_reply") && prop.getName().equals("messageContent") && prop.getColumn().equals("summary"))
     *                 //TODO to be confirmed
     *                 && !(eventKey.equals("wechat_receive_reply") && prop.getName().equals("wechatAccountId") && prop.getColumn().equals("channelAccount"))
     *                 && !(eventKey.equals("wechat_receive_message_from_wechat_guide") && prop.getName().equals("wechatAccountId") && prop.getColumn().equals("channelAccount"))
     *
     * @param event
     * @param eventEntityName
     * @return
     */
    @NotNull
    private List<Field> getEventFields(@Nonnull Event event, @Nonnull String eventEntityName) {

        Field eventGroupField = Field.builder()
                .fieldName(EVENT_GROUP_FIELD_NAME).fieldType(FieldType.String)
                .dbColumnName(EVENT_GROUP_COLUMN_NAME)
                .build();

        final String eventKey = event.getName();
        List<Prop> eventProps = event.getProps();
        Map<String, Prop> existedProps = new LinkedHashMap<>();
        for (Prop prop: eventProps) {
            final String propName = prop.getName();
            if (existedProps.containsKey(propName)) { // 使用最后定义的Field
               log.debug("Event Entity {} has duplicated field, the last one: {}", eventKey, propName);
               existedProps.put(propName, prop);
           } else if (propName.equals("source") || propName.equals("content_name")) { //使用了系统属性 source, contentName
                log.debug("Event Entity {} has system field: {}", eventKey, propName);
           } else {
               existedProps.put(propName, prop);
           }
        }
        List<Field> fieldList = existedProps.values().stream()
                .map(prop -> {
                    FieldType fieldType = getFieldTypeByPropType(prop.getType());
                    //TODO data fix
                    final String propName = prop.getName();
                    if (eventEntityName.equals("change_owner") && propName.equals("new_owner")) {
                        fieldType = FieldType.String;
                    }
                    if (propName.equals("customer_id") && !fieldType.equals(FieldType.Long)) {
                        fieldType = FieldType.Long;
                    }
                    Assert.notNull(fieldType, "Not found field type: event: " + eventEntityName + ", field: " + propName);

                    if (propName.equals("menu_i_d")) {
                        prop.setName("menu_id");
                    }

                    String columnName = CaseFormat.LOWER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, prop.column);
                    return Field.builder()
                            .fieldName(propName).dbColumnName(columnName)
                            .fieldType(fieldType).build();

                }).collect(Collectors.toList());
        fieldList.add(eventGroupField);
        return fieldList;
    }

}
