package com.convertlab.foundation.datapermission.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.FieldStrategy;
import com.baomidou.mybatisplus.annotation.TableField;
import com.convertlab.foundation.datapermission.util.GrantedPermissionTypeHandler;
import com.convertlab.foundation.datapermission.util.GrantedSubjectTypeHandler;
import com.convertlab.foundation.library.datapermission.GrantedPermission;
import com.convertlab.foundation.library.datapermission.GrantedSubjectType;
import lombok.Data;
import org.apache.commons.beanutils.BeanUtils;

import java.lang.reflect.InvocationTargetException;
import java.time.Instant;
import java.util.Map;

@Data
public class BaseResourceAccessEntityInternal {

    public BaseResourceAccessEntityInternal() {
    }

    private String uuid;
    private Long tenantId;
    @TableField(fill = FieldFill.INSERT, update = "%s+1", updateStrategy = FieldStrategy.IGNORED)
    private int version;
    private String resourceCode;
    private String resourceType;
    private String grantedSubjectType;
    private String grantedSubjectCode;
    private Integer grantedPermission;
    private String grantedReason;
    private String additionalInfo;
    private Instant dateCreated;
    private Instant lastUpdated;

}
