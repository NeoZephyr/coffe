package com.convertlab.foundation.user.service;

import com.convertlab.foundation.user.model.DpTaskDTO;
import com.convertlab.foundation.user.utils.DpTaskStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;

import java.util.Map;


@Slf4j
abstract class TaskExecutorService {
    FileService fileService;
    DeptTaskService deptTaskService;

    public TaskExecutorService(FileService fileService,
                               DeptTaskService deptTaskService) {
        this.fileService = fileService;
        this.deptTaskService = deptTaskService;
    }

    abstract boolean support(String type);

    abstract void beforeExecute(DpTaskDTO dto);

    abstract void doExecute(DpTaskDTO dto);

    public void updateTask(DpTaskDTO dto) {
        deptTaskService.update(dto);
    }

    public void execute(DpTaskDTO dto) {
        beforeExecute(dto);
        if (DpTaskStatus.failed.equals(dto.getStatus())) {
            log.warn("task {} beforeExecute failed, failed reason: {}", dto.getId(), dto.getFailReason());
            updateTask(dto);
            return;
        }

        doExecute(dto);

        if (DpTaskStatus.failed.equals(dto.getStatus())) {
            log.warn("task {} doExecute failed, failed reason: {}", dto.getId(), dto.getFailReason());
        }

        updateTask(dto);
    }
}