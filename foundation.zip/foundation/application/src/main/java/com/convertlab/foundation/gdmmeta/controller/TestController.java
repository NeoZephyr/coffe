package com.convertlab.foundation.gdmmeta.controller;

import com.convertlab.foundation.gdmmeta.model.Entity;
import com.convertlab.foundation.gdmmeta.service.ConfigMetaProvider;
import com.convertlab.foundation.gdmmeta.service.impl.DbMetaProviderImpl;
import com.convertlab.foundation.gdmmeta.service.impl.GdmEntityMergeService;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.constant.DataProcessingMode;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.gdmmeta.client.GdmStorageMetaRtClient;
import com.convertlab.foundation.library.gdmmeta.client.GeneralMetaClient;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.model.ColumnType;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.gdmmeta.model.general.BaseMetaSchema;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.GdmAclDto;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.ObjectRequest;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.ObjectResponse;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationship;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmSingularGdmRelationship;
import com.convertlab.foundation.library.property.DataProcessingModeProperties;
import com.google.common.base.Strings;
import io.swagger.v3.oas.annotations.Hidden;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.util.Lists;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@RestController
@Hidden
@RequestMapping("test")
public class TestController {
    private final DbMetaProviderImpl dbMetaProvider;
    private final ConfigMetaProvider configMetaProvider;
    private final GdmEntityMergeService gdmEntityMergeService;
    private final GsMetaClient gsMetaClient;
    private DataProcessingModeProperties  dataProcessingModeProperties;
    private final GeneralMetaClient generalMetaClient;
    private GdmStorageMetaRtClient gdmStorageMetaRtClient;

    public TestController(DbMetaProviderImpl dbMetaProvider,
                          ConfigMetaProvider configMetaProvider,
                          GdmEntityMergeService gdmEntityMergeService,
                          GsMetaClient gsMetaClient,
                          GeneralMetaClient generalMetaClient,
                          DataProcessingModeProperties dataProcessingModeProperties,
                          GdmStorageMetaRtClient gdmStorageMetaRtClient){

        this.dbMetaProvider = dbMetaProvider;
        this.configMetaProvider = configMetaProvider;
        this.gdmEntityMergeService = gdmEntityMergeService;
        this.gsMetaClient = gsMetaClient;
        this.generalMetaClient = generalMetaClient;
        this.dataProcessingModeProperties = dataProcessingModeProperties;
        this.gdmStorageMetaRtClient = gdmStorageMetaRtClient;
    }

    @GetMapping(value = "/{datasourceName}/catalog", produces = "application/json")
    public List<String> getCatalog(
            @PathVariable String datasourceName) {
        return dbMetaProvider.getCatalog(datasourceName);
    }

    @GetMapping(value = "/{datasourceName}/schema", produces = "application/json")
    public List<Map<String, String>> getSchemas(
            @PathVariable String datasourceName,
            @RequestParam(required = false) String cat) {

        cat = getDefaultCatalog(datasourceName, cat);

        return dbMetaProvider.getSchemas(datasourceName, cat);
    }

    @GetMapping(value = "/{datasourceName}/table", produces = "application/json")
    public List<String> getTables(
            @PathVariable String datasourceName,
            @RequestParam(required = false) String cat,
            @RequestParam(required = false) String schema) {

        cat = getDefaultCatalog(datasourceName, cat);
        schema = getDefaultSchema(datasourceName, schema);
        return dbMetaProvider.getTables(datasourceName, cat, schema);
    }


    @GetMapping(value = "/{datasourceName}/gdmEntityList", produces = "application/json")
    public List<GdmEntity> getEntity(
            @PathVariable String datasourceName,
            @RequestParam(required = false) String cat,
            @RequestParam(required = false) String schema) {
        cat = getDefaultCatalog(datasourceName, cat);
        schema = getDefaultSchema(datasourceName, schema);

        DbMetaProviderImpl.DatasourceInfo datasourceInfo = dbMetaProvider.getDatasourceInfoByName(datasourceName);
        Map<String, String> entityTableMap = (datasourceInfo.dbConnType.isOltpConn())?
                configMetaProvider.getRegisteredEntityTableMapWithOltpStorage() :
                configMetaProvider.getRegisteredEntityTableMapWithOlapStorage();

        List<Entity> entityListByTables = dbMetaProvider.getEntityListByTables(datasourceName, cat, schema, entityTableMap);
        return entityListByTables.stream().map(Entity::gdmEntity).collect(Collectors.toList());
    }

    private String getDefaultSchema(String datasourceName, String schema) {
        if (Strings.isNullOrEmpty(schema) && dbMetaProvider.isImpalaDataSrouce(datasourceName)) {
            schema = "cdp_test"; //TODO 从 JDBC 中获取
        }
        return schema;
    }

    private String getDefaultCatalog(String datasourceName, String cat) {
        if (Strings.isNullOrEmpty(cat)) {
            if (dbMetaProvider.isImpalaDataSrouce(datasourceName)) {
                cat = "Impala";
            }

            if ("su".equals(datasourceName)) {
                cat = "dmhub_su";
            }

            if ("main".equals(datasourceName)) {
                cat = "dmhub";
            }
        }
        return cat;
    }

    /**
     * 通过 JDBC 连接 mysql 的 catalog 就是 database ，没有 schema
     * 连接到 Impala
     *
     * @param datasourceName main/su/impala in application.yml
     * @param cat for mysql,
     * @param schema
     * @return
     */
    @GetMapping(value = "/{datasourceName}/allEntities", produces = "application/json")
    public List<GdmEntity> getAllEntities(
            @PathVariable String datasourceName,
            @RequestParam(required = false) String cat,
            @RequestParam(required = false) String schema) {
        cat = getDefaultCatalog(datasourceName, cat);
        schema = getDefaultSchema(datasourceName, schema);

        Map<String, String> entityTableMap = dbMetaProvider.isImpalaDataSrouce(datasourceName) ?
                configMetaProvider.getRegisteredEntityTableMapWithOlapStorage() :
                configMetaProvider.getRegisteredEntityTableMapWithOltpStorage();

        List<Entity> allEntities = dbMetaProvider.getAllEntities(datasourceName, cat, schema, entityTableMap);
        return allEntities.stream().map(Entity::gdmEntity).collect(Collectors.toList());
    }

    @GetMapping(value = "/raw", produces = "application/json")
    public List<GdmEntity> getRawGdmMeta() {
        return dbMetaProvider.getEntitiesFromBase();
    }


    @GetMapping(value = "/gdm/meta/merged/entity/{entityName}", produces = "application/json")
    public GdmEntity getMergeEntity( @PathVariable String entityName) {
        Entity entity = gdmEntityMergeService.getEntity(entityName);
        if (entity == null) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_003_001001", new String[]{entityName});
        }
        return entity.gdmEntity();
    }

    @GetMapping(value = "/gdm1")
    List<ObjectResponse> test() {
        return generalMetaClient.queryObjects(BaseMetaSchema.Namespace.GDM, BaseMetaSchema.MetaType.GDM_ACLS, new HashMap<>());
    }

    @GetMapping(value = "/erMeta/fks")
    Map<GdmField, GdmRelationship> erMetaFks(@RequestParam String entityName) {
        Map<GdmField, GdmRelationship> fkRelationshipMap = gsMetaClient.getFkRelationshipMap(entityName);
        return fkRelationshipMap;
    }

    @GetMapping(value = "/erMeta/udos")
    List<GdmEntity> erMetaUdos() {
        List<GdmEntity> udoList = gsMetaClient.getUdoGdmEntityList();
        return udoList;
    }

    /**
     * 返回 Map<GdmSingularGdmRelationship, GdmEntity> 的话，消息体太大了。
     *
     * @param entityName
     * @return
     */
    @GetMapping(value = "/erMeta/bakRefs")
    List<GdmSingularGdmRelationship> erMetaUdos(@RequestParam String entityName) {
        List<GdmSingularGdmRelationship>  backRefEntityList = gsMetaClient.getBackRefProfileList(entityName);
        return backRefEntityList;
    }

    @GetMapping(value = "/erMeta/udoEvents")
    List<GdmEntity> erMetaUdoEvents(@RequestParam String objId) {
        List<GdmEntity> udoEventGdmEntityList = gsMetaClient.getUdoEventGdmEntityList(objId);
        return udoEventGdmEntityList;
    }


    @GetMapping(value = "/stMeta/columns")
    Map<String, ColumnType> columnTypeMap(@RequestParam String entityName) {
        GdmEntity entity = gsMetaClient.getEntity(entityName);
        ArrayList<DataProcessingMode> dataProcessingModes = Lists.newArrayList(DataProcessingMode.REALTIME_AP, DataProcessingMode.BATCH_AP);
        Map<String, ColumnType> columnNameAndTypeMap = gdmStorageMetaRtClient.getColumnNameAndTypeMap(entity, dataProcessingModes);
        return columnNameAndTypeMap;
    }

    /**
     *
     * Sample Request:
     * <pre>
     * {
     *     "objectName": "acl_setting",
     *     "data": {
     *         "globalSetting": {
     *             "seaExclusiveDepartments": [],
     *             "grantedSubjectTypes": ["user", "group", "dept"]
     *         },
     *         "resourceSettings": [
     *             {
     *                 "resourceName": "resource1",
     *                 "isProprietary": true,
     *                 "outerAttribute": "uuid"
     *             },
     *             {
     *                 "resourceName": "resource2",
     *                 "isProprietary": false,
     *                 "outerAttribute": "id"
     *             }
     *         ]
     *     }
     * }
     * </pre>
     * @param objectRequest
     * @return
     */

    @PostMapping(value = "/gdm2", produces = MediaType.APPLICATION_JSON_VALUE)
    public ObjectResponse mergeEntity(@RequestBody ObjectRequest objectRequest) {

        GdmAclDto reqDto = objectRequest.getObject(GdmAclDto.class);
        log.trace("getting dto from ObjectRequest, {}", reqDto);

        // create a dto
        GdmAclDto reqObj = GdmAclDto.builder().globalSetting(
               reqDto.getGlobalSetting()
        ).resourceSettings(
                reqDto.getResourceSettings()
        ).build();

        log.trace("show creating a new request object using dto");
        ObjectRequest newReq = new ObjectRequest(objectRequest.getObjectName(), reqObj);

        log.trace("show calling generalMetaClient.createObject");
        ObjectResponse resp = generalMetaClient.createObject(BaseMetaSchema.Namespace.GDM, BaseMetaSchema.MetaType.GDM_ACLS, newReq);

        GdmAclDto respDto = resp.getObject(GdmAclDto.class);
        log.trace("show getting a response object, {}", respDto);

        return resp;
    }

}
