package com.convertlab.foundation.misc.service;

import javax.annotation.Nonnull;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.apache.commons.lang3.StringUtils;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class DPMigrationTestService {
//
//    private final static Logger log = LoggerFactory.getLogger(DPMigrationTestService.class);
//
//    private final static ObjectMapper mapper = new ObjectMapper();
//
//    private static final String INSERT_DP_RESOURCE_ACCESS_CONTROL_SQL_TEMPLATE = "insert into dp_resource_access_control_main values %s";
//    private static final String INSERT_SU_DP_RESOURCE_ACCESS_CONTROL_SQL_TEMPLATE = "insert into dp_resource_access_control_main values %s";
//
//    @Nonnull
//    private static String formatToLines(@Nonnull List<String> sqls) {
//        return sqls.stream().reduce("", (lhs, rhs) -> lhs + "\n" + rhs);
//    }
//
//    private final DynamicJdbcTemplate jdbcTemplate;
//
//    public DPMigrationTestService(DynamicJdbcTemplate jdbcTemplate) {
//        this.jdbcTemplate = jdbcTemplate;
//    }
//
//    private static Stream<MigrationRowSQL> toPlans(@NotNull List<Map> row) {
//        return row.stream().map(MigrationRowSQL::fromRow).filter(Objects::nonNull);
//    }
//
//    @Nonnull
//    public String migrateContentAccessControl(boolean enableSU, @Nullable Integer size) {
//        String select = "select id, version, tenant_id, resource_type, resource_id, resource_code, access_scope, access_code, access_source, access_level, date_created, last_updated from content_resource_access_control order by content_resource_access_control.id desc " + (Objects.isNull(size) ? "" : "limit " + size);
//        String dataSource = enableSU ? "su" : "main";
//        Map<String, List<Map>> rs = jdbcTemplate.queryAllForList(dataSource, select, Map.class);
//        List<MigrationRowSQL> migratingRows = rs.values().stream().flatMap(DPMigrationTestService::toPlans).collect(Collectors.toList());
//        String keptValuesSql = migratingRows.stream().map(r -> r.keepInAccessControl).filter(Objects::nonNull).collect(Collectors.joining(", \n"));
//        String keptSql = String.format(enableSU ? INSERT_SU_DP_RESOURCE_ACCESS_CONTROL_SQL_TEMPLATE : INSERT_DP_RESOURCE_ACCESS_CONTROL_SQL_TEMPLATE, keptValuesSql);
//        List<String> migratedSql = migratingRows.stream().map(r -> r.moveToResourceTable).filter(Objects::nonNull).collect(Collectors.toList());
//        List<String> sqls = new LinkedList<>();
//        if (StringUtils.isNotBlank(keptValuesSql)) {
//            sqls.add(keptSql);
//        }
//        if (!migratingRows.isEmpty()) {
//            sqls.addAll(migratedSql);
//        }
//        return formatToLines(sqls);
//    }


}
