package com.convertlab.foundation.gdmmeta.model;

import com.convertlab.foundation.gdmmeta.exception.GdmTableGeneratedFailedException;
import com.convertlab.foundation.gdmmeta.model.metaobject.SystemMetaCorrectionObject;
import com.convertlab.foundation.gdmmeta.persistance.entity.GdmFieldModel;
import com.convertlab.foundation.gdmmeta.persistance.table.GdmColumnDefModel;
import com.convertlab.foundation.gdmmeta.persistance.table.GdmColumnModel;
import com.convertlab.foundation.library.gdmmeta.model.ColumnType;
import com.convertlab.foundation.library.gdmmeta.model.FieldType;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.gdmmeta.model.ImmutableGdmField;
import com.convertlab.foundation.library.gdmmeta.model.storage.Storage;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.base.CaseFormat;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.Assert;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Field implements AssignValueStrategy<Field>{
    private Integer id;
    private String fieldName;
    private FieldType fieldType;
    private String dbColumnName;

    @Setter(AccessLevel.NONE)
    private ColumnType dbColumnType = ColumnType.UNKNOWN;
    private String fieldAlias;

    /**
     * columnType 只会设置从 DB 获取的实际 ColumnType,
     * 其他数据源提供的 columnType 都不使用。
     * @param columnType
     */
    private void finallySetDbColumnType(ColumnType columnType) {
        this.dbColumnType = columnType;
    }

    @Nonnull
    public GdmField gdmField() {
        GdmField gdmField = ImmutableGdmField.builder()
                .fieldName(fieldName).fieldType(fieldType)
                .dbColumnName(dbColumnName)
                .build();
        return gdmField;
    }

    @Nonnull
    public GdmFieldModel gdmFieldModel() {
        GdmFieldModel gdmFieldModel = new GdmFieldModel();
        gdmFieldModel.setFieldName(getFieldName());
        gdmFieldModel.setFieldType(getFieldType());
        gdmFieldModel.setDbColumnName(getDbColumnName());
        return gdmFieldModel;
    }

    public GdmColumnDefModel gdmColumnDefModel() {
        GdmColumnDefModel gdmColumnDefModel = new GdmColumnDefModel();
        gdmColumnDefModel.setColumnType(getDbColumnType());
        return gdmColumnDefModel;
    }

    @Nonnull
    public static GdmColumnModel newGdmColumnModel(@Nullable Field mysqlGdmField, @Nullable Field impalaGdmField,
                                             @Nonnull List<String> dbTypes){

        GdmColumnModel gdmColumnModel = new GdmColumnModel();
        Map<String, GdmColumnDefModel> gdmColumnDefs = new HashMap<>();
        if (mysqlGdmField != null){
            gdmColumnModel.setColumnName(mysqlGdmField.getFieldName());
            GdmColumnDefModel gdmColumnDefModel = mysqlGdmField.gdmColumnDefModel();
            gdmColumnDefs.put(Storage.MYSQL, gdmColumnDefModel);
        }
        if (impalaGdmField != null){
            String fieldName = impalaGdmField.getFieldName();
            gdmColumnModel.setColumnName(fieldName);
            GdmColumnDefModel gdmColumnDefModel = impalaGdmField.gdmColumnDefModel();
            if (dbTypes.contains(Storage.KUDU)) {
                gdmColumnDefs.put(Storage.KUDU, gdmColumnDefModel);
            } else if (dbTypes.contains(Storage.PARQUET)) {
                gdmColumnDefs.put(Storage.PARQUET, gdmColumnDefModel);
            } else {
                throw new GdmTableGeneratedFailedException(String.format("gdmColumn: %s has no olap storage type in dbTypes: %s",fieldName, dbTypes ));
            }
        }
        gdmColumnModel.setColumnDefs( gdmColumnDefs);
        return gdmColumnModel;
    }

    public Field(@Nonnull Field ora) {
        fieldName = ora.getFieldName();
        fieldType = ora.getFieldType();
        dbColumnName = ora.getDbColumnName();
        dbColumnType = ora.getDbColumnType();
    }

    public Field(@Nonnull GdmField gdmField) {
        fieldName = gdmField.getFieldName();
        fieldType = gdmField.getFieldType();
        dbColumnName = gdmField.getDbColumnName();
    }

    public void updateAttrs(String entityName, @Nonnull List<SystemMetaCorrectionObject.FieldOps> fieldOpsList) {
        for (SystemMetaCorrectionObject.FieldOps fieldOps: fieldOpsList) {
           switch (fieldOps.getFieldAttrName()) {
               // 默认从 meta 中会获得 dbColumnName，不过对于customer/customerStatistics， meta 中没有提供 dbColumnName 信息，
               // 需要根据 fieldName 进行转换，所以，在修正 fieldName 的同时，也需要修正 dbColumnName
               case "fieldNameAndColumnName":
                   Assert.isTrue(this.fieldName.equals(fieldOps.getOldValue()), notMatchedMessage(this.fieldName, fieldOps));
                   setFieldName(fieldOps.getNewValue());
                   String newDbColumnName = CaseFormat.LOWER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, fieldOps.getNewValue());
                   setDbColumnName(newDbColumnName);
                   break;
               case "fieldName":
                   Assert.isTrue(this.fieldName.equals(fieldOps.getOldValue()), notMatchedMessage(this.fieldName, fieldOps));
                   setFieldName(fieldOps.getNewValue());
                   break;
               case "fieldType":
                   if (!this.fieldType.equals(FieldType.valueOf(fieldOps.getOldValue()))) {
                       log.trace("Field type not matched for entity.fieldName: {}.{}, {} changeTo {}", entityName, this.fieldName, fieldOps.getOldValue(), this.fieldType);
                   }
                   setFieldType(FieldType.valueOf(fieldOps.getNewValue()));
                   break;
               case "dbColumnName":
                   Assert.isTrue(this.dbColumnName.equals(fieldOps.getOldValue()), notMatchedMessage(this.dbColumnName, fieldOps));
                   setDbColumnName(fieldOps.getNewValue());
                   break;
               default:
                   Assert.isTrue(false, "Unexpected fieldOps: " + fieldOps);
                   break;
           }
        }
    }

    @Nonnull
    public Field replaceOrAddIfNotNull(@Nonnull Field overlay, GdmObjectMerger gdmObjectMerger) {
        if (overlay.getFieldName() != null) {
            this.setFieldName(overlay.getFieldName());
        }
        if (overlay.getFieldType() != null && !overlay.getFieldType().isUnknown()) {
            this.setFieldType(overlay.getFieldType());
        }
        if (overlay.getDbColumnName() != null) {
            this.setDbColumnName(overlay.getDbColumnName());
        }
        if (overlay.getDbColumnType() != null && !overlay.getDbColumnType().isUnknown()) {
            this.finallySetDbColumnType(overlay.getDbColumnType());
        }
        if (overlay.getFieldAlias() != null) {
            this.setFieldAlias(overlay.getFieldAlias());
        }
        return this;
    }

    @Nonnull
    public Field unsetIfNotNull(@Nonnull Field overlay, GdmObjectMerger gdmObjectMerger) {
        if (overlay.getFieldName() != null) {
            this.setFieldName(null);
        }
        if (overlay.getFieldType() != null) {
            this.setFieldType(null);
        }
        if (overlay.getDbColumnName() != null) {
            this.setDbColumnName(null);
        }
        if (overlay.getDbColumnType() != null) {
            this.finallySetDbColumnType(ColumnType.UNKNOWN);
        }
        if (overlay.getFieldAlias() != null) {
            this.setFieldAlias(null);
        }
        return this;
    }

    @Nonnull
    public Field updateDbColumnInfo(@Nonnull Field overlay, GdmObjectMerger gdmObjectMerger) {
        if (overlay.getDbColumnType() != null && !overlay.dbColumnType.isUnknown()) {
            this.finallySetDbColumnType(overlay.dbColumnType);
        }
        return this;
    }

    @Nonnull
    public Field dummy(Field overlay, GdmObjectMerger gdmObjectMerger) {
        log.trace("matched field run into dummy: " + overlay);
        return this;
    }

    @Nonnull
    private String notMatchedMessage(Object attrValue, @Nonnull SystemMetaCorrectionObject.FieldOps ops) {
        return "Unexpected Field." + ops.getFieldAttrName() +"=" + attrValue + ", the FieldOps: " + ops;
    }

}
