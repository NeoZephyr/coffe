package com.convertlab.foundation.datapermission.model;

import com.convertlab.foundation.library.datapermission.GrantedSubjectType;
import lombok.Data;

import java.util.List;

@Data
public class ResourceAclListByResourceTypeAndGrantedSubjectDto {
    String resourceType;
    GrantedSubjectType grantedSubjectType;
    List<String> grantedSubjectCodeList;
}
