package com.convertlab.foundation.misc.entity;

import lombok.Data;

import java.time.Instant;

@Data
public class GdmColumnRecycle {
    public static final Integer STATUS_TO_BE_RECYCLE = 0;
    public static final Integer STATUS_RECYCLE_FAILED = -1;
    public static final Integer STATUS_RECYCLED = 1;
    private Long id;
    private Long tenantId;
    private String entityName;
    private String tableName;
    private String fieldName;
    private String dbColumnName;
    private Integer status;
    private String errorMsg;
    private Instant dateCreated;
    private Instant lastUpdated;
}
