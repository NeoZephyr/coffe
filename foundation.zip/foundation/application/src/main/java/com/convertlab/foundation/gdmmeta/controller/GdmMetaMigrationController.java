package com.convertlab.foundation.gdmmeta.controller;

import com.convertlab.foundation.gdmmeta.service.GdmEntityMetaService;
import com.convertlab.foundation.gdmmeta.service.GdmRelationshipMergeService;
import com.convertlab.foundation.gdmmeta.service.impl.GdmEntityMergeService;
import com.convertlab.foundation.library.business.autoconfigure.SpringBeans;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.utils.Try;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

import static com.convertlab.foundation.library.gdmmeta.model.general.BaseMetaSchema.CacheNames.GDM_META;

/**
 * Restful APIs for SDK are all aware of tenant context.
 */
@Slf4j
@RestController
@Tag(name = "Meta Store接口")
public class GdmMetaMigrationController {
    final GdmRelationshipMergeService gdmRelationMergeService;
    final GdmEntityMergeService gdmEntityMergeService;
    final GdmEntityMetaService gdmEntityMetaService;
    final CacheManager cacheManager;

    public GdmMetaMigrationController(GdmEntityMetaService gdmEntityMetaService, GdmRelationshipMergeService gdmRelationMergeService,
                                      GdmEntityMergeService gdmEntityMergeService, CacheManager cacheManager) {
        this.gdmEntityMetaService = gdmEntityMetaService;
        this.gdmRelationMergeService = gdmRelationMergeService;
        this.gdmEntityMergeService = gdmEntityMergeService;
        this.cacheManager = cacheManager;
    }

//    @Tag(name = "测试开发使用，清理 meta 服务缓存")
//    @Tag(name = "Meta Store接口")
//    @DeleteMapping(value = "/metaCache", produces = "application/json")
//    public void deleteMetaCache() {
//        Try.logAndIgnoreException(() -> {
//            CacheManager cacheManager = SpringBeans.getBean(CacheManager.class);
//            if (cacheManager != null) {
//                Optional.ofNullable(cacheManager.getCache(GDM_META)).ifPresent(Cache::clear);
//            }
//        });
//        gdmEntityMergeService.clearCache(this.cacheManager);
//    }

    @Tag(name = "Migration新世界")
    @Operation(summary = "GDM Entity初始化", description = "初始化GdmEntity, GdmRelationship 和 GdmTable 结构, 默认只处理系统meta，" +
            "如果要处理特定租户的，需要手动指定参数 tenantDefined == true")
    @GetMapping(value = "/gdmMetaInit", produces = "application/json")
    public void initGdmMetaStorage(@RequestParam(required = false, defaultValue = "false") boolean forceUpsert,
                                   @RequestParam(required = false, defaultValue = "false") boolean tenantDefined) {
        if (tenantDefined) {
            initTenantGdmMeta(forceUpsert);
        } else {
            try(TemporaryTenantContext ignore = new TemporaryTenantContext(-1L, "system gdm meta")){
                initTenantGdmMeta(forceUpsert);
                gdmEntityMergeService.saveSnapshotMetaFiles();
                gdmRelationMergeService.saveSnapshotMetaFiles();
            }
        }
    }

    @PostMapping(value = "/dumpGdmSystemMetaSnapshot", produces = "application/json")
    public void dumpMetaSnapshot() {
        try (TemporaryTenantContext ignore = new TemporaryTenantContext(-1L, "system gdm meta")) {
            gdmEntityMergeService.saveSnapshotMetaFiles();
            gdmRelationMergeService.saveSnapshotMetaFiles();
        }
    }

    private void initTenantGdmMeta(boolean forceUpsert) {
        CacheManager cacheManager = Try.ignoreException(
                () -> SpringBeans.getBean(CacheManager.class));
        if (cacheManager != null) {
            Optional.ofNullable(cacheManager.getCache(GDM_META)).ifPresent(Cache::clear);
        }
        gdmEntityMergeService.clearCache(this.cacheManager);
        gdmEntityMergeService.initGdmEntityStorage_mysql_first(forceUpsert);
        gdmRelationMergeService.initGdmRelationshipStorage(forceUpsert);
        gdmEntityMergeService.fetchAndUpsertUdoEventEntities();
    }

    @GetMapping(value = "/gdmTableMetaInit", produces = "application/json")
    public void initGdmTableMetaStorage(@RequestParam(required = false, defaultValue = "false") boolean forceUpsert) {
        gdmEntityMergeService.initGdmTableMeta(forceUpsert);
    }

    @GetMapping(value = "/gdmRelationMetaInit", produces = "application/json")
    public void initGdmRelationshipMetaStorage(@RequestParam(required = false, defaultValue = "false") boolean forceUpsert) {
        gdmRelationMergeService.initGdmRelationshipStorage(forceUpsert);
    }

}
