package com.convertlab.foundation.user.utils;

import com.google.common.base.Strings;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import java.util.Map;

public class DeptRowItem {
    public DeptRowItem(String name, String code, String parentCode) {
        this.name = name;
        this.code = code;
        this.parentCode = parentCode;
    }

    public interface Header {
        String CODE_TEXT = "\u7f16\u7801";

        // 名称
        String NAME_TEXT = "\u540d\u79f0";

        // 上级编码
        String PARENT_CODE_TEXT = "\u4e0a\u7ea7\u7f16\u7801";
    }

    public String name;
    public String code;
    public String parentCode;

    private static String cellToString(Cell cell) {
        if (cell != null) {
            return cell.getStringCellValue();
        }
        return null;
    }

    public static DeptRowItem fromFormattedRow(Map<String, Cell> cells) {
        String code = cellToString(cells.get(Header.CODE_TEXT));
        String name = cellToString(cells.get(Header.NAME_TEXT));
        String parent = cellToString(cells.get(Header.PARENT_CODE_TEXT));
        if (Strings.isNullOrEmpty(code) || Strings.isNullOrEmpty(name) || Strings.isNullOrEmpty(parent)) {
            return null;
        } else {
            return new DeptRowItem(name, code, parent);
        }
    }
}
