package com.convertlab.foundation.user.entity;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.time.Instant;

@Getter
@Setter
public class UserTenant {
    private Long id;

    private Long version;

    private Instant dateCreated;

    private Instant lastUpdated;

    @NotNull
    private Long userId;

}