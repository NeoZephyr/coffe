package com.convertlab.foundation.kvstore.consumer;

import javax.annotation.Nullable;

import com.convertlab.foundation.kvstore.dto.KvDtsMessage;
import com.convertlab.foundation.kvstore.service.KvStorageFascadeService;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class KvStorageDtsConsumer {
    private KvStorageFascadeService kvStorageFascadeService;
    private ObjectMapper objectMapper;

    public KvStorageDtsConsumer(KvStorageFascadeService kvStorageFascadeService){
        super();
        this.kvStorageFascadeService = kvStorageFascadeService;
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }
    @KafkaListener(
            topics = "${kafka.kvStoreDataDts.topic}",
            groupId = "${kafka.kvStoreDataDts.groupId}",
            concurrency = "${kafka.kvStoreDataDts.concurrency}",
            properties = {
                    "value.deserializer:org.apache.kafka.common.serialization.StringDeserializer"
            })
    public void receive(@Nullable String message) {
        log.info("receive KvStorageDtsConsumer message: {}", message);
        if(message == null){
            log.error("receive KvStorageDtsConsumer message is null");
            return;
        }
        try{
            KvDtsMessage dtsMessage = objectMapper.readValue(message, KvDtsMessage.class);
            kvStorageFascadeService.batchUpsert(dtsMessage.get_meta().getName(), dtsMessage.get_data());
        }catch (Exception e){
            log.error("receive KvStorageDtsConsumer message failed.", e);
        }
    }
}
