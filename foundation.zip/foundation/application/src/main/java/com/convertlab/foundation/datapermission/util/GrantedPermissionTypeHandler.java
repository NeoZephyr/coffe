package com.convertlab.foundation.datapermission.util;

import com.convertlab.foundation.library.datapermission.GrantedPermission;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GrantedPermissionTypeHandler extends BaseTypeHandler<GrantedPermission> {
    @Override
    public void setNonNullParameter(PreparedStatement ps, int i, GrantedPermission parameter, JdbcType jdbcType) throws SQLException {
        ps.setInt(i, parameter.getValue());
    }

    @Override
    public GrantedPermission getNullableResult(ResultSet rs, String columnName) throws SQLException {
        int value = rs.getInt(columnName);
        return GrantedPermission.fromValue(value);
    }

    @Override
    public GrantedPermission getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
        int value = rs.getInt(columnIndex);
        return GrantedPermission.fromValue(value);
    }

    @Override
    public GrantedPermission getNullableResult(CallableStatement cs, int columnIndex) throws SQLException {
        int value = cs.getInt(columnIndex);
        return GrantedPermission.fromValue(value);
    }
}
