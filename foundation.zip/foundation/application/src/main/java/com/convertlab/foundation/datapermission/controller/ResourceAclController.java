package com.convertlab.foundation.datapermission.controller;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.convertlab.foundation.datapermission.entity.BaseResourceAccessEntity;
import com.convertlab.foundation.datapermission.model.*;
import com.convertlab.foundation.datapermission.service.ResourceAccessServiceWrapper;
import com.convertlab.foundation.datapermission.service.SettingService;
import com.convertlab.foundation.library.datapermission.ListByResourcesDto;
import com.convertlab.foundation.library.datapermission.model.*;
import com.convertlab.foundation.library.datapermission.service.ResourceMetaService;
import com.convertlab.foundation.library.datapermission.ResourceAccessDto;
import com.convertlab.foundation.library.datapermission.feign.ResourceAclClient;
import com.convertlab.foundation.library.datapermission.service.ResourceEntityService;
import com.convertlab.foundation.library.datapermission.service.ResourceSettingService;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.jdbc.datasource.lookup.DataSourceLookupHelper;
import io.swagger.v3.oas.annotations.Hidden;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@Slf4j
public class ResourceAclController implements ResourceAclClient {

    final ResourceAccessServiceWrapper resourceAccessServiceWrapper;
    final ResourceMetaService resourceMetaService;
    final ResourceEntityService resourceEntityService;
    private final SettingService settingService;
    private final ResourceSettingService resourceSettingService;

    public ResourceAclController(ResourceAccessServiceWrapper resourceAccessServiceWrapper, ResourceMetaService resourceMetaService, ResourceEntityService resourceEntityService, SettingService settingService,ResourceSettingService resourceSettingService) {
        this.resourceAccessServiceWrapper = resourceAccessServiceWrapper;
        this.resourceMetaService = resourceMetaService;
        this.resourceEntityService = resourceEntityService;
        this.settingService = settingService;
        this.resourceSettingService=resourceSettingService;
    }

    //save方法
    @Override
    public Object save(@Nonnull @RequestBody ResourceAccessDto dto){
        return resourceAccessServiceWrapper.save(dto);
    }

    @Override
    public void batchSave(@Nonnull @RequestBody BatchResourceAccessDto dto){
        resourceAccessServiceWrapper.batchSave(dto);
    }

    @Nullable
    @PostMapping("/dp/acl/update")
    public void update(@Nonnull @RequestBody ResourceAccessDto dto){
         resourceAccessServiceWrapper.update(dto.getUuid(), dto);
    }

    @Nullable
    @PostMapping("/dp/acl/batchUpdate")
    public void batchUpdate(@Nonnull @RequestBody BatchResourceAccessDto dto){
        resourceAccessServiceWrapper.batchUpdate(dto);
    }

    @Nullable
    @PostMapping("/dp/acl/upsert")
    public void upsert(@Nonnull @RequestBody ResourceAccessDto dto){
        resourceAccessServiceWrapper.upsert(dto);
    }

    @Nullable
    @PostMapping("/dp/acl/batchUpsert")
    public void batchUpsert(@Nonnull @RequestBody BatchResourceAccessDto dto){
        resourceAccessServiceWrapper.batchUpsert(dto);
    }

    @Nullable
    @PostMapping("/dp/acl/deleteByUuid")
    public Map deleteByUuid(@Nonnull @RequestBody ResourceAclDeleteByUuidDto dto){
        BaseResourceAccessEntity
            entity = resourceAccessServiceWrapper.getById(dto.getResourceType(), dto.getUuid());

        if(entity == null){
            throw new BusinessException("entity not exist", "ResourceAclController.delete", "ResourceAclController.delete", new String[]{dto.getResourceType(), dto.getUuid()}, 400, null);
        }

        resourceAccessServiceWrapper.deleteById(dto.getResourceType(), entity.getUuid());

        entity = resourceAccessServiceWrapper.getById(dto.getResourceType(), entity.getUuid());

        Map result = new HashMap();
        if(entity == null){
            result.put("result", "success");
        }else{
            result.put("result", "fail");
        }
        return result;

    }

    @Nullable
    @PostMapping("/dp/acl/deleteByKey")
    public Map deleteByKey(@Nonnull @RequestBody ResourceAclDeleteByKeyDto dto){
        BaseResourceAccessEntity entity = resourceAccessServiceWrapper.getByKey(dto.getResourceType(), dto.getResourceAcl().getResourceCode(), dto.getResourceAcl().getGrantedSubjectType(),dto.getResourceAcl().getGrantedSubjectCode(), dto.getResourceAcl().getGrantedReason());

        if(entity == null){
            throw new BusinessException("entity not exist", "ResourceAclController.delete", "ResourceAclController.delete", new String[]{dto.getResourceType(), dto.getResourceAcl().getUuid()}, 400, null);
        }

        resourceAccessServiceWrapper.deleteById(dto.getResourceType(), entity.getUuid());

        entity = resourceAccessServiceWrapper.getById(dto.getResourceType(), entity.getUuid());

        Map result = new HashMap();
        if(entity == null){
            result.put("result", "success");
        }else{
            result.put("result", "fail");
        }
        return result;

    }


    @Nullable
    @PostMapping("/dp/acl/batchDeleteByUuids")
    public void batchDelete(@Nonnull @RequestBody ResourceBatchDeleteByUuidAclDto dto){
        //batch delete data. 暂不实现。
    }

    @PostMapping("/dp/acl/batchDeleteByKeys")
    public void batchDelete(@Nonnull @RequestBody BatchResourceAccessDto dto){
        resourceAccessServiceWrapper.batchDelete(dto);
    }

    @PostMapping("/dp/acl/deleteByResource")
    public void deleteByResource(@Nonnull @RequestBody ResourceAclDeleteByResourceDto dto){
        resourceAccessServiceWrapper.delete(dto.getResourceType(), dto.getResourceCode());
    }

    //listByResourceAndGrantedSubject
    @PostMapping("/dp/acl/listByResourceAndGrantedSubject")
    public List<BaseResourceAccessEntity> listByResourceAndGrantedSubject(@Nonnull @RequestBody ResourceAclListByResourceAndGrantedSubjectDto dto){
        return resourceAccessServiceWrapper.list(dto.getResourceType(), dto.getResourceCode(), dto.getGrantedSubjectType(), dto.getGrantedSubjectCode());
    }

    //listByResource
    @PostMapping("/dp/acl/listByResource")
    public List<BaseResourceAccessEntity>  listByResource(@Nonnull @RequestBody ResourceAclListByResourceDto dto){
        return resourceAccessServiceWrapper.list(dto.getResourceType(), dto.getResourceCode());
    }

    //listByResourceList
    @Override
    public List<ResourceAccessDto> listByResources(@Nonnull @RequestBody ListByResourcesDto dto){
        List<BaseResourceAccessEntity> entities = resourceAccessServiceWrapper.list(dto.getResourceType(), dto.getResourceCodeList());
        //将List<BaseResourceAccessEntity> entities 转化为 List<ResourceAccessDto> result
        List<ResourceAccessDto> result = new ArrayList<>();
        for(BaseResourceAccessEntity entity : entities){
            ResourceAccessDto resourceAccessDto = new ResourceAccessDto();
            resourceAccessDto.setResourceType(entity.getResourceType());
            resourceAccessDto.setResourceCode(entity.getResourceCode());
            resourceAccessDto.setGrantedSubjectType(entity.getGrantedSubjectType());
            resourceAccessDto.setGrantedSubjectCode(entity.getGrantedSubjectCode());
            resourceAccessDto.setGrantedReason(entity.getGrantedReason());
            resourceAccessDto.setUuid(entity.getUuid());
            resourceAccessDto.setGrantedPermission(entity.getGrantedPermission());
            resourceAccessDto.setAdditionalInfo(entity.getAdditionalInfo());
            result.add(resourceAccessDto);
        }
        return result;
    }

    @org.jetbrains.annotations.Nullable
    @Override
    public GetMetaAndSettingDto getMetaAndSetting(@NotNull String resourceType) {
        GetMetaAndSettingDto dto = new GetMetaAndSettingDto();

        ResourceMeta resourceMeta = resourceMetaService.getResourceMeta(resourceType);
        if(resourceMeta != null){
            dto.setResourceMeta(resourceMeta);
            dto.setAccessScopeSetting(settingService.getAccessScopeSetting());
            dto.setGlobalAccessSetting(settingService.getGlobalAccessSetting(resourceType));
            dto.setDeptAttrSetting(settingService.getDeptAttr(resourceType));
            dto.setHighSeasSettings(settingService.getHighSeaSettings());
        }

        return dto;
    }


    //listByResourceTypeAndGrantedSubjectMap
    @PostMapping("/dp/acl/listByResourceTypeAndGrantedSubjectMap")
    public List<BaseResourceAccessEntity>  listByResourceTypeAndGrantedSubjectMap(@Nonnull @RequestBody ResourceAclListByResourceTypeAndGrantedSubjectMapDto dto){
        return resourceAccessServiceWrapper.list(dto.getResourceType(), dto.getGrantedSubjectMap());
    }

    //listByResourceTypeAndGrantedSubjectList
    @PostMapping("/dp/acl/listByResourceTypeAndGrantedSubjectList")
    public List<BaseResourceAccessEntity>  listByResourceTypeAndGrantedSubjectList(@Nonnull @RequestBody ResourceAclListByResourceTypeAndGrantedSubjectListDto dto){
        return resourceAccessServiceWrapper.list(dto.getResourceType(), dto.getGrantedSubjectType(), dto.getGrantedSubjectCodeList());
    }

//    @Nullable
//    @PostMapping("/dp/aclmeta/{resourceType}")
//    public ResourceMeta getMeta(@Nonnull @PathVariable String resourceType){
//        return resourceMetaService.getResourceMeta(resourceType);
//    }

    @PostMapping("/dp/aclmeta/init")
    public List<ResourceMeta> initMeta(){
        //初始化resource metadata.
        resourceMetaService.initData();
        //初始化data permission settings.
        resourceSettingService.initSettings();
        //默认需要将folder设置为private.
        SetGlobalAccessRequest request = new SetGlobalAccessRequest();
        request.setResourceType("folder");
        request.setAccessPermission("private");

        ArrayList<SetGlobalAccessRequest> al = new ArrayList<>();
        al.add(request);
        settingService.setGlobalAccess(al);

        return resourceMetaService.getAllResourceMeta();
    }

    @PostMapping("/dp/aclmeta/clean")
    public void cleanMeta(){
         resourceMetaService.cleanData();
    }

    @PostMapping("/dp/aclmeta/update")
    public ResourceMetaDto updateMeta(@Nonnull @RequestBody ResourceMetaDto dto) {
        return resourceMetaService.updateData(dto);
    }

    @PostMapping("/dp/aclmeta/updateEntity")
    public ResourceMetaDto updateEntity(@Nonnull @RequestBody UpdateEntityDto dto) {
        return resourceMetaService.updateEntity(dto.getObjectName(), dto.getEntityName());
    }

    @PostMapping("/dp/aclmeta/batchUpdateEntity")
    public List<ResourceMetaDto> batchUpdateEntity(@Nonnull @RequestBody  List<UpdateEntityDto> dto) {
        List<ResourceMetaDto> results = new ArrayList<>();
        dto.forEach(updateEntityDto -> {
            ResourceMetaDto res = resourceMetaService.updateEntity(updateEntityDto.getObjectName(), updateEntityDto.getEntityName());
            results.add(res);
        });
        return results;
    }

    @GetMapping("/dp/aclmeta/{objectName}")
    public ResourceMetaDto getMeta(@Nonnull @PathVariable String objectName) {
        return resourceMetaService.getData(objectName);
    }

    @GetMapping("/dp/aclmeta-debug")
    @Hidden
    public List<ResourceMetaDto> listMetaDebug(@RequestParam String group, @RequestParam(required =
            false) String objectNames) {
        return listMeta(group, objectNames);
    }
    @GetMapping("/dp/aclmeta")
    public List<ResourceMetaDto> listMeta(@RequestParam(required = false) String group, @RequestParam(required = false) String objectNames) {
        log.info("listMeta() group: {}, objectNames: {}", group, objectNames);
        Map<String,String> filter = new HashMap<>();
        filter.put("data.permissionEnabled", "true");

        if(StringUtils.isNotBlank(objectNames)){
            filter.put("objectName", objectNames);
        }

        if(StringUtils.isNotBlank(group)){
            filter.put("data.dataPermission.group", group);
        }
        log.info("listMeta() filter: {}", filter);

        return resourceMetaService.getResourceMetaDtosByFilter(filter);
    }

    @GetMapping("/dp/resource/get")
    public Object getEntity(@RequestParam String resourceType, @RequestParam String id){

        final Object[] response = new Object[1];
        DataSourceLookupHelper.withLookupKey("main", () -> {
            response[0] = resourceEntityService.getResourceEntity(resourceType, id);
        });

        return response[0];
    }

}

