package com.convertlab.foundation.kvstore.service;

import javax.annotation.Nullable;

import com.convertlab.foundation.kvstore.dto.KeyValuesPair;
import com.convertlab.foundation.library.hbase.core.HbaseColumnSchema;

import java.util.List;
import java.util.Map;

public interface HbaseStoreService {

    List<KeyValuesPair> batchSelect(String tableName, String columnFamily, List<String> rowKeys,
                                    List<String> columns, List<HbaseColumnSchema> columnSchemas) throws Exception;

    void batchInsertOrUpdate(String tableName, String columnFamily, List<KeyValuesPair> kvPairs, List<HbaseColumnSchema> columnSchemas) throws Exception;

    void batchDelete(String tableName, String columnFamily, List<KeyValuesPair> kvPairs, List<HbaseColumnSchema> columnSchemas) throws Exception;

    Map<String, Map<String, Long>> batchIncrement(String tableName, String columnFamily, List<KeyValuesPair> kvPairs, List<HbaseColumnSchema> columnSchemas) throws Exception;

    @Nullable
    String getHbaseTableName(String entityName) throws Exception;

    List<HbaseColumnSchema> getHbaseColumnSchemas(String entityName) throws Exception;

    @Nullable
    String getHbaseColumnFamily(String entityName) throws Exception;
}
