package com.convertlab.foundation.gdmmeta.model.metaobject;

import javax.annotation.Nonnull;

/**
 * udo event meta 包括三部分：
 * 1. udo 系统事件
 *   udo 系统事件在 event.json 中定义
 * 2. udo 插件事件
 *   udo 插件事件在 udo_meta, meta类型是 @see UdoMeta.UDO_META_TYPE.UDO_EVENT_PLUGIN
 * 3. udo 自定义事件
 *   udo 自定义事件在 udo_meta, meta类型是 @see UdoMeta.UDO_META_TYPE.UDO_EVENT
 *
 *  UdoEventMetaObject 用于处理保存在 udo_meta 中的 udo 自定义事件 和 udo 插件事件
 */
public interface UdoEventMetaObject extends ProfileEventMetaObject{

    String UDO_EVENT_TABLE_NAME = "general_event";

    @Nonnull
    @Override
    default String getTableName() {
        return UDO_EVENT_TABLE_NAME;
    }

    static String formatUdoEventName(String objId, String oraEntityName) {
        return String.format("%s_%s", objId, oraEntityName);
    }

}
