package com.convertlab.foundation.datapermission.util;

import com.convertlab.foundation.datapermission.entity.BaseResourceAccessEntity;
import com.convertlab.foundation.library.datapermission.ResourceAccessDto;
import org.springframework.beans.BeanUtils;

import javax.annotation.Nonnull;

public class ResourceAccessDtoConverter {
    @Nonnull
    public static BaseResourceAccessEntity convertToEntity(@Nonnull ResourceAccessDto dto) {
        BaseResourceAccessEntity entity = new BaseResourceAccessEntity();
        BeanUtils.copyProperties(dto, entity);
        if(entity.getUuid() == null){
            entity.setUuid(java.util.UUID.randomUUID().toString());
        }
        return entity;
    }
}
