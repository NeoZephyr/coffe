package com.convertlab.foundation.user.service;

import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.jdbc.core.OLTPJdbcTemplate;
import com.convertlab.foundation.library.utils.BeanUtils;
import com.convertlab.foundation.user.entity.User;
import com.convertlab.foundation.user.entity.UserInfo;
import com.convertlab.foundation.user.mapper.UserMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@DataSourceLookup("main")
@Transactional
@Slf4j
public class UserService {

    final UserMapper userMapper;
    final OLTPJdbcTemplate oltpJdbcTemplate;

    public UserService(UserMapper userMapper, OLTPJdbcTemplate oltpJdbcTemplate) {
        this.userMapper = userMapper;
        this.oltpJdbcTemplate = oltpJdbcTemplate;
    }


    public boolean isAdmin(long userId){
        if(isUserAdmin(userId) || isSupportUser(userId) || isUserGroupAdmin(userId)){
            return true;
        }
        return false;
    }

    public boolean isUserAdmin(long userId){
        String sqlTemplate = "select role_key from user_role where user_id = ? and (role_key = 'admin' || role_key = 'tenantAdmin' ) ";
        List rs = oltpJdbcTemplate.queryForList(sqlTemplate, new Object[]{userId});
        if(rs.size() > 0){
            return true;
        }
        return false;
    }

    public boolean isSupportUser(long userId){
        String sqlTemplate = "select user_id from support_user where user_id = ? ";
        List rs = oltpJdbcTemplate.queryForList(sqlTemplate, new Object[]{userId});
        if(rs.size() > 0){
            return true;
        }
        return false;
    }

    public boolean isUserGroupAdmin(long userId){
        String sqlTemplate = "select ugr.role_key from user_group_map ugm join user_group_role ugr on ugm.group_code = ugr.group_code " +
                "where ugm.user_id = ? and (ugr.role_key = 'admin' || ugr.role_key = 'tenantAdmin' ) ";
        List rs = oltpJdbcTemplate.queryForList(sqlTemplate, new Object[]{userId});
        if(rs.size() > 0){
            return true;
        }
        return false;
    }

    public List<User> getUserByIdInList(List<Long> userIds){
        if(CollectionUtils.isEmpty(userIds)){
            return new ArrayList<>();
        }

        String placeholders = userIds.stream()
                .map(userId -> "?")
                .collect(Collectors.joining(", "));
        placeholders = "(" + placeholders + ")";

        //先查询UserTenant, 获取该tenant可以使用的UserId List
        String sqlTemplate = "select user_id from user_tenant where user_id in " + placeholders;
            List<Map<String, Object>> rs = oltpJdbcTemplate.queryForList(sqlTemplate, userIds.toArray());

        List<Long> tenantAvaiableUserIds = rs.stream()
                .map(map -> NumberUtils.toLong(map.get("user_id").toString()))
                .collect(Collectors.toList());

        if(tenantAvaiableUserIds.size() > 0){

            List<User> users = userMapper.getUserByIdList(tenantAvaiableUserIds, "");
//            sqlTemplate = "select * from user where id in " + placeholders;
//            List<User> users = oltpJdbcTemplate.query(sqlTemplate, new BeanPropertyRowMapper<>(User.class), tenantAvaiableUserIds.toArray());
            return users;
        }else {
            return  new ArrayList<>();
        }
    }

    public List<User>  findAllByEmailInList(List<String> emails){
        String placeholders = emails.stream()
                .map(email -> "?")
                .collect(Collectors.joining(", "));
        placeholders = "(" + placeholders + ")";

        String sqlTemplate = "select id from user where email in " + placeholders;
        List<Long> idList = oltpJdbcTemplate.queryForList(sqlTemplate, Long.class, emails.toArray());

        return getUserByIdInList(idList);
    }

    public List<User> findAllByPhoneInList(List<String> phones){
        String placeholders = phones.stream()
                .map(mobile -> "?")
                .collect(Collectors.joining(", "));
        placeholders = "(" + placeholders + ")";

        String sqlTemplate = "select id from user where phone in " + placeholders;
        List<Long> idList = oltpJdbcTemplate.queryForList(sqlTemplate, Long.class, phones.toArray());

        return getUserByIdInList(idList);
    }

    public UserInfo getUserInfo(Long userId){

        List<Long> userIds = new ArrayList<>();
        userIds.add(userId);
        List<User> users = this.getUserByIdInList(userIds);
        if(!org.apache.commons.collections.CollectionUtils.isEmpty(users)){
            User user = users.get(0);
            UserInfo userInfo = new UserInfo();
            org.springframework.beans.BeanUtils.copyProperties(user,userInfo);
            return userInfo;
        }
        return null;

    }


}
