package com.convertlab.foundation.misc.configure;

import javax.annotation.Nonnull;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import io.swagger.v3.oas.models.PathItem;
import io.swagger.v3.oas.models.Paths;
import io.swagger.v3.oas.models.examples.Example;
import io.swagger.v3.oas.models.media.MediaType;
import io.swagger.v3.oas.models.responses.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springdoc.core.customizers.OpenApiCustomiser;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.InputStreamReader;
import java.net.URL;
import java.util.Map;

@Configuration
@Slf4j
public class SwaggerExampleConfiguration {
    @Nonnull
    @Bean
    OpenApiCustomiser applyStandardOpenAPIModifications() {
        return openApi -> {
            Paths paths = new Paths();
            openApi.getPaths().entrySet().stream()
                    .sorted(Map.Entry.comparingByKey())
                    .forEach(stringPathItemEntry -> {
                        paths.addPathItem(stringPathItemEntry.getKey(),
                                addExamples(stringPathItemEntry.getValue()));
                    });
            openApi.setPaths(paths);
        };
    }

    private void appendExampleToMedia(@Nonnull MediaType c) {
        if(c.getExamples()!= null){
            c.getExamples().keySet().forEach(key -> {
                Example example = (Example)c.getExamples().get(key);
                if(example.getValue() != null && example.getValue() instanceof String
                        && StringUtils.isNotBlank((String) example.getValue())){
                    String fileName = (String) example.getValue();
                    // 判断从文件加载接口样例
                    if(fileName.startsWith("@") && fileName.lastIndexOf(".json") > 0){
                        try {
                            URL resource = Thread.currentThread().getClass().getResource(fileName.replaceFirst("@","/"));
                            if(resource!= null){
                                Object exampleData =  new ObjectMapper().readTree(new InputStreamReader(resource.openStream(), "UTF-8"));
                                if(exampleData instanceof ArrayNode){
                                    example.setValue((ArrayNode) exampleData);
                                }else if(exampleData instanceof ObjectNode){
                                    example.setValue((ObjectNode) exampleData);
                                }
                            }
                        } catch (Exception e) {
                            log.error("failed to load {} example", fileName, e);
                            throw new RuntimeException(e);
                        }
                    }
                }
            });
        }
    }

    /**
     * 根据资源文件，填充RequestBody的Example
     * @param pathItem 文件地址，以@开始, .json或者.json5 结束
     * @return
     */
    @Nonnull
    private PathItem addExamples(@Nonnull PathItem pathItem) {
        if(pathItem.getPost() !=null && pathItem.getPost().getRequestBody() != null && pathItem.getPost().getRequestBody().getContent() != null)  {
            //Note you can also Do this to APIResponses to insert info from a file into examples in say, a 200 response.
            pathItem.getPost().getRequestBody().getContent().values().stream()
                    .forEach(c -> appendExampleToMedia(c));
        }else{
            return pathItem;
        }
        ApiResponses responses = null;
        if(pathItem.getPost() !=null){
            responses = pathItem.getPost().getResponses();
        }else if(pathItem.getGet() != null){
            responses = pathItem.getGet().getResponses();
        }else if(pathItem.getDelete() != null){
            responses = pathItem.getDelete().getResponses();
        }else if(pathItem.getPut() != null){
            responses = pathItem.getPut().getResponses();
        }
        if(responses != null){
            responses.values().stream().forEach(r -> {
                if(r != null && r.getContent() != null && r.getContent().values() != null) {
                    r.getContent().values().stream().forEach(c -> appendExampleToMedia(c));
                }
            });
        }
        return pathItem;
    }
}
