package com.convertlab.foundation.datapermission.model;


import lombok.Getter;

import javax.validation.constraints.NotNull;

@Getter
public class SetGlobalAccessRequest {
    @NotNull
    String resourceType;
    @NotNull
    String accessPermission;

    public void setResourceType(String resourceType) {
        this.resourceType = resourceType;
    }

    public void setAccessPermission(String accessPermission) {
        this.accessPermission = accessPermission;
    }
}
