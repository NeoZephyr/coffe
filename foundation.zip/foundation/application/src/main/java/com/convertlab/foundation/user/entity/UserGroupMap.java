package com.convertlab.foundation.user.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import javax.validation.constraints.Size;


@Data
public class UserGroupMap {

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @TableField(fill = FieldFill.INSERT, update = "%s+1", updateStrategy = FieldStrategy.IGNORED)
    private Integer version;

    private Long userId;

    @Size(max = 255)
    private String groupCode;

    public UserGroupMap(Long userId, String groupCode) {
        this.userId = userId;
        this.groupCode = groupCode;
    }

}