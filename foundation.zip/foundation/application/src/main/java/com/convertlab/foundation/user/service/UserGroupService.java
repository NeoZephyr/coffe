package com.convertlab.foundation.user.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.convertlab.data.job.core.handler.annotation.ClJob;
import com.convertlab.data.job.core.util.data.BizJobClient;
import com.convertlab.data.job.core.util.data.JobData;
import com.convertlab.foundation.datapermission.service.ResourceAccessServiceWrapper;
import com.convertlab.foundation.library.business.audit.AuditEvent;
import com.convertlab.foundation.library.business.audit.AuditEventType;
import com.convertlab.foundation.library.business.audit.AuditOperations;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.datapermission.GrantedSubjectType;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.jdbc.core.OLTPJdbcTemplate;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.user.entity.User;
import com.convertlab.foundation.user.entity.UserGroup;
import com.convertlab.foundation.user.entity.UserGroupMap;
import com.convertlab.foundation.user.entity.UserTenant;
import com.convertlab.foundation.user.mapper.UserGroupMapMapper;
import com.convertlab.foundation.user.mapper.UserGroupMapper;
import com.convertlab.foundation.user.mapper.UserMapper;
import com.convertlab.foundation.user.model.*;
import com.google.common.collect.Multimaps;
import lombok.val;
import org.slf4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Nonnull;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.*;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.baomidou.mybatisplus.core.toolkit.Wrappers.lambdaQuery;
import static com.convertlab.foundation.user.utils.Persistence.genGroupCode;
import static org.slf4j.LoggerFactory.getLogger;


@Service
@DataSourceLookup("main")
public class UserGroupService {


    private static final Logger log = getLogger(UserGroupService.class);
    private static final String ENTITY_NAME = "userGroup";
    private final OLTPJdbcTemplate jdbcTemplate;
    private final UserGroupMapper userGroupMapper;
    private final UserGroupMapMapper userGroupMapMapper;
    private final UserMapper userMapper;
    private final AuditOperations auditor;
    private final OLTPJdbcTemplate oltpJdbcTemplate;
    private final ResourceAccessServiceWrapper resourceAccessServiceWrapper;
    private final BizJobClient bizJobClient;
    private final String DP_DELETE_USER_GROUP = "dp_delete_user_group";

    @Nonnull
    private AuditEvent<UserGroup> newAuditLog(@Nonnull AuditEventType operationType, @Nonnull @NotNull UserGroup currentValue, UserGroup oldValue, UserGroup newValue) {
        return new AuditEvent<>(operationType, ENTITY_NAME, currentValue.getId().toString(), currentValue.getName(), oldValue, newValue);
    }

    public UserGroupService(UserGroupMapper userGroupMapper, UserMapper userMapper, UserGroupMapMapper userGroupMapMapper,
                            AuditOperations auditor, OLTPJdbcTemplate jdbcTemplate, OLTPJdbcTemplate oltpJdbcTemplate, ResourceAccessServiceWrapper resourceAccessServiceWrapper, BizJobClient bizJobClient) {
        this.auditor = auditor;
        this.jdbcTemplate = jdbcTemplate;
        this.userGroupMapper = userGroupMapper;
        this.userMapper = userMapper;
        this.userGroupMapMapper = userGroupMapMapper;
        this.oltpJdbcTemplate = oltpJdbcTemplate;
        this.resourceAccessServiceWrapper = resourceAccessServiceWrapper;
        this.bizJobClient = bizJobClient;
    }

    public Page<UserGroup> index(String name, Page<UserGroup> page) {
        return userGroupMapper.selectPage(page,
                lambdaQuery(UserGroup.class).like(UserGroup::getName, "%" + name + "%").orderByDesc(UserGroup::getLastUpdated));
    }

    @Nonnull
    public List<String> indexByUser(Long userId) {
        return jdbcTemplate.queryForList("select ugm.group_code from user_group_map ugm where ugm.user_id = ?", String.class, userId);
    }

    public List<UserGroupCount> userCount(List<String> groupCodes) {
        if (groupCodes == null || groupCodes.isEmpty()) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_004_000004", new String[]{"groupCodes"}, 400);
        }

        String sql = String.format("select ugm.group_code, count(ugm.user_id) from user_group_map ugm where ugm.group_code in ( %s ) and ugm.user_id in (select id from user_tenant union select id from user) group by ugm.group_code", collectionParam(groupCodes));
        return jdbcTemplate.query(sql,
            (rs, rowNum) -> new UserGroupCount(rs.getString(1), rs.getLong(2)),
            composeArgsArray(groupCodes));
    }

    @Nonnull
    static public <T, K> List<T> groupReduce(@Nonnull List<T> xs, @Nonnull Function<T, K> key, BinaryOperator<T> reducer) {
        // groupBy never produce empty list
        //noinspection OptionalGetWithoutIsPresent
        return Multimaps.index(xs, key::apply).asMap().values().stream().map(list -> list.stream().reduce(reducer).get()).collect(Collectors.toList());
    }

    @Nonnull
    public List<UserDeptRoleComposite> userList(@NotBlank String groupCode, String name) {
        List<UserGroupMap> userGroupMaps = userGroupMapMapper.getUserGroupMapByGroupCode(groupCode);

        if (userGroupMaps.isEmpty()) {
            return Collections.emptyList();
        }

        List<UserDeptRoleComposite> userDeptRoles =jdbcTemplate.query("SELECT distinct ut.user_id, '', '', '', '', d.name, r.name " +
            "FROM (select user_id from user_tenant union select id as user_id from user) ut " +
            "    INNER JOIN user_group_map ugm ON ut.user_id = ugm.user_id " +
            "    INNER JOIN user_role ur ON ut.user_id = ur.user_id " +
            "    INNER JOIN role r ON ur.role_key = r.role_key " +
            "    INNER JOIN user_dept ud ON ut.user_id = ud.user_id " +
            "    INNER JOIN dept d ON ud.dept_code = d.code " +
            "WHERE ut.user_id not in (select su.id from support_user su) " +
            "    AND ugm.group_code = ?", (rs, rowNum) -> new UserDeptRoleComposite(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7)), groupCode);

        if (userDeptRoles == null || userDeptRoles.isEmpty()) {
            return Collections.emptyList();
        }

        List<UserDeptRoleComposite> userGrouped = groupReduce(userDeptRoles, u -> u.id, UserDeptRoleComposite::combineDeptAndRole);

        List<User> users= userMapper.getUserByIdList(userGroupMaps.stream().map(UserGroupMap::getUserId).collect(Collectors.toList()), name);

        return userGrouped.stream()
                .filter(userDeptRole -> users.stream()
                        .anyMatch(user -> user.getId().equals(userDeptRole.id)))
                .peek(userDeptRole -> {
                    Optional<User> userOptional = users.stream().filter(u -> u.getId().equals(userDeptRole.id)).findFirst();
                    userOptional.ifPresent(userDeptRole::fillInUserData);
                }).collect(Collectors.toList());
    }

    @Nonnull
    @Transactional
    public JoinLeaveUserGroupResponse join(@NotBlank String groupCode, @Nonnull @NotEmpty List<Long> userList) {
        if (!userGroupMapper.exists(lambdaQuery(UserGroup.class).eq(UserGroup::getCode, groupCode))) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_004_000002", new String[]{groupCode}, 404);
        }

        List<Long> users = userMapper.getUserTenantByIdList(userList);
        List<Long> diff = new ArrayList<>(userList);
        diff.removeAll(users);
        if (!diff.isEmpty()) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_004_000001", new String[]{diff.stream().map(Object::toString).collect(Collectors.joining(","))}, 404);
        }

        val mappings = users.stream()
            .map(user -> new UserGroupMap(user, groupCode))
            .filter(userGroupMap -> !userGroupMapMapper.exists(lambdaQuery(UserGroupMap.class).eq(UserGroupMap::getUserId, userGroupMap.getUserId()).eq(UserGroupMap::getGroupCode, userGroupMap.getGroupCode())))
            .collect(Collectors.toList());

        for (val mapping : mappings) {
            userGroupMapMapper.insert(mapping);
        }
        log.info("[ D&P ] add access control list count: {}", mappings.size());
        return new JoinLeaveUserGroupResponse(groupCode);
    }

    @Nonnull
    @Transactional
    public JoinLeaveUserGroupResponse leave(@NotBlank String groupCode, @NotEmpty List<Long> userList) {
        if (userList == null || userList.isEmpty()) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_004_000004", new String[]{"userList"}, 400);
        }
        if (!userGroupMapper.exists(lambdaQuery(UserGroup.class).eq(UserGroup::getCode, groupCode))) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_004_000002", new String[]{groupCode}, 404);
        }

        String sql = String.format("delete from user_group_map where group_code = ? and user_id in ( %s )", collectionParam(userList));
        Object[] args = composeArgsArray(groupCode, userList);

        int n = jdbcTemplate.update(sql, args);
        log.info("[ D&P ] remove access control list count: ${}", n);
        return new JoinLeaveUserGroupResponse(groupCode);

    }

    private static String collectionParam(Collection<?> collection) {
        return collection.stream().map(code -> "?").collect(Collectors.joining(","));
    }

    @NotNull
    private static Object[] composeArgsArray(Object... args) {
        List<Object> argsArray = new ArrayList<>();
        Stream.of(args).forEach(arg -> {
            if (arg instanceof Collection) {
                Collection<?> collection = (Collection<?>) arg;
                argsArray.addAll(collection);
            } else {
                argsArray.add(arg);
            }
        });
        return argsArray.toArray();
    }

    @Nonnull
    @Transactional
    public UserGroupDto save(@Nonnull @NotNull SaveUserGroupRequest request) {
        UserGroup entity = new UserGroup(request.name, genGroupCode(), request.remark);
        userGroupMapper.insert(entity);
        auditor.log(newAuditLog(AuditEventType.CREATE_ENTITY, entity, null, entity));
        return UserGroupDto.fromEntity(entity);
    }

    @Nonnull
    public UserGroup show(@NotBlank String groupCode) {
        UserGroup userGroup = userGroupMapper.selectOne(lambdaQuery(UserGroup.class).eq(UserGroup::getCode, groupCode));
        if (userGroup == null) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_004_000002", new String[]{groupCode}, 404);
        }

        return userGroup;
    }

    @Nonnull
    @Transactional
    public UserGroupDto update(@NotBlank String groupCode, @Nonnull @NotNull SaveUserGroupRequest request) {
        val conflictedGroup = Optional.ofNullable(userGroupMapper.selectOne(lambdaQuery(UserGroup.class).eq(UserGroup::getName, request.name)));
        boolean conflict = conflictedGroup.map(group -> !Objects.equals(group.getCode(), groupCode)).orElse(false);
        if (conflict) {
            throw new BusinessException(CommonErrors.DUPLICATED_KEY, "MSG_004_000003", new String[]{request.name}, 409);
        }

        val entity = userGroupMapper.selectOne(lambdaQuery(UserGroup.class).eq(UserGroup::getCode, groupCode));
        if (entity == null) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_004_000002", new String[]{groupCode}, 404);
        }

        entity.setName(request.name);
        entity.setRemark(request.remark);
        userGroupMapper.updateById(entity);
        return UserGroupDto.fromEntity(entity);
    }

    @Nonnull
    @Transactional
    public JoinLeaveUserGroupResponse delete(@NotBlank String groupCode) {
        val group = userGroupMapper.selectOne(lambdaQuery(UserGroup.class).eq(UserGroup::getCode, groupCode));

        if (group == null) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_004_000002", new String[]{groupCode}, 404);
        }

        userGroupMapper.deleteById(group);
        auditor.log(newAuditLog(AuditEventType.DELETE_ENTITY, group, group, null));
        Map<String, Object> message = new HashMap<>();
        message.put("id", group.getId());
        message.put("groupCode", group.getCode());
        message.put("tenantId", TenantContextHolder.getTenantId());

        JobData jobData = JobData.builder()
                .jobType(DP_DELETE_USER_GROUP)
                .bizUuid(UUID.randomUUID().toString())
                .appName("foundation")
                .jobHandler(DP_DELETE_USER_GROUP)
                .needNotification(true)
                .jobParameters(JsonUtils.instance().obj2Json(message))
                .build();

        bizJobClient.createAndStartBizJob(jobData);

        return new JoinLeaveUserGroupResponse(groupCode);
    }

    @ClJob(DP_DELETE_USER_GROUP)
    void deleteAssociatedAcls(JobData jobData) {
        Map<String, Object> message = JsonUtils.instance().convertToMap(jobData.getJobParameters());
        resourceAccessServiceWrapper.delete(GrantedSubjectType.SUBJECT_TYPE_GROUP, (String) message.get("deptCode"));
    }

    @Nonnull
    @Transactional
    public List<UserGroup> getUserGroupByCodeList(List<String> codeList){
        return userGroupMapper.getUserGroupByCodeList(codeList);
    }


    @Nonnull
    @Transactional
    public List<UserGroup> getUserGroupByIdList(List<Long> idList){
        return userGroupMapper.getUserGroupByIdList(idList);
    }

    @Nonnull
    @Transactional
    public List<UserGroupMap> getUserGroupMapByUserId(Long userId){
        return userGroupMapMapper.getUserGroupMapByUserId(userId);
    }
}
