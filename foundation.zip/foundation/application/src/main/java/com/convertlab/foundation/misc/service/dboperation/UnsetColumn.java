package com.convertlab.foundation.misc.service.dboperation;


import com.convertlab.foundation.library.sqlprocessor.SQLDialect;
import com.convertlab.foundation.misc.dto.CastAndCopyColumnRequest;

import java.sql.Connection;

public class UnsetColumn extends AbstractDbOperation {
    public UnsetColumn(CastAndCopyColumnRequest args, Connection connection, SQLDialect sqlDialect) {
        super(args, connection, sqlDialect);
    }

    @Override
    protected String buildSql() {
        String sql = "update `" + args.getTableName() + "` set `" + args.getFromColumn() + "` = NULL";
        sql += buildWhere(args);
        return sql;
    }
}
