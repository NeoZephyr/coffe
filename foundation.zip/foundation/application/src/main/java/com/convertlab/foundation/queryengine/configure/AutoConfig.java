package com.convertlab.foundation.queryengine.configure;

import com.convertlab.common.crypto.client.CryptoClient;
import com.convertlab.foundation.library.business.feature.FeatureClient;
import com.convertlab.foundation.library.filter.FilterJsonParser;
import com.convertlab.foundation.library.filter.v4.FilterJsonPreprocessor;
import com.convertlab.foundation.library.filter.v4.GdmFilterNodeParserRegistry;
import com.convertlab.foundation.library.filter.v4.attrcomp.AttrCompareNodeParser;
import com.convertlab.foundation.library.filter.v4.preprocessor.AssignParentNode;
import com.convertlab.foundation.library.filter.v4.preprocessor.ColumnToRowTableVisitor;
import com.convertlab.foundation.library.filter.v4.preprocessor.ReorgRelationNode;
import com.convertlab.foundation.library.filter.v4.preprocessor.SimplifyLogicalNode;
import com.convertlab.foundation.library.filter.v4.timeline.FilterJsonV4WithTimelineParser;
import com.convertlab.foundation.library.filter.v4.timeline.GdmFilterV4WithTimeline;
import com.convertlab.foundation.library.filter.v4.timeline.TimelinePreProcessor;
import com.convertlab.foundation.library.gdmmeta.client.GdmERMetaRtClient;
import com.convertlab.foundation.library.gdmmeta.client.GdmMetaHelper;
import com.convertlab.foundation.library.gdmmeta.client.GdmStorageMetaRtClient;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.jdbc.core.BaseJdbcTemplate;
import com.convertlab.foundation.library.jdbc.core.OLAPJdbcTemplate;
import com.convertlab.foundation.library.sqlprocessor.processor.visibility.client.ACLInformationClient;
import com.convertlab.foundation.library.sqlprocessor.processor.visibility.client.ResourceInformationClient;
import com.convertlab.foundation.library.sqlprocessor.processor.visibility.client.UserInformationClient;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.queryengine.service.GdmQueryService;
import com.convertlab.foundation.queryengine.service.PolymorphismGdmQueryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.convert.ConversionService;

import javax.annotation.Nonnull;
import javax.sql.DataSource;

@Configuration("queryEngineAutoConfig")
public class AutoConfig {
    @Bean
    public GdmFilterNodeParserRegistry filterNodeParserRegistry() {
        return GdmFilterNodeParserRegistry.getInstance();
    }

    @Nonnull
    @Bean
    public FilterJsonPreprocessor filterJsonPreprocessor(@Nonnull JsonUtils jsonUtils, @Nonnull GdmMetaHelper gdmMetaHelper) {
        SimplifyLogicalNode simplifyLogicalNode = new SimplifyLogicalNode();
        ReorgRelationNode reorgRelationNode = new ReorgRelationNode();
        AssignParentNode assignParentNode = new AssignParentNode();
        ColumnToRowTableVisitor columnToRowTableVisitor = new ColumnToRowTableVisitor();
        return new TimelinePreProcessor(simplifyLogicalNode, reorgRelationNode, assignParentNode, columnToRowTableVisitor, jsonUtils, gdmMetaHelper);
    }

    @Nonnull
    @Bean
    @ConditionalOnMissingBean(GdmMetaHelper.class)
    public GdmMetaHelper gdmMetaHelper(GsMetaClient gsMetaClient) {
        GdmERMetaRtClient gdmERMetaRtClient = new GdmERMetaRtClient(gsMetaClient, gsMetaClient);
        return new GdmMetaHelper(gdmERMetaRtClient);
    }

    @Nonnull
    @Bean("BindingVarParser")
    @Primary
    public FilterJsonParser<GdmFilterV4WithTimeline> filterJsonParserWithBindingVars(@Nonnull GdmMetaHelper gdmMetaHelper, @Nonnull FilterJsonPreprocessor filterJsonPreprocessor, @Nonnull GdmFilterNodeParserRegistry filterNodeParserRegistry, @Nonnull JsonUtils jsonUtils) {
        AttrCompareNodeParser attrCompareNodeParser = new AttrCompareNodeParser(gdmMetaHelper, jsonUtils);
        return new FilterJsonV4WithTimelineParser(gdmMetaHelper, true, filterJsonPreprocessor, filterNodeParserRegistry, attrCompareNodeParser);
    }

    @Nonnull
    @Bean("FilterJsonParser")
    public FilterJsonParser<GdmFilterV4WithTimeline> filterJsonParser(@Nonnull GdmMetaHelper gdmMetaHelper, @Nonnull FilterJsonPreprocessor filterJsonPreprocessor, @Nonnull GdmFilterNodeParserRegistry filterNodeParserRegistry, @Nonnull JsonUtils jsonUtils) {
        AttrCompareNodeParser attrCompareNodeParser = new AttrCompareNodeParser(gdmMetaHelper, jsonUtils);
        return new FilterJsonV4WithTimelineParser(gdmMetaHelper, false, filterJsonPreprocessor, filterNodeParserRegistry, attrCompareNodeParser);
    }

    @Nonnull
    @Bean
    public JsonUtils jsonUtils(@Nonnull GdmFilterNodeParserRegistry filterNodeParserRegistry) {
        return JsonUtils.instance(filterNodeParserRegistry.getObjectMapper());
    }

    @Nonnull
    @Bean("OlapJdbcTemplate")
    public BaseJdbcTemplate olapJdbcTemplate(@Nonnull @Qualifier("impalaDataSource") DataSource dataSource,
                                             @Autowired(required = false) FeatureClient featureClient,
                                             GdmStorageMetaRtClient storageMetaRtClient,
                                             @Autowired(required = false) UserInformationClient userInformationClient,
                                             @Autowired(required = false) ResourceInformationClient resourceInformationClient,
                                             @Autowired(required = false) ACLInformationClient aclInformationClient,
                                             @Autowired(required = false) ConversionService conversionService,
                                             @Autowired(required = false) CryptoClient cryptoClient) {
        return new OLAPJdbcTemplate(dataSource,
                true,
                featureClient,
                storageMetaRtClient,
                userInformationClient,
                resourceInformationClient,
                aclInformationClient,
                conversionService,
                cryptoClient);
    }

    @Bean
    public GdmQueryService gdmQueryService(@Qualifier("OlapJdbcTemplate") final BaseJdbcTemplate olapJdbcTemplate,
                                           @Qualifier("oltpJdbcTemplate") final BaseJdbcTemplate oltpJdbcTemplate,
                                           @Qualifier("BindingVarParser") final FilterJsonParser<GdmFilterV4WithTimeline> bindingVarsParser,
                                           final JsonUtils jsonUtils,
                                           final GdmMetaHelper gdmMetaHelper) {
        return new PolymorphismGdmQueryService(olapJdbcTemplate,oltpJdbcTemplate, bindingVarsParser, jsonUtils, gdmMetaHelper);
    }
}
