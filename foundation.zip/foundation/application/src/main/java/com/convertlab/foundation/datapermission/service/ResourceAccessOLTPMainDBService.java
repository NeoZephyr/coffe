package com.convertlab.foundation.datapermission.service;

import com.convertlab.foundation.datapermission.entity.BaseResourceAccessEntity;
import com.convertlab.foundation.library.datapermission.ResourceAccessDto;
import com.convertlab.foundation.library.datapermission.GrantedSubjectType;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
@Slf4j
@DataSourceLookup("main")
public class ResourceAccessOLTPMainDBService implements BaseResourceAccessService {

    private final ResourceAccessOLTPService resourceAccessOLTPService;

    public ResourceAccessOLTPMainDBService(ResourceAccessOLTPService resourceAccessOLTPService) {
        this.resourceAccessOLTPService = resourceAccessOLTPService;
    }

    @Override
    public BaseResourceAccessEntity save(String tableName, ResourceAccessDto dto) {
        return getService().save(tableName, dto);
    }

    @Override
    public void batchSave(String tableName, List<ResourceAccessDto> dtos) {
        getService().batchSave(tableName, dtos);
    }

    @Override
    public void update(String tableName, String uuid, ResourceAccessDto dto) {
        getService().update(tableName, uuid, dto);
    }

    @Override
    public void batchUpdate(String tableName, List<ResourceAccessDto> dtos) {
        getService().batchUpdate(tableName, dtos);
    }

    @Override
    public void upsert(String tableName, ResourceAccessDto dto) {
        getService().upsert(tableName, dto);
    }

    @Override
    public void batchUpsert(String tableName, List<ResourceAccessDto> dtos) {
        getService().batchUpsert(tableName, dtos);
    }

    @Override
    public BaseResourceAccessEntity getById(String tableName, String uuid) {
        return getService().getById(tableName, uuid);
    }

    @Override
    public void deleteById(String tableName, String uuid) {
        getService().deleteById(tableName, uuid);
    }

    @Override
    public void batchDelete(@NotNull String tableName, List<BaseResourceAccessEntity> entities) {
        getService().batchDelete(tableName, entities);
    }

    @Override
    public void delete(String tableName, String resourceType, String resourceCode) {
        getService().delete(tableName, resourceType, resourceCode);
    }

    @Override
    public void delete(String tableName, String resourceType, String resourceCode, GrantedSubjectType grantedSubjectType, String grantedSubjectCode) {
        getService().delete(tableName, resourceType, resourceCode, grantedSubjectType, grantedSubjectCode);
    }

    @Override
    public void delete(String tableName, String resourceType, GrantedSubjectType grantedSubjectType, String grantedSubjectCode) {
        getService().delete(tableName, resourceType, grantedSubjectType, grantedSubjectCode);
    }

    @Override
    public void delete(String tableName, GrantedSubjectType grantedSubjectType, String grantedSubjectCode) {
        getService().delete(tableName, grantedSubjectType, grantedSubjectCode);
    }

    @Override
    public List<BaseResourceAccessEntity> list(String tableName, String resourceType, String resourceCode, GrantedSubjectType grantedSubjectType, String grantedSubjectCode) {
        return getService().list(tableName, resourceType, resourceCode, grantedSubjectType, grantedSubjectCode);
    }

    @Override
    public List<BaseResourceAccessEntity> list(String tableName, String resourceType, String resourceCode) {
        return getService().list(tableName, resourceType, resourceCode);
    }

    @Nullable
    @Override
    public List<BaseResourceAccessEntity> list(String tableName, String resourceType, List<String> resourceCodeList) {
        return getService().list(tableName, resourceType, resourceCodeList);
    }

    @Nullable
    @Override
    public List<BaseResourceAccessEntity> list(String tableName, String resourceType, Map<GrantedSubjectType, List<String>> grantedSubjectTypeListMap) {
        return getService().list(tableName, resourceType, grantedSubjectTypeListMap);
    }

    @Override
    public List<BaseResourceAccessEntity> list(String tableName, String resourceType, GrantedSubjectType grantedSubjectType, List<String> grantedSubjectCodeList) {
        return getService().list(tableName, resourceType, grantedSubjectType, grantedSubjectCodeList);
    }

    @Override
    public BaseResourceAccessEntity getByKey(String tableName, String resourceType, String resourceCode, GrantedSubjectType grantedSubjectType, String grantedSubjectCode, String grantedReason) {
        return getService().getByKey(tableName, resourceType, resourceCode, grantedSubjectType, grantedSubjectCode, grantedReason);
    }

    BaseResourceAccessService getService() {
        return resourceAccessOLTPService;
    }
}