package com.convertlab.foundation.metahealth.loader;

import com.convertlab.foundation.api.gdm.pattern.GdmModelClient;
import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.libaray.meta.health.MetaLoader;
import com.convertlab.foundation.libaray.meta.health.annotation.MetaLoaderAnnotation;
import lombok.RequiredArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@MetaLoaderAnnotation
@RequiredArgsConstructor
public class GdmModelLoader implements MetaLoader<GdmModelDto> {
    private final GdmModelClient gdmModelClient;

    @Override
    public List<GdmModelDto> loadAll() {
        List<GdmModelDto> models = gdmModelClient.findAll();
        return models.stream().map(GdmModelDto::getName)
                .map(gdmModelClient::findByName)
                .collect(Collectors.toList());
    }
}
