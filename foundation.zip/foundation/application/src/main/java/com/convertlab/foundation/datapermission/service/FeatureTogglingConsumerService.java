package com.convertlab.foundation.datapermission.service;

import com.convertlab.foundation.library.business.feature.FeatureEvent;
import com.convertlab.foundation.library.datapermission.service.ResourceSettingService;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.user.entity.Dept;
import com.convertlab.foundation.user.entity.UserDept;
import com.convertlab.foundation.user.mapper.DeptMapper;
import com.convertlab.foundation.user.mapper.UserDeptMapper;
import com.convertlab.foundation.user.utils.BuiltInDept;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Nonnull;
import java.util.List;

@Service
@Slf4j
@DataSourceLookup("main")
public class FeatureTogglingConsumerService {

    final SettingService settingService;
    final ResourceSettingService resourceSettingService;
    final DeptMapper deptMapper;
    final UserDeptMapper userDeptMapper;

    final RedisTemplate<String, String> redisTemplate;

    public FeatureTogglingConsumerService(SettingService settingService, DeptMapper deptMapper, UserDeptMapper userDeptMapper,  RedisTemplate<String, String> redisTemplate,ResourceSettingService resourceSettingService) {
        this.settingService = settingService;
        this.deptMapper = deptMapper;
        this.userDeptMapper = userDeptMapper;
        this.redisTemplate = redisTemplate;
        this.resourceSettingService=resourceSettingService;
    }

    @EventListener
    // 顺序越小越先执行
    @Order(1)
    public void receiveAll(@Nonnull FeatureEvent event) {
        log.info("[ D&P ] feature toggle, receive event: " + event);
        //如果是feature toggled event.
        if(FeatureEvent.FeatureEventType.FEATURE_TOGGLED.getValue().equals(event.getType())){
            if("datapermission".equals(event.getDto().getFeature()) && event.getDto().isEnabled()){
                log.info("[ D&P ] feature toggle, init data permission settings");
                //初始化data permission settings.
                resourceSettingService.initSettings();

                //初始化部门数据
                processDeptData();

                //初始化userDept数据
                processUserDeptData();
            }

            //TODO, 临时代码，为了兼容之前的逻辑，在Redis里设置datapermisison enable flag
            if("datapermission".equals(event.getDto().getFeature())){
                String key = String.format("dp::enable::%d", event.getTenantId());
                if(event.getDto().isEnabled()){
                    redisTemplate.opsForValue().set(key, "on");
                }else{
                    redisTemplate.opsForValue().set(key, "off");
                }
            }
        }
    }


    void processDeptData(){

        //初始化部门数据
       Dept topDept = deptMapper.getDeptByCode(BuiltInDept.TOP_DEPT_CODE);
       if(topDept == null){
           Dept dept = new Dept();
           dept.setCode(BuiltInDept.TOP_DEPT_CODE);
           dept.setName(BuiltInDept.TOP_DEPT_NAME);
           dept.setParent(BuiltInDept.TOP_DEPT_CODE);
           dept.setPath(BuiltInDept.TOP_DEPT_CODE);
           dept.setOutCode(BuiltInDept.TOP_DEPT_CODE);
           dept.setEnabled(true);
           deptMapper.insert(dept);
           log.info("[ D&P ] feature toggle, init top dept, code: " + BuiltInDept.TOP_DEPT_CODE);

       }

       //更新部门的outCode
        deptMapper.updateOutCodeWhereNull();
        log.info("[ D&P ] feature toggle, set out code with inner code");
    }

    void processUserDeptData(){

        //获取所有未被分配部门的用户。
        List<Integer> userIds = deptMapper.listUserWithoutDept();

        //如果没有用户，则不需要处理。
        if(CollectionUtils.isEmpty(userIds)){
            return;
        }

        //获取所有管理员用户。
        List<Integer> adminUserIds = deptMapper.listUserAdminRole(userIds);

        //所有的管理员用户加入总部。
        if(!CollectionUtils.isEmpty(adminUserIds)){
            adminUserIds.forEach(userId -> {
                UserDept userDept = new UserDept();
                userDept.setUserId(userId.longValue());
                userDept.setDeptCode(BuiltInDept.TOP_DEPT_CODE);
                userDeptMapper.insert(userDept);
            });
            log.info("[ D&P ] feature toggle, add admin user to top dept");
        }

    }

}
