package com.convertlab.foundation.gdmmeta.service;

import java.util.List;
import java.util.Map;

import com.convertlab.foundation.gdmmeta.model.Entity;

public interface DbMetaProvider {
    public List<Entity> getSuOltpEntities(Map<String, String> oltpTables);
    public List<Entity> getMainOltpEntities(Map<String, String> oltpTables);

    public List<Entity> getOlapEntities(Map<String, String> olapTables);
}
