package com.convertlab.foundation.misc.service;

import com.convertlab.foundation.library.business.eventbroker.ImpalaRefreshEvent;
import com.convertlab.foundation.library.jdbc.datasource.DynamicDataSource;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Nonnull;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.stream.Collectors;

import static com.convertlab.foundation.library.business.eventbroker.EventListenerHelper.NOTIFICATION_BROKER_EXECUTOR;

@Slf4j
@Service
@RequiredArgsConstructor
public class ImpalaOperationService {

    private final DynamicDataSource dynamicDataSource;

    @EventListener
    @Async(NOTIFICATION_BROKER_EXECUTOR)
    public void impalaRefreshListener(@Nonnull ImpalaRefreshEvent event) {
        log.debug("Receive notify, eventType: {}, eventSubType: {}, tenantId: {}",
                event.getType(), event.getSubType(), event.getTenantId());
        ImpalaRefreshEvent.Dto dto = event.getDto();

        for (ImpalaRefreshEvent.Partition partition : dto.partitions) {
            executeRefresh(partition.tableName, partition.partitionColumns);
        }
    }

    public void executeRefresh(String tableName, List<ImpalaRefreshEvent.PartitionColumn> partitionColumns) {
        String sql = "REFRESH " + tableName;

        if (!CollectionUtils.isEmpty(partitionColumns)) {
            String partitionSql = partitionColumns.stream()
                    .map(column -> "String".equalsIgnoreCase(column.type) ?
                            column.column + "=" + StringUtils.wrap(column.value, "'")
                            :
                            column.column + "=" + column.value)
                    .collect(Collectors.joining(","));

            if (StringUtils.isNotBlank(partitionSql)) {
                sql += " PARTITION (" + partitionSql + ")";
            }
        }

        try {
            log.info("start refresh table, with sql: {}", sql);
            executeImpalaOps(sql);
        } catch (Exception e) {
            throw new IllegalArgumentException("Failed to refresh table, with sql: " + sql +" due to "+e.getMessage(), e);
        }
    }

    public void executeImpalaOps(String sql) throws SQLException {
        log.info("executing: {}", sql);

        DataSource dataSource = (DataSource) dynamicDataSource.getDataSourceMap().get("olap::impala");

        try (Connection connection = dataSource.getConnection()) {
            try (Statement stmt = connection.createStatement()) {
                stmt.execute(sql);
            }
        }
    }

    public String getConnectionUrl() throws SQLException {

        DataSource dataSource = (DataSource) dynamicDataSource.getDataSourceMap().get("olap::impala");

        try (Connection connection = dataSource.getConnection()) {
            return connection.getMetaData().getURL();
        }
    }
}
