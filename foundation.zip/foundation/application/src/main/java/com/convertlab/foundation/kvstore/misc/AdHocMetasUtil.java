package com.convertlab.foundation.kvstore.misc;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.convertlab.foundation.library.hbase.mapper.RowkeyMapperRule;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * 不属于GDM的Meta临时放这里
 */
public class AdHocMetasUtil {

    /**
     * tenantId 在rowkey中 中置的表
     */
    public static final ArrayList<String> TENANT_INSIDE_ROW_KEY_TABLES = new ArrayList<>();
    @Nonnull
    private static ObjectMapper objectMapper = new ObjectMapper();
    private static List<AdHocTableMeta> adhocTableDefs;
    static{
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        TypeReference<List<AdHocTableMeta>> valueTypeRef = new TypeReference<List<AdHocTableMeta>>() {};

        adhocTableDefs = loadLocalMetaObject("/meta/biz-schema/adhoc_table_metas.json5", valueTypeRef);
        adhocTableDefs.forEach(tableDef ->{

            // 将rowkey中置的表放到TENANT_INSIDE_ROW_KEY_TABLES中
            if(StringUtils.isNotEmpty(tableDef.getDbTableName()) && tableDef.getDbStorageTypes().containsKey("KV")){
                AdHocTableMeta.StorageType storageType = tableDef.getDbStorageTypes().get("KV");
                List<AdHocTableMeta.ColumnFamily> columnFamilies = storageType.getColumnFamilies();
                if(columnFamilies.size() == 1 && columnFamilies.get(0).getRowKeyRule().equals(RowkeyMapperRule.Types.INSIDE.getType())){
                    TENANT_INSIDE_ROW_KEY_TABLES.add(tableDef.getDbTableName());
                }
            }
        });
    }
    private AdHocMetasUtil(){
        super();
    }
    /**
     * 根据表名获取AdHoc的Meta
     * @param tableName
     * @return
     */
    @Nullable
    public static AdHocTableMeta getAdHocTableMetaByName(@Nonnull String tableName){
        if(adhocTableDefs != null ){
            AdHocTableMeta data =adhocTableDefs.stream().filter(item -> tableName.equals(item.getDbTableName())).findFirst().orElse(null);
            return data;
        }
        return null;
    }

    private static <T> T loadLocalMetaObject(@Nonnull String jsonFile, TypeReference<T> valueTypeRef ) {

        T metaObject;
        String failedMessagePrefix = "failed to load file: " + jsonFile;
        try {
            URL resource = Thread.currentThread().getClass().getResource(jsonFile);
            if (resource == null) {
                resource = AdHocMetasUtil.class.getResource(jsonFile);
            }
            if (resource != null) {
                try(InputStream inputStream = resource.openStream()) {
                    JsonParser parser = objectMapper.createParser(inputStream);
                    parser.enable(JsonParser.Feature.ALLOW_COMMENTS);
                    parser.enable(JsonReadFeature.ALLOW_TRAILING_COMMA.mappedFeature());
                    metaObject = objectMapper.readValue(parser, valueTypeRef);
                }
            } else {
                throw new IllegalStateException(failedMessagePrefix);
            }
        } catch (IOException e) {
            throw new IllegalStateException(failedMessagePrefix + " in currentThread with IOException.", e);
        }
        return metaObject;
    }

}
