package com.convertlab.foundation.gdmpattern.controller;

import com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto;
import com.convertlab.foundation.gdmpattern.service.GdmPatternService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Nonnull;
import javax.validation.constraints.NotBlank;
import java.util.List;

@RequestMapping("/v1/gdm/def")
@Slf4j
@RequiredArgsConstructor
@RestController
@Tag(name = "GDM Model定义 接口")
public class GdmPatternController {
    @Nonnull
    private final GdmPatternService patternService;

    @Nonnull
    @GetMapping("patterns")
    public List<GdmPatternDto> listGdmPatterns() {
        return patternService.listGdmPatterns();
    }

    @Nonnull
    @GetMapping("patterns/{patternName}")
    public GdmPatternDto getGdmPattern(@NotBlank @PathVariable String patternName) {
        return patternService.getGdmPattern(patternName);
    }
}
