package com.convertlab.foundation.misc.controller.api;

import com.convertlab.foundation.misc.dto.SampleDto;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import javax.annotation.Nullable;

public interface SampleApi {
    @GetMapping("/home/exception/{mode}")
    @Nullable
    SampleDto inspectExceptions(@PathVariable Mode mode);

    enum Mode {
        NULL, ILLEGAL_EXCEPTION, BUSINESS_EXCEPTION, CUSTOM_BUSINESS_EXCEPTION, EXTENDED_BUSINESS_EXCEPTION,
        BACKEND_EXCEPTION, WRAPPED_BACKEND_EXCEPTION
    }
}
