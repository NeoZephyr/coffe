package com.convertlab.foundation.user.model;

import com.convertlab.foundation.library.model.vo.BaseResponse;
import com.convertlab.foundation.user.entity.UserGroup;
import lombok.Value;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.Instant;

/**
 * A DTO for the {@link UserGroup} entity
 */
@Value
public class UserGroupDto implements BaseResponse, Serializable {
    @Nonnull
    Long id;
    @Nonnull
    @Size(max = 64)
    String name;
    @Nonnull
    @Size(max = 16)
    String code;
    @Nullable
    @Size(max = 255) String remark;
    @Nullable
    @Size(max = 255)
    String ownerName;
    @Nullable
    Long ownerId;
    @Nonnull
    Instant dateCreated;
    @Nonnull
    Instant lastUpdated;

    @Nonnull
    static public UserGroupDto fromEntity(@Nonnull UserGroup entity) {
        return new UserGroupDto(entity.getId(), entity.getName(), entity.getCode(), entity.getRemark(), entity.getOwnerName(), entity.getOwnerId(), entity.getDateCreated(), entity.getLastUpdated());
    }
}