package com.convertlab.foundation.datapermission.model;

import lombok.Data;
import java.util.List;

@Data
public class ResourceBatchListShareRequestDto {

    public ResourceBatchListShareRequestDto(){}

    private String resourceType;

    private List<String> resourceCode;

}
