package com.convertlab.foundation.metahealth.loader;

import com.convertlab.foundation.gdmmeta.dao.GdmRelationshipDao;
import com.convertlab.foundation.gdmmeta.persistance.relationship.GdmRelationshipModel;
import com.convertlab.foundation.libaray.meta.health.MetaLoader;
import com.convertlab.foundation.libaray.meta.health.annotation.MetaLoaderAnnotation;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationship;
import lombok.RequiredArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@MetaLoaderAnnotation
@RequiredArgsConstructor
public class GdmRelationshipLoader implements MetaLoader<GdmRelationship> {
    private final GdmRelationshipDao relationshipDao;

    @Override
    public List<GdmRelationship> loadAll() {
        List<GdmRelationshipModel> allRelationships = relationshipDao.getAllRelationships();
        return allRelationships.stream().map(model -> model.relationshipBasedOnInputEntityName(model.getLeftEntityName())).collect(Collectors.toList());
    }
}
