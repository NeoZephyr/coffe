package com.convertlab.foundation.user.service;

import com.convertlab.data.job.core.handler.annotation.ClJob;
import com.convertlab.data.job.core.util.data.BizJobClient;
import com.convertlab.data.job.core.util.data.JobData;
import com.convertlab.foundation.datapermission.service.ResourceAccessServiceWrapper;
import com.convertlab.foundation.datapermission.service.RuleService;
import com.convertlab.foundation.library.business.audit.AuditEvent;
import com.convertlab.foundation.library.business.audit.AuditEventType;
import com.convertlab.foundation.library.business.audit.KafkaAuditTemplate;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.datapermission.GrantedSubjectType;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.jdbc.core.OLTPJdbcTemplate;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.user.entity.Dept;
import com.convertlab.foundation.user.mapper.DeptMapper;
import com.convertlab.foundation.user.mapper.UserDeptMapper;
import com.convertlab.foundation.user.model.DeptDTO;
import com.convertlab.foundation.user.utils.BuiltInDept;
import com.convertlab.foundation.user.utils.DeptRowItem;
import com.convertlab.foundation.user.utils.Tree;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import static com.convertlab.foundation.user.utils.BuiltInDept.RESERVED_DEPT_CODE;

@Service
@DataSourceLookup("main")
@Transactional
@Slf4j
public class DeptService {

    //Declare a final DeptMapper private field
    private final DeptMapper deptMapper;
    private final UserDeptMapper userDeptMapper;

    private final KafkaAuditTemplate kafkaAuditTemplate;

    private final OLTPJdbcTemplate oltpJdbcTemplate;
    private final ResourceAccessServiceWrapper resourceAccessServiceWrapper;

    private final BizJobClient bizJobClient;

    private final static String DP_DELETE_DEPT = "dp_delete_dept";

    public DeptService(DeptMapper deptMapper, UserDeptMapper userDeptMapper, KafkaAuditTemplate kafkaAuditTemplate, OLTPJdbcTemplate oltpJdbcTemplate, ResourceAccessServiceWrapper resourceAccessServiceWrapper, BizJobClient bizJobClient) {
        this.deptMapper = deptMapper;
        this.userDeptMapper = userDeptMapper;
        this.kafkaAuditTemplate = kafkaAuditTemplate;
        this.oltpJdbcTemplate = oltpJdbcTemplate;
        this.resourceAccessServiceWrapper = resourceAccessServiceWrapper;
        this.bizJobClient = bizJobClient;
    }

    //Implement the method listDepts()
    public List<Dept> listDepts(String parent, List<String> codes) {
        return deptMapper.listDepts(parent, codes);
    }

    public Dept getDeptByCode(String code) {
        return deptMapper.getDeptByCode(code);
    }

    //Implement the method saveDept()
    @Nullable
    public Dept saveDept(@Nonnull DeptDTO dto) {

        Dept parentDept = deptMapper.getDeptByOutCode(dto.getParentOutCode());

        // Generate internal code for the department
        String code = generateDeptCode(parentDept);

        if (code == null || code.isEmpty()) {
            log.error("[ D&P ] generate dept code failed");
            return null;
        }

        Dept dept = new Dept();
        dept.setName(dto.getName());
        dept.setCode(code);
        dept.setParent(parentDept.getCode());
        dept.setPath(parentDept.getPath() + "-" + dept.getCode());

        if (dto.getOutCode() != null) {
            dept.setOutCode(dto.getOutCode());
        }

        if (dto.getSequence() != null) {
            dept.setSequence(dto.getSequence());
        }

        //TBD 需要具体看下什么时候需要refresh dept cache，按道理是不太需要。
//        // Clear tenant's department cache
//        cacheService.invalidateDeptInfo(currentTenant.get());

        deptMapper.insert(dept);

        //send audit log，需要放在transaction aware service里面。
        kafkaAuditTemplate.log(new AuditEvent(AuditEventType.CREATE_ENTITY, "dept", dept.getId().toString(), dept.getName(), null, dept));

        return dept;
    }

    //Implement the method updateDept()
    @Nonnull
    public Dept updateDept(String code, @Nonnull DeptDTO dto) {

        Dept dept = deptMapper.getDeptByCode(code);
        if (dept == null) {
            log.error("[ D&P ] dept not found, code: {}", code);
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_004_001002", "dept not found.", new String[]{code});
        }

        if (dto.getOutCode() != null) {
            Dept outDept = deptMapper.getDeptByOutCode(dto.getOutCode());
            if (outDept != null) {
                log.error("[ D&P ] dept out code already exists, code: {}", dto.getOutCode());
                throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_004_001006", "dept outer code has been used by other dept.", new String[]{dto.getOutCode()});
            }
        }

        Dept parentDept = deptMapper.getDeptByOutCode(dto.getParentOutCode());
        if (parentDept != null) {
            dept.setParent(parentDept.getCode());
        }

        if (dto.getName() != null) {
            dept.setName(dto.getName());
        }

        if (dto.getOutCode() != null) {
            dept.setOutCode(dto.getOutCode());
        }

        if (dto.getSequence() != null) {
            dept.setSequence(dto.getSequence());
        }

        if (dto.getEnabled() != null) {
            dept.setEnabled(dto.getEnabled());
        }

        deptMapper.updateById(dept);
        return dept;
    }

    //Implement the method deleteDept()
    @Nonnull
    public Dept deleteDept(String code) {

        Dept dept = deptMapper.getDeptByCode(code);
        if (dept == null) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_004_001002", "dept not found.", new String[]{});
        }

        val chindDepts = deptMapper.listDepts(code, null);
        if (chindDepts != null && chindDepts.size() > 0) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_004_001003", "can not delete dept which has sub dept.", new String[]{});
        }

        if (BuiltInDept.TOP_DEPT_CODE.equals(dept.getCode())) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_004_001007", "can not delete headquarter.", new String[]{});
        }


        //如果dept下有用户，则无法删除dept
        val userDepts = userDeptMapper.listUserDepts(dept.getCode());
        if (userDepts.size() > 0) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_004_001004", "can not delete dept which has users.", new String[]{});
        }

        deptMapper.deleteById(dept.getId());


        //send audit log，需要放在transaction aware service里面。
        kafkaAuditTemplate.log(new AuditEvent(AuditEventType.DELETE_ENTITY, "dept", dept.getId().toString(), dept.getName(), dept, null));

        Map<String, Object> message = new HashMap<>();
        message.put("type", "delete_dept");
        message.put("id", dept.getId());
        message.put("deptCode", code);
        message.put("tenantId", TenantContextHolder.getTenantId());
        message.put("useNewDPJob", true);

        JobData customerJobData = JobData.builder()
                .jobType(RuleService.SPARK_JOB_DATA_PERMISSION)
                .bizUuid(UUID.randomUUID().toString())
                .appName("foundation")
                .jobHandler(DP_DELETE_DEPT)
                .needNotification(true)
                .jobParameters(JsonUtils.instance().obj2Json(message))
                .build();

        message.put("objId", "udo");

        JobData udoJobData = JobData.builder()
                .jobType(RuleService.SPARK_JOB_DATA_PERMISSION)
                .bizUuid(UUID.randomUUID().toString())
                .appName("foundation")
                .jobHandler(DP_DELETE_DEPT)
                .needNotification(true)
                .jobParameters(JsonUtils.instance().obj2Json(message))
                .build();


        bizJobClient.createAndStartBizJob(customerJobData);
        bizJobClient.createAndStartBizJob(udoJobData);

        return dept;
    }


    @ClJob(DP_DELETE_DEPT)
    public void deleteDeptAssociatedAcl(JobData jobData) {
        Map<String, Object> message = JsonUtils.instance().convertToMap(jobData.getJobParameters());
        resourceAccessServiceWrapper.delete(GrantedSubjectType.SUBJECT_TYPE_DEPT, (String) message.get("deptCode"));
        bizJobClient.submitSparkJob(RuleService.SPARK_JOB_DATA_PERMISSION, RuleService.SPARK_JOB_DATA_PERMISSION, message);
    }


    private static final int MAX_TRIES = 5;

    // Implement this method to generate a unique code for the new department。
    // TBD 目前的实现存在潜在的并行冲突，即A线程随机产生的Code和B线程随机产生的Code一样，这样就会导致数据库中存在两个相同的Code。
    // 可能需要后续实现更加完整的锁机制，不过考虑到目前的并发性，以及随机产生的Code的长度，这种情况出现的概率应该很低，暂时不作处理。
    // 待重新review import代码的时候，决定如何实现。
    @Nonnull
    public String generateDeptCode(@Nonnull Dept parentDept) {
        //获得父部门的层级
        int level = parentDept.getPath().split("-").length;
        //获得当前部门的前缀
        char prefix = (char) ('A' + level);

        //考虑到生成的code可能会重复，所以需要尝试多次
        int tries = MAX_TRIES;
        while (tries > 0) {
            //尝试获得当前部门的code
            String code = prefix + UUID.randomUUID().toString().substring(0, 5);

            //如果code为保留字，则继续尝试生成新的Code
            if (code.equals(RESERVED_DEPT_CODE)) {
                continue;
            }

            //检查代码是否已经在数据库中存在
            Dept dept = deptMapper.getDeptByCode(code);

            //如果存在，尝试次数减一
            if (dept != null) {
                tries--;
                continue;
            }
            //如果不存在，返回code
            return code;

        }
        //如果尝试次数用完，抛出异常
        throw new RuntimeException("Failed to generate a unique dept code.");
    }

    public boolean check(@Nonnull DeptDTO dto) {

        if (StringUtils.isBlank(dto.getName())) {
            throw new BusinessException(CommonErrors.MISSING_FIELD, "MSG_004_001008", "organization name can not be empty.", new String[]{});
        }

        if (StringUtils.isBlank(dto.getOutCode())) {
            throw new BusinessException(CommonErrors.MISSING_FIELD, "MSG_004_001009", "must provide organization outer code.", new String[]{});
        }

        if (StringUtils.isBlank(dto.getParentOutCode())) {
            throw new BusinessException(CommonErrors.MISSING_FIELD, "MSG_004_001010", "must provide parent organization outer code.", new String[]{});
        }

        Pattern pattern = Pattern.compile("\\w{1,64}");
        if (!pattern.matcher(dto.getOutCode()).matches()) {
            throw new BusinessException(CommonErrors.GENERAL_ERROR, "MSG_004_001011", "organization outer code format error.", new String[]{});
        }

        Dept dept = deptMapper.getDeptByOutCode(dto.getOutCode());

        if (dept != null) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_004_001012", "organization outer code {0} has been used by other organization.", new String[]{dto.getOutCode()});
        }

        Dept parentDept = deptMapper.getDeptByOutCode(dto.getParentOutCode());
        if (parentDept == null) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_004_001013", "parent dept not found.", new String[]{dto.getParentOutCode()});
        }

        int level = parentDept.getPath().split("-").length;

        if (level >= 10) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_004_001014", "dept level can not be greater than 10.", new String[]{});
        }

        return true;
    }

    @Nonnull
    public boolean isHeadquarter(String deptCode) {
        return BuiltInDept.TOP_DEPT_PATH.equals(deptCode);
    }

    public List<String> listChildDeptCode(String deptCode) {
        Dept dept = this.getDeptByCode(deptCode);
        if (dept == null) {
            return Collections.singletonList(deptCode);
        }

        String deptPath = dept.getPath();
        List<Map<String, Object>> rs = oltpJdbcTemplate.queryForList("select code from dept where path like ?", deptPath + "%");

        List<String> deptCodes = new ArrayList<>();
        rs.forEach(r -> {
            Optional.ofNullable(r.get("code"))
                    .map(Object::toString)
                    .ifPresent(deptCodes::add);
        });
        return deptCodes;
    }

    @Nonnull
    @Transactional
    public List<Dept> getDeptsByCodeList(List<String> codeList) {
        List<Dept> depts = deptMapper.getDeptByCodeList(codeList);
        return depts;
    }

    @Transactional
    public Dept getDeptByOutCode(String outCode) {
        Dept dept = deptMapper.getDeptByOutCode(outCode);
        return dept;
    }

    @Nonnull
    @Transactional
    public List<Dept> getDeptsByOutCodeList(List<String> outCodeList) {
        List<Dept> depts = deptMapper.getDeptByOutCodeList(outCodeList);
        return depts;
    }

    private static Collector<DeptRowItem, ?, Map<String, List<DeptRowItem>>> toAdjacency() {
        return Collectors.groupingBy(item -> item.parentCode);
    }

    private void sanitize() {
    }

    public void importDepartments(List<Map<String, Cell>> cells) {
        DeptRowItem[] items = cells.stream().map(DeptRowItem::fromFormattedRow).toArray(DeptRowItem[]::new);
        Map<String, List<DeptRowItem>> adjacency = cells.stream().map(DeptRowItem::fromFormattedRow).collect(toAdjacency());
        Tree<DeptRowItem>[] roots = Tree.unfoldForest(item -> Maps.immutableEntry(item, adjacency.getOrDefault(item.code, Collections.emptyList()).toArray(new DeptRowItem[0])), items);
        if (roots.length != 0) {
        } else {
            throw new BusinessException("MSG_00000_00000", "empty roots");
        }
    }

}
