package com.convertlab.foundation.misc.service;

import com.convertlab.foundation.api.gdm.pattern.dto.GdmModelDto;
import com.convertlab.foundation.gdmpattern.custom.ColumnProvisionStrategy;
import com.convertlab.foundation.gdmpattern.custom.CustomizableTable;
import com.convertlab.foundation.gdmpattern.custom.CustomizableTableFactory;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.model.ColumnType;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.gdmmeta.model.ImmutableGdmField;
import com.convertlab.foundation.library.gdmmeta.model.entity.GdmEntityRequest;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationship;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmSingularGdmRelationship;
import com.convertlab.foundation.library.gdmmeta.model.storage.Storage;
import com.convertlab.foundation.library.gdmmeta.model.table.GdmColumn;
import com.convertlab.foundation.library.gdmmeta.model.table.GdmColumnDef;
import com.convertlab.foundation.library.gdmmeta.model.table.GdmTable;
import com.convertlab.foundation.library.jdbc.datasource.DynamicDataSource;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.redis.annotation.RedisLock;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.library.utils.Try;
import com.convertlab.foundation.misc.dto.CastAndCopyColumnRequest;
import com.convertlab.foundation.misc.dto.UpdateFieldMappingRequest;
import com.convertlab.foundation.misc.entity.GdmColumnRecycle;
import com.convertlab.foundation.misc.service.dboperation.BatchCastAndCopy;
import com.convertlab.foundation.misc.service.dboperation.BatchUnsetColumn;
import com.convertlab.foundation.misc.service.dboperation.CastAndCopy;
import com.convertlab.foundation.misc.service.dboperation.UnsetColumn;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.hadoop.util.Lists;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.convertlab.foundation.gdmpattern.custom.CustomizableTable.CustomizableColumnType.FK_LONG;
import static com.convertlab.foundation.gdmpattern.service.GdmProvisionService.exchangeKV;
import static com.convertlab.foundation.library.sqlprocessor.SQLDialect.IMPALA;
import static com.convertlab.foundation.library.sqlprocessor.SQLDialect.MYSQL;

@Service
@RequiredArgsConstructor
@Slf4j
public class OptimizeUdoFkService {
    private static final int MAX_COPY_TIMES = 2;
    private final GsMetaClient gsMetaClient;
    private final DataSource dynamicDataSource;
    private final CustomizableTableFactory customizableTableFactory;
    private final ColumnProvisionStrategy columnProvisionStrategy;
    private final GdmColumnRecycleService columnRecycleService;

    public List<Pair<String, GdmField>> scan() {
        List<GdmEntity> udoList = gsMetaClient.getUdoGdmEntityList();
        if (CollectionUtils.isEmpty(udoList)) {
            return Collections.emptyList();
        }
        List<Pair<String, GdmField>> result = Lists.newArrayList();
        udoList.forEach(udo -> {
            List<GdmField> fields = scanOneEntity(udo);
            fields.forEach(field -> result.add(new ImmutablePair<>(udo.getEntityName(), field)));
        });

        log.info("Scan result in tenant " + TenantContextHolder.getTenantIdExt() + ": " + JsonUtils.instanceOfDto().obj2Json(result));

        return result;
    }

    public List<GdmField> scanOneEntity(GdmEntity entity) {
        String udoEntity = entity.getEntityName();
        List<GdmField> result = new ArrayList<>();
        List<GdmRelationship> relationships = gsMetaClient.getRelationships(udoEntity, null);
        if (!CollectionUtils.isEmpty(relationships)) {
            List<GdmRelationship> toBeOptimizedRelations = relationships.stream().filter(r -> toBeOptimized(entity, r))
                    .collect(Collectors.toList());
            Map<String, GdmField> fieldsMap = entity.getFieldsMap();
            toBeOptimizedRelations.forEach(r -> {
                GdmField field = fieldsMap.get(((GdmSingularGdmRelationship) r).getMappedBy());
                result.add(field);
            });
        }
        return result;
    }

    private boolean toBeOptimized(GdmEntity udo, GdmRelationship relationship) {
        return Try.logAndIgnoreException(() -> {
            if (!(relationship instanceof GdmSingularGdmRelationship)) {
                return false;
            }
            GdmSingularGdmRelationship r = (GdmSingularGdmRelationship) relationship;
            if (!r.getForeignKeyOwningSide().equalsIgnoreCase(udo.getEntityName())) {
                return false;
            }
            GdmEntity refEntity = gsMetaClient.getEntity(r.getRightEntityName());
            ColumnType fkColumnType = getColumnType(udo, r.getMappedBy());
            ColumnType pkColumnType = getColumnType(refEntity, refEntity.getPrimaryKeyField());
            return fkColumnType.equals(ColumnType.VARCHAR) && pkColumnType.equals(ColumnType.BIGINT);
        }, false);
    }

    public ColumnType getColumnType(GdmEntity entity, String fieldName) {
        GdmField field = entity.getFieldsMap().get(fieldName);
        if (field == null) {
            throw new IllegalArgumentException("Unknown field " + fieldName + " in entity " + entity.getEntityName());
        }
        GdmTable table = gsMetaClient.getTable(entity.getDbTableName());
        if (table == null) {
            throw new IllegalArgumentException("Unknown table " + entity.getDbTableName());
        }
        GdmColumn gdmColumn = table.getColumnMap().get(field.getDbColumnName());
        if (gdmColumn == null) {
            throw new IllegalArgumentException("Unknown column " + field.getDbColumnName() + " in table " + table.tableName());
        }
        GdmColumnDef gdmColumnDef = gdmColumn.columnDefs().get(Storage.MYSQL);
        if (gdmColumnDef == null) {
            throw new IllegalArgumentException("Unknown column " + field.getDbColumnName() + " in table " + table.tableName() + " in mysql");
        }
        return gdmColumnDef.columnType();

    }


    private static final String SQL_ALL_TENANTS = "select distinct tenant_id from company_setting where status != 'disable'";

    public List<Long> getTenants() {
        Long tenantId = TenantContextHolder.getTenantIdExt();
        if (tenantId > 0) {
            return Lists.newArrayList(tenantId);
        }
        try (Connection connection = getMainConnection(dynamicDataSource)) {
            try (PreparedStatement pstmt = connection.prepareStatement(SQL_ALL_TENANTS)) {
                try (ResultSet rs = pstmt.executeQuery()) {
                    List<Long> result = Lists.newArrayList();
                    while (rs.next()) {
                        result.add(rs.getLong("tenant_id"));
                    }
                    return result;
                }
            }
        } catch (Exception e) {
            throw new IllegalStateException("failed to get main connection");
        }
    }

    public boolean updateGdmEntityFieldMapping(UpdateFieldMappingRequest request) {
        log.info("Update field mapping: " + JsonUtils.instanceOfDto().obj2Json(request));
        String entityName = request.getEntityName();
        String fieldName = request.getFieldName();
        String fromColumn = request.getFromColumn();
        String toColumn = request.getToColumn();
        GdmEntity entity = gsMetaClient.getEntity(entityName);
        if (entity == null) {
            throw new IllegalArgumentException("entity " + entityName + " is not found");
        }
        GdmField gdmField = entity.getFieldsMap().get(fieldName);
        if (gdmField == null) {
            throw new IllegalArgumentException("field " + fieldName + " is not found in entity " + entityName);
        }
        if (!gdmField.getDbColumnName().equalsIgnoreCase(fromColumn)) {
            throw new IllegalArgumentException("field " + fieldName + " is not mapped to column " + fromColumn);
        }
        ImmutableGdmField newField = ImmutableGdmField.copyOf(gdmField).withDbColumnName(toColumn);

        GdmEntityRequest gdmEntityRequest = new GdmEntityRequest(entity);
        List<GdmField> fieldList = gdmEntityRequest.getFields()
                .stream()
                .filter(x -> !x.getFieldName().equalsIgnoreCase(fieldName))
                .collect(Collectors.toList());
        fieldList.add(newField);
        gdmEntityRequest.setFields(fieldList);
        boolean updated = gsMetaClient.updateEntity(entityName, gdmEntityRequest) != null;

        if (updated) {
            upsertUdoFieldMeta(entityName, fieldName, fromColumn, toColumn);
        }
        return updated;
    }

    @Data
    @AllArgsConstructor
    private static class UdoFieldMeta {
        private Long id;
        private String objId;
        private String fieldId;
        private String columnName;
        private String originColumnName;
    }

    private static final String SQL_FIND_FIELD_META = "select id, obj_id, field_id, column_name, origin_column_name from nudo_field_meta where tenant_id=? and lower(obj_id)=? and lower(field_id)=?";
    private static final String SQL_INSERT_FIELD_META = "insert into nudo_field_meta (tenant_id, version, obj_id, field_id, column_name, origin_column_name, date_created, last_updated) values(?, 1, ?, ?, ?, ?, now(), now())";
    private static final String SQL_UPDATE_FIELD_META = "update nudo_field_meta set column_name = ?, version=version+1, last_updated=now() where id=?";

    private boolean upsertUdoFieldMeta(String entityName, String fieldName, String fromColumn, String toColumn) {
        Long tenantId = TenantContextHolder.getTenantIdExt();
        try (Connection connection = dynamicDataSource.getConnection()) {
            UdoFieldMeta field = null;
            try (PreparedStatement stmt = connection.prepareStatement(SQL_FIND_FIELD_META)) {
                stmt.setLong(1, tenantId);
                stmt.setString(2, entityName);
                stmt.setString(3, fieldName);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        Long id = rs.getLong("id");
                        String objId = rs.getString("obj_id");
                        String fieldId = rs.getString("field_id");
                        String columnName = rs.getString("column_name");
                        String originColumnName = rs.getString("origin_column_name");
                        field = new UdoFieldMeta(id, objId, fieldId, columnName, originColumnName);
                    }
                }
            }

            if (field != null) {
                try (PreparedStatement pstmt = connection.prepareStatement(SQL_UPDATE_FIELD_META)) {
                    pstmt.setString(1, toColumn);
                    pstmt.setLong(2, field.getId());
                    return pstmt.executeUpdate() > 0;
                }
            } else {
                try (PreparedStatement pstmt = connection.prepareStatement(SQL_INSERT_FIELD_META)) {
                    pstmt.setLong(1, tenantId);
                    pstmt.setString(2, entityName);
                    pstmt.setString(3, fieldName);
                    pstmt.setString(4, toColumn);
                    pstmt.setString(5, fromColumn);
                    return pstmt.executeUpdate() > 0;
                }
            }
        } catch (Exception e) {
            throw new IllegalStateException("failed to upsert udo field meta", e);
        }
    }

    public void castAndCopyColumn(CastAndCopyColumnRequest args) {
        validateCastAndCopyRequest(args);
        log.info("Cast and copy column starting: " + JsonUtils.instanceOfDto().obj2Json(args));
        try (Connection connection = dynamicDataSource.getConnection()) {
            for (int i = 0; i < MAX_COPY_TIMES; i++) {
                castAndCopyColumnInMysql(args, connection);
                if (isCastAndCopyDone(args, connection)) {
                    break;
                } else {
                    int newBatchSize = args.getBatchSize() / 10;
                    newBatchSize = newBatchSize >= 5 ? newBatchSize : 5;
                    args.setBatchSize(newBatchSize);
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to get db connection", e);
        }

        try (Connection connection = getImpalaConnection(dynamicDataSource)) {
            for (int i = 0; i < MAX_COPY_TIMES; i++) {
                castAndCopyColumnInKudu(args, connection);
                if (isCastAndCopyDone(args, connection)) {
                    break;
                }
            }
        } catch (Exception e) {
            throw new IllegalStateException("Failed to get impala db connection", e);
        }
        log.info("Cast and copy column end: " + JsonUtils.instanceOfDto().obj2Json(args));
    }

    private void castAndCopyColumnInMysql(CastAndCopyColumnRequest args, Connection connection) {
        BatchCastAndCopy batchCastAndCopy = new BatchCastAndCopy(args, connection, MYSQL);
        long count = batchCastAndCopy.count();
        if (count <= 0) {
            log.info("no data need to cast and copy " + JsonUtils.instanceOfDto().obj2Json(args));
            return;
        }
        batchCastAndCopy.run();
    }

    public boolean isCastAndCopyDone(CastAndCopyColumnRequest args) {
        try (Connection connection = dynamicDataSource.getConnection()) {
            return isCastAndCopyDone(args, connection);
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to get db connection", e);
        }
    }

    private boolean isCastAndCopyDone(CastAndCopyColumnRequest args, Connection connection) {
        CastAndCopy castAndCopy = new CastAndCopy(args, connection, MYSQL);
        long fromCount = castAndCopy.countNotNull(args.getFromColumn());
        long toCount = castAndCopy.countNotNull(args.getToColumn());
        log.info("count not null: {}, {}", fromCount, toCount);
        return Math.abs(fromCount - toCount) < 10L;
    }

    public void unsetColumn(CastAndCopyColumnRequest args) {
        log.info("Unset column starting: " + JsonUtils.instanceOfDto().obj2Json(args));
        args = JsonUtils.instanceOfDto().clone(args);
        args.setToColumn(null); //do not care about toColumn in this step
        validateUnsetRequest(args);

        try (Connection connection = dynamicDataSource.getConnection()) {
            BatchUnsetColumn batchUnsetColumn = new BatchUnsetColumn(args, connection, MYSQL);
            long count = batchUnsetColumn.count();
            if (count <= 0) {
                log.info("no data need to unset column " + JsonUtils.instanceOfDto().obj2Json(args));
                return;
            }
            batchUnsetColumn.run();
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to get db connection", e);
        }
        unsetColumnInKudu(args);
        log.info("Unset column end: " + JsonUtils.instanceOfDto().obj2Json(args));
    }

    private void validateCastAndCopyRequest(CastAndCopyColumnRequest args) {
        String entityName = args.getEntityName();
        String fromColumn = args.getFromColumn();
        String toColumn = args.getToColumn();
        String tableName = args.getTableName();
        GdmEntity entity = gsMetaClient.getEntity(entityName);
        if (entity == null) {
            throw new IllegalArgumentException("No entity found with name " + entityName);
        }
        if (!entity.getDbTableName().equalsIgnoreCase(tableName)) {
            throw new IllegalArgumentException("Entity " + entityName + " is not bound with table " + tableName);
        }
        boolean columnBound = entity.getFields().stream().anyMatch(x -> x.getDbColumnName().equalsIgnoreCase(fromColumn));
        if (!columnBound) {
            throw new IllegalArgumentException("Can not copy value from unbound column " + fromColumn + " in entity " + entityName);
        }
        columnBound = entity.getFields().stream().anyMatch(x -> x.getDbColumnName().equalsIgnoreCase(toColumn));
        if (columnBound) {
            throw new IllegalArgumentException("Can not copy value to bound column " + toColumn + " in entity " + entityName);
        }
    }

    private void validateUnsetRequest(CastAndCopyColumnRequest args) {
        String entityName = args.getObjId();
        String columnName = args.getFromColumn();
        String tableName = args.getTableName();
        GdmEntity entity = gsMetaClient.getEntity(entityName);
        if (entity == null) {
            throw new IllegalArgumentException("No entity found with name " + entityName);
        }
        if (!entity.getDbTableName().equalsIgnoreCase(tableName)) {
            throw new IllegalArgumentException("Entity " + entityName + " is not bound with table " + tableName);
        }
        boolean columnBound = entity.getFields().stream().anyMatch(x -> x.getDbColumnName().equalsIgnoreCase(columnName));
        if (columnBound) {
            throw new IllegalArgumentException("Can not unset bound column " + columnName + " in entity " + entityName);
        }
    }

    private void castAndCopyColumnInKudu(CastAndCopyColumnRequest args, Connection connection) {
        CastAndCopy castAndCopy = new CastAndCopy(args, connection, IMPALA);
//            castAndCopy.printColumn();
        castAndCopy.run();
    }

    private void unsetColumnInKudu(CastAndCopyColumnRequest args) {
        try (Connection connection = getImpalaConnection(dynamicDataSource)) {
            UnsetColumn unsetColumn = new UnsetColumn(args, connection, IMPALA);
//            unsetColumn.printColumn();
            unsetColumn.run();
        } catch (Exception e) {
            throw new IllegalStateException("Failed to get impala db connection", e);
        }
    }

    private Connection getImpalaConnection(DataSource dynamicDataSource) throws SQLException {
        if (dynamicDataSource instanceof DynamicDataSource) {
            DataSource dataSource = (DataSource) ((DynamicDataSource) dynamicDataSource).getDataSourceMap().get("olap::impala");
            return dataSource.getConnection();
        }
        throw new IllegalArgumentException("No dynamic data source found");
    }

    static Connection getMainConnection(DataSource dynamicDataSource) throws SQLException {
        if (dynamicDataSource instanceof DynamicDataSource) {
            DataSource dataSource = (DataSource) ((DynamicDataSource) dynamicDataSource).getDataSourceMap().get("oltp::main");
            return dataSource.getConnection();
        }
        throw new IllegalArgumentException("No dynamic data source found");
    }


    @RedisLock(key = "#{'updateGdmEntity.'+#entity.entityName}")
    public void optimize(GdmEntity entity, GdmField field) {
        List<GdmField> fields = scanOneEntity(entity);
        if (!fields.contains(field)) {
            throw new IllegalArgumentException("No need to optimize for field " + field.getFieldName() + " in entity " + entity.getEntityName());
        }
        CastAndCopyColumnRequest castAndCopyColumnRequest = toCastAndCopyRequest(entity, field);
        log.info("Optimize starting: " + entity.getEntityName() + "." + field.getFieldName() + " from " + castAndCopyColumnRequest.getFromColumn() + " to " + castAndCopyColumnRequest.getToColumn());
        castAndCopyColumn(castAndCopyColumnRequest);
        //再次确认
        if (!isCastAndCopyDone(castAndCopyColumnRequest)) {
            log.error("cast and copy not succeed: "+ JsonUtils.instanceOfDto().obj2Json(castAndCopyColumnRequest));
            return;
            //     castAndCopyColumn(castAndCopyColumnRequest);
        }
        UpdateFieldMappingRequest updateFieldMappingRequest = toUpdateFieldMappingRequest(castAndCopyColumnRequest, entity, field);
        updateGdmEntityFieldMapping(updateFieldMappingRequest);
        createToBeRecycleColumn(entity.getEntityName(), entity.getDbTableName(), field.getFieldName(), field.getDbColumnName());
//        optimizeUdoFkService.unsetColumn(castAndCopyColumnRequest);
        log.info("Optimize end: " + entity.getEntityName() + "." + field.getFieldName() + " from " + castAndCopyColumnRequest.getFromColumn() + " to " + castAndCopyColumnRequest.getToColumn());
    }

    private boolean createToBeRecycleColumn(String entityName, String tableName, String fieldName, String dbColumnName) {
        GdmColumnRecycle recycle = new GdmColumnRecycle();
        recycle.setTenantId(TenantContextHolder.getTenantIdExt());
        recycle.setEntityName(entityName);
        recycle.setTableName(tableName);
        recycle.setFieldName(fieldName);
        recycle.setDbColumnName(dbColumnName);
        recycle.setStatus(GdmColumnRecycle.STATUS_TO_BE_RECYCLE);
        return columnRecycleService.createGdmColumnRecycle(recycle);
    }

    private CastAndCopyColumnRequest toCastAndCopyRequest(GdmEntity entity, GdmField field) {
        CastAndCopyColumnRequest request = new CastAndCopyColumnRequest();
        request.setEntityName(entity.getEntityName());
        request.setObjId(entity.getTablePartition().getIdentifierValue());
        request.setTableName(entity.getDbTableName());
        request.setFromColumn(field.getDbColumnName());
        String toColumn = findAvailableLongFk(entity, field);
        request.setToColumn(toColumn);
        return request;
    }

    private UpdateFieldMappingRequest toUpdateFieldMappingRequest(CastAndCopyColumnRequest castAndCopyColumnRequest, GdmEntity entity, GdmField field) {
        UpdateFieldMappingRequest request = new UpdateFieldMappingRequest();
        request.setEntityName(entity.getEntityName());
        request.setFieldName(field.getFieldName());
        request.setFromColumn(castAndCopyColumnRequest.getFromColumn());
        request.setToColumn(castAndCopyColumnRequest.getToColumn());
        return request;
    }

    private String findAvailableLongFk(GdmEntity entity, GdmField gdmField) {
        String tableName = entity.getDbTableName();
        CustomizableTable customizableTable = customizableTableFactory.get(tableName);
        if (customizableTable == null) {
            throw new IllegalArgumentException("Table " + tableName + " is not customizable");
        }
        String entityName = entity.getEntityName();
        entity = gsMetaClient.getEntity(entityName); //read the latest version
        if (entity == null) {
            throw new IllegalArgumentException("Entity " + entityName + " is not found");
        }
        List<GdmField> customizableFields = entity.getFields().stream()
                .filter(customizableTable::isCustomizedColumn).collect(Collectors.toList());
        Map<String, String> existingColumnMapping = exchangeKV(customizableFields
                .stream()
                .collect(Collectors.toMap(GdmField::getFieldName, GdmField::getDbColumnName)));
        GdmModelDto.Field field = GdmModelDto.Field.fromGdmField(gdmField, entity.getPrimaryKeyField(), entity.getFieldsMap().get(entity.getPrimaryKeyField()).getFieldType());
        Map<String, String> provisionResult = columnProvisionStrategy.provision(customizableTable, FK_LONG, Lists.newArrayList(field), existingColumnMapping);
        return provisionResult.get(gdmField.getFieldName());
    }

}
