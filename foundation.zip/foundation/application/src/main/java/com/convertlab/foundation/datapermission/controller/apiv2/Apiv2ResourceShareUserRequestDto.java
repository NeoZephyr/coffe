package com.convertlab.foundation.datapermission.controller.apiv2;

import lombok.Data;

import java.util.List;

@Data
public class Apiv2ResourceShareUserRequestDto {
    String identityType;
    List<String> identityValues;
}
