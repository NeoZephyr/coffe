package com.convertlab.foundation.user.mapper;


import javax.annotation.Nullable;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.foundation.user.entity.Dept;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface DeptMapper extends BaseMapper<Dept> {

    default Dept getDeptByCode(String code) {
        QueryWrapper<Dept> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("code", code);
        return selectOne(queryWrapper);
    }

    default List<Dept> getDeptByCodeList(List<String> codeList) {
        QueryWrapper<Dept> queryWrapper = new QueryWrapper<>();
        queryWrapper.in("code", codeList);
        return selectList(queryWrapper);
    }

    default Dept getDeptByOutCode(String outCode) {
        QueryWrapper<Dept> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("out_code", outCode);
        return selectOne(queryWrapper);
    }

    default List<Dept> getDeptByOutCodeList(List<String> outCodeList) {
        QueryWrapper<Dept> queryWrapper = new QueryWrapper<>();
        queryWrapper.in("out_code", outCodeList);
        return selectList(queryWrapper);
    }

    default List<Dept> listDepts(@Nullable String parent, @Nullable List<String> codes) {
        QueryWrapper<Dept> queryWrapper = new QueryWrapper<>();
        if(parent != null) {
            queryWrapper.eq("parent", parent);
        }

        if(codes != null && !codes.isEmpty()){
            queryWrapper.in("code", codes);
        }

        return selectList(queryWrapper);
    }


     @Update("update dept set out_code = code where out_code is null")
     void updateOutCodeWhereNull();

     // 获取当前租户下的没有部门归属的用户
     @Select("select ut.user_id from user_tenant ut where ut.user_id not in (select ud.user_id from user_dept ud)")
     List<Integer> listUserWithoutDept();


     //select user_id, role_key from user_role where user_id in (:userIds) and (role_key = 'admin' or role_key = 'tenant_admin')
        @Select("<script> " +
                "select distinct user_id from user_role where user_id in " +
                "<foreach collection='userIds' item='userId' open='(' separator=',' close=')'> " +
                "#{userId} " +
                "</foreach> " +
                "and (role_key = 'admin' or role_key = 'tenant_admin') " +
                "</script>")
    List<Integer> listUserAdminRole(@Param("userIds") List<Integer> userIds);



}