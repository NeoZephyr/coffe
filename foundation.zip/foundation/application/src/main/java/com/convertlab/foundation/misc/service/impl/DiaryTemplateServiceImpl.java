package com.convertlab.foundation.misc.service.impl;

import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BackendException;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.client.SimpleMetaClient;
import com.convertlab.foundation.library.gdmmeta.model.general.BaseMetaSchema;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.ObjectResponse;
import com.convertlab.foundation.library.utils.LogUtils;
import com.convertlab.foundation.misc.dto.DiaryTemplate;
import com.convertlab.foundation.misc.service.DiaryTemplateService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomUtils;

import javax.annotation.Nullable;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class DiaryTemplateServiceImpl implements DiaryTemplateService {
    private final GsMetaClient gsMetaClient;
    private final SimpleMetaClient diaryTemplateMetaClient;

    public DiaryTemplateServiceImpl(GsMetaClient gsMetaClient) {
        this.gsMetaClient = gsMetaClient;
        this.diaryTemplateMetaClient = gsMetaClient.simpleClientOf(BaseMetaSchema.MetaType.EXT_MISC);
    }

    @Override
    public List<DiaryTemplate> getAllTemplates() {
        return null;
    }

    @Override
    public List<DiaryTemplate> getTemplatesNewerThan(Instant date) {
        return null;
    }

    @Override
    @Nullable
    public DiaryTemplate getTemplateByName(String name) {
        // 为了测试注释掉下面的代码。
//        Map<String,String> filter = new HashMap<>();
//        filter.put("objectName", name);
//        filter.put("data.extType", "DIARY_TEMPLATE");
//        List<DiaryTemplate> result = diaryTemplateMetaClient.queryObjects2(filter, DiaryTemplate.class);
        // 其实DiaryTemplate只是misc里面的一种类型，所以上面的代码加上了data.extType的过滤条件。
        // 下面的写法是如果misc里面保存的只有DiaryTemplate的话，就可以直接用下面的代码。
        return diaryTemplateMetaClient.getObject2(name, DiaryTemplate.class);
//        if (!result.isEmpty()) {
//            return result.get(0);
//        }
//        return null;
//        return diaryTemplateMetaClient.getObject2(name, DiaryTemplate.class);
    }

    @Override
    public DiaryTemplate getTemplateById(String id) {
        return null;
    }

    @Override
    public DiaryTemplate createTemplate(DiaryTemplate template) {
        template.setModifiable(RandomUtils.nextBoolean());
        return diaryTemplateMetaClient.createObject2(template.getName(), template);
    }

    @Override
    public DiaryTemplate updateTemplate(DiaryTemplate template) {
        DiaryTemplate result = this.getTemplateByName(template.getName());
        if (result == null) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_001_001_001","Template not found",
                    new String[]{template.getName()});
        }
        if ("DIARY_TEMPLATE".equals(result.getExtType())) {
            if (result.getModifiable())
                return diaryTemplateMetaClient.updateObject2(template.getName(), template);
            else
                throw new BackendException(CommonErrors.ACCESS_DENIED, "Bad luck :-( Not a modifiable metadata",
                        new String[]{template.getName()});
        }
        throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_001_001_002","It's not a DiaryTemplate",
                new String[]{template.getName()});
    }
}
