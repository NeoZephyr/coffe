package com.convertlab.foundation.datapermission.service;

import com.convertlab.foundation.user.utils.BuiltInDept;

import java.util.ArrayList;
import java.util.List;

public class RuntimeDemoService {

    public String transfomerSql(String sql, Context1 context){
        return null;
    }

    public String transfomerSql(String sql, Context2 context){
        return null;
    }

    /**
     *
     * @param sql  "select * from customer limit 10"
     * @param context "user:1  dept:b1234"
     */
    public void executeQuery(String sql, Context1 context){
        //找到Sql里的entity
        String entity = parseEntity(sql);
        //customer entity是否需要做数据权限。
        boolean requireDataPermission = requireDataPermission(entity);
        if(requireDataPermission){

            processDataPermissionSql(sql, context);
        }
    }

    private void processDataPermissionSql(String sql, Context1 context) {
        //1.读取Setting. 读取公海数据Setting,读取可见范围Setting, 读取DeptAttrSetting
        DpSetting setting = loadDpSetting();

        //3.构建policy group.
        List<Policy> buildPolicyGroupBySettings = buildPolicyGroupBySettings(setting, context);

        //4.build sql by policy group
        for (Policy buildPolicyGroupBySetting : buildPolicyGroupBySettings) {
            //sql + policy Sql  union.
        }
    }

    private void sharePolicyBuilder(DpSetting setting, Context1 context){
        //1.得到resource meta. 从resource meta中，获得 id column， 获得table name
        // customer id = id  table =  dp_resource_access_customer.
        // page  id = uuid table = dp_resoruce_access_content_main.

        //2.generate sql
        if(setting.accessScope == 1){
            //读取部门信息.
            List<String> subDepts = loadSubDeptInfo(context.deptCode);

            String sql =  "select * from customer c join dp_resource_access_customer dp on dp.resource_type = \"customer\" " +
                    "and c.id = dp.resource_code and dp.granted_subject_type = \'dept\' and dp.granted_subject_code in subDepts";
        }else if(setting.accessScope == 7){
            //读取部门信息.
            List<String> subDepts = loadSubDeptInfo(context.deptCode);
            //读取用户组信息
            List<String> usergroup = loadUserGroupInfo(context.userId);

            String sql =  "select * from customer c join dp_resource_access_customer dp on dp.resource_type = \"customer\" " +
                    "and c.id = dp.resource_code and ((dp.granted_subject_type = \'dept\' and dp.granted_subject_code in subDepts) or " +
                    "(dp.granted_subject_type = \'user\' and dp.granted_subject_code = context.userId) or" +
                    " (dp.granted_subject_type = \'group\' and dp.granted_subject_code in userGroup) )";
        }
    }

    private void orgPolicy(DpSetting setting, Context1 context){
        //获取子部门的数据
        List<String> subDepts = loadSubDeptInfo(context.deptCode);

        if(setting.isHighseaToAll && setting.accessScope == 1){

            String sql =  "select * from customer c where (c.dept_code in subDepts or c.owner_id = null)";

        }else if(!setting.isHighseaToAll && setting.accessScope == 1){

            //如果当前的部门清单中，有被设定在highsea dept中的，就可以访问所有公海数据
            if(setting.highseaDeptCodes.contains(null) ){
                String sql =  "select * from customer c where (c.dept_code in subDepts or c.owner_id = null)";
            }else{
                String sql =  "select * from customer c where c.dept_code in subDepts";
            }
        }else if(setting.isHighseaToAll && setting.accessScope == 7){
            String sql =  "select * from customer c where (c.dept_code in subDepts or c.owner_id = null or c.owner_id = context.userId)";
        }else if(!setting.isHighseaToAll && setting.accessScope == 7){
            //如果当前的部门清单中，有被设定在highsea dept中的，就可以访问所有公海数据
            if(setting.highseaDeptCodes.contains(null) ){
                String sql =  "select * from customer c where (c.dept_code in subDepts or c.owner_id = null or c.owner_id = context.userId)";
            }else{
                String sql =  "select * from customer c where (c.dept_code in subDepts or c.owner_id = context.userId)";
            }
        }
    }

    private void outerDeptAttrPolicy(DpSetting setting, Context1 context){
        //获取子部门的数据
        List<String> subDepts = loadOuterSubDeptInfo(context.deptCode);
        String attr = setting.outerDeptAttr;

        if(setting.isHighseaToAll && setting.accessScope == 1){

            String sql =  "select * from customer c where (c.${attr} in subDepts or c.owner_id = null)";

        }else if(!setting.isHighseaToAll && setting.accessScope == 1){

            //如果当前的部门清单中，有被设定在highsea dept中的，就可以访问所有公海数据
            if(setting.highseaDeptCodes.contains(null) ){
                String sql =  "select * from customer c where (c.${attr} in subDepts or c.owner_id = null)";
            }else{
                String sql =  "select * from customer c where c.${attr} in subDepts";
            }
        }
//
//        else if(setting.isHighseaToAll && setting.accessScope == 7){
//            String sql =  "select * from customer c where (c.${attr} in subDepts or c.owner_id = null or c.owner_id = context.userId)";
//        }else if(!setting.isHighseaToAll && setting.accessScope == 7){
//            //如果当前的部门清单中，有被设定在highsea dept中的，就可以访问所有公海数据
//            if(setting.highseaDeptCodes.contains(null) ){
//                String sql =  "select * from customer c where (c.${attr} in subDepts or c.owner_id = null or c.owner_id = context.userId)";
//            }else{
//                String sql =  "select * from customer c where (c.${attr} in subDepts or c.owner_id = context.userId)";
//            }
//        }

    }

    private List<String> loadOuterSubDeptInfo(String deptCode) {
        return null;
    }

    private List<String> loadUserGroupInfo(String userId) {
        return null;
    }

    private List<Policy> buildPolicyGroupBySettings(DpSetting setting, Context1 context) {
        List<Policy> group = new ArrayList<>();
        //首先判断用户是否是admin
        boolean isUserAdmin = isUserAdmin(context.userId);
        //普通用户必须要选择一个部门进来，作为上下文。
        if(!isUserAdmin && context.deptCode == null){
            //throw exception.
        }

        //如果用户是Admin，且未设置部门，则可以访问所有数据。 admin未归属任何部门。
        if(isUserAdmin && context.deptCode == null){
            //返回{}policy
            return group;
        }

        //如果当前选择的是总部，那么不做数据权限，可以访问所有数据。
        boolean isHQDept = isHQDept(context.deptCode);
        if(isHQDept){
            //返回{}policy
            return group;
        }

//        group.add("share_policy");

//        if(setting.outerDeptAttr != null){
//            group.add("outer_dept_policy");
//        }else{
//            group.add("dept_policy");
//        }

        //通用abac还未开发。
//        group.add("brand_policy");

        return group;
    }


    private DpSetting loadDpSetting() {
        return new DpSetting();
    }

    private List<String> loadSubDeptInfo(String deptCode){
        return null;
    }

    private boolean isHQDept(String deptCode) {
        //if deptCode = ""
        if(BuiltInDept.TOP_DEPT_CODE.equals(deptCode)){
            return true;
        }
        return false;
    }

    private boolean isUserAdmin(String userId) {

        //1. if UserRole = admin or tenant admin
        //2. if user group role = admin or tenant admin
        //3. if user is support user

        return true;
    }

    private String parseEntity(String sql) {
        return "customer";
    }

    private boolean requireDataPermission(String entity){
        //根据entity找到resource
        String resourceType = findResourceByEntity(entity);
        //根据setting找到resource是否设置为private
        boolean isPrivateSetting = getGlobalAccessSetting(resourceType);
        return isPrivateSetting;
    }

    private boolean getGlobalAccessSetting(String resourceType) {
        //load global setting metadata and check results.
        return true;
    }


    private String findResourceByEntity(String entity) {
        //find resource by entity.
        //retrieve meta, find resource meta by entity. (可能需要缓存所有的resource meta)
        return null;
    }


    class Context1{
        String userId;
        String deptCode;
    }

    class Context2{
        String userId;
        String deptCode;
    }

    class DpSetting {
        boolean isHighseaToAll;
        String highseaDeptCodes;

        //1 代表部门可见， 7 代表全部可见。
        int accessScope;

        //外部部门对应属性
        String outerDeptAttr;
    }

    class Policy{
        String name;
        List<String> attrs;
        String settings;
    }
}
