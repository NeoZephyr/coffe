package com.convertlab.foundation.user.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class JoinLeaveUserGroupResponse {
    private String groupCode;
}
