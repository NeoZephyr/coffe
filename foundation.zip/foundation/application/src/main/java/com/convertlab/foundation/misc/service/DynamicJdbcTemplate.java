package com.convertlab.foundation.misc.service;

import com.convertlab.foundation.library.jdbc.property.ExtraDataSourceProperties;
import com.convertlab.foundation.library.utils.Try;
import com.google.common.collect.Maps;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.annotation.Nonnull;
import javax.sql.DataSource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 类似JdbcTemplate的工具类，仅用于数据迁移的目的，业务系统慎用！！！
 */
@Deprecated
public class DynamicJdbcTemplate {
    @Nonnull
    private final Map<String, DataSource> dataSourceMap;

    public DynamicJdbcTemplate(@Nonnull ExtraDataSourceProperties dataSourceProperties) {
        dataSourceMap = Maps.newHashMap();
        dataSourceProperties.getOltp().getDatasources().forEach((k, v) -> {
            if (StringUtils.isNotBlank(v.getUrl()) && StringUtils.isNotBlank(v.getPassword())) {
                dataSourceMap.put(k, initDataSource(v));
            }
        });

        dataSourceProperties.getOlap().getDatasources().forEach((k, v) -> {
            if (StringUtils.isNotBlank(v.getUrl())) {
                dataSourceMap.put(k, initDataSource(v));
            }
        });
    }

    public DataSource getDataSource(String ds) {
        return dataSourceMap.get(ds);

    }

    /**
     * 针对特定数据源，调用JdbcTemplate的queryForList
     *
     * @param ds    数据源
     * @param sql   查询语句
     * @param clazz 返回的对象类
     * @return 查询结果
     */
    @Nonnull
    public <T> List<T> queryForList(String ds, @Nonnull String sql, @Nonnull Class<T> clazz) {
        JdbcTemplate jdbcTemplate = buildJdbcTemplate(ds);
        return jdbcTemplate.query(sql, new Object[]{}, new int[0], new BeanPropertyRowMapper<>(clazz));
    }

    /**
     * 对所有满足dsPattern的数据源，调用JdbcTemplate的queryForList，并聚合这些数据源的查询结果
     *
     * @param dsPattern 数据源的pattern，判断标准：ds.startWith(dsPattern)
     * @param sql       查询语句
     * @param clazz     返回的对象类
     * @return 多数据源查询结果的聚合
     */
    @Nonnull
    public <T> Map<String, List<T>> queryAllForList(@Nonnull String dsPattern, @Nonnull String sql, @Nonnull Class<T> clazz) {
        List<String> dsList = dataSourceMap.keySet().stream()
                .filter(x -> x.startsWith(dsPattern))
                .collect(Collectors.toList());
        Map<String, List<T>> result = Maps.newHashMap();
        for (String ds : dsList) {
            Try.ignoreException(() -> result.put(ds, queryForList(ds, sql, clazz)));
        }
        return result;
    }

    protected DataSource initDataSource(@Nonnull ExtraDataSourceProperties.DataSourceConfig properties) {
        HikariDataSource dataSource = properties.initializeDataSourceBuilder().type(HikariDataSource.class).build();
        HikariConfig configuration = properties.getHikari();
        if (configuration != null) {
            configuration.setJdbcUrl(properties.getUrl());
            configuration.setDriverClassName(properties.getDriverClassName());
            configuration.setUsername(properties.getUsername());
            configuration.setPassword(properties.getPassword());

            configuration.copyStateTo(dataSource);
        }
        return dataSource;
    }

    @Nonnull
    protected JdbcTemplate buildJdbcTemplate(String ds) {
        DataSource dataSource = dataSourceMap.get(ds);
        if (dataSource == null) {
            throw new IllegalArgumentException("No such data source found: " + ds);
        }
        return new JdbcTemplate(dataSource);
    }
}
