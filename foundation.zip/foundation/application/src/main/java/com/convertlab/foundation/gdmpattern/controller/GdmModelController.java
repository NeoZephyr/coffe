package com.convertlab.foundation.gdmpattern.controller;

import com.convertlab.data.job.core.biz.model.BizJobRunResult;
import com.convertlab.foundation.api.gdm.pattern.GdmModelClient;
import com.convertlab.foundation.api.gdm.pattern.dto.*;
import com.convertlab.foundation.gdmmeta.service.validator.GdmPatternValidator;
import com.convertlab.foundation.gdmpattern.service.GdmModelService;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BackendException;
import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationshipRequest;
import com.convertlab.foundation.library.gdmmeta.validation.Issue;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.principal.context.PrincipalContextHolder;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto.ProvisionType.isUdoBased;
import static com.convertlab.foundation.library.constant.GdmNamingConvention.CUSTOM_PROFILE_ENTITY_NAME_PATTERN;

@RequestMapping("/v1/gdm/def")
@Slf4j
@RequiredArgsConstructor
@RestController
@Tag(name = "GDM Model定义 接口")
public class GdmModelController {
    @Nonnull
    private final GdmModelService gdmModelService;
    @Nonnull
    private final GdmModelClient gdmModelClient;
    @Nonnull
    private final GdmPatternValidator gdmPatternValidator;

    @Nullable
    @PostMapping("models/{modelName}")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "GdmModel定义请求", required = true,
            content = @io.swagger.v3.oas.annotations.media.Content(
                    mediaType = "application/json",
                    schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = DefineGdmModelRequest.class),
                    examples = {@ExampleObject(name = "request", value = "{\n" +
                            "  \"name\" : \"c_second_member\",\n" +
                            "  \"patterns\" : [ \"general-profile\",\"platform-member\" ],\n" +
                            "  \"fields\" : [ {\n" +
                            "    \"fieldName\" : \"bk\",\n" +
                            "    \"fieldType\" : \"String\",\n" +
                            "    \"isCustomized\" : false,\n" +
                            "    \"isPrimaryKey\" : true,\n" +
                            "    \"isForeignKey\" : false\n" +
                            "  }, {\n" +
                            "    \"fieldName\" : \"name\",\n" +
                            "    \"fieldType\" : \"String\",\n" +
                            "    \"isCustomized\" : false,\n" +
                            "    \"isPrimaryKey\" : false,\n" +
                            "    \"isForeignKey\" : false\n" +
                            "  } ],\n" +
                            "  \"features\" : [ \"StaticTraits\", \"DynamicTraits\", \"StaticSegment\", \"DynamicSegment\", \"Event\", \"Cdc\", \"DataPermission\" ],\n" +
                            "  \"systemEventIds\" : [ \"create_membership\", \"delete_membership\", \"loyalty_dispatch_coupon\", \"membership_draw_coupon\", \"membership_exp_decr\", \"membership_exp_incr\", \"membership_level_down\", \"membership_level_up\", \"membership_point_decr\", \"membership_point_incr\", \"membership_redeem_coupon\", \"membership_submit_form\" ],\n" +
                            "  \"props\" : {\n" +
                            "    \"dataProcessingModes\" : [ \"OLTP\", \"REALTIME_AP\" ],\n" +
                            "    \"provisionType\" : \"PLATFORM_MEMBER_UDO\"\n" +
                            "  }\n" +
                            "}")}
            )
    )
    public GdmModelDto defineGdmModel(@Nonnull @NotBlank @PathVariable String modelName, @Nonnull @NotNull @RequestBody DefineGdmModelRequest gdmModel) {
        if (StringUtils.isNotBlank(gdmModel.getName()) && !modelName.equals(gdmModel.getName())) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Gdm name mismatch");
        }
        if (gdmModel.isGeneralProfilePattern() && !CUSTOM_PROFILE_ENTITY_NAME_PATTERN.matcher(modelName).matches()) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Invalid gdm name " + modelName);
        }
        if (CollectionUtils.isEmpty(gdmModel.getFields())) {
            throw new BackendException(CommonErrors.MISSING_FIELD, "Fields missing");
        }
        if (gdmModel.getFields().stream().filter(GdmModelDto.Field::isPrimaryKey).count() != 1) {
            throw new BackendException(CommonErrors.MISSING_FIELD, "One primary key is must");
        }
        if (gdmModel.getProps() == null || !isUdoBased(gdmModel.getProps().getProvisionType()) ) {
            throw new BackendException(CommonErrors.MISSING_FIELD, "Only UDO doProvision supported");
        }
        if (gdmModel.getProps().getDataProcessingModes() == null) {
            throw new BackendException(CommonErrors.MISSING_FIELD, "Data processing modes missing");
        }
        Map<String, List<GdmPatternDto.Feature>> features = gdmModel.getFeatures().stream().collect(Collectors.groupingBy(Enum::name));
        List<String> duplicatedFeatures = features.keySet().stream()
                .filter(x -> features.get(x).size() > 1)
                .collect(Collectors.toList());
        if(!CollectionUtils.isEmpty(duplicatedFeatures)) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Duplicated features found: "+StringUtils.join(duplicatedFeatures, ","));
        }


        gdmModel.setName(modelName);
        return gdmModelService.defineGdmModel(gdmModel);
    }

    @Nonnull
    @PutMapping("models/{modelName}")
    public GdmModelDto updateGdmModelDef(@Nonnull @NotBlank @PathVariable @NotNull String modelName, @NotNull @RequestBody ModifyGdmModelRequest request) {
        return gdmModelService.updateGdmModelDef(modelName, request);
    }

    @Nullable
    @GetMapping("models/{modelName}")
    @Operation(summary = "获取GdmModel定义",operationId = "get-model")
    public GdmModelDto getGdmModelDef(@Nonnull @NotBlank @PathVariable String modelName) {
        return gdmModelService.findByName(modelName);
    }

    /*
     * 创建异步任务删除GdmModel, model主表以及周边表数据
     * bizInfo为上游业务信息, 会作为删除任务的子类型, 任务结束后可以通过监听类型为JOB_003_DROP_GDM_MODEL_DEF的BizJobEvent得到该业务信息
     */
    @DeleteMapping("models/{modelName}")
    public BizJobRunResult dropGdmModelDef(@Nonnull @NotBlank @PathVariable String modelName,
                                           @RequestParam(required = false) String bizInfo,
                                           @RequestParam(required = false, defaultValue = "false") Boolean deleteData) {
        return gdmModelService.dropGdmModel(modelName, bizInfo, deleteData);
    }

    @Nonnull
    @GetMapping("models")
    public List<GdmModelDto> queryGdmModelDef(@NotNull GdmModelQueryParams queryParams) {
        return gdmModelClient.findByParams(queryParams);
    }

    @PostMapping("models/_health-check")
    @Tag(name = "health-check-endpoint")
    public List<Issue> checkGdmModel() {
        log.info("checkGdmModel - tenantId: {}, userId: {}", TenantContextHolder.getTenantId(), PrincipalContextHolder.getUserId());
        return gdmPatternValidator.validate();
    }

    @PostMapping("models/{modelName}/events/{eventName}")
    public GdmModelDto defineGdmModelEvent(@Nonnull @NotBlank @PathVariable String modelName, @NotBlank @PathVariable String eventName, @NotNull @RequestBody List<GdmModelDto.Field> eventFields) {
        return gdmModelService.defineGdmModelEvent(modelName, eventName, eventFields);
    }

    @DeleteMapping("models/{modelName}/events/{eventName}")
    public boolean dropGdmModelEventDef(@Nonnull @NotBlank @PathVariable String modelName, @Nonnull @NotBlank @PathVariable String eventName, @RequestParam(name = "delete_data", required = false, defaultValue = "false") Boolean deleteData) {
        return gdmModelService.dropGdmModelEvent(modelName, eventName, deleteData);
    }

    @PostMapping("models/{modelName}/attributed-segment-families/{segmentFamilyEntityName}")
    public GdmModelDto defineGdmModelAttributedSegmentFamily(@Nonnull @NotBlank @PathVariable String modelName, @NotBlank @PathVariable String segmentFamilyEntityName, @NotNull @RequestBody List<GdmModelDto.Field> eventFields) {
        return gdmModelService.defineGdmModelAttributedSegmentFamily(modelName, segmentFamilyEntityName, eventFields);
    }

    @DeleteMapping("models/{modelName}/attributed-segment-families/{segmentFamilyEntityName}")
    public boolean dropGdmModelAttributedSegmentFamilyDef(@Nonnull @NotBlank @PathVariable String modelName, @Nonnull @NotBlank @PathVariable String segmentFamilyEntityName, @Parameter(description = "并未实现") @RequestParam(name = "delete_data", required = false, defaultValue = "false") Boolean deleteData) {
        return gdmModelService.dropGdmModelAttributedSegmentFamily(modelName, segmentFamilyEntityName, deleteData);
    }


    @PutMapping("entities/{entityName}")
    public boolean updateGdmEntity(@Nonnull @NotBlank @PathVariable String entityName, @Nonnull @NotNull @RequestBody ModifyGdmEntityRequest request) {
        return gdmModelService.updateGdmEntity(entityName, request);
    }

    @PostMapping("relationships")
    public boolean createRelationship(@NotNull @RequestBody GdmRelationshipRequest request) {
        return gdmModelService.createGdmRelationship(request);
    }

    @DeleteMapping("relationships/{leftEntityName}/{relationshipName}")
    public boolean deleteRelationship(@NotNull @PathVariable("leftEntityName") String leftEntityName,
                                      @NotNull @PathVariable("relationshipName") String relationshipName) {
        return gdmModelService.deleteGdmRelationship(leftEntityName, relationshipName);
    }
}
