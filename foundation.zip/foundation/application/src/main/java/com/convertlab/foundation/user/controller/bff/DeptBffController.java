package com.convertlab.foundation.user.controller.bff;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.webmvc.annotation.ViewController;
import com.convertlab.foundation.user.entity.Dept;
import com.convertlab.foundation.user.model.DeptDTO;
import com.convertlab.foundation.user.model.MoveDeptDTO;
import com.convertlab.foundation.user.service.DeptService;
import com.convertlab.foundation.user.service.UserDeptService;
import com.convertlab.foundation.user.service.UserService;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ViewController
public class DeptBffController {

    private final DeptService deptService;
    private final UserService userService;
    private final UserDeptService userDeptService;

    public DeptBffController(DeptService deptService, UserService userService, UserDeptService userDeptService) {
        this.deptService = deptService;
        this.userService = userService;
        this.userDeptService = userDeptService;
    }

    //list方法
    @GetMapping("/dept/list")
    public List<Dept> list(@RequestParam(required = false) String parent, @RequestParam(required = false) List<String> codes) {
        return deptService.listDepts(parent, codes);
    }

    //get方法
    @GetMapping("/dept/{code}")
    public Object get(@PathVariable String code) {
        return deptService.getDeptByCode(code);
    }

    //save方法
    @Nullable
    @PostMapping("/dept/create")
    public Object save(@Nonnull @RequestBody DeptDTO dto) {
        if (deptService.check(dto)) {
            Dept dept = deptService.saveDept(dto);
            if (dept == null) {
                throw new BusinessException(CommonErrors.GENERAL_ERROR, "MSG_004_001000", "create dept failed", new String[]{});
            } else {
                dept = deptService.getDeptByCode(dept.getCode());
                return dept;
            }
        }
        return null;
    }

    //update方法
    @Nonnull
    @PutMapping("/dept/{code}")
    public Dept update(@PathVariable String code, @Nonnull @RequestBody DeptDTO dto) {
        return deptService.updateDept(code, dto);
    }

    //delete方法
    @Nonnull
    @DeleteMapping("/dept/{code}")
    public Dept delete(@PathVariable String code) {

        Dept dept = deptService.deleteDept(code);
        return dept;
    }


    //get方法
    @Nonnull
    @GetMapping("/dept/check")
    public String check(@RequestParam(required = false) String name, @RequestParam(required = false) String outCode, @RequestParam(required = false) String parentOutCode) {

        DeptDTO dto = new DeptDTO();
        dto.setName(name);
        dto.setOutCode(outCode);
        dto.setParentOutCode(parentOutCode);

        return deptService.check(dto) ? "success" : "fail";
    }


    @Nonnull
    @PostMapping("/dept/move")
    public Map<String, String> move(@Nonnull @RequestBody MoveDeptDTO dto) {

        Map<String, String> result = new HashMap<>();
        result.put("status", "success");

        userDeptService.move(dto);

        return result;
    }

    @Nonnull
    @PostMapping("/dept/userDeptInfo")
    public Map<String, Object> userDeptInfo(@Nonnull @RequestBody Map map) {
        Integer userId = (Integer) map.get("userId");
        if (userId != null) {
            Map<String, Object> result = userDeptService.getUserDeptInfo(userId.longValue());
            return result;
        } else {
            throw new BusinessException(CommonErrors.MISSING_FIELD, "MSG_005_000006", "userId is null", new String[]{});
        }
    }

    @Nonnull
    @GetMapping("/dept/superiorDept")
    public String[] superiorDept(@Nullable String deptCode) {
        //如果没有传入deptCode，返回空
        if (deptCode == null || deptCode.isEmpty()) {
            return new String[]{};
        }

        Dept dept = deptService.getDeptByCode(deptCode);
        if (dept != null) {
            //将部门路径拆分成数组
            return dept.getPath().split("-");
        }
        return new String[]{};
    }

}
