package com.convertlab.foundation.kvstore.service.impl;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.convertlab.foundation.kvstore.dto.KeyValuesPair;
import com.convertlab.foundation.kvstore.dto.KvQuery;
import com.convertlab.foundation.kvstore.misc.AdHocMetasUtil;
import com.convertlab.foundation.kvstore.misc.AdHocTableMeta;
import com.convertlab.foundation.kvstore.service.HbaseStoreService;
import com.convertlab.foundation.kvstore.service.KvStorageFascadeService;
import com.convertlab.foundation.library.constant.DataProcessingMode;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.gdmmeta.client.GdmStorageMetaRtClient;
import com.convertlab.foundation.library.gdmmeta.model.storage.Storage;
import com.convertlab.foundation.library.hbase.core.HbaseColumnSchema;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import static com.convertlab.foundation.library.constant.CommonErrors.*;

@Service
@Slf4j
public class KvStorageFascadeServiceImpl implements KvStorageFascadeService {

    public static final String STORAGE_TYPE_KV = "KV";
    public static final String DB_TYPE_HBASE = "HBASE";
    public static final String DB_TYPE_MONGO = "MONGODB";
    private final GdmStorageMetaRtClient gdmStorageMetaClient;
    private final HbaseStoreService hbaseStoreService;

    public KvStorageFascadeServiceImpl(GdmStorageMetaRtClient gdmStorageMetaClient,
                                       HbaseStoreService hbaseStoreService ) {
        this.gdmStorageMetaClient = gdmStorageMetaClient;
        this.hbaseStoreService = hbaseStoreService;
    }

    /**
     * 根据条件查询对应的KVStore
     * @param kvQuery : 包含entityName和查询条件；Fascade会自动根据GDMMeta查找entityName的KV Store使用的存储类型：（Hbase, MongoDB...）
     *                  ，调用对应的Service进行查询
     * @return Array of <KvPair>
     */
    @Override
    public List<KeyValuesPair> batchGet(@Nonnull String entityName, @Nonnull KvQuery kvQuery) throws Exception{
        String storageType = this.getKvStorageType(entityName);
        if(Storage.isHbase(storageType)){
            String columnFamily = hbaseStoreService.getHbaseColumnFamily(entityName);
            String tableName = hbaseStoreService.getHbaseTableName(entityName);
            List<HbaseColumnSchema> columnSchemas = hbaseStoreService.getHbaseColumnSchemas(entityName);
            try {
                // TBD ， 查询类型需要根据Meta读取，暂时用String类型走通, 后面增强。
                return hbaseStoreService.batchSelect(tableName, columnFamily, kvQuery.getKeys(), kvQuery.getColumns(), columnSchemas);
            }catch (Exception e){
                log.error("get KV from Hbase failed.", e);
                throw new BusinessException(VALIDATION_ERROR, "MSG_006_000005", "failed querying hbase", new String[]{e.getMessage()});
            }
        }else if(DB_TYPE_MONGO.equals(storageType)){
            throw new BusinessException(VALIDATION_ERROR, "MSG_006_000004", "MongoDB KV Store is not supported yet.", new String[]{DB_TYPE_MONGO});
        }else{
            throw new BusinessException(VALIDATION_ERROR, "MSG_006_000004", storageType + " KV Store is not supported yet.", new String[]{storageType});
        }
    }

    /**
     * 批量插入，更新kvParis；当kvPair.key所对应的记录存在时，更新kvPari.values中的列；当kvPair.key不存在对应记录，则插入一条记录
     * @param entityName 表名
     * @param kvPairs List<KvPair>
     * @return
     */
    @Override
    public void batchUpsert(@Nonnull String entityName, List<KeyValuesPair> kvPairs) throws Exception{
        String storageType = this.getKvStorageType(entityName);
        if(Storage.isHbase(storageType)){
            String columnFamily = hbaseStoreService.getHbaseColumnFamily(entityName);
            String tableName = hbaseStoreService.getHbaseTableName(entityName);
            List<HbaseColumnSchema> columnSchemas = hbaseStoreService.getHbaseColumnSchemas(entityName);
            try{
                hbaseStoreService.batchInsertOrUpdate(tableName, columnFamily, kvPairs, columnSchemas);
            }catch (Exception e){
                log.error("get KV from Hbase failed.", e);
                throw new BusinessException(VALIDATION_ERROR, "MSG_006_000011", "failed to upsert hbase", new String[]{e.getMessage()});
            }
        }else if(DB_TYPE_MONGO.equals(storageType)){
            throw new BusinessException(VALIDATION_ERROR, "MSG_006_000004", "MongoDB KV Store is not supported yet.", new String[]{DB_TYPE_MONGO});
        }else{
            throw new BusinessException(VALIDATION_ERROR, "MSG_006_000004", storageType + " KV Store is not supported yet.", new String[]{storageType});
        }
    }

    @Override
    public void batchDelete(@Nonnull String entityName, List<KeyValuesPair> kvPairs) throws Exception{
        String storageType = this.getKvStorageType(entityName);
        if(Storage.isHbase(storageType)){
            String columnFamily = hbaseStoreService.getHbaseColumnFamily(entityName);
            String tableName = hbaseStoreService.getHbaseTableName(entityName);
            List<HbaseColumnSchema> columnSchemas = hbaseStoreService.getHbaseColumnSchemas(entityName);
            try{
                hbaseStoreService.batchDelete(tableName, columnFamily, kvPairs, columnSchemas);
            }catch (Exception e){
                log.error("delete from Hbase failed.", e);
                throw new BusinessException(VALIDATION_ERROR, "MSG_006_000015", "failed to delete hbase", new String[]{e.getMessage()});
            }
        }else if(DB_TYPE_MONGO.equals(storageType)){
            throw new BusinessException(VALIDATION_ERROR, "MSG_006_000004", "MongoDB KV Store is not supported yet.", new String[]{DB_TYPE_MONGO});
        }else{
            throw new BusinessException(VALIDATION_ERROR, "MSG_006_000004", storageType + " KV Store is not supported yet.", new String[]{storageType});
        }
    }

    @Override
    public Map<String, Map<String, Long>> batchIncrement(@Nonnull String tableName, List<KeyValuesPair> kvPairs) {
        AdHocTableMeta adHocTableMeta = AdHocMetasUtil.getAdHocTableMetaByName(tableName);
        if(adHocTableMeta != null){
            if(adHocTableMeta.getDbStorageTypes().containsKey(STORAGE_TYPE_KV)
                    && Storage.isHbase(adHocTableMeta.getDbStorageTypes().get(STORAGE_TYPE_KV).getDbType())) {
                List<AdHocTableMeta.ColumnFamily>  columnFamilies = adHocTableMeta.getDbStorageTypes().get(STORAGE_TYPE_KV).getColumnFamilies();
                if(columnFamilies.size() != 1){
                    throw new BusinessException(VALIDATION_ERROR, "MSG_006_000003", "Hbase KV Store only support one column family.",new String[]{});
                }
                String columnFamily = columnFamilies.get(0).getName();
                try{
                    List<HbaseColumnSchema> columnSchemas = hbaseStoreService.getHbaseColumnSchemas(tableName);
                    return hbaseStoreService.batchIncrement(tableName, columnFamily, kvPairs, columnSchemas);
                }catch (Exception e){
                    log.error("delete from Hbase failed.", e);
                    throw new BusinessException(VALIDATION_ERROR, "MSG_006_000015", "failed to delete hbase", new String[]{e.getMessage()});
                }
            }else{
                throw new BusinessException(VALIDATION_ERROR, "MSG_006_000004", "MongoDB KV Store is not supported yet.", new String[]{DB_TYPE_MONGO});
            }
        }else{
            throw new BusinessException(VALIDATION_ERROR, "MSG_006_000017", "Table "+ tableName + " is not defined", new String[]{tableName});
        }
    }


    /**
     * 根据表名获取表KV存储类型
     * @param entityName
     * @return
     */
    @Nullable
    private String getKvStorageType(@Nonnull String entityName){
        // 优先查看AdHoc的定义
        AdHocTableMeta adHocTableMeta = AdHocMetasUtil.getAdHocTableMetaByName(entityName);
        if(adHocTableMeta!= null && adHocTableMeta.getDbStorageTypes().containsKey(STORAGE_TYPE_KV)){
            return adHocTableMeta.getDbStorageTypes().get(STORAGE_TYPE_KV).getDbType();
        }
        // 如果AdHoc没有定义，查GDM
        Storage storage = gdmStorageMetaClient.getTableStorageOfMode(entityName, DataProcessingMode.KV);
        if(storage != null){
            return storage.getDbType();
        }
        return null;
    }


}
