package com.convertlab.foundation.gdmpattern.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DeleteGdmEntityDataParams {

    public static final String DELETE_TYPE_ENTITY = "entity";
    public static final String DELETE_TYPE_FIELDS = "fields";

    private Long tenantId;
    private String gdmEntityName;
    private String dbTableName;
    private String tablePartitionIdentifierField;
    private String tablePartitionIdentifierValue;
    private String tablePartitionIdentifierType;
    private String primaryKeyField;
    private List<String> dbTypes;
    // 删除类型，entity（删除entity的所有数据）或者fields（删除entity中部分字段的数据）
    private String deleteType;
    private List<String> fieldsToBeRemoved;
    private List<String> dbColumnsToBeRemoved;
}
