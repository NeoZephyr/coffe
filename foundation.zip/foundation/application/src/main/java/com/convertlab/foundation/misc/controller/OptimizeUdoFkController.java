package com.convertlab.foundation.misc.controller;

import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.misc.dto.CastAndCopyColumnRequest;
import com.convertlab.foundation.misc.dto.UpdateFieldMappingRequest;
import com.convertlab.foundation.misc.job.OptimizeUdoFkAutoRunner;
import com.convertlab.foundation.misc.service.OptimizeUdoFkService;
import io.swagger.v3.oas.annotations.security.SecurityRequirements;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/v1/optimize")
@RequiredArgsConstructor
public class OptimizeUdoFkController {
    private final OptimizeUdoFkService optimizeUdoFkService;
    private final OptimizeUdoFkAutoRunner autoRunner;

    @GetMapping(value = "/scan")
    public Map<Long, List<Pair<String, GdmField>>> scan(@RequestHeader(name = "x-tenant-id", required = false, defaultValue = "-1") long tenantId) {
        try(TemporaryTenantContext ignored = new TemporaryTenantContext(tenantId)) {
            return autoRunner.scan();
        }
    }

    @PostMapping(value = "/autorun")
    @SecurityRequirements(value = {})
    public void autoRun(@RequestHeader(name = "x-tenant-id", required = false, defaultValue = "-1") long tenantId) {
        try(TemporaryTenantContext ignored = new TemporaryTenantContext(tenantId)) {
            autoRunner.autoRun();
        }
    }

    @PostMapping(value = "/autorecycle")
    @SecurityRequirements(value = {})
    public void autoRecycle(@RequestHeader(name = "x-tenant-id", required = false, defaultValue = "-1") long tenantId) {
        try(TemporaryTenantContext ignored = new TemporaryTenantContext(tenantId)) {
            autoRunner.autoColumnRecycle();
        }
    }

    @PostMapping(value = "/run/{entityName}/{fieldName}")
    public void optimize(@PathVariable String entityName, @PathVariable String fieldName) {
        autoRunner.optimize(entityName, fieldName);
    }

    @PostMapping(value = "castAndCopy")
    public void castAndCopy(@RequestBody CastAndCopyColumnRequest request) {
        optimizeUdoFkService.castAndCopyColumn(request);
    }

    @PostMapping(value = "updateFieldMapping")
    public void updateFieldMapping(@RequestBody UpdateFieldMappingRequest request) {
        optimizeUdoFkService.updateGdmEntityFieldMapping(request);
    }

    @PostMapping(value = "unsetColumn")
    public void unsetColumn(@RequestBody CastAndCopyColumnRequest request) {
        optimizeUdoFkService.unsetColumn(request);
    }
}
