package com.convertlab.foundation.datapermission.service;

import com.convertlab.foundation.datapermission.entity.BaseResourceAccessEntity;
import com.convertlab.foundation.datapermission.entity.ResourceEntity;
import com.convertlab.foundation.datapermission.model.DeleteShareRequestDto;
import com.convertlab.foundation.datapermission.model.ResourceListShareResponseDto;
import com.convertlab.foundation.datapermission.model.ResourceShareRequestDto;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.datapermission.GrantedReason;
import com.convertlab.foundation.library.datapermission.GrantedSubjectType;
import com.convertlab.foundation.library.datapermission.ResourceAccessDto;
import com.convertlab.foundation.library.datapermission.model.BatchResourceAccessDto;
import com.convertlab.foundation.library.datapermission.model.ResourceMeta;
import com.convertlab.foundation.library.datapermission.service.ResourceMetaService;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.jdbc.core.OLTPJdbcTemplate;
import com.convertlab.foundation.library.jdbc.datasource.lookup.DataSourceLookupHelper;
import com.convertlab.foundation.user.entity.Dept;
import com.convertlab.foundation.user.entity.User;
import com.convertlab.foundation.user.entity.UserGroup;
import com.convertlab.foundation.user.service.DeptService;
import com.convertlab.foundation.user.service.UserGroupService;
import com.convertlab.foundation.user.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ResourceService {

    final OLTPJdbcTemplate oltpJdbcTemplate;

    final UserService userService;

    final UserGroupService userGroupService;

    final DeptService deptService;

    final ResourceAccessServiceWrapper resourceAccessServiceWrapper;

    final ResourceMetaService resourceMetaService;

    public ResourceService(OLTPJdbcTemplate oltpJdbcTemplate, UserService userService, UserGroupService userGroupService, DeptService deptService, ResourceAccessServiceWrapper resourceAccessServiceWrapper, ResourceMetaService resourceMetaService) {
        this.oltpJdbcTemplate = oltpJdbcTemplate;
        this.userService = userService;
        this.userGroupService = userGroupService;
        this.deptService = deptService;
        this.resourceAccessServiceWrapper = resourceAccessServiceWrapper;
        this.resourceMetaService = resourceMetaService;
    }

    public ResourceEntity findEntity(ResourceMeta meta, String resourceCode){
        ResourceEntity[] entity = new ResourceEntity[1];
        if(meta.isMainDB()){
            DataSourceLookupHelper.withLookupKey("main", () -> {
                entity[0] = findEntityInternal(meta, resourceCode);
            });
        } else {
            entity[0] = findEntityInternal(meta, resourceCode);
        }
        return entity[0];
    }

    public ResourceEntity findEntityInternal(ResourceMeta meta, String resourceCode){

        String sqlTemplate = "/*+DATA_VISIBILITY_IGNORE_TABLES(%s)*/ select %s, owner_id, dept_code from %s where %s = ?";
        String sql = String.format(sqlTemplate, meta.getEntityName(), meta.getIdColumn(), meta.getEntityName(), meta.getIdColumn());

       List<Map<String, Object>> rs = new ArrayList<>();
        if("Long".equals(meta.getIdType())){
            rs.addAll(Optional.ofNullable(oltpJdbcTemplate.queryForList(sql, new Object[]{NumberUtils.createLong(resourceCode)})).orElseGet(ArrayList::new));
        }else if("String".equals(meta.getIdType())){
            rs.addAll(Optional.ofNullable(oltpJdbcTemplate.queryForList(sql, new Object[]{resourceCode})).orElseGet(ArrayList::new));
        }

        if(rs.isEmpty()){
            return null;
        }

        ResourceEntity entity = getResourceEntity(meta, rs.get(0));
        return entity;
    }

    public List<ResourceEntity> findEntities(ResourceMeta meta, List<String> resourceCodes){
        final List<ResourceEntity>[] entities = new List[]{new ArrayList<ResourceEntity>()};
        if(meta.isMainDB()){
            DataSourceLookupHelper.withLookupKey("main", () -> {
                entities[0] = findEntitiesInternal(meta, resourceCodes);
            });
        } else {
            entities[0] = findEntitiesInternal(meta, resourceCodes);
        }
        return entities[0];
    }

    public List<ResourceEntity> findEntitiesInternal(ResourceMeta meta, List<String> resourceCodes){

        String placeholders = resourceCodes.stream()
                .map(code -> "?")
                .collect(Collectors.joining(", "));
        placeholders = "(" + placeholders + ")";

        String sqlTemplate = "/*+DATA_VISIBILITY_IGNORE_TABLES(%s)*/ select %s, owner_id, dept_code from %s where %s in " + placeholders;
        String sql = String.format(sqlTemplate, meta.getEntityName(), meta.getIdColumn(), meta.getEntityName(), meta.getIdColumn());

        List<Map<String, Object>> rs = new ArrayList<>();
        if("Long".equals(meta.getIdType())){
            rs.addAll(Optional.ofNullable(oltpJdbcTemplate.queryForList(sql, resourceCodes.toArray())).orElseGet(ArrayList::new));
        }else if("String".equals(meta.getIdType())){
            Object[] objects = resourceCodes.toArray();
            rs.addAll(Optional.ofNullable(oltpJdbcTemplate.queryForList(sql, objects)).orElseGet(ArrayList::new));
        }

        List<ResourceEntity> results = new ArrayList<ResourceEntity>();
        rs.forEach(map -> {

            ResourceEntity entity = getResourceEntity(meta, map);
            results.add(entity);
        });

        return results;
    }

    @NotNull
    private static ResourceEntity getResourceEntity(ResourceMeta meta, Map<String, Object> map) {
        ResourceEntity entity = new ResourceEntity();
        entity.setResourceType(meta.getResourceType());
        entity.setResourceCode(map.get(meta.getIdColumn()).toString());
        Object ownerId = map.get("owner_id");
        //ownerId 有可能是int，也有可能是long，需要兼容处理。
        if(ownerId == null){
            entity.setOwnerId(null);
        }else if(ownerId instanceof Long){
            entity.setOwnerId((Long)ownerId);
        }else {
            entity.setOwnerId(Long.valueOf(ownerId.toString()));
        }
        entity.setDeptCode((String) map.get("dept_code"));
        return entity;
    }

    public void fillAccessorDetail(ResourceListShareResponseDto dto){

        //将dto.getUsers()里面的get("id")是否变成List<Long>
        List<Long> userIdList = dto.getUsers().stream()
                .map(map -> Optional.ofNullable(map.get("id")))
                .filter(Optional::isPresent)
                .map(optional -> Long.valueOf(optional.get().toString()))
                .collect(Collectors.toList());

        //将dto.getUserGroups()里面的get("id")是否变成List<Long>
        List<String> userGroupCodeList = dto.getUserGroups().stream()
                .map(map -> map.get("code"))
                .filter(Objects::nonNull)
                .map(Object::toString)
                .collect(Collectors.toList());

        //将dto.getDepts()里面的get("code")是否变成List<String>
        List<String> deptCodeList =  dto.getDepts().stream()
                .map(map -> map.get("code"))
                .filter(Objects::nonNull)
                .map(Object::toString)
                .collect(Collectors.toList());

        if(!userIdList.isEmpty()){
            List<User> userList = userService.getUserByIdInList(userIdList);
            //轮询dto.getUsers(), 根据id从userList中获取user, 并给user赋值
            dto.getUsers().forEach(map -> {
                Optional<User> userOptional = userList.stream()
                        .filter(user -> user.getId().equals(Long.valueOf(map.get("id").toString())))
                        .findFirst();
                if(userOptional.isPresent()){
                    User user = userOptional.get();
                    map.put("name", user.getName());
                    map.put("loginName", user.getLoginName());
                }
            });
        }

        if(!userGroupCodeList.isEmpty()){
            List<UserGroup> userGroups = userGroupService.getUserGroupByCodeList(userGroupCodeList);
            //轮询dto.getUserGroups(), 根据id从userGroupList中获取user, 并给user赋值
            dto.getUserGroups().forEach(map -> {
                Optional<UserGroup> userGroupOptional = userGroups.stream()
                        .filter(userGroup -> userGroup.getCode().equals(map.get("code").toString()))
                        .findFirst();
                if(userGroupOptional.isPresent()){
                    UserGroup userGroup = userGroupOptional.get();
                    map.put("name", userGroup.getName());
                    map.put("id", userGroup.getId());
                }
            });
        }

        if(!deptCodeList.isEmpty()) {
            List<Dept> depts = deptService.getDeptsByCodeList(deptCodeList);
            //轮询dto.getDepts(), 根据coddeptList中获取dept, 并给dept赋值
            dto.getDepts().forEach(map -> {
                Optional<Dept> deptOptional = depts.stream()
                        .filter(dept -> dept.getCode().equals(map.get("code").toString()))
                        .findFirst();
                if (deptOptional.isPresent()) {
                    Dept dept = deptOptional.get();
                    map.put("name", dept.getName());
                    map.put("code", dept.getCode());
                    map.put("outCode", dept.getOutCode());
                }
            });
        }
    }


    @NotNull
    public void internal_share(ResourceShareRequestDto dto) {
        //将dto转为ResourceAccessDTO。
        List<ResourceAccessDto> resourceAccessDtos = dto.convertToResourceAccessDTO();

        //删除该resourceCode的所有resource access历史记录。
        //确认了重构之前系统的行为，UI一直是增量而非全量，和Cid讨论后决定把这段注释掉
//        List<BaseResourceAccessEntity> existSharedData = resourceAccessServiceWrapper.list(dto.getResourceType(), dto.getResourceCode());
//        List<BaseResourceAccessEntity> filteredData = existSharedData.stream()
//                .filter(entity -> GrantedReason.GRANTED_REASON_MANUAL_SHARE.equals(entity.getGrantedReason()))
//                .collect(Collectors.toList());
//
//        if (!CollectionUtils.isEmpty(filteredData)) {
//            resourceAccessServiceWrapper.batchDelete(dto.getResourceType(), filteredData);
//        }

        //调用resourceAccessServiceWrapper的batchUpsert方法保存resource access dto。
        resourceAccessServiceWrapper.batchSave(new BatchResourceAccessDto(dto.getResourceType(), resourceAccessDtos));
    }


    @NotNull
    public Map<String, String> deleteShareInternal(DeleteShareRequestDto dto) {
        if (StringUtils.isBlank(dto.getResourceType()) || StringUtils.isBlank(dto.getResourceCode()) || StringUtils.isBlank(dto.getAccessScope()) || StringUtils.isBlank(dto.getAccessCode())){
            throw new BusinessException(CommonErrors.MISSING_FIELD, "MSG_005_000001", "resourceType is empty or resourceCode is empty.", new String[]{});
        }

        //根据resourceType获取metadata
        ResourceMeta resourceMeta = resourceMetaService.getResourceMeta(dto.getResourceType());

        //如果resource meta为空， 返回错误信息。
        if (resourceMeta == null) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_005_000002", String.format("resource type %s not support.", dto.getResourceType()), new String[]{dto.getResourceType()});
        }

        //将accessScope转化为GrantedSubjectType
        GrantedSubjectType grantedSubjectType = null;

        try {
            grantedSubjectType = GrantedSubjectType.fromValue(dto.getAccessScope());
        }catch(Exception e){
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_005_000003", String.format("granted subject type %s not support.", dto.getAccessScope()), new String[]{dto.getAccessScope()});
        }

        //如果grantedSubjectType为空， 返回错误信息。
        if (grantedSubjectType == null) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_005_000003", String.format("granted subject type %s not support.", dto.getAccessScope()), new String[]{dto.getAccessScope()});
        }

        //如果grantedSubjectType是dept类型，那么accessCode需要处理为deptCode, 原本是deptPath。
        if(GrantedSubjectType.SUBJECT_TYPE_DEPT.equals(grantedSubjectType)){
            //dto.getAccessCode()根据 - 进行分割，取最后一个。
            String deptCode = dto.getAccessCode();
            Optional<String> lastPart = Arrays.stream(deptCode.split("-"))
                    .reduce((first, second) -> second);
            lastPart.ifPresent(dto::setAccessCode);
        }

        resourceAccessServiceWrapper.delete(dto.getResourceType(), dto.getResourceCode(), grantedSubjectType, dto.getAccessCode());

        Map<String, String> result = new HashMap<>();
        result.put("status", "success");
        return result;
    }
}
