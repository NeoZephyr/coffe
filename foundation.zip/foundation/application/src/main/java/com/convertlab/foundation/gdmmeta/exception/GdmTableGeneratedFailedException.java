package com.convertlab.foundation.gdmmeta.exception;

public class GdmTableGeneratedFailedException extends RuntimeException{
    public GdmTableGeneratedFailedException(String message) {
        super(message);
    }

    public GdmTableGeneratedFailedException(String message, Throwable cause) {
        super(message, cause);
    }

    public GdmTableGeneratedFailedException(Throwable cause) {
        super(cause);
    }

}
