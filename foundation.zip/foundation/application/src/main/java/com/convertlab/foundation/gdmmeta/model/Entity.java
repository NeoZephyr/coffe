package com.convertlab.foundation.gdmmeta.model;



import com.convertlab.foundation.gdmmeta.exception.GdmTableGeneratedFailedException;
import com.convertlab.foundation.gdmmeta.service.impl.loader.SystemMetaDefObject;
import com.convertlab.foundation.library.constant.DataProcessingMode;
import com.convertlab.foundation.library.gdmmeta.model.*;
import com.convertlab.foundation.gdmmeta.persistance.entity.GdmEntityModel;
import com.convertlab.foundation.gdmmeta.persistance.entity.GdmFieldModel;
import com.convertlab.foundation.gdmmeta.persistance.entity.GdmInheritanceModel;
import com.convertlab.foundation.gdmmeta.persistance.entity.GdmTablePartitionModel;
import com.convertlab.foundation.gdmmeta.persistance.table.GdmColumnModel;
import com.convertlab.foundation.gdmmeta.persistance.table.GdmTableModel;
import com.convertlab.foundation.library.gdmmeta.model.storage.*;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import lombok.*;

import java.time.Instant;
import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import static com.convertlab.foundation.gdmmeta.persistance.entity.GdmEntityModel.BASE_PATH;

@Slf4j
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Entity implements AssignValueStrategy<Entity> {
    @Nullable
    private Integer id;
    @Nullable
    private String entityName;
    @Nullable
    private Boolean dbView;
    @Nullable
    private String dbTableName;
    @Nullable
    private List<Field> fields;
    @Nullable
    private Inheritance inheritance;
    @Nullable
    private TablePartition tablePartition;
    @Nullable
    private String primaryKeyField;
    @Nullable
    private MetaConf metaConf;

    /**
     * The same as {@link MetaProperty}
     */
    protected Boolean deletable = true;
    protected Boolean modifiable = true;
    protected Boolean isSystem = false;

    @Nullable
    private Map<GdmEntity.RequiredStorageType, Storage> dbStorageTypes;

    @JsonSetter("inheritance")
    public void setInheritance(Inheritance inheritance) {
        this.inheritance = inheritance;
    }

    @JsonSetter("tablePartition")
    public void setTablePartition(TablePartition tablePartition) {
        this.tablePartition = tablePartition;
    }

    @JsonSetter("primaryKeyField")
    public void setPrimaryKeyField(String primaryKeyField) {
        this.primaryKeyField = primaryKeyField;
    }

    @JsonSetter("isDbView")
    public void setIsDbView(Boolean isDbView) {
        this.dbView = isDbView;
    }

    public Entity(@Nonnull Entity ora) {
        id = ora.id;
        entityName = ora.entityName;
        dbView = ora.dbView;
        dbTableName = ora.dbTableName;
        fields = ora.fields.stream().map(Field::new).collect(Collectors.toList());
        inheritance = ora.inheritance == null ? null : new Inheritance(ora.inheritance);
        tablePartition = ora.tablePartition;
        primaryKeyField = ora.primaryKeyField;
        dbStorageTypes = ora.dbStorageTypes;
//        metaConf = ora.metaConf;
        isSystem = ora.isSystem;
        deletable = ora.deletable;
        modifiable = ora.modifiable;
    }


    public Entity(@Nonnull SystemMetaDefObject.GdmEntityTableDef ora) {
        entityName = ora.getEntityName();
        dbView = ora.getDbView();
        dbTableName = ora.getDbTableName();
        fields = new ArrayList<>();
        inheritance = ora.getInheritance() == null ? null : new Inheritance(ora.getInheritance());
        tablePartition = ora.getTablePartition() == null ? null : new TablePartition(ora.getTablePartition());
        dbStorageTypes = ora.getDbStorageTypes();
        metaConf = getMetaConf(ora);
        isSystem = ora.getIsSystem();
        deletable = ora.getDeletable();
        modifiable = ora.getModifiable();
    }

    private MetaConf getMetaConf(SystemMetaDefObject.GdmEntityTableDef ora) {
        SystemMetaDefObject.MetaConf sysMetaConf = ora.getMetaConf();
        Objects.requireNonNull(sysMetaConf, "metaConf should not be null");

        SystemMetaDefObject.SystemLevel systemLevel = sysMetaConf.getSystemLevel();
        SystemMetaDefObject.TenantLevel tenantLevel = sysMetaConf.getTenantLevel();

        SystemLevel systemLevelRet = new SystemLevel(systemLevel.isEnabled(), systemLevel.isSuTable());
        TenantLevel tenantLevelRet = new TenantLevel(tenantLevel.isEnabled());
        return new MetaConf(systemLevelRet, tenantLevelRet);
    }


    public Entity(@Nonnull GdmEntity ora) {
        entityName = ora.getEntityName();
        dbView = ora.isDbView();
        dbTableName = ora.getDbTableName();
        fields = ora.getFields().stream().map(Field::new).collect(Collectors.toList());
        inheritance = ora.getInheritance() == null ? null : new Inheritance(ora.getInheritance());
        tablePartition = ora.getTablePartition() == null ? null : new TablePartition(ora.getTablePartition());
        primaryKeyField = ora.getPrimaryKeyField();
        dbStorageTypes = hardcodeStorageByDataProcessingModes(ora.dataProcessingModes());
        isSystem = ora.getIsSystem();
        deletable = ora.getDeletable();
        modifiable = ora.getModifiable();
    }

    //TODO #implementme  should be replaced with dataProcessingModeProperties
    // 需要把 Storage 从 Entity 中挪出，考虑把 Entity Storage 关系分离到独立的 loader 中。
    private static Map<GdmEntity.RequiredStorageType, Storage> hardcodeStorageByDataProcessingModes(List<DataProcessingMode> modes ) {

        Set<GdmEntity.RequiredStorageType> storageTypes = modes.stream().map(GdmEntity.RequiredStorageType::valueOf).collect(Collectors.toSet());

        ImmutableList<String> dummyFieldList = ImmutableList.of("id");
        Map<GdmEntity.RequiredStorageType, Storage> dummyStorageTypeMap = ImmutableMap.of(
                GdmEntity.RequiredStorageType.OLTP, ImmutableMysql.builder().build(),
                GdmEntity.RequiredStorageType.REALTIME_AP, ImmutableKudu.builder().hashPartitionColumns(dummyFieldList).primaryKeyColumns(dummyFieldList).build(),
                GdmEntity.RequiredStorageType.BATCH_AP, ImmutableParquet.builder().partitionBy(dummyFieldList).build(),
                GdmEntity.RequiredStorageType.KV, ImmutableHbase.builder().dbTable("dummy").columnFamilies(new ArrayList<>()).build()
        );

        return dummyStorageTypeMap.entrySet().stream().filter(entry -> storageTypes.contains(entry.getKey()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }


    /**
     * AssignValueStrategy = ReplaceOrAddIfNotNull 加法操作
     * 使用overlay中的值来覆盖或者添加base中的值
     * @param overlay
     * @param gdmObjectMerger
     * @return
     */
    @Nonnull
    @Override
    public Entity replaceOrAddIfNotNull(@Nullable Entity overlay, @Nonnull GdmObjectMerger gdmObjectMerger) {
        if (overlay == null) {
            return this;
        }
        if (overlay.id != null) {
            this.id = overlay.id;
        }
        if (overlay.entityName != null) {
            this.entityName = overlay.entityName;
        }
        if (overlay.dbView != null) {
            this.dbView = overlay.dbView;
        }
        if (overlay.dbTableName != null) {
            this.dbTableName = overlay.dbTableName;
        }
        if (overlay.fields != null && overlay.fields.size() > 0) {
            if (gdmObjectMerger.getRecursiveStrategy(Entity.class).equals(GdmObjectMerger.RecursiveStrategy.NO_RECURSIVE)) {
                // 如果是NO_RECURSIVE，那么就直接把overlay的fields赋值给this.fields
                this.fields = overlay.fields;
            }
            else {
                // 如果是RECURSIVE，那么就把overlay的fields和this.fields合并
                // 对于没有匹配的overlay上的field，就直接加到this.fields上
                handleFieldList(overlay, gdmObjectMerger, ListIterator::set,
                        unmatchedOverlayField->fields.add(unmatchedOverlayField));
            }
        }
        if (overlay.inheritance != null) {
            this.inheritance = overlay.inheritance;
        }
        if (overlay.tablePartition != null ) {
            this.tablePartition = overlay.tablePartition;
        }
        if (overlay.primaryKeyField != null) {
            this.primaryKeyField = overlay.primaryKeyField;
        }
        if (overlay.dbStorageTypes != null && overlay.dbStorageTypes.size() > 0) {
            this.dbStorageTypes = overlay.dbStorageTypes;
        }
        if (overlay.isSystem != null) {
            this.isSystem = overlay.isSystem;
        }
        if (overlay.deletable != null) {
            this.deletable = overlay.deletable;
        }
        if (overlay.modifiable != null) {
            this.modifiable = overlay.modifiable;
        }
        return this;
    }

    /**
     * AssignValueStrategy = UnsetIfNotNull 减法操作
     * 如果overlay中的某个字段的值不为空，则将base中的值置为null
     * @param overlay
     * @param gdmObjectMerger
     * @return
     */
    @Nonnull
    @Override
    public Entity unsetIfNotNull(@Nullable Entity overlay, @Nonnull GdmObjectMerger gdmObjectMerger) {
        if (overlay == null) {
            return this;
        }
        if (overlay.id != null) {
            this.id = null;
        }
        if (overlay.entityName != null) {
            this.entityName = null;
        }
        if (overlay.dbView != null) {
            this.dbView = null;
        }
        if (overlay.dbTableName != null) {
            this.dbTableName = null;
        }
        if (overlay.fields != null) {
            if (gdmObjectMerger.getMergeStrategies(this.getClass()).getRecursiveStrategy().equals(GdmObjectMerger.RecursiveStrategy.NO_RECURSIVE)) {
                // 如果是NO_RECURSIVE，那么就直接把overlay的fields赋值给this.fields
                this.fields = null;
            }
            else {
                // 如果是RECURSIVE，那么就把overlay的fields和this.fields 按照fields的策略来合并
                // 这里需要把找到的field给删掉
                handleFieldList(overlay, gdmObjectMerger, (iterator, foundOverlayField)-> iterator.remove() , unmatchedOverlayField->{});
            }
        }

        if (overlay.inheritance!=null) {
            this.inheritance = null;
        }

        if (overlay.tablePartition!=null) {
            this.tablePartition = null;
        }

        if (overlay.primaryKeyField != null) {
            this.primaryKeyField = null;
        }

        if (overlay.dbStorageTypes != null) {
            this.dbStorageTypes = null;
        }
        return this;
    }

    @Nonnull
    public Entity updateFieldOrInitFieldList(@Nonnull Entity overlay, @Nonnull GdmObjectMerger gdmObjectMerger) {
        if (overlay.fields != null && !overlay.fields.isEmpty()) {
            if (gdmObjectMerger.getMergeStrategies(this.getClass()).getRecursiveStrategy().equals(GdmObjectMerger.RecursiveStrategy.NO_RECURSIVE)) {
                // 如果是NO_RECURSIVE，那么就直接把overlay的fields赋值给this.fields
                this.fields = overlay.fields;
            }
            else {
                //如果base中没有fields信息，直接全部添加
                if (this.fields.isEmpty()) {
                    this.fields.addAll(overlay.fields);
                }
                //如果base中已经存在field信息，则更新
                if (!this.fields.isEmpty()){
                    handleFieldList(overlay, gdmObjectMerger, (iterator, foundOverlayField)-> {} , unmatchedOverlayField->{});
                }
            }
        }
        return this;
    }

    /**
     * 处理fields的合并，策略从 GdmObjectMerger 中读取。
     * RecursiveStragey 控制是否递归合并
     * MatchStrategy 控制匹配算法
     * @param overlay 将合并字段的实体
     * @param gdmObjectMerger 合并所使用的上下文
     * @param foundAction 当在基础实体和叠加实体中都找到一个字段时要执行的操作
     * @param notFoundAction 当在叠加实体中找到一个字段但在基础实体中找不到时要执行的操作
     */
    private void handleFieldList(@NonNull Entity overlay, @Nonnull GdmObjectMerger gdmObjectMerger,
                                 @Nonnull BiConsumer<ListIterator<Field>, Field> foundAction, Consumer<Field> notFoundAction) {
        ListIterator<Field> iterator = fields.listIterator();
        while (iterator.hasNext()) {
            Field baseField = iterator.next();
            Optional<Field> matchedOverlayField = overlay.fields.stream()
                    .filter(overlayField -> gdmObjectMerger.getMatchStrategy(Field.class).apply(baseField, overlayField))
                    .findFirst();
            matchedOverlayField.ifPresent(overlayField -> {
                if (gdmObjectMerger.getRecursiveStrategy(Entity.class).equals(GdmObjectMerger.RecursiveStrategy.RECURSIVE)) {
                    // 如果是RECURSIVE，那么就把overlay的fields和this.fields合并
                    gdmObjectMerger.getAssignValueStrategy(Field.class)
                            .apply(baseField, overlayField, gdmObjectMerger);
                } else {
                    // 如果是StopAtValueObject 那么按照外部传入的策略来处理找到的field
                    foundAction.accept(iterator, overlayField);
                }
            });
        }
        // Find fields in overlay but not in base
        if (this.fields.isEmpty()) {
            overlay.fields.forEach(notFoundAction);
        } else {
            overlay.fields.stream()
                    .filter(overlayField -> fields.stream().noneMatch(baseField -> gdmObjectMerger
                            .getMatchStrategy(Field.class).apply(baseField, overlayField)))
                    .forEach(notFoundAction);
        }
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MetaConf {
        SystemLevel systemLevel;
        TenantLevel tenantLevel;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SystemLevel {
       boolean enabled;
       boolean suTable;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TenantLevel {
        boolean enabled;
    }

    @Nonnull
    public Boolean checkIsSuTable() {
        return Optional.ofNullable(getMetaConf())
                .map(MetaConf::getSystemLevel)
                .map(SystemLevel::isSuTable)
                .orElse(true);
    }

    @Nonnull
    public GdmEntity gdmEntity() {

        Assert.notNull(fields, "fields of GdmEntity is null: " + this);
        List<GdmField> gdmFieldList = fields.stream().map(Field::gdmField).collect(Collectors.toList());

        long customerIdSize = gdmFieldList.stream().filter(
                gdmField -> gdmField.getDbColumnName().equals("customer_id")).count();
        Assert.isTrue(customerIdSize == 1 || customerIdSize == 0,
                "entity " + entityName + " has two customerIds : " + gdmFieldList);
        GdmTablePartition gdmTablePartition = tablePartition == null ? null : tablePartition.gdmTablePartition();
        GdmInheritance gdmInheritance = inheritance == null ? null : inheritance.gdmInheritance();
        GdmEntity gdmEntity = ImmutableGdmEntity.builder().entityName(entityName)
                .isDbView(dbView).dbTableName(dbTableName)
                .fields(gdmFieldList)
                .inheritance(gdmInheritance)
                .tablePartition(gdmTablePartition)
                .primaryKeyField(primaryKeyField)
                .dataProcessingModes(dbStorageTypes.keySet().stream().map(GdmEntity.RequiredStorageType::mode).collect(Collectors.toList()))
                .isSystem(isSystem)
                .deletable(deletable)
                .modifiable(modifiable)
                .build();

        return gdmEntity;
    }

    @Nonnull
    public GdmEntityModel gdmEntityModel() {
        GdmEntityModel gdmEntityModel = new GdmEntityModel();
        gdmEntityModel.setEntityName(getEntityName());
        gdmEntityModel.setDbTableName(getDbTableName());
        gdmEntityModel.setPrimaryKeyField(getPrimaryKeyField());
        List<GdmFieldModel> fieldModels = getFields().stream().map(field -> field.gdmFieldModel()).collect(Collectors.toList());
        gdmEntityModel.setFields(fieldModels);
        GdmInheritanceModel inheritanceModel = getInheritance() == null ? null : getInheritance().gdmInheritanceModel();
        gdmEntityModel.setInheritance(inheritanceModel);
        GdmTablePartitionModel tablePartitionModel = getTablePartition() == null ? null : getTablePartition().gdmTablePartitionModel();
        gdmEntityModel.setTablePartition(tablePartitionModel);
        Map<GdmEntity.RequiredStorageType, Storage> dbStorageTypesMap = getDbStorageTypes();
        ArrayList<DataProcessingMode> dataProcessingModes = new ArrayList<>(dbStorageTypesMap.keySet().stream().map(
                GdmEntity.RequiredStorageType::mode
        ).collect(Collectors.toList()));
        gdmEntityModel.setDataProcessingModes(dataProcessingModes);
        gdmEntityModel.setSelf(BASE_PATH + "/" + getEntityName());
        gdmEntityModel.setBasePath(BASE_PATH);
        gdmEntityModel.setLastUpdated(Instant.now());
        gdmEntityModel.setIsSystem(isSystem);
        gdmEntityModel.setDeletable(deletable);
        gdmEntityModel.setModifiable(modifiable);
        return gdmEntityModel;
    }

    @Nonnull
    public static GdmTableModel newGdmTableModel(@Nullable Entity mysqlTableEntity, @Nullable Entity impalaTableEntity, @Nonnull List<GdmTableModel.StorageModel> storageModels) {
        if (mysqlTableEntity == null && impalaTableEntity == null) {
            return null;
        }

        GdmTableModel gdmTableModel = new GdmTableModel();
        Entity inputEntity  = mysqlTableEntity == null ? impalaTableEntity : mysqlTableEntity;
        List<Field> mysqlFields = mysqlTableEntity == null ? Collections.emptyList() : mysqlTableEntity.getFields();
        List<Field> impalaFields = impalaTableEntity == null ? Collections.emptyList() : impalaTableEntity.getFields();
        List<String> dbTypes = storageModels.stream().map(model -> model.getStorage().getDbType()).collect(Collectors.toList());
        List<GdmColumnModel> columnModelList = null;
        try {
            columnModelList = composeColumnModelList(mysqlFields, impalaFields, dbTypes, inputEntity.getDbTableName());
        } catch (GdmTableGeneratedFailedException e) {
            String message = "mysqlFields: " + mysqlFields +", impalaFields: " + impalaFields + ", " + e.getMessage();
            throw new GdmTableGeneratedFailedException(message, e);
        }
        gdmTableModel.setTableName(inputEntity.getDbTableName());
        gdmTableModel.setIsDbView(inputEntity.getDbView());
        gdmTableModel.setStorages(new ArrayList<>(storageModels));
        gdmTableModel.setBasePath(BASE_PATH);
        gdmTableModel.setSelf(String.format("%s/%s", BASE_PATH, gdmTableModel.getTableName()));
        gdmTableModel.setLastUpdated(Instant.now());
        gdmTableModel.setColumns(columnModelList);
        //设置Entity默认属性：系统entity，不可被删除，不可被修改
        gdmTableModel.setIsSystem(true);
        gdmTableModel.setDeletable(false);
        gdmTableModel.setModifiable(false);
        return gdmTableModel;
    }

    @Nonnull
    private static List<GdmColumnModel> composeColumnModelList(@Nonnull List<Field> mysqlFields, @Nonnull List<Field> impalaFields,
                                                               @Nonnull List<String> dbTypes, String entityName) {

        List<GdmColumnModel> modelList = new ArrayList<>();
        boolean hasNoOltpFields = CollectionUtils.isEmpty(mysqlFields);
        boolean hasNoOlapFields = CollectionUtils.isEmpty(impalaFields);
        if (hasNoOltpFields && hasNoOlapFields) {
            return Collections.emptyList();
        }
        Map<String, Field> impalaFieldMap = impalaFields.stream().collect(Collectors.toMap(Field::getFieldName, Function.identity()));

        Set<String> processField = new HashSet<>();
        for (Field mysqlField: mysqlFields) {
            Field impalaField = impalaFieldMap.get(mysqlField.getFieldName());
            if (impalaField == null && (dbTypes.contains("KUDU") || dbTypes.contains("PARQUET"))) {
                log.info("[DIRTY_DATA] entity.field({}.{}) does not have ap storage", entityName,  mysqlField.getFieldName());
            }
            GdmColumnModel gdmColumnModel = Field.newGdmColumnModel(mysqlField, impalaField, dbTypes);
            modelList.add(gdmColumnModel);
            processField.add(mysqlField.getFieldName());
        }

        for (Field impalaField: impalaFields) {
            if (processField.contains(impalaField.getFieldName())) {
                continue;
            }
            if (dbTypes.contains("MYSQL")) {
                log.info("[DIRTY_DATA] entity.field({}.{}) does not have mysql storage", entityName,  impalaField.getFieldName());
            }
            GdmColumnModel gdmColumnModel = Field.newGdmColumnModel(null, impalaField, dbTypes);
            modelList.add(gdmColumnModel);
        }
        if ("wechat_fans".equals(entityName)) {
            ImmutableSet<String> blockFields = ImmutableSet.of("location", "field_location");
            modelList = modelList.stream()
                    .filter(field -> !blockFields.contains(field.getColumnName())).collect(Collectors.toList());
        }

        return modelList;
    }
}
