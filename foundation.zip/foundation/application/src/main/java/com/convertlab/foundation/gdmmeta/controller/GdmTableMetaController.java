package com.convertlab.foundation.gdmmeta.controller;

import com.convertlab.foundation.gdmmeta.persistance.table.GdmTableModel;
import com.convertlab.foundation.gdmmeta.service.GdmTableMetaService;
import com.convertlab.foundation.gdmmeta.service.validator.GdmTableMetaValidator;
import com.convertlab.foundation.library.gdmmeta.api.GdmTableApiRoot;
import com.convertlab.foundation.library.gdmmeta.model.table.GdmTable;
import com.convertlab.foundation.library.gdmmeta.model.table.GdmTableRequest;
import com.convertlab.foundation.library.gdmmeta.validation.Issue;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.principal.context.PrincipalContextHolder;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;
import java.util.stream.Collectors;

@RestController("gdmTableMetaController")
@RequestMapping("/v1/meta/gdm")
@Tag(name = "Meta Store接口")
@Slf4j
public class GdmTableMetaController implements GdmTableApiRoot {

    GdmTableMetaService gdmTableMetaService;
    private final GdmTableMetaValidator gdmTableMetaValidator;

    public GdmTableMetaController(GdmTableMetaService gdmTableMetaService, GdmTableMetaValidator gdmTableMetaValidator) {
        this.gdmTableMetaService = gdmTableMetaService;
        this.gdmTableMetaValidator = gdmTableMetaValidator;
    }

    @Operation(summary = "所有Tables", description = "所有Tables")
    @Override
    @Nonnull
    public List<GdmTable> getTableList() {
        List<GdmTableModel> tableListModels = gdmTableMetaService.getTableList();
        return tableListModels.stream().map(GdmTableModel::getGdmTable).collect(Collectors.toList());
    }

    @Operation(summary = "按名字查询Table", description = "按名字查询Table")
    @Override
    @Nullable
    public GdmTable getTable(String tableName) {
        GdmTableModel dto = gdmTableMetaService.getGdmTableByName(tableName);
        if (dto == null) {
            return null;
        }
        return dto.getGdmTable();
    }

    @Operation(summary = "创建Table(不要用)", description = "创建Table")
    @Override
    @Nonnull
    public GdmTable createTable(GdmTableRequest gdmTableRequest) {
        gdmTableMetaService.checkRequestData(gdmTableRequest);
        GdmTableModel result = gdmTableMetaService.createGdmTable(GdmTableModel.newInstance(gdmTableRequest));
        return result.getGdmTable();
    }

    @Operation(summary = "更新Table(不要用)", description = "更新Table")
    @Override
    @Nonnull
    public GdmTable updateTable(String tableName, GdmTableRequest gdmTableRequest) {
        gdmTableMetaService.checkRequestData(gdmTableRequest);
        GdmTableModel requestDto = GdmTableModel.newInstance(gdmTableRequest);
        GdmTableModel gdmTable = gdmTableMetaService.updateGdmTable(tableName, requestDto);
        return gdmTable.getGdmTable();
    }

    @Operation(summary = "删除Table(不要用)", description = "删除Table")
    @Override
    @Nullable
    public GdmTable deleteTable(String tableName) {
        GdmTableModel gdmTableModel = gdmTableMetaService.deleteGdmTable(tableName);
        if (gdmTableModel == null) {
            return null;
//            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, TABLE_NOT_FOUND_MESSAGE_CODE, new String[]{tableName});
        }
        return gdmTableModel.getGdmTable();
    }

    @PostMapping("/tables/_health-check")
    @Tag(name = "health-check-endpoint")
    @Operation(summary = "校验 Table meta信息完整性", description = "校验 Table meta信息完整性")
    public List<Issue> checkGdmTable() {
        log.info("checkGdmTable - tenantId: {}, userId: {}", TenantContextHolder.getTenantId(), PrincipalContextHolder.getUserId());
        return gdmTableMetaValidator.validate();
    }
}
