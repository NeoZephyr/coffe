package com.convertlab.foundation.user.utils;

public interface FileUsage {

    int IMPORT = 0;
    int EXPORT = 1;
}