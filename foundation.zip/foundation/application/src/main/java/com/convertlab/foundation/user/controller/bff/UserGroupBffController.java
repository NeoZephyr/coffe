package com.convertlab.foundation.user.controller.bff;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.convertlab.foundation.user.entity.UserGroup;
import com.convertlab.foundation.user.model.*;
import com.convertlab.foundation.user.service.UserGroupService;
import lombok.val;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Nonnull;
import javax.validation.constraints.NotBlank;
import java.util.AbstractMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Qualifier("UserGroupBffController")
@RestController
@RequestMapping("/userGroups")
public class UserGroupBffController {
    private final UserGroupService userGroupService;

    public UserGroupBffController(UserGroupService userGroupService) {
        this.userGroupService = userGroupService;
    }

    @Nonnull
    @GetMapping("")
    public ListUserGroupResponse index(@RequestParam(defaultValue = "1") Integer page,
                                       @RequestParam(defaultValue = "20") Integer rows,
                                       @RequestParam(defaultValue = "") String q) {
        return ListUserGroupResponse.fromPage(userGroupService.index(q, Page.of(page, rows)));
    }

    @Nonnull
    @PostMapping("")
    public UserGroupDto save(@RequestBody @NotNull SaveUserGroupRequest request) {
        return userGroupService.save(request);
    }

    @Nonnull
    @GetMapping("/{code}")
    public UserGroup show(@PathVariable @NotBlank String code) {
        return userGroupService.show(code);
    }

    @Nonnull
    @PutMapping("/{code}")
    public UserGroupDto update(@PathVariable @NotBlank String code, @Nonnull @RequestBody SaveUserGroupRequest request) {
        return userGroupService.update(code, request);
    }

    @Nonnull
    @DeleteMapping("/{code}")
    public JoinLeaveUserGroupResponse delete(@PathVariable @NotBlank String code) {
        return userGroupService.delete(code);
    }

    @Nonnull
    @PostMapping("/userCount")
    public Map<String, Long> userCount(@RequestBody @NotNull UserCountRequest request) {
        val codes = request.getCodes();
        val counts = userGroupService.userCount(request.getCodes());
        val result = codes.stream()
                .map(c -> new AbstractMap.SimpleEntry<>(c, 0L))
                .collect(Collectors.toMap(AbstractMap.SimpleEntry::getKey, AbstractMap.SimpleEntry::getValue));
        for (UserGroupCount count :
                counts) {
            result.put(count.getGroupCode(), count.getCount());
        }
        return result;
    }

    @Nonnull
    @GetMapping("/{code}/userList")
    public List<UserDeptRoleComposite> userList(@PathVariable @NotBlank String code,
                                                @RequestParam(defaultValue = "") String q) {
        return userGroupService.userList(code, q);
    }

    @Nonnull
    @PostMapping("/{code}/join")
    public JoinLeaveUserGroupResponse join(@PathVariable @NotBlank String code,
                                           @RequestBody @NotNull JoinLeaveUserGroupRequest request) {
        return userGroupService.join(code, request.userList);
    }

    @Nonnull
    @PostMapping("/{code}/leave")
    public JoinLeaveUserGroupResponse leave(@PathVariable @NotBlank String code,
                                            @RequestBody @NotNull JoinLeaveUserGroupRequest request) {
        return userGroupService.leave(code, request.userList);
    }


}
