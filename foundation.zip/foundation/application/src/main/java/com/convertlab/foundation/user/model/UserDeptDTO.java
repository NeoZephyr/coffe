package com.convertlab.foundation.user.model;

import lombok.Data;

@Data
public class UserDeptDTO {
    private Long userId;
    private String deptCode;
    private Boolean isDefault;
}
