package com.convertlab.foundation.misc.controller;

import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BackendException;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.gdmmeta.client.exception.EntityNotFoundException;
import com.convertlab.foundation.library.gdmmeta.client.exception.MetaErrors;
import com.convertlab.foundation.misc.controller.api.SampleApi;
import com.convertlab.foundation.misc.dto.SampleDto;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

@RestController
public class SampleApiController implements SampleApi {
    @Nullable
    @Override
    public SampleDto inspectExceptions(Mode mode) {
        if (mode == Mode.NULL) {
            return null;
        } else if (mode == Mode.ILLEGAL_EXCEPTION) {
            throw new IllegalArgumentException("Illegal argument");
        } else if (mode == Mode.BUSINESS_EXCEPTION) {
            throw new BusinessException(CommonErrors.GENERAL_ERROR, "MSG_001_000001", "Business exception",
                    new String[]{"Args"});
        } else if (mode == Mode.CUSTOM_BUSINESS_EXCEPTION) {
            throw new CustomBusinessException();
        } else if (mode == Mode.EXTENDED_BUSINESS_EXCEPTION) {
            throw new EntityNotFoundException("Entity not found", "c_car");
        } else if (mode == Mode.BACKEND_EXCEPTION) {
            throw new BackendException(MetaErrors.OPTIMISTIC_LOCK, "乐观锁加持",
                    new String[]{"1","2"});
        } else if (mode == Mode.WRAPPED_BACKEND_EXCEPTION) {
            throw new BackendException(new IllegalArgumentException("Illegal argument"), new String[]{"8o81"});
        } else {
            return new SampleDto("Hello world", 1L);
        }
    }

    public static class CustomBusinessException extends BusinessException {
        public CustomBusinessException() {
            super(CommonErrors.GENERAL_ERROR, "MSG_001_000001", "Business exception",
                    new String[]{"Args"});
        }
    }
}
