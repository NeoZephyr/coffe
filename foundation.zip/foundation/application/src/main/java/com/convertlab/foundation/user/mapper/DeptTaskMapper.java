package com.convertlab.foundation.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.foundation.user.entity.DpTask;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface DeptTaskMapper extends BaseMapper<DpTask> {
}
