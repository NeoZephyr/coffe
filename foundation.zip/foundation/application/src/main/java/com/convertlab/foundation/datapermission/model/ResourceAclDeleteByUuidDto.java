package com.convertlab.foundation.datapermission.model;


import lombok.Data;

@Data
public class ResourceAclDeleteByUuidDto {

    String resourceType;
    String uuid;
}
