package com.convertlab.foundation.gdmmeta.service;

import com.convertlab.foundation.gdmmeta.model.Entity;
import com.convertlab.foundation.gdmmeta.model.Field;
import com.convertlab.foundation.gdmmeta.model.Relationship;
import com.convertlab.foundation.gdmmeta.mybatis.domain.CustomerMeta;
import com.convertlab.foundation.gdmmeta.service.impl.loader.UdoRawEvent;
import com.convertlab.foundation.library.gdmmeta.model.table.GdmTable;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface ConfigMetaProvider {

    List<Entity> getInitialSystemRegisteredEntitiesWithoutFields();

    Entity getRegisteredEntity(String entityName);

    List<Field> loadSystemCustomerFields();

    List<Field> filterAndCorrectEntityMetaFields(String entityName, final List<Field> metaFields);

    List<Entity> getRegisteredSystemCustomerEventEntities(boolean withFields);

    List<Field> loadSystemCustomerStatisticsFields();

    List<Field> loadSystemFullOrderFields();

    List<Field> filterGlobalIgnoreDbFields(String entityName, List<Field> fields);

    List<Field> filterAndCorrectImpalaEntityFields(String entityName, List<Field> fieldList);

    Set<Entity> getEntitiesWithoutFieldsHavingOlapStorage();

    List<Field> loadSystemMembershipPropsFields();

    Set<Entity> getEntitiesWithoutFieldsHavingOltpStorage();

    List<Entity> getTenantCustomerEventEntities(CustomerMeta.CustomerMetaType metaType,  String meta, boolean withFields);

    List<Field> getTenantCustomerFields(String meta);

    List<Field> getFullOrderFields(String meta, boolean predefined);

    List<Field> getTenantMembershipFields(String meta);

    List<UdoRawEvent> getSystemUdoEventEntities(boolean withFields);

    List<Field> loadTenantCustomerEventCommonFields();

//    List<Field> loadSystemUdoGeneralEventFields();

//    Map<String, List<Entity>> getTenantUdoEventEntities(String eventMetaString, Set<String> validObjIds, boolean withFields);

    Map<String, String> getRegisteredEntityTableMapWithOltpStorage();

    Map<String, String> getRegisteredEntityTableMapWithOlapStorage();

    List<Field> loadSystemParentCustomerEventFields();

    List<Field> getTenantSourceFields(String meta);

    Relationship getCustomerRelationship();

    List<Relationship> getSystemRegisteredRelationships();

    List<Entity> getSystemCustomerEventEntities();

    List<GdmTable> loadSystemGdmTableMeta();
}
