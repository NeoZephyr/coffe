package com.convertlab.foundation.datapermission.model;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
public class HomeDataSwitchSettingRequestDto extends SwitchSettingRequestDto implements Serializable {
    public HomeDataSwitchSettingRequestDto() {
        super();
    }

    public HomeDataSwitchSettingRequestDto(Boolean switchValue) {
        super(switchValue);
    }
}
