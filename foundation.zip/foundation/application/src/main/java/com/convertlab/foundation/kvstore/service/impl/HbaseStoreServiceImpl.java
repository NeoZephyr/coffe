package com.convertlab.foundation.kvstore.service.impl;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.convertlab.foundation.kvstore.dto.KeyValuesPair;
import com.convertlab.foundation.kvstore.misc.AdHocMetasUtil;
import com.convertlab.foundation.kvstore.misc.AdHocTableMeta;
import com.convertlab.foundation.kvstore.service.HbaseStoreService;
import com.convertlab.foundation.library.constant.DataProcessingMode;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.gdmmeta.client.GdmStorageMetaRtClient;
import com.convertlab.foundation.library.gdmmeta.model.storage.Hbase;
import com.convertlab.foundation.library.gdmmeta.model.storage.Storage;
import com.convertlab.foundation.library.hbase.core.HbaseColumnSchema;
import com.convertlab.foundation.library.hbase.core.TenantIsolationHbaseTemplate;
import com.convertlab.foundation.library.hbase.mapper.RowkeyMapperRule;
import com.convertlab.foundation.library.hbase.mapper.TenantInsideRowkeyMapperRule;
import com.google.common.collect.Maps;
import org.springframework.stereotype.Service;
import static com.convertlab.foundation.library.constant.CommonErrors.*;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class HbaseStoreServiceImpl implements HbaseStoreService {
    public static final String STORAGE_TYPE_KV = "KV";
    public static final String DB_TYPE_HBASE = "HBASE";

    private TenantIsolationHbaseTemplate tenantIsolationHbaseTemplate;
    private final GdmStorageMetaRtClient gdmStorageMetaClient;

    public HbaseStoreServiceImpl(GdmStorageMetaRtClient gdmStorageMetaClient,
                                 TenantIsolationHbaseTemplate tenantIsolationHbaseTemplate){
        this.gdmStorageMetaClient = gdmStorageMetaClient;
        this.tenantIsolationHbaseTemplate = tenantIsolationHbaseTemplate;
        // 注入需要特殊处理rowkey的表
        Map<String, RowkeyMapperRule> tidInsideTableRuleMapper = new HashMap<>();
        AdHocMetasUtil.TENANT_INSIDE_ROW_KEY_TABLES.forEach(tableName ->{
            tidInsideTableRuleMapper.put(tableName, new TenantInsideRowkeyMapperRule());
        });
        this.tenantIsolationHbaseTemplate.setTableRowkeyMapperRule(tidInsideTableRuleMapper);
    }

    @Nonnull
    @Override
    public List<KeyValuesPair> batchSelect(@Nonnull String tableName, @Nonnull String columnFamily, @Nonnull List<String> rowKeys, @Nonnull List<String> columns, @Nonnull List<HbaseColumnSchema> columnSchemas) throws Exception {
        Map<String, Object> result =  this.tenantIsolationHbaseTemplate.batchSelect(tableName, columnFamily, rowKeys, fullColumnsToShortColumns(columns, columnSchemas), columnSchemas);
        return convertToKvPairs(result, columnSchemas);
    }

    @Override
    public void batchInsertOrUpdate(@Nonnull String tableName, @Nonnull String columnFamily, @Nonnull List<KeyValuesPair> kvPairs, @Nonnull List<HbaseColumnSchema> columnSchemas) throws Exception {
        List<Map<String, Object>> upsertRows = convertToUpsertRows(kvPairs, columnSchemas);
        this.tenantIsolationHbaseTemplate.batchInsertOrUpdate(tableName, columnFamily, upsertRows, columnSchemas);
    }

    @Override
    public void batchDelete(@Nonnull String tableName, @Nonnull String columnFamily, @Nonnull List<KeyValuesPair> kvPairs, @Nonnull List<HbaseColumnSchema> columnSchemas) throws Exception {
        List<Map<String, Object>> deleteRows = convertToUpsertRows(kvPairs, columnSchemas);
        this.tenantIsolationHbaseTemplate.batchDelete(tableName, columnFamily, deleteRows);
    }

    @Nonnull
    @Override
    public Map<String, Map<String, Long>> batchIncrement(@Nonnull String tableName, @Nonnull String columnFamily, @Nonnull List<KeyValuesPair> kvPairs, @Nonnull List<HbaseColumnSchema> columnSchemas) throws Exception {
        List<Map<String, Object>> incrementRows = convertToUpsertRows(kvPairs, columnSchemas);
        return this.tenantIsolationHbaseTemplate.batchIncrementWithTtl(tableName, columnFamily, incrementRows);
    }

    /**
     * 从GDM Meta读取 hbase的 表名
     * @param entityName
     * @param entityName
     * @return
     */
    @Nullable
    @Override
    public String getHbaseTableName(@Nonnull String entityName) throws Exception {
        AdHocTableMeta adHocTableMeta = AdHocMetasUtil.getAdHocTableMetaByName(entityName);
        if(adHocTableMeta != null && adHocTableMeta.getDbStorageTypes().containsKey(STORAGE_TYPE_KV) &&
                Storage.isHbase(adHocTableMeta.getDbStorageTypes().get(STORAGE_TYPE_KV).getDbType())){
            return adHocTableMeta.getDbStorageTypes().get(STORAGE_TYPE_KV).getDbTable();
        }

        Storage storage = gdmStorageMetaClient.getTableStorageOfMode(entityName, DataProcessingMode.KV);
        if(storage != null) {
            if (Storage.isHbase(storage.getDbType())) {
                Hbase hbaseStorage = (Hbase) storage;
                return hbaseStorage.getDbTable();
            }
        }

        return null;
    }

    /**
     * 返回Hbase表的列信息，如果找不到Meta，返回空List；
     * @param entityName
     * @return
     * @throws Exception
     */
    @Override
    @SuppressWarnings("java:S1192")
    public List<HbaseColumnSchema> getHbaseColumnSchemas(@Nonnull String entityName) throws Exception {
        AdHocTableMeta adHocTableMeta = AdHocMetasUtil.getAdHocTableMetaByName(entityName);
        if(adHocTableMeta != null && adHocTableMeta.getDbStorageTypes().containsKey(STORAGE_TYPE_KV) &&
                Storage.isHbase(adHocTableMeta.getDbStorageTypes().get(STORAGE_TYPE_KV).getDbType())){
            List<AdHocTableMeta.ColumnFamily>  columnFamilies = adHocTableMeta.getDbStorageTypes().get(STORAGE_TYPE_KV).getColumnFamilies();
            if(columnFamilies.size() != 1){
                throw new BusinessException(VALIDATION_ERROR, "MSG_006_000003", "Hbase KV Store only support one column family.",new String[]{});
            }
            List<HbaseColumnSchema> result = columnFamilies.get(0).getColumns();
            return result;
        }

        Storage storage = gdmStorageMetaClient.getTableStorageOfMode(entityName, DataProcessingMode.KV);
        if(storage != null){
            if(Storage.isHbase(storage.getDbType())){
                Hbase hbaseStorage  = (Hbase) storage;
                if(hbaseStorage.getColumnFamilies().size() != 1){
                    throw new BusinessException(VALIDATION_ERROR, "MSG_006_000003", "Hbase KV Store only support one column family.",new String[]{});
                }
                List<HbaseColumnSchema> result = hbaseStorage.getColumnFamilies().get(0).getColumns().stream().map(hbaseColumn -> {
                    return new HbaseColumnSchema(hbaseColumn.getName(), hbaseColumn.getType());
                }).collect(Collectors.toList());
                return result;
            }
        }

        return Collections.emptyList();
    }

    @Nullable
    @Override
    public String getHbaseColumnFamily(@Nonnull String entityName) throws Exception {
        AdHocTableMeta adHocTableMeta = AdHocMetasUtil.getAdHocTableMetaByName(entityName);
        if(adHocTableMeta != null && adHocTableMeta.getDbStorageTypes().containsKey(STORAGE_TYPE_KV) &&
                Storage.isHbase(adHocTableMeta.getDbStorageTypes().get(STORAGE_TYPE_KV).getDbType())){
            List<AdHocTableMeta.ColumnFamily>  columnFamilies = adHocTableMeta.getDbStorageTypes().get(STORAGE_TYPE_KV).getColumnFamilies();
            if(columnFamilies.size() != 1){
                throw new BusinessException(VALIDATION_ERROR, "MSG_006_000003", "Hbase KV Store only support one column family.",new String[]{});
            }
            return columnFamilies.get(0).getName();
        }

        Storage storage = gdmStorageMetaClient.getTableStorageOfMode(entityName, DataProcessingMode.KV);
        if(storage != null) {
            if (Storage.isHbase(storage.getDbType())) {
                Hbase hbaseStorage = (Hbase) storage;
                if(hbaseStorage.getColumnFamilies().size() != 1){
                    throw new BusinessException(VALIDATION_ERROR, "MSG_006_000003", "Hbase KV Store only support one column family.",new String[]{});
                }
                Hbase.HbaseColumnFamily columnFamily = hbaseStorage.getColumnFamilies().get(0);
                if(columnFamily != null){
                    if(columnFamily.getColumns() !=null && columnFamily.getColumns().size()>0){
                        String cf= columnFamily.getColumns().get(0).getName();
                        if(!"*".equals(cf)){
                            return cf;
                        }
                    }
                    return columnFamily.getName();
                }
            }
        }

        return null;
    }

    @Nonnull
    private List<Map<String, Object>> convertToUpsertRows(@Nonnull List<KeyValuesPair> kvPairs, @Nonnull List<HbaseColumnSchema> columnSchemas) {
        HashMap<String, String> fullToShortColumnMap = new HashMap<>();
        if(columnSchemas.size() !=0  && !(columnSchemas.size() == 1 && columnSchemas.get(0).getName().equals("*"))){
            columnSchemas.forEach(it -> {
                if(!it.getName().equals(it.getFullName())){
                    fullToShortColumnMap.put(it.getFullName(), it.getName());
                }
            });
        }

        return kvPairs.stream().map(it -> {
            HashMap<String, Object> data = new HashMap();
            data.put("rowKey", it.getId());
            if(fullToShortColumnMap.size()>0){
                Map value = it.getKvMapping().entrySet().stream()
                        .collect(Collectors.toMap(entry -> {
                            if(fullToShortColumnMap.containsKey(entry.getKey())){
                                return fullToShortColumnMap.get(entry.getKey());
                            }else{
                                return entry.getKey();
                            }
                        }, Map.Entry::getValue));
                data.put("columns", value);
            }else{
                data.put("columns", it.getKvMapping());
            }
            return data;
        }).collect(Collectors.toList());
    }

    @Nonnull
    private List<KeyValuesPair> convertToKvPairs(@Nullable Map<String, Object> result, @Nonnull List<HbaseColumnSchema> columnSchemas){
        List<KeyValuesPair> kvResults = new ArrayList<>();
        if(result == null){
            return kvResults;
        }

        HashMap<String, String> shortToFullColumnMap = new HashMap<>();
        if(columnSchemas.size() !=0  && !(columnSchemas.size() == 1 && columnSchemas.get(0).getName().equals("*"))){
            columnSchemas.forEach(it -> {
                if(!it.getName().equals(it.getFullName())){
                    shortToFullColumnMap.put(it.getName(), it.getFullName());
                }
            });
        }

        result.entrySet().forEach(it -> {
            String key = it.getKey();
            HashMap<String, Object> value = (HashMap)it.getValue();
            if(shortToFullColumnMap.size() ==0){
                KeyValuesPair kvResult = new KeyValuesPair(key, value);
                kvResults.add(kvResult);
            }else{
                Map<String, Object> newValue = new HashMap();
                value.entrySet().forEach(entry->{
                    String columnKey = entry.getKey();
                    Object columnValue = entry.getValue();
                    if(shortToFullColumnMap.containsKey(columnKey)){
                        newValue.put(shortToFullColumnMap.get(columnKey), columnValue);
                    }else{
                        newValue.put(columnKey, columnValue);
                    }
                });
                KeyValuesPair kvResult = new KeyValuesPair(key, newValue);
                kvResults.add(kvResult);
            }
        });
        return kvResults;
    }
    /**
     * 根据bizMeta中的fullName，将columns中的短列名转换为全列名
     * @param columns
     * @param columnSchemas
     * @return
     */
    @Nonnull
    private List<String> shortColumnsToFullColumns(@Nonnull List<String> columns, @Nonnull List<HbaseColumnSchema> columnSchemas){
        if(columnSchemas.size() ==0 ){
            return columns;
        }
        if(columnSchemas.size() == 1 && columnSchemas.get(0).getName().equals("*")){
            return columns;
        }
        HashMap<String, String> shortToFullColumnMap = new HashMap<>();
        columnSchemas.forEach(it -> {
            if(!it.getName().equals(it.getFullName())){
                shortToFullColumnMap.put(it.getName(), it.getFullName());
            }
        });
        if(columnSchemas.size() >0){
            List<String> fullColumns = new ArrayList<>();
            columns.forEach(it -> {
                if(shortToFullColumnMap.containsKey(it)){
                    fullColumns.add(shortToFullColumnMap.get(it));
                }else{
                    fullColumns.add(it);
                }
            });
            return fullColumns;
        }else{
            return columns;
        }
    }

    /**
     * 根据bizMeta中的fullName，将columns中的短列名转换为全列名
     * @param columns
     * @param columnSchemas
     * @return
     */
    @Nonnull
    private List<String> fullColumnsToShortColumns(@Nonnull List<String> columns, @Nonnull List<HbaseColumnSchema> columnSchemas) {
        if(columnSchemas.size() ==0 ){
            return columns;
        }
        if(columnSchemas.size() == 1 && columnSchemas.get(0).getName().equals("*")){
            return columns;
        }
        HashMap<String, String> fullToShortColumnMap = new HashMap<>();
        columnSchemas.forEach(it -> {
            if(!it.getName().equals(it.getFullName())){
                fullToShortColumnMap.put(it.getFullName(), it.getName());
            }
        });
        if(columnSchemas.size() >0){
            List<String> shortColumns = new ArrayList<>();
            columns.forEach(it -> {
                if(fullToShortColumnMap.containsKey(it)){
                    shortColumns.add(fullToShortColumnMap.get(it));
                }else{
                    shortColumns.add(it);
                }
            });
            return shortColumns;
        }else{
            return columns;
        }
    }
}
