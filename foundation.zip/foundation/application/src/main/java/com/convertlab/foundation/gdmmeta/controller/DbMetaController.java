package com.convertlab.foundation.gdmmeta.controller;

import com.convertlab.foundation.library.gdmmeta.model.physics.Datasource;
import com.convertlab.foundation.library.gdmmeta.model.physics.PhysicalSimpleTable;
import com.convertlab.foundation.library.gdmmeta.model.physics.PhysicalTable;
import com.convertlab.foundation.gdmmeta.service.impl.DbMetaProviderImpl;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController("dbMetaController")
@RequestMapping("/v1/meta/gdm/db")
@Tag(name = "Db table meta 接口")
@Slf4j
public class DbMetaController {

    private DbMetaProviderImpl dbMetaProvider;

    public DbMetaController(DbMetaProviderImpl dbMetaProvider) {
        this.dbMetaProvider = dbMetaProvider;
    }

    @GetMapping("/datasources")
    public List<Datasource> getDataSources() {
        return dbMetaProvider.getDatasources();
    }

    @GetMapping("/{datasource}/tables")
    public List<PhysicalSimpleTable> getSimpleTableInfo(@PathVariable("datasource") String datasource,
                                                        @RequestParam("catalog") String catalog,
                                                        @RequestParam(name = "schema", required = false) String schema) {
        return dbMetaProvider.getPhysicalSimpleTableInfo(datasource, catalog, schema);
    }

    @GetMapping("/{datasource}/tables/{tableName}")
    public PhysicalTable getTableInfo(@PathVariable("datasource") String datasource,
                                      @RequestParam("catalog") String catalog,
                                      @RequestParam(name = "schema", required = false) String schema,
                                      @PathVariable(name = "tableName") String tableName) {
        return dbMetaProvider.getPhysicalTableInfo(datasource, catalog, schema, tableName);
    }

}
