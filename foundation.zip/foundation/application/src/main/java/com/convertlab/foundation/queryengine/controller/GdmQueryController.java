package com.convertlab.foundation.queryengine.controller;

import com.convertlab.foundation.api.queryengine.GdmCount;
import com.convertlab.foundation.api.queryengine.GdmQuery;
import com.convertlab.foundation.api.queryengine.GdmQueryApi;
import com.convertlab.foundation.api.queryengine.SqlBuilder;
import com.convertlab.foundation.library.sqlprocessor.SQLDialect;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.library.webmvc.swagger.TenantAuthentication;
import com.convertlab.foundation.queryengine.service.GdmQueryService;
import com.convertlab.foundation.queryengine.service.GdqlParseService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Nonnull;
import javax.validation.constraints.NotNull;

@Slf4j
@RestController
@RequestMapping("/v1/query-engine")
@RequiredArgsConstructor
@Tag(name = "Foundation Query Engine接口")
public class GdmQueryController implements GdmQueryApi, TenantAuthentication {
    @Nonnull
    private final GdmQueryService queryService;
    @Nonnull
    private final GdqlParseService gdqlParseService;

    @Nonnull
    @Override
    @PostMapping("/q")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "根据gdql或者filterv4查询数据库",
            content = @io.swagger.v3.oas.annotations.media.Content(
                    mediaType = "application/json",
                    examples = {@io.swagger.v3.oas.annotations.media.ExampleObject(
                            name = "GDQL",
                            value = "{\n" +
                                    "  \"gdql\": \"select * from customer where name = ? limit 2\",\n" +
                                    "  \"args\": [{\"value\": \"自动化测试\", \"type\": \"String\"}],\n" +
                                    "  \"processingMode\": \"OLAP\"\n" +
                                    "}"
                    ), @io.swagger.v3.oas.annotations.media.ExampleObject(
                            name = "Filter V4",
                            value = "{\n" +
                                    "  \"filter\": {\n" +
                                    "  \"version\": 4,\n" +
                                    "  \"table\": \"customer\",\n" +
                                    "  \"select\": [\n" +
                                    "    {\n" +
                                    "      \"type\": \"COLUMN\",\n" +
                                    "      \"value\": \"name\"\n" +
                                    "    }\n" +
                                    "  ],\n" +
                                    "  \"limit\": {\n" +
                                    "    \"offset\": 0,\n" +
                                    "    \"row\": 10\n" +
                                    "  },\n" +
                                    "  \"where\": {\n" +
                                    "    \"logicalOp\": {\n" +
                                    "      \"or\": {\n" +
                                    "        \"conditions\": [\n" +
                                    "          {\n" +
                                    "            \"eq\": {\n" +
                                    "              \"left\": {\n" +
                                    "                \"type\": \"COLUMN\",\n" +
                                    "                \"value\": \"name\"\n" +
                                    "              },\n" +
                                    "              \"right\": {\n" +
                                    "                \"type\": \"VALUE\",\n" +
                                    "                \"value\": \"自动化测试\"\n" +
                                    "              }\n" +
                                    "            }\n" +
                                    "          },\n" +
                                    "          {\n" +
                                    "            \"eq\": {\n" +
                                    "              \"left\": {\n" +
                                    "                \"type\": \"COLUMN\",\n" +
                                    "                \"value\": \"name\"\n" +
                                    "              },\n" +
                                    "              \"right\": {\n" +
                                    "                \"type\": \"VALUE\",\n" +
                                    "                \"value\": \"Bob\"\n" +
                                    "              }\n" +
                                    "            }\n" +
                                    "          }\n" +
                                    "        ]\n" +
                                    "      }\n" +
                                    "    }\n" +
                                    "  }\n" +
                                    "},\n" +
                                    "  \"needTotal\": true,\n" +
                                    "  \"processingMode\": \"OLAP\"\n" +
                                    "}"
                    )
                    }
            )
    )
    public GdmQuery.Response query(@Nonnull @NotNull @Validated @RequestBody GdmQuery.Request request) {
        return queryService.query(request);
    }

    @Nonnull
    @Override
    @PostMapping("/c")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "计算符合条件的记录数",
            content = @io.swagger.v3.oas.annotations.media.Content(
                    mediaType = "application/json",
                    examples = {@io.swagger.v3.oas.annotations.media.ExampleObject(
                            name = "Filter V4",
                            value = "{\n" +
                                    "  \"filter\": {\n" +
                                    "  \"version\": 4,\n" +
                                    "  \"table\": \"customer\",\n" +
                                    "  \"select\": [\n" +
                                    "    {\n" +
                                    "      \"type\": \"COLUMN\",\n" +
                                    "      \"value\": \"name\"\n" +
                                    "    }\n" +
                                    "  ],\n" +
                                    "  \"limit\": {\n" +
                                    "    \"offset\": 0,\n" +
                                    "    \"row\": 10\n" +
                                    "  },\n" +
                                    "  \"where\": {\n" +
                                    "    \"logicalOp\": {\n" +
                                    "      \"or\": {\n" +
                                    "        \"conditions\": [\n" +
                                    "          {\n" +
                                    "            \"eq\": {\n" +
                                    "              \"left\": {\n" +
                                    "                \"type\": \"COLUMN\",\n" +
                                    "                \"value\": \"name\"\n" +
                                    "              },\n" +
                                    "              \"right\": {\n" +
                                    "                \"type\": \"VALUE\",\n" +
                                    "                \"value\": \"自动化测试\"\n" +
                                    "              }\n" +
                                    "            }\n" +
                                    "          },\n" +
                                    "          {\n" +
                                    "            \"eq\": {\n" +
                                    "              \"left\": {\n" +
                                    "                \"type\": \"COLUMN\",\n" +
                                    "                \"value\": \"name\"\n" +
                                    "              },\n" +
                                    "              \"right\": {\n" +
                                    "                \"type\": \"VALUE\",\n" +
                                    "                \"value\": \"Bob\"\n" +
                                    "              }\n" +
                                    "            }\n" +
                                    "          }\n" +
                                    "        ]\n" +
                                    "      }\n" +
                                    "    }\n" +
                                    "  }\n" +
                                    "},\n" +
                                    "  \"processingMode\": \"OLAP\"\n" +
                                    "}"
                    )
                    }
            )
    )
    public GdmCount.Response count(@Nonnull @NotNull @Validated @RequestBody GdmCount.Request request) {
        return queryService.count(request);
    }

    @Nonnull
    @Override
    @PostMapping("/sql")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "从Filter V4构建GDQL或者Native SQL",
            content = @io.swagger.v3.oas.annotations.media.Content(
                    mediaType = "application/json",
                    examples = {@io.swagger.v3.oas.annotations.media.ExampleObject(
                            name = "Filter Json To Native SQL",
                            value = "{\n" +
                                    "  \"filter\": {\n" +
                                    "  \"version\": 4,\n" +
                                    "  \"table\": \"customer\",\n" +
                                    "  \"select\": [\n" +
                                    "    {\n" +
                                    "      \"type\": \"COLUMN\",\n" +
                                    "      \"value\": \"name\"\n" +
                                    "    }\n" +
                                    "  ],\n" +
                                    "  \"limit\": {\n" +
                                    "    \"offset\": 0,\n" +
                                    "    \"row\": 10\n" +
                                    "  },\n" +
                                    "  \"where\": {\n" +
                                    "    \"logicalOp\": {\n" +
                                    "      \"or\": {\n" +
                                    "        \"conditions\": [\n" +
                                    "          {\n" +
                                    "            \"eq\": {\n" +
                                    "              \"left\": {\n" +
                                    "                \"type\": \"COLUMN\",\n" +
                                    "                \"value\": \"name\"\n" +
                                    "              },\n" +
                                    "              \"right\": {\n" +
                                    "                \"type\": \"VALUE\",\n" +
                                    "                \"value\": \"自动化测试\"\n" +
                                    "              }\n" +
                                    "            }\n" +
                                    "          },\n" +
                                    "          {\n" +
                                    "            \"eq\": {\n" +
                                    "              \"left\": {\n" +
                                    "                \"type\": \"COLUMN\",\n" +
                                    "                \"value\": \"name\"\n" +
                                    "              },\n" +
                                    "              \"right\": {\n" +
                                    "                \"type\": \"VALUE\",\n" +
                                    "                \"value\": \"Bob\"\n" +
                                    "              }\n" +
                                    "            }\n" +
                                    "          }\n" +
                                    "        ]\n" +
                                    "      }\n" +
                                    "    }\n" +
                                    "  }\n" +
                                    "},\n" +
                                    "  \"outputFormat\": \"SQL\",\n" +
                                    "  \"sqlDialect\": \"SPARK\"\n" +
                                    "}"
                    ), @io.swagger.v3.oas.annotations.media.ExampleObject(
                            name = "Filter Json To GDQL",
                            value = "{\n" +
                                    "  \"filter\": {\n" +
                                    "  \"version\": 4,\n" +
                                    "  \"table\": \"customer\",\n" +
                                    "  \"select\": [\n" +
                                    "    {\n" +
                                    "      \"type\": \"COLUMN\",\n" +
                                    "      \"value\": \"name\"\n" +
                                    "    }\n" +
                                    "  ],\n" +
                                    "  \"limit\": {\n" +
                                    "    \"offset\": 0,\n" +
                                    "    \"row\": 10\n" +
                                    "  },\n" +
                                    "  \"where\": {\n" +
                                    "    \"logicalOp\": {\n" +
                                    "      \"or\": {\n" +
                                    "        \"conditions\": [\n" +
                                    "          {\n" +
                                    "            \"eq\": {\n" +
                                    "              \"left\": {\n" +
                                    "                \"type\": \"COLUMN\",\n" +
                                    "                \"value\": \"name\"\n" +
                                    "              },\n" +
                                    "              \"right\": {\n" +
                                    "                \"type\": \"VALUE\",\n" +
                                    "                \"value\": \"自动化测试\"\n" +
                                    "              }\n" +
                                    "            }\n" +
                                    "          },\n" +
                                    "          {\n" +
                                    "            \"eq\": {\n" +
                                    "              \"left\": {\n" +
                                    "                \"type\": \"COLUMN\",\n" +
                                    "                \"value\": \"name\"\n" +
                                    "              },\n" +
                                    "              \"right\": {\n" +
                                    "                \"type\": \"VALUE\",\n" +
                                    "                \"value\": \"Bob\"\n" +
                                    "              }\n" +
                                    "            }\n" +
                                    "          }\n" +
                                    "        ]\n" +
                                    "      }\n" +
                                    "    }\n" +
                                    "  }\n" +
                                    "},\n" +
                                    "  \"outputFormat\": \"GDQL\"\n" +
                                    "}"
                    ), @io.swagger.v3.oas.annotations.media.ExampleObject(
                            name = "GDQL To Native SQL",
                            value = "{\n" +
                                    "  \"gdql\": \"select * from customer where name = ? limit 2\",\n" +
                                    "  \"sqlDialect\": \"SPARK\"\n" +
                                    "}"
                    )
                    }
            )
    )
    public SqlBuilder.Response buildSql(@Nonnull @NotNull @Validated @RequestBody SqlBuilder.Request request) {
        return gdqlParseService.buildSql(request, gdqlParseService.sqlProcessor(JsonUtils.instance().convert(request.getSqlDialect(), SQLDialect.class)), false);

    }

    @PostMapping("/aclOnlySQL")
    public SqlBuilder.Response buildAclOnlySQL(@NotNull @Validated @RequestBody SqlBuilder.Request request) {
        if (StringUtils.isNotBlank(request.getGdql())) {
            if (!request.getGdql().contains("tenant_id")) {
                log.error("No tenantId in sql: " + request.getGdql());
            }
        }

        return gdqlParseService.buildSql(request, gdqlParseService.aclOnlyProcessor(JsonUtils.instance().convert(request.getSqlDialect(), SQLDialect.class)), true);
    }
}
