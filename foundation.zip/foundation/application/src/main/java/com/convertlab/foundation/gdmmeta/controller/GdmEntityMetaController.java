package com.convertlab.foundation.gdmmeta.controller;

import com.convertlab.foundation.gdmmeta.persistance.entity.GdmEntityModel;
import com.convertlab.foundation.gdmmeta.service.GdmEntityMetaService;
import com.convertlab.foundation.gdmmeta.service.validator.GdmEntityMetaValidator;
import com.convertlab.foundation.library.exception.business.BackendException;
import com.convertlab.foundation.library.gdmmeta.api.GdmEntityApiRoot;
import com.convertlab.foundation.library.gdmmeta.client.exception.MetaErrors;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.entity.GdmEntityRequest;
import com.convertlab.foundation.library.gdmmeta.validation.Issue;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.principal.context.PrincipalContextHolder;
import com.convertlab.foundation.library.utils.LogUtils;
import com.google.common.collect.Lists;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@RestController("gdmEntityMetaController")
@RequestMapping("/v1/meta/gdm")
@Tag(name = "Meta Store接口")
@Slf4j
public class GdmEntityMetaController implements GdmEntityApiRoot {

    GdmEntityMetaService gdmEntityMetaService;
    private final GdmEntityMetaValidator gdmEntityMetaValidator;

    public GdmEntityMetaController(GdmEntityMetaService gdmEntityMetaService, GdmEntityMetaValidator gdmEntityMetaValidator) {
        this.gdmEntityMetaService = gdmEntityMetaService;
        this.gdmEntityMetaValidator = gdmEntityMetaValidator;
    }

    @Operation(summary = "所有Entity", description = "所有Entity")
    @Override
    @Nonnull
    @Deprecated
    public List<GdmEntity> getEntityList() {

        List<GdmEntityModel> entityList = gdmEntityMetaService.getEntityList();
        StopWatch stopWatch = new StopWatch("get all entities");
        stopWatch.start("newGdmEntityInstance");
        List<GdmEntity> result = entityList.stream().map(GdmEntityModel::newGdmEntityInstance)
                .collect(Collectors.toList());
        stopWatch.stop();
        log.info("[stopWatch] {}, took {}ms", stopWatch.getLastTaskName(), stopWatch.getLastTaskTimeMillis());
        return result;
    }

    @Nonnull
    @Override
    public List<GdmEntity> getEntityListByFilter(Map<String, String> filter) {
        List<GdmEntityModel> entityList = gdmEntityMetaService.queryEntityListByFilter(filter, Collections.emptyList());
        return entityList.stream().map(GdmEntityModel::newGdmEntityInstance)
                .collect(Collectors.toList());
    }

    @NotNull
    @Override
    public List<String> getEntityNameList() {
        List<GdmEntityModel> entityList = gdmEntityMetaService.queryEntityListByFilter(Collections.emptyMap(), Lists.newArrayList("entityName"));
        return entityList.stream().map(GdmEntityModel::getEntityName).collect(Collectors.toList());
    }

    @Operation(summary = "按名字查询Entity", description = "查询Entity")
    @Override
    @Nullable
    public GdmEntity getEntity(String entityName) {
        GdmEntityModel entityModel = gdmEntityMetaService.getGdmEntityByName(entityName);
        if (entityModel == null) {
            log.warn("Entity {} is not found", entityName);
            return null;
        }
        return entityModel.newGdmEntityInstance();
    }

    @Operation(summary = "创建新Entity", description = "创建新Entity")
    @Override
    @Nonnull
    public GdmEntity createEntity(GdmEntityRequest gdmEntityRequest) {
        gdmEntityMetaService.checkRequestData(gdmEntityRequest);
        GdmEntityModel requestModel = GdmEntityModel.newInstance(gdmEntityRequest);
        GdmEntityModel result = gdmEntityMetaService.createGdmEntity(requestModel);
        return result.newGdmEntityInstance();
    }

    @Operation(summary = "更新Entity", description = "更新Entity")
    @Override
    @Nonnull
    public GdmEntity updateEntity(String entityName, GdmEntityRequest gdmEntityRequest) {
        gdmEntityMetaService.checkRequestData(gdmEntityRequest);
        GdmEntityModel requestModel = GdmEntityModel.newInstance(gdmEntityRequest);
        GdmEntityModel result = gdmEntityMetaService.updateGdmEntity(entityName, requestModel);
        return result.newGdmEntityInstance();
    }

    @Nonnull
    @Operation(summary = "删除Entity", description = "删除Entity")
    @Override
    public GdmEntity deleteEntity(String entityName) {
        GdmEntityModel result = gdmEntityMetaService.deleteGdmEntity(entityName);
        if (result == null) {
            throw new BackendException(MetaErrors.ENTITY_NOT_FOUND, LogUtils.args(entityName));
        }
        return result.newGdmEntityInstance();
    }

    @PostMapping("/entities/_health-check")
    @Tag(name = "health-check-endpoint")
    @Operation(summary = "校验 Entity meta信息完整性", description = "校验 Entity meta信息完整性")
    public List<Issue> checkGdmEntity() {
        log.info("checkGdmEntity - tenantId: {}, userId: {}", TenantContextHolder.getTenantId(), PrincipalContextHolder.getUserId());
        return gdmEntityMetaValidator.validate();
    }
}
