package com.convertlab.foundation.datapermission.model;

import javax.annotation.Nonnull;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class GetOwnerResourceCodeRequestDto {

    String resourceType;
    @Nonnull
    List<String> resourceCodes = new ArrayList<>();
}
