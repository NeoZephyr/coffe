package com.convertlab.foundation.user.utils;

public interface BuiltInDept {
    String TOP_DEPT_CODE = "A00001";
    String TOP_DEPT_NAME = "总部";
    String TOP_DEPT_PATH = "A00001";

    String RESERVED_DEPT_CODE = "A00000";
    String RESERVED_DEPT_NAME = "未分配组织";
    String RESERVED_DEPT_PATH = "A00000";
}
