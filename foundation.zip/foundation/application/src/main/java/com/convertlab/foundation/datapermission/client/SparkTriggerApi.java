package com.convertlab.foundation.datapermission.client;

import org.springframework.web.bind.annotation.*;

import java.util.Map;

public interface SparkTriggerApi {
    @PostMapping("/job/sendToJob")
    Map<String, Object> sendToJob(@RequestBody Map<String, Object> data);

}
