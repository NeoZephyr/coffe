package com.convertlab.foundation.queryengine.service;

import com.convertlab.foundation.api.queryengine.FilterV4Dto;
import com.convertlab.foundation.api.queryengine.GdmCount;
import com.convertlab.foundation.api.queryengine.GdmQuery;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BackendException;
import com.convertlab.foundation.library.filter.FilterJsonParser;
import com.convertlab.foundation.library.filter.GdmParseResult;
import com.convertlab.foundation.library.filter.v4.timeline.GdmFilterV4WithTimeline;
import com.convertlab.foundation.library.jdbc.core.BaseJdbcTemplate;
import com.convertlab.foundation.library.sqlprocessor.ProcessingMode;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.library.utils.Try;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.DataAccessException;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Slf4j
public class GdmQueryService {
    private final BaseJdbcTemplate olapJdbcTemplate;
    private final BaseJdbcTemplate oltpJdbcTemplate;
    private final FilterJsonParser<GdmFilterV4WithTimeline> filterJsonParser;
    private final JsonUtils jsonUtils;

    public GdmQueryService(final BaseJdbcTemplate olapJdbcTemplate,
                           final BaseJdbcTemplate oltpJdbcTemplate,
                           final FilterJsonParser<GdmFilterV4WithTimeline> bindingVarsParser,
                           final JsonUtils jsonUtils) {
        this.olapJdbcTemplate = olapJdbcTemplate;
        this.oltpJdbcTemplate = oltpJdbcTemplate;
        this.filterJsonParser = bindingVarsParser;
        this.jsonUtils = jsonUtils;
    }

    @Nonnull
    public GdmQuery.Response query(@Nonnull @NotNull GdmQuery.Request request) {
        long start = System.currentTimeMillis();
        String gdql = request.getGdql();
        FilterV4Dto filter = request.getFilter();
        if (StringUtils.isBlank(gdql) && filter == null) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "gdql或者filter json参数必须提供一个");
        }
        if (StringUtils.isNotBlank(gdql) && filter != null) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "gdql或者filter json参数二选一");
        }

        ProcessingMode processingMode= resolveProcessingMode(request.getProcessingMode());

        String actualGdql = gdql;
        String countQl = null;
        List<GdmParseResult.Arg> args;
        boolean needTotal = request.getNeedTotal();
        String masterTable = null;
        //解析filter json，得到gdql
        if (StringUtils.isBlank(gdql)) {
            GdmFilterV4WithTimeline filterV4 = jsonUtils.convert(filter, GdmFilterV4WithTimeline.class);
            masterTable = filterV4.getTable();
            GdmParseResult query = filterJsonParser.toGdql(filterV4);
            if (query == null) {
                throw new BackendException(CommonErrors.VALIDATION_ERROR, "parse filter json failed");
            }
            actualGdql = query.getGdql();
            args = query.getBindingVars();

            if (needTotal) {
                GdmParseResult count = filterJsonParser.toCountQl(filterV4);
                countQl = count.getGdql();
            }
        } else {
            args = jsonUtils.convertList(request.getArgs(), GdmParseResult.Arg.class);
            needTotal = false;
        }

        log.info("Transformation Filter V4 to gdql: {}, {}, took {} ms", actualGdql, args, System.currentTimeMillis() - start);
        Object[] bindingVars = GdmParseResult.argsToBindingVars(args);
        int[] argTypes = GdmParseResult.argsToDbTypes(args);

        GdmQuery.Response response = new GdmQuery.Response();
        //执行gdql
        List<Map<String, Object>> result = queryForList(masterTable, actualGdql, bindingVars, argTypes, processingMode);
        response.setRows(result);

        //查询count
        if (needTotal && StringUtils.isNotBlank(countQl)) {
            Long count = count(countQl, bindingVars, argTypes, processingMode);
            response.setTotal(count);
        }
        response.setElapseTime(System.currentTimeMillis() - start);
        log.info("Transformation query, including filterV4->GDQL->SQL->Result: {}, {}, took {} ms", actualGdql, args, response.getElapseTime());
        return response;
    }

    private ProcessingMode resolveProcessingMode(String processingModeName) {
        ProcessingMode processingMode = ProcessingMode.OLAP;
        if (StringUtils.isNotBlank(processingModeName)) {
            ProcessingMode availableProcessingMode = Try.ignoreException(() -> ProcessingMode.valueOf(processingModeName));

            if (Objects.isNull(availableProcessingMode)) {
                throw new BackendException(CommonErrors.VALIDATION_ERROR, String.format("non-supported processingMode:%s,Please choose between OLTP and OLAP", processingMode));
            }

            processingMode = availableProcessingMode;
        }

        return processingMode;
    }

    @Nonnull
    public GdmCount.Response count(@Nonnull @NotNull GdmCount.Request request) {
        long start = System.currentTimeMillis();
        FilterV4Dto filter = request.getFilter();
        if (filter == null) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "filter json参数必须提供");
        }
        GdmFilterV4WithTimeline filterV4 = jsonUtils.convert(filter, GdmFilterV4WithTimeline.class);
        GdmParseResult count = filterJsonParser.toCountQl(filterV4);
        String countQl = count.getGdql();
        List<GdmParseResult.Arg> args = count.getBindingVars();
        log.info("Transformation Filter V4 to gdql: {}, {}, took {} ms", countQl, args, System.currentTimeMillis() - start);

        ProcessingMode processingMode = resolveProcessingMode(request.getProcessingMode());
        Object[] bindingVars = GdmParseResult.argsToBindingVars(args);
        int[] argTypes = GdmParseResult.argsToDbTypes(args);
        Long result = count(countQl, bindingVars, argTypes, processingMode);
        return new GdmCount.Response(result, System.currentTimeMillis() - start);
    }

    @Nonnull
    protected List<Map<String, Object>> queryForList(String masterTable, String gdql, @Nullable Object[] args, @Nonnull int[] argTypes, ProcessingMode processingMode) {
        BaseJdbcTemplate baseJdbcTemplate = getEligibleJdbcTemplate(processingMode);

        if (args == null || args.length == 0) {
            return baseJdbcTemplate.queryForList(gdql);
        }
        if (args.length != argTypes.length) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Mismatched args and argTypes");
        }
        try {
            return baseJdbcTemplate.queryForList(gdql, args, argTypes);
        } catch (DataAccessException e) {
            Throwable t = e.getRootCause() == null ? e.getCause() : e.getRootCause();
            log.error("query failed", t);
            String msg = t == null ? e.getMessage() : t.getMessage();
            throw new BackendException(CommonErrors.BACKEND_EXCEPTION, msg);
        }
    }

    private BaseJdbcTemplate getEligibleJdbcTemplate(ProcessingMode processingMode) {
        if (Objects.equals(ProcessingMode.OLTP, processingMode)) {
            return oltpJdbcTemplate;
        }

        return olapJdbcTemplate;
    }

    @Nullable
    private Long count(String gdql, @Nullable Object[] args, @Nonnull int[] argTypes, ProcessingMode processingMode) {
        log.info("count: {}, {}", gdql, args);

        BaseJdbcTemplate baseJdbcTemplate = getEligibleJdbcTemplate(processingMode);

        if (args == null || args.length == 0) {
            return baseJdbcTemplate.queryForObject(gdql, Long.class);
        }
        if (args.length != argTypes.length) {
            throw new BackendException(CommonErrors.VALIDATION_ERROR, "Mismatched args and argTypes");
        }
        try {
            return baseJdbcTemplate.queryForObject(gdql, args, argTypes, Long.class);
        } catch (DataAccessException e) {
            Throwable t = e.getRootCause() == null ? e.getCause() : e.getRootCause();
            throw new IllegalStateException(t.getMessage(), e);
        }
    }
}
