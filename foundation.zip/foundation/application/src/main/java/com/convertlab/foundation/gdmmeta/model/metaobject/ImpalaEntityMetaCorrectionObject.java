package com.convertlab.foundation.gdmmeta.model.metaobject;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.*;
import java.util.ArrayList;
import java.util.stream.Collectors;

import org.jetbrains.annotations.NotNull;
import org.springframework.util.CollectionUtils;

import com.convertlab.foundation.gdmmeta.model.Field;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import static java.util.Collections.emptyList;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class ImpalaEntityMetaCorrectionObject {
    List<EntityOps> entityOpsList;

    @Data
    static class EntityOps {

        String entityName;
        ColumnListOps dbStruct;
        FieldListOps columnFieldsMeta;
    }

    @Data
    public static class ColumnListOps {
        FilterColumnsOps  filterColumns;

    }

    @Data
    public static class FilterColumnsOps {
        List<String> excludedList;
        List<String> includedList;
    }

    @Data
    public static class FieldListOps {

        FilterFieldsOps filterFields;
        List<SystemMetaCorrectionObject.FieldOps> correctFields;
        List<Field> appendFields;
    }

    @Data
    public static class FilterFieldsOps {
        List<String> excludedList;
        List<String> includedList;
    }

   @Nonnull
   public Optional<EntityOps> getEntityOpsOpt(String entityName) {
       Optional<EntityOps> entityOpsOpt;
       entityOpsOpt = entityOpsList.stream().filter(
               entityOps -> entityOps.getEntityName().equals(entityName)).findAny();
       return entityOpsOpt;
   }

    @Nullable
    public List<Field> filterAndCorrectFields(String entityName, @Nonnull final List<Field> fields) {
        List<Field> result = new ArrayList<>(fields);
        if (CollectionUtils.isEmpty(result)) {
            return result;
        }
        Map<String, List<SystemMetaCorrectionObject.FieldOps>> globalFieldOpsMapfieldOpsMap = getGlobalFieldOpsMap();
        Map<String, List<SystemMetaCorrectionObject.FieldOps>> enityFieldOpsMap = getEntityFieldOpsMap(entityName);

        List<String> entityExcludedFields = getEntityExculdeFields(entityName);
        result = result.stream().filter(field -> !entityExcludedFields.contains(field.getFieldName())).collect(Collectors.toList());

        result.forEach(field -> {
            if (globalFieldOpsMapfieldOpsMap.containsKey(field.getFieldName())) {
                field.updateAttrs(entityName, globalFieldOpsMapfieldOpsMap.get(field.getFieldName()));
            }
        });
        result.forEach(field -> {
            if (enityFieldOpsMap.containsKey(field.getFieldName())) {
                field.updateAttrs(entityName, enityFieldOpsMap.get(field.getFieldName()));
            }
        });

        List<Field> entityAppendedFields = getEntityAppendedFields(entityName);
        if (!entityAppendedFields.isEmpty()) {
            result.addAll(entityAppendedFields);
        }
        return result;
    }

    @NotNull
    private Map<String, List<SystemMetaCorrectionObject.FieldOps>> getGlobalFieldOpsMap() {
        String entityName = "_global";
        return getEntityFieldOpsMap(entityName);
    }

    @NotNull
    private Map<String, List<SystemMetaCorrectionObject.FieldOps>> getEntityFieldOpsMap(String entityName) {
        Optional<EntityOps> entityOps = getEntityOpsOpt(entityName);
        boolean hasCorrectFields = entityOps.isPresent() && entityOps.get().getColumnFieldsMeta() != null
                && !CollectionUtils.isEmpty(entityOps.get().getColumnFieldsMeta().getCorrectFields());

        if (!hasCorrectFields) {
            return new HashMap<>();
        }

        List<SystemMetaCorrectionObject.FieldOps> fieldOpsList = entityOps.get().getColumnFieldsMeta().getCorrectFields();
        Map<String, List<SystemMetaCorrectionObject.FieldOps>> fieldOpsMap = fieldOpsList.stream().collect(
                // 一个字段可能有多个属性需要修改
                Collectors.groupingBy(SystemMetaCorrectionObject.FieldOps::getFieldName));
        return fieldOpsMap;
    }
    @NotNull
    private List<String> getEntityExculdeFields(String entityName) {
        Optional<EntityOps> entityOps = getEntityOpsOpt(entityName);

        return entityOps.map(EntityOps::getDbStruct)
                .map(ColumnListOps::getFilterColumns)
                .map(FilterColumnsOps::getExcludedList)
                .orElse(emptyList());
    }

    private List<Field> getEntityAppendedFields(String entityName) {
        Optional<EntityOps> entityOps = getEntityOpsOpt(entityName);

        return entityOps.map(EntityOps::getColumnFieldsMeta)
                .map(FieldListOps::getAppendFields)
                .orElse(emptyList());
    }

    String semanticVersion;
}
