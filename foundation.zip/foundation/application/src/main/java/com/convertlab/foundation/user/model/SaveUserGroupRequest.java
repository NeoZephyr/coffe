package com.convertlab.foundation.user.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class SaveUserGroupRequest {
    @NotBlank
    @Size(max = 64)
    public String name;

    @Size(max = 255)
    public String remark;

    public SaveUserGroupRequest(String name, String remark) {
        this.name = name;
        this.remark = remark;
    }
}
