package com.convertlab.foundation.user.service;

import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.user.entity.Dept;
import com.convertlab.foundation.user.model.DeptDTO;
import com.convertlab.foundation.user.model.DpTaskDTO;
import com.convertlab.foundation.user.model.ErrorDTO;
import com.convertlab.foundation.user.utils.DeptFileHeader;
import com.convertlab.foundation.user.utils.DpTaskStatus;
import com.convertlab.foundation.user.utils.DpTaskType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.regex.Pattern;

@Slf4j
@Service
public class ImportFromExcelTaskExecutorService extends TaskExecutorService {

    private DeptService deptService;

    public ImportFromExcelTaskExecutorService(KafkaTemplate<String, Map<String, Object>> kafkaTemplate, FileService fileService,
                                              DeptService deptService, DeptTaskService deptTaskService) {
        super(fileService, deptTaskService);
        this.deptService = deptService;
    }

    @Override
    boolean support(String type) {
      return DpTaskType.import_from_excel.name().equals(type);
    }

    @Override
    public void beforeExecute(DpTaskDTO dto) {
        dto.setStatus(DpTaskStatus.processing);
    }

    /**
     * 通过文件导入组织
     *
     * @param dto
     * @return
     */
    @Override
    public void doExecute(DpTaskDTO dto) {
        List<Map<String, Object>> deptList;

        try {
            deptList = getDeptListFromAttachment(dto);
        } catch (Exception e) {
            log.error("[ D&P ] 读取上传文件失败", e);
            dto.setStatus(DpTaskStatus.failed);
            dto.setFailReason(JsonUtils.instance().obj2Json(
                    new ErrorDTO(CommonErrors.VALIDATION_ERROR, "MSG_005_000023", new String[]{}, "Cannot read excel file, " + e.getMessage())));
            return;
        }

        Set<String> headers = deptList.get(0).keySet();

        if (!headers.contains(DeptFileHeader.NAME_TEXT) ||
                !headers.contains(DeptFileHeader.CODE_TEXT) ||
                !headers.contains(DeptFileHeader.PARENT_CODE_TEXT)) {
            log.error("dept file must contains dept name, dept code, parent code column");
            dto.setStatus(DpTaskStatus.failed);
            dto.setFailReason(JsonUtils.instance().obj2Json(
                    new ErrorDTO(CommonErrors.VALIDATION_ERROR, "MSG_005_000024", new String[]{}, "Dept file must contains dept name, dept code, parent code column")));
            return;
        }

        // 导入部门组织树的根
        List<Map<String, Object>> topDeptList = new LinkedList<>();
        Map<String, Map<String, Object>> codeToDeptMap = new LinkedHashMap<>();

        List<LinkedHashMap<String, Object>> errorList = new LinkedList<>();
        int rowNum = 1;

        LinkedHashSet<String> errorMsgSet = new LinkedHashSet<>();
        LinkedHashSet<Integer> duplicateRowSet = new LinkedHashSet<>();
        ErrorDTO errorDTO = null;

        for (Map<String, Object> dept : deptList) {
            dept.put("children", new LinkedList<>());
            dept.put("name", dept.get(DeptFileHeader.NAME_TEXT));
            dept.put("outCode", dept.get(DeptFileHeader.CODE_TEXT));
            dept.put("parentOutCode", dept.get(DeptFileHeader.PARENT_CODE_TEXT));

            dept.remove(DeptFileHeader.NAME_TEXT);
            dept.remove(DeptFileHeader.CODE_TEXT);
            dept.remove(DeptFileHeader.PARENT_CODE_TEXT);

            // 在原文件中的行号
            dept.put("rowNum", rowNum++);

            if (StringUtils.isBlank(dept.get("name").toString())) {
                errorList.add(new LinkedHashMap<String, Object>() {{
                    put("rowNum", dept.get("rowNum"));
                    put("error", "组织名称为空");
                }});
                errorMsgSet.add("组织名称为空");

                if (errorDTO == null) {
                    errorDTO = new ErrorDTO(CommonErrors.VALIDATION_ERROR, "MSG_005_000025", new String[]{}, "Exist dept which name is blank");
                }

                continue;
            }

            if (StringUtils.isBlank(dept.get("outCode").toString()) || StringUtils.isBlank(dept.get("parentOutCode").toString())) {
                errorList.add(new LinkedHashMap<String, Object>() {{
                    put("rowNum", dept.get("rowNum"));
                    put("error", "组织编码为空");
                }});
                errorMsgSet.add("组织编码为空");

                if (errorDTO == null) {
                    errorDTO = new ErrorDTO(CommonErrors.VALIDATION_ERROR, "MSG_005_000026", new String[]{}, "Exist dept which code is blank");
                }

                continue;
            }

            if (!Pattern.matches("\\w{1,64}", dept.get("outCode").toString()) ||
                    !Pattern.matches("\\w{1,64}", dept.get("parentOutCode").toString())) {
                errorList.add(new LinkedHashMap<String, Object>() {{
                    put("rowNum", dept.get("rowNum"));
                    put("error", "组织编码长度 1-64 位，只允许数字、大小写字符、下划线");
                }});
                errorMsgSet.add("组织编码格式不合法");

                if (errorDTO == null) {
                    errorDTO = new ErrorDTO(CommonErrors.VALIDATION_ERROR, "MSG_005_000027", new String[]{}, "Exist dept which code or parent dept code is blank");
                }

                continue;
            }

            if (codeToDeptMap.containsKey(dept.get("outCode"))) {
                Integer dupRowNum = (int) codeToDeptMap.get(dept.get("outCode")).get(String.valueOf(rowNum));
                if (!duplicateRowSet.contains(dupRowNum)) {
                    errorList.add(new LinkedHashMap<String, Object>() {{
                        put("rowNum", dupRowNum);
                        put("error", "组织编码重复");
                    }});
                    duplicateRowSet.add(dupRowNum);
                }
                errorList.add(new LinkedHashMap<String, Object>() {{
                    put("rowNum", dept.get("rowNum"));
                    put("error", "组织编码重复");
                }});
                errorMsgSet.add("组织编码重复");

                if (errorDTO == null) {
                    errorDTO = new ErrorDTO(CommonErrors.VALIDATION_ERROR, "MSG_005_000028", new String[]{}, "Exist duplicate dept code");
                }

                continue;
            }
            codeToDeptMap.put(dept.get("outCode").toString(), dept);
        }

        if (errorDTO != null) {
            dto.setStatus(DpTaskStatus.failed);
            dto.setFailReason(JsonUtils.instance().obj2Json(errorDTO));
            return;
        }

        List<Set<String>> circles = findAllCircles(codeToDeptMap);

        if (!circles.isEmpty()) {
            log.error("[ D&P ] 组织树文件中存在环形结构");
            int count = 1;
            for (Set<String> circle : circles) {
                for (String outCode : circle) {
                    int finalCount = count;
                    errorList.add(new LinkedHashMap<String, Object>() {{
                        put("rowNum", codeToDeptMap.get("outCode").get("rowNum"));
                        put("error", "组织处于环形结构中，环编号为 " + finalCount);
                    }});
                }
                ++count;
            }
            dto.setStatus(DpTaskStatus.failed);
            dto.setFailReason(JsonUtils.instance().obj2Json(
                    new ErrorDTO(CommonErrors.VALIDATION_ERROR, "MSG_005_000029", new String[]{}, "Circle exists in excel file")));
            return;
        }

        boolean hasRootDept = false;

        for (Map<String, Object> dept : deptList) {
            Object parentOutCode = dept.get("parentOutCode");

            if (!codeToDeptMap.containsKey(parentOutCode)) {
                topDeptList.add(dept);
                hasRootDept = true;
            } else {
                ((List<Map<String, Object>>) codeToDeptMap.get(parentOutCode).get("children")).add(dept);
            }
        }

        if (!hasRootDept) {
            log.info("[ D&P ] 没有发现最上级组织");
            dto.setStatus(DpTaskStatus.failed);
            dto.setFailReason(JsonUtils.instance().obj2Json(
                    new ErrorDTO(CommonErrors.VALIDATION_ERROR, "MSG_005_000030", new String[]{}, "No root dept found in excel file")));
            return;
        }

        List<String> missingDeptCode = new LinkedList<>();
        for (Map<String, Object> dept : topDeptList) {
            Dept topDept = deptService.getDeptByOutCode(dept.get("parentOutCode").toString());
            if (Objects.isNull(topDept)) {
                missingDeptCode.add(dept.get("outCode").toString());
            } else {
                codeToDeptMap.get(dept.get("outCode")).put("parent", topDept);
            }
        }

        if (!missingDeptCode.isEmpty()) {
            log.info("[ D&P ] 组织树中存在未知上级组织: {}", missingDeptCode);
            for (String outCode : missingDeptCode) {
                errorList.add(new LinkedHashMap<String, Object>() {{
                    put("rowNum", codeToDeptMap.get(outCode).get("rowNum"));
                    put("error", "存在未知上级组织");
                }});
            }
            dto.setStatus(DpTaskStatus.failed);
            dto.setFailReason(JsonUtils.instance().obj2Json(
                    new ErrorDTO(CommonErrors.VALIDATION_ERROR, "MSG_005_000031", new String[]{}, "Exist unknown parent dept in excel file")));
            return;
        }

        log.info("[ D&P ] 导入文件中的根组织信息：{}", topDeptList);

        try {
            doImportDept(topDeptList, codeToDeptMap, errorList);
        } catch (Exception ex) {
            log.error("[ D&P ] 创建组织失败, ", ex);

            dto.setStatus(DpTaskStatus.failed);
            dto.setFailReason(JsonUtils.instance().obj2Json(
                    new ErrorDTO(CommonErrors.VALIDATION_ERROR, "MSG_005_000032", new String[]{}, "Exist unknown error")));
            return;
        }

        if (!errorList.isEmpty()) {
            dto.setStatus(DpTaskStatus.failed);
            dto.setFailReason(JsonUtils.instance().obj2Json(
                    new ErrorDTO(CommonErrors.VALIDATION_ERROR, "MSG_005_000032", new String[]{}, "Exist unknown error")));

            errorList.forEach(errorMap -> {
                String rowNo = errorMap.get("rowNum").toString();
                String error = errorMap.get("error").toString();
                log.warn("Errors found in rowNum {}, error: {}", rowNo, error);
            });
        } else {
            dto.setStatus(DpTaskStatus.finished);
        }
    }

    /**
     * 从附件中获取组织树
     *
     * @param dto
     * @return
     */
    @NotNull
    private List<Map<String, Object>> getDeptListFromAttachment(DpTaskDTO dto) {
        List<Map<String, Object>> deptList = fileService.downloadAndReadCells(dto.getAttachmentId());

        if (Objects.isNull(deptList)) {
            throw new RuntimeException("组织树文件内容为空");
        }

        return deptList;
    }

    /**
     * 查找导入文件树结构中的环形结构
     *
     * @param codeToDeptMap
     * @return
     */
    private List<Set<String>> findAllCircles(Map<String, Map<String, Object>> codeToDeptMap) {
        List<Set<String>> circles = new ArrayList<>();
        codeToDeptMap.forEach((outCode, dept) -> {
            Set<String> visitSet = new HashSet<>();
            boolean inCircle = false;
            for (Set<String> circle : circles) {
                if (circle.contains(outCode)) {
                    inCircle = true;
                    break;
                }
            }
            if (!inCircle) {
                dfs(codeToDeptMap, outCode, outCode, visitSet, circles);
            }
        });
        return circles;
    }

    private void dfs(Map<String, Map<String, Object>> codeToDeptMap, String startOutCode, String outCode, Set<String> visitSet, List<Set<String>> circles) {
        if (visitSet.contains(outCode)) {
            if (Objects.equals(startOutCode, outCode)) {
                log.info("[ D&P ] exists circle: " + StringUtils.join(visitSet, ","));
                circles.add(new HashSet<>(visitSet));
            }
            return;
        }
        visitSet.add(outCode);
        List<Map<String, Object>> children = (List<Map<String, Object>>) codeToDeptMap.get(outCode).get("children");
        children.forEach(c -> {
            dfs(codeToDeptMap, startOutCode, c.get(outCode).toString(), visitSet, circles);
        });
        visitSet.remove(outCode);
    }

    private void doImportDept(List<Map<String, Object>> topDeptList, Map<String, Map<String, Object>> codeToDeptMap,
                              List<LinkedHashMap<String, Object>> errorList) {
        Queue<Map<String, Object>> deptQueue = new LinkedBlockingQueue<>();

        topDeptList.forEach(deptQueue::offer);

        while (!deptQueue.isEmpty()) {
            Map<String, Object> dept = deptQueue.remove();
            Dept createDept = doImportDeptInternal(dept, errorList);
            List<Map<String, Object>> childrenDeptList = (List<Map<String, Object>>) ((Map<String, Object>) codeToDeptMap.get(dept.get("outCode"))).get("children");

            childrenDeptList.forEach(it -> {
                it.put("parent", createDept);
                deptQueue.offer(it);
            });
        }
    }

    private Dept doImportDeptInternal(Map<String, Object> dept, List<LinkedHashMap<String, Object>> errorList) {
        if (!dept.containsKey("parent")) {
            errorList.add(new LinkedHashMap<String, Object>() {{
                put("rowNum", dept.get("rowNum"));
                put("error", "创建上级组织失败");
            }});
            return null;
        }

        int level = ((Dept) dept.get("parent")).getPath().split("-").length;

        if (level >= 10) {
            errorList.add(new LinkedHashMap<String, Object>() {{
                put("rowNum", dept.get("rowNum"));
                put("error", "组织层级限制在 10 层以内");
            }});
            return null;
        }

        DeptDTO deptDTO = new DeptDTO();
        deptDTO.setName(dept.get("name").toString());
        deptDTO.setParentOutCode(dept.get("parentOutCode").toString());
        deptDTO.setOutCode(dept.get("outCode").toString());
        Dept createDept = deptService.saveDept(deptDTO);

        if (Objects.isNull(createDept)) {
            errorList.add(new LinkedHashMap<String, Object>() {{
                put("rowNum", dept.get("rowNum"));
                put("error", "创建组织失败，请检查组织编码是否已存在或稍后重试");
            }});
            return null;
        }

        return createDept;
    }

    private final static String ERROR_TITLE = "失败原因";

    /**
     * 生成错误记录文件
     *
     * @param task
     * @param failedRecords
     * @return
     */
//    def genFailedExcelFile(def task, def failedRecords) {
//
//        def attachmentId = task.attachmentId
//        def originSheet = fileService.getExcelSheet(attachmentId, 0);
//
//        if (!originSheet) {
//            return null
//        }
//
//        XSSFWorkbook failedWorkBook;
//        XSSFSheet failedSheet;
//
//        try {
//            failedWorkBook = new XSSFWorkbook()
//            failedSheet = failedWorkBook.createSheet("failedDepartments")
//
//            def originRow
//            def failedRow
//            def originCell
//            def failedCell
//
//            originRow = fileService.getExcelLine(originSheet, 0)
//
//            if (!originRow) {
//                log.error("can not get origin file header")
//                return
//            }
//
//            def cellNum = originRow.getLastCellNum()
//            def rowCount = 0
//
//            failedRow = failedSheet.createRow(rowCount++)
//
//            for (int i = 0; i < cellNum; ++i) {
//                originCell = originRow.getCell(i)
//
//                if (originCell) {
//                    failedCell = failedRow.createCell(i, (originCell.getCellType() == CellType.FORMULA) ? CellType.STRING : originCell.getCellType())
//                    failedCell.setCellValue(fileService.getCellValue(originCell))
//                } else {
//                    failedRow.createCell(i)
//                }
//            }
//
//            failedCell = failedRow.createCell(cellNum)
//            failedCell.setCellValue(ERROR_TITLE)
//
//            for (def failedRecord : failedRecords) {
//                def failedRowNum = failedRecord.rowNum
//                def error = failedRecord.error
//
//                originRow = fileService.getExcelLine(originSheet, failedRowNum)
//
//                if (!originRow) {
//                    log.error("can not get row: ${failedRowNum}")
//                    continue
//                }
//
//                failedRow = failedSheet.createRow(rowCount++)
//
//                for (int i = 0; i < cellNum; ++i) {
//                    originCell = originRow.getCell(i)
//
//                    if (originCell) {
//                        failedCell = failedRow.createCell(i, (originCell.getCellType() == CellType.FORMULA) ? CellType.STRING : originCell.getCellType())
//                        failedCell.setCellValue(fileService.getCellValue(originCell))
//                    } else {
//                        failedRow.createCell(i)
//                    }
//                }
//
//                failedCell = failedRow.createCell(cellNum)
//                failedCell.setCellValue(error)
//            }
//
//            def date = new Date().format('yyyy-MM-dd_HH-mm-ss')
//            def bytes = fileService.generateOutputBytes(failedWorkBook)
//            def attachment = fileService.upload("failedDepartments_${date}.xlsx",
//                    new ByteArrayInputStream(bytes), "application/octet-stream", bytes.size(), FileUsage.EXPORT)
//
//            return attachment
//        } catch (Exception e) {
//            log.warn "Department import error in upload failed result", e
//            return null
//        }
//    }
}
