package com.convertlab.foundation.user.controller;


import com.convertlab.foundation.user.entity.Dept;
import com.convertlab.foundation.user.service.DeptService;
import com.convertlab.foundation.user.service.UserGroupService;
import com.convertlab.foundation.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Nonnull;
import javax.validation.constraints.NotNull;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Qualifier("UserInfoController")
@RestController
@RequestMapping("v1/userInfo")
@RequiredArgsConstructor
public class UserInfoController {

    private final UserGroupService userGroupService;

    private final UserService userService;

    private final DeptService deptService;

    @Nonnull
    @GetMapping("/userGroups/{userId}")
    Set<String> getGroupCodes(@PathVariable Long userId) {
        return new HashSet<>(userGroupService.indexByUser(userId));
    }

    @Nonnull
    @GetMapping("/user/isAdmin/{userId}")
    Boolean isAdminUser(@NotNull @PathVariable Long userId) {
        return userService.isAdmin(userId);
    }

    @GetMapping("/subDept/{code}")
    Set<String> listChildDept(@PathVariable String code) {
        return new HashSet<>(deptService.listChildDeptCode(code));
    }

    @GetMapping("/subOuterCode/{code}")
    Set<String> listOuterChildDept(@PathVariable String code) {
        List<String> deptCodeList = deptService.listChildDeptCode(code);
        if (CollectionUtils.isEmpty(deptCodeList)) {
            return Collections.emptySet();
        } else {
            return deptService.getDeptsByCodeList(deptCodeList).stream()
                    .map(Dept::getOutCode).collect(Collectors.toSet());
        }
    }
}
