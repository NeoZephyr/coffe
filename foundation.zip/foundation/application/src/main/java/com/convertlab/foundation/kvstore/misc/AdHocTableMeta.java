package com.convertlab.foundation.kvstore.misc;

import com.convertlab.foundation.library.hbase.core.HbaseColumnSchema;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class AdHocTableMeta {

    @Data
    public static class ColumnFamily{
        String name;
        String rowKeyRule;
        List<HbaseColumnSchema> columns;
    }

    @Data
    public static class StorageType {
        String dbType;
        String dbTable;
        List<ColumnFamily> columnFamilies;
    }



    private String dbTableName;
    private Map<String, StorageType> dbStorageTypes;

}
