package com.convertlab.foundation.gdmmeta.model;

import javax.annotation.Nonnull;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiFunction;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.google.common.collect.Maps;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.function.TriFunction;

@Slf4j
public class GdmObjectMerger {
    protected Map<Class, MergeStrategies> mergeStrategiesMap;
    private ObjectMapper objectMapper;

    private GdmObjectMerger() {
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new Jdk8Module());
        mergeStrategiesMap = new HashMap<>();
    }

    /**
     * 给每个GDM对象定义merge策略。 这里使用一个Map来存储每个GDM对象的merge策略。
     * Map的Key是GDM对象类， Value是MergeStrategies对象，MergeStrategies对象包含了三个策略：
     * 1. matchStrategy: 在遍历Collection时用于判断两个GDM对象是否匹配
     * 2. assignValueStrategy: 用于定义如何将overlay对象的值赋值给base对象，可以是加法：overlay覆盖，也可以是减法：overlay中有值的属性，base中置为null
     * 3. recursiveStrategy: 用于判断是否需要递归merge
     */
    private void register(@Nonnull Map.Entry<Class, MergeStrategies>... entries) {
        for (Map.Entry<Class, MergeStrategies> entry : entries) {
            mergeStrategiesMap.put(entry.getKey(), entry.getValue());
        }
    }

    @Nonnull
    public static GdmObjectMerger build(Map.Entry<Class, MergeStrategies>... entries) {
        GdmObjectMerger gdmObjectMerger = new GdmObjectMerger();
        gdmObjectMerger.register(entries);
        return gdmObjectMerger;
    }

    @AllArgsConstructor
    @Getter
    public static class MergeStrategies<T extends AssignValueStrategy> {
        @Nonnull
        final private BiFunction<T, T, Boolean> matchStrategy;
        @Nonnull
        final private TriFunction<T, T, GdmObjectMerger, T> assignValueStrategy;
        @Nonnull
        final private GdmObjectMerger.RecursiveStrategy recursiveStrategy;
    }

    public static class EntityMergeStrategies {
        @Nonnull
        public static Map.Entry OVERRIDE_FIELDS = Maps.immutableEntry(
                Entity.class, new GdmObjectMerger.MergeStrategies<>(
                        (base, overlay) -> base.getEntityName().equals(overlay.getEntityName()),
                        Entity::replaceOrAddIfNotNull,
                        RecursiveStrategy.NO_RECURSIVE
                )
        );

        @Nonnull
        public static Map.Entry ADD_NOT_EXISTED_FIELDS = Maps.immutableEntry(
                Entity.class, new GdmObjectMerger.MergeStrategies<>(
                        (base, overlay) -> base.getEntityName().equals(overlay.getEntityName()),
                        Entity::replaceOrAddIfNotNull,
                        GdmObjectMerger.RecursiveStrategy.RECURSIVE
                )
        );

        @Nonnull
        public static Map.Entry UPDATE_EXISTED_FIELDS_OR_INIT = Maps.immutableEntry(
                Entity.class, new GdmObjectMerger.MergeStrategies<>(
                        (base, overlay) -> base.getEntityName().equals(overlay.getEntityName()),
                        Entity::updateFieldOrInitFieldList,
                        GdmObjectMerger.RecursiveStrategy.RECURSIVE
                )
        );


    }

    public static class FieldMergeStrategies {
        @Nonnull
        public static Map.Entry BY_ID = Maps.immutableEntry(Field.class, new MergeStrategies<>(
                        (base, overlay) -> base.getId().equals(overlay.getId()), // Field被Entity以List<Field>形式引用，所以需要定义查找方法
                        Field::replaceOrAddIfNotNull,
                        RecursiveStrategy.EXPAND_COLLECTION_NO_RECURSIVE
                )
        );
        @Nonnull
        public static Map.Entry DEFAULT = Maps.immutableEntry(Field.class, new MergeStrategies<>(
                        (base, overlay) -> base.getFieldName().equals(overlay.getFieldName()),
                        Field::replaceOrAddIfNotNull,
                        RecursiveStrategy.EXPAND_COLLECTION_NO_RECURSIVE
                )
        );
        @Nonnull
        public static Map.Entry DO_NOTHING = Maps.immutableEntry(Field.class, new MergeStrategies<>(
                        (base, overlay) ->  Boolean.TRUE,
                        Field::dummy,
                        RecursiveStrategy.NO_RECURSIVE
                )
        );
        @Nonnull
        public static Map.Entry FIND_BY_COLUMN_NAME = Maps.immutableEntry(Field.class, new MergeStrategies<>(
                        (base, overlay) ->  base.getDbColumnName().equals(overlay.getDbColumnName()),
                        Field::dummy,
                        RecursiveStrategy.NO_RECURSIVE
                )
        );
        @Nonnull
        public static Map.Entry UPDATE_COLUMN_INFO = Maps.immutableEntry(Field.class, new MergeStrategies<>(
                        (base, overlay) ->  base.getDbColumnName().equals(overlay.getDbColumnName()),
                        Field::updateDbColumnInfo,
                        RecursiveStrategy.NO_RECURSIVE
                )
        );



    }
    public static class InheritanceMergeStrategies {
        @Nonnull
        public static Map.Entry DEFAULT = Maps.immutableEntry(Inheritance.class, new MergeStrategies<>(
                        (base,overlay) -> true,
                        Inheritance::unsetIfNotNull,
                        RecursiveStrategy.RECURSIVE
                )
        );
    }


    /**
     * 使用MergeStrategies中定义的策略, 即AssignValueStrategy，将overlay对象的值赋值给base对象
     * @param base
     * @param overlay
     * @return overlay合并到base之后的对象
     * @param <T>
     */
    public <T extends AssignValueStrategy> T merge(@Nonnull T base, T overlay) {
        // 日志DEBUG打开时，把base，overlay写入debug日志
        if (log.isTraceEnabled()) {
            log.trace("GdmObjectMerger: {}, base: {}",this.getClass().getCanonicalName(), format(base));
            log.trace("GdmObjectMerger: {}, overlay: {}",this.getClass().getCanonicalName(), format(overlay));
        }
        T result = (T) getMergeStrategies(base.getClass()).getAssignValueStrategy().apply(base, overlay, this);
        if (log.isTraceEnabled()) {
            log.trace("GdmObjectMerger: {}, result: {}",this.getClass().getCanonicalName(), format(result));
        }
        return result;
    }

    //

    /**
     * 获取MergeStrategies对象. 提示：幺蛾子方法，使用的时候必须显示定义接收此函数返回值的对象类型。如：<br/>
     *   <code>GdmObjectMerger.MergeStrategies<Field> fieldMergeStrategies = gdmObjectMerger.getMergeStrategies(Field.class);
     *   fieldMergeStrategies.setAssignValueStrategy(Field::unsetIfNotNull);</code><br/>
     * 而不能两行合并成一行的写法: <br/>
     *   <code>gdmObjectMerger.getMergeStrategies(Field.class).setAssignValueStrategy(Field::unsetIfNotNull);</code> <br/>
     * 原因是在使用了泛型后，JAVA没有办法判断 setAssignValueStrategy 能够接收的参数。没有深究，如果能解决，请 push 代码！
     * @param clazz GDM对象的类型
     * @return 这个类型的合并策略集
     * @param <S> GDM对象的类型
     */
    public <S extends AssignValueStrategy> MergeStrategies<S> getMergeStrategies(Class clazz) {
        return (mergeStrategiesMap.get(clazz));
    }

    /**
     * 获取MergeStrategies中定义的matchStrategy
     * @param clazz GDM对象的类型
     * @return
     */
    @Nonnull
    public BiFunction<AssignValueStrategy, AssignValueStrategy, Boolean> getMatchStrategy(Class clazz) {
        return getMergeStrategies(clazz).getMatchStrategy();
    }

    /**
     * 获取MergeStrategies中定义的assignValueStrategy
     * @param clazz GDM对象的类型
     * @return
     */
    @Nonnull
    public TriFunction<AssignValueStrategy, AssignValueStrategy, GdmObjectMerger,
            AssignValueStrategy> getAssignValueStrategy(Class clazz) {
        return getMergeStrategies(clazz).getAssignValueStrategy();
    }

    /**
     * 获取MergeStrategies中定义的recursiveStrategy
     * @param clazz GDM对象的类型
     * @return
     */
    @Nonnull
    public GdmObjectMerger.RecursiveStrategy getRecursiveStrategy(Class clazz) {
        return getMergeStrategies(clazz).getRecursiveStrategy();
    }

    /**
     * 递归策略,只会在要合并的属性是Collection<Object>和ComplexObject时起作用<br/>
     * 为了简化，我们用Entity中的<pre>List&lt;Field&gt; fields</pre>来举例子<br/>
     * 并且使用<code>ReplaceOrAddIfNotNull</code> Strategy(overlay非空则覆盖)来举例子<br/>
     * base = entity{ name: "entity1", fields: [{a:1,b:2} , {a:3}] }<br/>
     * overlay = entity{ name: "entity1", fields: [{a:1,c:3}, {a:2}] }<br/>
     */
    public enum RecursiveStrategy {
        /**
         * 不递归, 此时会用overlay.fields直接覆盖到base.fields, base.fields中的所有元素彻底丢失。<br/>
         * merged = entity{ name: "entity1", fields: [{a:1, c:3}, {a:2}] }
         */
        NO_RECURSIVE,
        /**
         * 不递归但是展开COLLECTION。此时会用overlay.fields中的元素替换base.fields中的元素，
         * 如果base.fields中没有对应的元素，则添加到base.fields中。<br/>
         * field内部的成员变量的值，都会变成overlay.fields中的值。<br/>
         * merged = entity{ name: "entity1", fields: [{a:1, c:3}, {a:2} , {a:3}] }
         */
        EXPAND_COLLECTION_NO_RECURSIVE,
        /**
         * 递归。此时除了展开Collection，还会递归调用Field类的merge方法，
         * 如果这个时候Field的合并策略也是<code>ReplaceOrAddIfNotNull</code>，那么base.field内部的成员变量的值，都会与overlay.fields中的值合并。<br/>
         * merged = entity{ name: "entity1", fields: [{a:1, b:2, c:3}, {a:2} , {a:3}] } <br/>
         *
         * 要注意的是，如果Field的合并策略和Entity不一样，例如Field的合并策略是<code>UnsetIfNotNull</code>，那么base.field内部的成员变量的值，有些会被置空。<br/>
         * merged =  entity{ name: "entity1", fields: [{a:null, b:2, c:null}, {a:3}] }
         */
        RECURSIVE
    }

    private String format(Object toLog) {
        try {
            return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(toLog);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException(e);
        }
    }

}
