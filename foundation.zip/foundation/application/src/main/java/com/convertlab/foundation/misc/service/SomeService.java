package com.convertlab.foundation.misc.service;

import com.convertlab.foundation.library.business.cache.CacheEvent;
import com.convertlab.foundation.library.business.eventbroker.*;
import com.convertlab.foundation.library.business.feature.FeatureEvent;
import com.convertlab.foundation.library.business.property.EventBrokerProperties;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.constant.ComponentNames;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.gdmmeta.constants.MetaEvent;
import com.convertlab.foundation.library.gdmmeta.constants.SchemaEvent;
import com.convertlab.foundation.library.gdmmeta.model.general.BaseMetaSchema;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.multitenancy.exception.IllegalTenantIdException;
import com.convertlab.foundation.library.business.constants.CommonEventTypes;
import com.convertlab.foundation.library.utils.Try;
import com.google.common.collect.ImmutableMap;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.event.EventListener;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;

import javax.annotation.Nonnull;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import static com.convertlab.foundation.library.business.eventbroker.EventListenerHelper.NOTIFICATION_BROKER_EXECUTOR;

/**
 * 用来测试notification的服务
 */
@Slf4j
public class SomeService {

    public static final String QUEUE = "queue";

    /**
     * 这个地方直接使用了ApplicationEventPublisher，只是为了测试用，生产代码中不要直接引用ApplicationEventPublisher来发布事件
     * 推荐使用继承GenericDomainEventPublisher来发布事件,如果实在是需要ApplicationEventPublisher，可以调用
     * GenericDomainEventPublisher#getAppEventPublisher()来获取.
     */
    private final ApplicationEventPublisher eventPublisher;
    private final EventBrokerProperties eventBrokerProperties;

    private final GenericDomainEventPublisher<DemoEvent, DemoEvent.Dto, DemoEvent.DemoEventType> demoEventPublisher;
    private final RedisTemplate<String, String> redisTemplate;

    private final NotificationBroker dummyBroker = new NotificationBroker(null, null,
            new BrokerSettings("dummy", "dummy"));
    public SomeService(ApplicationEventPublisher eventPublisher, EventBrokerProperties eventBrokerProperties, RedisTemplate<String, String> redisTemplate) {
        this.eventPublisher = eventPublisher;
        this.eventBrokerProperties = eventBrokerProperties;
        this.redisTemplate = redisTemplate;
        demoEventPublisher = new GenericDomainEventPublisher<DemoEvent, DemoEvent.Dto, DemoEvent.DemoEventType>(
                eventPublisher,eventBrokerProperties
        ) {
            @Override
            protected String getPublisher() {
                return ComponentNames.DEMO_ONLY;
            }

            @Override
            protected DemoEvent createEvent(DemoEvent.Dto dto, EventOptions options) {
                return new DemoEvent(this, dto, options);
            }
        };
    }

    public String sendMiscEvent(@Nonnull String s) {
        try {
            EventOptions options = EventOptions.EventOptionsBuilder.builder()
                    .type(CommonEventTypes.MISC)
                    .publisher("SOME_SERVICE")
                    .build();
            NotificationEvent<?> notificationEvent;
            if (s.equalsIgnoreCase("meta")) {
                MetaEvent.Dto metaDto = new MetaEvent.Dto();
                metaDto.setObjectName("a");
                metaDto.setMetaType(BaseMetaSchema.MetaType.EXT_MISC);
                notificationEvent = new MetaEvent(this, metaDto, options);
                publish(notificationEvent);
            } else if (s.equalsIgnoreCase("schema")) {
                Map<String, String> map = ImmutableMap.of("key", "value");
                notificationEvent = new SchemaEvent(this, map, options);
                publish(notificationEvent);
            } else if (s.equalsIgnoreCase("feature")) {
                FeatureEvent.Dto dto = new FeatureEvent.Dto();
                dto.setFeature("feature");
                dto.setEnabled(true);
                options = options.toBuilder().type(FeatureEvent.FeatureEventType.FEATURE_TOGGLED.getValue()).build();
                notificationEvent = new FeatureEvent(this, dto, options);
                publish(notificationEvent);
            } else if (s.equalsIgnoreCase("error")) {
                DemoEvent.Dto dto = new DemoEvent.Dto();
                options = options.toBuilder().type(DemoEvent.DemoEventType.THROW_ERROR.getValue()).build();
//                notificationEvent = new DemoEvent(this, dto, options);
                demoEventPublisher.publish(dto,options,"Sent a THROW_ERROR event");
            } else {
                DemoEvent.Dto dto = new DemoEvent.Dto();
                dto.setName("name");
//                notificationEvent = new DemoEvent(this, dto, options);
                demoEventPublisher.publish(dto,options,"Sent a default event");
            }
        } catch (IllegalArgumentException e) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "message_code...", "Input validation error",
                    new String[]{s, CommonEventTypes.MISC, "SOME_SERVICE"});
        }
        return "OK";
    }

    public void sendAnyEvent(@Nonnull RemoteNotificationEvent event) {
        publish(dummyBroker.fromRemoteEvent(event.toBuilder().build()));
    }

    private void publish(NotificationEvent<?> genericEvent) {
        if (!demoEventPublisher.isEnabled()) {
            log.info("[SomeService消息发送者] 事件发布被禁用，不发送事件: {}", genericEvent);
            return;
        }
        log.info("[SomeService消息发送者] 走你！: {}", genericEvent);
        try (TemporaryTenantContext ignored = new TemporaryTenantContext(TenantContextHolder.getTenantIdExt())) {
            eventPublisher.publishEvent(genericEvent);
        }
    }

    @EventListener
    @Order(Ordered.HIGHEST_PRECEDENCE)
    @Async(NOTIFICATION_BROKER_EXECUTOR)
    public void handleAlarm(NotificationEvent<?> event) {
        log.info("[SomeService消息监听者] 接收所有消息:{}, {}", event.getClass(), event);
        log.info("[SomeService消息监听者] 谨慎的处理消息， 然后偷偷把事件对象放在了某处：{}", event);

        // save the else into redis as sampling
        redisTemplate.opsForList().rightPush(QUEUE, Instant.now().toString() + ":" + event);
        redisTemplate.expire(QUEUE, 30, TimeUnit.SECONDS);
    }

    /**
     * 查看SomeService处理过的消息的原值
     *
     * @return 消息原值
     */
    public String peek() {
        log.info("[SomeService消息监听者] 从租户 [{}] 偷偷看一眼", TenantContextHolder.getTenantId());
        try {
            final String[] event = {""};
            Long size = redisTemplate.opsForList().size(QUEUE);
            List<String> list = redisTemplate.opsForList().range(QUEUE, 0, Optional.ofNullable(size).orElse(0L));
            if (Objects.isNull(list)) {
                return "Empty";
            }
            list.forEach(it -> {
                if (it != null) {
                    event[0] = event[0] + it + "\n";
                }
            });
            return event[0];
        } catch (IllegalTenantIdException exception) {
            return "Access from an illegal tenant id. P.S. You've been watched!";
        }
    }
}
