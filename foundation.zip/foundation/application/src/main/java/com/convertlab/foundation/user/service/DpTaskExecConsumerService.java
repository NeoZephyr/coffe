package com.convertlab.foundation.user.service;

import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.user.entity.DpTask;
import com.convertlab.foundation.user.model.DpTaskDTO;
import com.convertlab.foundation.user.utils.DpTaskStatus;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.BeanUtils;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class DpTaskExecConsumerService {

    private final DeptTaskService deptTaskService;

    private final DpTaskContext dpTaskContext;

    public DpTaskExecConsumerService(DeptTaskService deptTaskService, DpTaskContext dpTaskContext) {
        this.deptTaskService = deptTaskService;
        this.dpTaskContext = dpTaskContext;
    }

    @KafkaListener(
            topics = "${kafka.dpRuleRebuild.execTopic}",
            groupId = "${kafka.dpRuleRebuild.execGroupId}",
            concurrency = "${kafka.dpRuleRebuild.numConsumers}",
            properties = {"value.deserializer=org.apache.kafka.common.serialization.StringDeserializer"}
    )
    public void consume(String value) {
        log.info("DpTaskExecConsumerService receive message {}", value);
        DpTaskDTO dto = JsonUtils.instanceOfDto().json2Obj(value, DpTaskDTO.class);
        try {
            dispatchTask(dto);
        } catch (Exception e) {
            log.error("DpTaskExecConsumerService consume error", e);
        }
    }

    private void dispatchTask(DpTaskDTO dto) {
        dto.setStatus(DpTaskStatus.processing);
        DpTask dpTask = deptTaskService.update(dto);
        executeTask(dpTask);
    }

    private void executeTask(DpTask dpTask) {
        DpTaskDTO dto = new DpTaskDTO();
        BeanUtils.copyProperties(dpTask, dto);
        dpTaskContext.executeTaskStrategy(dpTask.getType(), dto);
    }

}
