package com.convertlab.foundation.metahealth.loader;

import com.convertlab.foundation.libaray.meta.health.MetaLoader;
import com.convertlab.foundation.libaray.meta.health.annotation.MetaLoaderAnnotation;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@MetaLoaderAnnotation
@RequiredArgsConstructor
public class GdmEntityLoader implements MetaLoader<GdmEntity> {
    private final GsMetaClient gsMetaClient;

    @Override
    public List<GdmEntity> loadAll() {
        Map<String, String> virtualFilter = new HashMap<>();
        virtualFilter.put("isVirtual", "true");
        List<GdmEntity> virtualEntities = gsMetaClient.getEntityListByFilter(virtualFilter);
        log.info("Virtual Entities size: {}", virtualEntities.size());
        Set<String> virtualEntityNames = virtualEntities.stream().map(GdmEntity::getEntityName).collect(Collectors.toSet());

        Map<String, String> allFilter = new HashMap<>();
        List<GdmEntity> all = gsMetaClient.getEntityListByFilter(allFilter);

        List<GdmEntity> filteredEntities = all.stream()
                .filter(entity -> !virtualEntityNames.contains(entity.getEntityName())).collect(Collectors.toList());
        log.info("Filtered Entities size: {}", filteredEntities.size());
        return filteredEntities;
    }
}
