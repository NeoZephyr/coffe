package com.convertlab.foundation.gdmmeta.utils;

import javax.annotation.Nonnull;

import com.convertlab.foundation.library.multitenancy.context.TenantContextHelper;
import lombok.extern.slf4j.Slf4j;

import java.time.Duration;
import java.time.Instant;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

@Slf4j
public class FunUtils {

    public static <T, R> R runInTenant(Long tenantId, T params, @Nonnull Function<T, R> function) {
//        R result = null;
//        try {
//            TenantContextHolder.setTenantId(tenantId);
//            result = function.apply(params);
//        } finally {
//            TenantContextHolder.setTenantId(null);
//        }
//        return result;

        return TenantContextHelper.withTenant(tenantId, () -> function.apply(params));
    }

    public static <R> R runInTenant(Long tenantId, @Nonnull Supplier<R> supplier) {
//        R result = null;
//        try {
//            TenantContextHolder.setTenantId(tenantId);
//            result = supplier.get();
//        } finally {
//            TenantContextHolder.setTenantId(null);
//        }
//        return result;
        return TenantContextHelper.withTenant(tenantId, supplier);
    }

    public static <T1, T2, R> R runInTenant(Long tenantId, T1 params1, T2 params2, @Nonnull BiFunction<T1, T2, R> biFunction) {
//        R result = null;
//        try {
//            TenantContextHolder.setTenantId(tenantId);
//            result = biFunction.apply(params1, params2);
//        } finally {
//            TenantContextHolder.setTenantId(null);
//        }
//        return result;
        return TenantContextHelper.withTenant(tenantId, () -> biFunction.apply(params1, params2));
    }

    public static <T, R> R printElapsed(T param, @Nonnull Function<T, R> function, String methodMessage) {

        Instant start = Instant.now();
        R result = function.apply(param);
        Instant stop = Instant.now();
        long ms = Duration.between(start, stop).toMillis();
        log.info("ElapsedTime: {}, method: {}", ms, methodMessage);
        return result;
    }

    public static <R> R printElapsed(@Nonnull Supplier<R> supplier, String methodMessage) {
        Instant start = Instant.now();
        R result = supplier.get();
        Instant stop = Instant.now();
        long ms = Duration.between(start, stop).toMillis();
        log.info("ElapsedTime: {}, method: {}", ms, methodMessage);
        return result;
    }

    public static <T1, T2, R> R printElapsed(T1 params1, T2 params2, @Nonnull BiFunction<T1, T2, R> biFunction, String methodMessage) {
        Instant start = Instant.now();
        R result = biFunction.apply(params1, params2);
        Instant stop = Instant.now();
        long ms = Duration.between(start, stop).toMillis();
        log.info("ElapsedTime: {}, method: {}", ms, methodMessage);
        return result;
    }

    public static <T, S> void printElapsed(T params1, S params2, @Nonnull BiConsumer<T, S> biConsumer, String methodMessage) {
        Instant start = Instant.now();
        biConsumer.accept(params1, params2);
        Instant stop = Instant.now();
        long ms = Duration.between(start, stop).toMillis();
        log.info("ElapsedTime: {}, method: {}", ms, methodMessage);
        return;
    }

}
