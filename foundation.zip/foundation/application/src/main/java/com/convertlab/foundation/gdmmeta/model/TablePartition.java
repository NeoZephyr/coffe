package com.convertlab.foundation.gdmmeta.model;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import static com.convertlab.foundation.gdmmeta.model.metaobject.ProfileEventMetaObject.UDO_TABLE_PARTITION_IDENTIFIER;

import java.util.Optional;

import com.convertlab.foundation.library.gdmmeta.model.GdmTablePartition;
import com.convertlab.foundation.library.gdmmeta.model.ImmutableGdmTablePartition;

import com.convertlab.foundation.gdmmeta.persistance.entity.GdmTablePartitionModel;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class TablePartition implements AssignValueStrategy<TablePartition> {

    @Nullable
    private String identifierField;
    @Nullable
    private String identifierValue;


    public TablePartition(@Nonnull GdmTablePartition gdmTablePartition) {
        this.identifierField = gdmTablePartition.getIdentifierField();
        this.identifierValue = gdmTablePartition.getIdentifierValue();
    }

    public TablePartition(@Nonnull TablePartition tablePartition) {
        this.identifierField = tablePartition.getIdentifierField();
        this.identifierValue = tablePartition.getIdentifierValue();
    }

    @Nonnull
    public static Optional<TablePartition> empty() {
        return Optional.empty();
    }

    public static TablePartition newUdoTablePartition(String identifierValue) {
        TablePartition tablePartition = TablePartition.builder()
                .identifierField(UDO_TABLE_PARTITION_IDENTIFIER).identifierValue(identifierValue)
                .build();
        return tablePartition;
    }
    @Nonnull
    public GdmTablePartition gdmTablePartition() {
        GdmTablePartition tablePartition = ImmutableGdmTablePartition.builder()
                .identifierField(this.identifierField)
                .identifierValue(this.identifierValue)
                .build();
        return tablePartition;
    }

    @Nonnull
    public GdmTablePartitionModel gdmTablePartitionModel() {
        GdmTablePartitionModel gdmTablePartitionModel = new GdmTablePartitionModel();
        gdmTablePartitionModel.setIdentifierField(getIdentifierField());
        gdmTablePartitionModel.setIdentifierValue(getIdentifierValue());
        gdmTablePartitionModel.setIdentifierType("String");
        return gdmTablePartitionModel;
    }

    @Nonnull
    @Override
    public TablePartition replaceOrAddIfNotNull(@Nullable TablePartition overlay, GdmObjectMerger gdmObjectMerger) {
        if (overlay == null) {
            return this;
        }
        if (overlay.identifierField != null) {
            this.identifierField = overlay.identifierField;
        }
        if (overlay.identifierValue != null) {
            this.identifierValue = overlay.identifierValue;
        }
        return this;
    }

    @Nonnull
    @Override
    public TablePartition unsetIfNotNull(@Nullable TablePartition overlay, GdmObjectMerger gdmObjectMerger) {
        if (overlay == null) {
            return this;
        }
        if (overlay.identifierField != null) {
            this.identifierField = null;
        }
        if (overlay.identifierValue != null) {
            this.identifierValue = null;
        }
        return this;
    }
}
