package com.convertlab.foundation.gdmdata.controller;

import com.convertlab.foundation.api.gdmdata.GdmData;
import com.convertlab.foundation.api.gdmdata.GdmDataApi;
import com.convertlab.foundation.api.gdmdata.GenericGdmModel;
import com.convertlab.foundation.gdmdata.service.GenericGdmModelService;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/v1/gdm/data")
@Validated
@RequiredArgsConstructor
@Tag(name = "Generic Data接口")
public class GdmDataController implements GdmDataApi {
    @Nonnull
    private final GenericGdmModelService gdmEntityService;
    @Nonnull
    @Qualifier("localGsMetaClient")
    private final GsMetaClient gsMetaClient;

    @Nullable
    @Override
    @GetMapping("{entityName}/{id}")
    public GdmData selectById(@Nonnull @PathVariable String entityName, @PathVariable Object id, @Nonnull @RequestParam(value = "select", required = false) List<String> selectList) {
        GdmEntity gdmEntity = gsMetaClient.getEntity(entityName);
        Assert.notNull(gdmEntity, "Gdm entity not found "+entityName);
        GenericGdmModel gdmModel = gdmEntityService.selectById(gdmEntity, id, selectList);
        return gdmModel == null ? new GdmData() : gdmModel.toGdmData();
    }

    @Nonnull
    @Override
    @GetMapping("{entityName}")
    public List<GdmData> selectByIds(@Nonnull @PathVariable String entityName,
                                     @RequestParam(value = "ids", required = false) List<Object> ids,
                                     @Nonnull @RequestParam(value = "select", required = false, defaultValue = "*") List<String> selectList,
                                     @RequestParam(value = "offset", required = false, defaultValue = "0") Integer offset,
                                     @RequestParam(value = "limit", required = false, defaultValue = "20") Integer limit,
                                     @RequestParam Map<String, Object> params) {
        GdmEntity gdmEntity = gsMetaClient.getEntity(entityName);
        Assert.notNull(gdmEntity, "Gdm entity not found "+entityName);
        List<GenericGdmModel> gdmModels;
        if(!CollectionUtils.isEmpty(ids)) {
            gdmModels = gdmEntityService.selectByIds(gdmEntity, ids, selectList);
        } else {
            gdmModels = gdmEntityService.selectByParams(gdmEntity, selectList, params, offset, limit);
        }
        return gdmModels.stream()
                .map(GenericGdmModel::toGdmData)
                .collect(Collectors.toList());
    }

    @Nonnull
    @Override
    @PostMapping("{entityName}")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "创建GDM entity",
            content = @io.swagger.v3.oas.annotations.media.Content(
                    mediaType = "application/json",
                    examples = {@io.swagger.v3.oas.annotations.media.ExampleObject(
                            name = "Create GDM entity",
                            value = "{\n" +
                                    "    \"id\": 1368095019218512886,\n" +
                                    "    \"name\": \"张三\",\n" +
                                    "    \"birthday\": \"2000-01-01\"\n" +
                                    "}"
                    )
                    }
            )
    )
    public GdmData insert(@Nonnull @PathVariable String entityName, @Nonnull @RequestBody GdmData dto) {
        GdmEntity gdmEntity = gsMetaClient.getEntity(entityName);
        Assert.notNull(gdmEntity, "Gdm entity not found "+entityName);
        GenericGdmModel entity = GenericGdmModel.buildFromMap(dto, gdmEntity, GenericGdmModel.class);
        return gdmEntityService.insert(entity);
    }

    @Override
    @DeleteMapping("{entityName}/{id}")
    public GdmData deleteById(@Nonnull @PathVariable String entityName, @PathVariable Object id) {
        GdmEntity gdmEntity = gsMetaClient.getEntity(entityName);
        Assert.notNull(gdmEntity, "Gdm entity not found "+entityName);
        return gdmEntityService.deleteById(gdmEntity, id);
    }


    @Override
    @DeleteMapping("{entityName}?ids={ids}")
    public int deleteByIds(@Nonnull @PathVariable String entityName, @RequestParam List<Object> ids) {
        GdmEntity gdmEntity = gsMetaClient.getEntity(entityName);
        Assert.notNull(gdmEntity, "Gdm entity not found "+entityName);
        return gdmEntityService.deleteByIds(gdmEntity, ids);
    }

    @Override
    @PostMapping("{entityName}/{id}")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "更新GDM entity",
            content = @io.swagger.v3.oas.annotations.media.Content(
                    mediaType = "application/json",
                    examples = {@io.swagger.v3.oas.annotations.media.ExampleObject(
                            name = "Update GDM entity",
                            value = "{\n" +
                                    "    \"name\": \"李四\",\n" +
                                    "    \"birthday\": \"1999-01-01\"\n" +
                                    "}"
                    )
                    }
            )
    )
    public GdmData updateById(@Nonnull @PathVariable String entityName, @PathVariable Object id, @Nonnull @RequestBody GdmData dto) {
        GdmEntity gdmEntity = gsMetaClient.getEntity(entityName);
        Assert.notNull(gdmEntity, "Gdm entity not found "+entityName);
        GenericGdmModel entity = GenericGdmModel.buildFromMap(dto, gdmEntity, GenericGdmModel.class);
        entity.setPk(id);
        return gdmEntityService.updateById(entity);
    }
}
