package com.convertlab.foundation.gdmmeta.service;

import java.util.List;

import com.convertlab.foundation.library.gdmmeta.model.relationship.GdmRelationship;

import javax.annotation.Nullable;

public interface GdmRelationshipMergeService {

    List<GdmRelationship> getAllRelationships();

    List<GdmRelationship> getSystemEntityRelationships();

    List<GdmRelationship> getSystemCustomerEventRelationships();

    List<GdmRelationship> getSystemUdoEventRelationships();

    @Nullable
    GdmRelationship getRelationship(String leftEntityName, String relationshipName);

    List<GdmRelationship> getRelationshipByEntity(String entityName);

    void initGdmRelationshipStorage(boolean forceUpdate);

    void saveSnapshotMetaFiles();
}
