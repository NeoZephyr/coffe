package com.convertlab.foundation.misc.service;


import javax.annotation.Nonnull;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class MigrationRowSQL {

//    String keepInAccessControl;
//    String moveToResourceTable;
//    private static final String RESOURCE_CONTROL_ROW_VALUE_SQL_TEMPLATE = "uuid = %s, version = %s, tenant_id = %s, resource_code = %s, " +
//            "resource_type = %s, granted_subject_type = %s, granted_subject_code = %s, granted_permission = %s, granted_reason = %s, additional_info = %s, date_created = %s, last_updated = %s";
//    private static final String RESOURCE_TABLE_OWNER_ROW_VALUE_SQL_TEMPLATE = "update %s set owner_id = %s where %s = %s";
//    private static final String RESOURCE_TABLE_DEPT_ROW_VALUE_SQL_TEMPLATE = "update %s set dept_code = %s where %s = %s";
//
//
//    private MigrationRowSQL(String keepInAccessControl, String moveToResourceTable) {
//        this.keepInAccessControl = keepInAccessControl;
//        this.moveToResourceTable = moveToResourceTable;
//    }
//
//    @javax.annotation.Nullable
//    private static Table resourceTypeToResourceTable(Integer resourceType) {
//        return Table.fromResourceType(resourceType).orElse(null);
//    }
//
//    @javax.annotation.Nullable
//    private static String accessScopeToGrantedSubjectType(@Nonnull Integer accessScope) {
//        switch (accessScope) {
//            // all access scope, deprecated
//            case -1:
//                return null;
//
//            // high sea scope, deprecated
//            case 3:
//                return null;
//
//            case 0:
//                return "dept";
//
//            case 1:
//                return "group";
//
//            case 2:
//                return "user";
//
//            default:
//                return null;
//        }
//    }
//
//    @javax.annotation.Nullable
//    private static String accessSourceToGrantedReason(@Nonnull Integer accessSource) {
//        switch (accessSource) {
//            // create, migrate to share
//            case 0:
//                return "share";
//
//            case 1:
//                return "share";
//
//            case 10:
//                return "own";
//
//            // high sea, deprecated
//            case 11:
//                return null;
//
//            default:
//                return null;
//        }
//    }
//
//    @javax.annotation.Nullable
//    private static String accessLevelToGrantedPermission(@Nonnull Integer accessLevel) {
//        switch (accessLevel) {
//            case 0:
//                return "all";
//            case 1:
//                return "read";
//            case 2:
//                return "write";
//            default:
//                return null;
//        }
//    }
//
//    private static String eitherIdCodeToCode(@Nonnull Object resourceId, String resourceCode, @Nonnull Table resource) {
//        if (resource.getUniqueColumnType().isAssignableFrom(String.class)) {
//            return resourceCode;
//        } else {
//            // since there is only two types of identifier
//            return resourceId.toString();
//        }
//    }
//
//    private static String stripDeptPath(@NotNull String deptPath) {
//        String[] codes = StringUtils.split(deptPath, "-");
//        if (codes == null) {
//            return deptPath;
//        } else {
//            return codes[codes.length - 1];
//        }
//    }
//
//    private static @Nullable String stringify(@Nullable String str) {
//        if (StringUtils.hasText(str)) {
//            return "\"" + str + "\"";
//        } else {
//            return null;
//        }
//    }
//
//    private static @Nullable String stringify(@Nullable LocalDateTime dateTime) {
//        if (dateTime != null) {
//            return "DATE(" + "\"" + dateTime.atZone(ZoneId.of("UTC")).format(DateTimeFormatter.ISO_LOCAL_DATE_TIME).replace("T", " ") + "\")";
//        } else {
//            return null;
//        }
//    }
//
//    static public @Nullable MigrationRowSQL fromRow(@NotNull Map<String, Object> row) {
//        Table resourceTable = resourceTypeToResourceTable((Integer) row.get("resource_type"));
//        String grantedSubjectType = accessScopeToGrantedSubjectType((Integer) row.get("access_scope"));
//        String grantedReason = accessSourceToGrantedReason((Integer) row.get("access_source"));
//        String grantedPermission = accessLevelToGrantedPermission((Integer) row.get("access_level"));
//        if (resourceTable != null && grantedSubjectType != null && grantedReason != null && grantedPermission != null) {
//            Object id = Objects.isNull(row.get("resource_id")) ? row.get("resource_code") : row.get("resource_id");
//            String identifier = resourceTable.getUniqueColumn();
//            String tableName = resourceTable.getResourceTable();
//            if (grantedReason.equals("own") && !grantedSubjectType.equals("user_group")) {
//                String sql;
//                if (grantedSubjectType.equals("user")) {
//                    sql = String.format(RESOURCE_TABLE_OWNER_ROW_VALUE_SQL_TEMPLATE, tableName, stringify((String) row.get("access_code")), identifier, id);
//                } else if (grantedSubjectType.equals("dept")) {
//                    String deptPath = (String) row.get("access_code");
//                    String deptCode = stripDeptPath(deptPath);
//                    sql = String.format(RESOURCE_TABLE_DEPT_ROW_VALUE_SQL_TEMPLATE, tableName, stringify(deptCode), identifier, id);
//                } else {
//                    return null;
//                }
//                return new MigrationRowSQL(null, sql);
//            } else {
//                String sql = "( " + String.format(RESOURCE_CONTROL_ROW_VALUE_SQL_TEMPLATE,
//                        stringify(java.util.UUID.randomUUID().toString().replace("-", "")),
//                        row.get("version"),
//                        row.get("tenant_id"),
//                        stringify(eitherIdCodeToCode(row.get("resource_id"), (String) row.get("resource_code"), resourceTable)),
//                        stringify(resourceTable.getResourceTable()),
//                        stringify(grantedSubjectType),
//                        stringify((String) row.get("access_code")),
//                        stringify(grantedPermission),
//                        stringify(grantedReason),
//                        "null",
//                        stringify((LocalDateTime) row.get("date_created")),
//                        stringify((LocalDateTime) row.get("last_updated"))
//                ) + " )";
//                return new MigrationRowSQL(sql, null);
//            }
//        } else {
//            return null;
//        }
//    }

}
