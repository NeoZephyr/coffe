package com.convertlab.foundation.datapermission.controller.bff;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.convertlab.foundation.datapermission.mapper.ResourceMapper;
import com.convertlab.foundation.library.datapermission.ResourceAccessDto;
import com.convertlab.foundation.library.datapermission.model.DeptAttrSetting;
import com.convertlab.foundation.library.datapermission.model.GlobalAccessSetting;
import com.convertlab.foundation.library.datapermission.model.ResourceMeta;
import com.convertlab.foundation.library.jdbc.datasource.lookup.DataSourceLookupHelper;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.user.entity.Dept;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;


import com.convertlab.foundation.library.datapermission.model.HighSeasSetting;
import com.convertlab.foundation.datapermission.entity.ResourceEntity;
import com.convertlab.foundation.datapermission.model.ResourceShareRequestDto;
import com.convertlab.foundation.datapermission.entity.BaseResourceAccessEntity;
import com.convertlab.foundation.datapermission.model.*;
import com.convertlab.foundation.datapermission.service.ResourceAccessServiceWrapper;
import com.convertlab.foundation.library.datapermission.service.ResourceMetaService;
import com.convertlab.foundation.datapermission.service.ResourceService;
import com.convertlab.foundation.datapermission.service.SettingService;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.datapermission.GrantedPermission;
import com.convertlab.foundation.library.datapermission.GrantedReason;
import com.convertlab.foundation.library.datapermission.GrantedSubjectType;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.user.entity.UserGroupMap;
import com.convertlab.foundation.user.service.DeptService;
import com.convertlab.foundation.user.service.UserGroupService;
import com.convertlab.foundation.user.service.UserService;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

import com.convertlab.foundation.library.principal.context.PrincipalContextHolder;

@RestController
@Slf4j
public class ResourceController {

    final ResourceAccessServiceWrapper resourceAccessServiceWrapper;

    final ResourceMetaService resourceMetaService;

    final ResourceService resourceService;

    final UserService userService;

    final DeptService deptService;

    final SettingService settingService;

    final UserGroupService userGroupService;

    final ResourceMapper resourceMapper;

    public ResourceController(ResourceAccessServiceWrapper resourceAccessServiceWrapper, ResourceMetaService resourceMetaService, ResourceService resourceService, UserService userService, DeptService deptService, SettingService settingService, UserGroupService userGroupService, ResourceMapper resourceMapper) {
        this.resourceAccessServiceWrapper = resourceAccessServiceWrapper;
        this.resourceMetaService = resourceMetaService;
        this.resourceService = resourceService;
        this.userService = userService;
        this.deptService = deptService;
        this.settingService = settingService;
        this.userGroupService = userGroupService;
        this.resourceMapper = resourceMapper;
    }

    //在目前的逻辑中， hasOwn永远返回false, 意味着总是可以立刻删除用户，或者用户组，部门， 事后再对于归属于此用户或者部门的数据进行处理。
    @Nonnull
    @GetMapping("/dp/resource/hasOwn")
    public Map hasOwn(@RequestParam String grantedSubjectType, @RequestParam String grantedSubjectCode) {
        Map<String, Object> map = new HashMap<>();
        map.put("ownResource", false);
        return map;
    }


    /*
         分享资源接口, 分享资源采用override的模式，即新更新的分享会覆盖原来的分享。
         request :
         {
            "resourceType": "page",
            "resourceCode": "1cb7b96e79c2416fa50a533760322d99",
            "userIds": [22],
            "groupCodes": [],
            "deptCodes": ["B04c07"],
            "accessLevel": "all"
         }

         {
            "resourceType": "page",
            "resourceCode": "1cb7b96e79c2416fa50a533760322d99",
            "userIds": [1],
            "groupCodes": ["hWW8zeyc"],
            "deptCodes": ["B029b5"],
            "accessLevel": "read"
         }

         response :
         {"resourceCode":"1cb7b96e79c2416fa50a533760322d99","resourceType":"page"}
         目前share是只支持 content, 以及customer resource。 目前并不支持customer, udo的手工分享。
     */
    @Nullable
    @PostMapping("/dp/resource/share")
    public Map<String, Object> share(@Nonnull @RequestBody ResourceShareRequestDto dto) {

        //如果resourceType或者resourceCode为空，则返回错误信息。
        if (StringUtils.isBlank(dto.getResourceType()) || StringUtils.isBlank(dto.getResourceCode())) {
            throw new BusinessException(CommonErrors.MISSING_FIELD, "MSG_005_000001", "resourceType is empty or resourceCode is empty.", new String[]{});
        }

        //如果userIds, groupCodes, deptCodes都为空，则返回错误信息。
        if (CollectionUtils.isEmpty(dto.getUserIds()) && CollectionUtils.isEmpty(dto.getGroupCodes()) && CollectionUtils.isEmpty(dto.getDeptCodes())) {
            throw new BusinessException(CommonErrors.MISSING_FIELD, "MSG_005_000003", "userIds, groupCodes, deptCodes are all empty.", new String[]{});
        }

        //如果accessLevel不等于all, read 则返回错误信息。
        if (!"all".equals(dto.getAccessLevel()) && !"read".equals(dto.getAccessLevel())) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_005_000004", "accessLevel is not all or read.", new String[]{});
        }

        //获得ResourceType Metadata。
        ResourceMeta resourceMeta = resourceMetaService.getResourceMeta(dto.getResourceType());

        //如果resource meta为空， 返回错误信息。
        if (resourceMeta == null) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_005_000002", "resource type ${resourceType} not support", new String[]{dto.getResourceType()});
        }

        resourceService.internal_share(dto);

        //返回map对象，内容类似 {"resourceCode":"1cb7b96e79c2416fa50a533760322d99","resourceType":"page"}
        Map<String, Object> map = new HashMap<>();
        map.put("resourceCode", dto.getResourceCode());
        map.put("resourceType", dto.getResourceType());
        return map;
    }



    /**
     * request 1: 单个返回。
     * https://xxxx/resource/share?resourceType=page&resourceCode=473f5c9198b54e55a54a2d58f871c930
     * <p>
     * response:
     * {
     * "shareToAllDept": false,
     * "shareToAllUserGroup": false,
     * "shareToAllUser": false,
     * "highSeas": false,
     * "users": [
     * {
     * "id": 14,
     * "name": "gavin",
     * "loginName": "xiaoshu",
     * "source": "manual_share",
     * "level": "all"
     * },
     * {
     * "id": 44,
     * "name": "zj",
     * "loginName": "user1656407724653",
     * "source": "owner",
     * "level": "all"
     * }
     * ],
     * "userGroups": [
     * {
     * "id": 14,
     * "name": "测试用户组",
     * "code": "qNjcRwNc",
     * "source": "manual_share",
     * "level": "all"
     * }
     * ],
     * "depts": [
     * {
     * "code": "A00001",
     * "name": "总部",
     * "source": "owner",
     * "level": "all"
     * },
     * {
     * "code": "B14f0d",
     * "name": "AutoDeptwUFE",
     * "source": "manual_share",
     * "level": "all"
     * }
     * ]
     * }
     *
     *
     * request2 : 批量返回。
     * https://master-app.dmhub.cn/resource/share?resourceType=page&resourceCode=["8a1d8b32c3124a9fbd298ed7755e0b64","426b7af94328433ca02682eede888d37"]
     * response :
     * [
     *     {
     *         "shareToAllDept": false,
     *         "shareToAllUserGroup": false,
     *         "shareToAllUser": false,
     *         "highSeas": false,
     *         "users": [
     *             {
     *                 "id": 14,
     *                 "name": "gavin",
     *                 "loginName": "xiaoshu",
     *                 "source": "owner",
     *                 "level": "all"
     *             },
     *             {
     *                 "id": 1127,
     *                 "name": "bodi",
     *                 "loginName": "user1127",
     *                 "source": "manual_share",
     *                 "level": "all"
     *             }
     *         ],
     *         "userGroups": [],
     *         "depts": [
     *             {
     *                 "code": "A00001",
     *                 "name": "总部",
     *                 "source": "owner",
     *                 "level": "all"
     *             }
     *         ]
     *     },
     *     {
     *         "shareToAllDept": false,
     *         "shareToAllUserGroup": false,
     *         "shareToAllUser": false,
     *         "highSeas": false,
     *         "users": [
     *             {
     *                 "id": 177,
     *                 "name": "张珊珊",
     *                 "loginName": "cashew",
     *                 "source": "owner",
     *                 "level": "all"
     *             },
     *             {
     *                 "id": 1127,
     *                 "name": "bodi",
     *                 "loginName": "user1127",
     *                 "source": "manual_share",
     *                 "level": "all"
     *             }
     *         ],
     *         "userGroups": [],
     *         "depts": [
     *             {
     *                 "code": "A00001",
     *                 "name": "总部",
     *                 "source": "owner",
     *                 "level": "all"
     *             }
     *         ]
     *     }
     * ]
     */
    @GetMapping("/dp/resource/listShare")
    public Object listShare(@RequestParam String resourceType, @RequestParam String resourceCode) {

        //如果resourceType或者resourceCode为空，则返回错误信息。
        if (StringUtils.isBlank(resourceType) || StringUtils.isBlank(resourceCode)) {
            throw new BusinessException(CommonErrors.MISSING_FIELD, "MSG_005_000001", "resourceType is empty or resourceCode is empty.", new String[]{});
        }

        //根据resourceType获取metadata
        ResourceMeta resourceMeta = resourceMetaService.getResourceMeta(resourceType);

        //如果resource meta为空， 返回错误信息。
        if (resourceMeta == null) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_005_000002", "resource type ${resourceType} not support", new String[]{resourceType});
        }

        if(isList(resourceCode)){
            List<ResourceListShareResponseDto> responseDTO = new ArrayList<>();
            ObjectMapper mapper = new ObjectMapper();

            try {
                // TODO should never save code as number, now front-end actually saves entity's id as number
                ArrayList list = mapper.readValue(resourceCode, ArrayList.class);
                list.forEach(code -> {

                    try {
                        ResourceListShareResponseDto elementDTO = internal_listShareSingle(resourceType, code.toString(), resourceMeta);
                        responseDTO.add(elementDTO);
                    }catch (BusinessException e){
                        log.error("process resource code {} failed.", code.toString(), e);
                    }

                });

            } catch (IOException e) {
                throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_005_000010", "parse resource code ${resourceCode} failed.", new String[]{resourceCode});
            }

            return responseDTO;
        }else{

            ResourceListShareResponseDto responseDTO = internal_listShareSingle(resourceType, resourceCode, resourceMeta);

            return responseDTO;
        }

    }

    private Dept getDeptByOutCode(String outCode) {
        final Dept[] dept = {null};

        DataSourceLookupHelper.withLookupKey("main", () -> {
            dept[0] = deptService.getDeptByOutCode(outCode);
        });

        return dept[0];
    }


    @NotNull
    private ResourceListShareResponseDto internal_listShareSingle(String resourceType, String resourceCode, ResourceMeta resourceMeta) {
        ResourceListShareResponseDto dto = new ResourceListShareResponseDto();

        DeptAttrSetting deptAttrSetting = settingService.getDeptAttr(resourceType);
        if(deptAttrSetting != null && !StringUtils.isBlank(deptAttrSetting.getColumn())){
            //如果设置了外部属性，则查询外部属性column的值, 作为deptCode, 以及owner
            Map<String, Object> values = resourceMapper.getEntity(resourceMeta.getEntityName(), resourceMeta.getIdColumn(), deptAttrSetting.getColumn(), resourceCode);
            if(CollectionUtils.isEmpty(values)){
                throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_005_000005", "resource type: " +resourceType +" code: "+resourceCode + " does not exist", new String[]{resourceType, resourceCode});
            }
            //基于assumption, 只有客户和udo有外部组织属性，单独写一个mapper来读取数据。
            String deptAttr = ObjectUtils.toString(values.get( deptAttrSetting.getColumn()), StringUtils.EMPTY);
            if(StringUtils.isBlank(deptAttr)){
                //意味是公海数据。
                dto.setHighSeas(true);
            }else{
                //意味是outerDeptCode对应的数据。
                Dept dept = getDeptByOutCode(deptAttr);
                if(dept != null){
                    Map<String, Object> deptDto = new HashMap<String, Object>();
                    deptDto.put("code", dept.getCode());
                    deptDto.put("outCode", dept.getOutCode());
                    deptDto.put("source", "owner");
                    deptDto.put("level", "all");
                    dto.getDepts().add(deptDto);
                }
            }
        }else{
            //如果没有设置外部属性，则查询ownerId, 作为owner
            //找到数据
            ResourceEntity entity = resourceService.findEntity(resourceMeta, resourceCode);

            //如果entity 为空， 返回错误信息
            if (entity == null) {
                throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_005_000005", "resource ${resourceType}, ${resourceCode} not exist", new String[]{resourceType, resourceCode});
            }

            //put owner data
            if(entity.getOwnerId() != null){
                Map<String, Object> owner = new HashMap<String, Object>();
                owner.put("id", entity.getOwnerId());
                owner.put("source", "owner");
                owner.put("level", "all");
                dto.getUsers().add(owner);
            } else {
                // OwnerId is null -> High sea data
                dto.setHighSeas(true);
            }

            if(entity.getDeptCode() != null){
                Map<String, Object> dept = new HashMap<String, Object>();
                dept.put("code", entity.getDeptCode());
                dept.put("source", "owner");
                dept.put("level", "all");
                dto.getDepts().add(dept);
            }
        }


        //put shared data
        List<BaseResourceAccessEntity> sharedData = resourceAccessServiceWrapper.list(resourceType, resourceCode);
        if(sharedData != null){
            //轮询SharedData
            for (BaseResourceAccessEntity sharedDatum : sharedData) {

                //如果是部门
                if (sharedDatum.getGrantedSubjectType() == GrantedSubjectType.SUBJECT_TYPE_DEPT) {
                    Map<String, Object> deptMap = new HashMap<String, Object>();
                    deptMap.put("code", sharedDatum.getGrantedSubjectCode());
                    deptMap.put("source", sharedDatum.getGrantedReason());
                    deptMap.put("level", sharedDatum.getGrantedPermission());
                    dto.getDepts().add(deptMap);
                }

                //如果是用户组
                else if (sharedDatum.getGrantedSubjectType() == GrantedSubjectType.SUBJECT_TYPE_GROUP) {
                    Map<String, Object> userGroupMap = new HashMap<String, Object>();
                    userGroupMap.put("code", sharedDatum.getGrantedSubjectCode());
                    userGroupMap.put("source", sharedDatum.getGrantedReason());
                    userGroupMap.put("level", sharedDatum.getGrantedPermission());
                    dto.getUserGroups().add(userGroupMap);
                }

                //如果是用户
                else if (sharedDatum.getGrantedSubjectType() == GrantedSubjectType.SUBJECT_TYPE_USER) {
                    Map<String, Object> userMap = new HashMap<String, Object>();
                    userMap.put("id", NumberUtils.createLong(sharedDatum.getGrantedSubjectCode()));
                    userMap.put("source", sharedDatum.getGrantedReason());
                    userMap.put("level", sharedDatum.getGrantedPermission());
                    dto.getUsers().add(userMap);
                }

            }
        }

        resourceService.fillAccessorDetail(dto);
        return dto;
    }

    /**
     * request :
     * {
         "resourceCodes": ["1cb7b96e79c2416fa50a533760322d99"],
         "resourceType": "page"
     * }
     *
     * response :
     * ["1cb7b96e79c2416fa50a533760322d99"]
     *
     *
     *  逻辑 ：
     *  1.如果是管理员，可以分享。
     *  2.如果是总部的用户，可以分享。
     *  3.如果是非总部的用户，只能分享自己和自己部门的资源。
     *      3.1 如果资源属于当前组织及其下级组织则可见进行分享。
     *      3.2 如果ownerId属于当前用户，则可以分享。
     *  4.对于公海数据，如果指定部门，则该部门人员可以分享。
     *  5.对于用户组数据，都不能作为分享的依据。
     *
     */
    @PostMapping("/dp/resource/getOwnerResourceCode")
    public List<String> getOwnerResourceCode(@Nonnull @RequestBody GetOwnerResourceCodeRequestDto dto) {

        //如果resourceType或者resourceCode为空，则返回错误信息。
        if (StringUtils.isBlank(dto.getResourceType()) || dto.getResourceCodes() == null || dto.getResourceCodes().isEmpty()) {
            throw new BusinessException(CommonErrors.MISSING_FIELD, "MSG_005_000001", "resourceType is empty or resourceCode is empty.", new String[]{});
        }

        //根据resourceType获取metadata
        ResourceMeta resourceMeta = resourceMetaService.getResourceMeta(dto.getResourceType());

        //如果resource meta为空， 返回错误信息。
        if (resourceMeta == null) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_005_000002", "resource type ${resourceType} not support", new String[]{dto.getResourceType()});
        }

        return getShareableResourceCodes(resourceMeta, dto.getResourceCodes());
    }

    @NotNull
    private List<String> getShareableResourceCodes(ResourceMeta resourceMeta, List<String> resourceCodes) {
        //1.如果是管理员，可以分享。
        Long userId = PrincipalContextHolder.getUserId();
        if(userId == null){
            //如果userId为空，返回错误信息。
            throw new BusinessException(CommonErrors.MISSING_FIELD, "MSG_005_000007", "userId is empty.", new String[]{});
        }

        boolean isAdminUser = userService.isAdmin(userId);

        //2.如果是总部，可以分享。
        String deptCode = PrincipalContextHolder.getDeptCode();
        if(deptCode == null){
            //如果deptCode为空，返回错误信息。
            throw new BusinessException(CommonErrors.MISSING_FIELD, "MSG_005_000008", "deptCode is empty.", new String[]{});
        }
        boolean isHeadquarter = deptService.isHeadquarter(deptCode);

        if(isAdminUser || isHeadquarter){
            return resourceCodes;
        }

        //构建返回结果
        List<String> results = new ArrayList<>();

        //获得资源列表
        List<ResourceEntity> entities = resourceService.findEntities(resourceMeta, resourceCodes);
        if(entities.isEmpty()){
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_005_000005", "resource ${resourceType}, ${resourceCode} not exist", new String[]{resourceMeta.getResourceType(), resourceCodes.toString()});
        }

        //获得当前部门及其子部门的deptCode
        List<String> childDeptCodes = deptService.listChildDeptCode(deptCode);

        entities.forEach(
                entity -> {
                    //3.如果是非总部的用户，只能分享自己和自己部门的资源。

                    //如果ownerId 等于 userId, 则具备权限
                    if(entity.getOwnerId() != null && entity.getOwnerId().equals(userId)){
                        results.add(entity.getResourceCode());
                        return;
                    }

                    //如果deptCode,以及deptCode的子部门等于entity的deptCode,则具备权限。
                    if( entity.getDeptCode() != null && childDeptCodes.contains(entity.getDeptCode())){
                        results.add(entity.getResourceCode());
                        return;
                    }

                    //4.对于公海数据，如果指定部门，则该部门人员可以分享。
                    if(entity.getOwnerId() == null && entity.getDeptCode() == null) {
                        List<HighSeasSetting> highSeaSettings = settingService.getHighSeaSettings();
                        if(highSeaSettings.size() == 1 && highSeaSettings.get(0).isPublic()){
                            //public意味所有人可见，因此无owner归属和分享的必要
                        }else{
                            //private意味着high seas setting中的部门，存在于childDeptCodes中，则具备权限。
                            highSeaSettings.forEach(
                                    highSea -> {
                                        if(HighSeasSetting.DEPT_ACCESS_SCOPE.equals(highSea.getGrantedSubjectType())
                                                && childDeptCodes.contains(highSea.getGrantedSubjectCode())){
                                            results.add(entity.getResourceCode());
                                        }
                                    });
                        }
                    }
                }
        );

        return results;
    }

    @NotNull
    private List<String> getPublicResourceCodes(ResourceMeta resourceMeta, List<String> resourceCodes) {
        //构建返回结果
        List<String> results = new ArrayList<>();

        //获得资源列表
        List<ResourceEntity> entities = resourceService.findEntities(resourceMeta, resourceCodes);

        if(entities.isEmpty()){
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_005_000005", "resource ${resourceType}, ${resourceCode} not exist", new String[]{resourceMeta.getResourceType(), resourceCodes.toString()});
        }

        List<HighSeasSetting> highSeaSettings = settingService.getHighSeaSettings();

        // 是公海数据且公海数据所有人都可以看
        if (highSeaSettings.size() == 1 && highSeaSettings.get(0).isPublic()) {

            entities.forEach(
                    entity -> {
                        if(entity.getOwnerId() == null && entity.getDeptCode() == null) {
                            results.add(entity.getResourceCode());
                        }
                    }
            );
        }

        return results;
    }

    /*
       request :
       {
          "resourceType": "mktcmp",
          "resourceCode": "affe8c8******************4959aff",
          "accessScope": "dept",
          "accessCode": "A00001-B89b1e"
        }

        response :
        {
          "status": "success"
        }
     */
    @PostMapping("/dp/resource/deleteShare")
    public Map<String, String> deleteShare(@RequestBody DeleteShareRequestDto dto) {

        return resourceService.deleteShareInternal(dto);
    }


    /*
         *  0.如果资源开启的是所有人可见，则所有人都可以编辑。
             //对于可以分享数据的人，都可以编辑
             *  1.如果是管理员，可以编辑。
             *  2.如果是总部的用户，可以编辑。
             *  3.如果是非总部的用户，只能编辑自己和自己部门的资源。
             *      3.1 如果资源属于当前组织及其下级组织则可见进行编辑。
             *      3.2 如果ownerId属于当前用户，则可以编辑。
             *  4.对于公海数据，如果指定部门，则该部门人员可以编辑。
             //
         *  5.对于分享给用户的数据，如果分享的是all权限，则可以编辑，如果分享的是read权限，则只能读取，不能编辑。
            6.如果资源开启的是所有人只读可见，则剩余的数据都设置为read
            7.如果资源开启的是private，而剩下的数据都没有命中任何权限，则返回none权限。
         *

        request :
        [
            {
                "resourceType": "media_resource",
                "resourceCode": 7102
            },
            {
                "resourceType": "media_resource",
                "resourceCode": 7052
            }
        ]

        response :
        {
            "media_resource": {
                "7102": "all",
                "7052": "all"
            }
        }
     */
    @PostMapping("/dp/resource/access")
    public Map<String, Map> access(@RequestBody List<Map<String, String>> resourceMapList){

        //根据resourceMapList生成type2codeList Map
        Map<String, List<String>> type2codeList = getResourceType2CodeList(resourceMapList);
        Map<String, Map> result = new HashMap<String, Map>();

        //轮询type2codeList，根据每种resource type，进行访问检查。
        for (Map.Entry<String, List<String>> entry : type2codeList.entrySet()) {
            //获取resource type和resource code list
            String type = entry.getKey();
            List<String> codeList = entry.getValue();

            //获取resource meta
            ResourceMeta resourceMeta = getResourceMeta(type);
            //校验meta是否存在
            validateResourceMeta(resourceMeta, type);
            //获取该resource type的数据权限相关设定，是public，还是public-readonly, 还是private
            GlobalAccessSetting dto = settingService.getGlobalAccessSetting(type);
            if(dto == null || isAdminOrHeadquarter(PrincipalContextHolder.getUserId(), PrincipalContextHolder.getDeptCode())){
                result.put(
                        type,
                        codeList.stream()
                                .collect(Collectors.toMap(e -> e, e -> GrantedPermission.ALL_ACCESS_LEVEL.getName()))
                );
                continue;
            }
            //首先从数据库中校验resource type + resource code是否存在。
            List<ResourceEntity> entities = resourceService.findEntities(resourceMeta, codeList);
            //处理entities，返回结果。

            Map<String, String> accessResults = new HashMap<>();
            result.put(type, accessResults);

            if(entities != null && !entities.isEmpty()){
                accessResults.putAll(handleEntities(entities, codeList, dto, resourceMeta));
            }

            //处理fixed dashboard的特殊逻辑
            if("dashboard".equals(type)){
                List<String> fixedDashboardCodes = getFixedDashboardCodes();
                //轮询codeList
                for (String code : codeList) {
                    if(fixedDashboardCodes.contains(code)){
                        //如果code属于fixedDashboardCode, 则设置为'none'
                        accessResults.put(code, "none");
                    }
                }
            }
        }

        return result;
    }

    private List<String> getFixedDashboardCodes(){
        List<String> fixedCodes = new ArrayList<>();
        fixedCodes.add("40612280101");
        fixedCodes.add("40612280102");
        fixedCodes.add("4061228020101");
        fixedCodes.add("4061228020102");
        return fixedCodes;
    }

    private boolean isAdminOrHeadquarter(Long userId, String deptCode){
        boolean isAdminUser = userService.isAdmin(userId);
        boolean isHeadquarter = deptService.isHeadquarter(deptCode);
        return isAdminUser || isHeadquarter;
    }

    @Nonnull
    private Map<String, String> handleEntities(List<ResourceEntity> entities, List<String> codeList, @Nonnull GlobalAccessSetting dto, ResourceMeta resourceMeta){
        Map<String, String> typeResults = new HashMap<>();

        //0. 如果资源开启的是所有人可见，则所有人都可以编辑。
        if (ResourceSettingDto.permission_public.equals(dto.getAccessPermission())){
            entities.forEach(entity -> typeResults.put(entity.getResourceCode(), GrantedPermission.ALL_ACCESS_LEVEL.getName()));
            return typeResults;
        }

        //1. 如果资源可被分享，则资源也可以被编辑。
        List<String> shareableResourceCodes = getShareableResourceCodes(resourceMeta, codeList);
        List<String> publicResourceCodes = getPublicResourceCodes(resourceMeta, codeList);

        //2.获得分享数据
        Map<GrantedSubjectType, List<String>> queryParameters = getQueryParameters();
        Map<String, String> accessLevels = getAccessLevels(resourceMeta.getResourceType(), queryParameters);

        entities.forEach(entity -> {
            String resourceCode = entity.getResourceCode();
            if(shareableResourceCodes.contains(resourceCode)){
                //具备数据分享权限的人，均可以编辑数据。
                typeResults.put(resourceCode, GrantedPermission.ALL_ACCESS_LEVEL.getName());
            } else if (publicResourceCodes.contains(resourceCode)) {
                // 公海数据给所有人看
                typeResults.put(resourceCode, GrantedPermission.ALL_ACCESS_LEVEL.getName());
            } else {
                //被分享数据的人，根据分享的权限，和默认的权限，进行判断。
                String level = accessLevels.getOrDefault(resourceCode, getDefaultLevel(dto));
                typeResults.put(resourceCode, level);
            }
        });

        return typeResults;
    }

    private String getDefaultLevel(@Nonnull GlobalAccessSetting dto){
        return GlobalAccessSetting.PUBLIC_READONLY_PERMISSION.equals(dto.getAccessPermission()) ? GrantedPermission.READ_ACCESS_LEVEL.getName() : GrantedPermission.NONE_ACCESS_LEVEL.getName();
    }

    @Nonnull
    private Map<GrantedSubjectType, List<String>> getQueryParameters(){
        Long userId = PrincipalContextHolder.getUserId();
        List<String> deptCodeList = deptService.listChildDeptCode(PrincipalContextHolder.getDeptCode());
        List<String> userGroupCodeList = userGroupService.getUserGroupMapByUserId(userId).stream()
                .map(UserGroupMap::getGroupCode)
                .collect(Collectors.toList());

        Map<GrantedSubjectType, List<String>> queryParameters = new HashMap<>();
        if(!deptCodeList.isEmpty()){
            queryParameters.put(GrantedSubjectType.SUBJECT_TYPE_DEPT, deptCodeList);
        }

        if(!userGroupCodeList.isEmpty()){
            queryParameters.put(GrantedSubjectType.SUBJECT_TYPE_GROUP, userGroupCodeList);
        }

        if(userId != null){
            queryParameters.put(GrantedSubjectType.SUBJECT_TYPE_USER, Arrays.asList(String.valueOf(userId)));
        }

        return queryParameters;
    }

    @Nonnull
    private Map<String, String> getAccessLevels(String type, Map<GrantedSubjectType, List<String>> queryParameters){
        Map<String, String> accessLevels = new HashMap<>();
        List<String> fullAccessList = new ArrayList<>();
        resourceAccessServiceWrapper.list(type, queryParameters).forEach(
                access -> {
                    if(GrantedPermission.ALL_ACCESS_LEVEL.equals(access.getGrantedPermission())){
                        accessLevels.put(access.getResourceCode(), GrantedPermission.ALL_ACCESS_LEVEL.getName());
                        fullAccessList.add(access.getResourceCode());
                    }else if(GrantedPermission.READ_ACCESS_LEVEL.equals(access.getGrantedPermission())) {
                        //all access 优先级高于 READ_ACCESS_LEVEL， 如果已经被赋予all access, 则取高的权限。
                        if(!fullAccessList.contains(access.getResourceCode())){
                            accessLevels.put(access.getResourceCode(), GrantedPermission.READ_ACCESS_LEVEL.getName());
                        }
                    }
                }
        );
        return accessLevels;
    }

    private ResourceMeta getResourceMeta(String type){
        ResourceMeta resourceMeta = resourceMetaService.getResourceMeta(type);
        return resourceMeta;
    }

    private void validateResourceMeta(ResourceMeta resourceMeta, String type){
        if (resourceMeta == null) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_005_000002", "resource type ${resourceType} not support.", new String[]{type});
        }
    }

    private Map<String, List<String>> getResourceType2CodeList(@Nonnull List<Map<String, String>> resourceMapList){
        return resourceMapList.stream()
                .collect(Collectors.groupingBy(
                        map -> map.get("resourceType"),
                        Collectors.mapping(
                                map -> map.get("resourceCode"),
                                Collectors.toList()
                        )
                ));
    }

    /**
     * request :
     * {
     * 	"resourceType": "page",
     * 	"resourceCodes": ["426b7af94328433ca02682eede888d37", "22af2e54caf6404cb43afb016dedf8d1"],
     * 	"userIds": [1],
     * 	"groupCodes": ["mmYtw3Jb"],
     * 	"deptCodes": ["B13c55"],
     * 	"accessLevel": "read"
     * }
     *
     * response :
     * {
     *     "resourceCodes": [
     *         "426b7af94328433ca02682eede888d37",
     *         "22af2e54caf6404cb43afb016dedf8d1"
     *     ],
     *     "resourceType": "page"
     * }
     *
     */
    @PostMapping("/dp/resource/batchShare")
    public ResourceBatchShareResponseDto batchShare(@RequestBody ResourceBatchShareRequestDto dto){

        //如果resourceType或者resourceCode为空，则返回错误信息。
        if (StringUtils.isBlank(dto.getResourceType()) || CollectionUtils.isEmpty(dto.getResourceCodes())) {
            throw new BusinessException(CommonErrors.MISSING_FIELD, "MSG_005_000001", "resourceType is empty or resourceCode is empty.", new String[]{});
        }

        //如果userIds, groupCodes, deptCodes都为空，则返回错误信息。
        if (CollectionUtils.isEmpty(dto.getUserIds()) && CollectionUtils.isEmpty(dto.getGroupCodes()) && CollectionUtils.isEmpty(dto.getDeptCodes())) {
            throw new BusinessException(CommonErrors.MISSING_FIELD, "MSG_005_000003", "userIds, groupCodes, deptCodes are all empty.", new String[]{});
        }

        //如果accessLevel不等于all, read 则返回错误信息。
        if (!"all".equals(dto.getAccessLevel()) && !"read".equals(dto.getAccessLevel())) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_005_000004", "accessLevel is not all or read.", new String[]{});
        }

        //获得ResourceType Metadata。
        ResourceMeta resourceMeta = resourceMetaService.getResourceMeta(dto.getResourceType());

        //如果resource meta为空， 返回错误信息。
        if (resourceMeta == null) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_005_000002", "resource type ${resourceType} not support", new String[]{dto.getResourceType()});
        }

        //调用internal_share，服务分享的逻辑。
        List<ResourceShareRequestDto> resourceShareRequestDtos = dto.convertToResourceShareRequestDTO();
        resourceShareRequestDtos.forEach(resourceShareRequestDto -> {
                resourceService.internal_share(resourceShareRequestDto);
        });

        //return response
        ResourceBatchShareResponseDto responseDTO = new ResourceBatchShareResponseDto();
        responseDTO.setResourceType(dto.getResourceType());
        responseDTO.setResourceCodes(dto.getResourceCodes());
        return responseDTO;
    }


    /**
     * 根据资源类型，资源唯一ids 删除所有共享数据
     * request :
     * {
     * 	"resourceType": "page",
     * 	"resourceCodes": ["8a1d8b32c3124a9fbd298ed7755e0b64", "426b7af94328433ca02682eede888d37"]
     * }
     *
     * response :
     * {
     *  "status":"success"
     * }
     */
    @PostMapping("/dp/resource/batchDeleteShare")
    public ResourceBatchDeleteShareResponseDto batchDeleteShare(@Nonnull @RequestBody ResourceBatchDeleteShareRequestDto dto){
        //如果resourceType或者resourceCode为空，则返回错误信息。
        if (StringUtils.isBlank(dto.getResourceType()) || CollectionUtils.isEmpty(dto.getResourceCodes())) {
            throw new BusinessException(CommonErrors.MISSING_FIELD, "MSG_005_000001", "resourceType is empty or resourceCode is empty.", new String[]{});
        }

        //获得ResourceType Metadata。
        ResourceMeta resourceMeta = resourceMetaService.getResourceMeta(dto.getResourceType());

        //获得所有的分享权限。
        List<BaseResourceAccessEntity> entities = resourceAccessServiceWrapper.list(dto.getResourceType(), dto.getResourceCodes());

        //找到所有manual share的部分，放到一个子集合。
        List<BaseResourceAccessEntity> manualShareEntities = entities.stream().filter(entity -> GrantedReason.GRANTED_REASON_MANUAL_SHARE.equals(entity.getGrantedReason())).collect(Collectors.toList());

        //批量删除所有的manual share的部分。
        resourceAccessServiceWrapper.batchDelete(dto.getResourceType(), manualShareEntities);

        ResourceBatchDeleteShareResponseDto responseDTO = new ResourceBatchDeleteShareResponseDto();
        responseDTO.setStatus(ResourceBatchDeleteShareResponseDto.STATUS_SUCCESS);
        return responseDTO;
    }


    /**
     * request :
         * {"resourceType":"tags","resourceCode":"Auto静态值标签_文本虑撬紊噶"}
     *
     * response :
     * {
     *     "shareToAllDept": false,
     *     "shareToAllUserGroup": false,
     *     "shareToAllUser": false,
     *     "highSeas": false,
     *     "users": [
     *         {
     *             "id": 214,
     *             "name": "auto",
     *             "loginName": "auto",
     *             "source": "owner",
     *             "level": "all"
     *         }
     *     ],
     *     "userGroups": [],
     *     "depts": [
     *         {
     *             "code": "A00001",
     *             "name": "总部",
     *             "source": "owner",
     *             "level": "all"
     *         }
     *     ]
     * }
     *
     */
    //singleShare
    @PostMapping("/dp/resource/listSingleShare")
    public ResourceListShareResponseDto listSingleShare(@Nonnull @RequestBody ResourceListShareRequestDto dto){

        //如果resourceType或者resourceCode为空，则返回错误信息。
        if (StringUtils.isBlank(dto.getResourceType()) || StringUtils.isBlank(dto.getResourceCode())) {
            throw new BusinessException(CommonErrors.MISSING_FIELD, "MSG_005_000001", "resourceType is empty or resourceCode is empty.", new String[]{});
        }

        //根据resourceType获取metadata
        ResourceMeta resourceMeta = resourceMetaService.getResourceMeta(dto.getResourceType());

        //如果resource meta为空， 返回错误信息。
        if (resourceMeta == null) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_005_000002", "resource type ${resourceType} not support", new String[]{dto.getResourceType()});
        }

        ResourceListShareResponseDto responseDTO = internal_listShareSingle(dto.getResourceType(), dto.getResourceCode(), resourceMeta);

        return responseDTO;
    }


    /**
     * request :
     * {
     *      "resourceType":"tags",
     *      "resourceCode":
     *          [
     *          "Auto静态值标签_文本虑撬紊噶",
     *          "Auto静态值标签_文本镰柬梦蠕"
     *          ]
     *}
     *
     * response :
     * [
     *     {
     *         "shareToAllDept": false,
     *         "shareToAllUserGroup": false,
     *         "shareToAllUser": false,
     *         "highSeas": false,
     *         "users": [
     *             {
     *                 "id": 214,
     *                 "name": "auto",
     *                 "loginName": "auto",
     *                 "source": "owner",
     *                 "level": "all"
     *             }
     *         ],
     *         "userGroups": [],
     *         "depts": [
     *             {
     *                 "code": "A00001",
     *                 "name": "总部",
     *                 "source": "owner",
     *                 "level": "all"
     *             }
     *         ]
     *     },
     *     {
     *         "shareToAllDept": false,
     *         "shareToAllUserGroup": false,
     *         "shareToAllUser": false,
     *         "highSeas": false,
     *         "users": [
     *             {
     *                 "id": 214,
     *                 "name": "auto",
     *                 "loginName": "auto",
     *                 "source": "owner",
     *                 "level": "all"
     *             }
     *         ],
     *         "userGroups": [],
     *         "depts": [
     *             {
     *                 "code": "A00001",
     *                 "name": "总部",
     *                 "source": "owner",
     *                 "level": "all"
     *             }
     *         ]
     *     }
     * ]
     */
    //listShareBatch
    @PostMapping("/dp/resource/listBatchShare")
    public List<ResourceListShareResponseDto> listBatchShare(@Nonnull @RequestBody ResourceBatchListShareRequestDto dto) {
        //如果resourceType或者resourceCode为空，则返回错误信息。
        if (StringUtils.isBlank(dto.getResourceType()) || CollectionUtils.isEmpty(dto.getResourceCode())) {
            throw new BusinessException(CommonErrors.MISSING_FIELD, "MSG_005_000001", "resourceType is empty or resourceCode is empty."
                    , new String[]{dto.getResourceType(), dto.getResourceCode().toString(), JsonUtils.instanceOfDto().obj2Json(dto)});
        }

        //获得ResourceType Metadata。
        ResourceMeta resourceMeta = resourceMetaService.getResourceMeta(dto.getResourceType());
        //如果resource meta为空， 返回错误信息。
        if (resourceMeta == null) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, "MSG_005_000002", "resource type ${resourceType} not support", new String[]{dto.getResourceType()});
        }


        List<ResourceListShareResponseDto> responseDTO = new ArrayList<>();

        dto.getResourceCode().forEach(resourceCode -> {
            //找到数据
            try {
                ResourceListShareResponseDto elementDTO = this.internal_listShareSingle(dto.getResourceType(), resourceCode, resourceMeta);
                responseDTO.add(elementDTO);
            }catch (BusinessException e){
                log.error("process resource code {} failed.", resourceCode, e);
            }

        });

        return responseDTO;
    }


    @Contract(pure = true)
    private boolean isList(@Nonnull String resourceCode) {
        if(resourceCode.startsWith("[")) {
            return true;
        }
        return false;
    }

    @PostMapping("/dp/test_transaction")
    public void testTransaction(){
        //调用maindb的service
        deptService.getDeptByCode("A00001");
        //调用sudb的service
        ResourceAccessDto dto = new ResourceAccessDto();
        dto.setResourceType("tags");
        dto.setResourceCode("123");
        dto.setGrantedSubjectType(GrantedSubjectType.SUBJECT_TYPE_DEPT);
        dto.setGrantedSubjectCode("A00001");
        dto.setGrantedPermission(GrantedPermission.ALL_ACCESS_LEVEL);
        resourceAccessServiceWrapper.save(dto);
    }

}