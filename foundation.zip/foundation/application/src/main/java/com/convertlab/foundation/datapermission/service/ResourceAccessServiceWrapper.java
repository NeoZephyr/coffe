package com.convertlab.foundation.datapermission.service;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.convertlab.foundation.datapermission.entity.BaseResourceAccessEntity;
import com.convertlab.foundation.library.datapermission.model.BatchResourceAccessDto;
import com.convertlab.foundation.library.datapermission.ResourceAccessDto;
import com.convertlab.foundation.library.datapermission.model.ResourceMeta;
import com.convertlab.foundation.datapermission.util.ResourceAccessDtoConverter;
import com.convertlab.foundation.library.constant.DataProcessingMode;
import com.convertlab.foundation.library.datapermission.GrantedSubjectType;
import com.convertlab.foundation.library.datapermission.service.ResourceMetaService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@Transactional(propagation = Propagation.NOT_SUPPORTED)
public class ResourceAccessServiceWrapper {

    private final ResourceAccessOLTPService resourceAccessOLTPService;
    private final ResourceAccessOLTPMainDBService resourceAccessOLTPMainDBService;
    private final ResourceAccessOLAPService resourceAccessOLAPService;
    private final ResourceMetaService metaService;

    public ResourceAccessServiceWrapper(ResourceAccessOLTPService resourceAccessOLTPService, ResourceAccessOLTPMainDBService resourceAccessOLTPMainDBService, ResourceAccessOLAPService resourceAccessOLAPService, ResourceMetaService metaService) {
        this.resourceAccessOLTPService = resourceAccessOLTPService;
        this.resourceAccessOLTPMainDBService = resourceAccessOLTPMainDBService;
        this.resourceAccessOLAPService = resourceAccessOLAPService;
        this.metaService = metaService;
    }

    @Nullable
    public BaseResourceAccessEntity save(@Nonnull ResourceAccessDto dto) {
        ServiceAndTable serviceAndTable = getService(dto.getResourceType());
        return serviceAndTable.service.save(serviceAndTable.tableName, dto);
    }

    @Nullable
    public void batchSave(BatchResourceAccessDto dto) {
        ServiceAndTable serviceAndTable = getService(dto.getResourceType());
        serviceAndTable.service.batchSave(serviceAndTable.tableName, dto.getResourceAclList());
    }

    public void update(String uuid, @Nonnull ResourceAccessDto dto) {
        ServiceAndTable serviceAndTable = getService(dto.getResourceType());
        serviceAndTable.service.update(serviceAndTable.tableName, uuid, dto);
    }

    @Nullable
    public void batchUpdate(BatchResourceAccessDto dto) {
        ServiceAndTable serviceAndTable = getService(dto.getResourceType());
        serviceAndTable.service.batchUpdate(serviceAndTable.tableName, dto.getResourceAclList());
    }

    public void upsert(@Nonnull ResourceAccessDto dto) {
        ServiceAndTable serviceAndTable = getService(dto.getResourceType());
        serviceAndTable.service.upsert(serviceAndTable.tableName, dto);
    }

    @Nullable
    public void batchUpsert(BatchResourceAccessDto dto) {
        ServiceAndTable serviceAndTable = getService(dto.getResourceType());
        serviceAndTable.service.batchUpsert(serviceAndTable.tableName, dto.getResourceAclList());
    }

    @Nullable
    public BaseResourceAccessEntity getById(@Nonnull String resourceType, String uuid) {
        ServiceAndTable serviceAndTable = getService(resourceType);
        return serviceAndTable.service.getById(serviceAndTable.tableName, uuid);
    }

    @Nullable
    public BaseResourceAccessEntity getByKey(@Nonnull String resourceType, String resourceCode, GrantedSubjectType grantedSubjectType, String grantedSubjectCode, String grantedReason) {
        ServiceAndTable serviceAndTable = getService(resourceType);
        return serviceAndTable.service.getByKey(serviceAndTable.tableName, resourceType, resourceCode, grantedSubjectType, grantedSubjectCode, grantedReason);
    }

    public void deleteById(@Nonnull String resourceType, String uuid) {
        ServiceAndTable serviceAndTable = getService(resourceType);
        serviceAndTable.service.deleteById(serviceAndTable.tableName, uuid);
    }

    public void batchDelete(@Nonnull String resourceType, List<BaseResourceAccessEntity> entities) {
        ServiceAndTable serviceAndTable = getService(resourceType);
        serviceAndTable.service.batchDelete(serviceAndTable.tableName, entities);

    }

    public void batchDelete(@Nonnull BatchResourceAccessDto dto) {
        List<BaseResourceAccessEntity> entities = new ArrayList<>();
        for (ResourceAccessDto resourceAccessDto : dto.getResourceAclList()) {
            BaseResourceAccessEntity entity = ResourceAccessDtoConverter.convertToEntity(resourceAccessDto);
            entities.add(entity);
        }
        batchDelete(dto.getResourceType(), entities);
    }

    public void delete(@Nonnull String resourceType, String resourceCode) {
        ServiceAndTable serviceAndTable = getService(resourceType);
        serviceAndTable.service.delete(serviceAndTable.tableName, resourceType, resourceCode);
    }


    public void delete(@Nonnull String resourceType, String resourceCode, GrantedSubjectType grantedSubjectType, String grantedSubjectCode) {
        ServiceAndTable serviceAndTable = getService(resourceType);
        serviceAndTable.service.delete(serviceAndTable.tableName, resourceType, resourceCode, grantedSubjectType, grantedSubjectCode);
    }

    public void delete(@Nonnull String resourceType, GrantedSubjectType grantedSubjectType, String grantedSubjectCode) {
        ServiceAndTable serviceAndTable = getService(resourceType);
        serviceAndTable.service.delete(serviceAndTable.tableName, resourceType, grantedSubjectType, grantedSubjectCode);
    }

    public void delete(GrantedSubjectType grantedSubjectType, String grantedSubjectCode) {
        Set<ServiceAndTable> servicesAndTables = metaService.getAllResourceMeta().stream().map(this::getService).collect(Collectors.toSet());
        for (ServiceAndTable serviceAndTable : servicesAndTables) {
            serviceAndTable.service.delete(serviceAndTable.tableName, grantedSubjectType, grantedSubjectCode);
        }
    }

    //listByResourceAndGrantedSubject
    @Nullable
    public List<BaseResourceAccessEntity> list(@Nonnull String resourceType, String resourceCode, GrantedSubjectType grantedSubjectType, String grantedSubjectCode) {
        ServiceAndTable serviceAndTable = getService(resourceType);
        return serviceAndTable.service.list(serviceAndTable.tableName, resourceType, resourceCode, grantedSubjectType, grantedSubjectCode);
    }


    //listByResource
    @Nullable
    public List<BaseResourceAccessEntity> list(@Nonnull String resourceType, String resourceCode) {
        ServiceAndTable serviceAndTable = getService(resourceType);
        return serviceAndTable.service.list(serviceAndTable.tableName, resourceType, resourceCode);
    }

    //listByResourceList
    @Nullable
    public List<BaseResourceAccessEntity> list(@Nonnull String resourceType, List<String> resourceCodeList) {
        ServiceAndTable serviceAndTable = getService(resourceType);
        return serviceAndTable.service.list(serviceAndTable.tableName, resourceType, resourceCodeList);
    }

    //listByResourceTypeAndGrantedSubjectList
    @Nullable
    public List<BaseResourceAccessEntity> list(@Nonnull String resourceType, Map<GrantedSubjectType, List<String>> grantedDataMap) {
        ServiceAndTable serviceAndTable = getService(resourceType);
        return serviceAndTable.service.list(serviceAndTable.tableName, resourceType, grantedDataMap);
    }

    //listByResourceTypeAndGrantedSubjectList
    @Nullable
    public List<BaseResourceAccessEntity> list(@Nonnull String resourceType, GrantedSubjectType grantedSubjectType, List<String> grantedSubjectCodeList) {
        ServiceAndTable serviceAndTable = getService(resourceType);
        return serviceAndTable.service.list(serviceAndTable.tableName, resourceType, grantedSubjectType, grantedSubjectCodeList);
    }

    @Nullable
    ServiceAndTable getService(@Nonnull String resourceType) {

        //get resource meta from meta repo by resourceType
        ResourceMeta resourceMeta = metaService.getResourceMeta(resourceType);

        return getService(resourceMeta);
    }

    @Nullable
    ServiceAndTable getService(@Nonnull ResourceMeta resourceMeta) {
        //get resource meta from meta repo by resourceType
        if (DataProcessingMode.REALTIME_AP.equals(resourceMeta.getStorageEngine())) {
            //if storage engine = REALTIME_AP, return OLAP service
            return new ServiceAndTable(resourceAccessOLAPService, resourceMeta.getDpTable());
        } else if (DataProcessingMode.OLTP.equals(resourceMeta.getStorageEngine())) {
            //if storage engine = OLTP
            if (resourceMeta.isMainDB()) {
                //if data source is main, return OLTP main db service
                return new ServiceAndTable(resourceAccessOLTPMainDBService, resourceMeta.getDpTable());
            } else {
                //if data source is not main, return OLTP service
                return new ServiceAndTable(resourceAccessOLTPService, resourceMeta.getDpTable());
            }
        }
        return null;
    }

    @Data
    static class ServiceAndTable {
        BaseResourceAccessService service;
        String tableName;

        public ServiceAndTable(BaseResourceAccessService service, String tableName) {
            this.service = service;
            this.tableName = tableName;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            ServiceAndTable that = (ServiceAndTable) o;
            return Objects.equals(tableName, that.tableName);
        }

        @Override
        public int hashCode() {
            return Objects.hash(tableName);
        }
    }

}
