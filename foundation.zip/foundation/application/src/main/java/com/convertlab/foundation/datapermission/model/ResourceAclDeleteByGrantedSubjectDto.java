package com.convertlab.foundation.datapermission.model;


import com.convertlab.foundation.library.datapermission.GrantedSubjectType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResourceAclDeleteByGrantedSubjectDto {

    String resourceType;
    GrantedSubjectType grantedSubjectType;
    String grantedSubjectCode;

}
