package com.convertlab.foundation.user.model;
import javax.annotation.Nonnull;

import lombok.Data;

import java.util.Date;

@Data
public class DeptDTO {

    private String name;
    private String parentOutCode;
    private String outCode;
    @Nonnull
    private Integer sequence = 0;
    private Boolean enabled;

}