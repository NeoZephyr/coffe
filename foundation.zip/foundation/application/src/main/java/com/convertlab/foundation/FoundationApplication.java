package com.convertlab.foundation;

import com.convertlab.foundation.gdmmeta.autoconfigure.EnableGdmMetaLocalClient;
import com.convertlab.foundation.libaray.meta.health.config.EnableMetaHealthCheck;
import com.convertlab.foundation.library.redis.annotation.EnableRedisLocalCaching;
import com.convertlab.foundation.library.redis.annotation.EnableRedisLock;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

import java.util.TimeZone;

@SpringBootApplication
@EnableFeignClients(basePackages = {
        "com.convertlab.foundation.**.feign",
        "com.convertlab.foundation.datapermission.client", // todo: DELETE ME !
        })
@EnableRedisLocalCaching
@EnableGdmMetaLocalClient
@EnableRedisLock
@MapperScan("com.convertlab.**.mapper")
@EnableMetaHealthCheck
public class FoundationApplication {
    public static void main(String[] args) {
//        System.setProperty("user.timezone", "UTC");
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        SpringApplication.run(FoundationApplication.class, args);
    }
}
