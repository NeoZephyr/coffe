package com.convertlab.foundation.gdmmeta.model;

import static com.convertlab.foundation.gdmmeta.model.metaobject.ProfileEventMetaObject.EVENT_IDENTIFIER_FIELD;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.convertlab.foundation.library.gdmmeta.model.GdmInheritance;
import com.convertlab.foundation.library.gdmmeta.model.ImmutableGdmInheritance;

import com.convertlab.foundation.gdmmeta.persistance.entity.GdmInheritanceModel;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class Inheritance implements AssignValueStrategy<Inheritance> {
    @Nullable
    @Builder.Default
    private Boolean isSubtype = false;
    @Nullable
    private String parentEntityName;
    @Nullable
    private String identifierField;
    @Nullable
    private String identifierValue;


    public Inheritance(@Nonnull GdmInheritance gdmInheritance) {
        this.isSubtype = gdmInheritance.isSubtype();
        this.parentEntityName = gdmInheritance.getParentEntityName();
        this.identifierField = gdmInheritance.getIdentifierField();
        this.identifierValue = gdmInheritance.getIdentifierValue();
    }


    public static Inheritance newCustomerEventInheritance(Boolean isSubtype, String identifierValue) {
        return Inheritance.builder().isSubtype(isSubtype)
                .parentEntityName("customer_event")
                .identifierField(EVENT_IDENTIFIER_FIELD).identifierValue(identifierValue).build();
    }

    @Nonnull
    public GdmInheritance gdmInheritance() {
        GdmInheritance inheritance = ImmutableGdmInheritance.builder()
                .isSubtype(this.isSubtype)
                .parentEntityName(this.parentEntityName)
                .identifierField(this.identifierField)
                .identifierValue(this.identifierValue)
                .build();
        return inheritance;
    }

    @Nonnull
    public GdmInheritanceModel gdmInheritanceModel() {
        GdmInheritanceModel gdmInheritanceModel = new GdmInheritanceModel();
        gdmInheritanceModel.setParentEntityName(getParentEntityName());
        gdmInheritanceModel.setIdentifierField(getIdentifierField());
        gdmInheritanceModel.setIdentifierValue(getIdentifierValue());
        gdmInheritanceModel.setIdentifierType("String");
        gdmInheritanceModel.setIsSubtype(getIsSubtype());
        return gdmInheritanceModel;
    }

    public Inheritance(@Nonnull Inheritance ora) {
        parentEntityName = ora.parentEntityName;
        isSubtype = ora.isSubtype;
        identifierField = ora.identifierField;
        identifierValue = ora.identifierValue;
    }

    @Nonnull
    @Override
    public Inheritance replaceOrAddIfNotNull(@Nullable Inheritance overlay, GdmObjectMerger gdmObjectMerger) {
        if (overlay == null) {
            return this;
        }
        if (overlay.parentEntityName != null) {
            this.parentEntityName = overlay.parentEntityName;
        }

        if (overlay.isSubtype != null) {
            this.isSubtype = overlay.isSubtype;
        }
        if (overlay.identifierField != null) {
            this.identifierField = overlay.identifierField;
        }
        if (overlay.identifierValue != null) {
            this.identifierValue = overlay.identifierValue;
        }
        return this;
    }

    @Nonnull
    @Override
    public Inheritance unsetIfNotNull(@Nullable Inheritance overlay, GdmObjectMerger gdmObjectMerger) {
        if (overlay == null) {
            return this;
        }
        if (overlay.parentEntityName != null) {
            this.parentEntityName = null;
        }
        if (overlay.isSubtype != null) {
            this.isSubtype = null;
        }
        if (overlay.identifierField != null) {
            this.identifierField = null;
        }
        if (overlay.identifierValue != null) {
            this.identifierValue = null;
        }
        return this;
    }
}
