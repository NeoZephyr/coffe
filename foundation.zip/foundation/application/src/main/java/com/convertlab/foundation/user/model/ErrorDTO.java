package com.convertlab.foundation.user.model;

import com.convertlab.foundation.library.exception.ErrorEnum;
import lombok.Data;

@Data
public class ErrorDTO {
    String code;
    String message_code;
    String[] message_arguments;
    String description;

    public ErrorDTO(ErrorEnum codeEnum, String messageCode, String[] messageArguments, String description) {
        this.code = codeEnum.getCode();
        this.message_code = messageCode;
        this.message_arguments = messageArguments;
        this.description = description;
    }
}
