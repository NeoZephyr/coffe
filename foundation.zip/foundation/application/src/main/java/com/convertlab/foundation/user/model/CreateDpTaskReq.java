package com.convertlab.foundation.user.model;

import lombok.Data;

@Data
public class CreateDpTaskReq {

    private Long attachmentId;
    private String taskDef;
    private String type;
}
