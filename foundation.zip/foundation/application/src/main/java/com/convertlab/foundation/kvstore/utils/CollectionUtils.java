package com.convertlab.foundation.kvstore.utils;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.*;

public class CollectionUtils {
    /**
     * @Description:判断Collection中的元素是否有重复元素
     * @param datas 需要判断的目标集合
     * @return
     */
    public static boolean hasRepeatInCollection(@Nullable Collection<?> datas) {
        if (datas == null) {
            return false;
        }
        if (datas instanceof Set) {
            return false;
        }
        Set<?> noRepeatSet = new HashSet<>(datas);
        if(datas.size() == noRepeatSet.size()){
            return false;
        }else{
            return true;
        }
    }

    /**
     * @Description:找出list中的重复数据
     * @param datas
     * @return
     */
    @Nonnull
    public static <T> List<T> findRepeat(Collection<T> datas) {
        if (datas instanceof Set) {
            return new ArrayList<>();
        }
        HashSet<T> set = new HashSet<T>();
        List<T> repeatElements = new ArrayList<T>();
        for (T t : datas) {
            if (set.contains(t)) {
                repeatElements.add(t);
            } else {
                set.add(t);
            }
        }
        return repeatElements;
    }
}
