package com.convertlab.foundation.user.model;

import com.convertlab.foundation.user.utils.DpTaskStatus;
import lombok.Data;

import java.time.Instant;

@Data
public class DpTaskDTO {

    private Long id;

    private Long tenantId;

    private String type;

    private DpTaskStatus status;

    private String taskDef;

    private String failReason;

    private Boolean recoverable;

    private Long attachmentId;

    private Long failedAttachmentId;

    private Instant dateCreated;

    private Instant lastUpdated;
}
