package com.convertlab.foundation.user.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

@Data
public class UserDept {

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @TableField(fill = FieldFill.INSERT, update = "%s+1", updateStrategy = FieldStrategy.IGNORED)
    private int version = 0;

    private Long userId;

    private String deptCode;

    private Boolean isDefault;

}