package com.convertlab.foundation.user.service;

import javax.annotation.Nonnull;

import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.jdbc.core.OLTPJdbcTemplate;
import com.convertlab.foundation.user.entity.Dept;
import com.convertlab.foundation.user.entity.UserDept;
import com.convertlab.foundation.user.entity.UserTenant;
import com.convertlab.foundation.user.mapper.DeptMapper;
import com.convertlab.foundation.user.mapper.UserDeptMapper;
import com.convertlab.foundation.user.mapper.UserMapper;
import com.convertlab.foundation.user.model.MoveDeptDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@DataSourceLookup("main")
@Transactional
@Slf4j
public class UserDeptService {

    private final UserDeptMapper userDeptMapper;

    private final DeptMapper deptMapper;

    private final UserMapper userMapper;

    private  final OLTPJdbcTemplate oltpJdbcTemplate;



    public UserDeptService(DeptMapper deptMapper, UserDeptMapper userDeptMapper, UserMapper userMapper, OLTPJdbcTemplate oltpJdbcTemplate) {
        this.deptMapper = deptMapper;
        this.userMapper = userMapper;
        this.userDeptMapper = userDeptMapper;
        this.oltpJdbcTemplate = oltpJdbcTemplate;
    }


    public void move(@Nonnull MoveDeptDTO dto){

        if (dto.getUserIds() == null || dto.getUserIds().isEmpty()) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_004_001015", "userIds is empty", new String[]{});
        }

        if (dto.getFromDeptCode() == null && (dto.getToDeptCodes() == null || dto.getToDeptCodes().isEmpty())) {
            throw new BusinessException(CommonErrors.MISSING_FIELD,"MSG_004_001016", "missing field fromDeptCode or toDeptCodes", new String[]{});
        }

        List<Long> userTenants = userMapper.getUserTenantByIdList(dto.getUserIds());

        if (userTenants == null || userTenants.size() != dto.getUserIds().size()) {
            throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_004_001017","exist invalid userId", new String[]{});
        }

        //delete user dept based on fromDeptCode
        if(!StringUtils.isBlank(dto.getFromDeptCode())){
            //如果dept 不存在，抛出错误
            Dept dept = deptMapper.getDeptByCode(dto.getFromDeptCode());
            if(dept == null){
                throw new BusinessException(CommonErrors.VALIDATION_ERROR, "MSG_004_001018", "fromDeptCode is invalid", new String[]{});
            }

            dto.getUserIds().forEach(userId -> {
                deleteUserDept(dto.getFromDeptCode(), userId);
            });
        }

        //add user dept based on toDeptCodes
        if(dto.getToDeptCodes() != null && !dto.getToDeptCodes().isEmpty()){

            //轮询检查deptCode是否存在
            dto.getToDeptCodes().forEach(deptCode -> {
                Dept dept = deptMapper.getDeptByCode(deptCode);
                if(dept == null){
                    throw new BusinessException(CommonErrors.VALIDATION_ERROR,"MSG_004_001019", "toDeptCode is invalid", new String[]{});
                }
            });

            dto.getUserIds().forEach(userId -> {
                dto.getToDeptCodes().forEach(deptCode -> {
                    saveUserDept(deptCode, userId);
                });
            });
        }
    }

    public void saveUserDept(String deptCode, Long userId) {
        //检查是否deptCode, userId都存在
        Dept dept = deptMapper.getDeptByCode(deptCode);
        List<Long> userIds = userMapper.getUserTenantByUserId(userId);
        if(dept != null && !userIds.isEmpty()){
            //检查userDept是否在数据库中已经存在。
            UserDept userDept = userDeptMapper.getUserDeptByUserIdAndDeptCode(userId, deptCode);
            if(userDept != null){
                return;
            }

            userDept = new UserDept();
            userDept.setUserId(userId);
            userDept.setDeptCode(deptCode);
            userDeptMapper.insert(userDept);
        }
    }

    public void deleteUserDept(String deptCode, Long userId) {
        UserDept userDept = userDeptMapper.getUserDeptByUserIdAndDeptCode(userId, deptCode);
        if(userDept != null){
            userDeptMapper.deleteById(userDept.getId());
        }
    }

    @Nonnull
    public  Map<String, Object> getUserDeptInfo(Long userId) {

        String sql = "select d.code as deptCode, d.path as deptPath from user_dept ud inner join dept d " +
                "on ud.dept_code = d.code where ud.user_id = ?";

        List<Map<String, Object>>  list = oltpJdbcTemplate.queryForList(sql, userId);

        Map<String, Object> defaultDept = null;

        for (Map<String, Object> it : list) {
            if (defaultDept == null) {
                defaultDept = it;
            } else {
                String oldDeptPath = (String) defaultDept.get("deptPath");
                String newDeptPath = (String) it.get("deptPath");

                if (oldDeptPath.startsWith(newDeptPath) || (oldDeptPath.split("-").length > newDeptPath.split("-").length)) {
                    defaultDept = it;
                }
            }
        }

        Map<String, Object> result = new HashMap<>();
        result.put("defaultDept", defaultDept);
        result.put("deptList", list);

        return result;
    }

//
//    def superiorDept(String deptCode){
//        if (!deptCode){
//            render CommonErrors.MISSING_FIELD.errorObject("missing field deptCode") as JSON
//            return
//        }
//        Dept dept = Dept.findByCode(deptCode)
//        if (dept){
//            return render(dept.path.split("-") as JSON)
//        }
//    }


}
