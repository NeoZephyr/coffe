package com.convertlab.foundation.datapermission.model;

public class ResourceAclListByResourceList {
}
