package com.convertlab.foundation.user.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.Instant;

@Data
public class UserGroup {

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @TableField(fill = FieldFill.INSERT, update = "%s+1", updateStrategy = FieldStrategy.IGNORED)
    private Integer version;



    private String name;


    private String code;


    private String remark;


    private String ownerName;

    private Long ownerId;

    private Instant dateCreated;

    private Instant lastUpdated;

    public UserGroup(String name, String code, String remark) {
        this.name = name;
        this.code = code;
        this.remark = remark;
    }

}