package com.convertlab.foundation.misc.service.impl;

import javax.annotation.Nonnull;

import com.convertlab.foundation.gdmmeta.dao.mongodb.GdmMetaHistoryDao;
import com.convertlab.foundation.library.business.annotations.DesignTimeOnly;
import com.convertlab.foundation.library.gdmmeta.api.GdmEntityApiRoot;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.misc.service.HomeService;
import com.convertlab.foundation.misc.service.dao.HomeDao;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.time.Instant;

@Service
@Slf4j
public class HomeServiceImpl implements HomeService {
    private final HomeDao homeDao;
    private final GdmEntityApiRoot entityApi;
    private final GdmMetaHistoryDao gdmMetaHistoryDao;
    public HomeServiceImpl(HomeDao homeDao,
                           @Qualifier("localGsMetaClient") GsMetaClient entityApi, GdmMetaHistoryDao gdmMetaHistoryDao) {
        this.homeDao = homeDao;
        this.entityApi = entityApi;
        this.gdmMetaHistoryDao = gdmMetaHistoryDao;
    }
    @Nonnull
    public String greeting() {
        return "Hello DB:"+ homeDao.getCurrentDB() +"! Now is:" + homeDao.getDate() + "\n <a href='/swagger-ui/index.html'>Swagger Doc</a>";
    }

    @Override
    @DesignTimeOnly
    public boolean checkDesignTime() {
        return true;
    }

    @Override
    public String benchmarkDbOperations(int count, long startId, HomeDao.BenchmarkMode mode) {
        startId = startId >= 900000000L ? startId : 900000000L + startId;
        GdmEntity entity = entityApi.getEntity("dashboard");
        String response = "DB benchmark: \n";
        long startTime = System.currentTimeMillis();
        long endId = startId + count;
        switch (mode) {
            case OLTP_JDBC_TEMPLATE:
                homeDao.insertDashboardsByOltpJdbcTemplate(startId, endId);
                break;
            case JDBC_TEMPLATE:
                homeDao.insertDashboardsByJdbcTemplate(startId, endId);
                break;
            case GENERIC_GDM_MODEL:
            default:
                homeDao.insertDashboards(entity, startId, endId);
        }
        long insertFinishTime = System.currentTimeMillis();
        response += (insertFinishTime - startTime) + "ms for insert " + count + " records\n";
        switch (mode) {
            case OLTP_JDBC_TEMPLATE:
                homeDao.removeDashboardsByOltpJdbcTemplate(startId, endId-1);
                break;
            case JDBC_TEMPLATE:
                homeDao.removeDashboardsByJdbcTemplate(startId, endId-1);
                break;
            case GENERIC_GDM_MODEL:
            default:
                homeDao.removeDashboards(entity, startId, endId-1);
        }
        response += (System.currentTimeMillis() - insertFinishTime) + "ms for delete " + (count-1) + " records\n";
        return response;
    }

    public Long deleteMetaHistoryBefore(Instant before) {
        log.info("deleteMetaHistoryBefore : {}", before);
        return gdmMetaHistoryDao.deleteBefore(before);
    }
}
