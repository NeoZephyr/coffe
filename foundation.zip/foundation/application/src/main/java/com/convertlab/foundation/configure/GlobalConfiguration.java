package com.convertlab.foundation.configure;

import com.convertlab.common.crypto.client.CryptoClient;
import com.convertlab.foundation.library.business.feature.JdbcFeatureClient;
import com.zaxxer.hikari.HikariDataSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.annotation.Nonnull;
import javax.sql.DataSource;

/**
 * All the shared components/beans should be defined here.
 * 越少越好！！！ 别滥用！！！
 * Don't abuse this class, it's not a good practice for decoupling!
 * - 如果是需要提供给其他服务使用的bean，转换成library导入，在library里提供springboot-starter
 * - 如果是在application中声明的共享bean需要放在这里。
 */
@Configuration("GlobalConfiguration")
@Slf4j
@EnableAspectJAutoProxy
public class GlobalConfiguration {

    @Nonnull
    @Bean
    protected SystemWarmup systemWarmup() {
        return new SystemWarmup();
    }

    @Nonnull
    @Bean
    @ConditionalOnMissingBean
    public CryptoClient cryptoClient(@Value("${keyAdapter.serverUrl}") String keyAdapterServerUrl) {
        CryptoClient client = CryptoClient.getInstance();
        client.setUrl(keyAdapterServerUrl);
        return client;
    }

    @Bean(name = "mainDataSource")
    @ConfigurationProperties(prefix = "spring.datasource.main")
    public DataSource mainDataSource() {
        return DataSourceBuilder.create().type(HikariDataSource.class).build();
    }

    @Bean("jdbcFeatureClient")
    public JdbcFeatureClient jdbcFeatureClient(@Qualifier("mainDataSource") DataSource dataSource) {
        return new JdbcFeatureClient(new JdbcTemplate(dataSource));
    }
}
