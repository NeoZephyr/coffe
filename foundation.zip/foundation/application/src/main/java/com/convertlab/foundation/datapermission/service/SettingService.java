package com.convertlab.foundation.datapermission.service;

import com.convertlab.foundation.library.datapermission.model.*;
import com.convertlab.foundation.datapermission.model.*;
import com.convertlab.foundation.library.gdmmeta.client.GeneralMetaClient;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.client.exception.MetaException;
import com.convertlab.foundation.library.gdmmeta.model.general.BaseMetaSchema;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.ObjectRequest;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.ObjectResponse;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.library.jdbc.core.OLTPJdbcTemplate;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.user.entity.Dept;
import com.convertlab.foundation.user.service.DeptService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.convertlab.foundation.library.gdmmeta.model.general.BaseMetaSchema.MetaType.GDM_ACLS;
import static com.convertlab.foundation.library.gdmmeta.model.general.BaseMetaSchema.Namespace.GDM;

@Service
@Slf4j
@DataSourceLookup("main")
public class SettingService {

    final GeneralMetaClient generalMetaClient;
    final GsMetaClient gsMetaClient;

    public SettingService(GeneralMetaClient generalMetaClient, GsMetaClient gsMetaClient) {
        this.generalMetaClient = generalMetaClient;
        this.gsMetaClient = gsMetaClient;
    }

    private static <T> Function<Map<String, Object>, T> cast(Class<T> clazz) {
        return (data) -> JsonUtils.instanceOfDto().convertFromMap(data, clazz);
    }

    private <T> @NotNull List<T> accessTableLikeStruct(String objectKey, Class<T> clazz) {
        ObjectResponse response = gsMetaClient.getObject(GDM, GDM_ACLS, objectKey);
        return accessTableLikeStruct(response, clazz);
    }

    @SuppressWarnings("unchecked")
    private <T> @NotNull List<T> accessTableLikeStruct(ObjectResponse response, Class<T> clazz) {
        if (response != null) {
            Map<String, Object> data = response.getData();
            if (data != null) {
                List<Map<String, Object>> rows = (List<Map<String, Object>>) data.get("rows");
                return rows.stream().filter(x -> !x.isEmpty()).map(cast(clazz)).collect(Collectors.toList());
            }
        }
        return Collections.emptyList();
    }

    private <T> @NotNull List<T> writeTableLikeStruct(String objectKey, List<T> rows, Class<T> clazz) {
        Map<String, List<T>> data = new HashMap<>();
        data.put("rows", rows);
        ObjectResponse object = gsMetaClient.getObject(GDM, GDM_ACLS, objectKey);
        if (object == null) {
            gsMetaClient.createObject(GDM, GDM_ACLS, new ObjectRequest(objectKey, data));
        } else {
            gsMetaClient.updateObject(GDM, GDM_ACLS, objectKey, new ObjectRequest(objectKey, data));
        }
        @NotNull List<T> retrieved = accessTableLikeStruct(objectKey, clazz);
        return retrieved;
    }

    public List<GlobalAccessSetting> listGlobalAccess() {
        return accessTableLikeStruct(GlobalAccessSetting.DOCUMENT_OBJECT_KEY, GlobalAccessSetting.class);
    }

    @Nullable
    public GlobalAccessSetting getGlobalAccessSetting(String resourceCategory) {
        @NotNull List<GlobalAccessSetting> rows = accessTableLikeStruct(GlobalAccessSetting.DOCUMENT_OBJECT_KEY, GlobalAccessSetting.class);
        for (GlobalAccessSetting row : rows) {
            if (Objects.equals(row.getResourceType(), resourceCategory)) {
                return row;
            }
        }
        return null;
    }

    public List<GlobalAccessSetting> setGlobalAccess(List<SetGlobalAccessRequest> requests) {
        List<GlobalAccessSetting> oldRows = accessTableLikeStruct(GlobalAccessSetting.DOCUMENT_OBJECT_KEY, GlobalAccessSetting.class);
        List<GlobalAccessSetting> keep = oldRows.stream().filter(row -> requests.stream().noneMatch(request -> Objects.equals(request.getResourceType(), row.getResourceType()))).collect(Collectors.toList());

        List<GlobalAccessSetting> rows = requests.stream()
                .map(request -> new GlobalAccessSetting(request.getResourceType(), request.getAccessPermission()))
                .collect(Collectors.toList());
        rows.addAll(keep);
        return writeTableLikeStruct(GlobalAccessSetting.DOCUMENT_OBJECT_KEY, rows, GlobalAccessSetting.class);
    }

    public List<HighSeasSetting> getHighSeaSettings() {
        @NotNull List<HighSeasSetting> rows = accessTableLikeStruct(HighSeasSetting.DOCUMENT_OBJECT_KEY, HighSeasSetting.class).stream().filter(row -> Objects.equals(row.getGrantedSubjectType(), HighSeasSetting.DEPT_ACCESS_SCOPE)).collect(Collectors.toList());
        return rows;
    }

    public void setHighSeaSettings(List<HighSeasSetting> highSeaSettings) {
        writeTableLikeStruct(HighSeasSetting.DOCUMENT_OBJECT_KEY, highSeaSettings, HighSeasSetting.class);
    }

    public List<SwitchSetting> getSwitchSettings() {
        @NotNull List<SwitchSetting> switchSettings = accessTableLikeStruct(SwitchSetting.SWITCH_OBJECT_KEY, SwitchSetting.class);
        return switchSettings;
    }

    public void setSwitchSettings(List<SwitchSetting> settings) {
        List<SwitchSetting> oldSwitchSettings = getSwitchSettings();
        if (!CollectionUtils.isEmpty(settings) && !CollectionUtils.isEmpty(oldSwitchSettings)) {
            for (SwitchSetting setting : settings) {
                Optional<SwitchSetting> first = oldSwitchSettings.stream().filter(oldSwitchSetting -> setting.getGrantedSubjectKey().equals(oldSwitchSetting.getGrantedSubjectKey())).findFirst();
                if (first.isPresent()) {
                    //修改已有数据
                    first.get().setGrantedSubjectValue(setting.getGrantedSubjectValue());
                } else {
                    //新增数据
                    oldSwitchSettings.add(setting);
                }
            }
        }
        if (!CollectionUtils.isEmpty(settings) && CollectionUtils.isEmpty(oldSwitchSettings)) {
            oldSwitchSettings = settings;
        }
        writeTableLikeStruct(SwitchSetting.SWITCH_OBJECT_KEY, oldSwitchSettings, SwitchSetting.class);
    }

    public SwitchSetting getOneSwitchSetting(String subjectKey) {
        return getOneSwitchSetting(subjectKey, null);
    }

    public SwitchSetting getOneSwitchSetting(String subjectKey, Boolean defaultValue) {
        if (defaultValue == null) {
            defaultValue = false;
        }
        if (StringUtils.isBlank(subjectKey)) {
            return new SwitchSetting(subjectKey, defaultValue);
        }
        List<SwitchSetting> switchSettings = getSwitchSettings();
        if (CollectionUtils.isEmpty(switchSettings)) {
            return new SwitchSetting(subjectKey, defaultValue);
        }
        Optional<SwitchSetting> first = switchSettings.stream().filter(switchSetting -> subjectKey.equals(switchSetting.getGrantedSubjectKey())).findFirst();
        return first.orElse(new SwitchSetting(subjectKey, defaultValue));
    }

    public void setOneSwitchSetting(String subjectKey, Boolean subjectValue) {
        if (subjectValue == null) {
            subjectValue = false;
        }
        setSwitchSettings(Collections.singletonList(new SwitchSetting(subjectKey, subjectValue)));
    }

    public DeptAttrSetting setDeptAttr(String deptAttrColumn, String objectName) {
        log.info("SetDeptAttr request body is {}, {}", objectName, deptAttrColumn);
        @NotNull List<DeptAttrSetting> rows = accessTableLikeStruct(DeptAttrSetting.DOCUMENT_OBJECT_NAME, DeptAttrSetting.class)
                .stream().filter(s -> !Objects.equals(s.getObjectName(), objectName)).collect(Collectors.toList());
        rows.add(new DeptAttrSetting(objectName, deptAttrColumn));
        return writeTableLikeStruct(DeptAttrSetting.DOCUMENT_OBJECT_NAME, rows, DeptAttrSetting.class)
                .stream()
                .filter(s -> Objects.equals(s.getObjectName(), objectName))
                .findFirst().orElse(null);
    }

    public @Nullable
    DeptAttrSetting getDeptAttr(String resourceType) {
        return accessTableLikeStruct(DeptAttrSetting.DOCUMENT_OBJECT_NAME, DeptAttrSetting.class).stream()
                .filter(s -> Objects.equals(s.getObjectName(), resourceType))
                .findFirst().orElse(null);
    }

    public List<DeptAttrSetting> cleanDeptAttr(String resourceType) {
        log.info("cleanDeptAttr request resourceType is {}", resourceType);
        @NotNull List<DeptAttrSetting> rows = accessTableLikeStruct(DeptAttrSetting.DOCUMENT_OBJECT_NAME, DeptAttrSetting.class)
                .stream().filter(s -> !Objects.equals(s.getObjectName(), resourceType)).collect(Collectors.toList());

        return writeTableLikeStruct(DeptAttrSetting.DOCUMENT_OBJECT_NAME, rows, DeptAttrSetting.class);
    }

    public void setAccessScopeSetting(AccessScopeSetting accessScopeSetting) {
        writeTableLikeStruct(AccessScopeSetting.DOCUMENT_OBJECT_KEY, Collections.singletonList(accessScopeSetting), AccessScopeSetting.class);
    }

    public AccessScopeSetting getAccessScopeSetting() {
        AccessScopeSetting accessScopeSetting = accessTableLikeStruct(AccessScopeSetting.DOCUMENT_OBJECT_KEY, AccessScopeSetting.class).stream().findFirst().orElse(null);
        return accessScopeSetting;
    }

}
