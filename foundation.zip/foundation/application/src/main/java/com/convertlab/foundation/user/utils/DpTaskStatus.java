package com.convertlab.foundation.user.utils;

public enum DpTaskStatus {

    init, dispatch, processing, finished, failed
}
