package com.convertlab.foundation.user.service;

import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BusinessException;
import com.convertlab.foundation.library.jdbc.annotation.DataSourceLookup;
import com.convertlab.foundation.user.entity.DpTask;
import com.convertlab.foundation.user.mapper.DeptTaskMapper;
import com.convertlab.foundation.user.model.CreateDpTaskReq;
import com.convertlab.foundation.user.model.DpTaskDTO;
import com.convertlab.foundation.user.utils.DpTaskStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Objects;

@Service
@DataSourceLookup("main")
@Transactional
@Slf4j
public class DeptTaskService {

    @Value("${kafka.dpRuleRebuild.execTopic}")
    private String execTopic;

    private final KafkaTemplate<String, DpTask> kafkaTemplate;

    private final DeptTaskMapper deptTaskMapper;

    public DeptTaskService(DeptTaskMapper deptTaskMapper, KafkaTemplate<String, DpTask> kafkaTemplate) {
        this.deptTaskMapper = deptTaskMapper;
        this.kafkaTemplate = kafkaTemplate;
    }

    public DpTask create(CreateDpTaskReq req) {
        DpTask dpTask = DpTask.builder()
                .attachmentId(req.getAttachmentId())
                .taskDef(req.getTaskDef())
                .type(req.getType())
                .status(DpTaskStatus.init.name())
                .build();
        deptTaskMapper.insert(dpTask);
        return dpTask;
    }

    public DpTask start(Long id) {
        DpTask task = deptTaskMapper.selectById(id);
        if (Objects.isNull(task)) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, String.format("task %d not found", id));
        }
        kafkaTemplate.send(execTopic, id.toString(), task);
        return task;
    }

    public DpTask show(Long id) {
        DpTask task = deptTaskMapper.selectById(id);
        if (Objects.isNull(task)) {
            throw new BusinessException(CommonErrors.DATA_NOT_FOUND, String.format("task %d not found", id));
        }
        return task;
    }

    public DpTask updateStatus(DpTask dpTask, String status) {
        dpTask.setStatus(status);
        deptTaskMapper.updateById(dpTask);
        return dpTask;
    }
    public DpTask update(DpTaskDTO dto) {
        DpTask dpTask = show(dto.getId());
        dpTask.setStatus(String.valueOf(dto.getStatus()));
        if (Objects.equals(DpTaskStatus.failed, dto.getStatus())) {
            dpTask.setFailReason(dto.getFailReason());
        }
        if (dto.getAttachmentId() != null) {
            dpTask.setAttachmentId(dto.getAttachmentId());
        }
        deptTaskMapper.updateById(dpTask);
        return dpTask;
    }
}
