package com.convertlab.foundation.misc.controller;

import com.convertlab.foundation.library.business.eventbroker.ImpalaRefreshEvent;
import com.convertlab.foundation.misc.service.ImpalaOperationService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v1/impala/ops")
@Tag(name = "Impala Operations接口")
@Slf4j
@RequiredArgsConstructor
public class ImpalaOperationsController {

    private final ImpalaOperationService impalaOperationService;

    @PostMapping(value = "refresh/{table}")
    public ResultDto refreshTable(@PathVariable(name = "table") String tableName, @RequestBody(required = false) RefreshTableRequest request) {
        impalaOperationService.executeRefresh(tableName, request != null ? request.partitionColumns : null);
        return ResultDto.OK;
    }

    @PostMapping(value = "invalidateMetaData/{table}")
    public ResultDto invalidateMetaData(@PathVariable(name = "table") String tableName) {
        String sql = "INVALIDATE METADATA " + tableName;
        try {
            impalaOperationService.executeImpalaOps(sql);
            return ResultDto.OK;
        } catch (Exception e) {
            throw new IllegalArgumentException("Failed to invalidate meta data, with sql: " + sql+" due to "+e.getMessage(), e);
        }
    }

    @PostMapping(value = "computeStats/{table}")
    public ResultDto computeStats(@PathVariable(name = "table") String tableName) {
        String sql = "COMPUTE STATS " + tableName;
        try {
            impalaOperationService.executeImpalaOps(sql);
            return ResultDto.OK;
        } catch (Exception e) {
            throw new IllegalArgumentException("Failed to compute stats, with sql: " + sql+" due to "+e.getMessage(), e);
        }
    }

    @GetMapping(value = "connectionUrl")
    public ResultDto connectionUrl() {
        try {
            String result = impalaOperationService.getConnectionUrl();
            return ResultDto.ok(result);
        } catch (Exception e) {
            throw new IllegalArgumentException("Failed to get connection url", e);
        }
    }

    @Data
    public static class RefreshTableRequest {
        private List<ImpalaRefreshEvent.PartitionColumn> partitionColumns;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ResultDto {
        public static final ResultDto OK = new ResultDto("success");
        private String result;

        public static ResultDto ok(String result) {
            return new ResultDto(result);
        }
    }
}
