package com.convertlab.foundation.datapermission.model;

import lombok.Data;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.List;

@Data
public class ResourceBatchShareRequestDto {

        private String resourceType;

        @Nonnull
        private List<String> resourceCodes = new ArrayList<>();

        @Nonnull
        private List<Integer> userIds = new ArrayList<Integer>();

        @Nonnull
        private List<String> groupCodes = new ArrayList<String>();

        @Nonnull
        private List<String> deptCodes = new ArrayList<String>();

        private String accessLevel;

        @Nonnull
        public List<ResourceShareRequestDto> convertToResourceShareRequestDTO(){

                List<ResourceShareRequestDto> shareRequestDTOList = new ArrayList<ResourceShareRequestDto>();

                for (String resourceCode : resourceCodes) {
                        ResourceShareRequestDto dto = new ResourceShareRequestDto();
                        dto.setResourceType(resourceType);
                        dto.setResourceCode(resourceCode);
                        dto.setUserIds(userIds);
                        dto.setGroupCodes(groupCodes);
                        dto.setDeptCodes(deptCodes);
                        dto.setAccessLevel(accessLevel);
                        shareRequestDTOList.add(dto);
                }

                return shareRequestDTOList;
        }


}
