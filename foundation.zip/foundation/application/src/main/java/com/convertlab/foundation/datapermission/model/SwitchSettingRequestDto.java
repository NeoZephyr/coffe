package com.convertlab.foundation.datapermission.model;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
public class SwitchSettingRequestDto implements Serializable {
    /**
     * 是否关闭
     */
    protected Boolean switchValue;

    public SwitchSettingRequestDto() {
    }

    public SwitchSettingRequestDto(Boolean isOff) {
        this.switchValue = isOff;
    }
}
