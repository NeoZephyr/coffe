package com.convertlab.foundation.datapermission.model;


import com.convertlab.foundation.library.datapermission.ResourceAccessDto;
import lombok.Data;

@Data
public class ResourceAclDeleteByKeyDto {

    String resourceType;
    ResourceAccessDto resourceAcl;
}
