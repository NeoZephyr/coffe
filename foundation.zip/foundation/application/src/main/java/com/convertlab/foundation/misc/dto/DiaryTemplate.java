package com.convertlab.foundation.misc.dto;

import com.convertlab.foundation.gdmmeta.dao.mongodb.DaoConfig;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.Ref;
import com.convertlab.foundation.library.gdmmeta.model.general.dto.BaseMetaDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * 业务面向前端的DTO的示例。有几点需要注意：
 * 1. BaseMetaDto，这样就可以使用version字段了。但是要确认这个DTO背后的meta存储节点支持version字段的检查。
 * 字段检查参考 {@link DaoConfig#isVersioned(String)}
 * 2. Ref的使用，根据需要判断，是直接把Ref暴露给前端，还是把Ref转换成String暴露给前端。
 *
 */
@EqualsAndHashCode(callSuper = false)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DiaryTemplate extends BaseMetaDto {
    @Schema(hidden = true)
    final String extType = "DIARY_TEMPLATE";
    @Schema(example = "123")
    String id;
    @Schema(example = "模板名称")
    String name;
    @Schema(example = "模板内容")
    String templateContent;
    @Schema(example = "模板描述")
    String description;
    Ref modelRef;
}


