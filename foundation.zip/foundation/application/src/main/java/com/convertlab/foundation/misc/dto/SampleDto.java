package com.convertlab.foundation.misc.dto;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class SampleDto {
    String name;
    Long id;
}
