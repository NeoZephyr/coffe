package com.convertlab.foundation.user.mapper;


import javax.annotation.Nullable;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.foundation.user.entity.Dept;
import com.convertlab.foundation.user.entity.UserDept;

import java.util.List;

public interface UserDeptMapper extends BaseMapper<UserDept> {

    default UserDept getUserDeptByUserIdAndDeptCode(long userId, String deptCode){
        QueryWrapper<UserDept> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userId);
        queryWrapper.eq("dept_code", deptCode);
        return selectOne(queryWrapper);
    }

    default List<UserDept> listUserDepts(@Nullable String deptCode) {
        QueryWrapper<UserDept> queryWrapper = new QueryWrapper<>();
        if(deptCode != null) {
            queryWrapper.eq("dept_code", deptCode);
        }
        return selectList(queryWrapper);
    }
}


