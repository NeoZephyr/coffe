package com.convertlab.foundation.misc.controller;


import javax.annotation.Nonnull;

import com.convertlab.foundation.misc.service.DPMigrationTestService;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.lang.Nullable;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/dp/migration/sql")
@Tag(name = "Data Permission Migration接口")
public class DpMigrationController {

    private final DPMigrationTestService dpMigrationTestService;

    public DpMigrationController(DPMigrationTestService dpMigrationTestService) {
        this.dpMigrationTestService = dpMigrationTestService;
    }

    @Nonnull
    @GetMapping("/resource")
    String resource(@RequestParam @Nullable String su, @RequestParam @Nullable Integer size) {
//        return dpMigrationTestService.migrateContentAccessControl(StringUtils.hasText(su), size);
        return null;
    }
}
