package com.convertlab.foundation.misc.service.dboperation;

import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;
import com.convertlab.foundation.library.sqlprocessor.SQLDialect;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.misc.dto.CastAndCopyColumnRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.logging.log4j.util.Strings;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import static com.convertlab.foundation.library.sqlprocessor.SQLDialect.MYSQL;

@RequiredArgsConstructor
@Slf4j
public abstract class AbstractDbOperation {
    protected final CastAndCopyColumnRequest args;
    protected final Connection connection;
    protected final SQLDialect sqlDialect;

    public void run() {
        String sql = buildSql();
        log.info(sql);
        long start = System.currentTimeMillis();
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.executeUpdate();
            log.info("Db operation" + this.getClass().getSimpleName() + " is done, took " + (System.currentTimeMillis() - start) + "ms, args: " + JsonUtils.instanceOfDto().obj2Json(args));
        } catch (Exception e) {
            throw new IllegalStateException("failed to run db operation " + this.getClass().getSimpleName(), e);
        }
    }

    protected String buildSimpleWhere(CastAndCopyColumnRequest args) {
        long tenantId = TenantContextHolder.getTenantIdExt();
        String sql = " WHERE tenant_id = " + tenantId;
        if (!StringUtils.isBlank(args.getObjId())) {
            sql += " AND obj_id = '" + args.getObjId() + "'";
        }
        if (!StringUtils.isBlank(args.getExtraConditions())) {
            sql += " AND " + args.getExtraConditions();
        }
        return sql;
    }

    protected String buildWhere(CastAndCopyColumnRequest args) {
        long tenantId = TenantContextHolder.getTenantIdExt();
        String sql = " WHERE tenant_id = " + tenantId;
        if (!StringUtils.isBlank(args.getObjId())) {
            sql += " AND obj_id = '" + args.getObjId() + "'";
        }
        if (!StringUtils.isBlank(args.getFromColumn())) {
            sql += " AND `" + args.getFromColumn() + "` IS NOT NULL AND `" + args.getFromColumn() + "` !='null' ";
        }
        if (!StringUtils.isBlank(args.getToColumn())) {
            sql += " AND `" + args.getToColumn() + "` IS NULL ";
        }
        if (!StringUtils.isBlank(args.getExtraConditions())) {
            sql += " AND " + args.getExtraConditions();
        }
        return sql;
    }

    protected String castFunctionToSql(CastAndCopyColumnRequest.CastFunction castFunction, String columnName, SQLDialect dialect) {
        if (dialect.equals(MYSQL)) {
            switch (castFunction) {
                case CharToBigInt:
                    return "CAST(`" + columnName + "` AS UNSIGNED)";
                case BigIntToChar:
                    return "CAST(`" + columnName + "` AS CHAR)";
                default:
                    return Strings.EMPTY;
            }
        } else {
            switch (castFunction) {
                case CharToBigInt:
                    //fk11~fk15 in kudu is actually string.
                    return columnName;
//                    return "CAST(`" + columnName + "` AS BIGINT)";
                case BigIntToChar:
                    return columnName;
//                    return "CAST(`" + columnName + "` AS STRING)";
                default:
                    return Strings.EMPTY;
            }
        }
    }

    public void printColumn() {
        String fromColumn = args.getFromColumn() == null ? "'N/A'" : args.getFromColumn();
        String toColumn = args.getToColumn() == null ? "'N/A'" : args.getToColumn();
        String sql = "SELECT " + fromColumn + "," + toColumn + " FROM " + args.getTableName() + buildWhere(args);
        log.info(sql);
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            try (ResultSet rs = pstmt.executeQuery()) {
                log.info("{}, {}", args.getFromColumn(), args.getToColumn());
                List<Pair<Object, Object>> result = new ArrayList<>();
                while (rs.next()) {
                    Object from = rs.getObject(args.getFromColumn());
                    Object to = rs.getObject(args.getToColumn());
                    result.add(new ImmutablePair<>(from, to));
                }
                result.forEach(x -> {
                    log.info(JsonUtils.instanceOfDto().obj2Json(result));
                });
            }
        } catch (Exception e) {
            log.error("Failed to print column", e);
        }

    }

    public long count() {
        String sql = "SELECT count(1) AS c FROM " + args.getTableName() + buildWhere(args);
        log.info(sql);
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getLong("c");
                }
            }
        } catch (Exception e) {
            log.error("Failed to count", e);
        }
        return 0;
    }

    public long countNotNull(String column) {
        String sql = "SELECT count(1) AS c FROM " + args.getTableName() + buildSimpleWhere(args);
        sql += " AND " + column + " IS NOT NULL AND "+ column + " != 'null'";
        log.info(sql);
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getLong("c");
                }
            }
        } catch (Exception e) {
            log.error("Failed to count not null", e);
        }
        return 0;
    }

    protected abstract String buildSql();
}
