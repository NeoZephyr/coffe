package com.convertlab.foundation.datapermission.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.convertlab.foundation.datapermission.util.GrantedPermissionTypeHandler;
import com.convertlab.foundation.datapermission.util.GrantedSubjectTypeHandler;
import com.convertlab.foundation.library.datapermission.GrantedPermission;
import com.convertlab.foundation.library.datapermission.GrantedSubjectType;
import lombok.Data;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.ibatis.type.TypeHandler;

import java.lang.reflect.InvocationTargetException;
import java.time.Instant;
import java.util.Map;

@Data
public class BaseResourceAccessEntity {

    public BaseResourceAccessEntity() {
    }

    private String uuid;
    private Long tenantId;
    @TableField(fill = FieldFill.INSERT, update = "%s+1", updateStrategy = FieldStrategy.IGNORED)
    private int version;
    private String resourceCode;
    private String resourceType;
    @TableField(typeHandler = GrantedSubjectTypeHandler.class)
    private GrantedSubjectType grantedSubjectType;
    private String grantedSubjectCode;
    @TableField(typeHandler = GrantedPermissionTypeHandler.class)
    private GrantedPermission grantedPermission;
    private String grantedReason;
    private String additionalInfo;
    private Instant dateCreated;
    private Instant lastUpdated;

    public static BaseResourceAccessEntity fromInternalEntity(BaseResourceAccessEntityInternal data){
        BaseResourceAccessEntity entity = new BaseResourceAccessEntity();
        entity.setUuid(data.getUuid());
        entity.setDateCreated(data.getDateCreated());
        entity.setAdditionalInfo(data.getAdditionalInfo());
        entity.setGrantedReason(data.getGrantedReason());
        entity.setGrantedPermission(GrantedPermission.fromValue(data.getGrantedPermission()));
        entity.setGrantedSubjectCode(data.getGrantedSubjectCode());
        entity.setGrantedSubjectType(GrantedSubjectType.fromValue(data.getGrantedSubjectType()));
        entity.setResourceCode(data.getResourceCode());
        entity.setResourceType(data.getResourceType());
        entity.setTenantId(data.getTenantId());
        entity.setVersion(data.getVersion());
        entity.setLastUpdated(data.getLastUpdated());
        return entity;
    }

}
