package com.convertlab.foundation.datapermission.model;

import lombok.Data;

@Data
public class DeleteShareRequestDto {

    private String resourceType;
    private String resourceCode;
    private String accessScope;
    private String accessCode;

}
