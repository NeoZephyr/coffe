package com.convertlab.foundation.user.service;

import com.convertlab.foundation.library.jdbc.core.OLTPJdbcTemplate;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.user.model.DpTaskDTO;
import com.convertlab.foundation.user.utils.DeptFileHeader;
import com.convertlab.foundation.user.utils.DpTaskStatus;
import com.convertlab.foundation.user.utils.DpTaskType;
import com.convertlab.foundation.user.utils.FileUsage;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.LinkedBlockingQueue;

@Slf4j
@Service
public class ExportToExcelTaskExecutorService extends TaskExecutorService {

    private final OLTPJdbcTemplate jdbcTemplate;

    private static final String allSubDeptQuerySql = "select d2.code, d2.name, d2.parent, d2.out_code from dept d1 join dept d2 " +
            "on d1.tenant_id = d2.tenant_id " +
            "where d1.tenant_id = ? and d1.code = ? " +
            "and (d2.path = d1.path or d2.path like concat(d1.path, '-%'))";

    public ExportToExcelTaskExecutorService(
            FileService fileService,
            OLTPJdbcTemplate jdbcTemplate,
            DeptTaskService deptTaskService) {
        super(fileService, deptTaskService);
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    boolean support(String type) {
        return StringUtils.equals(DpTaskType.export_to_excel.name(), type);
    }

    @Override
    public void beforeExecute(DpTaskDTO dto) {

        if (StringUtils.isEmpty(dto.getTaskDef())) {
            dto.setStatus(DpTaskStatus.failed);
            dto.setFailReason("task def is null or empty");
            return ;
        }

        Map<String, Object> taskDef = JsonUtils.instanceOfDto().convertToMap(dto.getTaskDef());

        if (!taskDef.containsKey("deptCode") || StringUtils.isEmpty((String) taskDef.get("deptCode"))) {
            dto.setStatus(DpTaskStatus.failed);
            dto.setFailReason("deptCode is null or empty");
            return ;
        }
        dto.setStatus(DpTaskStatus.processing);
    }

    @Override
    public void doExecute(DpTaskDTO dto) {
        Map<String, Object> taskDef = JsonUtils.instanceOfDto().convertToMap(dto.getTaskDef());
        Long tenantId = dto.getTenantId();
        String deptCode = taskDef.get("deptCode").toString();

        List<Map<String, Object>> deptList = jdbcTemplate.queryForList(allSubDeptQuerySql, tenantId, deptCode);

        if (deptList.isEmpty()) {
            dto.setStatus(DpTaskStatus.failed);
            dto.setFailReason("dept not found");
            return ;
        }

        Map<String, Object> codeToDeptMap = new HashMap<>();

        for (Map<String, Object> dept : deptList) {
            String code = dept.get("d2.code").toString();
            String parent = dept.get("d2.parent").toString();
            HashMap<String, Object> map = new HashMap<String, Object>() {{
                put("code", code);
                put("name", parent);
                put("parent", dept.get("d2.parent"));
                put("outCode", dept.get("d2.out_code"));
                put("children", new LinkedList<>());
            }};
            codeToDeptMap.put(dept.get("d2.code").toString(), map);

            if (codeToDeptMap.containsKey(parent) && (!Objects.equals(code, parent))) {
                ((Map<String, Object>) codeToDeptMap.get(parent)).put("children", codeToDeptMap.get(code));
            }
        }

        SXSSFWorkbook workbook=null;
        Sheet sheet;
        OutputStream outputStream = null;
        InputStream inputStream = null;

        try {
            workbook = new SXSSFWorkbook(500);
            sheet = workbook.createSheet("departments");
            int rowNum = 0;

            Row header = sheet.createRow(rowNum++);
            header.createCell(0, CellType.STRING).setCellValue(DeptFileHeader.CODE_TEXT);
            header.createCell(1, CellType.STRING).setCellValue(DeptFileHeader.NAME_TEXT);
            header.createCell(2, CellType.STRING).setCellValue(DeptFileHeader.PARENT_CODE_TEXT);

            Queue<Map<String, Object>> queue = new LinkedBlockingQueue<>();
            queue.offer((Map<String, Object>) codeToDeptMap.get("deptCode"));

            while (!queue.isEmpty()) {
                Map<String, Object> dept = queue.poll();

                Row row = sheet.createRow(rowNum++);

                // 导出外部编码、名称、上级组织的外部编码
                row.createCell(0, CellType.STRING).setCellValue(dept.get("outCode").toString());
                row.createCell(1, CellType.STRING).setCellValue(dept.get("name").toString());
                row.createCell(2, CellType.STRING).setCellValue(((Map<String, Object>) codeToDeptMap.get(dept.get("parent"))).get("outCode").toString());
            }

            String date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH_mm_ss"));

            File tmpFile = File.createTempFile("department-export-" + tenantId, ".xlsx");
            tmpFile.deleteOnExit();

            outputStream = Files.newOutputStream(tmpFile.toPath());
            workbook.write(outputStream);

            log.info("[ D&P ] write to tmp file " + tmpFile.getAbsolutePath());

            inputStream = new BufferedInputStream(Files.newInputStream(tmpFile.toPath()));

            log.info("[ D&P ] upload excel file $fileName");

            Map<String, Object> attachment = fileService.upload(String.format("departments_%s.xlsx", date), inputStream,
                    "application/octet-stream", tmpFile.length(), FileUsage.EXPORT);

            if (Objects.nonNull(attachment)) {
                dto.setStatus(DpTaskStatus.finished);
                dto.setAttachmentId((Long) attachment.get("id"));
            } else {
                dto.setStatus(DpTaskStatus.failed);
                dto.setFailReason("Attachment is empty");
            }
        } catch (Exception ex) {
            log.error("[ D&P ] 导出组织树失败, " + ex.getMessage(), ex);
            dto.setStatus(DpTaskStatus.failed);
            dto.setFailReason(ex.getMessage());
        } finally {
            try {
                if (Objects.nonNull(outputStream)) {
                    outputStream.close();
                }
                if (Objects.nonNull(inputStream)) {
                    inputStream.close();
                }

                if (Objects.nonNull(workbook)) {
                    workbook.close();
                }
            } catch (IOException e) {
                log.error(e.getMessage(), e);
            }
        }
    }
}
