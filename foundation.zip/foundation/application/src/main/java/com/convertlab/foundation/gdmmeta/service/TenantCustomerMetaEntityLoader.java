package com.convertlab.foundation.gdmmeta.service;


import javax.annotation.Nullable;

import com.convertlab.foundation.gdmmeta.mybatis.service.CustomerMetaService;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHolder;

/**
 * 租户级别的Entity Meta Layer处理服务。
 * 主要添加了获取 tenantId 的默认方法。
 *
 */
public abstract class TenantCustomerMetaEntityLoader implements GdmEntityLoader {


    protected CustomerMetaService customerMetaService;
    protected ConfigMetaProvider configMetaProvider;

    protected TenantCustomerMetaEntityLoader(CustomerMetaService customerMetaService, ConfigMetaProvider configMetaProvider) {
        this.customerMetaService = customerMetaService;
        this.configMetaProvider = configMetaProvider;
    }
    @Nullable
    Long getTenantId() {
        return TenantContextHolder.getTenantId();
    }


}
