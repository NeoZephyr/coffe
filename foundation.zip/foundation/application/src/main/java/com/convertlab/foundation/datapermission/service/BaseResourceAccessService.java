package com.convertlab.foundation.datapermission.service;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.convertlab.foundation.datapermission.entity.BaseResourceAccessEntity;
import com.convertlab.foundation.library.datapermission.ResourceAccessDto;
import com.convertlab.foundation.library.datapermission.GrantedSubjectType;

import java.util.List;
import java.util.Map;


public interface BaseResourceAccessService {

    //insert
    @Nullable
    BaseResourceAccessEntity save(String tableName, ResourceAccessDto dto);

    void batchSave(String tableName, List<ResourceAccessDto> dtos);

    //update
    void update(String tableName, String uuid, ResourceAccessDto dto);

    void batchUpdate(String tableName, List<ResourceAccessDto> dtos);

    //upsert
    void upsert(String tableName, ResourceAccessDto dto);

    void batchUpsert(String tableName, List<ResourceAccessDto> dtos);

    //get by id
    @Nullable
    BaseResourceAccessEntity getById(String tableName, String uuid);

    void deleteById(String tableName, String uuid);

    void batchDelete(@Nonnull String tableName, List<BaseResourceAccessEntity> entities);

    //remove by resource type and resource code, in case resource is deleted
    void delete(String tableName, String resourceType, String resourceCode);

    //remove by resource type and resource code and granted subject type and granted subject code, in case share is reverted
    void delete(String tableName, String resourceType, String resourceCode, GrantedSubjectType grantedSubjectType, String grantedSubjectCode);

    //remove by resource type and granted subject type and granted subject code in case granted subject is deleted
    void delete(String tableName, String resourceType, GrantedSubjectType grantedSubjectType, String grantedSubjectCode);

    void delete(String tableName, GrantedSubjectType grantedSubjectType, String grantedSubjectCode);

    //find list of BaseResourceAccessEntity by resource type, resource code, granted subject type, granted subject code
    @Nullable
    List<BaseResourceAccessEntity> list(String tableName, String resourceType, String resourceCode, GrantedSubjectType grantedSubjectType, String grantedSubjectCode);

    //find list of BaseResourceAccessEntity by resource type, resource code
    @Nullable
    List<BaseResourceAccessEntity> list(String tableName, String resourceType, String resourceCode);

    @Nullable
    List<BaseResourceAccessEntity> list(String tableName, String resourceType, List<String> resourceCodeList);

    @Nullable
    List<BaseResourceAccessEntity> list(String tableName, String resourceType, Map<GrantedSubjectType, List<String>> grantedDataMap);

    //find list of BaseResourceAccessEntity by resource type, granted subject type, list of granted subject code
    @Nullable
    List<BaseResourceAccessEntity> list(String tableName, String resourceType, GrantedSubjectType grantedSubjectType, List<String> grantedSubjectCodeList);

    BaseResourceAccessEntity getByKey(String tableName, String resourceType, String resourceCode, GrantedSubjectType grantedSubjectType, String grantedSubjectCode, String grantedReason);
}