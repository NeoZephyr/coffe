package com.convertlab.foundation.datapermission.model;

import io.swagger.v3.oas.annotations.Hidden;
import lombok.Data;

import javax.validation.constraints.Size;
import java.util.List;
import java.util.Map;

@Data
public class DpDatapermissionRuleDto {

    @Hidden
    private Long id;
    @Size(max = 64)
    private String name;
    private Map<String, Object> filter;
    private List<String> deptCodes;
    @Hidden
    private String status;
    private String profileName;
    private Map<String, Object> ignoredBusinessInfo;

}
