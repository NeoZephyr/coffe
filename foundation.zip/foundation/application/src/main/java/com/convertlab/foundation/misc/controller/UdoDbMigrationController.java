package com.convertlab.foundation.misc.controller;

import javax.annotation.Nonnull;

import com.convertlab.foundation.misc.service.DynamicJdbcTemplate;
import com.convertlab.foundation.misc.service.UdoDbMigrationService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;


@RequiredArgsConstructor
@Deprecated
public class UdoDbMigrationController {
    private static final String ALL_SU = "all";
    @Nonnull
    private final UdoDbMigrationService udoDbMigrationService;
    @Nonnull
    private final DynamicJdbcTemplate jdbcTemplate;

    @Nonnull
    @GetMapping("fk/{su}")
    @Operation(summary = "Migrate UDO FK", description = "Mysql step 3")
    public String getFkMigrationSqls(@PathVariable String su) {
        if (ALL_SU.equals(su)) {
            return formatSqlList("migrating udo fk", udoDbMigrationService.getAllFkMigrationSqls());
        } else {
            return formatSqlList("migrating udo fk", udoDbMigrationService.getFkMigrationSqls(su));
        }
    }

    @Nonnull
    @GetMapping("meta/{su}")
    @Operation(summary = "Migrate UDO Meta per SU", description = "Mysql step 4, Kudu step 4")
    public String getMetaMigrationSqls(@PathVariable String su) {
        return formatSqlList("migrating udo meta", udoDbMigrationService.getMetaMigrationSqls(su));
    }

    @Nonnull
    @GetMapping("meta/table/copy")
    @Operation(summary = "Copy UDO meta for KUDU", description = "Kudu step 2")
    public String getCopyTableMetasSqls() {
        return formatSqlList("Copying udo table meta from MySQL", udoDbMigrationService.getCopyTableMetasSqls());
    }

    @Nonnull
    protected String formatSqlList(String subject, @Nonnull Map<String, List<String>> map) {
        StringBuilder sb = new StringBuilder();
        sb.append("-- ").append(subject).append(" --\n");
        sb.append("\n");
        map.forEach((k, v) -> {
            sb.append("-- ").append(k).append("\n");
            v.forEach(sql -> {
                sb.append(sql).append(";\n");
            });
            sb.append("\n");
        });
        return sb.toString();
    }
}
