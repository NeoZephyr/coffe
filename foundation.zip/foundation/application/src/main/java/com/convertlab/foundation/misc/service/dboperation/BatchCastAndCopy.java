package com.convertlab.foundation.misc.service.dboperation;

import com.convertlab.foundation.library.sqlprocessor.SQLDialect;
import com.convertlab.foundation.misc.dto.CastAndCopyColumnRequest;
import java.sql.Connection;

public class BatchCastAndCopy extends AbstractBatchDbOperation {
    public BatchCastAndCopy(CastAndCopyColumnRequest args, Connection connection, SQLDialect sqlDialect) {
        super(args, connection, sqlDialect);
    }

    @Override
    protected String buildBatchSql(CastAndCopyColumnRequest args, long startId, long endId) {
        String sql = "update `" + args.getTableName() + "` /*+_maxwell_ignore_*/ set `" + args.getToColumn() + "` = " + castFunctionToSql(args.getCastFunction(), args.getFromColumn(), sqlDialect);
        sql += buildWhere(args);
        sql += " and " + args.getPkColumnName() + " > " + startId;
        sql += " and " + args.getPkColumnName() + " <= " + endId;
        return sql;
    }
}
