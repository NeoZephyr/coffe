package com.convertlab.foundation.kvstore.dto;

import javax.annotation.Nonnull;

import lombok.Data;
import lombok.ToString;

import java.util.HashMap;
import java.util.Map;

@Data
public class KeyValuesPair {
    private String id;

    private KvPair kvMapping;

    public KeyValuesPair(){
        super();
        this.kvMapping = new KvPair(new HashMap<>());
    }

    public KeyValuesPair(String id){
        super();
        this.id = id;
        this.kvMapping = new KvPair(new HashMap<>());
    }

    public KeyValuesPair(String id, @Nonnull Map<String, Object> data) {
        super();
        this.id = id;
        this.kvMapping = new KvPair(data);
    }

    @Nonnull
    @Override
    public String toString() {
        StringBuilder stringBuffer = new StringBuilder();
        stringBuffer.append("{\"id\": \"" + id + "\", ");
        stringBuffer.append("\"kvMapping\": [");
        Object [] keys =kvMapping.keySet().toArray();
        for(int i=0; i<keys.length; i++){
            Object columnValue =kvMapping.get(keys[i]);
            if(columnValue != null){
                if(columnValue instanceof String){
                    stringBuffer.append("{\"" + keys[i] + "\":\"" + columnValue + "\"}");
                }else{
                    stringBuffer.append("{\"" + keys[i] + "\":" + columnValue + "}");
                }
                if(i<keys.length-1){
                    stringBuffer.append(", ");
                }
            }
        }
        stringBuffer.append("]}");
        return stringBuffer.toString();
    }
}
