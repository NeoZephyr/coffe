package com.convertlab.foundation.metahealth.checker;

import com.convertlab.foundation.libaray.meta.health.Issue;
import com.convertlab.foundation.libaray.meta.health.MetaChecker;
import com.convertlab.foundation.libaray.meta.health.annotation.MetaCheckerAnnotation;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.gdmmeta.model.table.GdmColumn;
import com.convertlab.foundation.library.gdmmeta.model.table.GdmTable;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.convertlab.foundation.libaray.meta.health.BasicMetaValidationRule.*;

@MetaCheckerAnnotation
@RequiredArgsConstructor
public class GdmEntityChecker implements MetaChecker<GdmEntity> {
    private final GsMetaClient gsMetaClient;

    @Override
    public List<Issue> check(@Nonnull GdmEntity entity) {
        List<Issue> issues = new ArrayList<>();

        String entityName = entity.getEntityName();
        List<GdmField> fields = entity.getFields();
        if (CollectionUtils.isEmpty(fields)) {
            issues.add(RULE_03_002.toIssue(entityName));
        }

        String tableName = entity.getDbTableName();
        GdmTable table = gsMetaClient.getTable(tableName);
        if (table == null) {
            issues.add(RULE_03_001.toIssue(entityName));
        } else {
            Optional<String> wrongFields = fields.stream().filter(field -> {
                        String dbColumnName = field.getDbColumnName();
                        GdmColumn column = table.getColumnByName(dbColumnName);
                        return column == null;
                    }).map(GdmField::getFieldName)
                    .reduce((x, y) -> x + "," + y);
            wrongFields.ifPresent(s -> issues.add(RULE_03_003.toIssue(entityName, s, tableName)));
        }

        String pk = entity.getPrimaryKeyField();
        if(StringUtils.isNotBlank(pk)) {
            GdmField pkField = entity.getFieldsMap().get(pk);
            if(pkField == null) {
                issues.add(RULE_03_004.toIssue(entityName, pk));
            }
        }
        return issues;
    }
}
