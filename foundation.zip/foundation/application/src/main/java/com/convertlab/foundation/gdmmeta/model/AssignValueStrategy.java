package com.convertlab.foundation.gdmmeta.model;

public interface AssignValueStrategy <T>{
    T replaceOrAddIfNotNull (T overlay, GdmObjectMerger gdmObjectMerger);
    T unsetIfNotNull (T overlay, GdmObjectMerger gdmObjectMerger);
    default T replace (T overlay, GdmObjectMerger gdmObjectMerger) {
        throw new UnsupportedOperationException();
    }
}
