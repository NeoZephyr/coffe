package com.convertlab.foundation.misc.job;

import com.convertlab.data.job.core.biz.model.BizJobRunResult;
import com.convertlab.data.job.core.biz.model.ReturnCode;
import com.convertlab.data.job.core.biz.model.ReturnT;
import com.convertlab.data.job.core.constants.DataJobConstants;
import com.convertlab.data.job.core.context.ClJobContext;
import com.convertlab.data.job.core.enums.ClFailStrategyEnum;
import com.convertlab.data.job.core.handler.annotation.ClJob;
import com.convertlab.data.job.core.util.data.BizJobClient;
import com.convertlab.data.job.core.util.data.JobData;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.convertlab.foundation.library.multitenancy.context.TemporaryTenantContext;
import com.convertlab.foundation.library.redis.annotation.RedisLock;
import com.convertlab.foundation.library.utils.JsonUtils;
import com.convertlab.foundation.library.utils.Try;
import com.convertlab.foundation.misc.dto.CastAndCopyColumnRequest;
import com.convertlab.foundation.misc.entity.GdmColumnRecycle;
import com.convertlab.foundation.misc.service.GdmColumnRecycleService;
import com.convertlab.foundation.misc.service.OptimizeUdoFkService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.convertlab.foundation.misc.entity.GdmColumnRecycle.STATUS_RECYCLED;
import static com.convertlab.foundation.misc.entity.GdmColumnRecycle.STATUS_RECYCLE_FAILED;

@Slf4j
@Component
@RequiredArgsConstructor
public class OptimizeUdoFkAutoRunner {
    private static final String JOB_GDM_COLUMN_RECYCLE = "gdm_column_auto_recycle";
    @Value("${spring.application.name}")
    private String appName;
    private final GsMetaClient gsMetaClient;
    private final OptimizeUdoFkService optimizeUdoFkService;
    private final GdmColumnRecycleService recycleService;
    private final BizJobClient bizJobClient;

    @RedisLock(key = "ScanUdoFkJob", waitTime = 1, isTenantIsolation = false)
    public Map<Long, List<Pair<String, GdmField>>> scan() {
        log.info("ScanUdoFkJob is running...");
        List<Long> allTenants = optimizeUdoFkService.getTenants();
        if (CollectionUtils.isEmpty(allTenants)) {
            log.warn("Not tenant found");
            return new HashMap<>();
        }
        Map<Long, List<Pair<String, GdmField>>> result = new HashMap<>();
        allTenants.forEach(tenantId -> {
            List<Pair<String, GdmField>> toBeOptimized = scan(tenantId);
            if (!CollectionUtils.isEmpty(toBeOptimized)) {
                result.put(tenantId, toBeOptimized);
            }
        });

        log.info("ScanUdoFkJob is done");
        return result;
    }

    private List<Pair<String, GdmField>> scan(Long tenantId) {
        log.info("ScanUdoFkJob in tenant " + tenantId + " is running...");
        List<Pair<String, GdmField>> result;
        try (TemporaryTenantContext ignored = new TemporaryTenantContext(tenantId)) {
            result = optimizeUdoFkService.scan();
        }

        log.info("ScanUdoFkJob in tenant " + tenantId + " is done");
        return result;
    }

    @RedisLock(key = "OptimizeUdoFkJob", waitTime = 1, isTenantIsolation = false)
    public void autoRun() {
        log.info("OptimizeUdoFkJob is running...");
        List<Long> allTenants = optimizeUdoFkService.getTenants();
        if (CollectionUtils.isEmpty(allTenants)) {
            log.warn("Not tenant found");
            return;
        }
        allTenants.forEach(this::autoRun);

        startAutoColumnRecycleJob();
        log.info("OptimizeUdoFkJob is done");
    }

    private void autoRun(Long tenantId) {
        log.info("OptimizeUdoFkJob in tenant " + tenantId + " is running...");

        try (TemporaryTenantContext ignored = new TemporaryTenantContext(tenantId)) {
            List<Pair<String, GdmField>> toBeOptimized = optimizeUdoFkService.scan();
            if (CollectionUtils.isEmpty(toBeOptimized)) {
                log.info("Nothing to be optimized in tenant {}", tenantId);
                return;
            }
            log.info("Start optimizing tenant {}", tenantId);
            optimize(toBeOptimized);
        }

        log.info("OptimizeUdoFkJob in tenant " + tenantId + " is done");
    }

    private void optimize(List<Pair<String, GdmField>> toBeOptimized) {
        toBeOptimized.forEach(args -> Try.logAndIgnoreException(() -> {
            String entityName = args.getLeft();
            GdmEntity entity = gsMetaClient.getEntity(entityName);
            GdmField field = args.getRight();
            optimizeUdoFkService.optimize(entity, field);
        }));
    }

    public void optimize(String entityName, String fieldName) {
        GdmEntity entity = gsMetaClient.getEntity(entityName);
        if (entity == null) {
            throw new IllegalStateException("Unknown entity " + entityName);
        }
        GdmField field = entity.getFieldsMap().get(fieldName);
        if (field == null) {
            throw new IllegalStateException("Unknown field " + fieldName + " in entity " + entityName);
        }
        optimizeUdoFkService.optimize(entity, field);
    }

    protected void startAutoColumnRecycleJob() {
        Map<String, String> jobParams = new HashMap<>();
        String bizUuid = UUID.randomUUID().toString();
        String jobType = "JOB_004_GDM_COLUMN_RECYCLE";
        JobData.JobDataBuilder jobDataBuilder = JobData.builder()
                .jobType(jobType)
                .bizUuid(bizUuid)
                .jobNo(bizJobClient.getBizJobNo(jobType, bizUuid))
                .appName(appName)
                .jobHandler(JOB_GDM_COLUMN_RECYCLE)
                .failStrategy(ClFailStrategyEnum.CONTINUE)
                .timeout(36000L)
                .jobParameters(JsonUtils.instance().obj2Json(jobParams, false));
        ReturnT<BizJobRunResult> createJobResult = bizJobClient.createAndStartBizJob(jobDataBuilder.build());
        if (createJobResult.getCode() != ReturnCode.SUCCESS) {
            log.error("register AutoColumnRecycle job failed {}, {}", createJobResult.getCode(), createJobResult.getMsg());
        } else {
            log.info("succeed to start auto column recycle job {}", JsonUtils.instanceOfDto().obj2Json(createJobResult));
        }
    }

    @ClJob(value = JOB_GDM_COLUMN_RECYCLE)
    public void autoColumnRecycleJob() {
        log.info("auto column recycle running... ");
        ClJobContext clJobContext = ClJobContext.getClJobContext();
        try {
            autoColumnRecycle();
            bizJobClient.updateBizJobStatus(clJobContext, DataJobConstants.STATUS_FINISHED);
        } catch (Throwable t) {
            bizJobClient.updateBizJobStatus(clJobContext, DataJobConstants.STATUS_FAIL);
        }
        log.info("auto column recycle end ");
    }

    public void autoColumnRecycle() {
        log.info("auto column recycle running... ");
        List<GdmColumnRecycle> toBeRecycled = recycleService.findAllToBeRecycled();
        if (!CollectionUtils.isEmpty(toBeRecycled)) {
            toBeRecycled.forEach(r -> {
                recycle(r);
            });
        }
        log.info("auto column recycle end ");
    }

    private void recycle(GdmColumnRecycle recycle) {
        try (TemporaryTenantContext ignored = new TemporaryTenantContext(recycle.getTenantId())) {
            CastAndCopyColumnRequest args = new CastAndCopyColumnRequest();
            GdmEntity entity = gsMetaClient.getEntity(recycle.getEntityName());
            if (entity != null) {
                args.setObjId(entity.getTablePartition().getIdentifierValue());
                args.setTableName(recycle.getTableName());
                args.setFromColumn(recycle.getDbColumnName());
                try {
                    optimizeUdoFkService.unsetColumn(args);
                    recycleService.updateGdmColumnRecycleStatus(recycle.getId(), STATUS_RECYCLED, null);
                } catch (Exception e) {
                    log.error("Failed to unset column " + JsonUtils.instanceOfDto().obj2Json(args));
                    recycleService.updateGdmColumnRecycleStatus(recycle.getId(), STATUS_RECYCLE_FAILED, e.getMessage());
                }
            }
        }
    }
}
