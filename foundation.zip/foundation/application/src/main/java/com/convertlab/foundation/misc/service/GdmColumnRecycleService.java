package com.convertlab.foundation.misc.service;

import com.convertlab.foundation.misc.entity.GdmColumnRecycle;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.convertlab.foundation.misc.service.OptimizeUdoFkService.getMainConnection;

@Service
@RequiredArgsConstructor
@Slf4j
public class GdmColumnRecycleService {
    private static final String SQL_FIND_TO_BE_RECYCLE = "select id, tenant_id, entity_name, table_name, field_name, db_column_name, status, error_msg, date_created, last_updated from gdm_column_recycle where status = 0";
    private static final String SQL_CREATE_RECYCLE = "insert into gdm_column_recycle (tenant_id, entity_name, table_name, field_name, db_column_name, status, error_msg) values (?, ?, ?, ?, ?, ?, ?)";
    private static final String SQL_UPDATE_RECYCLE_STATUS = "update gdm_column_recycle set status=?, error_msg=?, last_updated=now() where id=?";
    private final DataSource dynamicDataSource;

    public List<GdmColumnRecycle> findAllToBeRecycled() {
        try (Connection connection = getMainConnection(dynamicDataSource)) {
            try (PreparedStatement pstmt = connection.prepareStatement(SQL_FIND_TO_BE_RECYCLE)) {
                try (ResultSet rs = pstmt.executeQuery()) {
                    List<GdmColumnRecycle> result = new ArrayList<>();
                    while (rs.next()) {
                        GdmColumnRecycle recycle = rsToEntity(rs);
                        result.add(recycle);
                    }
                    return result;
                }
            }
        } catch (SQLException e) {
            log.error("Failed to findAllToBeRecycled", e);
            throw new IllegalStateException("Failed to findAllToBeRecycled", e);
        }
    }

    public boolean createGdmColumnRecycle(GdmColumnRecycle recycle) {
        try (Connection connection = getMainConnection(dynamicDataSource)) {
            try (PreparedStatement pstmt = connection.prepareStatement(SQL_CREATE_RECYCLE)) {
                pstmt.setLong(1, recycle.getTenantId());
                pstmt.setString(2, recycle.getEntityName());
                pstmt.setString(3, recycle.getTableName());
                pstmt.setString(4, recycle.getFieldName());
                pstmt.setString(5, recycle.getDbColumnName());
                pstmt.setInt(6, recycle.getStatus());
                pstmt.setString(7, recycle.getErrorMsg());
                return pstmt.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            log.error("Failed to createGdmColumnRecycle", e);
            throw new IllegalStateException("Failed to createGdmColumnRecycle", e);
        }
    }

    private GdmColumnRecycle rsToEntity(ResultSet rs) throws SQLException {
        Long id = rs.getLong("id");
        Long tenantId = rs.getLong("tenant_id");
        String entityName = rs.getString("entity_name");
        String tableName = rs.getString("table_name");
        String fieldName = rs.getString("field_name");
        String dbColumnName = rs.getString("db_column_name");
        Integer status = rs.getInt("status");
        String errorMsg = rs.getString("error_msg");
        GdmColumnRecycle recycle = new GdmColumnRecycle();
        recycle.setId(id);
        recycle.setTenantId(tenantId);
        recycle.setEntityName(entityName);
        recycle.setTableName(tableName);
        recycle.setFieldName(fieldName);
        recycle.setDbColumnName(dbColumnName);
        recycle.setStatus(status);
        recycle.setErrorMsg(errorMsg);
        return recycle;
    }

    public boolean updateGdmColumnRecycleStatus(Long id, int status, String errorMsg) {
        try (Connection connection = getMainConnection(dynamicDataSource)) {
            try (PreparedStatement pstmt = connection.prepareStatement(SQL_UPDATE_RECYCLE_STATUS)) {
                pstmt.setInt(1, status);
                pstmt.setString(2, errorMsg);
                pstmt.setLong(3, id);
                return pstmt.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            log.error("Failed to updateGdmColumnRecycleStatus", e);
            throw new IllegalStateException("Failed to updateGdmColumnRecycleStatus", e);
        }
    }
}
