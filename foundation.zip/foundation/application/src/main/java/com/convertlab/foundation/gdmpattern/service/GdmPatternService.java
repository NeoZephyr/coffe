package com.convertlab.foundation.gdmpattern.service;

import javax.annotation.Nonnull;

import com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto;
import com.convertlab.foundation.library.constant.CommonErrors;
import com.convertlab.foundation.library.exception.business.BackendException;
import com.google.common.collect.Maps;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.convertlab.foundation.api.gdm.pattern.dto.GdmPatternDto.*;

@Service
public class GdmPatternService {
  private static final Map<String, GdmPatternDto> patternMap = initGdmPatternMap();

    @Nonnull
    public List<GdmPatternDto> listGdmPatterns() {
        return new ArrayList<>(patternMap.values());
    }

    @Nonnull
    public GdmPatternDto getGdmPattern(String patternName) {
        GdmPatternDto pattern = patternMap.get(patternName);
        if (pattern == null) {
            throw new BackendException(CommonErrors.DATA_NOT_FOUND, "Gdm pattern - " + patternName + " is not found");
        }
        return pattern;
    }

    @Nonnull
    private static Map<String, GdmPatternDto> initGdmPatternMap() {
        Map<String, GdmPatternDto> patternMap = Maps.newHashMap();
        patternMap.put(PATTERN_PRIMARY_PROFILE.getName(), PATTERN_PRIMARY_PROFILE);
        patternMap.put(PATTERN_GENERAL_PROFILE.getName(), PATTERN_GENERAL_PROFILE);
        patternMap.put(PATTERN_AD_HOC.getName(), PATTERN_AD_HOC);
        patternMap.put(PATTERN_PLATFORM_MEMBER.getName(), PATTERN_PLATFORM_MEMBER);
        patternMap.put(PATTERN_OMNI_MEMBER.getName(), PATTERN_OMNI_MEMBER);
        patternMap.put(PATTERN_MEMBER_CARD.getName(), PATTERN_MEMBER_CARD);
        return patternMap;
    }
}
