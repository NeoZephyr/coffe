package com.convertlab.foundation.datapermission.model;

import lombok.Data;

@Data
public class ResourceBatchDeleteShareResponseDto {

    public static final String STATUS_SUCCESS = "success";
    public static final String STATUS_FAILED = "failed";

    private String status;
}

