package com.convertlab.foundation.gdmdata.service;

import com.convertlab.foundation.api.gdmdata.GdmData;
import com.convertlab.foundation.api.gdmdata.GenericGdmModel;
import com.convertlab.foundation.gdmdata.mapper.GdmDataMapper;
import com.convertlab.foundation.library.gdmmeta.model.FieldType;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.convertlab.foundation.api.gdmdata.GenericGdmModel.DEFAULT_ID_FIELD;

@Service
public class GenericGdmModelService {
    private final GdmDataMapper gdmDataMapper;
    private static final String SELECT_ALL = "*";

    public GenericGdmModelService(GdmDataMapper gdmDataMapper) {
        this.gdmDataMapper = gdmDataMapper;
    }

    @Nullable
    public GenericGdmModel selectById(@Nonnull GdmEntity gdmEntity, Object id, @Nonnull List<String> selectList) {
        GdmField pkColumn = GenericGdmModel.getPkColumn(gdmEntity);
        id = convertTypeIfNecessary(pkColumn, id);
        List<String> newSelectList = ensurePkInSelectList(gdmEntity, pkColumn, selectList);
        Map<String, Object> result = gdmDataMapper.selectById(gdmEntity.getEntityName(), newSelectList, pkColumn.getFieldName(), id);
        return result == null ? null : GenericGdmModel.buildFromMap(result, gdmEntity, GenericGdmModel.class);
    }

    @Nonnull
    public List<GenericGdmModel> selectByIds(@Nonnull GdmEntity gdmEntity, List<Object> ids, @Nonnull List<String> selectList) {
        GdmField pkColumn = GenericGdmModel.getPkColumn(gdmEntity);
        ids = ids.stream()
                .map(id -> convertTypeIfNecessary(pkColumn, id))
                .collect(Collectors.toList());
        List<String> newSelectList = ensurePkInSelectList(gdmEntity, pkColumn, selectList);
        List<Map<String, Object>> result = gdmDataMapper.selectByIds(gdmEntity.getEntityName(), newSelectList, pkColumn.getFieldName(), ids);
        return result.stream()
                .map(x -> GenericGdmModel.buildFromMap(x, gdmEntity, GenericGdmModel.class))
                .collect(Collectors.toList());
    }

    @Nonnull
    public List<GenericGdmModel> selectByParams(@Nonnull GdmEntity gdmEntity, List<String> selectList, Map<String, Object> params, Integer offset, Integer limit) {
        GdmField pkColumn = GenericGdmModel.getPkColumn(gdmEntity);
        List<String> newSelectList = ensurePkInSelectList(gdmEntity, pkColumn, selectList);
        Map<String, Object> newParams = removeUnknownParams(gdmEntity, params);
        List<Map<String, Object>> result = gdmDataMapper.selectByParams(gdmEntity.getEntityName(), newSelectList, newParams, offset, limit);
        return result.stream()
                .map(x -> GenericGdmModel.buildFromMap(x, gdmEntity, GenericGdmModel.class))
                .collect(Collectors.toList());
    }

    @Nonnull
    public GdmData insert(@Nonnull GenericGdmModel entity) {
        if (entity.getPk() == null) {
            throw new IllegalArgumentException("TODO auto-generate id");
        }
        GdmField pkColumn = entity.getPkColumn();
        List<String> columns = Lists.newArrayList();
        List<Object> values = Lists.newArrayList();
        columns.add(pkColumn.getFieldName());
        values.add(entity.getPk());
        entity.getProps().forEach((k, v) -> {
            if (v != null) {
                columns.add(k);
                values.add(v);
            }
        });
        gdmDataMapper.insert(entity.getGdmEntity().getEntityName(), columns, values);
        return selectById(entity.getGdmEntity(), entity.getPk(), Lists.newArrayList(SELECT_ALL)).toGdmData();
    }

    public GdmData deleteById(@Nonnull GdmEntity gdmEntity, @Nullable Object id) {
        if (id == null) {
            throw new IllegalArgumentException("id is null");
        }
        GdmField pkColumn = GenericGdmModel.getPkColumn(gdmEntity);
        GenericGdmModel gdmModel = selectById(gdmEntity, id, Lists.newArrayList(SELECT_ALL));
        if(gdmModel==null) {
            throw new IllegalArgumentException("data not found for id "+id);
        }
        id = convertTypeIfNecessary(pkColumn, id);
        gdmDataMapper.deleteById(gdmEntity.getEntityName(), pkColumn.getFieldName(), id);
        return gdmModel.toGdmData();
    }

    public int deleteByIds(@Nonnull GdmEntity gdmEntity, List<Object> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return 0;
        }
        GdmField pkField = GenericGdmModel.getPkColumn(gdmEntity);
        ids = ids.stream()
                .map(id -> convertTypeIfNecessary(pkField, id))
                .collect(Collectors.toList());
        return gdmDataMapper.deleteByIds(gdmEntity.getEntityName(), pkField.getFieldName(), ids);
    }

    public GdmData updateById(@Nonnull GenericGdmModel entity) {
        if (CollectionUtils.isEmpty(entity.getProps())) {
            return entity.toGdmData();
        }
        GdmField pkColumn = entity.getPkColumn();
        gdmDataMapper.updateById(entity.getGdmEntity().getEntityName(), pkColumn.getFieldName(), entity.getPk(), entity.getProps());
        return selectById(entity.getGdmEntity(), entity.getPk(), Lists.newArrayList(SELECT_ALL)).toGdmData();
    }

    @Nonnull
    private List<String> ensurePkInSelectList(@Nonnull GdmEntity gdmEntity, @Nonnull GdmField pkColumn, @Nonnull List<String> selectList) {
        List<String> list;
        GenericGdmModel gdmModel = new GenericGdmModel(gdmEntity);
        if (CollectionUtils.isEmpty(selectList)) {
            list = Lists.newArrayList();
        } else if (selectList.size() == 1 && selectList.get(0).equalsIgnoreCase(SELECT_ALL)) {
            list = gdmEntity.getFields().stream()
                    .filter(field -> !gdmModel.isPrimaryKey(field))
                    .map(x -> StringUtils.wrap(x.getFieldName(), "`"))
                    .collect(Collectors.toList());
        } else {
            list = selectList.stream()
                    .filter(x -> !DEFAULT_ID_FIELD.equalsIgnoreCase(x) && !pkColumn.getFieldName().equalsIgnoreCase(x))
                    .map(field -> StringUtils.wrap(gdmModel.getGdmField(field).getFieldName(), "`"))
                    .collect(Collectors.toList());
        }
        list.add(StringUtils.wrap(pkColumn.getFieldName(), "`") + " as " + DEFAULT_ID_FIELD);
        return list;
    }

    @Nonnull
    private Map<String, Object> removeUnknownParams(GdmEntity gdmEntity, Map<String, Object> params) {
        Map<String, Object> map = Maps.newHashMap();
        params.forEach((k, v) -> {
            GdmField gdmField = gdmEntity.getFieldsMap().get(k);
            if (gdmField != null) {
                map.put(k, convertTypeIfNecessary(gdmField, v));
            }
        });
        return map;
    }

    @Nullable
    private Object convertTypeIfNecessary(@Nonnull GdmField gdmField, Object value) {
        FieldType fieldType = gdmField.getFieldType();
        return GenericGdmModel.convertTypeIfNecessary(fieldType, value);
    }
}
