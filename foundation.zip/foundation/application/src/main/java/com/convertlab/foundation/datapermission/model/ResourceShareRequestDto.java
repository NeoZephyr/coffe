package com.convertlab.foundation.datapermission.model;

import javax.annotation.Nonnull;

import com.convertlab.foundation.library.datapermission.GrantedPermission;
import com.convertlab.foundation.library.datapermission.GrantedReason;
import com.convertlab.foundation.library.datapermission.GrantedSubjectType;
import com.convertlab.foundation.library.datapermission.ResourceAccessDto;
import lombok.Data;
import org.apache.commons.collections.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@Data
public class ResourceShareRequestDto {

        private String resourceType;

        private String resourceCode;

        private List<Integer> userIds = new ArrayList<Integer>();

        private List<String> groupCodes = new ArrayList<String>();

        private List<String> deptCodes = new ArrayList<String>();

        private String accessLevel;

        @Nonnull
        public List<ResourceAccessDto> convertToResourceAccessDTO(){

                List<ResourceAccessDto> resourceAccessDtos = new ArrayList<ResourceAccessDto>();
                if(!CollectionUtils.isEmpty(userIds)) {
                        for (Integer userId : userIds) {
                                ResourceAccessDto resourceAccessDTO = new ResourceAccessDto();
                                resourceAccessDTO.setResourceType(resourceType);
                                resourceAccessDTO.setResourceCode(resourceCode);
                                resourceAccessDTO.setGrantedSubjectType(GrantedSubjectType.SUBJECT_TYPE_USER);
                                resourceAccessDTO.setGrantedSubjectCode(userId.toString());
                                resourceAccessDTO.setGrantedPermission(convertAccessLevelToGrantedPermission(accessLevel));
                                resourceAccessDTO.setGrantedReason(GrantedReason.GRANTED_REASON_MANUAL_SHARE);
                                resourceAccessDtos.add(resourceAccessDTO);
                        }
                }


                if(!CollectionUtils.isEmpty(groupCodes)){
                        for(String groupCode : groupCodes){
                                ResourceAccessDto resourceAccessDTO = new ResourceAccessDto();
                                resourceAccessDTO.setResourceType(resourceType);
                                resourceAccessDTO.setResourceCode(resourceCode);
                                resourceAccessDTO.setGrantedSubjectType(GrantedSubjectType.SUBJECT_TYPE_GROUP);
                                resourceAccessDTO.setGrantedSubjectCode(groupCode);
                                resourceAccessDTO.setGrantedReason(GrantedReason.GRANTED_REASON_MANUAL_SHARE);
                                resourceAccessDTO.setGrantedPermission(convertAccessLevelToGrantedPermission(accessLevel));
                                resourceAccessDtos.add(resourceAccessDTO);
                        }
                }


                if(!CollectionUtils.isEmpty(deptCodes)){

                        for(String deptCode : deptCodes) {
                                ResourceAccessDto resourceAccessDTO = new ResourceAccessDto();
                                resourceAccessDTO.setResourceType(resourceType);
                                resourceAccessDTO.setResourceCode(resourceCode);
                                resourceAccessDTO.setGrantedSubjectType(GrantedSubjectType.SUBJECT_TYPE_DEPT);
                                resourceAccessDTO.setGrantedSubjectCode(deptCode);
                                resourceAccessDTO.setGrantedReason(GrantedReason.GRANTED_REASON_MANUAL_SHARE);
                                resourceAccessDTO.setGrantedPermission(convertAccessLevelToGrantedPermission(accessLevel));
                                resourceAccessDtos.add(resourceAccessDTO);
                        }
                }

                return resourceAccessDtos;
        }

        private GrantedPermission convertAccessLevelToGrantedPermission(String accessLevel){
                if(accessLevel.equals("read")){
                        return GrantedPermission.READ_ACCESS_LEVEL;
                }else if(accessLevel.equals("all")){
                        return GrantedPermission.ALL_ACCESS_LEVEL;
                }else {
                        return GrantedPermission.WRITE_ACCESS_LEVEL;
                }
        }

}
