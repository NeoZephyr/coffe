package com.convertlab.foundation.gdmmeta.model.metaobject;


import javax.annotation.Nonnull;
import java.util.*;
import java.util.stream.Collectors;

import com.convertlab.foundation.gdmmeta.model.Entity;
import com.convertlab.foundation.gdmmeta.model.Field;
import com.convertlab.foundation.gdmmeta.model.Inheritance;
import com.convertlab.foundation.gdmmeta.utils.GdmNamingUtils;
import com.convertlab.foundation.library.gdmmeta.model.ColumnType;
import com.convertlab.foundation.library.gdmmeta.model.FieldType;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.CaseFormat;

import lombok.*;
import lombok.extern.slf4j.Slf4j;

/**
 * used by system and tenant level meta;
 */
@Slf4j
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class ClickEventMetaObject implements CustomerEventMetaObject {

    private List<Prop> props;

    @Data
    @Getter
    public static class Prop {
        private String name;
        private String column;
        private ItemType type;
    }


    public enum ItemType {
        @JsonProperty("Text")
        TEXT( FieldType.String),
        @JsonProperty("Integer")
        INTEGER(FieldType.Integer),
        /**
         * flowVersion, flowId, StepId
         * 都是 Number 类型
         */
        @JsonProperty("Number")
        NUMBER(FieldType.Integer);

        private FieldType fieldType;

        ItemType(FieldType fieldType) {
            this.fieldType = fieldType;
        }

        public FieldType fieldType() {
            return this.fieldType;
        }
    }

    public Entity getEventEntity(boolean withEventFields) {
        final String entityName = "click";
        List<Field> fields = withEventFields ? getFields() : new ArrayList<>();
        Inheritance inheritance = Inheritance.newCustomerEventInheritance(true, entityName);
        Entity entity = newEventEntity(entityName, fields, inheritance);
        log.trace("clickEvent entity: {}", entity);
        return entity;
    }

    @Nonnull
    private List<Field> getFields() {
        List<Field> clickEventFields = getProps().stream().map(prop -> {
            String columnName = CaseFormat.UPPER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, prop.getColumn());
            String fieldName = GdmNamingUtils.toUnderScoreCase(prop.getName());
            Field field = Field.builder()
                    .fieldName(fieldName)
                    .dbColumnName(columnName)
                    .fieldType(prop.getType().fieldType())
                    .build();
            return field;
        }).collect(Collectors.toList());
        log.trace("clickEventFields: {}", clickEventFields);
        return clickEventFields;
    }

}
