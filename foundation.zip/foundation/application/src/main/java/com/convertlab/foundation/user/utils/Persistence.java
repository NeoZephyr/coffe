package com.convertlab.foundation.user.utils;

import javax.annotation.Nonnull;

import org.jetbrains.annotations.NotNull;
import org.springframework.data.domain.Sort;

public class Persistence {
    @Nonnull
    static public Sort lastUpdatedDesc = Sort.by(Sort.Direction.DESC, "lastUpdated");

    static final String ALPHABET = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ123456789";

    static final int BASE = ALPHABET.length();

    @Nonnull
    static String toStr(long i) {
        StringBuilder sb = new StringBuilder();
        if (i == 0) {
            return "a";
        }
        while (i > 0) {
            i = fromBase10(i, sb);
        }
        return sb.toString();
    }

    private static long fromBase10(long i, @Nonnull final StringBuilder sb) {
        long rem = i % BASE;
        sb.append(ALPHABET.charAt((int) rem));
        return i / BASE;
    }

    static public @NotNull String genGroupCode() {
        long millis = System.currentTimeMillis();

        if (millis % 10 == 0) {
            millis += 1;
        }

        millis = Long.parseLong(new StringBuilder(String.valueOf(millis)).reverse().toString());
        return toStr(millis);
    }
}
