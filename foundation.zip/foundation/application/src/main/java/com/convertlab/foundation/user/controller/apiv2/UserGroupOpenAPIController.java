package com.convertlab.foundation.user.controller.apiv2;

import javax.annotation.Nonnull;

import com.convertlab.foundation.library.webmvc.annotation.OpenApiController;
import com.convertlab.foundation.user.model.SaveUserGroupRequest;
import com.convertlab.foundation.user.model.UserGroupDto;
import com.convertlab.foundation.user.service.UserGroupService;
import org.jetbrains.annotations.NotNull;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@OpenApiController
@RequestMapping("/apiv2/userGroups")
public class UserGroupOpenAPIController {

    private final UserGroupService userGroupService;

    public UserGroupOpenAPIController(UserGroupService userGroupService) {
        this.userGroupService = userGroupService;
    }

    @Nonnull
    @PostMapping("")
    public UserGroupDto save(@RequestBody @NotNull SaveUserGroupRequest request) {
        return userGroupService.save(request);
    }
}
