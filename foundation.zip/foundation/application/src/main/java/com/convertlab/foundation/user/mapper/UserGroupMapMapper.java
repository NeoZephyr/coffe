package com.convertlab.foundation.user.mapper;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.convertlab.foundation.user.entity.UserGroup;
import com.convertlab.foundation.user.entity.UserGroupMap;
import org.springframework.stereotype.Component;

import java.util.List;


@Component
public interface UserGroupMapMapper extends BaseMapper<UserGroupMap> {
    default List<UserGroupMap> getUserGroupMapByUserId(Long userId){
        QueryWrapper<UserGroupMap> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userId);
        return this.selectList(queryWrapper);
    }

    default List<UserGroupMap> getUserGroupMapByGroupCode(String groupCode){
        QueryWrapper<UserGroupMap> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("group_code", groupCode);
        return this.selectList(queryWrapper);
    }
}
