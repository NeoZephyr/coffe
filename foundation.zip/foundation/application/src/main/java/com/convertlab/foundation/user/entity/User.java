package com.convertlab.foundation.user.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

@Data
public class User {

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @TableField(fill = FieldFill.INSERT, update = "%s+1", updateStrategy = FieldStrategy.IGNORED)
    private Long version;

//    private Instant dateCreated;


    private String email;

    private String img;


//    private Instant lastUpdated;

    private String loginName;

    private String name;

    private String passwordHash;

    private String phone;

//    private Long tenantId;

    private String status;

    private Boolean firstLogin;

    private Boolean emailVerified;

    private Boolean phoneVerified;

    private Boolean eulaAccepted;

    private Boolean visitedSettingPage;

//    private Instant lastPasswordUpdated;

    private String oauth2RegistrationId;

    private String saml2RegistrationId;

    private String ssoIdentity;

    private String wxOpenId;

}