package com.convertlab.foundation.misc.service.impl;

import com.convertlab.foundation.library.redis.localcache.L2Cache;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service("L2CacheWarmup")
public class L2CacheWarmup implements L2Cache.CacheWarmupFunction {
    @Override
    public void doLazyCacheWarmup() {
        log.info("warm up function running...");
    }
}
