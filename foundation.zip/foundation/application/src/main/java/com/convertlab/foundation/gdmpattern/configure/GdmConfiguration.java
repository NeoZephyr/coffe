package com.convertlab.foundation.gdmpattern.configure;

import com.convertlab.data.job.core.util.data.BizJobClient;
import com.convertlab.foundation.api.gdm.pattern.GdmModelClient;
import com.convertlab.foundation.api.gdm.pattern.facade.GdmMetaFacade;
import com.convertlab.foundation.api.gdm.pattern.facade.GdmProfileEventClient;
import com.convertlab.foundation.gdmdata.mapper.GdmDataMapper;
import com.convertlab.foundation.gdmmeta.service.GdmTableMetaService;
import com.convertlab.foundation.gdmpattern.custom.ColumnProvisionStrategy;
import com.convertlab.foundation.gdmpattern.custom.CustomizableTableFactory;
import com.convertlab.foundation.gdmpattern.job.GdmModelJob;
import com.convertlab.foundation.gdmpattern.job.GdmModelJobClient;
import com.convertlab.foundation.gdmpattern.service.GdmModelService;
import com.convertlab.foundation.gdmpattern.service.GdmProvisionService;
import com.convertlab.foundation.gdmpattern.service.TableProvisionService;
import com.convertlab.foundation.gdmpattern.service.feign.MigrationServiceFeignClient;
import com.convertlab.foundation.library.business.audit.AuditOperations;
import com.convertlab.foundation.library.gdmmeta.api.GdmTableApi;
import com.convertlab.foundation.library.gdmmeta.client.GdmStorageMetaRtClient;
import com.convertlab.foundation.library.gdmmeta.client.GsMetaClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Nonnull;

@Slf4j
@Configuration("GdmConfiguration")
public class GdmConfiguration {
    @Nonnull
    @Bean
    public GdmProfileEventClient gdmProfileEventClient(@Nonnull GsMetaClient gsMetaClient) {
        return new GdmProfileEventClient(gsMetaClient);
    }

    @Nonnull
    @Bean
    public GdmMetaFacade gdmMetaFacade(@Nonnull GsMetaClient gsMetaClient, @Nonnull GdmProfileEventClient gdmProfileEventClient) {
        return new GdmMetaFacade(gsMetaClient, gdmProfileEventClient);
    }

    @Bean
    public GdmModelClient gdmModelClient(GsMetaClient gsMetaClient, GdmProfileEventClient gdmProfileEventClient) {
        return new GdmModelClient(gsMetaClient, gdmProfileEventClient);
    }

    @Nonnull
    @Bean
    public GdmProvisionService gdmProvisionService(@Nonnull GdmMetaFacade gdmMetaFacade, @Nonnull ColumnProvisionStrategy columnProvisionStrategy, @Nonnull CustomizableTableFactory customizableTableFactory) {
        return new GdmProvisionService(gdmMetaFacade, columnProvisionStrategy, customizableTableFactory);
    }

    @Nonnull
    @Bean
    public GdmModelJob gdmModelJob(GdmDataMapper gdmDataMapper,
                                   BizJobClient bizJobClient,
                                   GdmModelService gdmModelService) {
        return new GdmModelJob(gdmDataMapper, bizJobClient, gdmModelService);
    }

    @Nonnull
    @Bean
    public GdmModelJobClient gdmModelJobClient(BizJobClient bizJobClient,
                                                GdmMetaFacade gdmMetaFacade,
                                                GdmStorageMetaRtClient gdmStorageMetaRtClient) {
        return new GdmModelJobClient(bizJobClient, gdmMetaFacade, gdmStorageMetaRtClient);
    }

    @Nonnull
    @Bean
    public TableProvisionService tableProvisionService(MigrationServiceFeignClient migrationServiceFeignClient, GdmTableMetaService gdmTableMetaService) {
        log.info("Initiating TableProvisionService, migrationServiceFeignClient:{}", migrationServiceFeignClient);
        return new TableProvisionService(migrationServiceFeignClient, gdmTableMetaService);
    }

    @Nonnull
    @Bean
    public GdmModelService gdmModelService(@Nonnull GdmMetaFacade gdmMetaFacade,
                                           @Nonnull GdmProvisionService gdmProvisionService,
                                           @Nonnull GdmDataMapper gdmDataMapper,
                                           @Nonnull GdmModelJobClient gdmModelJobClient,
                                           @Nonnull CustomizableTableFactory customizableTableFactory,
                                           @Nonnull AuditOperations auditOperations,
                                           @Nonnull TableProvisionService tableProvisionService) {
        return new GdmModelService(gdmMetaFacade, gdmProvisionService, gdmDataMapper, gdmModelJobClient, customizableTableFactory, auditOperations, tableProvisionService);
    }

    @Nonnull
    @Bean
    public CustomizableTableFactory customizableTableFactory() {
        String jsonFile = "meta/gdm-table/customizable-tables.json";
        return new CustomizableTableFactory(jsonFile);
    }

    @Nonnull
    @Bean
    public ColumnProvisionStrategy provisionStrategy() {
        return ColumnProvisionStrategy.STRAIGHT_FORWARD_AND_LOOK_BACK;
    }
}
