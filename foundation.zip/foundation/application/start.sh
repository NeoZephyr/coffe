#! /bin/bash

export S_LOG_DIR=${LOG_DIR}/${SERVICE_NAME}
mkdir -p ${S_LOG_DIR}/

[ -f .init_jmx_exporter.sh ] && . .init_jmx_exporter.sh

exec java ${JAVA_OPTS} \
   ${JACOCO_OPTS} \
   ${JVM_OPTS} \
   ${JMX_EXPORTER_OPTS} \
   -XX:+ExitOnOutOfMemoryError \
   -XX:+HeapDumpOnOutOfMemoryError \
   -XX:HeapDumpPath=${S_LOG_DIR}/ \
   -Xloggc:${S_LOG_DIR}/${SERVICE_NAME}.gc \
   -XX:ErrorFile=${S_LOG_DIR}/${SERVICE_NAME}_java_error%p.err \
   -Dgrails.env=${ENV} \
   -jar ${WAR} 2> >(tee -a ${S_LOG_DIR}/${SERVICE_NAME}.err)
