package com.convertlab.foundation.library.multitenancy;

public interface Constants {
    String TENANT_ID = "x_tenant_id";
}
