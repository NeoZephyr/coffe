## Requirements

* Java 8

<br>

## 功能列表

* 提供 MongoTemplate 的定制子类 `TenantIgnoredMongoTemplate` 实现多个产品线之间的数据隔离。

* 提供 MongoTemplate 的定制子类 `TenantIsolationMongoTemplate` 以 Separate Collections Per Tenant 的方式实现多租户之间的数据隔离。

* 提供 MongoTemplate 的定制子类 `TenantIsolationSharedMongoTemplate` 以 Shared Collection 的方式实现多租户之间的数据隔离。

<br>

## 如何使用

在`build.gradle`添加 gradle 依赖项：

```gradle
dependencies {
  implementation 'com.convertlab.foundation.library:mongodb-boot-starter:{version}'
}
```

在`application.yml`中通过`spring.data.mongo.*`配置 MongoDB 数据源。 具体配置请参考[Spring Data MongoDB Properties](https://docs.spring.io/spring-boot/docs/current/reference/html/application-properties.html#appendix.application-properties.data)
.

```yaml
spring:
  data:
    mongodb:
      host: ${host}
      port: ${port}
      database: ${database}
      username: ${username}
      password: ${password}
      ...
```

<br>

### 全部可配置项

```yaml
convertlab:
  mongodb:
    multi-tenancy:
      identifier:
        tenant-id:
          key: tenantId
          location: field
```

**以上配置已有默认值，如无特殊不需要指定。**

| 配置项 | 值类型 | 示例 |解释 |
| --- | :--: | :--: | :-- |
| convertlab.mongodb.multi-tenancy.identifier.tenant-id.key | string |  | 当使用 TenantIsolationSharedMongoTemplate 操作 collection 时，指定以 document 中哪一个 field 作为区分多租户的字段, 默认为 tenantId字段 |

<br>

### 使用`TenantIgnoredMongoTemplate`实现多个产品线之间的数据隔离

在代码中注入`TenantIgnoredMongoTemplate`

```java
@Autowired
private TenantIgnoredMongoTemplate tenantIgnoredMongoTemplate;
```

使用方法和原生`MongoTemplate`相同，两者之间的区别在于：使用`TenantIgnoredMongoTemplate`存储和查询数据时，会自动为 collection 增加标识产品线的前缀。

实际访问的 collection 格式为 **${product code}:${collection}**

```java
tenantIgnoredMongoTemplate.save(data, "mycollection");
```
假如当前是DMHub中的代码，那么在 MongoDB 实际存储和访问的 collection 是以下这个样子：
```text
DMH:mycollection
```

<br>

### 在多租户模式的 Spring Boot 应用中使用`TenantIsolationMongoTemplate`或`TenantIsolationSharedMongoTemplate`实现多租户数据隔离

#### TenantIsolationMongoTemplate

以 Separate Collections Per Tenant 的方式实现多租户之间的数据隔离，每个租户保持自己独立的 collection。

在代码中注入`TenantIsolationMongoTemplate`

```java
@Autowired
private TenantIsolationMongoTemplate tenantIsolationMongoTemplate;
```

使用方法和原生`MongoTemplate`相同，两者之间的区别在于：使用`TenantIsolationMongoTemplate`存储和查询数据时，会自动为 collection 增加标识产品线的前缀和标识租户的后缀。

实际访问的 collection 格式为 **${product code}:${collection}-t${租户ID}**

```java
tenantIsolationMongoTemplate.save(data, "mycollection");
```
假如当前是DMHub中的代码、当前上下文中租户ID为6、那么在 MongoDB 实际存储和访问的 collection 是以下这个样子：
```text
DMH:mycollection-t6
```

<br>

#### TenantIsolationSharedMongoTemplate

以 Shared Collection 的方式实现多租户之间的数据隔离，所有租户共享一个 collection，每个 document 包含一个 标识 tenantId 的 field。

在代码中注入`TenantIsolationSharedMongoTemplate`

```java
@Autowired
private TenantIsolationSharedMongoTemplate tenantIsolationSharedMongoTemplate;
```

使用方法和原生`MongoTemplate`相同，两者之间的区别在于：

1. 使用`TenantIsolationSharedMongoTemplate`存储和查询数据时，会自动为 collection 增加标识产品线的前缀。
2. 使用`TenantIsolationSharedMongoTemplate`存储数据时，会自动为每个 document 补充一个名为`tenantId`的 field，并赋值为当前上下文中的租户ID；查询数据时，会自动在查询条件中增加 tenantId = ? 的过滤项。

```java
tenantIgnoredMongoTemplate.save(data, "mycollection");
```

假如当前是DMHub中的代码、当前上下文中租户ID为6、那么在 MongoDB 实际存储和访问的 collection 是以下这个样子：
```text
DMH:mycollection
```
存入的 document 在业务数据以外增加了一个名为`tenantId`的 field。
```json
{
  ...
  "tenantId" : NumberInt(6),
  ...
}
```

<br>

#### MongoTemplate 及子类的比较

| 类名                                 | 产品线之间的数据隔离 | 租户之间数据隔离 | Collection 名字增加了租户后缀 | Document中添加了标识 tenantId 的Field |
|------------------------------------|------------|----------|----------------------|--------------------------------|
| MongoTemplate         | 否          | 否        | 否                    | 否                              |
| TenantIgnoredMongoTemplate         | 是          | 否        | 否                    | 否                              |
| TenantIsolationMongoTemplate       | 是          | 是        | 是                    | 否                              |
| TenantIsolationSharedMongoTemplate | 是          | 是        | 否                    | 是                              |

<br>

### 在多租户模式下访问不需要租户数据隔离的 Document

以下两种方式任选其一：

1. 显式使用`TenantIgnoredMongoTemplate`。

2. 把对应的 Document Entity 类标记为`@TenantIgnore`，此时不论使用`tenantIsolationMongoTemplate`或是`TenantIsolationSharedMongoTemplate`，效果都与`TenantIgnoredMongoTemplate`完全相同。
```java
@Document(value = "user")
@TenantIgnore
public class User implements Serializable {
    @Id
    private String id;

    private String name;
}
```
