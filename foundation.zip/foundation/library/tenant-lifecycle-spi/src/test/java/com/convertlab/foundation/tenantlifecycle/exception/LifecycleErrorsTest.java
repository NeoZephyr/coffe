package com.convertlab.foundation.tenantlifecycle.exception;

import com.convertlab.foundation.library.tenantlifecycle.exception.LifecycleErrors;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@Slf4j
class LifecycleErrorsTest {
    @Test
    @DisplayName("Test to use the ErrorEnum API to get LifecycleErrors")
    void testLifecycleErrors() {
        LifecycleErrors lifecycleErrors = LifecycleErrors.NOT_IMPLEMENTED;
        log.info("LifecycleErrors: {}", lifecycleErrors);
        log.info("LifecycleErrors: {}", lifecycleErrors.getDescription());
        log.info("LifecycleErrors: {}", lifecycleErrors.getCode());
        log.info("LifecycleErrors: {}", lifecycleErrors.getMessageCode());
    }
}