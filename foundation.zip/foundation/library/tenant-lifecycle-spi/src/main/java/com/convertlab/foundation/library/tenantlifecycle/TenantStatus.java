package com.convertlab.foundation.library.tenantlifecycle;

public enum TenantStatus {
    CREATED,
    CREATION_FAILED,
    SUSPENDED,
    SUSPENSION_FAILED,
    RESUMED,
}
