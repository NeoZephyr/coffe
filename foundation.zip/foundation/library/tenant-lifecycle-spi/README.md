# Tenant Lifecycle API specification
参考wiki链接 [Tenant Lifecycle/租户生命周期规范](https://confluence.xiaoshu.biz/pages/viewpage.action?pageId=159498590)

## 主API定义
[LifecycleApi](src/main/java/com/convertlab/foundation/tenantlifecycle/LifecycleApi.java)

## 数据对象定义
[TenantDto](src/main/java/com/convertlab/foundation/tenantlifecycle/dto/TenantDto.java)
[LifecycleResponse](src/main/java/com/convertlab/foundation/tenantlifecycle/dto/LifecycleResponse.java)

## 异常处理定义
### 错误码定义
[LifecycleErrors](src/main/java/com/convertlab/foundation/tenantlifecycle/exception/LifecycleErrors.java)
### 异常类型
#### 父类
[LifecycleException](src/main/java/com/convertlab/foundation/tenantlifecycle/exception/LifecycleException.java)

#### 子类列表
- [NotImplementedException](src/main/java/com/convertlab/foundation/tenantlifecycle/exception/NotImplementedException.java)
    ```json5
      {
          "error": {
            "code": "0100001",
            "description": "Not implemented",
            "message_code": "MSG_000_000000",
            "message_arguments": [],
            "http_status_code": 521
          }
        }
    ```
- [TenantNotFoundException.java](src/main/java/com/convertlab/foundation/tenantlifecycle/exception/TenantNotFoundException.java)
  ```json5
  {
      "error": {
        "code": "0100002",
        "description": "Tenant not found...",
        "message_code": "MSG_000_000000",
        "message_arguments": [
          "查了这里，没找到",
          "查了那里，也没找到"
        ],
        "http_status_code": 521
      }
    }
  ```
