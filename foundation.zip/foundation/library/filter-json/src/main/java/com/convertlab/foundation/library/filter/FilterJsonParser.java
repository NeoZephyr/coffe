package com.convertlab.foundation.library.filter;

import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;

public interface FilterJsonParser<JSON> {
    @Nullable
    JSON parse(@NotNull String filterJson);

    /**
     * Parse filter json to gdql.
     *
     * @param filter filter json, refer to
     *    https://confluence.xiaoshu.biz/display/rd/Filter+Json+V4 for more details.
     * @return parse result with gdql and binding variables if enabled, e.g.:
     * <code>
     * SELECT * FROM (SELECT brand, owner_name
     * FROM car
     * WHERE car.type = ?
     * AND car.brand = ?) temp LIMIT 0,10
     * </code>
     * or without binding variables:
     * <code>
     * SELECT * FROM (SELECT brand, owner_name
     * FROM car
     * WHERE car.type = 1
     * AND car.brand = 'unknown') temp LIMIT 0,10
     * </code>
     */
    GdmParseResult toGdql(@NotNull JSON filter);

    /**
     * Parse filter json to count gdql
     *
     * @param filter filter json
     * @return parse result with gdql and binding variables if enabled, e.g.:
     * <code>
     * SELECT count(1) AS count FROM (select owner_name,brand from car where type = ? and brand = ?) temp
     * </code>
     */
    GdmParseResult toCountQl(@NotNull JSON filter);
}
