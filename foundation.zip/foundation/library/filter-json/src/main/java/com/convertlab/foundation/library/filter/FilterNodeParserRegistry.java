package com.convertlab.foundation.library.filter;

import org.apache.commons.lang3.tuple.Pair;
import javax.validation.constraints.NotNull;

public interface FilterNodeParserRegistry<ConditionNode, NodeParser> {
    @SuppressWarnings("unchecked")
    FilterNodeParserRegistry<ConditionNode, NodeParser> register(@NotNull Pair<Class<? extends ConditionNode>, NodeParser>... nodeParserPairs);

    NodeParser getNodeParser(@NotNull Class<? extends ConditionNode> node);
}
