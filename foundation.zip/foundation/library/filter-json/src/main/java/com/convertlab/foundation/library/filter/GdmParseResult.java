package com.convertlab.foundation.library.filter;

import com.convertlab.foundation.library.gdmmeta.model.FieldType;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.RegExUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.util.CollectionUtils;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.sql.Types;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.convertlab.foundation.library.filter.v4.ParseContext.BINDING_VAR_PREFIX;

@Data
@NoArgsConstructor
public class GdmParseResult {
    public static final String BINDING_VAR_CHAR = "?";
    private static final Pattern BINDING_VAR_PATTERN = Pattern.compile(BINDING_VAR_PREFIX + "(\\d)+");

    private String gdql;
    private boolean bindingVarsEnabled;
    private List<Arg> bindingVars;

    public GdmParseResult(@Nonnull String gdql, boolean bindingVarsEnabled, @Nonnull Map<String, Arg> bindingVars) {
        if (bindingVarsEnabled) {
            this.bindingVarsEnabled = true;
            this.bindingVars = extractBindingVars(gdql, bindingVars);
            this.gdql = RegExUtils.replaceAll(gdql, BINDING_VAR_PATTERN, BINDING_VAR_CHAR);
        } else {
            this.bindingVarsEnabled = false;
            this.gdql = gdql;
            this.bindingVars = Lists.newArrayList();
        }
    }

    @Nonnull
    public static Object[] argsToBindingVars(@Nonnull List<Arg> args) {
        if (CollectionUtils.isEmpty(args)) {
            return new Object[0];
        }
        return args.stream()
                .map(GdmParseResult::argToBindingVar)
                .toArray();
    }

    public static int[] argsToDbTypes(@Nonnull List<Arg> args) {
        if (CollectionUtils.isEmpty(args)) {
            return new int[0];
        }
        return args.stream()
                .mapToInt(GdmParseResult::argToDbType)
                .toArray();
    }

    private static final String BOOLEAN_TRUE = "1";

    @Nullable
    public static Object argToBindingVar(@Nonnull Arg arg) {
        String value = arg.getValue().toString();
        FieldType fieldType = arg.getType();
        if (fieldType == null) {
            return arg.getValue();
        }
        switch (arg.getType()) {
            case Long:
                return Long.parseLong(value);
            case Integer:
                return Integer.parseInt(value);
            case Short:
                return Short.parseShort(value);
            case Byte:
                return Byte.parseByte(value);
            case Double:
                return Double.parseDouble(value);
            case Decimal:
                return NumberUtils.createBigDecimal(value);
            case Boolean:
                return BOOLEAN_TRUE.equals(value) || Boolean.parseBoolean(value);
            default:
                return arg.getValue();
        }
    }

    private static int argToDbType(@Nonnull Arg arg) {
        FieldType fieldType = arg.getType();
        if (fieldType == null) {
            return Types.VARCHAR;
        }
        switch (arg.getType()) {
            case Long:
                return Types.BIGINT;
            case Integer:
                return Types.INTEGER;
            case Short:
            case Byte:
                return Types.SMALLINT;
            case Double:
            case Decimal:
                return Types.DOUBLE;
            case Boolean:
                return Types.BOOLEAN;
            default:
                return Types.VARCHAR;
        }
    }

    @Nonnull
    private List<Arg> extractBindingVars(@Nonnull String gdql, @Nonnull Map<String, Arg> bindingVars) {
        List<Arg> list = Lists.newArrayList();
        Matcher matcher = BINDING_VAR_PATTERN.matcher(gdql);
        while (matcher.find()) {
            list.add(bindingVars.get(matcher.group()));
        }
        return list;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Arg {
        private Object value;
        private FieldType type;
    }
}
