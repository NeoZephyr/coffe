DROP TABLE IF EXISTS car;

CREATE TABLE car
(
    id        BIGINT NOT NULL PRIMARY KEY,
    driver_id BIGINT NOT NULL,
    brand     VARCHAR(30) NULL DEFAULT NULL,
    type      INT,
    owner_name     VARCHAR(30) NULL DEFAULT NULL,
    production_date  TIMESTAMP
);

DROP TABLE IF EXISTS driver;

CREATE TABLE driver
(
    id        BIGINT NOT NULL PRIMARY KEY,
    work_address_id BIGINT NOT NULL,
    home_address_id BIGINT NOT NULL,
    name       VARCHAR(30) NULL DEFAULT NULL,
    gender     VARCHAR(10) NULL DEFAULT NULL,
    age        BIGINT NOT NULL
);

DROP TABLE IF EXISTS address;

CREATE TABLE address
(
    id        BIGINT NOT NULL PRIMARY KEY,
    province     VARCHAR(30) NULL DEFAULT NULL,
    street     VARCHAR(30) NULL DEFAULT NULL,
    city     INT
);

DROP TABLE IF EXISTS subscribe_wechat_oa_event;
CREATE TABLE subscribe_wechat_oa_event (
    id        BIGINT NOT NULL PRIMARY KEY,
    driver_id  BIGINT NOT NULL,
    target_id   BIGINT NULL DEFAULT NULL,
    field_date     TIMESTAMP
);

DROP TABLE IF EXISTS unsubscribe_wechat_oa_event;
CREATE TABLE unsubscribe_wechat_oa_event (
    id        BIGINT NOT NULL PRIMARY KEY,
    driver_id  BIGINT NOT NULL,
    target_id   BIGINT NULL DEFAULT NULL,
    field_date     TIMESTAMP
);

DROP TABLE IF EXISTS event_target;
CREATE TABLE event_target (
    id        BIGINT NOT NULL PRIMARY KEY,
    name   VARCHAR(30) NULL DEFAULT NULL
);