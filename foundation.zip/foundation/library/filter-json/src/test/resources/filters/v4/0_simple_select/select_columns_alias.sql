SELECT car.id, car.brand, car.owner_name AS owner_name_alias
FROM car car