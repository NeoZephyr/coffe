SELECT car.id, car.brand, car.owner_name
FROM car car
WHERE UPPER(car.brand) IN (?, ?)
	AND car.type NOT IN (?, ?)
	AND car.type BETWEEN ? AND ?
LIMIT 0,10