SELECT driver.id, driver.name, driver.gender
FROM driver driver
	LEFT SEMI JOIN (
		SELECT driver.id AS id
		FROM driver driver
			LEFT ANTI JOIN (
				SELECT subscribe_wechat_oa_event.driver_id AS driver_id
				FROM subscribe_wechat_oa_event subscribe_wechat_oa_event
					LEFT SEMI JOIN (
						SELECT event_target.id AS id
						FROM event_target event_target
						WHERE event_target.name IN (?, ?, ?)
					) tmp0
					ON subscribe_wechat_oa_event.target_id = tmp0.id
			) tmp1
			ON driver.id = tmp1.driver_id
	) tmp3
	ON driver.id = tmp3.id
WHERE driver.gender = ?
LIMIT 10