SELECT driver.id, driver.name
FROM driver driver
	LEFT SEMI JOIN (
		SELECT car.driver_id AS driver_id
		FROM car car
		WHERE car.brand = ?
	) tmp1
	ON driver.id = tmp1.driver_id
WHERE driver.id IN (SELECT left_table.driver_id FROM car left_table JOIN car right_table ON left_table.driver_id = right_table.driver_id WHERE left_table.type=1 AND right_table.type=2 AND left_table.brand = right_table.brand)
LIMIT 0, 10