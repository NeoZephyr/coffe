SELECT driver.id, driver.name, tmp2.total_car AS total_car
FROM driver driver
	INNER JOIN (
		SELECT DISTINCT tmp0.id AS id, tmp1.total_car AS total_car
		FROM (
			SELECT driver.id AS id
			FROM driver driver
			WHERE driver.gender = ?
		) tmp0
			INNER JOIN (
				SELECT car.driver_id AS id, count(1) AS total_car
				FROM car car
				WHERE car.brand = ?
				GROUP BY car.driver_id
				HAVING total_car > ?
			) tmp1
			ON tmp0.id = tmp1.id
	) tmp2
	ON driver.id = tmp2.id
LIMIT 0,10