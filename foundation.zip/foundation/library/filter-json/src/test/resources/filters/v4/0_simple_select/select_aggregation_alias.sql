SELECT MAX(driver.age) AS max_age, MIN(driver.age) AS min_age
FROM driver driver