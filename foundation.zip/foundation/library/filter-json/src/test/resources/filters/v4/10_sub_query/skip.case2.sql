SELECT tmp0.gender, tmp0.max_age AS max_age
FROM (
	SELECT driver.gender, COUNT(1) AS total, MAX(driver.age) AS max_age
		, MIN(driver.age) AS min_age, AVG(driver.age) AS avg_age
	FROM driver driver
	WHERE driver.gender = ?
	GROUP BY gender
	HAVING total >= ?
	AND max_age - min_age <= avg_age
) tmp0