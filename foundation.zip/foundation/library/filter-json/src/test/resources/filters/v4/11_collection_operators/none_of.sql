SELECT driver.id, driver.name, driver.gender
FROM driver driver
	LEFT SEMI JOIN (
		SELECT driver.id AS id
		FROM driver driver
			LEFT ANTI JOIN (
				SELECT car.driver_id AS driver_id
				FROM car car
				WHERE car.brand IN (?, ?, ?)
			) tmp0
			ON driver.id = tmp0.driver_id
	) tmp2
	ON driver.id = tmp2.id
WHERE driver.gender = ?
LIMIT 10