SELECT driver.name
FROM driver driver
WHERE driver.gender = ?
	AND (driver.name = ?
		OR driver.name = ?
		OR driver.gender = ?)