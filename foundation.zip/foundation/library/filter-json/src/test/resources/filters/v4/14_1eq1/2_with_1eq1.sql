SELECT driver.id, driver.name
FROM driver driver
	LEFT SEMI JOIN (
		SELECT tmp3.id AS id
		FROM (
			SELECT driver.id AS id
			FROM driver driver
			WHERE driver.gender = ?
		) tmp3
			LEFT SEMI JOIN (
				SELECT car.driver_id AS driver_id
				FROM car car
				WHERE car.brand = ?
			) tmp0
			ON tmp3.id = tmp0.driver_id
			LEFT SEMI JOIN (
				SELECT driver.id AS id
				FROM driver driver
					LEFT JOIN (
						SELECT car.driver_id AS driver_id, COUNT(1) AS count_car_id
						FROM car car
						GROUP BY car.driver_id
					) tmp1
					ON driver.id = tmp1.driver_id
				WHERE NVL(tmp1.count_car_id, 0) > ?
			) tmp2
			ON tmp3.id = tmp2.id
	) tmp4
	ON driver.id = tmp4.id
LIMIT 0, 10