SELECT driver.id, driver.name, driver.gender
FROM driver driver
	LEFT SEMI JOIN (
		SELECT car.driver_id AS driver_id
		FROM car car
		WHERE CONCAT('enc:123:', TO_BASE64(AES_ENCRYPT(car.owner_name, FROM_BASE64('KgMvfFupMocvDwReDPa1PPcC8sWFoHfRGGiWutmMWJ4=')))) = ?
			AND (month(car.production_date) + year(car.production_date) + round(2.0)) / 2 = ?
	) tmp1
	ON driver.id = tmp1.driver_id
WHERE driver.gender = ?
LIMIT 0, 10