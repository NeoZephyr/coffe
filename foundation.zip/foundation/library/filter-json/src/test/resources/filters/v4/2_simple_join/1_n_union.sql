SELECT driver.id, driver.name, driver.home_address_id
FROM driver driver
	LEFT SEMI JOIN (
		SELECT tmp1.id AS id
		FROM (
			SELECT driver.id AS id
			FROM driver driver
			WHERE driver.gender = ?
				AND driver.name = ?
			UNION
			SELECT driver.id AS id
			FROM driver driver
				LEFT SEMI JOIN (
					SELECT car.driver_id AS driver_id
					FROM car car
					WHERE car.brand = ?
						AND car.type = ?
				) tmp0
				ON driver.id = tmp0.driver_id
		) tmp1
	) tmp2
	ON driver.id = tmp2.id
LIMIT 0, 10