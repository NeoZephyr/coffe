SELECT driver.id, driver.name, home_address.city
FROM driver driver
	LEFT SEMI JOIN (
		SELECT home_address.id AS id
		FROM address home_address
		WHERE home_address.province = ?
	) tmp1
	ON driver.home_address_id = tmp1.id
	LEFT JOIN address home_address ON driver.home_address_id = home_address.id
WHERE driver.gender = ?
	AND driver.name = ?
LIMIT 0, 10