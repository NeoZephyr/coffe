SELECT driver.id, driver.name, driver.home_address_id
FROM driver driver
	LEFT SEMI JOIN (
		SELECT tmp4.id AS id
		FROM (
			SELECT driver.id AS id
			FROM driver driver
				LEFT SEMI JOIN (
					SELECT car.driver_id AS driver_id
					FROM car car
					WHERE car.brand = ?
				) tmp1
				ON driver.id = tmp1.driver_id
			WHERE driver.gender = ?
			UNION
			SELECT driver.id AS id
			FROM driver driver
				LEFT SEMI JOIN (
					SELECT car.driver_id AS driver_id
					FROM car car
					WHERE car.type = ?
				) tmp3
				ON driver.id = tmp3.driver_id
			WHERE driver.name = ?
		) tmp4
	) tmp5
	ON driver.id = tmp5.id
LIMIT 0, 10