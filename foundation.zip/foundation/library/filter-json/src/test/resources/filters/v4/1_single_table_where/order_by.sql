SELECT car.id, car.brand, car.owner_name
FROM car car
ORDER BY id ASC, owner_name DESC