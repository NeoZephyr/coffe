SELECT driver.id, driver.name, driver.home_address_id
FROM driver driver
	LEFT SEMI JOIN (
		SELECT tmp3.id AS id
		FROM (
			SELECT driver.id AS id
			FROM driver driver
			WHERE driver.name = ?
		) tmp3
			LEFT SEMI JOIN (
				SELECT driver.id AS id
				FROM driver driver
					LEFT SEMI JOIN (
						SELECT tmp1.id AS id
						FROM (
							SELECT driver.id AS id
							FROM driver driver
							WHERE driver.gender = ?
							UNION
							SELECT driver.id AS id
							FROM driver driver
								LEFT SEMI JOIN (
									SELECT car.driver_id AS driver_id
									FROM car car
									WHERE car.brand = ?
								) tmp0
								ON driver.id = tmp0.driver_id
						) tmp1
					) tmp2
					ON driver.id = tmp2.id
			) tmp4
			ON tmp3.id = tmp4.id
			LEFT SEMI JOIN (
				SELECT car.driver_id AS driver_id
				FROM car car
				WHERE car.type = ?
			) tmp5
			ON tmp3.id = tmp5.driver_id
	) tmp6
	ON driver.id = tmp6.id
LIMIT 0, 10