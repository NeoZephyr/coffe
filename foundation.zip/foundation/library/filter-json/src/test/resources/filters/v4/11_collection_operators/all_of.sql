SELECT driver.id, driver.name, driver.gender
FROM driver driver
	LEFT SEMI JOIN (
		SELECT tmp0.driver_id AS driver_id
		FROM (
			SELECT car.driver_id AS driver_id
			FROM car car
			WHERE car.brand = ?
		) tmp0
			INNER JOIN (
				SELECT car.driver_id AS driver_id
				FROM car car
				WHERE car.brand = ?
			) tmp1
			ON tmp0.driver_id = tmp1.driver_id
	) tmp3
	ON driver.id = tmp3.driver_id
WHERE driver.gender = ?
LIMIT 10