SELECT driver.id
FROM driver driver
WHERE driver.id IN (
	SELECT DISTINCT tmp4.unified_fk
	FROM (
		SELECT tmp3.unified_fk AS unified_fk, min(tmp3.field_date) AS field_date
		FROM (
			SELECT tmp0.unified_fk, tmp0.field_date
			FROM (
				SELECT se.driver_id AS unified_fk, se.field_date
				FROM subscribe_wechat_oa_event se
				WHERE se.field_date >= ?
					AND se.field_date < ?
					AND se.target_id = ?
			) tmp0
				LEFT SEMI JOIN (
					SELECT tmp1.unified_fk AS unified_fk, min(tmp1.field_date) AS field_date
					FROM (
						SELECT se.driver_id AS unified_fk, se.field_date
						FROM subscribe_wechat_oa_event se
						WHERE se.field_date >= ?
							AND se.field_date < ?
							AND se.target_id = ?
					) tmp1
					GROUP BY tmp1.unified_fk
				) tmp2
				ON tmp0.unified_fk = tmp2.unified_fk
					AND tmp0.field_date > tmp2.field_date
		) tmp3
		GROUP BY tmp3.unified_fk
	) tmp4
		LEFT SEMI JOIN (
			SELECT driver.id AS unified_fk
			FROM driver driver
			WHERE driver.gender = ?
				AND (driver.name = ?
					OR driver.name = ?)
		) tmp5
		ON tmp4.unified_fk = tmp5.unified_fk
)