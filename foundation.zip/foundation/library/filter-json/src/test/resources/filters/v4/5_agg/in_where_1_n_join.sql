SELECT driver.id, driver.name, driver.home_address_id
FROM driver driver
	LEFT JOIN (
		SELECT car.driver_id AS driver_id, COUNT(1) AS count_car_id
		FROM car car
		WHERE car.brand = ?
		GROUP BY car.driver_id
	) tmp1
	ON driver.id = tmp1.driver_id
WHERE driver.gender = ?
	AND NVL(tmp1.count_car_id, 0) > ?
LIMIT 0, 10