SELECT car.id, car.brand, car.owner_name, car.driver_id
FROM car car
	LEFT SEMI JOIN (
		SELECT driver.id AS id
		FROM driver driver
		WHERE driver.name = ?
			AND driver.gender = ?
	) tmp1
	ON car.driver_id = tmp1.id
WHERE car.brand = ?
	AND car.type = ?
LIMIT 0, 10