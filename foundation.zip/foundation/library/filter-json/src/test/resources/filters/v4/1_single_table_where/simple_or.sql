SELECT driver.name
FROM driver driver
WHERE driver.name = ?
	OR driver.name = ?
LIMIT 0,10