SELECT driver.id, driver.name, car.brand
FROM driver driver
	LEFT JOIN car car
	ON driver.id = car.driver_id
		AND (car.type = ? OR car.brand = ?)
WHERE driver.gender = ?
	AND driver.name = ?
LIMIT 0, 10