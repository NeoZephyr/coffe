SELECT driver.id, driver.name, driver.gender
FROM driver driver
	LEFT SEMI JOIN (
		SELECT tmp0.driver_id AS driver_id
		FROM (
			SELECT car.id AS id, car.driver_id AS driver_id
			FROM car car
			WHERE car.type = ?
		) tmp0
			LEFT ANTI JOIN (
				SELECT car.driver_id AS driver_id
				FROM car car
				WHERE car.type = ?
					AND car.brand IN (?, ?, ?)
			) tmp1
			ON tmp0.driver_id = tmp1.driver_id
	) tmp3
	ON driver.id = tmp3.driver_id
WHERE driver.gender = ?
LIMIT 10