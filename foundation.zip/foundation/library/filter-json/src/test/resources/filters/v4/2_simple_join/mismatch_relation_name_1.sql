SELECT driver.id, driver.name, driver.gender, sales.name AS sales_name
FROM driver driver
	LEFT SEMI JOIN (
		SELECT sales.driver_id AS driver_id
		FROM salesman sales
		WHERE sales.gender = ?
	) tmp1
	ON driver.id = tmp1.driver_id
	LEFT JOIN salesman sales ON driver.id = sales.driver_id
WHERE driver.home_address_id = driver.work_address_id
LIMIT 0, 10