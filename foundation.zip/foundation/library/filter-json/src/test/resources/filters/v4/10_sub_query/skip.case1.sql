SELECT tmp0.gender, tmp0.max_age AS max_age
FROM (
	SELECT driver.gender, COUNT(1) AS total, MAX(driver.age) AS max_age
		, MIN(driver.age) AS min_age, AVG(driver.age) AS avg_age
	FROM driver driver
	WHERE driver.gender = ?
	GROUP BY gender
	HAVING total >= ?
) tmp0
WHERE tmp0.max_age - tmp0.min_age <= tmp0.avg_age