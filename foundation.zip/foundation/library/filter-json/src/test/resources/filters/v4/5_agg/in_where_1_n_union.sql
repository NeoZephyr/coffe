SELECT driver.id, driver.name, driver.home_address_id
FROM driver driver
	LEFT SEMI JOIN (
		SELECT tmp1.id AS id
		FROM (
			SELECT driver.id AS id
			FROM driver driver
			WHERE driver.gender = ?
			UNION
			SELECT driver.id AS id
			FROM driver driver
				LEFT JOIN (
					SELECT car.driver_id AS driver_id, COUNT(1) AS count_car_id
					FROM car car
					WHERE car.brand = ?
					GROUP BY car.driver_id
				) tmp0
				ON driver.id = tmp0.driver_id
			WHERE NVL(tmp0.count_car_id, 0) > ?
		) tmp1
	) tmp2
	ON driver.id = tmp2.id
LIMIT 0, 10