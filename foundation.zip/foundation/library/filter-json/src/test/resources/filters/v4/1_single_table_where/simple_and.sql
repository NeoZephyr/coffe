SELECT driver.name
FROM driver driver
WHERE driver.name = ?
	AND driver.name = ?
	AND driver.gender = ?
	AND driver.gender = ?
LIMIT 0,10