SELECT car.id, car.brand, car.owner_name, driver.gender AS gender
FROM car car
	LEFT SEMI JOIN (
		SELECT driver.id AS id
		FROM driver driver
		WHERE driver.name = ?
			OR driver.name = ?
	) tmp1
	ON car.driver_id = tmp1.id
	LEFT JOIN driver driver ON car.driver_id = driver.id
WHERE car.brand = ?
	AND car.type = ?