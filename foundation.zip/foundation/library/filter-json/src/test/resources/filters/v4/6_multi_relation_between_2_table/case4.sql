SELECT driver.id, driver.name, home_address.city AS home_city, work_address.city AS work_city
FROM driver driver
	LEFT SEMI JOIN (
		SELECT tmp0.id AS id
		FROM (
			SELECT driver.id AS id, driver.home_address_id AS home_address_id, driver.work_address_id AS work_address_id
			FROM driver driver
			WHERE driver.gender = ?
		) tmp0
			LEFT SEMI JOIN (
				SELECT work_address.id AS id
				FROM address work_address
				WHERE work_address.province = ?
			) tmp1
			ON tmp0.work_address_id = tmp1.id
			LEFT SEMI JOIN (
				SELECT home_address.id AS id
				FROM address home_address
				WHERE home_address.province = ?
			) tmp2
			ON tmp0.home_address_id = tmp2.id
	) tmp3
	ON driver.id = tmp3.id
	LEFT JOIN address home_address ON driver.home_address_id = home_address.id
	LEFT JOIN address work_address ON driver.work_address_id = work_address.id
LIMIT 0, 10