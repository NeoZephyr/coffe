SELECT MAX(driver.age), MIN(driver.age)
	, AVG(driver.age), SUM(driver.age)
FROM driver driver