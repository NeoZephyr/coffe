SELECT car.id, car.brand, driver.name, home_address.city AS home_city, work_address.city AS work_city
FROM car car
	LEFT SEMI JOIN (
		SELECT driver.id AS id, driver.home_address_id AS home_address_id, driver.work_address_id AS work_address_id
		FROM driver driver
			LEFT SEMI JOIN (
				SELECT driver.id AS id, driver.home_address_id AS home_address_id, driver.work_address_id AS work_address_id
				FROM driver driver
					LEFT SEMI JOIN (
						SELECT tmp2.id AS id
						FROM (
							SELECT driver.id AS id
							FROM driver driver
								LEFT SEMI JOIN (
									SELECT home_address.id AS id
									FROM address home_address
									WHERE home_address.province = ?
								) tmp0
								ON driver.home_address_id = tmp0.id
							UNION
							SELECT driver.id AS id
							FROM driver driver
								LEFT SEMI JOIN (
									SELECT work_address.id AS id
									FROM address work_address
									WHERE work_address.province = ?
								) tmp1
								ON driver.work_address_id = tmp1.id
						) tmp2
					) tmp3
					ON driver.id = tmp3.id
			) tmp5
			ON driver.id = tmp5.id
		WHERE driver.gender = ?
	) tmp7
	ON car.driver_id = tmp7.id
	LEFT JOIN driver driver ON car.driver_id = driver.id
	LEFT JOIN address home_address ON driver.home_address_id = home_address.id
	LEFT JOIN address work_address ON driver.work_address_id = work_address.id
WHERE car.brand = ?
LIMIT 0, 10