SELECT car.id, car.brand
FROM car car
	LEFT SEMI JOIN (
		SELECT tmp2.id AS id
		FROM (
			SELECT car.id AS id
			FROM car car
			WHERE car.brand = ?
			UNION
			SELECT car.id AS id
			FROM car car
				LEFT SEMI JOIN (
					SELECT driver.id AS id, driver.work_address_id AS work_address_id
					FROM driver driver
						LEFT SEMI JOIN (
							SELECT work_address.id AS id
							FROM address work_address
							WHERE work_address.province = ?
						) tmp0
						ON driver.work_address_id = tmp0.id
				) tmp1
				ON car.driver_id = tmp1.id
		) tmp2
	) tmp3
	ON car.id = tmp3.id
LIMIT 0, 10