SELECT driver.id, driver.name
FROM driver driver
	LEFT SEMI JOIN (
		SELECT driver.id AS id
		FROM driver driver
			LEFT SEMI JOIN (
				SELECT tmp0.id AS id
				FROM (
					SELECT id, count(1) AS sales_count
					FROM salesman
					GROUP BY id
					HAVING sales_count > 1
				) tmp0
				WHERE tmp0.sales_count > ?
			) tmp2
			ON driver.id = tmp2.id
	) tmp4
	ON driver.id = tmp4.id
WHERE driver.gender = ?
	AND driver.name = ?
LIMIT 0, 10