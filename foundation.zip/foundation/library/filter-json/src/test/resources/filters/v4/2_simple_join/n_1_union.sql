SELECT car.brand, car.owner_name, car.driver_id
FROM car car
	LEFT SEMI JOIN (
		SELECT tmp1.id AS id
		FROM (
			SELECT car.id AS id
			FROM car car
			WHERE car.brand = ?
			UNION
			SELECT car.id AS id
			FROM car car
				LEFT SEMI JOIN (
					SELECT driver.id AS id
					FROM driver driver
					WHERE driver.name = ?
				) tmp0
				ON car.driver_id = tmp0.id
		) tmp1
	) tmp2
	ON car.id = tmp2.id
LIMIT 0, 10