SELECT car.id, car.brand, car.owner_name
	, ADDDATE('2023-01-01', -1) AS production_date
FROM car car