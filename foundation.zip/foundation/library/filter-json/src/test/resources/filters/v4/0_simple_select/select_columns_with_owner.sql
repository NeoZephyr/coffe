SELECT car.id, car.brand, upper(car.owner_name) AS owner_name
FROM car car