SELECT driver.id, driver.name
FROM driver driver
	LEFT SEMI JOIN (
		SELECT tmp4.id AS id
		FROM (
			SELECT driver.id AS id
			FROM driver driver
			WHERE driver.gender = ?
			UNION
			SELECT driver.id AS id
			FROM driver driver
				LEFT SEMI JOIN (
					SELECT car.driver_id AS driver_id
					FROM car car
					WHERE car.brand = ?
				) tmp0
				ON driver.id = tmp0.driver_id
			UNION
			SELECT driver.id AS id
			FROM driver driver
				LEFT SEMI JOIN (
					SELECT driver.id AS id
					FROM driver driver
						LEFT JOIN (
							SELECT car.driver_id AS driver_id, COUNT(1) AS count_car_id
							FROM car car
							GROUP BY car.driver_id
						) tmp1
						ON driver.id = tmp1.driver_id
					WHERE NVL(tmp1.count_car_id, 0) > ?
				) tmp2
				ON driver.id = tmp2.id
		) tmp4
	) tmp5
	ON driver.id = tmp5.id
LIMIT 0, 10