SELECT car.id, car.brand
FROM car car
	LEFT SEMI JOIN (
		SELECT driver.id AS id, driver.work_address_id AS work_address_id
		FROM driver driver
			LEFT SEMI JOIN (
				SELECT work_address.id AS id
				FROM address work_address
				WHERE work_address.province = ?
			) tmp0
			ON driver.work_address_id = tmp0.id
	) tmp2
	ON car.driver_id = tmp2.id
WHERE car.brand = ?
LIMIT 0, 10