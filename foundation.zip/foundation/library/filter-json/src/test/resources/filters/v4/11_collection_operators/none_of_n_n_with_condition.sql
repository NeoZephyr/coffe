SELECT driver.id, driver.name, driver.gender
FROM driver driver
	LEFT SEMI JOIN (
		SELECT driver.id AS id
		FROM driver driver
			LEFT ANTI JOIN (
				SELECT subscribe_wechat_oa_event.driver_id AS driver_id
				FROM subscribe_wechat_oa_event subscribe_wechat_oa_event
					LEFT SEMI JOIN (
						SELECT event_target.id AS id
						FROM event_target event_target
						WHERE event_target.id > ?
							AND event_target.name IN (?, ?, ?)
					) tmp0
					ON subscribe_wechat_oa_event.target_id = tmp0.id
			) tmp2
			ON driver.id = tmp2.driver_id
	) tmp4
	ON driver.id = tmp4.id
WHERE driver.gender = ?
LIMIT 10