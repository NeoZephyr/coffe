SELECT driver.id, driver.name, car.type
FROM driver driver
	LEFT SEMI JOIN (
		SELECT car.driver_id AS driver_id
		FROM car car
		WHERE car.brand = ?
	) tmp1
	ON driver.id = tmp1.driver_id
	LEFT JOIN car car ON driver.id = car.driver_id
WHERE driver.gender = ?
LIMIT 0, 10