SELECT car.id, car.type, car.brand
FROM car car
	LEFT SEMI JOIN (
		SELECT driver.id AS id, driver.home_address_id AS home_address_id
		FROM driver driver
			LEFT SEMI JOIN (
				SELECT home_address.id AS id
				FROM address home_address
				WHERE home_address.city NOT IN (#cities)
			) tmp0
			ON driver.home_address_id = tmp0.id
	) tmp2
	ON car.driver_id = tmp2.id
WHERE car.brand = ?
LIMIT 10