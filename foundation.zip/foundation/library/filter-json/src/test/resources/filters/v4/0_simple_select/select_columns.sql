SELECT car.id, car.brand, car.owner_name
FROM car car