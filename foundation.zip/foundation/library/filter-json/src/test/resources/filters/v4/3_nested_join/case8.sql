SELECT driver.id, driver.name, driver.home_address_id
FROM driver driver
WHERE driver.gender != ?
	OR driver.name IS NOT NULL
LIMIT 0,10