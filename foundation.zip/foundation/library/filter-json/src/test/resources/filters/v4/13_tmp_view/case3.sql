SELECT driver.id, driver.name
FROM driver driver
	LEFT SEMI JOIN (
		SELECT tmp5.id AS id
		FROM (
			SELECT driver.id AS id
			FROM driver driver
			WHERE driver.gender = ?
			UNION
			SELECT driver.id AS id
			FROM driver driver
				LEFT SEMI JOIN (
					SELECT tmp0.id AS id
					FROM (
						SELECT id, count(1) AS sales_count
						FROM salesman
						GROUP BY id
						HAVING sales_count > 1
					) tmp0
					WHERE tmp0.sales_count > ?
				) tmp2
				ON driver.id = tmp2.id
			UNION
			SELECT driver.id AS id
			FROM driver driver
				LEFT SEMI JOIN (
					SELECT car.driver_id AS driver_id
					FROM car car
					WHERE car.brand = ?
				) tmp3
				ON driver.id = tmp3.driver_id
		) tmp5
	) tmp6
	ON driver.id = tmp6.id
LIMIT 0, 10