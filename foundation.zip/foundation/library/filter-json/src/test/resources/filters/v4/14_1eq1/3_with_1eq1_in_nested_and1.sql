SELECT driver.id, driver.name
FROM driver driver
	LEFT SEMI JOIN (
		SELECT tmp2.id AS id
		FROM (
			SELECT driver.id AS id
			FROM driver driver
			WHERE driver.gender = ?
		) tmp2
			LEFT SEMI JOIN (
				SELECT car.driver_id AS driver_id
				FROM car car
				WHERE car.brand = ?
					AND car.id = ?
			) tmp0
			ON tmp2.id = tmp0.driver_id
			LEFT SEMI JOIN (
				SELECT car.driver_id AS driver_id
				FROM car car
				WHERE car.brand = ?
					AND car.id = ?
			) tmp1
			ON tmp2.id = tmp1.driver_id
	) tmp3
	ON driver.id = tmp3.id
LIMIT 0, 10