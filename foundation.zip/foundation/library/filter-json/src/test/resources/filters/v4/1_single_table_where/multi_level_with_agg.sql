SELECT driver.id, driver.name, driver.gender
FROM driver driver
	LEFT SEMI JOIN (
		SELECT driver.id AS id
		FROM driver driver
			LEFT JOIN (
				SELECT car.driver_id AS driver_id, COUNT(1) AS count_car_id
				FROM car car
				WHERE car.brand = ?
					AND (car.brand IS NOT NULL
						OR car.type IS NOT NULL)
				GROUP BY car.driver_id
			) tmp0
			ON driver.id = tmp0.driver_id
		WHERE NVL(tmp0.count_car_id, 0) = ?
	) tmp1
	ON driver.id = tmp1.id
ORDER BY id DESC
LIMIT 50