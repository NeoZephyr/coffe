SELECT driver.id, driver.name, home_address.city
FROM driver driver
	LEFT SEMI JOIN (
		SELECT tmp1.id AS id
		FROM (
			SELECT driver.id AS id
			FROM driver driver
			WHERE driver.gender = ?
				OR driver.name = ?
			UNION
			SELECT driver.id AS id
			FROM driver driver
				LEFT SEMI JOIN (
					SELECT work_address.id AS id
					FROM address work_address
					WHERE work_address.province = ?
				) tmp0
				ON driver.work_address_id = tmp0.id
		) tmp1
	) tmp2
	ON driver.id = tmp2.id
	LEFT JOIN address home_address ON driver.home_address_id = home_address.id
LIMIT 0, 10