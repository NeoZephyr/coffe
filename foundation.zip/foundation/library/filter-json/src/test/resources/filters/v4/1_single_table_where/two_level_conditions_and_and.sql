SELECT driver.id
FROM driver driver
WHERE driver.name = ?
	AND driver.gender = ?
	AND driver.gender = ?