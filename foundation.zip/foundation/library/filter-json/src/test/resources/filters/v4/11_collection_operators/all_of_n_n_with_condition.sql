SELECT driver.id, driver.name, driver.gender
FROM driver driver
	LEFT SEMI JOIN (
		SELECT tmp3.driver_id AS driver_id
		FROM (
			SELECT subscribe_wechat_oa_event.id AS id, subscribe_wechat_oa_event.driver_id AS driver_id, subscribe_wechat_oa_event.target_id AS target_id
			FROM subscribe_wechat_oa_event subscribe_wechat_oa_event
				LEFT SEMI JOIN (
					SELECT event_target.id AS id
					FROM event_target event_target
					WHERE event_target.id > ?
						AND event_target.name = ?
				) tmp0
				ON subscribe_wechat_oa_event.target_id = tmp0.id
		) tmp3
			INNER JOIN (
				SELECT subscribe_wechat_oa_event.id AS id, subscribe_wechat_oa_event.driver_id AS driver_id, subscribe_wechat_oa_event.target_id AS target_id
				FROM subscribe_wechat_oa_event subscribe_wechat_oa_event
					LEFT SEMI JOIN (
						SELECT event_target.id AS id
						FROM event_target event_target
						WHERE event_target.id > ?
							AND event_target.name = ?
					) tmp1
					ON subscribe_wechat_oa_event.target_id = tmp1.id
			) tmp4
			ON tmp3.driver_id = tmp4.driver_id
			INNER JOIN (
				SELECT subscribe_wechat_oa_event.id AS id, subscribe_wechat_oa_event.driver_id AS driver_id, subscribe_wechat_oa_event.target_id AS target_id
				FROM subscribe_wechat_oa_event subscribe_wechat_oa_event
					LEFT SEMI JOIN (
						SELECT event_target.id AS id
						FROM event_target event_target
						WHERE event_target.id > ?
							AND event_target.name = ?
					) tmp2
					ON subscribe_wechat_oa_event.target_id = tmp2.id
			) tmp5
			ON tmp4.driver_id = tmp5.driver_id
	) tmp7
	ON driver.id = tmp7.driver_id
WHERE driver.gender = ?
LIMIT 10