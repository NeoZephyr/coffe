SELECT salesman.id, salesman.name, salesman.gender, driver.name
FROM salesman salesman
	LEFT SEMI JOIN (
		SELECT driver.id AS id
		FROM driver driver
		WHERE driver.home_address_id = driver.work_address_id
			AND driver.gender = ?
	) tmp0
	ON salesman.driver_id = tmp0.id
	LEFT JOIN driver driver ON salesman.driver_id = driver.id
LIMIT 0, 10