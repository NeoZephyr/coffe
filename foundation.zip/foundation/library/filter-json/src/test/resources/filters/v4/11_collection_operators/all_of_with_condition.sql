SELECT driver.id, driver.name, driver.gender
FROM driver driver
	LEFT SEMI JOIN (
		SELECT tmp0.driver_id AS driver_id
		FROM (
			SELECT car.driver_id AS driver_id
			FROM car car
			WHERE car.type = ?
				AND car.brand = ?
		) tmp0
			INNER JOIN (
				SELECT car.driver_id AS driver_id
				FROM car car
				WHERE car.type = ?
					AND car.brand = ?
			) tmp1
			ON tmp0.driver_id = tmp1.driver_id
			INNER JOIN (
				SELECT car.driver_id AS driver_id
				FROM car car
				WHERE car.type = ?
					AND car.brand = ?
			) tmp2
			ON tmp1.driver_id = tmp2.driver_id
	) tmp4
	ON driver.id = tmp4.driver_id
WHERE driver.gender = ?
LIMIT 10