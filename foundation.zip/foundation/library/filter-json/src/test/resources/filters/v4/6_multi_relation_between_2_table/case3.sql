SELECT driver.id, driver.name, home_address.city AS home_city
FROM driver driver
	LEFT SEMI JOIN (
		SELECT driver.id AS id
		FROM driver driver
			LEFT SEMI JOIN (
				SELECT work_address.id AS id
				FROM address work_address
				WHERE work_address.province = ?
			) tmp0
			ON driver.work_address_id = tmp0.id
			LEFT SEMI JOIN (
				SELECT home_address.id AS id
				FROM address home_address
				WHERE home_address.province = ?
			) tmp1
			ON driver.home_address_id = tmp1.id
	) tmp2
	ON driver.id = tmp2.id
	LEFT JOIN address home_address ON driver.home_address_id = home_address.id
LIMIT 0, 10