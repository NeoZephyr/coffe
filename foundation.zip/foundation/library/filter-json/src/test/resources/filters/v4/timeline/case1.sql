SELECT driver.id
FROM driver driver
	LEFT SEMI JOIN (
		SELECT car.driver_id AS driver_id
		FROM car car
		WHERE car.brand = ?
			AND car.type = ?
	) tmp1
	ON driver.id = tmp1.driver_id
WHERE driver.gender = ?
	AND driver.name = ?