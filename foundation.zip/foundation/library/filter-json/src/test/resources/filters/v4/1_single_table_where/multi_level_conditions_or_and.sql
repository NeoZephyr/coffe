SELECT driver.name
FROM driver driver
WHERE driver.gender = ?
	OR (driver.name = ?
		AND (driver.name = ?
			OR (driver.name = ?
				AND (driver.name = ?
					OR driver.name = ?))))