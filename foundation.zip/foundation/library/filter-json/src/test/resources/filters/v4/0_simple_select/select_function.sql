SELECT car.brand, DATE_FORMAT('1978-11-20 00:00:00', '%W %M %d %Y') AS birthday
FROM car car