SELECT COUNT(1) AS total, MAX(driver.age) AS max_age
	, MIN(driver.age) AS min_age, AVG(driver.age) AS avg_age
FROM driver driver
WHERE driver.gender = ?
GROUP BY gender
HAVING max_age - min_age > avg_age
AND total <= ?