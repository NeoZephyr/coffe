SELECT driver.name
FROM driver driver
WHERE driver.gender = ?
	AND driver.name = ?
	AND (driver.name = ?
		OR (driver.name = ?
			AND (driver.name = ?
				OR driver.name = ?)))