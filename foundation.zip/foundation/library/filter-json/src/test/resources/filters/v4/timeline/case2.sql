SELECT driver.id
FROM driver driver
WHERE driver.id IN (
	SELECT DISTINCT id AS id
	FROM driver driver
		LEFT SEMI JOIN (
			SELECT tmp6.unified_fk AS unified_fk, min(tmp6.field_date) AS field_date
			FROM (
				SELECT tmp3.unified_fk, tmp3.field_date
				FROM (
					SELECT se.driver_id AS unified_fk, se.field_date
					FROM subscribe_wechat_oa_event se
					WHERE se.field_date >= ?
						AND se.field_date < ?
						AND se.target_id = ?
				) tmp3
					LEFT SEMI JOIN (
						SELECT tmp4.unified_fk AS unified_fk, min(tmp4.field_date) AS field_date
						FROM (
							SELECT tmp0.unified_fk, tmp0.field_date
							FROM (
								SELECT ue.driver_id AS unified_fk, ue.field_date
								FROM unsubscribe_wechat_oa_event ue
								WHERE ue.field_date >= ?
									AND ue.field_date < ?
									AND ue.target_id = ?
							) tmp0
								LEFT SEMI JOIN (
									SELECT tmp1.unified_fk AS unified_fk, min(tmp1.field_date) AS field_date
									FROM (
										SELECT se.driver_id AS unified_fk, se.field_date
										FROM subscribe_wechat_oa_event se
										WHERE se.field_date >= ?
											AND se.field_date < ?
											AND se.target_id = ?
									) tmp1
									GROUP BY tmp1.unified_fk
								) tmp2
								ON tmp0.unified_fk = tmp2.unified_fk
									AND tmp0.field_date > tmp2.field_date
						) tmp4
						GROUP BY tmp4.unified_fk
					) tmp5
					ON tmp3.unified_fk = tmp5.unified_fk
						AND tmp3.field_date > tmp5.field_date
			) tmp6
			GROUP BY tmp6.unified_fk
		) tmp7
		ON driver.id = tmp7.unified_fk
)