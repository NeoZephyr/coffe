SELECT car.id, car.brand, car.production_date
FROM car car
WHERE car.brand = ?
	AND car.production_date < now()
	AND car.production_date >= addDate(now(), -60)
	AND month(car.production_date) = ?
LIMIT 0,10