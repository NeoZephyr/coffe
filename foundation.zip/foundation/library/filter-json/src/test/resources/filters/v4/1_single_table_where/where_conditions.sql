SELECT car.id, car.brand, car.owner_name
FROM car car
WHERE car.brand = ?
	AND car.brand LIKE ?
	AND car.brand NOT LIKE ?
	AND car.type != ?
	AND car.driver_id > ?
	AND car.driver_id <= ?
	AND car.owner_name IS NOT NULL
	AND car.production_date IS NULL
LIMIT 0,10