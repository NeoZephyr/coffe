SELECT driver.name
FROM driver driver
WHERE driver.name = ?
	OR driver.gender = ?
	OR driver.gender = ?