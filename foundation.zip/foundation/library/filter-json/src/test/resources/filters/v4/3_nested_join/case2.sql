SELECT driver.id, driver.name, driver.home_address_id
FROM driver driver
	LEFT SEMI JOIN (
		SELECT tmp6.id AS id
		FROM (
			SELECT driver.id AS id
			FROM driver driver
				LEFT SEMI JOIN (
					SELECT tmp1.id AS id
					FROM (
						SELECT driver.id AS id
						FROM driver driver
						WHERE driver.gender = ?
						UNION
						SELECT driver.id AS id
						FROM driver driver
							LEFT SEMI JOIN (
								SELECT car.driver_id AS driver_id
								FROM car car
								WHERE car.brand = ?
							) tmp0
							ON driver.id = tmp0.driver_id
					) tmp1
				) tmp2
				ON driver.id = tmp2.id
		) tmp6
			LEFT SEMI JOIN (
				SELECT driver.id AS id
				FROM driver driver
					LEFT SEMI JOIN (
						SELECT tmp4.id AS id
						FROM (
							SELECT driver.id AS id
							FROM driver driver
							WHERE driver.name = ?
							UNION
							SELECT driver.id AS id
							FROM driver driver
								LEFT SEMI JOIN (
									SELECT car.driver_id AS driver_id
									FROM car car
									WHERE car.type = ?
								) tmp3
								ON driver.id = tmp3.driver_id
						) tmp4
					) tmp5
					ON driver.id = tmp5.id
			) tmp7
			ON tmp6.id = tmp7.id
	) tmp8
	ON driver.id = tmp8.id
LIMIT 0, 10