SELECT driver.id
FROM driver driver
WHERE driver.gender = ?
	AND (driver.name = ?
		OR driver.name = ?)