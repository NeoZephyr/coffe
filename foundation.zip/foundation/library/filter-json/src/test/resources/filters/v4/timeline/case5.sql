SELECT driver.id
FROM driver driver
	LEFT SEMI JOIN (
		SELECT car.driver_id AS driver_id
		FROM car car
		WHERE car.brand = ?
			OR car.brand = ?
	) tmp0
	ON driver.id = tmp0.driver_id
WHERE driver.id IN (
	SELECT DISTINCT tmp10.unified_fk
	FROM (
		SELECT tmp8.unified_fk
		FROM (
			SELECT tmp4.unified_fk AS unified_fk, min(tmp4.field_date) AS field_date
			FROM (
				SELECT tmp1.unified_fk, tmp1.field_date
				FROM (
					SELECT se.driver_id AS unified_fk, se.field_date
					FROM subscribe_wechat_oa_event se
					WHERE se.field_date >= ?
						AND se.field_date < ?
						AND se.target_id = ?
				) tmp1
					LEFT SEMI JOIN (
						SELECT tmp2.unified_fk AS unified_fk, min(tmp2.field_date) AS field_date
						FROM (
							SELECT se.driver_id AS unified_fk, se.field_date
							FROM subscribe_wechat_oa_event se
							WHERE se.field_date >= ?
								AND se.field_date < ?
								AND se.target_id = ?
						) tmp2
						GROUP BY tmp2.unified_fk
					) tmp3
					ON tmp1.unified_fk = tmp3.unified_fk
						AND tmp1.field_date > tmp3.field_date
			) tmp4
			GROUP BY tmp4.unified_fk
		) tmp8
			LEFT ANTI JOIN (
				SELECT tmp7.unified_fk AS unified_fk, min(tmp7.field_date) AS field_date
				FROM (
					SELECT tmp5.unified_fk, tmp5.field_date
					FROM (
						SELECT ue.driver_id AS unified_fk, ue.field_date
						FROM unsubscribe_wechat_oa_event ue
						WHERE ue.field_date >= ?
							AND ue.field_date < ?
							AND ue.target_id = ?
					) tmp5
						LEFT SEMI JOIN (
							SELECT tmp4.unified_fk AS unified_fk, min(tmp4.field_date) AS field_date
							FROM (
								SELECT tmp1.unified_fk, tmp1.field_date
								FROM (
									SELECT se.driver_id AS unified_fk, se.field_date
									FROM subscribe_wechat_oa_event se
									WHERE se.field_date >= ?
										AND se.field_date < ?
										AND se.target_id = ?
								) tmp1
									LEFT SEMI JOIN (
										SELECT tmp2.unified_fk AS unified_fk, min(tmp2.field_date) AS field_date
										FROM (
											SELECT se.driver_id AS unified_fk, se.field_date
											FROM subscribe_wechat_oa_event se
											WHERE se.field_date >= ?
												AND se.field_date < ?
												AND se.target_id = ?
										) tmp2
										GROUP BY tmp2.unified_fk
									) tmp3
									ON tmp1.unified_fk = tmp3.unified_fk
										AND tmp1.field_date > tmp3.field_date
							) tmp4
							GROUP BY tmp4.unified_fk
						) tmp6
						ON tmp5.unified_fk = tmp6.unified_fk
							AND tmp5.field_date > tmp6.field_date
				) tmp7
				GROUP BY tmp7.unified_fk
			) tmp9
			ON tmp8.unified_fk = tmp9.unified_fk
	) tmp10
		LEFT SEMI JOIN (
			SELECT driver.id AS unified_fk
			FROM driver driver
				LEFT SEMI JOIN (
					SELECT car.driver_id AS driver_id
					FROM car car
					WHERE car.brand = ?
						OR car.brand = ?
				) tmp0
				ON driver.id = tmp0.driver_id
		) tmp11
		ON tmp10.unified_fk = tmp11.unified_fk
)