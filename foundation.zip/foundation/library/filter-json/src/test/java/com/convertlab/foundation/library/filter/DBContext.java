package com.convertlab.foundation.library.filter;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class DBContext {
}
