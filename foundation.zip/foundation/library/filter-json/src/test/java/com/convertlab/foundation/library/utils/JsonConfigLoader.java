package com.convertlab.foundation.library.utils;

import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;

@Slf4j
public class JsonConfigLoader {
    public static final String DEFAULT_CONFIG_DIR = "/tmp";

    public static <T> T config2Obj(String configName, Class<T> clazz) {
        return config2Obj(DEFAULT_CONFIG_DIR, configName, clazz);
    }

    public static <T> List<T> config2List(String configName, Class<T> clazz) {
        return config2List(DEFAULT_CONFIG_DIR, configName, clazz);
    }

    public static <T> List<T> config2List(String configFolder, String configName, Class<T> clazz) {
        try {
            String content = readContent(configFolder, configName);
            final List<T> ts = JsonUtils.instance().json2List(content, clazz);
            return ts;
        } catch (Exception e) {
            return Lists.newArrayList();
        }
    }

    public static <T> T config2Obj(String configFolder, String configName, Class<T> clazz) {
        try {
            String content = readContent(configFolder, configName);
            JsonUtils jsonUtils = JsonUtils.instance();
            return jsonUtils.json2Obj(content, clazz);
        } catch (Exception e) {
            return null;
        }
    }

    public static String readContent(String configName) {
        return readContent(DEFAULT_CONFIG_DIR, configName);
    }

    private static String readContent(String configFolder, String configName) {
        String content = null;
        try (InputStream is = new FileInputStream(configFolder.concat(configName))) {
            content = IOUtils.toString(is, StandardCharsets.UTF_8);
        } catch (Exception e) {
            try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(configName)) {
                if (is != null) {
                    content = IOUtils.toString(is, StandardCharsets.UTF_8);
                }
            } catch (Exception e1) {
                log.warn("no config file found for " + configName);
                return "";
            }
        }
        if (StringUtils.isBlank(content)) {
            return content;
        }
        return content.replaceAll("\r\n", "");
    }

    public static void writeContent(String fileAbsolutePath, String content) {
        try {
            Files.write(
                    Paths.get(fileAbsolutePath),
                    content.getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception e) {
            log.warn("failed to write file " + fileAbsolutePath);
        }
    }
}
