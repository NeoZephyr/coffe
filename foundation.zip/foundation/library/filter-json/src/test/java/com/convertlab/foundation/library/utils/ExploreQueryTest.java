package com.convertlab.foundation.library.utils;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

import com.convertlab.filter.common.*;
import com.convertlab.filter.timeline.EventTimeLineQuery;
import com.diogonunes.jcolor.Attribute;
import com.github.vertical_blank.sqlformatter.SqlFormatter;
import org.slf4j.Logger;

import static com.diogonunes.jcolor.Ansi.colorize;
import static com.diogonunes.jcolor.Attribute.BOLD;
import static com.diogonunes.jcolor.Attribute.GREEN_TEXT;

@Deprecated
@SuppressWarnings("all")
public class ExploreQueryTest {

    private static final Logger log = org.slf4j.LoggerFactory.getLogger(ExploreQueryTest.class);

    public static void main(String[] args) throws IOException, URISyntaxException {
        ExploreQueryTest exploreQueryTest = new ExploreQueryTest();
        exploreQueryTest.filterJson2Sql();
    }

    public void filterJson2Sql() throws IOException, URISyntaxException {
        String jsonFile = System.getProperty("user.dir") + "/library/filter-json/src/test/resources/utils/filterv2.json";
        QueryGenerator queryGenerator = new QueryGenerator(
                new FiltersQueryGenerator(new SingleQueryGenerator(new FilterProperties())),
                new EventWindowQueryGenerator()
        );

        FilterProperties properties = new FilterProperties();
        properties.setDialect(FilterProperties.DIALECT_IMPALA);
        SingleQueryGenerator singleQueryGenerator = new SingleQueryGenerator(properties);
        FiltersQueryGenerator filtersQueryGenerator = new FiltersQueryGenerator(singleQueryGenerator);

        EventTimeLineQuery eventTimeLineQuery = new EventTimeLineQuery(
                new SingleQueryGenerator(new FilterProperties()),new QueryGenerator());

        System.out.println(System.getProperty("user.dir"));

        while (shouldContinue()) {
            logDebug("Starting ...");
            String json = new String(Files.readAllBytes(Paths.get(jsonFile)));

            long start = System.currentTimeMillis();
            String sql = queryGenerator.generateQuery(1, json, "default");
            if (sql == null || sql.trim().length() == 0) {
                sql = queryGenerator.generateQuery(1, json, "event_window");
            }
            logDebug("elapse time: " + (System.currentTimeMillis() - start));
            logDebug("json file content: \n" + json);
            logDebug("Generated SQL(queryGenerator) is : \n" + SqlFormatter.format(sql));

            try {
                sql = filtersQueryGenerator.getQuery(1, json);
                logDebug("Generated SQL(filtersQueryGenerator) is : \n" + SqlFormatter.format(sql));
            } catch (Exception e) {
                log.error(e.getMessage());
                logDebug("Not a timeline filter");
            }

            try {
                sql = eventTimeLineQuery.getQuery(1, json, "default");
                logDebug("Generated SQL(eventTimeLineQuery) is : \n" + SqlFormatter.format(sql));
            } catch (Exception e) {
                log.error(e.getMessage());
                logDebug("Not a timeline filter");
            }
        }
    }

    private boolean shouldContinue() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("看看v2翻译成什么SQL，请修改library/filter-json/src/test/resources/utils/filterv2.json\n改好了吗?(Y/N)");
        String input = scanner.nextLine();
        System.out.println(input);
        return input!=null && input.equalsIgnoreCase("Y");
    }

    public void logDebug(String format) {
        Attribute[] myFormat = new Attribute[]{GREEN_TEXT(), BOLD()};
        log.debug(colorize(format, myFormat));
    }
}