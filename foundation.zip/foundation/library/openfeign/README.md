## Requirements

* Java 8

<br>

## 功能列表

* 根据配置项，在向下游服务的请求中添加 header 用以传递上下文。

* 用来访问使用 NGA 框架编写的内部接口时，在原有 ErrorDecoder 功能基础上，增加了把下游服务产生的业务异常反序列化成`DownstreamBusinessException`的功能。

* 可用作 OAuth2 Client 来访问受保护的接口，只需要在`application.yml`中配置 OAuth Client 所需的相关信息，能自动获取 accessToken 以及在 token 过期之前刷新 refreshToken。

<br>

## 如何使用

在`build.gradle`添加 gradle 依赖项：

```gradle
dependencies {
  implementation 'com.convertlab.foundation.library:openfeign-boot-starter:{version}'
}
```

声明作为 FeignClient 的 多个 Java Interface：

```java
@FeignClient(
    name = "demoClient",
    url = "${target.url}",
    configuration = ...)
public interface DemoClient {

  @PostMapping("/demos")
  void save(@Valid @RequestBody DemoRequest request);

  ...
}
```

在`application.yml`中为每个 FeignClient 配置参数。
```yaml
feign:
  client:
    config:
      {feignName}:
        connectTimeout: 5000
        readTimeout: 5000
        loggerLevel: full
```
或者为所有 FeignClient 配置默认参数。
```yaml
feign:
  client:
    config:
      default:
        connectTimeout: 5000
        readTimeout: 5000
        loggerLevel: full
```

<br>

### 全部可配置项

```yaml
convertlab:
  openfeign:
    propagation:
      tenant-id:
        - key: x-tenant-id
          location: header
      tenant-name:
        - key: x-tenant-name
          location: header
      user-id:
        - key: x-user-id
          location: header
      user-name:
        - key: x-user-name
          location: header
      request-id:
        - key: x-request-id
          location: header
    oauth2-client:
      enabled: false
```

**以上配置已有默认值，如无特殊不需要指定。**

| 配置项 | 值类型 | 示例 | 解释                                                        |
| --- | :--: | :--: |:----------------------------------------------------------|
| convertlab.openfeign.propagation.tenant-id | list |  | 指定如何传递 Tenant Id 给下游服务, 默认通过 Header 中 x-tenant-id 传递      |
| convertlab.openfeign.propagation.tenant-name | list |  | 指定如何传递 Tenant Name 给下游服务, 默认通过 Header 中 x-tenant-name 传递  |
| convertlab.openfeign.propagation.user-id | list |  | 指定如何传递 User Id 给下游服务, 默认通过 Header 中 x-user-id 传递          |
| convertlab.openfeign.propagation.user-name | list |  | 指定如何传递 User Name 给下游服务, 默认通过 Header 中 x-user-name 传递      |
| convertlab.openfeign.propagation.user-role | list | | 指定如何传递 User Roles 给下游服务, 默认通过 Header中 x-user-role 传递      |
| convertlab.openfeign.propagation.dept-code | list | | 指定如何传递 Department Code 给下游服务, 默认通过 Header中 x-dept-code 传递 |
| convertlab.openfeign.propagation.request-id | list |  | 指定如何传递 Request Id 给下游服务, 默认通过 Header 中 x-request-id 传递      |

<br>

### 用作内部 Web 接口的 Client

访问内部接口时，OpenFeign 会把 status code 值不等于2XX 的 response 反序列化包装成对应的 Exception。

| Status Code | Exception Class                           |
|-------------|-------------------------------------------|
| 400         | FeignClientException.BadRequest           |
| 401         | FeignClientException.Unauthorized         |
| 403         | FeignClientException.Forbidden            |
| 404         | FeignClientException.NotFound             |
| 405         | FeignClientException.MethodNotAllowed     |
| 406         | FeignClientException.NotAcceptable        |
| 409         | FeignClientException.Conflict             |
| 410         | FeignClientException.Gone                 |
| 415         | FeignClientException.UnsupportedMediaType |
| 429         | FeignClientException.TooManyRequests      |
| 422         | FeignClientException.UnprocessableEntity  |
| 除了以上之外的4XX  | FeignClientException                      |
| 500         | FeignServerException.InternalServerError  |
| 501         | FeignServerException.NotImplemented       |
| 502         | FeignServerException.BadGateway           |
| 503         | FeignServerException.ServiceUnavailable   |
| 504         | FeignServerException.GatewayTimeout       |
| 除了以上之外的5XX  | FeignServerException                      |
| 521         | DownstreamBusinessException               |

通过对 FeignClient 的接口做 try-catch 来对不同的异常做处理。

<br>

### 用作 OpenAPI 接口的 Client

调用 OpenAPI 接口时，client 框架需要提供的主要功能是获得 accessToken 放到 Authorization header 中，并且负责在 accessToken 失效之前刷新 refreshToken。
为了激活传递上下文信息的功能，需要确保`@FeignClient`的`configuration`属性中包含`OAuth2FeignConfiguration.class`
```java
@FeignClient(
    name = "openApiClient",
    url = "${test.url}",
    configuration = OAuth2FeignConfiguration.class)
public interface OpenApiClient {

  @GetMapping(value = "/payments", headers = "registrationId=authnz")
  IntegratedResponse<List> getPayments();
}
```

在`application.yml`中通过`spring.security.oauth2.client`配置 ClientRegistration 和 Provider 信息。
```yaml
spring:
  security:
    oauth2:
      client:
        registration:
          { registrationId }:
            provider: { provider }
            client-id: { client-id }
            client-secret: { client-secret }
            authorization-grant-type: client_credentials
            scope: {scopes}
            ...
        provider:
          { provider }:
            token-uri: { token-uri }
```

当`@FeignClient`的`configuration`属性中包含`OAuth2FeignConfiguration.class`时，
这个 interface 的 每个 method 必须包含名为`registrationId`的 header，header 的值对应`spring.security.oauth2.client.registration`指定的 registrationId。

<br>

**作为OAuth2 Client，会导致宿主应用在启动时自动访问 Authorization Server 以获取 Access Token。**
如果想要禁止这一个特征，可以按照以下方法配置：
1. 确保`application.yml`中没有设置`spring.security.oauth2.**`属性。
2. 在`application.yml`中指定`convertlab.openfeign.oauth2-client.enabled`为`false`。
```yaml
convertlab:
  openfeign:
    oauth2-client:
      enabled: false
```
<br>

### 用代理的方式访问外部资源

需要在`@FeignClient`的`configuration`属性中包含`ProxyFeignConfiguration.class`。

在`application.yml`中的`convertlab.openfeign.proxy.server`属性指定代理服务器的地址。

<br>

### 动态指定目标地址

如果需要`@FeignClient`的目标 url 的 base 路径能在调用时才确定，可以通过在`@FeignClient`中 method 的参数列表中声明一个`java.net.URI`类型的参数来实现。
```java
@FeignClient(name = "dynamicPingClient", url = "xxx")
public interface DynamicPingClient {
    
  @GetMapping(value = "/test/oneArg")
  String oneArg(URI baseUrl, @RequestParam("arg") String arg);
  
}
```
由于`@FeignClient`注解中的`url`是必须的，所以在这种使用场景下可以填充一个适当的地址用以通过编译，实际并不会向这个地址发起请求。
真正调用 FeignClient 的方法时再提供目标地址。
```java
URI uri = URI.create("http://localhost:" + port);
dynamicPingClient.oneArg(uri, str);
```

<br>

### 配置连接池

```yaml
feign:
  httpclient:
    max-connections: 1000 #最大连接数
    max-connections-per-route: 100 #每个路径的最大连接数
```