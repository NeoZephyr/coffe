```mermaid
---
title: ErrorCodes And Exceptions
---

classDiagram
direction BT

%% namespace ErrorCodes {
    
    class ErrorEnum {
    <<Interface>>
    String code
    String description
    String messageCode
    }
    
    class CommonErrors
    class MetaErrors
%% }

%%namespace Exceptions {
    class BackendException {
    + BackendException(ErrorEnum, String, String[]) 
    + BackendException(ErrorEnum, String[]) 
    + BackendException(ErrorEnum, String) 
    + BackendException(ErrorEnum) 
    + BackendException(BusinessException) 
    + BackendException(Throwable) 
    + BackendException(Throwable, String[]) 
    Throwable cause
    }
    class BusinessException {
    String code
    String description
    String messageCode
    String[] messageArguments
    Map<String, String> additions
    int httpStatusCode
    }
    class DownstreamBusinessException 
    class Exception 
    class MetaException 
    class RuntimeException 
    class Throwable
%% }

Exception  --|>  Throwable 
RuntimeException  --|>  Exception 
BusinessException  --|>  RuntimeException 
BackendException "1" *--> "cause 1" Throwable 
BackendException  --|>  BusinessException 
MetaException  --|>  BackendException 
DownstreamBusinessException  --|>  BusinessException 
CommonErrors ..|> ErrorEnum
MetaErrors ..|> ErrorEnum
BackendException  ..>  ErrorEnum
```

