## Requirements

* Java 8

## 如何使用

在`build.gradle`添加 gradle 依赖项：

```gradle
dependencies {
  implementation 'com.convertlab.foundation.library:commons-boot-starter:{version}'
}
```
## 其他
[Error Code & Exception Diagram](ExceptionDiagrams.md)
### 全局常量定义
#### 组件名称
[ComponentNames](commons-core/src/main/java/com/convertlab/foundation/library/constant/ComponentNames.java#L5-L76)
根据wiki
[消息Key中Module编号登记](https://confluence.xiaoshu.biz/pages/viewpage.action?pageId=148321661)定义每个模块的编码，模块种类包括
- 可运行的springboot app， e.g. Foundation, MA-MGT
- app下面的子package， e.g. Foundation.queryEngine
- 不依赖运行时app的library， e.g. sql-processor
#### 其他(Draft中)

### 工具类
#### LogUtils
##### `logAndThrow` 和 `warnAndThrow`
一般使用在案发现场上报异常的代码中,
这里只记录基本的用法，[LogAndBackendExceptionTest.java: Line 14](commons-core/src/test/java/com/convertlab/foundation/library/utils/LogAndBackendExceptionTest.java#L14)
里有一些更详细的使用的例子。
```java
     /**
     * <b>一般使用在案发现场上报异常的代码中</b><br/>
     * Log.warn the exception and throw it, 如果是BusinessException则直接抛出，否则包装成BusinessException再抛出
     * 日志会将BusinessException转换成字符串，格式为：[Error Code: 0010001] exception原生description due to reasonOfException.
     * Arguments=[异常参数1, 异常参数2]<br/>
     * 例如：[Error Code: 0010001] 无法找到对应的用户 due to 用户不存在. Arguments=[Evil]<br/>
      */
     public static BusinessException logAndThrow(@Nonnull Logger log, String reasonOfException,
                                                @Nonnull Throwable throwable);
     /**
     * <b>一般使用在案发现场上报异常的代码中</b><br/>
     * Log.error the exception and throw it, 如果是BusinessException则直接抛出，否则包装成BusinessException再抛出<br/>
     * 日志会将BusinessException转换成字符串，格式为：[Error Code: 0010001] exception原生description due to reasonOfException.
     * Arguments=[异常参数1, 异常参数2]<br/>
     * 例如：[Error Code: 0010001] 无法找到对应的用户 due to 用户不存在. Arguments=[Evil]<br/>
     */
    public static BusinessException warnAndThrow(@Nonnull Logger log, String reasonOfException,
                                                 @Nonnull Throwable throwable);
```
使用示例

```java
    try {
        ObjectResponse response = convertToResponse(generalSchemaMongoDao.update(object, collectionName));
        metaEventPublisher.publish(MetaEventPublisher.OBJECT_UPDATED,
                "刚刚成功修改了一个meta对象: " + response.getSelf());
        return response;
    } catch (OptimisticLockingFailureException e) {
        throw warnAndThrow(log, "OptimisticLockingFailureException occurred when updating object.",
                new MetaException(MetaErrors.OPTIMISTIC_LOCK, new String[]{ objectName, e.getMessage()}));
    } catch (Exception e) {
        throw logAndThrow(log, "Exception occurred when updating object.",
                new MetaException(MetaErrors.UNKNOWN_ERROR,
                new String[]{objectName, e.getMessage()}));
    }
```

##### `warn`和`error`
主要功能是格式化错误输出，保证
- 错误日志输出格式一致
- 既可以传入BusinessException，也可以不依赖Exception而是直接引用ErrorCode打印

例子

输出示例
```
14:41:23.891 [Test worker] WARN  c.c.f.l.u.LogAndBackendExceptionTest - [Error Code: 0010001] Failed to create object. 数据库连接超时 - 不用Exception. Arguments=[现场参数1, 现场参数2]
14:37:33.742 [Test worker] WARN  c.c.f.l.u.LogAndBackendExceptionTest - [Error Code: 0010001] 添加记录失败. 数据库连接超时. Arguments=[dmhub_su]
com.convertlab.foundation.library.exception.business.BackendException: 添加记录失败
	at com.convertlab.foundation.library.utils.LogAndBackendExceptionTest.testLogAndThrow(LogAndBackendExceptionTest.java:19)
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
...
14:37:33.767 [Test worker] ERROR c.c.f.l.u.LogAndBackendExceptionTest - [Error Code: 0010001] 添加记录失败. 数据库连接超时. Arguments=[dmhub_su]
com.convertlab.foundation.library.exception.business.BackendException: 添加记录失败
	at com.convertlab.foundation.library.utils.LogAndBackendExceptionTest.testLogAndThrow(LogAndBackendExceptionTest.java:19)
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
...
```

#### BackendException和ErrorUtils
`BackendException`是对`BusinessException`的包装，主要是为了
- 简化`BusinessException`的构造方法， 具体请直接参考注释 [BackendException](commons-core/src/main/java/com/convertlab/foundation/library/exception/business/BackendException.java#L10-L93)
- 包装不是`BusinessException`的其他`Exception`，例如`IllegalArgumentException`；而且将cause记录到additional
  properties里面，即使是序列化到了REST CLIENT端，也能知道root
  cause是什么Exception.
  可以参考[LogAndBackendExceptionTest](commons-core/src/test/java/com/convertlab/foundation/library/utils/LogAndBackendExceptionTest.java#L33-L47)
  和调用Foundation的API[SampleApiController](../../application/src/main/java/com/convertlab/foundation/misc/controller/SampleApiController.java#L17-L39)
  考察BACKEND_EXCEPTION/WRAPPED_BACKEND_EXCEPTION的返回值来测试

### 模板类
#### [ErrorEnum](commons-core/src/main/java/com/convertlab/foundation/library/exception/ErrorEnum.java#L5-L21) 接口
所有的ErrorCode都需要放在实现了`ErrorEnum`的一个enum结构中，具体的样子参考[README](#errorcode的通用规范)

### 使用推荐
#### 提供方
1. 定义一个自己的Error枚举类
2. 出错时，构造BackendException，并制定错误码
3. 使用LogUtils的函数来打印日志
4. 在枚举类里，按需关联Error Code和Message Code
#### 调用方
1. catch调用方的BusinessException
2. 获取并比对Error Code，做相应处理

### ErrorCode(错误码)和MessageCode(消息码)
wiki上的参考链接
- [09_API接口处理异常时的消息规范](https://confluence.xiaoshu.biz/pages/viewpage.action?pageId=148320796)
- [消息资源文件 & 消息Key规范](https://confluence.xiaoshu.biz/pages/viewpage.action?pageId=148321678)
- [03_日志规范](https://confluence.xiaoshu.biz/pages/viewpage.action?pageId=77498506)

#### 如何区分(必读)
主要从使用的场景来划分

##### ErrorCode
ErrorCode是被调用方(Library, Rest API, 甚至Kafka消息) 提供给调用方 ( App,
Rest Client, Kafka 消费者 ) 用以描述自身状态/出错 的系统编码。
- 使用者：调用方开发者Developer。
  调用方从Exception中获取错误码，然后根据错误码来编写处理逻辑。
- 使用者：Support。根据日志里出现的错误码来判断问题严重性，判断是否需要处理，及如何处理。
- 使用者：Debugger。根据日志错误码来定位问题，提供问题评估意见。

##### MessageCode
MessageCode是前端UI用来指分配给特定消息或通知的标识符或代码，该消息或通知将显示给用户在用户界面中。这些消息代码通常用作从消息包或资源文件中检索相应消息文本的键。
在典型的软件应用程序中，尤其是具有国际化（i18n）和本地化（l10n）支持的应用程序，显示给用户的消息与应用程序的源代码分开。应用程序不会直接将消息文本硬编码到代码中，而是使用消息代码来标识消息，实际消息文本将存储在外部资源文件中。
- 使用者：前端UI开发 Front End Developer。通过MESSAGE
  KEY找到资源文件里的国际化之后的消息文本，并显示。
- 使用者：国际化工程师。对每条MESSAGE KEY提供不同语言的消息文本。

##### ErrorCode和MessageCode的关系
- 只有一小部分的ErrorCode会有相应的MessageCode
- 只有一小部分的MessageCode是用来描述Error的

#### ErrorCode的使用
- 定义你需要的ErrorCode
- 在代码中结合ErrorCode使用Exception

##### ErrorCode的通用规范
- 所有的ErrorCode都是enum类型，都继承[ErrorEnum.java](commons-core/src/main/java/com/convertlab/foundation/library/exception/ErrorEnum.java),
- ErrorCode的格式是`模块码(3位数字)+小错误码(4位数字)`
- 模块码参考 [README](#组件名称)
- 参考下面的例子
  - ErrorCode是必须的
  - Description是必须的
  - MESSAGE CODE是可选的，进针对哪些需要向前端暴露的ERROR

 例如[ErrorUtilsTest.java: Lines 64-102](commons-core/src/test/java/com/convertlab/foundation/library/utils/ErrorUtilsTest.java#L64-L102)
```java
enum MyErrors implements ErrorEnum{
    // ERROR CODE Mapping表
    // 模块码999
    // 999+0001, DESC_001, MSG_001_000001; 消息码放到properties文件里！
    ERROR1("0001", "DESC_001", "MSG_001_000001"),
    // 999+0002, DESC_002, MSG_001_000002; 消息码放到properties文件里！
    ERROR2("0002", "DESC_002", "MSG_002_000002"),
    // 999+0003, "Unknown error", "MSG_000_000000"；默认描述和消息码
    ERROR2("0003", DEFAULT_DESCRIPTION, NO_MESSAGE_CODE),
    // 999+0004，没有描述，没有消息码
    ERROR2("0004", "", ""),
    ;

    // 通用部分，拷贝就好
    @Nonnull
    private final String code;
    @Nonnull
    private final String description;
    @Nonnull
    private final String messageCode;
    MyErrors(@Nonnull String errorCode, @Nonnull String description, @Nonnull String messageCode) {
        this.code = errorCode;
        this.description = description;
        this.messageCode = messageCode;
    }

    @Override
    @Nonnull
    public String getCode() {
        return EVIL1_CODE + code;
    }

    @Override
    @Nonnull
    public String getDescription() {
        return description;
    }

    @Override
    @Nonnull
    public String getMessageCode() {
        return messageCode;
    }
}
```
##### 系统默认的通用Code
[CommonErrors](commons-core/src/main/java/com/convertlab/foundation/library/constant/CommonErrors.java#L7-L63)

##### 模块中扩展的Code
每个模块单独实现，例如[MetaErrors](../meta/gdm-meta/src/main/java/com/convertlab/foundation/library/gdmmeta/client/exception/MetaErrors.java#L9-L48)

