package library.desensitize;

import com.convertlab.foundation.library.desensitize.MaskRule;
import com.convertlab.foundation.library.desensitize.MaskUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.*;

public class MaskUtilsTest {

    @Test
    public void testMaskField() {
        Assertions.assertEquals("12****789", MaskUtils.mask("123456789", MaskRule.buildPartMaskRule(MaskRule.MaskPosition.CENTER, 4)), "mask field failed");
        Assertions.assertEquals("****", MaskUtils.mask("1234", MaskRule.ALL), "mask as replace failed");
        Assertions.assertEquals("已加密", MaskUtils.mask("12345678", MaskRule.buildReplaceMaskRule("已加密")), "mask as replace failed");
    }

    @Test
    public void testMaskAll() {
        Assertions.assertNull(MaskUtils.maskAll(null), "mask null failed");
        Assertions.assertEquals("******", MaskUtils.maskAll("test12"), "mask all failed");
    }

    @Test
    public void testMaskPart() {
        Assertions.assertNull(MaskUtils.maskPart(null, MaskRule.MaskPosition.CENTER, 1), "mask null failed");
        Assertions.assertEquals("**", MaskUtils.maskPart("12", MaskRule.MaskPosition.CENTER, 4), "mask part failed");
        Assertions.assertEquals("12****78", MaskUtils.maskPart("12345678", MaskRule.MaskPosition.CENTER, 4), "mask part failed");
        Assertions.assertEquals("****5678", MaskUtils.maskPart("12345678", MaskRule.MaskPosition.LEFT, 4), "mask part failed");
        Assertions.assertEquals("1234****", MaskUtils.maskPart("12345678", MaskRule.MaskPosition.RIGHT, 4), "mask part failed");
        Assertions.assertEquals("12XXXX78", MaskUtils.maskPart("12345678", MaskRule.MaskPosition.CENTER, 4, 'X'), "mask part failed");
        Assertions.assertEquals("12****789", MaskUtils.maskPart("123456789", MaskRule.MaskPosition.CENTER, 4), "mask part failed");
    }

    @Test
    public void testMaskAsReplace() {
        Assertions.assertEquals("已加密", MaskUtils.maskAsReplace(null, "已加密"), "mask as replace failed");
        Assertions.assertEquals("已加密", MaskUtils.maskAsReplace("12345678", "已加密"), "mask as replace failed");
    }

    @Test
    public void testMaskMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("string", "123456789");
        map.put("Integer", 1);
        map.put("array", new String[]{"1234567", "2345678", "3456789"});
        List<String> listValue = new ArrayList<>();
        listValue.add("1234567");
        listValue.add("2345678");
        listValue.add("3456789");
        map.put("list", listValue);
        map.put("date", new Date());
        map.put("password", "123456");
        map.put("encrypted", "ras-encrypted");

        Map<String, MaskRule> rules = buildTestMaskRule();

        MaskUtils.mask(map, rules);
        Assertions.assertEquals("12****789", map.get("string"), "mask map failed");
        Assertions.assertEquals("1****67", ((String[]) map.get("array"))[0], "mask map failed");
        Assertions.assertEquals("1****67", ((List<String>) map.get("list")).get(0), "mask failed");
        Assertions.assertEquals("******", map.get("password"), "mask map failed");
        Assertions.assertFalse(map.containsKey("integer"), "mask map failed");
        Assertions.assertEquals("已加密", map.get("encrypted"), "mask map failed");
    }

    @Test
    public void testMaskListOfMap() {
        List<Map<String, Object>> list = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        map.put("string", "123456789");
        map.put("Integer", 1);
        map.put("array", new String[]{"1234567", "2345678", "3456789"});
        List<String> listValue = new ArrayList<>();
        listValue.add("1234567");
        listValue.add("2345678");
        listValue.add("3456789");
        map.put("list", listValue);
        map.put("date", new Date());
        map.put("password", "123456");
        map.put("encrypted", "ras-encrypted");
        list.add(map);

        Map<String, MaskRule> rules = buildTestMaskRule();

        MaskUtils.mask(list, rules);
        Assertions.assertEquals("12****789", list.get(0).get("string"), "mask map failed");
        Assertions.assertEquals("1****67", ((String[]) list.get(0).get("array"))[0], "mask map failed");
        Assertions.assertEquals("1****67", ((List<String>) list.get(0).get("list")).get(0), "mask failed");
        Assertions.assertEquals("******", list.get(0).get("password"), "mask map failed");
        Assertions.assertFalse(list.get(0).containsKey("integer"), "mask map failed");
        Assertions.assertEquals("已加密", list.get(0).get("encrypted"), "mask map failed");
    }

    private Map<String, MaskRule> buildTestMaskRule() {
        Map<String, MaskRule> rules = new HashMap<>();
        rules.put("string", MaskRule.buildPartMaskRule(MaskRule.MaskPosition.CENTER, 4));
        rules.put("password", MaskRule.ALL);
        rules.put("array", MaskRule.buildPartMaskRule(MaskRule.MaskPosition.CENTER, 4));
        rules.put("list", MaskRule.buildPartMaskRule(MaskRule.MaskPosition.CENTER, 4));
        rules.put("integer", MaskRule.HIDE);
        rules.put("encrypted", MaskRule.buildReplaceMaskRule("已加密"));
        return rules;
    }
}
