package com.convertlab.foundation.api.queryengine;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import static com.convertlab.foundation.api.queryengine.SqlBuilder.OutputFormat.GDQL;
import static com.convertlab.foundation.api.queryengine.SqlBuilder.SQLDialect.SPARK;

public class SqlBuilder {
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Request {
        private String gdql;
        private FilterV4Dto filter;
        @Nonnull
        private OutputFormat outputFormat = GDQL;
        @Nonnull
        private SQLDialect sqlDialect = SPARK;
        @Nullable
        private Impersonate impersonate;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Response {
        private String gdql;
        private String sql;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Impersonate {
        private Long userId;
        private String deptCode;
    }

    public enum OutputFormat {
        GDQL, SQL
    }

    public enum SQLDialect {
        MYSQL,
        SPARK,
        IMPALA
    }
}
