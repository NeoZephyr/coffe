package com.convertlab.foundation.api.gdmdata;

import javax.annotation.Nonnull;

import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

@NoArgsConstructor
public class GdmData extends HashMap<String, Object> {
    public GdmData(@Nonnull Map<String, Object> props) {
        super(props);
    }
}
