package com.convertlab.foundation.api.queryengine;

public interface GdmQueryApi {
    GdmQuery.Response query(GdmQuery.Request request);

    GdmCount.Response count(GdmCount.Request request);

    SqlBuilder.Response buildSql(SqlBuilder.Request request);
}
