package com.convertlab.foundation.api.queryengine;

import javax.annotation.Nonnull;
import javax.validation.constraints.NotNull;

import com.convertlab.foundation.library.constant.DataProcessingMode;
import com.convertlab.foundation.library.gdmmeta.model.FieldType;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

public class GdmQuery {
    /**
     * gdql或者filter参数二选一
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Request {
        private String gdql;
        private List<Arg> args;
        private FilterV4Dto filter;
        //此参数仅当filter参数不为空时生效
        @Nonnull
        private Boolean needTotal = false;
        private String processingMode;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Response {
        private Long total;
        private List<Map<String, Object>> rows;
        private long elapseTime;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Arg {
        private Object value;
        private FieldType type;
    }
}
