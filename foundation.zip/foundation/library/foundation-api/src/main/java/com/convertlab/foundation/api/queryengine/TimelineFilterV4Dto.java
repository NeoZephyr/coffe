package com.convertlab.foundation.api.queryengine;

import javax.annotation.Nonnull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

import static com.convertlab.foundation.api.queryengine.FilterV4Dto.IdentifierType.VALUE;
import static com.convertlab.foundation.api.queryengine.TimelineFilterV4Dto.Constants.*;

@Data
public class TimelineFilterV4Dto {
    public interface Constants {
        String OCCUR = "occur";
        String NOT_OCCUR = "not_occur";
        String TIME_RANGE = "time_range";
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    public static class Where extends FilterV4Dto.Where {
        private List<Occurrence> timeline;
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    public static class Occurrence extends FilterV4Dto.Operator {
        private String event;
        private String alias;
        @JsonProperty(TIME_RANGE)
        private TimeRange timeRange;
        private FilterV4Dto.LogicalOperator conditions;
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(OCCUR)
    public static class Occur extends Occurrence {

    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(NOT_OCCUR)
    public static class NotOccur extends Occurrence {

    }

    @Data
    @JsonTypeName(TIME_RANGE)
    public static class TimeRange {
        private FilterV4Dto.Identifier from;
        private FilterV4Dto.Identifier to;
    }

    public static class Builder {
        @Nonnull
        public static TimeRange buildTimeRange(@Nonnull Date from, @Nonnull Date to) {
            TimeRange range = new TimeRange();
            FilterV4Dto.Identifier dateFrom = new FilterV4Dto.Identifier(VALUE.getType(), String.valueOf(from.getTime()));
            range.setFrom(dateFrom);
            FilterV4Dto.Identifier dateTo = new FilterV4Dto.Identifier(VALUE.getType(), String.valueOf(to.getTime()));
            range.setTo(dateTo);
            return range;
        }
    }
}
