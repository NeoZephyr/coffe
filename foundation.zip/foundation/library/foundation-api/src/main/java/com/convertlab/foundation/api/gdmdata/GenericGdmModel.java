package com.convertlab.foundation.api.gdmdata;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.convertlab.foundation.library.gdmmeta.model.FieldType;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.gdmmeta.model.GdmField;
import lombok.Data;
import lombok.Getter;
import org.checkerframework.checker.initialization.qual.Initialized;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ReflectionUtils;
import org.springframework.util.StringUtils;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.*;

import static com.convertlab.foundation.library.gdmmeta.model.Gdm.conventionizedName;

/**
 * 通用的GDM Model，用于和GDM Entity相关联<br>
 * 通常情况下，我们会继承此类，然后定义自己的Domain Model，如下所示：<br>
 * <pre>
 * &#064;Setter
 * &#064;Getter
 * public class Profile extends GenericGdmModel {
 *     // 1. 这里定义此种Domain Model的固有属性，p.s. GDM entity中一定会有的字段
 *     private String name;
 *     private Date birthday;
 *     ...
 *     public Profile(GdmEntity gdmEntity) {
 *         super(gdmEntity);
 *     }
 * }
 * </pre>
 * <p>
 *     Model class必须放在<code>com.convertlab.foundation.api.gdmdata</code><br>
 *     或者<code>com.convertlab.macore.*.model</code>包下，否则无法使用。
 *</p>
 */
@Data
public class GenericGdmModel {
    @Nullable
    private Object pk;
    public static final String DEFAULT_ID_FIELD = "pk";

    @Nonnull
    public final Map<String, Object> props;

    @Nonnull
    @Getter
    private final GdmEntity gdmEntity;
    @Getter
    private final Map<String, GdmField> gdmFieldMap;

    public GenericGdmModel(@Nonnull GdmEntity gdmEntity) {
        this.props = new HashMap<>();
        this.gdmEntity = gdmEntity;
        this.gdmFieldMap = gdmEntity.conventionizedFieldsMap();
    }

    @Nonnull
    protected List<String> getStaticFields() {
        return StaticFieldsHolder.getStaticFieldsOf(this.getClass());
    }

    public void setPk(Object pk) {
        FieldType fieldType = getPkColumn().getFieldType();
        this.pk = convertTypeIfNecessary(fieldType, pk);
    }

    public GdmField getPkColumn() {
        return getPkColumn(gdmEntity);
    }

    public static GdmField getPkColumn(@Nonnull GdmEntity gdmEntity) {
        String primaryKeyField = gdmEntity.getPrimaryKeyField();
        return gdmEntity.getFields()
                .stream()
                .filter(gdmField -> gdmField.getFieldName().equals(primaryKeyField))
                .findAny()
                .orElseThrow(() -> new IllegalArgumentException("No pk found in " + gdmEntity.getEntityName()));
    }

    protected boolean isStaticField(@Nonnull GdmField field) {
        List<String> staticFields = getStaticFields();
        if(CollectionUtils.isEmpty(staticFields)) {
            return false;
        }
        return staticFields.stream()
                .anyMatch(x -> x.equals(caseInsensitiveField(field.getFieldName())));
    }

    public boolean isPrimaryKey(@Nonnull GdmField field) {
        return field.getFieldName().equals(gdmEntity.getPrimaryKeyField());
    }

    @Nullable
    protected Object getFieldValue(@Nonnull GdmField gdmField) {
        if (isPrimaryKey(gdmField)) {
            return this.getPk();
        } else if (isStaticField(gdmField)) {
            Field field = gdmFieldToField(gdmField);
            ReflectionUtils.makeAccessible(field);
            return ReflectionUtils.getField(field, this);
        } else {
            //Dynamic props
            return this.props.get(gdmField.getFieldName());
        }
    }

    @Nullable
    public Object getFieldValue(String fieldName) {
        GdmField gdmField = gdmFieldMap.get(fieldName);
        if (gdmField == null) {
            throw new IllegalArgumentException("No field " + fieldName + " found in " + gdmEntity.getEntityName());
        }
        return getFieldValue(gdmField);
    }

    public void setFieldValue(String fieldName, Object value) {
        GdmField gdmField = gdmFieldMap.get(fieldName);
        if (gdmField == null) {
            throw new IllegalArgumentException("No field " + fieldName + " found in " + gdmEntity.getEntityName());
        }
        setFieldValue(gdmField, value);
    }

    protected void setFieldValue(@Nonnull GdmField gdmField, @Nullable Object value) {
        Object convertedValue = convertTypeIfNecessary(gdmField.getFieldType(), value);
        if (isPrimaryKey(gdmField)) {
            if (convertedValue == null) {
                throw new IllegalArgumentException("Primary key cannot be null");
            }
            this.setPk(convertedValue);
        } else if (isStaticField(gdmField)) {
            Field field = gdmFieldToField(gdmField);
            ReflectionUtils.makeAccessible(field);
            ReflectionUtils.setField(field, this, convertedValue);
        } else {
            //Dynamic props
            if (convertedValue == null) {
                this.props.remove(gdmField.getFieldName());
            } else {
                this.props.put(gdmField.getFieldName(), convertedValue);
            }
        }
    }

    @SuppressWarnings("unchecked")
    @Nullable
    public static Object convertTypeIfNecessary(@Nonnull FieldType fieldType, @Nullable Object propValue) {
        if (propValue == null) {
            return null;
        }
        return fieldType.getJavaClass().isAssignableFrom(propValue.getClass()) ?
                propValue :
                convertType(fieldType, propValue);
    }

    private static final String BOOLEAN_TRUE = "1";
    @Nullable
    public static Object convertType(@Nullable FieldType fieldType, @Nullable Object propValue) {
        if (fieldType == null || propValue == null) {
            return propValue;
        }
        String value = propValue.toString();
        switch (fieldType) {
            case Long:
                return Long.parseLong(value);
            case Integer:
                return Integer.parseInt(value);
            case Short:
                return Short.parseShort(value);
            case Byte:
                return Byte.parseByte(value);
            case Double:
                return Double.parseDouble(value);
            case Decimal:
                return new BigDecimal(value);
            case Boolean:
                return BOOLEAN_TRUE.equals(propValue) || Boolean.parseBoolean(value);
            default:
                return propValue;
        }
    }

    @Nonnull
    protected Field gdmFieldToField(@Nonnull GdmField gdmField) {
        if (isPrimaryKey(gdmField)) {
            Field result = ReflectionUtils.findField(this.getClass(), DEFAULT_ID_FIELD);
            if (result == null) {
                throw new IllegalArgumentException("No field " + DEFAULT_ID_FIELD + " found in " + this.getClass().getSimpleName());
            }
            return result;
        }
        return Arrays.stream(this.getClass().getDeclaredFields())
                .filter(field -> field.getName().equalsIgnoreCase(caseInsensitiveField(gdmField.getFieldName())))
                .findAny()
                .orElseThrow(() -> new IllegalArgumentException("Unknown field " + gdmField.getFieldName() + " in class " + this.getClass().getSimpleName()));
    }

    @Nonnull
    public GdmField getGdmField(String fieldName) {
        GdmField gdmField = gdmFieldMap.get(fieldName);
        if (gdmField == null) {
            throw new IllegalArgumentException("No field " + fieldName + " found in " + gdmEntity.getEntityName());
        }
        return gdmField;
    }

    @Nonnull
    @SuppressWarnings("argument")
    public GdmData toGdmData() {
        GdmData dto = new GdmData(this.props);
        List<String> staticFields = this.getStaticFields();
        if(!CollectionUtils.isEmpty(staticFields)) {
            staticFields.forEach(gdmField -> {
                if(DEFAULT_ID_FIELD.equalsIgnoreCase(gdmField)) {
                    String pk = gdmEntity.getPrimaryKeyField();
                    Object idValue = this.getPk();
                    if (pk == null || idValue == null) {
                        throw new IllegalArgumentException("No pk found or id is null in " + gdmEntity.getEntityName());
                    }
                    dto.put(pk, idValue);
                } else {
                    Field field = gdmFieldToField(gdmFieldMap.get(gdmField));
                    dto.put(field.getName(), this.getFieldValue(gdmField));
                }
            });
        }
        return dto;
    }

    @Nonnull
    public static <T extends GenericGdmModel> T buildFromMap(@Nonnull Map<String, Object> gdmDataMap, @Nonnull GdmEntity gdmEntity, @Nonnull Class<T> clazz) {
        try {

            final @Initialized T model = ReflectionUtils.accessibleConstructor(clazz, new Class[]{GdmEntity.class}).newInstance(gdmEntity);
            if (model == null) {
                throw new IllegalArgumentException("Cannot create instance of " + clazz.getSimpleName());
            }
            gdmDataMap.forEach((k, v) -> {
                if (DEFAULT_ID_FIELD.equalsIgnoreCase(k)) {
                    model.setPk(v);
                } else {
                    GdmField field = model.getGdmField(k);
                    if (field == null) {
                        throw new IllegalArgumentException("Unknown field " + k + " in " + gdmEntity.getEntityName());
                    }
                    // DMHub的openapi允许通过传递“"代表清空字段
                    if("".equals (v) && (field.getFieldType() == FieldType.Long || field.getFieldType() == FieldType.Integer
                        || field.getFieldType() == FieldType.Byte || field.getFieldType() == FieldType.Short)){
                        v = null;
                    }
                    model.setFieldValue(field, v);
                }
            });
            return model;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Nonnull
    public static String caseInsensitiveField(@Nonnull String fieldName) {
        if (!StringUtils.hasText(fieldName)) {
            return fieldName;
        }
        return conventionizedName(fieldName);
    }
}
