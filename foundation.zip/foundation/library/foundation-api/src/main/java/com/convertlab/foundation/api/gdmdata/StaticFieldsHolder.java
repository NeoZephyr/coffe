package com.convertlab.foundation.api.gdmdata;

import javax.annotation.Nonnull;
import java.lang.annotation.*;
import java.lang.reflect.Field;
import java.util.*;

import org.reflections.Reflections;
import org.reflections.scanners.Scanners;
import org.reflections.util.ClasspathHelper;
import org.reflections.util.ConfigurationBuilder;
import org.reflections.util.FilterBuilder;

import static com.convertlab.foundation.api.gdmdata.GenericGdmModel.caseInsensitiveField;

public class StaticFieldsHolder {

    @Nonnull
    private static final Map<Class<?>, List<String>> staticFields;
    private static final FilterBuilder MODEL_FILTER;
    static {
        MODEL_FILTER = new FilterBuilder()
                .includePattern("com\\.convertlab\\.foundation\\.api\\.gdmdata\\..*")
                .includePattern("com\\.convertlab\\.macore\\..*\\.model\\..*");
        staticFields = getSubclassFieldsMap();
    }


    @Nonnull
    public static List<String> getStaticFieldsOf(Class<?> clazz) {
        List<String> fields = staticFields.get(clazz);
        if (fields == null) {
            return Collections.emptyList();
        }
        return fields;
    }
    private StaticFieldsHolder() {
    }

    @Nonnull
    private static Map<Class<?>, List<String>> getSubclassFieldsMap() {
        Map<Class<?>, List<String>> subclassFieldsMap = new HashMap<>();

        // Get all the subclasses of the parent class
        Reflections reflections = new Reflections(new ConfigurationBuilder()
                .setUrls(ClasspathHelper.forPackage("com.convertlab"))
                .filterInputsBy(MODEL_FILTER)
                .setScanners(
                        Scanners.SubTypes,
                        Scanners.TypesAnnotated));

        Set<Class<? extends GenericGdmModel>> subclasses = reflections.getSubTypesOf(GenericGdmModel.class);
        subclasses.add(GenericGdmModel.class);
        // Iterate through each subclass and get its private fields
        for (Class<?> subclass : subclasses) {
            List<String> fields = new ArrayList<>();
            Field[] allFields = subclass.getDeclaredFields();
            for (Field field : allFields) {
                if (java.lang.reflect.Modifier.isPrivate(field.getModifiers())
                        && !java.lang.reflect.Modifier.isFinal(field.getModifiers())
                        && !field.getName().startsWith("$")) {
                    fields.add(caseInsensitiveField(field.getName()));
                }
            }
            subclassFieldsMap.put(subclass, fields);
        }

        return subclassFieldsMap;
    }
}
