package com.convertlab.foundation.api.gdmdata;

import java.util.List;
import java.util.Map;

public interface GdmDataApi {
    GdmData selectById(String entityName, Object id, List<String> selectList);
    List<GdmData> selectByIds(String entityName, List<Object> ids, List<String> selectList, Integer offset, Integer limit, Map<String, Object> params);
    Object insert(String entityName, GdmData dto);
    GdmData deleteById(String entityName, Object id);
    int deleteByIds(String entityName, List<Object> ids);
    GdmData updateById(String entityName, Object id, GdmData dto);
}
