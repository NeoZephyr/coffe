package com.convertlab.foundation.api.queryengine;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

public class GdmCount {
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Request {
        private FilterV4Dto filter;
        private String processingMode;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Response {
        private Long total;
        private long elapseTime;
    }
}
