package com.convertlab.foundation.api.queryengine;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import lombok.*;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.convertlab.foundation.api.queryengine.FilterV4Dto.IdentifierType.COLUMN;
import static com.convertlab.foundation.api.queryengine.FilterV4Dto.Operator.Constants.*;
import static com.convertlab.foundation.api.queryengine.TimelineFilterV4Dto.Constants.OCCUR;
import static com.convertlab.foundation.api.queryengine.TimelineFilterV4Dto.Constants.NOT_OCCUR;

@Data
public class FilterV4Dto {
    private int version;
    private List<? extends Identifier> select;
    private String table;      //查表，和from参数二选一
    private FilterV4Dto from;  //子查询，和table参数二选一
    private Where where;
    private List<String> groupBy;
    private List<OrderByItem> orderBy;
    private Limit limit;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Limit {
        private Integer offset;
        private Integer row;

        public String toString() {
            return String.format("%s,%s", offset, row);
        }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class OrderByItem {
        private String field;
        private Boolean desc;
    }

    @Data
    public static class Where {
        private LogicalOperator logicalOp;
        private List<TimelineFilterV4Dto.Occurrence> timeline;
    }

    @Data
    @JsonTypeInfo(
            use = JsonTypeInfo.Id.NAME,
            include = JsonTypeInfo.As.WRAPPER_OBJECT
    )
    @JsonSubTypes({ //设置对应子类的识别码值
            @JsonSubTypes.Type(value = And.class, name = AND),
            @JsonSubTypes.Type(value = Or.class, name = OR),
            @JsonSubTypes.Type(value = Equal.class, name = EQUAL),
            @JsonSubTypes.Type(value = NotEqual.class, name = NOT_EQUAL),
            @JsonSubTypes.Type(value = GreatThan.class, name = GREAT_THAN),
            @JsonSubTypes.Type(value = GreatEqual.class, name = GREAT_EQUAL),
            @JsonSubTypes.Type(value = LessThan.class, name = LESS_THAN),
            @JsonSubTypes.Type(value = LessEqual.class, name = LESS_EQUAL),
            @JsonSubTypes.Type(value = In.class, name = IN),
            @JsonSubTypes.Type(value = NotIn.class, name = NOT_IN),
            @JsonSubTypes.Type(value = Like.class, name = LIKE),
            @JsonSubTypes.Type(value = NotLike.class, name = NOT_LIKE),
            @JsonSubTypes.Type(value = IsNull.class, name = IS_NULL),
            @JsonSubTypes.Type(value = IsNotNull.class, name = NOT_NULL),
            @JsonSubTypes.Type(value = IsBlank.class, name = IS_BLANK),
            @JsonSubTypes.Type(value = IsNotBlank.class, name = NOT_BLANK),
            @JsonSubTypes.Type(value = FalseOrNull.class, name = FALSE_OR_NULL),
            @JsonSubTypes.Type(value = EqOrNull.class, name = EQ_OR_NULL),
            @JsonSubTypes.Type(value = AllOf.class, name = ALL_OF),
            @JsonSubTypes.Type(value = NoneOf.class, name = NONE_OF),
            @JsonSubTypes.Type(value = Between.class, name = BETWEEN),
            @JsonSubTypes.Type(value = AttrEqual.class, name = ATTR_EQ),
            @JsonSubTypes.Type(value = AttrNotEqual.class, name = ATTR_NE),
            @JsonSubTypes.Type(value = AttrGreatThan.class, name = ATTR_GT),
            @JsonSubTypes.Type(value = AttrGreatEqual.class, name = ATTR_GE),
            @JsonSubTypes.Type(value = AttrLessThan.class, name = ATTR_LT),
            @JsonSubTypes.Type(value = AttrLessEqual.class, name = ATTR_LE),
            @JsonSubTypes.Type(value = TimelineFilterV4Dto.Occur.class, name = OCCUR),
            @JsonSubTypes.Type(value = TimelineFilterV4Dto.NotOccur.class, name = NOT_OCCUR)
    })
    public static abstract class Operator {
        public interface Constants {
            String AND = "and";
            String OR = "or";
            String EQUAL = "eq";
            String NOT_EQUAL = "ne";
            String GREAT_THAN = "gt";
            String GREAT_EQUAL = "ge";
            String LESS_THAN = "lt";
            String LESS_EQUAL = "le";
            String LIKE = "like";
            String NOT_LIKE = "not_like";
            String IN = "in";
            String NOT_IN = "not_in";
            String IS_NULL = "null";
            String NOT_NULL = "not_null";
            String IS_BLANK = "blank";
            String NOT_BLANK = "not_blank";
            String FALSE_OR_NULL = "false_or_null";
            String EQ_OR_NULL = "eq_or_null";
            String ALL_OF = "all_of";
            String NONE_OF = "none_of";
            String BETWEEN = "between";

            String ATTR_EQ = "attr_eq";
            String ATTR_NE = "attr_ne";
            String ATTR_GT = "attr_gt";
            String ATTR_GE = "attr_ge";
            String ATTR_LT = "attr_lt";
            String ATTR_LE = "attr_le";
        }
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    public static abstract class LogicalOperator extends Operator {
        private List<Operator> conditions;
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(AND)
    public static class And extends LogicalOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(OR)
    public static class Or extends LogicalOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    public static abstract class CompareOperator extends Operator {
        private Identifier left;
        private Identifier right;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonTypeInfo(use = JsonTypeInfo.Id.DEDUCTION, defaultImpl = Identifier.class)
    @JsonSubTypes({
            @JsonSubTypes.Type(value = ConditionalIdentifier.class)
    })
    public static class Identifier {
        private String type;
        @Nullable
        private String value;
        @Nullable
        private List<String> values;
        @Nullable
        private String alias;

        //Just for TMP_VIEW
        @Nullable
        protected String sql;
        @JsonProperty("primary_key")
        @Nullable
        protected String primaryKey;
        @Nullable
        protected String column;
        @Nullable
        @JsonProperty("column_type")
        protected String columnType;

        public Identifier(String type, @Nullable String value) {
            this(type, value, null);
        }

        public Identifier(String type, @Nullable String value, @Nullable String alias) {
            this.type = type;
            this.value = value;
            this.alias = alias;
        }

        public Identifier(String type, @Nullable String value, @Nullable List<String> values, @Nullable String alias) {
            this.type = type;
            this.value = value;
            this.values = values;
            this.alias = alias;
        }
    }
    @Data
    @EqualsAndHashCode(callSuper = true)
    @NoArgsConstructor
    public static class ConditionalIdentifier extends Identifier {
        private LogicalOperator logicalOp;
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(EQUAL)
    public static class Equal extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(Operator.Constants.NOT_EQUAL)
    public static class NotEqual extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(Operator.Constants.GREAT_THAN)
    public static class GreatThan extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(Operator.Constants.GREAT_EQUAL)
    public static class GreatEqual extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(Operator.Constants.LESS_THAN)
    public static class LessThan extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(Operator.Constants.LESS_EQUAL)
    public static class LessEqual extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(Operator.Constants.LIKE)
    public static class Like extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(Operator.Constants.NOT_LIKE)
    public static class NotLike extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(Operator.Constants.IS_NULL)
    public static class IsNull extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(Operator.Constants.NOT_NULL)
    public static class IsNotNull extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(Operator.Constants.IS_BLANK)
    public static class IsBlank extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(Operator.Constants.NOT_BLANK)
    public static class IsNotBlank extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(Operator.Constants.FALSE_OR_NULL)
    public static class FalseOrNull extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(Operator.Constants.EQ_OR_NULL)
    public static class EqOrNull extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(Operator.Constants.IN)
    public static class In extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(Operator.Constants.NOT_IN)
    public static class NotIn extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(ALL_OF)
    public static class AllOf extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(NONE_OF)
    public static class NoneOf extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(Operator.Constants.BETWEEN)
    public static class Between extends CompareOperator {
    }
    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(ATTR_EQ)
    public static class AttrEqual extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(ATTR_NE)
    public static class AttrNotEqual extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(ATTR_GT)
    public static class AttrGreatThan extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(ATTR_GE)
    public static class AttrGreatEqual extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(ATTR_LT)
    public static class AttrLessThan extends CompareOperator {
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    @JsonTypeName(ATTR_LE)
    public static class AttrLessEqual extends CompareOperator {
    }

    @RequiredArgsConstructor
    @Getter
    public enum IdentifierType {
        COLUMN("COLUMN", "列名", false, true),
        ATTR("ATTR", "属性比较列", false, true),
        VALUE("VALUE", "数值", false, false),
        VALUES("VALUES", "数值数组", false, false),
        PLACEHOLDER("PLACEHOLDER", "占位符", false, false),
        COUNT("COUNT", "count函数", true, true),
        MAX("MAX", "max函数", true, true),
        MIN("MIN", "min函数", true, true),
        AVG("AVG", "avg函数", true, true),
        SUM("SUM", "sum", true, true),
        AGG("AGGREGATION", "聚合函数", true, true),
        FUNC("FUNCTION", "函数", false, true);

        @Nonnull
        private final String type;
        @Nonnull
        private final String desc;
        private final boolean aggregation;
        private final boolean relationCheck;
    }

    @RequiredArgsConstructor
    @Getter
    public enum CompareNodeSide {
        LEFT("left", "左子式"),
        RIGHT("right", "右子式");

        @Nonnull
        private final String side;
        @Nonnull
        private final String desc;
    }

    public static class Builder {
        @Nonnull
        public static LogicalOperator buildLogicalNode(@Nonnull String op, @Nonnull Operator... conditions) {
            LogicalOperator node = newLogicalOp(op);
            node.setConditions(Arrays.stream(conditions).collect(Collectors.toList()));
            return node;
        }

        @Nonnull
        public static CompareOperator buildCompareNode(@Nonnull String op, String column, @Nullable Identifier value) {
            CompareOperator node = newCompareOp(op);
            Identifier left = new Identifier();
            left.setType(COLUMN.getType());
            left.setValue(column);
            node.setLeft(left);

            if (value != null) {
                node.setRight(value);
            }
            return node;
        }

        @Nonnull
        public static CompareOperator buildCompareNode(@Nonnull String op, String column, @Nullable IdentifierType type, @Nullable Object value) {
            CompareOperator node = newCompareOp(op);
            Identifier left = new Identifier();
            left.setType(COLUMN.getType());
            left.setValue(column);
            node.setLeft(left);

            if (type != null && value != null) {
                Identifier right = new Identifier();
                right.setType(type.getType());
                right.setValue(value.toString());
                node.setRight(right);
            }
            return node;
        }

        @Nonnull
        private static LogicalOperator newLogicalOp(@Nonnull String op) {
            switch (op) {
                case AND:
                    return new And();
                case OR:
                    return new Or();
                default:
                    throw new IllegalArgumentException("Unsupported op " + op);
            }
        }

        @Nonnull
        private static CompareOperator newCompareOp(@Nonnull String op) {
            switch (op) {
                case EQUAL:
                    return new Equal();
                case NOT_EQUAL:
                    return new NotEqual();
                case GREAT_THAN:
                    return new GreatThan();
                case GREAT_EQUAL:
                    return new GreatEqual();
                case LESS_THAN:
                    return new LessThan();
                case LESS_EQUAL:
                    return new LessEqual();
                case IN:
                    return new In();
                case NOT_IN:
                    return new NotIn();
                case IS_NULL:
                    return new IsNull();
                case NOT_NULL:
                    return new IsNotNull();
                case IS_BLANK:
                    return new IsBlank();
                case NOT_BLANK:
                    return new IsNotBlank();
                case FALSE_OR_NULL:
                    return new FalseOrNull();
                case LIKE:
                    return new Like();
                case NOT_LIKE:
                    return new NotLike();
                case BETWEEN:
                    return new Between();
                default:
                    throw new IllegalArgumentException("Unsupported op " + op);
            }
        }

    }
}