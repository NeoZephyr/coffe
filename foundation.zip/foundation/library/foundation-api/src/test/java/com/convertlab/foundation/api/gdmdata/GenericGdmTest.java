package com.convertlab.foundation.api.gdmdata;

import javax.annotation.Nonnull;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.convertlab.foundation.library.gdmmeta.client.GdmERMetaRtClient;
import com.convertlab.foundation.library.gdmmeta.client.mock.MockMetaClientBuilder;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import com.convertlab.foundation.library.multitenancy.context.TenantContextHelper;
import com.convertlab.macore.cdp.profile.AModel;
import com.convertlab.macore.cdp.profile.model.Driver;
import com.convertlab.macore.cdp.profile.model.submodel.BModel;
import lombok.Data;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GenericGdmTest {
    GdmERMetaRtClient metaClient;
    @BeforeEach
    void setup() {
        metaClient = MockMetaClientBuilder.buildErMetaHelperFromJsonFiles("/tenant10.json");
    }

    /**
     * Demo如何使用Model Class。这里就是Profile。
     */
    @Test
    @DisplayName("Demo如何使用Model Class")
    void demoHowToUseModelClass() {
        // 模拟租户上下文
        TenantContextHelper.withTenant(10L, ()-> {
            // 获取实体定义
            GdmEntity car = metaClient.getEntity("car");
            // 创建 Profile
            Profile bmw = new Profile(car);

            // 设置固定属性
            bmw.setName("宝马2号车");
            Date birthday = new Date(1684482542589L);
            bmw.setBirthday(birthday);
            bmw.setGender((byte) 1);
            bmw.setIsMember(true);
            // 设置动态属性
            bmw.setFieldValue("brand", "BMW");


            // 验证固定属性
            assertEquals("宝马2号车", bmw.getName());
            assertEquals(birthday, bmw.getBirthday());
            assertEquals((byte) 1, bmw.getGender());
            assertEquals(true, bmw.getIsMember());
            // 验证动态属性
            assertEquals("BMW", bmw.getFieldValue("brand"));
        });
    }

    /**
     * Demo如何从数据库读取数据，然后转换成Model Class。
     */
    @Test
    @DisplayName("Demo如何从数据库读取数据，然后转换成Model Class")
    void demoHowToConvertFromDataToModel(){
        // 模拟租户上下文
        TenantContextHelper.withTenant(10L, ()-> {
            // 从数据库读取数据，是个Map
            Map<String, Object> data = queryFromDB();

            // 从Map创建Profile
            Profile car = Profile.buildFromMap(data, metaClient.getEntity("car"), Profile.class);

            // 验证固定属性
            assertEquals("宝马2号车", car.getName());
            assertEquals(new Date(1684482542589L), car.getBirthday());
            assertEquals((byte) 1, car.getGender());
            assertEquals(true, car.getIsMember());
            // 验证动态属性
            assertEquals("BMW", car.getFieldValue("brand"));
        });
    }

    @Nonnull
    private Map<String, Object> queryFromDB() {
        Map<String, Object> data = new HashMap<>();
        data.put("name", "宝马2号车");
        data.put("birthday", new Date(1684482542589L));
        data.put("gender", (byte) 1);
        data.put("isMember", true);
        data.put("brand", "BMW");
        return data;
    }

    @Test
    void testAnotherModel() {
        TenantContextHelper.withTenant(10L, ()-> {
            GdmEntity driver = metaClient.getEntity("driver");
            Driver zhang3 = new Driver(driver);
            zhang3.setName("张三");
            zhang3.setGender((short) 1);
            zhang3.setFieldValue("address", "北京市海淀区");

            Assertions.assertThrows(IllegalArgumentException.class, ()->{
                zhang3.setFieldValue("brand", "不存在的字段");
            });

            assertEquals("张三", zhang3.getName());
            assertEquals((short) 1, zhang3.getGender());
            assertEquals("北京市海淀区", zhang3.getFieldValue("address"));
        });
    }

    @Test
    void testStaticFieldsHolder() {
        System.out.println("Profile:");
        StaticFieldsHolder.getStaticFieldsOf(Profile.class).forEach(System.out::println);
        System.out.println("\nDriver:");
        StaticFieldsHolder.getStaticFieldsOf(Driver.class).forEach(System.out::println);

        Assertions.assertEquals(4, StaticFieldsHolder.getStaticFieldsOf(Profile.class).size());
        Assertions.assertEquals(2, StaticFieldsHolder.getStaticFieldsOf(Driver.class).size());

        // MyProfile没有继承GenericGdmData，所以不会有static fields
        Assertions.assertEquals(0, StaticFieldsHolder.getStaticFieldsOf(MyProfile.class).size());
        // AModel没有放在model包下，所以不会有static fields
        Assertions.assertEquals(0, StaticFieldsHolder.getStaticFieldsOf(AModel.class).size());
        // BModel继承GenericGdmData，放在model包的子包下，所以也会有static fields
        Assertions.assertNotNull(StaticFieldsHolder.getStaticFieldsOf(BModel.class));
    }

    @Test
    void testRegex () {
        String regex = "com/convertlab/foundation/api/gdmdata/.*";
        String newRegex = "com\\.convertlab\\.foundation\\.api\\.gdmdata\\..*";
        String path = "com/convertlab/foundation/api/gdmdata/GenericGdmTest.class";
        String newPath = path.replace('/', '.');
        System.out.println(newPath);
        System.out.println(newRegex);
        Assertions.assertTrue(path.matches(regex));
        Assertions.assertTrue(newPath.matches(newRegex));
        Assertions.assertFalse("com.convertlab.foundation.api.gdmdataProfile".matches(regex));
    }

    @Test
    void testPerformanceOverhead() {
        TenantContextHelper.withTenant(10L, ()-> {
            GdmEntity gdmEntity = metaClient.getEntity("car");
            {
                Profile profile = new Profile(gdmEntity);
                profile.setName("宝马2号车");
                profile.setBirthday(new Date(1684482542589L));
                profile.setGender((byte) 1);
                profile.setIsMember(true);
                profile.setFieldValue("brand", "BMW");
            }

            long start;
            int count = 10000;
            // run performance test 3 times and compare the result
            for (int round = 0; round < 10; round++) {
                start = System.currentTimeMillis();
                for (int i = 0; i < count; i++) {
                    MyProfile profile = new MyProfile();
                    profile.setName("宝马2号车");
                    profile.setBirthday(new Date(1684482542589L));
                    profile.setGender((byte) 1);
                    profile.setIsMember(true);
                }
                System.out.println("简单Pojo耗时：" + (System.currentTimeMillis() - start) + "ms");

                start = System.currentTimeMillis();
                for (int i = 0; i < count; i++) {
                    Profile profile = new Profile(gdmEntity);
                    profile.setName("宝马2号车");
                    profile.setBirthday(new Date(1684482542589L));
                    profile.setGender((byte) 1);
                    profile.setIsMember(true);
                    profile.setFieldValue("brand", "BMW");
                }
                System.out.println("GdmModel耗时：" + (System.currentTimeMillis() - start) + "ms");

                start = System.currentTimeMillis();
                for (int i = 0; i < count; i++) {
                    Profile profile = new Profile(gdmEntity);
                    profile.setName("宝马2号车");
                    profile.setBirthday(new Date(1684482542589L));
                    profile.setGender((byte) 1);
                    profile.setIsMember(true);
                    profile.props.put("brand2", "BMW");
                }
                System.out.println("GdmModel direct write耗时：" + (System.currentTimeMillis() - start) + "ms");
            }

        });
    }
}

/**
 * 以下是一个普通的Java Bean，用于对比
 */
@Data
class MyProfile {
    private String name;
    private Date birthday;
    private Byte gender;
    private Boolean isMember;
}