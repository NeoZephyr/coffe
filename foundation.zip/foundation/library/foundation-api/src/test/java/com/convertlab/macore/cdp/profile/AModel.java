package com.convertlab.macore.cdp.profile;

import com.convertlab.foundation.api.gdmdata.GenericGdmModel;
import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;

public class AModel extends GenericGdmModel {
    private String testName;
    public AModel(GdmEntity gdmEntity) {
        super(gdmEntity);
    }
}
