package com.convertlab.foundation.api.gdmdata;

import java.lang.reflect.Field;
import java.util.*;

import com.convertlab.foundation.library.gdmmeta.model.GdmEntity;
import lombok.Getter;
import lombok.Setter;

/**
 * 演示如何写一个干净的Domain Model，并且和GdmEntity的定义相关联<br>
 * 按照如下两步即可。<br>
 * 同时请参考 @see ProfileTest.java 中的示例代码看如何使用。
 */
@Setter
@Getter
public class Profile extends GenericGdmModel {
    // 1. 这里定义此种Domain Model的固有属性，p.s. GDM entity中一定会有的字段
    private String name;
    private Date birthday;
    private Byte gender;
    private Boolean isMember;

    public Profile(GdmEntity gdmEntity) {
        super(gdmEntity);
    }
}