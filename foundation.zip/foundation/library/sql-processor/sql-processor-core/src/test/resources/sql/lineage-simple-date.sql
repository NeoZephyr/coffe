select id, driver_id, concat(id,driver_id) from
(select id, driver_id, FROM_UNIXTIME(CAST(bigint_date/1000 as SIGNED)) as _production_date from car) car1
where _production_date > '2024-03-15'
order by month(_production_date);
