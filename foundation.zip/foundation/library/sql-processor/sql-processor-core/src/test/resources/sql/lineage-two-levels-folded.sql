select t_id as tt_id, t_d_id as tt_d_id, concat(t_type, '-', t_brand) as tt_brand
from t
where t_owner_name = 'Y'
  and t_production_date > '2024-01-01';
