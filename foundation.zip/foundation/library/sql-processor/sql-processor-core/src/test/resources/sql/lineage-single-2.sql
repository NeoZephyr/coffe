# THIS MAY NOT BE A VALID SQL
# this is just a sample to collect the lineage information from sql syntax
select  car.id             as t_id,
       car.driver_id       as t_d_id ,
       car.driver_id + 1   as t_d_id_plus_1,
       car.brand           as t_brand,
       car.owner_name      as t_owner_name,
       car.production_date as t_production_date,
       concat(car.id, car.`type`) as t_id_plus_d_id
from car
where id = 1 OR car.driver_id + 1 = 1 OR length(car.owner_name) < 10 AND car.production_date > '2019-01-01';
# AND (COMPATIBLE_FUNCTION(t_production_date) = '2019-01-01' OR NON_COMPATIBLE_FUNCTION(t_production_date) = '2019-01-01')
# group by id, length(t_owner_name)
# order by t_id+t_d_id+1 desc, t_production_date asc


