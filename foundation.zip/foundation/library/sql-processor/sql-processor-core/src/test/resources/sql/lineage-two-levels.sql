select t_id as tt_id, t_d_id as tt_d_id, concat(t_type, '-', t_brand) as tt_brand
from (select id              as t_id,
             driver_id       as t_d_id,
             brand           as t_brand,
             `type`          as t_type,
             owner_name      as t_owner_name,
             production_date as t_production_date
      from car) t
where t_owner_name = 'Y'
  and t_production_date > '2024-01-01';