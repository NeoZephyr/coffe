SELECT
    COUNT(1)
FROM
    (
        SELECT
            customer.id
        FROM
            (
                SELECT
                    `id` AS `id`
                FROM
                    customer
                WHERE
                    customer.tenant_id = 8241
            ) customer LEFT SEMI
            JOIN (
                SELECT
                    static_list.customer_id AS customer_id
                FROM
                    (
                        SELECT
                            `customer_id` AS `customer_id`,
                            `list_id` AS `list_id`
                        FROM
                            list_member
                        WHERE
                            list_member.tenant_id = 8241
                    ) static_list
                WHERE
                    static_list.list_id IN (0)
            ) tmp0 ON customer.id = tmp0.customer_id LEFT SEMI
            JOIN (
            SELECT
            full_order.customer_id AS customer_id
            FROM
            (
            SELECT
            CAST(`is_header` AS BOOLEAN) AS `is_header`,
            `brand_name` AS `brand_name`,
            CAST(CAST(`date_order` / 1000 AS BIGINT) AS TIMESTAMP) AS `date_order`,
            `customer_id` AS `customer_id`
            FROM
            full_order
            WHERE
            full_order.tenant_id = 8241
            UNION
            ALL
            SELECT
            CAST(`is_header` AS BOOLEAN) AS `is_header`,
            `brand_name` AS `brand_name`,
            CAST(CAST(`date_order` / 1000 AS BIGINT) AS TIMESTAMP) AS `date_order`,
            `customer_id` AS `customer_id`
            FROM
            full_order_history
            WHERE
            dt IN (
            SELECT
            partition_id
            FROM
            cdp_table_partition
            WHERE
            target_table = 'full_order_history'
            AND end_time > -28800000
            AND start_time <= 1710259200000
            AND cdp_table_partition.tenant_id = 8241
            )
            AND full_order_history.tenant_id = 8241
            ) full_order
            WHERE
            full_order.is_header = 0
            AND full_order.date_order IS NOT NULL
            AND full_order.date_order >= '1969-12-31 16:00:00'
            AND full_order.date_order < '2024-03-12 16:00:00'
            AND full_order.brand_name LIKE '%KIEHLS%'
            ) tmp1 ON customer.id = tmp1.customer_id
    ) v4count;