select
    tmp_car.c_id as `车号`, tmp_driver.d_name as `司机姓名`
from
    (
        (
            select
                id + driver_id as c_id,
                driver_id as d_id
            from
                (
                    select
                        type as id,
                        driver_id
                    from
                        car
                ) temp_car_1
        ) tmp_car
            left join (
            select
                id as d_id,
                name as d_name
            from
                driver
        ) tmp_driver on tmp_car.d_id = tmp_driver.d_id
    )
where tmp_car.c_id not in (
    select
        id
    from
        car
)
order by tmp_car.c_id
;