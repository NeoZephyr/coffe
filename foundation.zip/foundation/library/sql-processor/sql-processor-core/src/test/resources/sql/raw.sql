SELECT
    e.employee_id,
    CONCAT(e.first_name ,' ' , e.last_name ) AS full_name,
    d.department_name AS department_name_from_select, e.hire_date as hire_date_from_select,
    CASE
        WHEN e.salary > (SELECT MAX(avg_salary) FROM (
                                                         SELECT employee_id, AVG(salary) as avg_salary
                                                         FROM employee_salaries
                                                         GROUP BY employee_id
                                                         HAVING AVG(salary) > 50000
                                                     ) cte) THEN 'High Earner'
        ELSE 'Regular Earner'
        END AS income_category_from_select,
    DATE_FORMAT(e.hire_date, '%Y-%m-%d') AS formatted_hire_date_from_select
FROM
    (
        SELECT
            employee_id,
            first_name,
            last_name,
            salary,
            hire_date
        FROM employees
        WHERE hire_date >= '2023-01-01'
    ) e
        JOIN
    (
        SELECT
            department_id,
            department_name
        FROM departments
        WHERE location_id IN (
            SELECT location_id
            FROM locations
            WHERE country_id = 'US'
        )
    ) d ON e.department_id = d.department_id
WHERE
    e.salary > 30000
ORDER BY
    income_category_from_select DESC, e.salary DESC;
