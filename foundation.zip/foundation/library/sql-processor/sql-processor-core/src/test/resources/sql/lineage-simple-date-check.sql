select id, driver_id, concat(id,driver_id) from car
where production_date > '2024-03-15' and month(production_date)>2 or month(car.production_date)<12;

