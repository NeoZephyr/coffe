package com.convertlab.foundation.library.arena;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;

@Slf4j
class EmailAddressTest {
    @Test
    void testEmailAddressRegex() {
        // 参考链接 https://www.abstractapi.com/guides/java-email-validation
        String regex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        String email = "abc.d@abc.com";
        log.info("email: {}, regex: {}, match: {}", email, regex, email.matches(regex));
    }
}
