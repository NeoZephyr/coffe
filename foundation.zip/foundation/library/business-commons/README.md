## 其他链接
[Event Broker 使用介绍](EventBroker.MD)

## Requirements

* Java 8

<br>

## 如何使用

在`build.gradle`添加 gradle 依赖项：

```gradle
dependencies {
  implementation 'com.convertlab.foundation.library:business-commons-boot-starter:{version}'
}
```

<br>

### FeatureClient

```java
  boolean checkToggleStatus(String feature);
```
查询某项 feature 是否开启。

* 输入参数

| 参数     | 值类型 |
|--------|:---:|
| feature | 需要查询的feature |

* 返回值
true：该项 feature 目前已开启；
false：该项 feature 不存在，或者未开启。

<br>

### QuotaClient

```java
  Long queryQuotaByFeature(String feature);
```
查询某项 feature 的限额。

* 输入参数

| 参数     | 值类型 |
|--------|:---:|
| feature | 需要查询的feature |

* 返回值

该项 feature 的限额。可能为 Null，表示该项 feature 未设置限额。

<br>

### AuditOperations

```java
  void log(AuditEvent<T> auditEvent);
```
记录 Audit 日志。

* 输入参数

| 参数     | 值类型 |
|--------|:---:|
| auditEvent | Audit 日志 |

<br>

如果 KafkaTemplate 存在，AuditOperations 的实现类是 KafkaAuditTemplate，以发送 Kafka 消息的方式异步记录 Audit。

### ExecutorUtils
```java
        Sring thredPoolName = "test-";
        int poolSize = 2;
        Executor executor = ExecutorUtils.createMdcTtlExecutor(thredPoolName, poolSize);
        
//        Runnable runnable = ...;
//        executor.execute(runnable);
```
获取Executor，并保留当前ThreadLocal和MDC的内容；
<br>
注：当前user_id和tenant_id等信息都是保留在ThreadLocal中，异步线程建议都使用该方法启动。
<br>
