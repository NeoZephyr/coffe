DROP TABLE IF EXISTS `feature`;

CREATE TABLE `feature`
(
    `id`           BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `tenant_id`    BIGINT NOT NULL,
    `version`      BIGINT NOT NULL,
    `company_name` VARCHAR(64)  DEFAULT NULL,
    `feature`      VARCHAR(64)  DEFAULT NULL,
    `enabled`      BOOLEAN      DEFAULT NULL,
    `date_created` DATETIME     DEFAULT NULL,
    `last_updated` DATETIME     DEFAULT NULL,
    `config`       VARCHAR(255) DEFAULT NULL
);

DROP TABLE IF EXISTS `limit`;

CREATE TABLE `limit`
(
    `id`           BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `tenant_id`    BIGINT NOT NULL,
    `version`      BIGINT NOT NULL,
    `company_name` VARCHAR(64)  DEFAULT NULL,
    `feature`      VARCHAR(64)  DEFAULT NULL,
    `quantity`     BIGINT       DEFAULT '0',
    `date_created` DATETIME     DEFAULT NULL,
    `last_updated` DATETIME     DEFAULT NULL,
    `ext_param`    VARCHAR(255) DEFAULT NULL
);