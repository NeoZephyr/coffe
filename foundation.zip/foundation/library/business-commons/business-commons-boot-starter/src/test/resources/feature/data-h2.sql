DELETE FROM `feature`;

INSERT INTO `feature` (tenant_id, version, company_name, feature, enabled, date_created, last_updated, config)
VALUES (9, 1, 'convertlab', 'udo_data_security', 0, '2022-06-13 05:50:16', '2022-06-13 05:51:49', '{}'),
       (9, 0, 'convertlab', 'data_security', 1, '2022-06-13 05:51:46', '2022-06-13 05:51:46', '{}'),
       (9, 1, 'convertlab', 'encryptionCustomer', 0, '2022-06-13 05:55:40', '2022-06-13 08:26:33', NULL),
       (9, 0, 'convertlab', 'page_v3', 1, '2022-06-13 05:58:55', '2022-06-13 05:58:55', '{}'),
       (1, 2, 'Phoenix', 'page_v3', 1, '2022-06-13 08:24:42', '2023-07-18 03:23:52', '{}'),
       (9, 8, 'convertlab', 'loyalty', 1, '2022-06-13 08:45:36', '2023-05-10 12:08:16', '{}'),
       (8, 0, 'PhoenixTets', 'show_content_tag', 1, '2022-06-13 09:18:20', '2022-06-13 09:18:20', '{}'),
       (1, 2, 'Phoenix', 'ab_test', 1, '2022-06-13 09:20:00', '2022-08-17 07:16:38', '{}'),
       (8, 0, 'PhoenixTets', 'share_fission', 1, '2022-06-13 09:20:23', '2022-06-13 09:20:23', '{}');

DELETE FROM `limit`;

INSERT INTO `limit` (tenant_id, version, company_name, feature, quantity, date_created, last_updated, ext_param)
VALUES (1, 4, 'Phoenix', 'dynamic_tag_num_limit', 2000, '2022-05-24 02:22:33', '2023-04-21 10:31:44', NULL),
       (1, 2, 'Phoenix', 'dynamic_list_num_limit', 999, '2022-05-24 02:22:33', '2022-07-20 10:27:25', NULL),
       (1, 0, 'Phoenix', 'flow_num_limit', 100000, '2022-05-24 02:22:33', '2022-05-24 02:22:33', NULL),
       (1, 0, 'Phoenix', 'external_tag_num_limit', 100000, '2022-05-24 02:22:33', '2022-05-24 02:22:33', NULL),
       (1, 0, 'Phoenix', 'external_udo_tag_num_limit', 100000, '2022-05-24 02:22:33', '2022-05-24 02:22:33', NULL),
       (1, 0, 'Phoenix', 'ana_offline_limit', 30, '2022-05-24 02:22:33', '2022-05-24 02:22:33', NULL),
       (7, 0, 'Convertlab', 'dynamic_tag_num_limit', 100000, '2022-05-27 03:13:26', '2022-05-27 03:13:26', NULL),
       (7, 0, 'Convertlab', 'dynamic_list_num_limit', 100000, '2022-05-27 03:13:26', '2022-05-27 03:13:26', NULL),
       (7, 0, 'Convertlab', 'flow_num_limit', 100000, '2022-05-27 03:13:26', '2022-05-27 03:13:26', NULL),
       (7, 0, 'Convertlab', 'external_tag_num_limit', 100000, '2022-05-27 03:13:26', '2022-05-27 03:13:26', NULL);