## Overview
Foundation-daemon为foundation中的基础组件提供可观测性和可管理性，比如，提供分布式缓存和分布式锁的观测和管理能力。

## 使用方法
导入依赖， 自动获得下述的能力
```gradle
dependencies {
  implementation 'com.convertlab.foundation.library:foundation-daemon:{version}'
}
```

## 分布式缓存

### 1. 查看所有的CacheName
* GET http://localhost:8080/v1/system/caches
* Request示例:
```shell
curl -X 'GET' 'http://localhost:8080/v1/system/caches'
```
* Response示例:
```json5
{
  "gdm:meta": "com.convertlab.foundation.library.redis.localcache.RedisPubSubBasedLocalCache",
  "SYS_BZ:META": "com.convertlab.foundation.library.redis.localcache.L2Cache",
  "biz:meta": "com.convertlab.foundation.library.redis.localcache.L2Cache"
}
```

### 2. 查看指定Cache指定Tenant中以keyPrefix开头的所有的key
* GET http://localhost:8080/v1/system/caches/{cacheName}/{keyPrefix}/keys
* Request示例:
```shell
curl -X 'GET' 'http://localhost:8080/v1/system/caches/gdm:meta/entity/keys' \
  -H 'x-tenant-id: 1'
```
* Response示例:
```json5
[
  "entity:customer",
  "entity:page_dt"
]
```

### 3. 查看指定Cache指定Tenant中以keyPrefix开头的Key的数量
* GET http://localhost:8080/v1/system/caches/{cacheName}/{keyPrefix}/size
* Request示例:
```shell
curl -X 'GET' 'http://localhost:8080/v1/system/caches/gdm:meta/entity/size' \
  -H 'x-tenant-id: 1'
```
* Response示例:
```json5
2
```

### 4. 查看指定Cache指定Tenant指定Key的值
* GET http://localhost:8080/v1/system/caches/{cacheName}/{key}
* Request示例:
```shell
curl -X 'GET' \
  'http://localhost:8080/v1/system/caches/gdm:meta/entity:customer' \
  -H 'x-tenant-id: 1'
```
* Response示例:
```json5
{
  "ext": {},
  "deletable": false,
  "modifiable": true,
  "isSystem": true,
  "entityName": "customer",
  "fields": [
    
    {
      "ext": {},
      "fieldName": "id",
      "fieldType": "Long",
      "dbColumnName": "id"
    },
    {
      "ext": {},
      "fieldName": "status",
      "fieldType": "String",
      "dbColumnName": "status"
    },
    //......
  ],
  "dbTableName": "v_customer",
  "primaryKeyField": "id",
  "dataProcessingModes": [
    "OLTP",
    "REALTIME_AP"
  ],
  "$version": "2963",
  "$self": "/v1/meta/gdm/entities/customer",
  "$basePath": "/v1/meta/gdm/entities",
  "dateCreated": "2024-06-12T10:41:38.417Z",
  "lastUpdated": "2024-07-03T06:20:22.910Z",
  "isDbView": false
}
```

### 5. 清除指定Cache指定Tenant中指定的Key
* DELETE http://localhost:8080/v1/system/caches/{cacheName}/{key}
* Request示例:
```shell
curl -X 'DELETE' 'http://localhost:8080/v1/system/caches/gdm:meta/entity:customer' \
  -H 'x-tenant-id: 1'
```
* Response示例:
```json5
"Cache key gdm:meta:entity:customer is evicted"
```

### 6. 清除指定Cache
* DELETE http://localhost:8080/v1/system/caches/{cacheName}
* Request示例:
```shell
curl -X 'DELETE' 'http://localhost:8080/v1/system/caches/gdm:meta'
```
* Response示例:
```json5
"Cache gdm:meta cleared"
```

注：
* 在Request Url中, 如果cacheName, key, keyPrefix中出现特殊字符，需要使用[urlEncode](https://www.urlencoder.io)编码

## 分布式锁

### 1. 查看特定租户所有的Redis Lock
* GET http://localhost:8080/v1/system/locks
* Request示例:
```shell
curl -X 'GET' 'http://localhost:8080/v1/system/locks' \
  -H 'x-tenant-id: -1'
```
* Response示例:
```json5
[
  "metaHealthChecker"
]
```
注：
* tenantId=-1指不区分租户的全局锁。

### 2. 释放Redis Lock
* DELETE http://localhost:8080/v1/system/locks/{lockKey}
* Request示例:
```shell
curl -X 'DELETE' 'http://localhost:8080/v1/system/locks/metaHealthChecker' \
  -H 'x-tenant-id: -1'
```
* Response示例:
```json5
true
```
注：
* 此接口适用于服务异常退出而没有正常释放Redis Lock的场景。