## Requirements

* Java 8

<br>

## 功能列表

* 提供`DynamicDataSource`实现动态切换数据源功能。

* 提供`OLTPJdbcTemplate`作为访问 OLTP 数据库的接口。

* 提供`OLAPJdbcTemplate`作为访问 OLAP 数据库的接口。

<br>

## 如何使用

在`build.gradle`添加 gradle 依赖项：

```gradle
dependencies {
  implementation 'com.convertlab.foundation.library:jdbc-boot-starter:{version}'
}
```

<br>

### 全部可配置项

```yaml
convertlab:
  dynamic-datasource:
    enabled: true
    primary: ds1
    datasources:
      {datasource}:
        driver-class-name: com.mysql.jdbc.Driver
        url: jdbc:mysql://127.0.0.1:3306/demo
        username: root
        password: root
        hikari:
          connection-test-query: SELECT 1
          connection-init-sql: "show databases;"
          maximum-pool-size: 25
          minimum-idle: 5
          connection-timeout: 30000
          pool-name: ds1-hikari-pool
```

| 配置项 | 值类型 | 示例 |解释 |
| --- | :--: | :--: | :-- |
| convertlab.dynamic-datasource.enabled | boolean |  | 指定是否启用 DynamicDataSource， 默认值为false |
| convertlab.dynamic-datasource.primary | string |  | 指定默认的数据源，当无法找到路由策略时，将使用这个数据源 |
| convertlab.dynamic-datasource.datasources.{datasource}.driver-class-name | string |  | 指定底层数据源的 Driver Class |
| convertlab.dynamic-datasource.datasources.{datasource}.url | string |  | 指定底层数据源的 URL |
| convertlab.dynamic-datasource.datasources.{datasource}.username | string |  | 指定底层数据源的 UserName |
| convertlab.dynamic-datasource.datasources.{datasource}.password | string |  | 指定底层数据源的 Password |
| convertlab.dynamic-datasource.datasources.{datasource}.hikari.* |  |  | 指定 Hikari 连接池的各种属性，参考[Hikari配置](https://docs.spring.io/spring-boot/docs/current/reference/html/application-properties.html#application-properties.data.spring.datasource.hikari)|

<br>

### 使用`DynamicDataSource`实现动态切换数据源功能

根据定义的规则选择当前的数据源。每次访问数据库时，通过 DataSourceLookupStrategy 决定使用哪一个底层数据源，从这个数据源中获取 Connection 来访问数据库。

已提供 DataSourceLookupStrategy 的默认实现类`ServiceUnitLookupStrategy` 以SU的逻辑实现动态路由数据源。