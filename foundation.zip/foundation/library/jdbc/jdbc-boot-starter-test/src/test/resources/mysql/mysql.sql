DROP TABLE IF EXISTS `types_tbl`;

CREATE TABLE `types_tbl`
(
    `id`             bigint    NOT NULL AUTO_INCREMENT,
    `tenant_id`      bigint    NOT NULL,
    `attr_char`      char(50)       DEFAULT NULL,
    `attr_varchar`   varchar(50)    DEFAULT NULL,
    `attr_tinyint`   tinyint        DEFAULT NULL,
    `attr_smallint`  smallint       DEFAULT NULL,
    `attr_int`       int            DEFAULT NULL,
    `attr_bigint`    bigint         DEFAULT NULL,
    `attr_double`    double         DEFAULT NULL,
    `attr_boolean`   tinyint(1)     DEFAULT '1',
    `attr_date`      date           DEFAULT NULL,
    `attr_timestamp` timestamp NULL DEFAULT NULL,
    `attr_datetime`  datetime       DEFAULT NULL,
    PRIMARY KEY (`id`)
);

DELETE
FROM types_tbl;

INSERT INTO `types_tbl` (`id`, `tenant_id`, `attr_char`, `attr_varchar`, `attr_tinyint`, `attr_smallint`, `attr_int`,
                         `attr_bigint`, `attr_double`, `attr_boolean`, `attr_date`, `attr_timestamp`, `attr_datetime`)
VALUES (1, 1, '2021-01-11', '2022-03-01T12:21:53Z', 1, 10, 10000, 1681108078666, 123.456, 1, '2023-04-09',
        '2023-04-09 17:09:33', '2023-04-09 17:09:33'),
       (2, 2, '2147483647120', NULL, NULL, NULL, NULL, 2147483647120, 21474836.22, 1, NULL, NULL, NULL);

