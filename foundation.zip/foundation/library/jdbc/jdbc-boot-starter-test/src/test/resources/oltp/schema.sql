DROP TABLE IF EXISTS `test_tbl`;

CREATE TABLE `test_tbl`
(
    `id`             bigint    NOT NULL AUTO_INCREMENT,
    `tenant_id`      bigint    NOT NULL,
    `attr_varchar`   varchar(50)    DEFAULT NULL,
    `attr_tinyint`   tinyint        DEFAULT NULL,
    `attr_int`       int            DEFAULT NULL,
    `attr_bigint`    bigint         DEFAULT NULL,
    `attr_double`    double         DEFAULT NULL,
    `attr_boolean`   tinyint(1)     DEFAULT '1',
    `attr_date`      date           DEFAULT NULL,
    `attr_timestamp` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`id`)
);