DROP TABLE IF EXISTS `employee`;

CREATE TABLE `employee`
(
    `id`   int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `name` varchar(45) DEFAULT NULL,
    `role` varchar(45) DEFAULT NULL
)