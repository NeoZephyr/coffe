DELETE
FROM `test_tbl`;

INSERT INTO `test_tbl` (`id`, `tenant_id`, `attr_varchar`, `attr_tinyint`, `attr_int`, `attr_bigint`, `attr_double`, `attr_boolean`, `attr_date`, `attr_timestamp`)
VALUES
       (1, 1, '2020-03-01T12:21:53Z', 1, 1, 1, NULL, 1, NULL, NULL),
       (2, 1, '2022-03-01T12:21:53Z', NULL, 2, NULL, NULL, 0, NULL, NULL),
       (3, 1, '2023-03-01T12:21:53Z', NULL, 3, NULL, NULL, 1, NULL, NULL),
       (4, 2, '21', NULL, NULL, 1681108078666, NULL, 1, NULL, NULL),
       (5, 2, '22', NULL, NULL, 1649742660111, NULL, 1, NULL, NULL),
       (6, 2, '23', NULL, NULL, 1586497951333, NULL, 1, NULL, NULL),
       (7, 3, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
       (8, 3, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
       (9, 3, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL);

