DELETE
FROM employee;

INSERT INTO `employee`
VALUES (1, 'sraddha', 'LEAD');
