DELETE
FROM employee;

INSERT INTO `employee`
VALUES (1, 'attyuttam', 'ADMIN'),
       (2, 'debarka', 'DEVELOPER'),
       (3, 'nilesh', 'MANAGER');
