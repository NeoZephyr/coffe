DELETE FROM udo1;

INSERT INTO udo1 (id, tenant_id, attr1, attr2, attr3)
VALUES (1, 10, 'a1', '10000', 16000),
       (2, 20, 'a2', '20000', 26000),
       (3, 10, 'a3', '30000', 36000);

DELETE FROM udo2;

INSERT INTO udo2 (id, tenant_id, attr1, attr2, attr3)
VALUES (1, 10, '***', '***', 16000),
       (2, 10, '***', '***', 26000),
       (3, 10, '***', '***', 36000);

DELETE FROM udo3;

INSERT INTO udo3 (id, tenant_id, attr1)
VALUES (1, 10, 12.21),
       (2, 10, 60.36),
       (3, 10, 1.58);