DROP TABLE IF EXISTS udo1;

CREATE TABLE udo1
(
    id        BIGINT      NOT NULL PRIMARY KEY,
    tenant_id BIGINT      NOT NULL,
    attr1     VARCHAR(30) NULL DEFAULT NULL,
    attr2     VARCHAR(30) NULL DEFAULT NULL,
    attr3     INT         NULL DEFAULT NULL
);

DROP TABLE IF EXISTS udo2;

CREATE TABLE udo2
(
    id        BIGINT      NOT NULL PRIMARY KEY,
    tenant_id BIGINT      NOT NULL,
    attr1     VARCHAR(30) NULL DEFAULT NULL,
    attr2     VARCHAR(30) NULL DEFAULT NULL,
    attr3     INT         NULL DEFAULT NULL
);

CREATE TABLE udo3
(
    id        BIGINT        NOT NULL PRIMARY KEY,
    tenant_id BIGINT        NOT NULL,
    attr1     DECIMAL(6, 2) NULL DEFAULT NULL
);