对[百度 UidGenerator](baidu_uidgenerator.zh_cn.md)做了定制开发，基于Snowflake算法的唯一ID生成器。

<br>

## Requirements

* Java 8

<br>

## 功能列表

* 通过 YAML 配置即可简单注入ID生成器。

* 基于 redis 实现的 worker id 生成器。

<br>

## 如何使用

在`build.gradle`添加 gradle 依赖项：
```gradle
dependencies {
  implementation 'com.convertlab.foundation.library:uid-generator-boot-starter:{version}'
}
```

在`application.yml`中通过`convertlab.uid.generators.*`配置一个或多个 UidGenerator。

<br>

### 全部可配置项

```yaml
convertlab:
  uid:
    generators:
      {qualifier}:
        cached: false
```

| 配置项                          | 值类型     |      示例       | 解释                                                                                                                   |
|------------------------------|:--------|:-------------:|:---------------------------------------------------------------------------------------------------------------------|
| convertlab.uid.generators.{qualifier} | string  |  | 指定 UidGenerator 的 qualifier                                                                                          |
| convertlab.uid.generators.{qualifier}.cached | boolean |  | 值为 true 时，表示指定该 UidGenerator 为 `CachedUidGenerator`; 值为 false 时，表示指定该 UidGenerator 为`DefaultUidGenerator`，默认值为 false |

由于 worker id 需要使用 redis 作为注册中心来保证唯一性，所以必须提供 redis 的连接信息。
```yaml
spring:
  redis:
    host: localhost
    port: 6379
    database: 0
```

配置成功后，在代码中就可以通过`@Autowired`结合`@Qualifier`注入`UidGenerator`的Bean，
Bean名字规则是 ${qualifier}UidGenerator 。
```java
@Autowired
@Qualifier("uid1UidGenerator")
private UidGenerator uid1UidGenerator;

@Autowired
@Qualifier("uid2UidGenerator")
private UidGenerator uid2UidGenerator;
```

通过调用`UidGenerator`的`getUID`方法获得 UID。
```java
long uid = uidGenerator.getUID();
```


### Reference(By Cloude GPT)
| Algorithm  | Uniqueness | Sortable | Ordered | Embed Metadata | Readability | Collision Probability | Performance | Storage Size | Monotonic | Centralization Required | Implementation Complexity | Collision Resolution    | Ordering Flexibility | Security        | Concurrency Support |    |    |
|:-----------|:-----------|:---------|:--------|:---------------|:------------|:----------------------|:------------|:-------------|:----------|:------------------------|:--------------------------|:------------------------|:---------------------|:----------------|:--------------------|:---|:---|
| UUID       | High       | No       | No      | No             | Low         | Very Low              | Slow        | 128 bits     | No        | No                      | Low                       | No                      | No                   | Low             | Yes                 |    |    |
| Sequential | Moderate   | Yes      | Yes     | No             | High        | Moderate              | Very Fast   | 32-64 bits   | Yes       | Yes                     | Low                       | Needs external handling | Configurable         | Moderate        | With coordination   |    |    |
| Snowflake  | High       | Yes      | Roughly | Yes            | Moderate    | Low                   | Fast        | 64 bits      | Roughly   | Yes                     | Moderate                  | No                      | Configurable         | Moderate        | Yes                 |    |    |
| ObjectID   | High       | No       | No      | Yes            | Low         | Very Low              | Fast        | 96 bits      | No        | No                      | Low                       | No                      | No                   | Low             | Yes                 |    |    |
| Hashing    | High       | No       | No      | Configurable   | Low         | Low                   | Fast        | 32-128 bits  | No        | No                      | Highly variable           | No                      | No                   | Highly variable | Yes                 |    |    |
| NanoID     | High       | No       | No      | No             | High        | Very Low              | Very fast   | 21 chars     | No        | No                      | Low                       | No                      | No                   | Low             | Yes                 |    |    |
| ULID       | High       | Yes      | Roughly | Yes            | Moderate    | Very Low              | Fast        | 26 chars     | Roughly   | No                      | Low                       | No                      | No                   | Low             | Yes                 |    |    |
| UUIDv1     | High       | No       | No      | Yes            | Low         | Very Low              | Slow        | 128 bits     | No        | No                      | Low                       | No                      | No                   | Low             | Yes                 |    |    |
| UUIDv4     | High       | No       | No      | No             | Low         | Very Low              | Slow        | 128 bits     | No        | No                      | Low                       | No                      | No                   | Low             | Yes                 |    |    |
| Flake ID   | High       | Yes      | Yes     | Configurable   | Moderate    | Very Low              | Fast        | 64-128 bits  | Yes       | Yes                     | Moderate                  | No                      | Configurable         | Low             | Yes                 |    |    |
