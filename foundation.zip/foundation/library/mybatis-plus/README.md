## Requirements

* Java 8

<br>

## 功能列表

* 无论是 MyBatis 风格的 XML 定义 SQL 语句，还是 MyBatis-Plus 风格的 Mapper CRUD 接口，对于多租户表的增删改查操作都会自动拼接租户ID的条件。

* 结合`uid-generator`，对于`ASSIGN_ID`类型的主键，可以通过 Snowflake 唯一ID生成器生成ID值。

* 插入数据时，自动填充`dateCreated`和`lastUpdated`字段；更新数据时，自动更新`lastUpdated`字段。

* 插入数据时，自动填充`creatorId`和`creatorName`字段。

* 插入数据时，自动填充`updaterId`和`updaterName`字段。

* 插入数据时，`version`字段自动填充为1；更新数据时，`version`字段自动增加1。

<br>

## 如何使用

在`build.gradle`添加 gradle 依赖项：
```gradle
dependencies {
  implementation 'com.convertlab.foundation.library:mybatis-plus-boot-starter:{version}'
}
```

* 多租户表的实体类请继承`BaseTenantEntity`。
```java
public class UserEntity extends BaseTenantEntity {
  ...
}
```

* 非多租户表的实体类请继承`BaseEntity`。
```java
public class AddressEntity extends BaseEntity {
  ...
}
```

<br>

### 全部可配置项

```yaml
convertlab:
  mybatis:
    multi-tenancy:
      ignored-tables:
        - user_address
      identifier:
        tenant-id:
          key: tenant_id
          location: column
```
**以上配置已有默认值，如无特殊不需要指定。**

| 配置项 | 值类型 | 示例 |解释 |
| --- | :--: | :--: | :-- |
| convertlab.mybatis.multi-tenancy.identifier.tenant-id.key | string |  | 指定中的哪个字段作为租户识别列 |
| convertlab.mybatis.multi-tenancy.ignored-tables | list |  | 指定访问时不需要进行多租户处理的表 |

<br>

### 多租户模式下租户间数据隔离

如果是多租户表，会自动拼接上租户ID的条件，以此保证租户间的数据隔离；对于非多租户表，则不会添加过滤条件。
默认都是多租户表，非多租户的表需要在`application.yml`的`convertlab.mybatis.multi-tenancy.ignored-tables`中指定。

**注意：如果用 XML 定义 SQL，请勿在 SQL 语句中自行添加租户条件；如果使用 Mapper CRUD 接口，请勿自行给租户字段赋值。**（多租户字段必须是包装类型，基础类型会有默认值）

<br>

如果需要在一个Mapper的方法中以不隔离的模式访问多租户表，可以通过在方法上使用`@InterceptorIgnore(tenantLine = "true")`注解：
```java
public interface UserMapper extends BaseMapper<UserEntity> {
    
    @InterceptorIgnore(tenantLine = "true")
    List<UserEntity> listAllUser();
```

<br>

### 使用 Snowflake UID Generator 生成 ID 主键

对于主键生成策略为`ASSIGN_ID`类型的表，可以借助`uid-generator`模块的功能来生成主键值。

```yaml
convertlab:
  uid:
    generators:
      myDefault:
        cached: true
```

在实体类的主键字段上添加`@UseUidGenerator`注解来指定 UID Generator 的 qualifier，这个 qualifier 应该列在`convertlab.uid.generators`中，否则将产生`org.mybatis.spring.MyBatisSystemException`异常。
```java
@TableId(value = "id") // 不指定type时，默认为 IdType.ASSIGN_ID
@UseUidGenerator("myDefault")
private Long id;
```

如果使用了`@UseUidGenerator`，必须和`@TableId`放在同一个字段上。

一个应用中可以定义多个不同的 UID Generator。对于新增数据QPS高的表，建议指定一个单独的 UID Generator 作为ID生成器，其它的表可以多表共用一个 UID Generator。 

<br>

### 调试时在日志中输出生成的 SQL

请在`application.yml`中添加以下配置：
```yaml
mybatis-plus:
  configuration:
    log-impl: org.apache.ibatis.logging.stdout.StdOutImpl
```

实现效果如下图：
![SQL日志示例](https://s2.loli.net/2022/04/28/fXGzA7Hv8wNJp6l.png)

<br>

### 固定字段自动填充

推荐 Entity 类继承自`BaseEntity`以便捷获得这些字段。

* `version`：对应数据表中的`version`字段。新增记录时，这条记录的`version`字段自动被赋值为1；更新记录时，这条记录的`version`字段自动增加1。仅仅填充`version`字段，不附带乐观锁的效果。

* `creatorId`：对应数据表中的`creator_id`字段。当前线程中如果存在`LoginUserContext`，新增记录时，这条记录的`creator_id`字段自动被赋值为 LoginUserContext 的 userId；更新记录时，这条记录的`creator_id`禁止更新。

* `creatorName`：对应数据表中的`creator_name`字段。当前线程中如果存在`LoginUserContext`，新增记录时，这条记录的`creator_name`字段自动被赋值为 LoginUserContext 的 userName；更新记录时，这条记录的`creator_name`禁止更新。

* `dateCreated`：对应数据表中的`date_created`字段。新增记录时，这条记录的`date_created`字段自动被赋值为当前系统时间；更新记录时，这条记录的`date_created`禁止更新。

* `lastUpdated`：对应数据表中的`last_updated`字段。新增记录时，这条记录的`last_updated`字段自动被赋值为当前系统时间；更新记录时，这条记录的`last_updated`字段自动被更新为当前系统时间。

**注意：如果要确保`dateCreated`和`lastUpdated`填充成功，需要数据库URL加上 `serverTimezone=UTC`，否则会出现自动填充失败。**