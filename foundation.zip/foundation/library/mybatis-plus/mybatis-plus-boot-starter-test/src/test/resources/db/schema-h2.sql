DROP TABLE IF EXISTS user_entity;

CREATE TABLE user_entity
(
    id           BIGINT(20)  NOT NULL COMMENT '主键ID',
    name         VARCHAR(30) NULL DEFAULT NULL COMMENT '姓名',
    age          INT(11)     NULL DEFAULT NULL COMMENT '年龄',
    tenant_id    BIGINT      NOT NULL COMMENT '租户ID',
    version      INT(11)     NULL DEFAULT NULL COMMENT '版本',
    last_updated DATETIME    NULL COMMENT '更新时间',
    date_created DATETIME    NULL COMMENT '创建时间',
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS user_role;

CREATE TABLE user_role
(
    id           BIGINT(20)  NOT NULL COMMENT '主键ID',
    user_id      BIGINT(20)  NOT NULL COMMENT '用户ID',
    role         VARCHAR(30) NULL DEFAULT NULL COMMENT '角色名称',
    tenant_id    BIGINT      NOT NULL COMMENT '租户ID',
    last_updated DATETIME    NULL COMMENT '更新时间',
    date_created DATETIME    NULL COMMENT '创建时间',
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS user_address;

CREATE TABLE user_address
(
    id           BIGINT(20)  NOT NULL COMMENT '主键ID',
    user_id      BIGINT(20)  NOT NULL COMMENT '用户ID',
    address      VARCHAR(30) NULL DEFAULT NULL COMMENT '地址名称',
    last_updated DATETIME    NULL COMMENT '更新时间',
    date_created DATETIME    NULL COMMENT '创建时间',
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS customer;

CREATE TABLE customer
(
    id           BIGINT(20)  NOT NULL COMMENT '主键ID',
    name         VARCHAR(30) NULL DEFAULT NULL COMMENT '姓名',
    tenant_id    BIGINT      NOT NULL COMMENT '租户ID',
    version      INT(11)     NULL DEFAULT NULL COMMENT '版本',
    creator_id   BIGINT(20)  NULL COMMENT '创建者ID',
    creator_name VARCHAR(30) NULL COMMENT '创建者姓名',
    updater_id   BIGINT(20)  NULL COMMENT '修改者ID',
    updater_name VARCHAR(30) NULL COMMENT '修改者姓名',
    last_updated DATETIME    NULL COMMENT '更新时间',
    date_created DATETIME    NULL COMMENT '创建时间',
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS address;

CREATE TABLE address
(
    id           BIGINT(20)  NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    address      VARCHAR(30) NULL DEFAULT NULL COMMENT '地址名称',
    tenant_id    BIGINT      NOT NULL COMMENT '租户ID',
    last_updated DATETIME    NULL COMMENT '更新时间',
    date_created DATETIME    NULL COMMENT '创建时间',
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS udo;

CREATE TABLE udo
(
    id             BIGINT(20)  NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    tenant_id      BIGINT      NOT NULL COMMENT '租户ID',
    attr_string    VARCHAR(50) NULL DEFAULT NULL,
    attr_long      BIGINT      NULL,
    attr_timestamp TIMESTAMP   NULL,
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS udo1;

CREATE TABLE udo1
(
    id        BIGINT      NOT NULL PRIMARY KEY,
    tenant_id BIGINT      NOT NULL,
    attr1     VARCHAR(30) NULL DEFAULT NULL,
    attr2     VARCHAR(30) NULL DEFAULT NULL,
    attr3     INT         NULL DEFAULT NULL
);

DROP TABLE IF EXISTS udo2;

CREATE TABLE udo2
(
    id        BIGINT      NOT NULL PRIMARY KEY,
    tenant_id BIGINT      NOT NULL,
    attr1     VARCHAR(30) NULL DEFAULT NULL,
    attr2     VARCHAR(30) NULL DEFAULT NULL,
    attr3     INT         NULL DEFAULT NULL
);