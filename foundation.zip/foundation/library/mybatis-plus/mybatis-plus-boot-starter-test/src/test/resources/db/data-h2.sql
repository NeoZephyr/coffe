DELETE
FROM user_entity;

INSERT INTO user_entity (id, name, age, tenant_id, last_updated, date_created)
VALUES (1, 'Jone', 18, 11, '2022-02-23 15:43:03', '2022-02-23 15:43:03'),
       (2, 'Jack', 20, 1, null, null),
       (3, 'Tom', 28, 2, null, null),
       (4, 'Justin1', 18, 3, null, null),
       (5, 'Justin2', 18, 3, null, null),
       (6, 'Justin3', 18, 3, null, null),
       (7, 'Justin4', 18, 3, null, null),
       (8, 'Justin5', 18, 3, null, null),
       (9, 'Justin6', 18, 3, null, null),
       (10, 'Justin7', 18, 3, null, null),
       (11, 'Justin8', 18, 3, null, null),
       (12, 'Justin9', 18, 3, null, null),
       (13, 'Justin10', 18, 3, null, null),
       (14, 'Justin11', 18, 3, null, null),
       (15, 'Justin12', 18, 3, null, null),
       (16, 'Justin13', 18, 3, null, null),
       (17, 'Justin14', 18, 3, null, null),
       (18, 'Justin15', 18, 3, null, null),
       (19, 'Justin16', 18, 3, null, null);

INSERT INTO user_address (id, user_id, address)
VALUES (1, 1, 'addr1'),
       (2, 1, 'addr2');

INSERT INTO user_role (id, user_id, role, tenant_id)
VALUES (1, 1, 'admin', 1),
       (2, 2, 'user', 1),
       (3, 2, 'admin', 1),
       (4, 1, 'admin', 11);

DELETE
FROM udo;

INSERT INTO `udo` (`id`, `tenant_id`, `attr_string`, `attr_long`, `attr_timestamp`)
VALUES (1, 10, '199', 1682251043000, NULL);

DELETE
FROM udo2;

INSERT INTO udo2 (id, tenant_id, attr1, attr2, attr3)
VALUES (1, 13, '***', '***', 16000),
       (2, 13, '111', '111', 26000),
       (3, 13, '111', '111', 36000),
       (4, 13, null, null, 36000);