## Quick Start

### 1. 导入依赖
```gradle
dependencies {
  implementation 'com.convertlab.foundation.library:meta-health-check:{version}'
}
```

### 2. 开启meta-health-check
XxxApplication中增加注解@EnableMetaHealthCheck
```java
@EnableMetaHealthCheck
public class XxxApplication {
  //...
}
```

### 3. 定义Meta校验规则
参考[BasicMetaValidationRule](src/main/java/com/convertlab/foundation/libaray/meta/health/BasicMetaValidationRule.java)定义自己的Meta Validation Rule：
```java
public enum XxxMetaValidationRule implements MetaValidationRule {
    //...
}
```

### 4. 定义Meta Checker
对每类Meta对象，实现Meta Checker，确保第三步中定义的每条Meta Validation Rule被验证到。
```java
@MetaCheckerAnnotation
@RequiredArgsConstructor
public class GdmEntityChecker implements MetaChecker<GdmEntity> {
  @Override
  public List<Issue> check(@Nonnull GdmEntity entity) {
      //TODO Your check code here.
    return new ArrayList<>();
  }
}
```
注：
* MetaChecker实现类被注解@MetaCheckerAnnotation修饰
* 实现MetaChecker<T>接口
* Override List<Issue> check(T t)方法,check方法不抛出异常，将问题记录在返回的Issue List中。

### 5. 定义Meta Loader
对每类Meta对象，实现Meta Loader，加载所有需要校验的Meta对象
```java
@MetaLoaderAnnotation
@RequiredArgsConstructor
public class GdmEntityLoader implements MetaLoader<GdmEntity> {
    
    @Override
    public List<GdmEntity> loadAll() {
        //TODO Your load code here
      return new ArrayList<>();
    }
}
```
注：
* MetaLoader实现类被注解@MetaLoaderAnnotation修饰
* 实现MetaLoader<T>接口
* Override public List<T> loadAll()方法。

### 6. Meta Health Check Url
全租户Meta校验：
```
curl --location 'http://localhost:8080/v1/meta/health'
```

指定租户Meta校验：
```
curl --location 'http://localhost:8080/v1/meta/health' \
--header 'x-tenant-id: 1'
```
