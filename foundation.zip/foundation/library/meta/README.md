# meta service 

meta service 提供通用的 meta 存储服务，包括 meta 的分级，meta 的版本，meta 的查询，meta 的更新，meta 的删除等。
meta 的数据格式使用 JSON, 存储规划使用 MongoDB。

## meta 存储的组成部分 

meta 的存储层级初步规划分四部分，分别为 GDM、 business、UI和扩展 。

| 分级       | 路径           | 说明          |
|----------|--------------|-------------|
| GDM      | /v1/meta/gdm | GDM meta |
| business | /v1/meta/biz | 业务meta    |
| ui       | /v1/meta/ui  | UI meta   |
| ext      | /v1/meta/ext | 扩展meta    |


## business meta

### business meta API 

business meta 的每个实体都有对应的 objectName, objectName 一般是驼峰命名，为了兼容历史数据，以 `c_` 和 `cp_` 开头的 objectName 也是合法的。
objectName 在 business meta 中唯一标识一个实体，不能重复。

business meta 有内置的一级路径，每个路径保存一类实体，如下表所示：

| business meta 一级路径   | 说明           |
|----------------------|--------------|
| /v1/meta/biz/objects | 实体对象meta |
| /v1/meta/biz/events  |  事件meta |
| /v1/meta/biz/gem     | GEM meta, GEM meta不是根节点，有下一级的路径 |
| /v1/meta/biz/ext     | business meta 的扩展 meta|

#### 对象meta

##### 创建对象meta

<details>
<summary> <code> 
 POST /v1/meta/biz/objects 
</code></summary>

这里以 `/v1/meta/biz/objects` 为例，对所有 business meta 的以及路径，请求的定义都是一样的。

###### request payload

请求的通用结构如下：
- 其中 objectName 为必填字段，且在 business meta 存储内，objectName 唯一标识一个实体。
- data 为对象，保存 meta 数据。注意 data 必须是一个对象，不能是数组或者其他类型。

```json
{
  "objectName": "${objectName}",
  "data": {}
}

```

以创建 customer 的 object meta 为例：

```json
{
  "objectName": "customer",
  "data": {
    "groupName": "customer",
    "groupLabel": "客户属性",
    "enGroupLabel": "",
    "twGroupLabel": "客戶屬性",
    "showInFilter": true,
    "showInDimension": true,
    "showInFlow": true,
    "props": [
      {
        "name": "ownerId",
        "label": "客户负责人",
        "enLabel": "",
        "twLabel": "客戶負責人",
        "type": "Users",
        "innerType": "Integer",
        "exportable": true,
        "inDetailView": true,
        "isDropdown": true,
        "filterable": true,
        "editable": true,
        "frontendEditable": true,
        "valuable": false,
        "inForm": false,
        "dimension": true,
        "sensitive": false
      },
      {
        "name": "attr2",
        "used": true,
        "isAttr": true,
        "filterable": true,
        "inDetailView": true,
        "inForm": true,
        "meta": {
          "url": "/codelists"
        },
        "label": "型号",
        "type": "Text",
        "isDropdown": true,
        "frontendEditable": true,
        "regular": true,
        "order": 0,
        "editable": true,
        "category": "customer",
        "dimension": true,
        "exportable": true,
        "cdpColumn": "attr2",
        "valuable": true
      }
    ]
  }
}

```

###### response

返回的数据结构如下：

```json5
{
  "$version": 1684408987023,
  "$self": "/v1/meta/biz/objects/${objName}",
  "$basePath": "/v1/meta/biz/objects",
  "objectName": "customer",
  "data": {} 
}
```

**说明**：
- $version 为 meta 的版本，单位为毫秒，使用long类型存储。
- $self 为 meta 的路径，可以定位 meta。
- $basePath 为 meta 的根路径，可以定位 meta 的根路径。
- objectName 为 meta 的唯一标识，客户保存制定
- data 为 meta 的内容，和请求内容一致

</details>


##### 更新对象meta
<details>
<summary> <code> 
PUT /v1/meta/biz/objects/{objectName} 
</code></summary>

这里以 `/v1/meta/biz/objects` 为例，对所有 business meta 的以及路径，请求的定义都是一样的。

请求的通用结构如下：
- 其中 objectName 为选填字段
- data 为对象，保存 meta 数据。注意 data 必须是一个对象，不能是数组或者其他类型。

```json
{
  "objectName": "${objectName}",
  "data": {}
}

```
</details>

##### 删除对象meta
<details>
<summary> <code> 
DELETE /v1/meta/biz/objects/{objectName}
</code></summary>

这里以 `/v1/meta/biz/objects` 为例，对所有 business meta 的以及路径，请求的定义都是一样的。

</details>

##### 查询对象meta
<details>
<summary> <code> 
GET /v1/meta/biz/objects/{objectName}
</code></summary>

这里以 `/v1/meta/biz/objects` 为例，对所有 business meta 的以及路径，请求的定义都是一样的。
</details>


##### 查询 `$basePath` 下的所有对象meta
<details>
<summary> <code> 
GET /v1/meta/biz/objects
</code></summary>

这里以 `/v1/meta/biz/objects` 为例，对所有 business meta 的以及路径，请求的定义都是一样的。

###### response

返回的数据结构如下：

```json5
{
  "$basePath": "/v1/meta/biz/objects",
  "data": [
    {
      "$version": 1684408987023,
      "$self": "/v1/meta/biz/objects/customer",
      "objectName": "customer",
    },
    {
      "$version": 1684408987023,
      "$self": "/v1/meta/biz/objects/product",
      "objectName": "product",
    }
  ]
}
```

</details>