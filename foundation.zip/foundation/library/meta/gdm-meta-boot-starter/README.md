# Gdm Meta Client使用说明

### Step 1 导入依赖
```groovy
    implementation("com.convertlab.foundation.library:gdm-meta-boot-starter:${branch}.2+")
```

### Step 2 配置gdm meta server url
```yaml
gdmMetaService:
  serverUrl: 'http://foundation:8080'
```

### Setp 3 使用GsMetaClient
```java
@RequiredArgsConstructor
public class XxxService {
    private final GsMetaClient gsMetaClient;
    
    public void test(String entityName) {
        GdmEntity entity = gsMetaClient.getEntity(entityName);
        Assert.notNull(entity, "Entity "+entityName+ " not found");
        
    }
}

```