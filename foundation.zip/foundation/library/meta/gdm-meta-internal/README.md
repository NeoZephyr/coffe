
1. 迁移到 gdm-meta-internal 的操作步骤和遗留问题
   1. 拷贝 com.convertlab.foundation.library.gdmmeta.model.persistance;
   2. 把 Entity/Field/TablePartition/Inheritance 相关的代码移动到 这些类。
   3. 删除原 persistance 目录
   4. 更新对 persistance 目录类的引用 
      s/com.convertlab.foundation.gdmmeta.model.persistance/com.convertlab.foundation.library.gdmmeta.model.persistance/g
      需要删除mongoDB存储，因为序列化信息中保存了 _class
   5. GdmNamingUtils and MetaFilterHelper 迁移
   4. 迁移 dao/repository
   5. 迁移 service/serviceImpl/ut