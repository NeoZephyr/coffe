## Requirements

* Java 8

<br>

## 功能列表

* 多租户模式下，消息发送端自动传递当前的 TenantId 到接收端，可选择通过 Message 的 Header 还是 Payload 作为 TenantId 载体。

* 多租户模式下，无论是批量消费还是单条消费，实现多租户隔离，在当前线程中自动注入租户上下文信息。

<br>

## 如何使用

在`build.gradle`添加 gradle 依赖项：

```gradle
dependencies {
  implementation 'com.convertlab.foundation.library:kafka-boot-starter:{version}'
}
```

在`application.yml`中通过`spring.kafka.*`配置相关信息，具体配置请参考[Spring Kafka Properties](https://docs.spring.io/spring-boot/docs/current/reference/html/application-properties.html#application-properties.integration.spring.kafka.bootstrap-servers)
.

```yaml
spring:
  kafka:
    bootstrap-servers: ${kafka.brokers}
    ...
```

由于多租户模式下需要借助 Redis 进行幂等处理，因此需要添加对 Redis 的依赖。
```gradle
dependencies {
  implementation "com.convertlab.library:spring-boot-kafka:${version}"
  implementation 'org.springframework.boot:spring-boot-starter-data-redis'
}
```

相应地需要在`application.yml`中通过`spring.redis.*`配置Redis连接信息。
```yaml
spring:
  kafka:
    bootstrap-servers: ${brokers}
  redis:
    host: ${host}
    port: ${port}
    database: ${database}
    ...
```

<br>

### 全部可配置项

```yaml
convertlab:
  kafka:
    topic:
      prefix: ns_
      default-config:
        identifier:
          request-id:
            - key: requestId
              location: header
        propagation:
          request-id:
            - key: requestId
              location: header
          user-id:
            - key: userId
              location: header
          user-name:
            - key: userName
              location: header
        multi-tenancy:
          identifier:
            tenant-id:
              - key: tenantId
                location: header
            tenant-name:
              - key: tenantName
                location: header
          propagation:
            tenant-id:
              - key: tenantId
                location: header
            tenant-name:
              - key: tenantName
                location: header
      configs-topic-specific:
        my-topic:
          multi-tenancy:
            identifier:
              tenant-id:
                - key: tenantId
                  location: payload
            propagation:
              tenant-id:
                - key: tenantId
                  location: payload
    listener:
      default-config:
        ack-mode: record
      configs-listener-specific:
        my_listener:
          ack-mode: record
```

**以上配置已有默认值，如无特殊不需要指定。**

| 配置项 | 值类型 | 示例 |解释 |
| --- | :--: | :--: | :-- |
| convertlab.kafka.topic.prefix | | | 为Topic添加的前缀 |
| convertlab.kafka.topic.default-config.identifier.request-id |  |  | 指定如何从消息中取得 requestId, 默认从 requestId Header 取得 |
| convertlab.kafka.topic.default-config.propagation.request-id |  |  | 指定如何通过消息传递 requestId, 默认通过 requestId Header 传递 |
| convertlab.kafka.topic.default-config.multi-tenancy.identifier.tenant-id |  |  | 指定如何从消息中取得 TenantId, 默认从 TenantId Header 取得 |
| convertlab.kafka.topic.default-config.multi-tenancy.propagation.tenant-id |  |  | 指定如何通过消息传递 TenantId, 默认通过 TenantId Header 传递 |
| convertlab.kafka.topic.configs-topic-specific.{topic}.* |  |  | 对于特定 Topic 做覆盖默认值的配置 |
| convertlab.kafka.listener.default-config.ack-mode |  |  | 指定 Listener 的 Ack Mode |
| convertlab.kafka.listener.configs-listener-specific.{listener}.* |  |  | 对于特定 Listener 做覆盖默认值的配置 |

<br>

### 使用`KafkaTemplate`发送 Kafka 消息

用法和原生 Spring Kafka 一致，请参考[Spring KafkaTemplate](https://docs.spring.io/spring-kafka/reference/html/#kafka-template)

<br>

#### 发送消息往旧框架服务

KafkaTemplate的泛型参数设置为`<String, Map<?, ?>>`，即 payload 的类型为`Map<?, ?>`。

```java
    @Autowired
    KafkaTemplate<String, Map<?, ?>> kafkaTemplate;
```

<br>

在application.yml中把这个topic各项目的location属性设置为`payload`。
```yaml
convertlab:
  kafka:
    topic:
      configs-topic-specific:
        {topic名}:
            propagation:
              request-id:
                - key: requestId
                  location: payload
            multi-tenancy:
              propagation:
                tenant-id:
                  - key: tenantId
                    location: payload
```

<br>

### 使用`@KafkaListener`接收 kafka 消息

```java
@Component
public class RecordConsumer {

  @KafkaListener(topics = "my-topic", groupId = "my-consumer-group", concurrency = "3")
  public void receive(DemoModel message) {
    ...
  }
}
```
* topics：订阅的 Topic，建议不要订阅多个 Topic。
* groupId: Consumer Group 名。
* concurrency：Consumer 数量。

以上属性都支持`SpEL表达式`和环境变量。

**请勿在方法参数中声明 Acknowledgment，不要自行操作 Acknowledgment。**

<br>

#### 接收单条消息

确保`@KafkaListener`的`batch`属性未指定。

```java
@Component
public class RecordConsumer {

  @KafkaListener(topics = "my-topic", groupId = "my-consumer-group", concurrency = "3")
  public void receive(DemoModel message) {
    ...
  }
}
```

<br>

#### 接收批量消息

1. 把`@KafkaListener`的`batch`属性设置为 true。

2. 在接收消息的方法中声明集合类型的参数。

```java
@Component
public class BatchConsumer {

  @KafkaListener(
          topics = "my-topic",
          groupId = "my-consumer-group",
          concurrency = "3",
          batch = "true")
  public void receive(List<DemoModel> messages) {
    ...
  }
}
```

**在多租户模式下，批量消费时框架已经确保方法中每一批执行的都是相同租户ID的消息，并且在当前上下文中已自动注入了租户ID。**

<br>

#### 配置 Consumer 参数

通过`application.yml`中的`spring.kafka.consumer.*`属性可以配置全局 Consumer 参数。

```yaml
spring:
  kafka:
    consumer:
      auto-offset-reset: earliest
      enable-auto-commit: false
      properties:
        isolation:
          level: read_committed
```

通过`@KafkaListener`的`properties`属性可以配置单个 Consumer 的参数。

```java
@KafkaListener(
    topics = "my-topic",
    groupId = "my-consumer-group",
    concurrency = "3",
    properties = {
      "value.deserializer:org.apache.kafka.common.serialization.ByteArrayDeserializer",
      "max.poll.interval.ms:600000",
      "max.poll.records:100"
    })
```

<br>

#### 接收旧框架服务发来的消息

KafkaListener方法中的参数类型必须为`Map<String, Object>`。

```java
@KafkaListener(
    topics = "my-topic",
    groupId = "my-consumer-group",
    concurrency = "3")
public void receive(Map<String, Object> message) {
    ...
}
```

在application.yml中这个topic的各项目的location属性设置为`payload`。
```yaml
convertlab:
  kafka:
    topic:
      configs-topic-specific:
        {topic名}:
            identifier:
              request-id:
                - key: requestId
                  location: payload
            multi-tenancy:
              identifier:
                tenant-id:
                  - key: tenantId
                    location: payload
```