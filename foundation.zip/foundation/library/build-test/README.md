# Test cases for build
This is the module to write test cases for common builds, the purpose is
to check the source code commit is following the best practices.

# Current supported cases
1. Check the ENV variables are exposed into env-example.yml, which is
   used by DevOps team to setup the environment.
2. Check @Async annotation is using the reviewed executor, which is
   tenant aware and take care of the tenant context.

# How to use
0. Prerequisite: The Gradle project layout should follow `ma-mgt`, there
   must be a module named `application`.
1. Add dependency in `build.gradle` file in the `application` module
   ```groovy
    testImplementation 'org.junit.platform:junit-platform-suite-engine:1.8.1'
    testImplementation("com.convertlab.foundation.library:build-test:${branch}.+")
   ```
2. Create the test suite runner java class. Refer to
   [BuildTestSuite.java: Lines 7-11](../../application/src/test/java/com/convertlab/build/BuildTestSuite.java#L7-L11)
