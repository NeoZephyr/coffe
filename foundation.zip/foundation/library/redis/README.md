## Requirements

* Java 8

<br>

## 功能列表

* 提供 RedisTemplate 的定制子类 `TenantIsolationRedisTemplate` 实现多租户之间的数据隔离。

* 增强原生 `RedisTemplate` 的功能，实现以 JSON 形式序列化。

* 通过配置`application.yml`中的`convertlab.redis.*` 可连接多个 Redis 数据源。

* 提供 `@RedisCacheable`、`@RedisCachePut`、`@RedisCacheEvict` 支持对方法的执行结果用 Redis 做缓存。

* 提供 `@RedisLock` 支持用 Redis 做分布式锁控制方法的并发执行。

<br>

## 如何使用

在`build.gradle`添加 gradle 依赖项：

```gradle
dependencies {
  implementation 'com.convertlab.foundation.library:redis-boot-starter:{version}'
}
```

在`application.yml`中通过`spring.redis.*`配置 Redis
数据源，具体配置请参考[Spring Redis Properties](https://docs.spring.io/spring-boot/docs/current/reference/html/application-properties.html#appendix.application-properties.data)
.

```yaml
spring:
  redis:
    host: ${host}
    port: ${port}
    database: ${database}
    ...
```

<br>

### 在多租户模式的Spring Boot应用中使用`TenantIsolationRedisTemplate`实现多租户数据隔离

在代码中注入`TenantIsolationRedisTemplate`

```java
@Autowired
private TenantIsolationRedisTemplate tenantIsolationRedisTemplate;
```

然后就可以按照原生`RedisTemplate`的方式使用，就像这样:

```java
tenantIsolationRedisTemplate.opsForValue().set("mykey",value);
```

与原生`RedisTemplate`的区别在于，使用`TenantIsolationRedisTemplate`时会自动给 Redis 的 key 加上前缀来实现多租户间的数据隔离。

实际存储的key格式为 **${产品名的缩写}:t${租户ID}:${key}**

假设当前代码所属的Spring Boot应用隶属于DMHub产品、当前上下文中租户ID为6、那么在Redis中实际生成的 key 是以下这个样子：

```text
DMH:t6:mykey
```

**注意:** 如果需要在多租户模式的应用中进行跨租户间的数据访问（非必要不允许，需要在代码Review时提供理由），可以使用我们提供的另一个类`TenantIgnoredRedisTemplate`。

<br>

### 在非多租户模式的Spring Boot应用中使用`TenantIgnoredRedisTemplate`

在代码中注入`TenantIgnoredRedisTemplate`

```java
@Autowired
private TenantIgnoredRedisTemplate tenantIgnoredRedisTemplate;
```

与原生`RedisTemplate`的区别在于，使用`tenantIgnoredRedisTemplate`时会自动给 Redis 的 key 加上前缀来实现多租户间的数据隔离。

实际存储的key格式为 **${产品名的缩写}:tn :${key}**

假设当前代码所属的Spring Boot应用隶属于DMHub产品、那么在Redis中实际生成的 key 是以下这个样子：

```text
DMH:tn:mykey
```

<br>

### RedisTemplate使用规范

* **禁止直接使用原生`RedisTemplate`**。

* **使用`TenantIsolationRedisTemplate`和`TenantIgnoredRedisTemplate`进行赋值操作时，需要紧跟 xxxRedisTemplate.expire()
  命令，确保每一个key都设置了过期时间。**

<br>

### 配置Redis多数据源

在`application.yml`的`convertlab.redis.*`配置多数据源。

```yaml
convertlab:
  redis:
    source1:
      host: ${host}
      port: ${port}
      database: ${database}
      ...
    source2:
      host: ${host}
      port: ${port}
      database: ${database}
      ...

spring:
  redis:
    host: ${host}
    port: ${port}
    database: ${database}
```

例子中的"source1"和"source2"，我们称之为"qualifier"。

**注意**

* `convertlab.redis.${qualifier}.*` 的可配置项和 `spring.redis.*` 完全相同。
* 即使配置了`convertlab.redis.${qualifier}.*`，仍然需要同时配置`spring.redis.*`，因为`@RedisLock`使用的 Redis 连接将使用`spring.redis.*`指定的连接信息。

在代码中通过`@Autowired`结合`@Qualifier`注入`TenantIsolationRedisTemplate`或者`TenantIgnoredRedisTemplate`的Bean， Bean名字规则是 **
${qualifier}TenantIsolationRedisTemplate 或者 ${qualifier}TenantIgnoredRedisTemplate**

```java
@Autowired
@Qualifier("source1TenantIsolationRedisTemplate")
private TenantIsolationRedisTemplate source1TenantIsolationRedisTemplate;

@Autowired
@Qualifier("source2TenantIsolationRedisTemplate")
private TenantIsolationRedisTemplate source2TenantIsolationRedisTemplate;


@Autowired
@Qualifier("source1TenantIgnoredRedisTemplate")
private TenantIgnoredRedisTemplate source1TenantIgnoredRedisTemplate;

@Autowired
@Qualifier("source2TenantIgnoredRedisTemplate")
private TenantIgnoredRedisTemplate source2TenantIgnoredRedisTemplate;
```

在多数据源模式下，上下文中会存在多个Type为`TenantIsolationRedisTemplate`和`TenantIgnoredRedisTemplate`的Bean，所以需要使用`@Autowired`+`@Qualifier`
的组合来注入期望的实例。

<br>

### Redis缓存注解 `@RedisCacheable`
(Deprecated, 推荐直接使用Spring原生的@Cacheable注解，详见[configurable-cache](LOCALCACHE.md) )
```java
@RedisCacheable(key = "mykey", ttl = 3000)
public Value myMethod(String arg){...}
```

当调用方法myMethod时，首先在Redis中查询名字为mykey的key。如果存在mykey，直接返回存储在mykey的值，不实际执行myMethod的方法体；如果不存在mykey，则执行myMethod的方法体，并将执行的结果存入mykey中。

|        参数         |  必需  | 解释                                                                   |
|:-----------------:|:----:|----------------------------------------------------------------------|
|        key        |  是   | 存储在Redis中的key，实际在Redis中生成的key名和用TenantIsolationRedisTemplate生成的规则一致。 |
|        ttl        |  是   | 指定Redis key过期的时间，单位为毫秒。                                              |
| isTenantIsolation |  否   | 存储在Redis中的key是否进行多租户间隔离，默认为true。                                     |
|     qualifier     |  否   | Redis多数据源模式下使用，指定从哪一个数据源读写key。                                       |

key支持[SpEL表达式](https://www.baeldung.com/spring-expression-language) `#{...}`和 placeholder `${...}`，以下给出其中几种使用示例：

```java
// 常量值
@RedisCacheable(key = "abc", ttl = 3000)
public Value myMethod(String arg){...}
```

```java
// 包含环境变量
@RedisCacheable(key = "${myprop.attr1}", ttl = 3000)
public Value myMethod(String arg){...}
```

```java
// 包含环境变量并且进行运算
@RedisCacheable(key = "#{'${myprop.attr1}' + 'abc'}", ttl = 3000)
public Value myMethod(String arg){...}
```

```java
// 使用方法参数作为变量
@RedisCacheable(key = "#{#arg + 'abc'}", ttl = 3000)
public Value myMethod(String arg){...}
```

<br>

### Redis缓存注解 `@RedisCachePut`

```java
@RedisCachePut(key = "mykey", ttl = 3000)
public Value myMethod(String arg){...}
```

当调用方法myMethod时，首先执行myMethod的方法体，并将执行的结果存入mykey中。

参数与`@RedisCacheable`完全一致。

<br>

### Redis缓存注解 `@RedisCacheEvict`

```java
@RedisCacheEvict(key = "mykey", ttl = 3000, beforeInvocation = true)
public Value RedisCacheEvict(String arg){...}
```

当调用方法myMethod时，如果参数beforeInvocation为true，则首先从Redis中删除mykey，然后执行方法体；如果参数beforeInvocation为false，则首先执行方法体，然后从Redis中删除mykey。

其余参数与`@RedisCacheable`完全一致。

<br>

## Redis分布式锁
两种使用方式：
* 注解方式
* 非注解方式 

注意：foundation lib默认依赖Lettuce client，项目中不要引入redisson client

### Redis分布式锁注解 `@RedisLock`

必须使用`@EnableRedisLock`开启Redis分布式锁的功能。

```java
@RedisLock(key = "#{#arg}", waitTime = 3000)
public Value myMethod(String arg){...}
```

调用方法myMethod之前，首先尝试获取Redis并发锁mykey，如果获取成功，则执行方法体；如果等待3秒后仍然无法获得锁，产生异常`RedisLockException`
。

|        参数         | 必需  | 解释                                                                   |
|:-----------------:|:---:|----------------------------------------------------------------------|
|        key        |  是  | 分布式锁的key, 支持spel表达式 |
|        waitTime        |  否  | 等待获取锁的超时时间，单位毫秒，默认值为3000毫秒。                                          |
| leaseTime(deprecated) |  否  | 锁过期自动释放时间，单位毫秒，值为0时表示不自动释放，默认值为0。                                    |
|     isTenantIsolation     |  否  | 存储在Redis中的key是否进行多租户间隔离，默认为true。                                       |

**注意：** `@RedisLock`关联的Redis数据源连接信息由`spring.redis.*`配置。

### Redis分布式锁 非注解方式
示例代码如下：
```java
@Slf4j
@RequiredArgsConstructor
@Service
public class RedisLockTest {
  private final RedisLockRegistry lockRegistry;

  public boolean testLock(String key) {
    Lock lock = lockRegistry.obtain(key); //获取锁
    try {
      boolean locked = lock.tryLock(1, TimeUnit.SECONDS); //lock
      if (locked) {
        try {
          // your biz logic here
        } catch (Exception e) {
          log.error(e.getMessage(), e);
        } finally {
          lock.unlock();  //unlock
        }
      } else {
        log.warn("failed to acquire lock");
      }
      return locked;
    } catch (Exception e) {
      log.error(e.getMessage(), e);
      return false;
    }
  }
}
```
[示例代码](../../application/src/main/java/com/convertlab/foundation/misc/service/RedisLockTestService.java)
