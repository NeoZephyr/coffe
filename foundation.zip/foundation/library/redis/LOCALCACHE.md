## Configurable Cache Manager
在spring application.yml中配置Cache，示例如下：
```yaml
convertlab:
  caching:
    properties:
      -
        name: "local:demo"
        type: Local
        local:
          capacity: 1000
          ttl: 600000
      -
        name: "redis:demo"
        type: Redis
        redis:
          ttl: 86400000
      -
        name: "localBackedRedis:demo"
        type: LocalBackedRedis
        local:
          capacity: 1000
          ttl: 600000
        redis:
          ttl: 86400000
      -
        name: "l2:demo"
        type: L2
        local:
          capacity: 1000
          ttl: 600000
        redis:
          ttl: 86400000
        l2:
          l1HashKeyName: "l1-map"
          l2HashKeyPrefix: "l2-map"
          warmupBeanName: L2CacheWarmup
          warmupDelay: 30000
      -
        name: default
        type: Local
        local:
          capacity: 1000
          ttl: 600000
```
参数说明：
* name - Cache实例的名字
* type - Cache的类型，可以为Local, Redis, LocalBackedRedis, L2, NotifiableLocal
* local.capacity - 缓存类型为Local(CaffeineCache)的size
* local.ttl - Local Cache(CaffeineCache)的过期时间，单位为毫秒
* redis.ttl - Redis Cache的过期时间，单位为毫秒
* l2.l1HashKeyName - L2 Cache的L1 Hash Key的名字
* l2.l2HashKeyPrefix - L2 Cache的L2 Hash Key的前缀
* l2.warmupBeanName - L2 Cache延迟预热的Bean name，可以为空
* l2.warmupDelay - L2 Cache延迟预热delay时间，单位为毫秒

根据配置创建Cache的逻辑: 
* 如果cache name命中配置的name，则使用配置创建相应Cache
* 如果没有命中配置，系统默认Cache类型为NotifiableLocal, capacity为1000， ttl为10分钟。
* 可以通过配置name为"default"的cache来override系统的默认配置。


## 各种缓存的特性
|        缓存类型         |  租户隔离  | 解释                                                                   |
|:-----------------:|:----:|----------------------------------------------------------------------|
|        Local        |  否   | Caffeine Cache实现的Local Cache，不区分租户，evict操作仅影响当前节点，不会通知集群的其它节点 |
|        Redis        |  是   | Redis Cache，区分租户，clear操作通过scan实现           |
| LocalBackedRedis |  是   | 本地 + redis 两级缓存， 区分租户， evict操作会通知集群的其它节点清本地缓存        |
|     L2     |  是   |  本地 + redis 两级缓存， 区分租户， evict操作会通知集群的其它节点清本地缓存，clear操作通过L2 cache精准清理  |
|     NotifiableLocal     |  是   | Caffeine Cache实现的Local Cache，区分租户，evict操作会通知集群的其它节点清本地缓存  |
|     Nope     |  N/A   | 不使用缓存  |

## Redis本地缓存(LocalBackedRedis)的特性
* 写缓存：同步写Redis和本地缓存
* 读缓存：本地缓存命中后不再访问远程Redis Server
* (微服务)Server A清缓存，异步通知Server B清除本地缓存
* 缓存中的key启用租户隔离

### Read flow:
```mermaid
graph TD
    A[Client SDK] -->|get by key| B(Local Cache)
    B --> |local cache miss| C(Redis Cache)
    C --> |redis cache miss| D(Database)
    D --> E{Not null?}
    E --> |put to redis cache| C
    E --> |put to local cache| B
```
### Evict flow:
```mermaid
graph TD
    A[Client SDK] -->|update by key| B(Database)
    B --> |evict redis cache| C(Redis Cache)
    C --> |evict local cache| D(Local Cache)
    D --> |evict local cache on notification| E(Server A)
    D --> F(Server B)
    D --> G(...)
```
## Redis本地缓存的使用场景
* 针对特定的meta数据，它们的特点是变化频率低，但是业务系统中大量高频访问，可以使用本地缓存来降低访问Redis Server的次数
* 这些数据的写入口在同一服务中，否则需要在所有的写入口执行cache evict操作

## 使用方法
### 注入依赖
```gradle
dependencies {
  implementation 'com.convertlab.foundation.library:redis-boot-starter:{version}'
}
```
### 开启本地缓存
```java
@EnableRedisLocalCaching
public class XxxApplication
```
### 使用Spring @Cacheable @CacheEvict注解操作缓存
```java
    @Cacheable(cacheNames = "xxx:meta", key = "('entity:').concat(#entityName)", cacheManager = "configurableCacheManager", condition = "#entityName!=null", unless = "#result==null")
    public GdmEntity get(String entityName){
        //...
   }

    @CacheEvict(cacheNames = "xxx:meta", key = "('entity:').concat(#entityName)", cacheManager = "configurableCacheManager", condition = "#entityName!=null")
    public void delete(String entityName) {
        //...
   }
```
参数说明：
* cacheNames - Cache实例的名字，Cache实例数和Redis Connection数量成正比。
* key - 一般格式为: #domain:#id, e.g. entity:customer，避免key重复
* cacheManager - 可以为空，默认为"configurableCacheManager"
* condition - 满足条件才执行
* unless -  缓存时排除满足unless条件的结果，建议将null排除

### 使用非注解方式操作缓存
```java
        CacheManager cacheManager = SpringBeans.getBean(CacheManager.class);
        Cache cache = cacheManager.getCache("xxx:meta");
        cache.clear();
```

## 最佳实践
* Client Side SDK中读(ById, ByName等)方法使用@Cacheable注解启用本地缓存
* Server Side DAO中写(update / delete)方法使用@CacheEvict注解清缓存，批量更新/删除方法需要在代码中使用非注解方式Evict Cache。
* 不使用@CachePut注解
* Cache key使用"#domain:#id"格式，避免key冲突
* 增加unless("#result==null")参数，不缓存null

