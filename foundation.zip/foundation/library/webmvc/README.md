## Requirements

* Java 8

<br>

## 功能列表

* 在每次请求中提供当前用户的上下文信息。

* 多租户模式下，在每次请求中提供当前租户的上下文信息。

* JSR-303 Bean Validation 支持。

* `BusinessException`在多个应用之间远程透传、错误提示信息的标准化显示。

* `bff`模式下，UI API 的 response 标准化。参考 [REST API规范](https://confluence.xiaoshu.biz/pages/viewpage.action?pageId=88911740) 。

* `bff`模式下，Open API 的 response 标准化。

* 全局异常处理。

* 在`bff`模式下，UI API 的错误提示信息的国际化(i18n)支持。

* 提供通用接口，例如`/ping`。

* 可配置的请求日志输出内容。

* URI访问权限控制。

<br>

## 如何使用

在`build.gradle`添加 gradle 依赖项：

```gradle
dependencies {
  implementation 'com.convertlab.foundation.library:webmvc-boot-starter:{version}'
}
```

<br>

### 全部可配置项

```yaml
convertlab:
  webmvc:
    identifier:
      request-id:
        - key: x-request-id
          location: header
      user-id:
        - key: x-user-id
          location: header
      user-name:
        - key: x-user-name
          location: header
      user-role:
        - key: x-user-role
          location: header
      dept-code:
        - key: x-user-dept
          location: header
    multi-tenancy:
      identifier:
        tenant-id:
          - key: x-tenant-id
            location: header
        tenant-name:
          - key: x-tenant-name
            location: header
      ignored-patterns:
        - /ping
        - /hello/**
        - POST /send
        - post /receive
    request-logging:
      ignored-patterns:
        - /**
      include-headers: on
      include-client-info: on
      include-query-string: on
```

**以上配置已有默认值，如无特殊不需要指定。** 

| 配置项                                               | 值类型 | 示例 | 解释                                                      |
|---------------------------------------------------| :--: | :--: |:--------------------------------------------------------|
| convertlab.webmvc.identifier.request-id             | list |  | 指定如何从上游服务取得 Request Id, 默认从 Header中 x-request-id 取得     |
| convertlab.webmvc.identifier.user-id              | list | | 指定如何从上游服务取得 User Id, 默认从 Header中 x-user-id 取得           |
| convertlab.webmvc.identifier.user-name            | list | | 指定如何从上游服务取得 User Name, 默认从 Header中 x-user-name 取得       |
| convertlab.webmvc.identifier.user-role            | list | | 指定如何从上游服务取得 User Roles, 默认从 Header中 x-user-role 取得      |
| convertlab.webmvc.identifier.dept-code            | list | | 指定如何从上游服务取得 Department Code, 默认从 Header中 x-dept-code 取得 |
| convertlab.webmvc.multi-tenancy.identifier.tenant-id | list | | 指定如何从上游服务取得 Tenant Id, 默认从 Header中 x-tenant-id 取得       |
| convertlab.webmvc.multi-tenancy.identifier.tenant-name | list | | 指定如何从上游服务取得 Tenant Name, 默认从 Header中 x-tenant-name 取得   |
| convertlab.webmvc.multi-tenancy.ignored-patterns  | list |  | 指定哪些请求不检查是否携带 Tenant Id                                 |
| convertlab.webmvc.request-logging.ignored-patterns | list | | 指定哪些请求不打印请求日志                                           |
| convertlab.webmvc.request-logging.include-headers | boolean | | 指定请求日志中是否输出请求Header                                     |
| convertlab.webmvc.request-logging.include-query-string | boolean | | 指定请求日志中是否输出请求参数                                         |
| convertlab.webmvc.request-logging.include-client-info | boolean | | 指定请求日志中是否输出客户端信息                                        |

<br>

### bff 模式 & backend 模式

`bff`和`backend`针对的是本 web 应用在微服务层次结构中的位置，请参考下图。

![微服务层次结构中的web应用](https://s2.loli.net/2022/04/11/agFL4ez8yNWbGZi.png)

* `backend`: 底层提供基础功能的 web 应用，提供 web 接口供上层服务调用。

* `bff`: 提供 Open API 和 UI API 两种形式的对外 web 接口。

通过在应用的`application.yml`中的`convertlab.webmvc.service-layer`配置项指定 web 应用启用哪种模式。

`bff`模式和`backend`模式的区别参考下表：

| 功能 | bff | backend |
| --- | :--: | :--: |
| 正常 response 格式标准化 | ✓ | ✕ |
| 全局异常处理 + 异常 response 格式标准化 | ✓ | ✓ |
| 错误提示信息多语言支持 | ✓ | ✕ |
| 提供当前租户的上下文信息 | ✓ | ✓ |
| 提供当前用户的上下文信息 | ✓ | ✓ |
| Tracing | ✓ | ✓ |

<br>

### `@RestController` & `@ViewController` & `@OpenApiController`

* `@ViewController`：提供 UI API 接口的 Controller 类。

* `@OpenApiController`：提供 Open API 接口的 Controller 类。

* `@RestController`：提供内部接口的 Controller 类。

|                               | @ViewController                                                               | @OpenApiController                                                            | @RestController |
|-------------------------------|-------------------------------------------------------------------------------|-------------------------------------------------------------------------------|---------------|
| 生效的层次                         | `bff`层                                                                        | `bff`层                                                                        | 任意层           |
| 正常 response body 标准化          | 是                                                                             | 是                                                                             | 否             |
| 全局异常处理 + 异常 response body 标准化 | 是                                                                             | 是                                                                             | 是             |
| Controller中 Method 返回类型       | 推荐是`GenericResponse`、`GenericListResponse`、`GenericPageResponse`、`void`四种类型之一 | 必须是`GenericResponse`、`GenericListResponse`、`GenericPageResponse`、`void`四种类型之一 | 任意类型          |
| Http Status Code              | 丰富的 status code                                                               | 全部200                                                                         | 丰富的 status code |
| 错误消息多语言支持                     | 支持多语言                                                                         | 英文                                                                            | 英文            |
| 异常 response body 的原则          | 对于需要展示的错误细节以 Human Readable 的风格展示，对于不适合展示的错误细节统一为"发生了内部异常"                    | 避免透露过多异常细节、通过`error.code`来区分错误原因 | 详细的错误信息，供上游服务知道产生异常的原因 |
| 功能权限鉴权                        | 针对 Role 的鉴权                                                                   | 针对 Scope 的鉴权                                                                  | 无             |
| 需要当前登录用户信息                    | 是                                                                             | 否                                                                             | 否 |

**注意：**`@ViewController`和`@OpenApiController`必须配合`convertlab.webmvc.service-layer = bff` 使用。

为了兼容之前版本的代码，`@ViewController` Controller Method的返回值可以是任何类型，但是经过 ResponseBodyAdvice 的加工处理后最终展现的是标准化的格式，为了更好地支持API文档自动生产工具，
尽量把`@ViewController` Controller Method的返回值统一成`GenericResponse`、`GenericListResponse`、`GenericPageResponse`、`void`四种类型之一，否则会导致文档和实际响应格式不一致的情况。

`@OpenApiController` Controller Method的返回值如果是`GenericResponse`、`GenericListResponse`、`GenericPageResponse`、`void`四种类型以外，会产生异常。

`@RestController`和`@ViewController`接口的 response 有2XX、3XX、4XX、5XX 多种类型的 status code，调用方可以通过 status code 来判断是否调用成功。

对于`@RestController`提供的内部接口，推荐通过`OpenFeign`等 web-client 框架调用，`OpenFeign`框架把 status code 不为 2XX 的 response 包装成 FeignException，通过 try-catch 可以捕获相应的异常。

对于`@ViewController`提供的 UI 接口，预想其调用方应该是前端的 js 代码，请勿使用`OpenFeign`等 web-client 框架调用，否则有可能发生反序列化异常。

对于`@OpenApiController`提供的 OpenAPI 接口，无论执行过程中是否成功，是否发生异常，status code 都是200，所以需要通过 response body 中是否存在相关的子元素来判断成功与否：
当 body 中存在 error 这个子元素时，表示发生了异常，再从 error.code 中获取异常的原因；如果不存在 error 子元素，表示执行成功。
OpenAPI 接口可以使用`OpenFeign`等 web-client 框架调用。

<br>

### 正常 Response Body 的标准化格式

**注意：** 正常 response body 的标准化格式只针对`bff`模式下的`@ViewController`和`@OpenApiController`提供的接口。

<br>

* 返回值为单个对象（包括单个Map）：
```java
@GetMapping("/single")
public GenericResponse<BookResponse> getGenericResponse() {
  BookResponse bookResponse =
     BookResponse.builder()
        .id(1211540797225183231L)
        .title("book-A")
        .price(50)
        .tags(Collections.singletonList("children"))
        .build();

  return GenericResponse.<BookResponse>builder().result(bookResponse).build();
}
```
生成的 response 格式：
```json
{
  "result": {
    "id": "1211540797225183231",
    "title": "book-A",
    "price": 50,
    "tags": [
      "children"
    ],
    "issueDate": "2022-03-29T05:42:37.229Z"
  }
}
```

<br>

* 返回值为List：
```java
@GetMapping("/list")
public GenericListResponse<BookResponse> getGenericListResponse() {
  List<BookResponse> list =
      Lists.newArrayList(
          BookResponse.builder()
              .id(1211540797225183231L)
              .title("book-A")
              .tags(Collections.singletonList("comics"))
              .build(),
          BookResponse.builder()
              .id(1211540797225183232L)
              .title("book-B")
              .tags(Lists.newArrayList("mystery", "detective"))
              .build());

  return GenericListResponse.<BookResponse>builder().results(list).build();
}
```
生成的 response 格式：
```json
{
  "results": [
    {
      "id": "1211540797225183231",
      "title": "book-A",
      "price": 0,
      "tags": [
        "comics"
      ]
    },
    {
      "id": "1211540797225183232",
      "title": "book-B",
      "price": 0,
      "tags": [
        "mystery",
        "detective"
      ]
    }
  ]
}
```

<br>

* 返回值为分页（GenericPage）类型：
```java
@GetMapping("/page")
default GenericPageResponse<BookResponse> getGenericPageResponse() {
  GenericPage<BookResponse> genericPage =
      GenericPage.<BookResponse>builder()
          .current(2)
          .total(100)
          .records(
              Lists.newArrayList(
                  BookResponse.builder()
                      .id(1211540797225183231L)
                      .title("book-A")
                      .tags(Collections.singletonList("comics"))
                      .build(),
                  BookResponse.builder()
                      .id(1211540797225183232L)
                      .title("book-B")
                      .tags(Lists.newArrayList("mystery", "detective"))
                      .build()))
          .build();

  return GenericPageResponse.<BookResponse>builder().pagination(genericPage).build();
}
```
生成的 response 格式：
```json
{
  "pagination": {
    "total": 100,
    "current": 2,
    "records": [
      {
        "id": "1211540797225183231",
        "title": "book-A",
        "price": 0,
        "tags": [
          "comics"
        ]
      },
      {
        "id": "1211540797225183232",
        "title": "book-B",
        "price": 0,
        "tags": [
          "mystery",
          "detective"
        ]
      }
    ]
  }
}
```

<br>

### 全局异常处理 + 异常 Response Body 的标准化格式

代码执行时产生的所有异常，如果开发者没有自行做 try-catch 处理，都将由`全局异常处理器`拦截并加工成标准化格式的 response body。

<br>

#### Spring MVC框架产生的异常

对于`@RestController`和`@ViewController`，异常类型和 status code 的对应关系如下：

| 异常类 | status code |
| --- | :--: |
| HttpRequestMethodNotSupportedException | 405 |
| HttpMediaTypeNotSupportedException | 415 |
| HttpMediaTypeNotAcceptableException | 406 |
| MissingPathVariableException | 500 |
| MissingServletRequestParameterException | 400 |
| ServletRequestBindingException | 400 |
| ConversionNotSupportedException | 500 |
| TypeMismatchException | 400 |
| HttpMessageNotReadableException | 400 |
| HttpMessageNotWritableException | 500 |
| MethodArgumentNotValidException | 400 |
| ConstraintViolationException| 400 |
| MissingServletRequestPartException | 400 |
| BindException | 400 |
| NoHandlerFoundException | 404 |
| AsyncRequestTimeoutException | 503 |

无论`@RestController`、`@ViewController`、`@OpenApiController`，对于Spring MVC框架产生的异常，除了`MethodArgumentNotValidException`以外，response body 的标准化格式如下。
`MethodArgumentNotValidException`请参考 'JSR-303 Bean Validation'
```json
{
  "error": {
    "code": "...",
    "message": "..."
  }
}
```

<br>

#### `BusinessException`业务异常

```java
throw new BusinessException(
        "error.code",            // error-code
        "MSG_A001",              // message-key
        new String[] {"a", "b"}, // message-arguments
        401                      // status-code
);
```
* error-code：错误码。
* message-key：消息资源文件中对应的key。
* message-arguments：当消息资源文件中对应消息内容中有类似 {0} 这样的占位符时，用于填充占位符的参数。
* status-code：在`bff`层的 response status code。如果不指定，默认为 521。

#### `@RestController`中产生的`BusinessException`
status code 固定为 521，response body 格式如下：
```json
{
  "error": {
    "code": "error.code",
    "message_code": "MSG_A001",
    "message_arguments": ["a", "b"],
    "http_status_code": 401
  }
}
```

#### `@ViewController`和`@OpenApiController`中产生的`BusinessException`

* `@ViewController`接口的 status code 由生成`BusinessException`时指定的 status-code 参数决定。
* `@OpenApiController`接口的 status code 固定为 200。

response body 格式如下：
```json
{
  "error": {
    "code": "error.code",
    "message": "..."
  }
}
```
`message_code`和`message_arguments`两个字段已经组装合并成了`message`字段。
其中`message`字段的值是通过 message-key 在`消息资源文件`中找到匹配的条目，结合 message-arguments 拼装而成。

`消息资源文件`默认为`src/main/resources/messages.properties`，也可以通过`spring.messages.basename`配置项来更改路径。
为了支持国际化，在同一目录下可以准备相同前缀的多语言文件，例如`messages_zh_CN.properties`。

`消息资源文件`中的内容示例如下：
```properties
MSG_A001 = price should higher than {0}
```

<br>

#### 其它异常

对于`@RestController`和`@ViewController`产生的其它类型异常，status code 固定为 500。

<br>

### JSR-303 Bean Validation

JSR-303：使用`javax.validation.constraints`包下的 Constraint 注解作为元数据，对数据进行校验。

* @Null
* @NotNull
* @NotBlank
* @NotEmpty
* @Max
* @Min
* @Size
* @AssertFalse
* @AssertTrue
* @DecimalMax
* @DecimalMin
* @Digits
* @Email
* @Future
* @FutureOrPresent
* @Negative
* @NegativeOrZero
* @Past
* @PastOrPresent
* @Pattern
* @Positive
* @PositiveOrZero

```java
public class Book {

  @NotNull
  private String title;

  @Min(value = 10)
  private float price;
}
```

当校验不通过时，会产生`MethodArgumentNotValidException`异常。
对于`@RestController`和`@ViewController`产生的`MethodArgumentNotValidException`异常，response 的 status code 为 400。

response body 格式如下：
```json
{
  "error": {
    "code": "bad.request",
    "field_errors": [
      {
        "field": "price",
        "reason": "must be greater than or equal to 10"
      },
      {
        "field": "title",
        "reason": "must not be null"
      }
    ]
  }
}
```

`@ViewController` response 中的`reason`字段支持国际化。Hibernate Validator 对每个 Constraint 注解已提供默认的多语言支持，参考`ValidationMessages.properties`。
```json
{
  "error": {
    "code": "bad.request",
    "field_errors": [
      {
        "field": "price",
        "reason": "最小不能小于10"
      },
      {
        "field": "title",
        "reason": "不能为null"
      }
    ]
  }
}
```

如果默认的错误消息不能满足您的需求，可以在 Constraint 注解的 message 属性指定对应的 message-key。
```java
  @NotNull(message = "MSG_001")
  private String title;

  @Min(value = 10, message = "MSG_002")
  private float price;
```

<br>

### 自动注入用户信息的上下文

在应用中通过`PrincipalContextHolder`能获得当前登录的用户信息。

用户登录信息需要从上游服务来的请求中取得，支持通过 Request Header 和 Request Parameter 传递用户信息。

<br>

### 自动注入租户信息的上下文

在应用中通过`TenantContextHolder`能获得当前登录的租户信息。

当前租户信息需要从上游服务来的请求中取得，支持通过 Request Header 或者 Request Parameter 传递租户信息。
如果无法取得 TenantId，将会产生异常。


对于某些确实无法从上游取得租户信息的 URL，有两种办法可以避免由于强制解析租户信息而产生异常：

* 通过`convertlab.webmvc.multi-tenancy.ignored-patterns`指定对于哪些 URL 的请求不需要解析当前租户信息，以 Ant 风格进行 URL 的匹配。

* 在这些 URL 对应的 Controller 的 Class 或者 Method 上添加`@TenantIgnore`注解。

<br>

### 激活和配置请求日志的调试模式

通过配置`convertlab.webmvc.request-logging.*`来指定是否输出请求的 Parameter、Header、Client Info 到日志。

所有项目都开启的输出日志如下图所示：
![2022-08-23_17-10-27.png](https://s2.loli.net/2022/08/23/Sz3vhb4nwZrNMIx.png)

<br>

### 添加自定义 HandlerInterceptor

如果需要添加自己的 HandlerInterceptor，可以通过注入一个`CustomOrderedHandlerInterceptor`接口实现类的方式。
```java
@Component
public class MyInterceptor implements CustomOrderedHandlerInterceptor {

  @Override
  public boolean preHandle(
      HttpServletRequest request, HttpServletResponse response, Object handler) {
    ...
  }

  @Override
  public List<String> getExcludePathPatterns() {
    ...
  }

  @Override
  public int getOrder() {
    ...
  }
}
```

* getExcludePathPatterns()：指定不希望被这个 HandlerInterceptor 处理的请求URL列表。如果返回 Null，表示所有请求都会被这个 HandlerInterceptor 处理。

* getOrder()：指定这个 HandlerInterceptor 在 Interceptor Chain 中的执行顺序，数值越大越靠后。**请确保 getOrder() 返回值大于1000**。

<br>

### 通过`@RequirePermission`声明访问接口需要的权限

@RequirePermission 注解作用于 Controller 类中声明 Request Mapping 的方法上。对接口的访问进行用户权限验证，如果当前用户拥有的角色不满足接口的权限要求，将产生`InsufficientPermissionException`异常。

```java
@RestController
public class SampleController {

    @RequirePermission({"admin","user"})
    @RequestMapping("/path/{profile}")
    public String test(@ResourceIdentifier @PathVariable("profile") String profile, @RequestParam("name") String name) {
        ...
    }
}
```
@RequirePermission注解的参数：
* permissions: 访问接口需要的权限列表。

使用`@ResourceIdentifier`注解在 Controller 方法的参数列表中标识 Resource 类型，可以和 `@PathVariable`、`@RequestParam`、`@RequestHeader`、`@CookieValue`、`@RequestAttribute`、`@MatrixVariable`等 Spring MVC 的注解搭配使用。

**`@ResourceIdentifier`注解只能标注在 String 类型的参数上。**

#### 自行实现`PermissionValidator`接口并且通过Java Configurator注册到Spring容器中

```java
boolean validate(@NotNull String methodSignature, @Nullable String resource, @Nullable String[] roles, @Nullable String[] permissions);
```
自行实现实现上述接口
* methodSignature: 方法签名，用于定位接口函数，主要用于在日志中打印。
* resource: 资源类型。
* roles: 当前用户拥有的角色列表。
* permissions: 当前接口需要的权限列表。

返回值为 true 表示验证通过，false 表示验证不通过。