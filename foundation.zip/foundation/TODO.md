# TODO记事本

2. 考虑是否使用更好的第三方版本依赖管理的格式toml，暂时先这样
3. 统一groupId, artifactId的格式
 - 已有的library，保持原有的groupId, artifactId

6. 在CI上跑编译docker image和jar包
7. 在CI上跑Helm Chart编译
8. 在Master环境中部署foundation service
9. 复制到ma core service

# Propose的package和maven pom coordinate 的结构
需要讨论一下！兼容性是问题
- `com.convertlab.foundation:application:0.1.0` or `com.convertlab.application:foundation:0.1.0`
- `com.convertlab.foundation.library:redis-core:0.1.0`
- `com.convertlab.foundation.library:redis-spring-boot-starter:0.1.0`

App自己的东西
- `com.convertlab.macore.library:ma-core:0.1.0`
- `com.convertlab.macore.library:ma-gdm:0.1.0`
- `com.convertlab.maruntime.library:react-flow:0.1.0`
- `com.convertlab.datacore.library:data-gdm:0.1.0`